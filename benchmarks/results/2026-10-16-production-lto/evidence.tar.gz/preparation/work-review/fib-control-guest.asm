00000000000587b0 <f.2>:
   587b0:      	pushq	%rbp
   587b1:      	pushq	%r15
   587b3:      	pushq	%r14
   587b5:      	pushq	%r13
   587b7:      	pushq	%r12
   587b9:      	pushq	%rbx
   587ba:      	subq	$0x88, %rsp
   587c1:      	movq	%rdx, %r12
   587c4:      	movq	%rsi, %rbx
   587c7:      	movq	%rdi, %r14
   587ca:      	leaq	0x20(%rsp), %rdi
   587cf:      	movl	$0x3, %esi
   587d4:      	callq	0x29860 <native_roots_enter>
   587d9:      	movq	%r14, 0x38(%rsp)
   587de:      	movq	$0x0, 0x40(%rsp)
   587e7:      	testq	%r14, %r14
   587ea:      	je	0x7085f <f.2+0x180af>
   587f0:      	movq	%r14, 0x40(%rsp)
   587f5:      	cmpq	%rbx, 0x8(%r14)
   587f9:      	jle	0x7083e <f.2+0x1808e>
   587ff:      	leaq	0x68(%rsp), %r15
   58804:      	nopw	%cs:(%rax,%rax)
   5880e:      	nop
   58810:      	cmpb	$0x0, 0x1d249(%rip)     # 0x75a60 <g.6>
   58817:      	je	0x7085f <f.2+0x180af>
   5881d:      	cmpb	$0x0, 0x1d21c(%rip)     # 0x75a40 <g.2>
   58824:      	je	0x7085f <f.2+0x180af>
   5882a:      	cmpq	$0x0, 0x1d206(%rip)     # 0x75a38 <g.1>
   58832:      	je	0x7085f <f.2+0x180af>
   58838:      	movq	0x1d219(%rip), %r14     # 0x75a58 <g.5>
   5883f:      	movq	$0x2, 0x30(%rsp)
   58848:      	movq	%r15, %rdi
   5884b:      	xorl	%esi, %esi
   5884d:      	callq	0x29860 <native_roots_enter>
   58852:      	movq	$0x0, 0x78(%rsp)
   5885b:      	movq	%r14, %rdi
   5885e:      	callq	0x13700 <hide_i64>
   58863:      	movq	%rax, %r12
   58866:      	movq	%r15, %rdi
   58869:      	callq	0x298b0 <native_roots_leave>
   5886e:      	cmpb	$0x0, 0x1d1db(%rip)     # 0x75a50 <g.4>
   58875:      	je	0x7085f <f.2+0x180af>
   5887b:      	cmpq	$0x0, 0x1d1c5(%rip)     # 0x75a48 <g.3>
   58883:      	je	0x7085f <f.2+0x180af>
   58889:      	cmpq	$0x2, %r12
   5888d:      	jl	0x707ed <f.2+0x1803d>
   58893:      	jne	0x588b0 <f.2+0x100>
   58895:      	movl	$0x1, %r13d
   5889b:      	cmpq	$0x0, 0x1d1a5(%rip)     # 0x75a48 <g.3>
   588a3:      	jne	0x64637 <f.2+0xbe87>
   588a9:      	jmp	0x7085f <f.2+0x180af>
   588ae:      	nop
   588b0:      	cmpq	$0x4, %r12
   588b4:      	jb	0x588d1 <f.2+0x121>
   588b6:      	jne	0x588e9 <f.2+0x139>
   588b8:      	movl	$0x1, %r13d
   588be:      	cmpq	$0x0, 0x1d182(%rip)     # 0x75a48 <g.3>
   588c6:      	jne	0x5abad <f.2+0x23fd>
   588cc:      	jmp	0x7085f <f.2+0x180af>
   588d1:      	movl	$0x1, %ebp
   588d6:      	cmpq	$0x0, 0x1d16a(%rip)     # 0x75a48 <g.3>
   588de:      	jne	0x5e674 <f.2+0x5ec4>
   588e4:      	jmp	0x7085f <f.2+0x180af>
   588e9:      	cmpq	$0x6, %r12
   588ed:      	jb	0x5890a <f.2+0x15a>
   588ef:      	jne	0x58923 <f.2+0x173>
   588f1:      	movl	$0x1, %r15d
   588f7:      	cmpq	$0x0, 0x1d149(%rip)     # 0x75a48 <g.3>
   588ff:      	jne	0x5946b <f.2+0xcbb>
   58905:      	jmp	0x7085f <f.2+0x180af>
   5890a:      	movl	$0x1, %r14d
   58910:      	cmpq	$0x0, 0x1d130(%rip)     # 0x75a48 <g.3>
   58918:      	jne	0x59feb <f.2+0x183b>
   5891e:      	jmp	0x7085f <f.2+0x180af>
   58923:      	cmpq	$0x8, %r12
   58927:      	jb	0x58944 <f.2+0x194>
   58929:      	jne	0x5895d <f.2+0x1ad>
   5892b:      	movl	$0x1, %r15d
   58931:      	cmpq	$0x0, 0x1d10f(%rip)     # 0x75a48 <g.3>
   58939:      	jne	0x58c0b <f.2+0x45b>
   5893f:      	jmp	0x7085f <f.2+0x180af>
   58944:      	movl	$0x1, %r14d
   5894a:      	cmpq	$0x0, 0x1d0f6(%rip)     # 0x75a48 <g.3>
   58952:      	jne	0x58ecf <f.2+0x71f>
   58958:      	jmp	0x7085f <f.2+0x180af>
   5895d:      	cmpq	$0xa, %r12
   58961:      	jb	0x5897e <f.2+0x1ce>
   58963:      	jne	0x58997 <f.2+0x1e7>
   58965:      	movl	$0x1, %r15d
   5896b:      	cmpq	$0x0, 0x1d0d5(%rip)     # 0x75a48 <g.3>
   58973:      	jne	0x58a23 <f.2+0x273>
   58979:      	jmp	0x7085f <f.2+0x180af>
   5897e:      	movl	$0x1, %r14d
   58984:      	cmpq	$0x0, 0x1d0bc(%rip)     # 0x75a48 <g.3>
   5898c:      	jne	0x58aba <f.2+0x30a>
   58992:      	jmp	0x7085f <f.2+0x180af>
   58997:      	leaq	-0xa(%r12), %rsi
   5899c:      	movq	$0x0, 0x48(%rsp)
   589a5:      	movq	$0x3, 0x30(%rsp)
   589ae:      	xorl	%edi, %edi
   589b0:      	callq	0x70870 <f.3>
   589b5:      	subq	$0x8, %rsp
   589b9:      	cmpb	$0x0, 0x1d090(%rip)     # 0x75a50 <g.4>
   589c0:      	je	0x7085f <f.2+0x180af>
   589c6:      	cmpq	$0x0, 0x1d07a(%rip)     # 0x75a48 <g.3>
   589ce:      	je	0x7085f <f.2+0x180af>
   589d4:      	movq	%rax, %r14
   589d7:      	leaq	-0xb(%r12), %r13
   589dc:      	movq	$0x0, 0x48(%rsp)
   589e5:      	movq	$0x3, 0x30(%rsp)
   589ee:      	xorl	%edi, %edi
   589f0:      	movq	%r13, %rsi
   589f3:      	callq	0x70870 <f.3>
   589f8:      	subq	$0x8, %rsp
   589fc:      	cmpb	$0x0, 0x1d04d(%rip)     # 0x75a50 <g.4>
   58a03:      	je	0x7085f <f.2+0x180af>
   58a09:      	cmpq	$0x0, 0x1d037(%rip)     # 0x75a48 <g.3>
   58a11:      	je	0x7085f <f.2+0x180af>
   58a17:      	movq	%rax, %r15
   58a1a:      	addq	%r14, %r15
   58a1d:      	cmpq	$0xb, %r12
   58a21:      	ja	0x58a2a <f.2+0x27a>
   58a23:      	leaq	-0xa(%r12,%r15), %r14
   58a28:      	jmp	0x58aa0 <f.2+0x2f0>
   58a2a:      	movq	$0x0, 0x48(%rsp)
   58a33:      	movq	$0x3, 0x30(%rsp)
   58a3c:      	xorl	%edi, %edi
   58a3e:      	movq	%r13, %rsi
   58a41:      	callq	0x70870 <f.3>
   58a46:      	subq	$0x8, %rsp
   58a4a:      	cmpb	$0x0, 0x1cfff(%rip)     # 0x75a50 <g.4>
   58a51:      	je	0x7085f <f.2+0x180af>
   58a57:      	cmpq	$0x0, 0x1cfe9(%rip)     # 0x75a48 <g.3>
   58a5f:      	je	0x7085f <f.2+0x180af>
   58a65:      	movq	%rax, %r13
   58a68:      	leaq	-0xc(%r12), %rsi
   58a6d:      	movq	$0x0, 0x48(%rsp)
   58a76:      	movq	$0x3, 0x30(%rsp)
   58a7f:      	xorl	%edi, %edi
   58a81:      	callq	0x70870 <f.3>
   58a86:      	subq	$0x8, %rsp
   58a8a:      	cmpb	$0x0, 0x1cfbf(%rip)     # 0x75a50 <g.4>
   58a91:      	je	0x7085f <f.2+0x180af>
   58a97:      	movq	%rax, %r14
   58a9a:      	addq	%r13, %r14
   58a9d:      	addq	%r15, %r14
   58aa0:      	cmpq	$0x0, 0x1cfa0(%rip)     # 0x75a48 <g.3>
   58aa8:      	je	0x7085f <f.2+0x180af>
   58aae:      	cmpq	$0xb, %r12
   58ab2:      	je	0x58ad2 <f.2+0x322>
   58ab4:      	cmpq	$0xa, %r12
   58ab8:      	jne	0x58aeb <f.2+0x33b>
   58aba:      	leaq	-0x9(%r12,%r14), %r15
   58abf:      	cmpq	$0x0, 0x1cf81(%rip)     # 0x75a48 <g.3>
   58ac7:      	jne	0x58c05 <f.2+0x455>
   58acd:      	jmp	0x7085f <f.2+0x180af>
   58ad2:      	movl	$0x1, %r13d
   58ad8:      	cmpq	$0x0, 0x1cf68(%rip)     # 0x75a48 <g.3>
   58ae0:      	jne	0x58b77 <f.2+0x3c7>
   58ae6:      	jmp	0x7085f <f.2+0x180af>
   58aeb:      	leaq	-0xb(%r12), %rsi
   58af0:      	movq	$0x0, 0x48(%rsp)
   58af9:      	movq	$0x3, 0x30(%rsp)
   58b02:      	xorl	%edi, %edi
   58b04:      	callq	0x70870 <f.3>
   58b09:      	subq	$0x8, %rsp
   58b0d:      	cmpb	$0x0, 0x1cf3c(%rip)     # 0x75a50 <g.4>
   58b14:      	je	0x7085f <f.2+0x180af>
   58b1a:      	cmpq	$0x0, 0x1cf26(%rip)     # 0x75a48 <g.3>
   58b22:      	je	0x7085f <f.2+0x180af>
   58b28:      	movq	%rax, %r15
   58b2b:      	leaq	-0xc(%r12), %rbp
   58b30:      	movq	$0x0, 0x48(%rsp)
   58b39:      	movq	$0x3, 0x30(%rsp)
   58b42:      	xorl	%edi, %edi
   58b44:      	movq	%rbp, %rsi
   58b47:      	callq	0x70870 <f.3>
   58b4c:      	subq	$0x8, %rsp
   58b50:      	cmpb	$0x0, 0x1cef9(%rip)     # 0x75a50 <g.4>
   58b57:      	je	0x7085f <f.2+0x180af>
   58b5d:      	cmpq	$0x0, 0x1cee3(%rip)     # 0x75a48 <g.3>
   58b65:      	je	0x7085f <f.2+0x180af>
   58b6b:      	movq	%rax, %r13
   58b6e:      	addq	%r15, %r13
   58b71:      	cmpq	$0xc, %r12
   58b75:      	ja	0x58b7e <f.2+0x3ce>
   58b77:      	leaq	-0xb(%r12), %r15
   58b7c:      	jmp	0x58be4 <f.2+0x434>
   58b7e:      	movq	$0x0, 0x48(%rsp)
   58b87:      	movq	$0x3, 0x30(%rsp)
   58b90:      	xorl	%edi, %edi
   58b92:      	movq	%rbp, %rsi
   58b95:      	callq	0x70870 <f.3>
   58b9a:      	subq	$0x8, %rsp
   58b9e:      	cmpb	$0x0, 0x1ceab(%rip)     # 0x75a50 <g.4>
   58ba5:      	je	0x7085f <f.2+0x180af>
   58bab:      	cmpq	$0x0, 0x1ce95(%rip)     # 0x75a48 <g.3>
   58bb3:      	je	0x7085f <f.2+0x180af>
   58bb9:      	movq	%rax, %rbp
   58bbc:      	leaq	-0xd(%r12), %rsi
   58bc1:      	movq	$0x0, 0x48(%rsp)
   58bca:      	movq	$0x3, 0x30(%rsp)
   58bd3:      	xorl	%edi, %edi
   58bd5:      	callq	0x70870 <f.3>
   58bda:      	subq	$0x8, %rsp
   58bde:      	movq	%rax, %r15
   58be1:      	addq	%rbp, %r15
   58be4:      	cmpb	$0x0, 0x1ce65(%rip)     # 0x75a50 <g.4>
   58beb:      	je	0x7085f <f.2+0x180af>
   58bf1:      	addq	%r13, %r15
   58bf4:      	addq	%r14, %r15
   58bf7:      	cmpq	$0x0, 0x1ce49(%rip)     # 0x75a48 <g.3>
   58bff:      	je	0x7085f <f.2+0x180af>
   58c05:      	cmpq	$0x9, %r12
   58c09:      	ja	0x58c23 <f.2+0x473>
   58c0b:      	leaq	-0x8(%r12,%r15), %r14
   58c10:      	cmpq	$0x0, 0x1ce30(%rip)     # 0x75a48 <g.3>
   58c18:      	jne	0x58ec3 <f.2+0x713>
   58c1e:      	jmp	0x7085f <f.2+0x180af>
   58c23:      	cmpq	$0xa, %r12
   58c27:      	jne	0x58c42 <f.2+0x492>
   58c29:      	movl	$0x1, %r13d
   58c2f:      	cmpq	$0x0, 0x1ce11(%rip)     # 0x75a48 <g.3>
   58c37:      	jne	0x58d81 <f.2+0x5d1>
   58c3d:      	jmp	0x7085f <f.2+0x180af>
   58c42:      	cmpq	$0xc, %r12
   58c46:      	jb	0x58d54 <f.2+0x5a4>
   58c4c:      	leaq	-0xb(%r12), %rsi
   58c51:      	movq	$0x0, 0x48(%rsp)
   58c5a:      	movq	$0x3, 0x30(%rsp)
   58c63:      	xorl	%edi, %edi
   58c65:      	callq	0x70870 <f.3>
   58c6a:      	subq	$0x8, %rsp
   58c6e:      	cmpb	$0x0, 0x1cddb(%rip)     # 0x75a50 <g.4>
   58c75:      	je	0x7085f <f.2+0x180af>
   58c7b:      	cmpq	$0x0, 0x1cdc5(%rip)     # 0x75a48 <g.3>
   58c83:      	je	0x7085f <f.2+0x180af>
   58c89:      	movq	%rax, %r13
   58c8c:      	leaq	-0xc(%r12), %rbp
   58c91:      	movq	$0x0, 0x48(%rsp)
   58c9a:      	movq	$0x3, 0x30(%rsp)
   58ca3:      	xorl	%edi, %edi
   58ca5:      	movq	%rbp, %rsi
   58ca8:      	callq	0x70870 <f.3>
   58cad:      	subq	$0x8, %rsp
   58cb1:      	cmpb	$0x0, 0x1cd98(%rip)     # 0x75a50 <g.4>
   58cb8:      	je	0x7085f <f.2+0x180af>
   58cbe:      	cmpq	$0x0, 0x1cd82(%rip)     # 0x75a48 <g.3>
   58cc6:      	je	0x7085f <f.2+0x180af>
   58ccc:      	movq	%rax, %r14
   58ccf:      	addq	%r13, %r14
   58cd2:      	cmpq	$0xc, %r12
   58cd6:      	je	0x58d68 <f.2+0x5b8>
   58cdc:      	movq	$0x0, 0x48(%rsp)
   58ce5:      	movq	$0x3, 0x30(%rsp)
   58cee:      	xorl	%edi, %edi
   58cf0:      	movq	%rbp, %rsi
   58cf3:      	callq	0x70870 <f.3>
   58cf8:      	subq	$0x8, %rsp
   58cfc:      	cmpb	$0x0, 0x1cd4d(%rip)     # 0x75a50 <g.4>
   58d03:      	je	0x7085f <f.2+0x180af>
   58d09:      	cmpq	$0x0, 0x1cd37(%rip)     # 0x75a48 <g.3>
   58d11:      	je	0x7085f <f.2+0x180af>
   58d17:      	movq	%rax, %rbp
   58d1a:      	leaq	-0xd(%r12), %rsi
   58d1f:      	movq	$0x0, 0x48(%rsp)
   58d28:      	movq	$0x3, 0x30(%rsp)
   58d31:      	xorl	%edi, %edi
   58d33:      	callq	0x70870 <f.3>
   58d38:      	subq	$0x8, %rsp
   58d3c:      	cmpb	$0x0, 0x1cd0d(%rip)     # 0x75a50 <g.4>
   58d43:      	je	0x7085f <f.2+0x180af>
   58d49:      	movq	%rax, %r13
   58d4c:      	addq	%rbp, %r13
   58d4f:      	addq	%r14, %r13
   58d52:      	jmp	0x58d6d <f.2+0x5bd>
   58d54:      	movl	$0x1, %r14d
   58d5a:      	cmpq	$0x0, 0x1cce6(%rip)     # 0x75a48 <g.3>
   58d62:      	je	0x7085f <f.2+0x180af>
   58d68:      	leaq	-0xb(%r12,%r14), %r13
   58d6d:      	cmpq	$0x0, 0x1ccd3(%rip)     # 0x75a48 <g.3>
   58d75:      	je	0x7085f <f.2+0x180af>
   58d7b:      	cmpq	$0xb, %r12
   58d7f:      	ja	0x58d8b <f.2+0x5db>
   58d81:      	leaq	-0xa(%r12), %r14
   58d86:      	jmp	0x58ea2 <f.2+0x6f2>
   58d8b:      	cmpq	$0xc, %r12
   58d8f:      	jne	0x58daa <f.2+0x5fa>
   58d91:      	movl	$0x1, %r14d
   58d97:      	cmpq	$0x0, 0x1cca9(%rip)     # 0x75a48 <g.3>
   58d9f:      	jne	0x58e33 <f.2+0x683>
   58da5:      	jmp	0x7085f <f.2+0x180af>
   58daa:      	leaq	-0xc(%r12), %rsi
   58daf:      	movq	$0x0, 0x48(%rsp)
   58db8:      	movq	$0x3, 0x30(%rsp)
   58dc1:      	xorl	%edi, %edi
   58dc3:      	callq	0x70870 <f.3>
   58dc8:      	subq	$0x8, %rsp
   58dcc:      	cmpb	$0x0, 0x1cc7d(%rip)     # 0x75a50 <g.4>
   58dd3:      	je	0x7085f <f.2+0x180af>
   58dd9:      	cmpq	$0x0, 0x1cc67(%rip)     # 0x75a48 <g.3>
   58de1:      	je	0x7085f <f.2+0x180af>
   58de7:      	movq	%rax, %rbp
   58dea:      	leaq	-0xd(%r12), %rsi
   58def:      	movq	$0x0, 0x48(%rsp)
   58df8:      	movq	$0x3, 0x30(%rsp)
   58e01:      	xorl	%edi, %edi
   58e03:      	callq	0x70870 <f.3>
   58e08:      	subq	$0x8, %rsp
   58e0c:      	cmpb	$0x0, 0x1cc3d(%rip)     # 0x75a50 <g.4>
   58e13:      	je	0x7085f <f.2+0x180af>
   58e19:      	cmpq	$0x0, 0x1cc27(%rip)     # 0x75a48 <g.3>
   58e21:      	je	0x7085f <f.2+0x180af>
   58e27:      	movq	%rax, %r14
   58e2a:      	addq	%rbp, %r14
   58e2d:      	cmpq	$0xd, %r12
   58e31:      	ja	0x58e3a <f.2+0x68a>
   58e33:      	leaq	-0xc(%r12), %rax
   58e38:      	jmp	0x58e9f <f.2+0x6ef>
   58e3a:      	movq	$0x0, 0x48(%rsp)
   58e43:      	movq	$0x3, 0x30(%rsp)
   58e4c:      	xorl	%edi, %edi
   58e4e:      	leaq	-0xd(%r12), %rsi
   58e53:      	callq	0x70870 <f.3>
   58e58:      	subq	$0x8, %rsp
   58e5c:      	cmpb	$0x0, 0x1cbed(%rip)     # 0x75a50 <g.4>
   58e63:      	je	0x7085f <f.2+0x180af>
   58e69:      	cmpq	$0x0, 0x1cbd7(%rip)     # 0x75a48 <g.3>
   58e71:      	je	0x7085f <f.2+0x180af>
   58e77:      	movq	%rax, %rbp
   58e7a:      	leaq	-0xe(%r12), %rsi
   58e7f:      	movq	$0x0, 0x48(%rsp)
   58e88:      	movq	$0x3, 0x30(%rsp)
   58e91:      	xorl	%edi, %edi
   58e93:      	callq	0x70870 <f.3>
   58e98:      	subq	$0x8, %rsp
   58e9c:      	addq	%rbp, %rax
   58e9f:      	addq	%rax, %r14
   58ea2:      	cmpb	$0x0, 0x1cba7(%rip)     # 0x75a50 <g.4>
   58ea9:      	je	0x7085f <f.2+0x180af>
   58eaf:      	addq	%r13, %r14
   58eb2:      	addq	%r15, %r14
   58eb5:      	cmpq	$0x0, 0x1cb8b(%rip)     # 0x75a48 <g.3>
   58ebd:      	je	0x7085f <f.2+0x180af>
   58ec3:      	cmpq	$0x9, %r12
   58ec7:      	je	0x58ee7 <f.2+0x737>
   58ec9:      	cmpq	$0x8, %r12
   58ecd:      	jne	0x58f00 <f.2+0x750>
   58ecf:      	leaq	-0x7(%r12,%r14), %r15
   58ed4:      	cmpq	$0x0, 0x1cb6c(%rip)     # 0x75a48 <g.3>
   58edc:      	jne	0x59465 <f.2+0xcb5>
   58ee2:      	jmp	0x7085f <f.2+0x180af>
   58ee7:      	movl	$0x1, %r13d
   58eed:      	cmpq	$0x0, 0x1cb53(%rip)     # 0x75a48 <g.3>
   58ef5:      	jne	0x591a2 <f.2+0x9f2>
   58efb:      	jmp	0x7085f <f.2+0x180af>
   58f00:      	cmpq	$0xb, %r12
   58f04:      	jb	0x58f21 <f.2+0x771>
   58f06:      	jne	0x58f3a <f.2+0x78a>
   58f08:      	movl	$0x1, %r13d
   58f0e:      	cmpq	$0x0, 0x1cb32(%rip)     # 0x75a48 <g.3>
   58f16:      	jne	0x58fc6 <f.2+0x816>
   58f1c:      	jmp	0x7085f <f.2+0x180af>
   58f21:      	movl	$0x1, %r15d
   58f27:      	cmpq	$0x0, 0x1cb19(%rip)     # 0x75a48 <g.3>
   58f2f:      	jne	0x5905d <f.2+0x8ad>
   58f35:      	jmp	0x7085f <f.2+0x180af>
   58f3a:      	leaq	-0xb(%r12), %rsi
   58f3f:      	movq	$0x0, 0x48(%rsp)
   58f48:      	movq	$0x3, 0x30(%rsp)
   58f51:      	xorl	%edi, %edi
   58f53:      	callq	0x70870 <f.3>
   58f58:      	subq	$0x8, %rsp
   58f5c:      	cmpb	$0x0, 0x1caed(%rip)     # 0x75a50 <g.4>
   58f63:      	je	0x7085f <f.2+0x180af>
   58f69:      	cmpq	$0x0, 0x1cad7(%rip)     # 0x75a48 <g.3>
   58f71:      	je	0x7085f <f.2+0x180af>
   58f77:      	movq	%rax, %r15
   58f7a:      	leaq	-0xc(%r12), %rbp
   58f7f:      	movq	$0x0, 0x48(%rsp)
   58f88:      	movq	$0x3, 0x30(%rsp)
   58f91:      	xorl	%edi, %edi
   58f93:      	movq	%rbp, %rsi
   58f96:      	callq	0x70870 <f.3>
   58f9b:      	subq	$0x8, %rsp
   58f9f:      	cmpb	$0x0, 0x1caaa(%rip)     # 0x75a50 <g.4>
   58fa6:      	je	0x7085f <f.2+0x180af>
   58fac:      	cmpq	$0x0, 0x1ca94(%rip)     # 0x75a48 <g.3>
   58fb4:      	je	0x7085f <f.2+0x180af>
   58fba:      	movq	%rax, %r13
   58fbd:      	addq	%r15, %r13
   58fc0:      	cmpq	$0xc, %r12
   58fc4:      	ja	0x58fcd <f.2+0x81d>
   58fc6:      	leaq	-0xb(%r12,%r13), %r15
   58fcb:      	jmp	0x59043 <f.2+0x893>
   58fcd:      	movq	$0x0, 0x48(%rsp)
   58fd6:      	movq	$0x3, 0x30(%rsp)
   58fdf:      	xorl	%edi, %edi
   58fe1:      	movq	%rbp, %rsi
   58fe4:      	callq	0x70870 <f.3>
   58fe9:      	subq	$0x8, %rsp
   58fed:      	cmpb	$0x0, 0x1ca5c(%rip)     # 0x75a50 <g.4>
   58ff4:      	je	0x7085f <f.2+0x180af>
   58ffa:      	cmpq	$0x0, 0x1ca46(%rip)     # 0x75a48 <g.3>
   59002:      	je	0x7085f <f.2+0x180af>
   59008:      	movq	%rax, %rbp
   5900b:      	leaq	-0xd(%r12), %rsi
   59010:      	movq	$0x0, 0x48(%rsp)
   59019:      	movq	$0x3, 0x30(%rsp)
   59022:      	xorl	%edi, %edi
   59024:      	callq	0x70870 <f.3>
   59029:      	subq	$0x8, %rsp
   5902d:      	cmpb	$0x0, 0x1ca1c(%rip)     # 0x75a50 <g.4>
   59034:      	je	0x7085f <f.2+0x180af>
   5903a:      	movq	%rax, %r15
   5903d:      	addq	%rbp, %r15
   59040:      	addq	%r13, %r15
   59043:      	cmpq	$0x0, 0x1c9fd(%rip)     # 0x75a48 <g.3>
   5904b:      	je	0x7085f <f.2+0x180af>
   59051:      	cmpq	$0xc, %r12
   59055:      	je	0x59067 <f.2+0x8b7>
   59057:      	cmpq	$0xb, %r12
   5905b:      	jne	0x5907f <f.2+0x8cf>
   5905d:      	leaq	-0xa(%r12,%r15), %r13
   59062:      	jmp	0x5918e <f.2+0x9de>
   59067:      	movl	$0x1, %ebp
   5906c:      	cmpq	$0x0, 0x1c9d4(%rip)     # 0x75a48 <g.3>
   59074:      	jne	0x59108 <f.2+0x958>
   5907a:      	jmp	0x7085f <f.2+0x180af>
   5907f:      	leaq	-0xc(%r12), %rsi
   59084:      	movq	$0x0, 0x48(%rsp)
   5908d:      	movq	$0x3, 0x30(%rsp)
   59096:      	xorl	%edi, %edi
   59098:      	callq	0x70870 <f.3>
   5909d:      	subq	$0x8, %rsp
   590a1:      	cmpb	$0x0, 0x1c9a8(%rip)     # 0x75a50 <g.4>
   590a8:      	je	0x7085f <f.2+0x180af>
   590ae:      	cmpq	$0x0, 0x1c992(%rip)     # 0x75a48 <g.3>
   590b6:      	je	0x7085f <f.2+0x180af>
   590bc:      	movq	%rax, %r13
   590bf:      	leaq	-0xd(%r12), %rsi
   590c4:      	movq	$0x0, 0x48(%rsp)
   590cd:      	movq	$0x3, 0x30(%rsp)
   590d6:      	xorl	%edi, %edi
   590d8:      	callq	0x70870 <f.3>
   590dd:      	subq	$0x8, %rsp
   590e1:      	cmpb	$0x0, 0x1c968(%rip)     # 0x75a50 <g.4>
   590e8:      	je	0x7085f <f.2+0x180af>
   590ee:      	cmpq	$0x0, 0x1c952(%rip)     # 0x75a48 <g.3>
   590f6:      	je	0x7085f <f.2+0x180af>
   590fc:      	movq	%rax, %rbp
   590ff:      	addq	%r13, %rbp
   59102:      	cmpq	$0xd, %r12
   59106:      	ja	0x5910f <f.2+0x95f>
   59108:      	leaq	-0xc(%r12), %r13
   5910d:      	jmp	0x5917b <f.2+0x9cb>
   5910f:      	movq	$0x0, 0x48(%rsp)
   59118:      	movq	$0x3, 0x30(%rsp)
   59121:      	xorl	%edi, %edi
   59123:      	leaq	-0xd(%r12), %rsi
   59128:      	callq	0x70870 <f.3>
   5912d:      	subq	$0x8, %rsp
   59131:      	cmpb	$0x0, 0x1c918(%rip)     # 0x75a50 <g.4>
   59138:      	je	0x7085f <f.2+0x180af>
   5913e:      	movq	%rax, 0x10(%rsp)
   59143:      	cmpq	$0x0, 0x1c8fd(%rip)     # 0x75a48 <g.3>
   5914b:      	je	0x7085f <f.2+0x180af>
   59151:      	leaq	-0xe(%r12), %rsi
   59156:      	movq	$0x0, 0x48(%rsp)
   5915f:      	movq	$0x3, 0x30(%rsp)
   59168:      	xorl	%edi, %edi
   5916a:      	callq	0x70870 <f.3>
   5916f:      	subq	$0x8, %rsp
   59173:      	movq	%rax, %r13
   59176:      	addq	0x10(%rsp), %r13
   5917b:      	cmpb	$0x0, 0x1c8ce(%rip)     # 0x75a50 <g.4>
   59182:      	je	0x7085f <f.2+0x180af>
   59188:      	addq	%rbp, %r13
   5918b:      	addq	%r15, %r13
   5918e:      	cmpq	$0x0, 0x1c8b2(%rip)     # 0x75a48 <g.3>
   59196:      	je	0x7085f <f.2+0x180af>
   5919c:      	cmpq	$0xa, %r12
   591a0:      	ja	0x591b9 <f.2+0xa09>
   591a2:      	leaq	-0x9(%r12), %r15
   591a7:      	cmpb	$0x0, 0x1c8a2(%rip)     # 0x75a50 <g.4>
   591ae:      	jne	0x59451 <f.2+0xca1>
   591b4:      	jmp	0x7085f <f.2+0x180af>
   591b9:      	cmpq	$0xb, %r12
   591bd:      	jne	0x591d8 <f.2+0xa28>
   591bf:      	movl	$0x1, %r15d
   591c5:      	cmpq	$0x0, 0x1c87b(%rip)     # 0x75a48 <g.3>
   591cd:      	jne	0x59319 <f.2+0xb69>
   591d3:      	jmp	0x7085f <f.2+0x180af>
   591d8:      	cmpq	$0xd, %r12
   591dc:      	jb	0x592ed <f.2+0xb3d>
   591e2:      	leaq	-0xc(%r12), %rsi
   591e7:      	movq	$0x0, 0x48(%rsp)
   591f0:      	movq	$0x3, 0x30(%rsp)
   591f9:      	xorl	%edi, %edi
   591fb:      	callq	0x70870 <f.3>
   59200:      	subq	$0x8, %rsp
   59204:      	cmpb	$0x0, 0x1c845(%rip)     # 0x75a50 <g.4>
   5920b:      	je	0x7085f <f.2+0x180af>
   59211:      	cmpq	$0x0, 0x1c82f(%rip)     # 0x75a48 <g.3>
   59219:      	je	0x7085f <f.2+0x180af>
   5921f:      	movq	%rax, %r15
   59222:      	leaq	-0xd(%r12), %rsi
   59227:      	movq	$0x0, 0x48(%rsp)
   59230:      	movq	$0x3, 0x30(%rsp)
   59239:      	xorl	%edi, %edi
   5923b:      	callq	0x70870 <f.3>
   59240:      	subq	$0x8, %rsp
   59244:      	cmpb	$0x0, 0x1c805(%rip)     # 0x75a50 <g.4>
   5924b:      	je	0x7085f <f.2+0x180af>
   59251:      	cmpq	$0x0, 0x1c7ef(%rip)     # 0x75a48 <g.3>
   59259:      	je	0x7085f <f.2+0x180af>
   5925f:      	movq	%rax, %rbp
   59262:      	addq	%r15, %rbp
   59265:      	cmpq	$0xd, %r12
   59269:      	je	0x59300 <f.2+0xb50>
   5926f:      	movq	$0x0, 0x48(%rsp)
   59278:      	movq	$0x3, 0x30(%rsp)
   59281:      	xorl	%edi, %edi
   59283:      	leaq	-0xd(%r12), %rsi
   59288:      	callq	0x70870 <f.3>
   5928d:      	subq	$0x8, %rsp
   59291:      	cmpb	$0x0, 0x1c7b8(%rip)     # 0x75a50 <g.4>
   59298:      	je	0x7085f <f.2+0x180af>
   5929e:      	movq	%rax, 0x10(%rsp)
   592a3:      	cmpq	$0x0, 0x1c79d(%rip)     # 0x75a48 <g.3>
   592ab:      	je	0x7085f <f.2+0x180af>
   592b1:      	leaq	-0xe(%r12), %rsi
   592b6:      	movq	$0x0, 0x48(%rsp)
   592bf:      	movq	$0x3, 0x30(%rsp)
   592c8:      	xorl	%edi, %edi
   592ca:      	callq	0x70870 <f.3>
   592cf:      	subq	$0x8, %rsp
   592d3:      	cmpb	$0x0, 0x1c776(%rip)     # 0x75a50 <g.4>
   592da:      	je	0x7085f <f.2+0x180af>
   592e0:      	movq	%rax, %r15
   592e3:      	addq	0x10(%rsp), %r15
   592e8:      	addq	%rbp, %r15
   592eb:      	jmp	0x59305 <f.2+0xb55>
   592ed:      	movl	$0x1, %ebp
   592f2:      	cmpq	$0x0, 0x1c74e(%rip)     # 0x75a48 <g.3>
   592fa:      	je	0x7085f <f.2+0x180af>
   59300:      	leaq	-0xc(%r12,%rbp), %r15
   59305:      	cmpq	$0x0, 0x1c73b(%rip)     # 0x75a48 <g.3>
   5930d:      	je	0x7085f <f.2+0x180af>
   59313:      	cmpq	$0xc, %r12
   59317:      	ja	0x59323 <f.2+0xb73>
   59319:      	leaq	-0xb(%r12), %rbp
   5931e:      	jmp	0x59441 <f.2+0xc91>
   59323:      	cmpq	$0xd, %r12
   59327:      	jne	0x59341 <f.2+0xb91>
   59329:      	movl	$0x1, %ebp
   5932e:      	cmpq	$0x0, 0x1c712(%rip)     # 0x75a48 <g.3>
   59336:      	jne	0x593ce <f.2+0xc1e>
   5933c:      	jmp	0x7085f <f.2+0x180af>
   59341:      	leaq	-0xd(%r12), %rsi
   59346:      	movq	$0x0, 0x48(%rsp)
   5934f:      	movq	$0x3, 0x30(%rsp)
   59358:      	xorl	%edi, %edi
   5935a:      	callq	0x70870 <f.3>
   5935f:      	subq	$0x8, %rsp
   59363:      	cmpb	$0x0, 0x1c6e6(%rip)     # 0x75a50 <g.4>
   5936a:      	je	0x7085f <f.2+0x180af>
   59370:      	movq	%rax, 0x10(%rsp)
   59375:      	cmpq	$0x0, 0x1c6cb(%rip)     # 0x75a48 <g.3>
   5937d:      	je	0x7085f <f.2+0x180af>
   59383:      	leaq	-0xe(%r12), %rsi
   59388:      	movq	$0x0, 0x48(%rsp)
   59391:      	movq	$0x3, 0x30(%rsp)
   5939a:      	xorl	%edi, %edi
   5939c:      	callq	0x70870 <f.3>
   593a1:      	subq	$0x8, %rsp
   593a5:      	cmpb	$0x0, 0x1c6a4(%rip)     # 0x75a50 <g.4>
   593ac:      	je	0x7085f <f.2+0x180af>
   593b2:      	cmpq	$0x0, 0x1c68e(%rip)     # 0x75a48 <g.3>
   593ba:      	je	0x7085f <f.2+0x180af>
   593c0:      	movq	%rax, %rbp
   593c3:      	addq	0x10(%rsp), %rbp
   593c8:      	cmpq	$0xe, %r12
   593cc:      	ja	0x593d5 <f.2+0xc25>
   593ce:      	leaq	-0xd(%r12), %rax
   593d3:      	jmp	0x5943e <f.2+0xc8e>
   593d5:      	movq	$0x0, 0x48(%rsp)
   593de:      	movq	$0x3, 0x30(%rsp)
   593e7:      	xorl	%edi, %edi
   593e9:      	leaq	-0xe(%r12), %rsi
   593ee:      	callq	0x70870 <f.3>
   593f3:      	subq	$0x8, %rsp
   593f7:      	cmpb	$0x0, 0x1c652(%rip)     # 0x75a50 <g.4>
   593fe:      	je	0x7085f <f.2+0x180af>
   59404:      	movq	%rax, 0x10(%rsp)
   59409:      	cmpq	$0x0, 0x1c637(%rip)     # 0x75a48 <g.3>
   59411:      	je	0x7085f <f.2+0x180af>
   59417:      	leaq	-0xf(%r12), %rsi
   5941c:      	movq	$0x0, 0x48(%rsp)
   59425:      	movq	$0x3, 0x30(%rsp)
   5942e:      	xorl	%edi, %edi
   59430:      	callq	0x70870 <f.3>
   59435:      	subq	$0x8, %rsp
   59439:      	addq	0x10(%rsp), %rax
   5943e:      	addq	%rax, %rbp
   59441:      	addq	%rbp, %r15
   59444:      	cmpb	$0x0, 0x1c605(%rip)     # 0x75a50 <g.4>
   5944b:      	je	0x7085f <f.2+0x180af>
   59451:      	addq	%r13, %r15
   59454:      	addq	%r14, %r15
   59457:      	cmpq	$0x0, 0x1c5e9(%rip)     # 0x75a48 <g.3>
   5945f:      	je	0x7085f <f.2+0x180af>
   59465:      	cmpq	$0x7, %r12
   59469:      	ja	0x59488 <f.2+0xcd8>
   5946b:      	leaq	-0x6(%r12,%r15), %r14
   59470:      	cmpq	$0x0, 0x1c5d0(%rip)     # 0x75a48 <g.3>
   59478:      	leaq	0x68(%rsp), %r15
   5947d:      	jne	0x59fdf <f.2+0x182f>
   59483:      	jmp	0x7085f <f.2+0x180af>
   59488:      	cmpq	$0x8, %r12
   5948c:      	jne	0x594a7 <f.2+0xcf7>
   5948e:      	movl	$0x1, %r13d
   59494:      	cmpq	$0x0, 0x1c5ac(%rip)     # 0x75a48 <g.3>
   5949c:      	jne	0x59a33 <f.2+0x1283>
   594a2:      	jmp	0x7085f <f.2+0x180af>
   594a7:      	cmpq	$0xa, %r12
   594ab:      	jb	0x594c8 <f.2+0xd18>
   594ad:      	jne	0x594e1 <f.2+0xd31>
   594af:      	movl	$0x1, %r13d
   594b5:      	cmpq	$0x0, 0x1c58b(%rip)     # 0x75a48 <g.3>
   594bd:      	jne	0x59620 <f.2+0xe70>
   594c3:      	jmp	0x7085f <f.2+0x180af>
   594c8:      	movl	$0x1, %r14d
   594ce:      	cmpq	$0x0, 0x1c572(%rip)     # 0x75a48 <g.3>
   594d6:      	jne	0x59771 <f.2+0xfc1>
   594dc:      	jmp	0x7085f <f.2+0x180af>
   594e1:      	cmpq	$0xc, %r12
   594e5:      	jb	0x595f3 <f.2+0xe43>
   594eb:      	leaq	-0xb(%r12), %rsi
   594f0:      	movq	$0x0, 0x48(%rsp)
   594f9:      	movq	$0x3, 0x30(%rsp)
   59502:      	xorl	%edi, %edi
   59504:      	callq	0x70870 <f.3>
   59509:      	subq	$0x8, %rsp
   5950d:      	cmpb	$0x0, 0x1c53c(%rip)     # 0x75a50 <g.4>
   59514:      	je	0x7085f <f.2+0x180af>
   5951a:      	cmpq	$0x0, 0x1c526(%rip)     # 0x75a48 <g.3>
   59522:      	je	0x7085f <f.2+0x180af>
   59528:      	movq	%rax, %r13
   5952b:      	leaq	-0xc(%r12), %rbp
   59530:      	movq	$0x0, 0x48(%rsp)
   59539:      	movq	$0x3, 0x30(%rsp)
   59542:      	xorl	%edi, %edi
   59544:      	movq	%rbp, %rsi
   59547:      	callq	0x70870 <f.3>
   5954c:      	subq	$0x8, %rsp
   59550:      	cmpb	$0x0, 0x1c4f9(%rip)     # 0x75a50 <g.4>
   59557:      	je	0x7085f <f.2+0x180af>
   5955d:      	cmpq	$0x0, 0x1c4e3(%rip)     # 0x75a48 <g.3>
   59565:      	je	0x7085f <f.2+0x180af>
   5956b:      	movq	%rax, %r14
   5956e:      	addq	%r13, %r14
   59571:      	cmpq	$0xc, %r12
   59575:      	je	0x59607 <f.2+0xe57>
   5957b:      	movq	$0x0, 0x48(%rsp)
   59584:      	movq	$0x3, 0x30(%rsp)
   5958d:      	xorl	%edi, %edi
   5958f:      	movq	%rbp, %rsi
   59592:      	callq	0x70870 <f.3>
   59597:      	subq	$0x8, %rsp
   5959b:      	cmpb	$0x0, 0x1c4ae(%rip)     # 0x75a50 <g.4>
   595a2:      	je	0x7085f <f.2+0x180af>
   595a8:      	cmpq	$0x0, 0x1c498(%rip)     # 0x75a48 <g.3>
   595b0:      	je	0x7085f <f.2+0x180af>
   595b6:      	movq	%rax, %rbp
   595b9:      	leaq	-0xd(%r12), %rsi
   595be:      	movq	$0x0, 0x48(%rsp)
   595c7:      	movq	$0x3, 0x30(%rsp)
   595d0:      	xorl	%edi, %edi
   595d2:      	callq	0x70870 <f.3>
   595d7:      	subq	$0x8, %rsp
   595db:      	cmpb	$0x0, 0x1c46e(%rip)     # 0x75a50 <g.4>
   595e2:      	je	0x7085f <f.2+0x180af>
   595e8:      	movq	%rax, %r13
   595eb:      	addq	%rbp, %r13
   595ee:      	addq	%r14, %r13
   595f1:      	jmp	0x5960c <f.2+0xe5c>
   595f3:      	movl	$0x1, %r14d
   595f9:      	cmpq	$0x0, 0x1c447(%rip)     # 0x75a48 <g.3>
   59601:      	je	0x7085f <f.2+0x180af>
   59607:      	leaq	-0xb(%r12,%r14), %r13
   5960c:      	cmpq	$0x0, 0x1c434(%rip)     # 0x75a48 <g.3>
   59614:      	je	0x7085f <f.2+0x180af>
   5961a:      	cmpq	$0xb, %r12
   5961e:      	ja	0x5962a <f.2+0xe7a>
   59620:      	leaq	-0xa(%r12,%r13), %r14
   59625:      	jmp	0x59757 <f.2+0xfa7>
   5962a:      	cmpq	$0xc, %r12
   5962e:      	jne	0x59648 <f.2+0xe98>
   59630:      	movl	$0x1, %ebp
   59635:      	cmpq	$0x0, 0x1c40b(%rip)     # 0x75a48 <g.3>
   5963d:      	jne	0x596d1 <f.2+0xf21>
   59643:      	jmp	0x7085f <f.2+0x180af>
   59648:      	leaq	-0xc(%r12), %rsi
   5964d:      	movq	$0x0, 0x48(%rsp)
   59656:      	movq	$0x3, 0x30(%rsp)
   5965f:      	xorl	%edi, %edi
   59661:      	callq	0x70870 <f.3>
   59666:      	subq	$0x8, %rsp
   5966a:      	cmpb	$0x0, 0x1c3df(%rip)     # 0x75a50 <g.4>
   59671:      	je	0x7085f <f.2+0x180af>
   59677:      	cmpq	$0x0, 0x1c3c9(%rip)     # 0x75a48 <g.3>
   5967f:      	je	0x7085f <f.2+0x180af>
   59685:      	movq	%rax, %r14
   59688:      	leaq	-0xd(%r12), %rsi
   5968d:      	movq	$0x0, 0x48(%rsp)
   59696:      	movq	$0x3, 0x30(%rsp)
   5969f:      	xorl	%edi, %edi
   596a1:      	callq	0x70870 <f.3>
   596a6:      	subq	$0x8, %rsp
   596aa:      	cmpb	$0x0, 0x1c39f(%rip)     # 0x75a50 <g.4>
   596b1:      	je	0x7085f <f.2+0x180af>
   596b7:      	cmpq	$0x0, 0x1c389(%rip)     # 0x75a48 <g.3>
   596bf:      	je	0x7085f <f.2+0x180af>
   596c5:      	movq	%rax, %rbp
   596c8:      	addq	%r14, %rbp
   596cb:      	cmpq	$0xd, %r12
   596cf:      	ja	0x596d8 <f.2+0xf28>
   596d1:      	leaq	-0xc(%r12), %r14
   596d6:      	jmp	0x59744 <f.2+0xf94>
   596d8:      	movq	$0x0, 0x48(%rsp)
   596e1:      	movq	$0x3, 0x30(%rsp)
   596ea:      	xorl	%edi, %edi
   596ec:      	leaq	-0xd(%r12), %rsi
   596f1:      	callq	0x70870 <f.3>
   596f6:      	subq	$0x8, %rsp
   596fa:      	cmpb	$0x0, 0x1c34f(%rip)     # 0x75a50 <g.4>
   59701:      	je	0x7085f <f.2+0x180af>
   59707:      	movq	%rax, 0x10(%rsp)
   5970c:      	cmpq	$0x0, 0x1c334(%rip)     # 0x75a48 <g.3>
   59714:      	je	0x7085f <f.2+0x180af>
   5971a:      	leaq	-0xe(%r12), %rsi
   5971f:      	movq	$0x0, 0x48(%rsp)
   59728:      	movq	$0x3, 0x30(%rsp)
   59731:      	xorl	%edi, %edi
   59733:      	callq	0x70870 <f.3>
   59738:      	subq	$0x8, %rsp
   5973c:      	movq	%rax, %r14
   5973f:      	addq	0x10(%rsp), %r14
   59744:      	cmpb	$0x0, 0x1c305(%rip)     # 0x75a50 <g.4>
   5974b:      	je	0x7085f <f.2+0x180af>
   59751:      	addq	%rbp, %r14
   59754:      	addq	%r13, %r14
   59757:      	cmpq	$0x0, 0x1c2e9(%rip)     # 0x75a48 <g.3>
   5975f:      	je	0x7085f <f.2+0x180af>
   59765:      	cmpq	$0xb, %r12
   59769:      	je	0x59789 <f.2+0xfd9>
   5976b:      	cmpq	$0xa, %r12
   5976f:      	jne	0x597a1 <f.2+0xff1>
   59771:      	leaq	-0x9(%r12,%r14), %r13
   59776:      	cmpq	$0x0, 0x1c2ca(%rip)     # 0x75a48 <g.3>
   5977e:      	jne	0x59a2d <f.2+0x127d>
   59784:      	jmp	0x7085f <f.2+0x180af>
   59789:      	movl	$0x1, %ebp
   5978e:      	cmpq	$0x0, 0x1c2b2(%rip)     # 0x75a48 <g.3>
   59796:      	jne	0x598e3 <f.2+0x1133>
   5979c:      	jmp	0x7085f <f.2+0x180af>
   597a1:      	cmpq	$0xd, %r12
   597a5:      	jb	0x598b6 <f.2+0x1106>
   597ab:      	leaq	-0xc(%r12), %rsi
   597b0:      	movq	$0x0, 0x48(%rsp)
   597b9:      	movq	$0x3, 0x30(%rsp)
   597c2:      	xorl	%edi, %edi
   597c4:      	callq	0x70870 <f.3>
   597c9:      	subq	$0x8, %rsp
   597cd:      	cmpb	$0x0, 0x1c27c(%rip)     # 0x75a50 <g.4>
   597d4:      	je	0x7085f <f.2+0x180af>
   597da:      	cmpq	$0x0, 0x1c266(%rip)     # 0x75a48 <g.3>
   597e2:      	je	0x7085f <f.2+0x180af>
   597e8:      	movq	%rax, %rbp
   597eb:      	leaq	-0xd(%r12), %rsi
   597f0:      	movq	$0x0, 0x48(%rsp)
   597f9:      	movq	$0x3, 0x30(%rsp)
   59802:      	xorl	%edi, %edi
   59804:      	callq	0x70870 <f.3>
   59809:      	subq	$0x8, %rsp
   5980d:      	cmpb	$0x0, 0x1c23c(%rip)     # 0x75a50 <g.4>
   59814:      	je	0x7085f <f.2+0x180af>
   5981a:      	cmpq	$0x0, 0x1c226(%rip)     # 0x75a48 <g.3>
   59822:      	je	0x7085f <f.2+0x180af>
   59828:      	movq	%rax, %r13
   5982b:      	addq	%rbp, %r13
   5982e:      	cmpq	$0xd, %r12
   59832:      	je	0x598ca <f.2+0x111a>
   59838:      	movq	$0x0, 0x48(%rsp)
   59841:      	movq	$0x3, 0x30(%rsp)
   5984a:      	xorl	%edi, %edi
   5984c:      	leaq	-0xd(%r12), %rsi
   59851:      	callq	0x70870 <f.3>
   59856:      	subq	$0x8, %rsp
   5985a:      	cmpb	$0x0, 0x1c1ef(%rip)     # 0x75a50 <g.4>
   59861:      	je	0x7085f <f.2+0x180af>
   59867:      	movq	%rax, 0x10(%rsp)
   5986c:      	cmpq	$0x0, 0x1c1d4(%rip)     # 0x75a48 <g.3>
   59874:      	je	0x7085f <f.2+0x180af>
   5987a:      	leaq	-0xe(%r12), %rsi
   5987f:      	movq	$0x0, 0x48(%rsp)
   59888:      	movq	$0x3, 0x30(%rsp)
   59891:      	xorl	%edi, %edi
   59893:      	callq	0x70870 <f.3>
   59898:      	subq	$0x8, %rsp
   5989c:      	cmpb	$0x0, 0x1c1ad(%rip)     # 0x75a50 <g.4>
   598a3:      	je	0x7085f <f.2+0x180af>
   598a9:      	movq	%rax, %rbp
   598ac:      	addq	0x10(%rsp), %rbp
   598b1:      	addq	%r13, %rbp
   598b4:      	jmp	0x598cf <f.2+0x111f>
   598b6:      	movl	$0x1, %r13d
   598bc:      	cmpq	$0x0, 0x1c184(%rip)     # 0x75a48 <g.3>
   598c4:      	je	0x7085f <f.2+0x180af>
   598ca:      	leaq	-0xc(%r12,%r13), %rbp
   598cf:      	cmpq	$0x0, 0x1c171(%rip)     # 0x75a48 <g.3>
   598d7:      	je	0x7085f <f.2+0x180af>
   598dd:      	cmpq	$0xc, %r12
   598e1:      	ja	0x598ed <f.2+0x113d>
   598e3:      	leaq	-0xb(%r12), %r13
   598e8:      	jmp	0x59a0c <f.2+0x125c>
   598ed:      	cmpq	$0xd, %r12
   598f1:      	jne	0x5990c <f.2+0x115c>
   598f3:      	movl	$0x1, %r13d
   598f9:      	cmpq	$0x0, 0x1c147(%rip)     # 0x75a48 <g.3>
   59901:      	jne	0x59999 <f.2+0x11e9>
   59907:      	jmp	0x7085f <f.2+0x180af>
   5990c:      	leaq	-0xd(%r12), %rsi
   59911:      	movq	$0x0, 0x48(%rsp)
   5991a:      	movq	$0x3, 0x30(%rsp)
   59923:      	xorl	%edi, %edi
   59925:      	callq	0x70870 <f.3>
   5992a:      	subq	$0x8, %rsp
   5992e:      	cmpb	$0x0, 0x1c11b(%rip)     # 0x75a50 <g.4>
   59935:      	je	0x7085f <f.2+0x180af>
   5993b:      	movq	%rax, 0x10(%rsp)
   59940:      	cmpq	$0x0, 0x1c100(%rip)     # 0x75a48 <g.3>
   59948:      	je	0x7085f <f.2+0x180af>
   5994e:      	leaq	-0xe(%r12), %rsi
   59953:      	movq	$0x0, 0x48(%rsp)
   5995c:      	movq	$0x3, 0x30(%rsp)
   59965:      	xorl	%edi, %edi
   59967:      	callq	0x70870 <f.3>
   5996c:      	subq	$0x8, %rsp
   59970:      	cmpb	$0x0, 0x1c0d9(%rip)     # 0x75a50 <g.4>
   59977:      	je	0x7085f <f.2+0x180af>
   5997d:      	cmpq	$0x0, 0x1c0c3(%rip)     # 0x75a48 <g.3>
   59985:      	je	0x7085f <f.2+0x180af>
   5998b:      	movq	%rax, %r13
   5998e:      	addq	0x10(%rsp), %r13
   59993:      	cmpq	$0xe, %r12
   59997:      	ja	0x599a0 <f.2+0x11f0>
   59999:      	leaq	-0xd(%r12), %rax
   5999e:      	jmp	0x59a09 <f.2+0x1259>
   599a0:      	movq	$0x0, 0x48(%rsp)
   599a9:      	movq	$0x3, 0x30(%rsp)
   599b2:      	xorl	%edi, %edi
   599b4:      	leaq	-0xe(%r12), %rsi
   599b9:      	callq	0x70870 <f.3>
   599be:      	subq	$0x8, %rsp
   599c2:      	cmpb	$0x0, 0x1c087(%rip)     # 0x75a50 <g.4>
   599c9:      	je	0x7085f <f.2+0x180af>
   599cf:      	movq	%rax, 0x10(%rsp)
   599d4:      	cmpq	$0x0, 0x1c06c(%rip)     # 0x75a48 <g.3>
   599dc:      	je	0x7085f <f.2+0x180af>
   599e2:      	leaq	-0xf(%r12), %rsi
   599e7:      	movq	$0x0, 0x48(%rsp)
   599f0:      	movq	$0x3, 0x30(%rsp)
   599f9:      	xorl	%edi, %edi
   599fb:      	callq	0x70870 <f.3>
   59a00:      	subq	$0x8, %rsp
   59a04:      	addq	0x10(%rsp), %rax
   59a09:      	addq	%rax, %r13
   59a0c:      	cmpb	$0x0, 0x1c03d(%rip)     # 0x75a50 <g.4>
   59a13:      	je	0x7085f <f.2+0x180af>
   59a19:      	addq	%rbp, %r13
   59a1c:      	addq	%r14, %r13
   59a1f:      	cmpq	$0x0, 0x1c021(%rip)     # 0x75a48 <g.3>
   59a27:      	je	0x7085f <f.2+0x180af>
   59a2d:      	cmpq	$0x9, %r12
   59a31:      	ja	0x59a4a <f.2+0x129a>
   59a33:      	leaq	-0x8(%r12), %r14
   59a38:      	cmpb	$0x0, 0x1c011(%rip)     # 0x75a50 <g.4>
   59a3f:      	jne	0x59fc6 <f.2+0x1816>
   59a45:      	jmp	0x7085f <f.2+0x180af>
   59a4a:      	cmpq	$0xa, %r12
   59a4e:      	jne	0x59a69 <f.2+0x12b9>
   59a50:      	movl	$0x1, %r14d
   59a56:      	cmpq	$0x0, 0x1bfea(%rip)     # 0x75a48 <g.3>
   59a5e:      	jne	0x59d14 <f.2+0x1564>
   59a64:      	jmp	0x7085f <f.2+0x180af>
   59a69:      	cmpq	$0xc, %r12
   59a6d:      	jb	0x59a8a <f.2+0x12da>
   59a6f:      	jne	0x59aa2 <f.2+0x12f2>
   59a71:      	movl	$0x1, %r14d
   59a77:      	cmpq	$0x0, 0x1bfc9(%rip)     # 0x75a48 <g.3>
   59a7f:      	jne	0x59b2b <f.2+0x137b>
   59a85:      	jmp	0x7085f <f.2+0x180af>
   59a8a:      	movl	$0x1, %ebp
   59a8f:      	cmpq	$0x0, 0x1bfb1(%rip)     # 0x75a48 <g.3>
   59a97:      	jne	0x59bc8 <f.2+0x1418>
   59a9d:      	jmp	0x7085f <f.2+0x180af>
   59aa2:      	leaq	-0xc(%r12), %rsi
   59aa7:      	movq	$0x0, 0x48(%rsp)
   59ab0:      	movq	$0x3, 0x30(%rsp)
   59ab9:      	xorl	%edi, %edi
   59abb:      	callq	0x70870 <f.3>
   59ac0:      	subq	$0x8, %rsp
   59ac4:      	cmpb	$0x0, 0x1bf85(%rip)     # 0x75a50 <g.4>
   59acb:      	je	0x7085f <f.2+0x180af>
   59ad1:      	cmpq	$0x0, 0x1bf6f(%rip)     # 0x75a48 <g.3>
   59ad9:      	je	0x7085f <f.2+0x180af>
   59adf:      	movq	%rax, %rbp
   59ae2:      	leaq	-0xd(%r12), %rsi
   59ae7:      	movq	$0x0, 0x48(%rsp)
   59af0:      	movq	$0x3, 0x30(%rsp)
   59af9:      	xorl	%edi, %edi
   59afb:      	callq	0x70870 <f.3>
   59b00:      	subq	$0x8, %rsp
   59b04:      	cmpb	$0x0, 0x1bf45(%rip)     # 0x75a50 <g.4>
   59b0b:      	je	0x7085f <f.2+0x180af>
   59b11:      	cmpq	$0x0, 0x1bf2f(%rip)     # 0x75a48 <g.3>
   59b19:      	je	0x7085f <f.2+0x180af>
   59b1f:      	movq	%rax, %r14
   59b22:      	addq	%rbp, %r14
   59b25:      	cmpq	$0xd, %r12
   59b29:      	ja	0x59b32 <f.2+0x1382>
   59b2b:      	leaq	-0xc(%r12,%r14), %rbp
   59b30:      	jmp	0x59bae <f.2+0x13fe>
   59b32:      	movq	$0x0, 0x48(%rsp)
   59b3b:      	movq	$0x3, 0x30(%rsp)
   59b44:      	xorl	%edi, %edi
   59b46:      	leaq	-0xd(%r12), %rsi
   59b4b:      	callq	0x70870 <f.3>
   59b50:      	subq	$0x8, %rsp
   59b54:      	cmpb	$0x0, 0x1bef5(%rip)     # 0x75a50 <g.4>
   59b5b:      	je	0x7085f <f.2+0x180af>
   59b61:      	movq	%rax, 0x10(%rsp)
   59b66:      	cmpq	$0x0, 0x1beda(%rip)     # 0x75a48 <g.3>
   59b6e:      	je	0x7085f <f.2+0x180af>
   59b74:      	leaq	-0xe(%r12), %rsi
   59b79:      	movq	$0x0, 0x48(%rsp)
   59b82:      	movq	$0x3, 0x30(%rsp)
   59b8b:      	xorl	%edi, %edi
   59b8d:      	callq	0x70870 <f.3>
   59b92:      	subq	$0x8, %rsp
   59b96:      	cmpb	$0x0, 0x1beb3(%rip)     # 0x75a50 <g.4>
   59b9d:      	je	0x7085f <f.2+0x180af>
   59ba3:      	movq	%rax, %rbp
   59ba6:      	addq	0x10(%rsp), %rbp
   59bab:      	addq	%r14, %rbp
   59bae:      	cmpq	$0x0, 0x1be92(%rip)     # 0x75a48 <g.3>
   59bb6:      	je	0x7085f <f.2+0x180af>
   59bbc:      	cmpq	$0xd, %r12
   59bc0:      	je	0x59bd2 <f.2+0x1422>
   59bc2:      	cmpq	$0xc, %r12
   59bc6:      	jne	0x59bea <f.2+0x143a>
   59bc8:      	leaq	-0xb(%r12,%rbp), %r14
   59bcd:      	jmp	0x59d00 <f.2+0x1550>
   59bd2:      	movl	$0x1, %eax
   59bd7:      	cmpq	$0x0, 0x1be69(%rip)     # 0x75a48 <g.3>
   59bdf:      	jne	0x59c70 <f.2+0x14c0>
   59be5:      	jmp	0x7085f <f.2+0x180af>
   59bea:      	leaq	-0xd(%r12), %rsi
   59bef:      	movq	$0x0, 0x48(%rsp)
   59bf8:      	movq	$0x3, 0x30(%rsp)
   59c01:      	xorl	%edi, %edi
   59c03:      	callq	0x70870 <f.3>
   59c08:      	subq	$0x8, %rsp
   59c0c:      	cmpb	$0x0, 0x1be3d(%rip)     # 0x75a50 <g.4>
   59c13:      	je	0x7085f <f.2+0x180af>
   59c19:      	cmpq	$0x0, 0x1be27(%rip)     # 0x75a48 <g.3>
   59c21:      	je	0x7085f <f.2+0x180af>
   59c27:      	movq	%rax, %r14
   59c2a:      	leaq	-0xe(%r12), %rsi
   59c2f:      	movq	$0x0, 0x48(%rsp)
   59c38:      	movq	$0x3, 0x30(%rsp)
   59c41:      	xorl	%edi, %edi
   59c43:      	callq	0x70870 <f.3>
   59c48:      	subq	$0x8, %rsp
   59c4c:      	cmpb	$0x0, 0x1bdfd(%rip)     # 0x75a50 <g.4>
   59c53:      	je	0x7085f <f.2+0x180af>
   59c59:      	cmpq	$0x0, 0x1bde7(%rip)     # 0x75a48 <g.3>
   59c61:      	je	0x7085f <f.2+0x180af>
   59c67:      	addq	%r14, %rax
   59c6a:      	cmpq	$0xe, %r12
   59c6e:      	ja	0x59c77 <f.2+0x14c7>
   59c70:      	leaq	-0xd(%r12), %r14
   59c75:      	jmp	0x59ced <f.2+0x153d>
   59c77:      	movq	%rax, 0x10(%rsp)
   59c7c:      	movq	$0x0, 0x48(%rsp)
   59c85:      	movq	$0x3, 0x30(%rsp)
   59c8e:      	xorl	%edi, %edi
   59c90:      	leaq	-0xe(%r12), %rsi
   59c95:      	callq	0x70870 <f.3>
   59c9a:      	subq	$0x8, %rsp
   59c9e:      	cmpb	$0x0, 0x1bdab(%rip)     # 0x75a50 <g.4>
   59ca5:      	je	0x7085f <f.2+0x180af>
   59cab:      	movq	%rax, 0x18(%rsp)
   59cb0:      	cmpq	$0x0, 0x1bd90(%rip)     # 0x75a48 <g.3>
   59cb8:      	je	0x7085f <f.2+0x180af>
   59cbe:      	leaq	-0xf(%r12), %rsi
   59cc3:      	movq	$0x0, 0x48(%rsp)
   59ccc:      	movq	$0x3, 0x30(%rsp)
   59cd5:      	xorl	%edi, %edi
   59cd7:      	callq	0x70870 <f.3>
   59cdc:      	subq	$0x8, %rsp
   59ce0:      	movq	%rax, %r14
   59ce3:      	addq	0x18(%rsp), %r14
   59ce8:      	movq	0x10(%rsp), %rax
   59ced:      	cmpb	$0x0, 0x1bd5c(%rip)     # 0x75a50 <g.4>
   59cf4:      	je	0x7085f <f.2+0x180af>
   59cfa:      	addq	%rax, %r14
   59cfd:      	addq	%rbp, %r14
   59d00:      	cmpq	$0x0, 0x1bd40(%rip)     # 0x75a48 <g.3>
   59d08:      	je	0x7085f <f.2+0x180af>
   59d0e:      	cmpq	$0xb, %r12
   59d12:      	ja	0x59d1e <f.2+0x156e>
   59d14:      	leaq	-0xa(%r12), %rbp
   59d19:      	jmp	0x59fb6 <f.2+0x1806>
   59d1e:      	cmpq	$0xc, %r12
   59d22:      	jne	0x59d3c <f.2+0x158c>
   59d24:      	movl	$0x1, %ebp
   59d29:      	cmpq	$0x0, 0x1bd17(%rip)     # 0x75a48 <g.3>
   59d31:      	jne	0x59e81 <f.2+0x16d1>
   59d37:      	jmp	0x7085f <f.2+0x180af>
   59d3c:      	cmpq	$0xe, %r12
   59d40:      	jb	0x59e55 <f.2+0x16a5>
   59d46:      	leaq	-0xd(%r12), %rsi
   59d4b:      	movq	$0x0, 0x48(%rsp)
   59d54:      	movq	$0x3, 0x30(%rsp)
   59d5d:      	xorl	%edi, %edi
   59d5f:      	callq	0x70870 <f.3>
   59d64:      	subq	$0x8, %rsp
   59d68:      	cmpb	$0x0, 0x1bce1(%rip)     # 0x75a50 <g.4>
   59d6f:      	je	0x7085f <f.2+0x180af>
   59d75:      	cmpq	$0x0, 0x1bccb(%rip)     # 0x75a48 <g.3>
   59d7d:      	je	0x7085f <f.2+0x180af>
   59d83:      	movq	%rax, %rbp
   59d86:      	leaq	-0xe(%r12), %rsi
   59d8b:      	movq	$0x0, 0x48(%rsp)
   59d94:      	movq	$0x3, 0x30(%rsp)
   59d9d:      	xorl	%edi, %edi
   59d9f:      	callq	0x70870 <f.3>
   59da4:      	subq	$0x8, %rsp
   59da8:      	cmpb	$0x0, 0x1bca1(%rip)     # 0x75a50 <g.4>
   59daf:      	je	0x7085f <f.2+0x180af>
   59db5:      	cmpq	$0x0, 0x1bc8b(%rip)     # 0x75a48 <g.3>
   59dbd:      	je	0x7085f <f.2+0x180af>
   59dc3:      	addq	%rbp, %rax
   59dc6:      	cmpq	$0xe, %r12
   59dca:      	je	0x59e68 <f.2+0x16b8>
   59dd0:      	movq	%rax, 0x10(%rsp)
   59dd5:      	movq	$0x0, 0x48(%rsp)
   59dde:      	movq	$0x3, 0x30(%rsp)
   59de7:      	xorl	%edi, %edi
   59de9:      	leaq	-0xe(%r12), %rsi
   59dee:      	callq	0x70870 <f.3>
   59df3:      	subq	$0x8, %rsp
   59df7:      	cmpb	$0x0, 0x1bc52(%rip)     # 0x75a50 <g.4>
   59dfe:      	je	0x7085f <f.2+0x180af>
   59e04:      	movq	%rax, 0x18(%rsp)
   59e09:      	cmpq	$0x0, 0x1bc37(%rip)     # 0x75a48 <g.3>
   59e11:      	je	0x7085f <f.2+0x180af>
   59e17:      	leaq	-0xf(%r12), %rsi
   59e1c:      	movq	$0x0, 0x48(%rsp)
   59e25:      	movq	$0x3, 0x30(%rsp)
   59e2e:      	xorl	%edi, %edi
   59e30:      	callq	0x70870 <f.3>
   59e35:      	subq	$0x8, %rsp
   59e39:      	cmpb	$0x0, 0x1bc10(%rip)     # 0x75a50 <g.4>
   59e40:      	je	0x7085f <f.2+0x180af>
   59e46:      	movq	%rax, %rbp
   59e49:      	addq	0x18(%rsp), %rbp
   59e4e:      	addq	0x10(%rsp), %rbp
   59e53:      	jmp	0x59e6d <f.2+0x16bd>
   59e55:      	movl	$0x1, %eax
   59e5a:      	cmpq	$0x0, 0x1bbe6(%rip)     # 0x75a48 <g.3>
   59e62:      	je	0x7085f <f.2+0x180af>
   59e68:      	leaq	-0xd(%r12,%rax), %rbp
   59e6d:      	cmpq	$0x0, 0x1bbd3(%rip)     # 0x75a48 <g.3>
   59e75:      	je	0x7085f <f.2+0x180af>
   59e7b:      	cmpq	$0xd, %r12
   59e7f:      	ja	0x59e8b <f.2+0x16db>
   59e81:      	leaq	-0xc(%r12), %rcx
   59e86:      	jmp	0x59fb3 <f.2+0x1803>
   59e8b:      	cmpq	$0xe, %r12
   59e8f:      	jne	0x59ea9 <f.2+0x16f9>
   59e91:      	movl	$0x1, %ecx
   59e96:      	cmpq	$0x0, 0x1bbaa(%rip)     # 0x75a48 <g.3>
   59e9e:      	jne	0x59f36 <f.2+0x1786>
   59ea4:      	jmp	0x7085f <f.2+0x180af>
   59ea9:      	leaq	-0xe(%r12), %rsi
   59eae:      	movq	$0x0, 0x48(%rsp)
   59eb7:      	movq	$0x3, 0x30(%rsp)
   59ec0:      	xorl	%edi, %edi
   59ec2:      	callq	0x70870 <f.3>
   59ec7:      	subq	$0x8, %rsp
   59ecb:      	cmpb	$0x0, 0x1bb7e(%rip)     # 0x75a50 <g.4>
   59ed2:      	je	0x7085f <f.2+0x180af>
   59ed8:      	movq	%rax, 0x10(%rsp)
   59edd:      	cmpq	$0x0, 0x1bb63(%rip)     # 0x75a48 <g.3>
   59ee5:      	je	0x7085f <f.2+0x180af>
   59eeb:      	leaq	-0xf(%r12), %rsi
   59ef0:      	movq	$0x0, 0x48(%rsp)
   59ef9:      	movq	$0x3, 0x30(%rsp)
   59f02:      	xorl	%edi, %edi
   59f04:      	callq	0x70870 <f.3>
   59f09:      	subq	$0x8, %rsp
   59f0d:      	cmpb	$0x0, 0x1bb3c(%rip)     # 0x75a50 <g.4>
   59f14:      	je	0x7085f <f.2+0x180af>
   59f1a:      	cmpq	$0x0, 0x1bb26(%rip)     # 0x75a48 <g.3>
   59f22:      	je	0x7085f <f.2+0x180af>
   59f28:      	movq	%rax, %rcx
   59f2b:      	addq	0x10(%rsp), %rcx
   59f30:      	cmpq	$0xf, %r12
   59f34:      	ja	0x59f3d <f.2+0x178d>
   59f36:      	leaq	-0xe(%r12), %rax
   59f3b:      	jmp	0x59fb0 <f.2+0x1800>
   59f3d:      	movq	%rcx, 0x10(%rsp)
   59f42:      	movq	$0x0, 0x48(%rsp)
   59f4b:      	movq	$0x3, 0x30(%rsp)
   59f54:      	xorl	%edi, %edi
   59f56:      	leaq	-0xf(%r12), %rsi
   59f5b:      	callq	0x70870 <f.3>
   59f60:      	subq	$0x8, %rsp
   59f64:      	cmpb	$0x0, 0x1bae5(%rip)     # 0x75a50 <g.4>
   59f6b:      	je	0x7085f <f.2+0x180af>
   59f71:      	movq	%rax, 0x18(%rsp)
   59f76:      	cmpq	$0x0, 0x1baca(%rip)     # 0x75a48 <g.3>
   59f7e:      	je	0x7085f <f.2+0x180af>
   59f84:      	leaq	-0x10(%r12), %rsi
   59f89:      	movq	$0x0, 0x48(%rsp)
   59f92:      	movq	$0x3, 0x30(%rsp)
   59f9b:      	xorl	%edi, %edi
   59f9d:      	callq	0x70870 <f.3>
   59fa2:      	subq	$0x8, %rsp
   59fa6:      	addq	0x18(%rsp), %rax
   59fab:      	movq	0x10(%rsp), %rcx
   59fb0:      	addq	%rax, %rcx
   59fb3:      	addq	%rcx, %rbp
   59fb6:      	addq	%rbp, %r14
   59fb9:      	cmpb	$0x0, 0x1ba90(%rip)     # 0x75a50 <g.4>
   59fc0:      	je	0x7085f <f.2+0x180af>
   59fc6:      	addq	%r13, %r14
   59fc9:      	addq	%r15, %r14
   59fcc:      	cmpq	$0x0, 0x1ba74(%rip)     # 0x75a48 <g.3>
   59fd4:      	leaq	0x68(%rsp), %r15
   59fd9:      	je	0x7085f <f.2+0x180af>
   59fdf:      	cmpq	$0x7, %r12
   59fe3:      	je	0x5a003 <f.2+0x1853>
   59fe5:      	cmpq	$0x6, %r12
   59fe9:      	jne	0x5a01c <f.2+0x186c>
   59feb:      	leaq	-0x5(%r12,%r14), %r13
   59ff0:      	cmpq	$0x0, 0x1ba50(%rip)     # 0x75a48 <g.3>
   59ff8:      	jne	0x5aba7 <f.2+0x23f7>
   59ffe:      	jmp	0x7085f <f.2+0x180af>
   5a003:      	movl	$0x1, %r15d
   5a009:      	cmpq	$0x0, 0x1ba37(%rip)     # 0x75a48 <g.3>
   5a011:      	jne	0x5ab7c <f.2+0x23cc>
   5a017:      	jmp	0x7085f <f.2+0x180af>
   5a01c:      	cmpq	$0x9, %r12
   5a020:      	jb	0x5a03d <f.2+0x188d>
   5a022:      	jne	0x5a056 <f.2+0x18a6>
   5a024:      	movl	$0x1, %r15d
   5a02a:      	cmpq	$0x0, 0x1ba16(%rip)     # 0x75a48 <g.3>
   5a032:      	jne	0x5a2f8 <f.2+0x1b48>
   5a038:      	jmp	0x7085f <f.2+0x180af>
   5a03d:      	movl	$0x1, %r13d
   5a043:      	cmpq	$0x0, 0x1b9fd(%rip)     # 0x75a48 <g.3>
   5a04b:      	jne	0x5a5c6 <f.2+0x1e16>
   5a051:      	jmp	0x7085f <f.2+0x180af>
   5a056:      	cmpq	$0xb, %r12
   5a05a:      	jb	0x5a077 <f.2+0x18c7>
   5a05c:      	jne	0x5a090 <f.2+0x18e0>
   5a05e:      	movl	$0x1, %r15d
   5a064:      	cmpq	$0x0, 0x1b9dc(%rip)     # 0x75a48 <g.3>
   5a06c:      	jne	0x5a11c <f.2+0x196c>
   5a072:      	jmp	0x7085f <f.2+0x180af>
   5a077:      	movl	$0x1, %r13d
   5a07d:      	cmpq	$0x0, 0x1b9c3(%rip)     # 0x75a48 <g.3>
   5a085:      	jne	0x5a1b3 <f.2+0x1a03>
   5a08b:      	jmp	0x7085f <f.2+0x180af>
   5a090:      	leaq	-0xb(%r12), %rsi
   5a095:      	movq	$0x0, 0x48(%rsp)
   5a09e:      	movq	$0x3, 0x30(%rsp)
   5a0a7:      	xorl	%edi, %edi
   5a0a9:      	callq	0x70870 <f.3>
   5a0ae:      	subq	$0x8, %rsp
   5a0b2:      	cmpb	$0x0, 0x1b997(%rip)     # 0x75a50 <g.4>
   5a0b9:      	je	0x7085f <f.2+0x180af>
   5a0bf:      	cmpq	$0x0, 0x1b981(%rip)     # 0x75a48 <g.3>
   5a0c7:      	je	0x7085f <f.2+0x180af>
   5a0cd:      	movq	%rax, %r13
   5a0d0:      	leaq	-0xc(%r12), %rbp
   5a0d5:      	movq	$0x0, 0x48(%rsp)
   5a0de:      	movq	$0x3, 0x30(%rsp)
   5a0e7:      	xorl	%edi, %edi
   5a0e9:      	movq	%rbp, %rsi
   5a0ec:      	callq	0x70870 <f.3>
   5a0f1:      	subq	$0x8, %rsp
   5a0f5:      	cmpb	$0x0, 0x1b954(%rip)     # 0x75a50 <g.4>
   5a0fc:      	je	0x7085f <f.2+0x180af>
   5a102:      	cmpq	$0x0, 0x1b93e(%rip)     # 0x75a48 <g.3>
   5a10a:      	je	0x7085f <f.2+0x180af>
   5a110:      	movq	%rax, %r15
   5a113:      	addq	%r13, %r15
   5a116:      	cmpq	$0xc, %r12
   5a11a:      	ja	0x5a123 <f.2+0x1973>
   5a11c:      	leaq	-0xb(%r12,%r15), %r13
   5a121:      	jmp	0x5a199 <f.2+0x19e9>
   5a123:      	movq	$0x0, 0x48(%rsp)
   5a12c:      	movq	$0x3, 0x30(%rsp)
   5a135:      	xorl	%edi, %edi
   5a137:      	movq	%rbp, %rsi
   5a13a:      	callq	0x70870 <f.3>
   5a13f:      	subq	$0x8, %rsp
   5a143:      	cmpb	$0x0, 0x1b906(%rip)     # 0x75a50 <g.4>
   5a14a:      	je	0x7085f <f.2+0x180af>
   5a150:      	cmpq	$0x0, 0x1b8f0(%rip)     # 0x75a48 <g.3>
   5a158:      	je	0x7085f <f.2+0x180af>
   5a15e:      	movq	%rax, %rbp
   5a161:      	leaq	-0xd(%r12), %rsi
   5a166:      	movq	$0x0, 0x48(%rsp)
   5a16f:      	movq	$0x3, 0x30(%rsp)
   5a178:      	xorl	%edi, %edi
   5a17a:      	callq	0x70870 <f.3>
   5a17f:      	subq	$0x8, %rsp
   5a183:      	cmpb	$0x0, 0x1b8c6(%rip)     # 0x75a50 <g.4>
   5a18a:      	je	0x7085f <f.2+0x180af>
   5a190:      	movq	%rax, %r13
   5a193:      	addq	%rbp, %r13
   5a196:      	addq	%r15, %r13
   5a199:      	cmpq	$0x0, 0x1b8a7(%rip)     # 0x75a48 <g.3>
   5a1a1:      	je	0x7085f <f.2+0x180af>
   5a1a7:      	cmpq	$0xc, %r12
   5a1ab:      	je	0x5a1bd <f.2+0x1a0d>
   5a1ad:      	cmpq	$0xb, %r12
   5a1b1:      	jne	0x5a1d5 <f.2+0x1a25>
   5a1b3:      	leaq	-0xa(%r12,%r13), %r15
   5a1b8:      	jmp	0x5a2e4 <f.2+0x1b34>
   5a1bd:      	movl	$0x1, %ebp
   5a1c2:      	cmpq	$0x0, 0x1b87e(%rip)     # 0x75a48 <g.3>
   5a1ca:      	jne	0x5a25e <f.2+0x1aae>
   5a1d0:      	jmp	0x7085f <f.2+0x180af>
   5a1d5:      	leaq	-0xc(%r12), %rsi
   5a1da:      	movq	$0x0, 0x48(%rsp)
   5a1e3:      	movq	$0x3, 0x30(%rsp)
   5a1ec:      	xorl	%edi, %edi
   5a1ee:      	callq	0x70870 <f.3>
   5a1f3:      	subq	$0x8, %rsp
   5a1f7:      	cmpb	$0x0, 0x1b852(%rip)     # 0x75a50 <g.4>
   5a1fe:      	je	0x7085f <f.2+0x180af>
   5a204:      	cmpq	$0x0, 0x1b83c(%rip)     # 0x75a48 <g.3>
   5a20c:      	je	0x7085f <f.2+0x180af>
   5a212:      	movq	%rax, %r15
   5a215:      	leaq	-0xd(%r12), %rsi
   5a21a:      	movq	$0x0, 0x48(%rsp)
   5a223:      	movq	$0x3, 0x30(%rsp)
   5a22c:      	xorl	%edi, %edi
   5a22e:      	callq	0x70870 <f.3>
   5a233:      	subq	$0x8, %rsp
   5a237:      	cmpb	$0x0, 0x1b812(%rip)     # 0x75a50 <g.4>
   5a23e:      	je	0x7085f <f.2+0x180af>
   5a244:      	cmpq	$0x0, 0x1b7fc(%rip)     # 0x75a48 <g.3>
   5a24c:      	je	0x7085f <f.2+0x180af>
   5a252:      	movq	%rax, %rbp
   5a255:      	addq	%r15, %rbp
   5a258:      	cmpq	$0xd, %r12
   5a25c:      	ja	0x5a265 <f.2+0x1ab5>
   5a25e:      	leaq	-0xc(%r12), %r15
   5a263:      	jmp	0x5a2d1 <f.2+0x1b21>
   5a265:      	movq	$0x0, 0x48(%rsp)
   5a26e:      	movq	$0x3, 0x30(%rsp)
   5a277:      	xorl	%edi, %edi
   5a279:      	leaq	-0xd(%r12), %rsi
   5a27e:      	callq	0x70870 <f.3>
   5a283:      	subq	$0x8, %rsp
   5a287:      	cmpb	$0x0, 0x1b7c2(%rip)     # 0x75a50 <g.4>
   5a28e:      	je	0x7085f <f.2+0x180af>
   5a294:      	movq	%rax, 0x10(%rsp)
   5a299:      	cmpq	$0x0, 0x1b7a7(%rip)     # 0x75a48 <g.3>
   5a2a1:      	je	0x7085f <f.2+0x180af>
   5a2a7:      	leaq	-0xe(%r12), %rsi
   5a2ac:      	movq	$0x0, 0x48(%rsp)
   5a2b5:      	movq	$0x3, 0x30(%rsp)
   5a2be:      	xorl	%edi, %edi
   5a2c0:      	callq	0x70870 <f.3>
   5a2c5:      	subq	$0x8, %rsp
   5a2c9:      	movq	%rax, %r15
   5a2cc:      	addq	0x10(%rsp), %r15
   5a2d1:      	cmpb	$0x0, 0x1b778(%rip)     # 0x75a50 <g.4>
   5a2d8:      	je	0x7085f <f.2+0x180af>
   5a2de:      	addq	%rbp, %r15
   5a2e1:      	addq	%r13, %r15
   5a2e4:      	cmpq	$0x0, 0x1b75c(%rip)     # 0x75a48 <g.3>
   5a2ec:      	je	0x7085f <f.2+0x180af>
   5a2f2:      	cmpq	$0xa, %r12
   5a2f6:      	ja	0x5a310 <f.2+0x1b60>
   5a2f8:      	leaq	-0x9(%r12,%r15), %r13
   5a2fd:      	cmpq	$0x0, 0x1b743(%rip)     # 0x75a48 <g.3>
   5a305:      	jne	0x5a5ba <f.2+0x1e0a>
   5a30b:      	jmp	0x7085f <f.2+0x180af>
   5a310:      	cmpq	$0xb, %r12
   5a314:      	jne	0x5a32e <f.2+0x1b7e>
   5a316:      	movl	$0x1, %ebp
   5a31b:      	cmpq	$0x0, 0x1b725(%rip)     # 0x75a48 <g.3>
   5a323:      	jne	0x5a470 <f.2+0x1cc0>
   5a329:      	jmp	0x7085f <f.2+0x180af>
   5a32e:      	cmpq	$0xd, %r12
   5a332:      	jb	0x5a443 <f.2+0x1c93>
   5a338:      	leaq	-0xc(%r12), %rsi
   5a33d:      	movq	$0x0, 0x48(%rsp)
   5a346:      	movq	$0x3, 0x30(%rsp)
   5a34f:      	xorl	%edi, %edi
   5a351:      	callq	0x70870 <f.3>
   5a356:      	subq	$0x8, %rsp
   5a35a:      	cmpb	$0x0, 0x1b6ef(%rip)     # 0x75a50 <g.4>
   5a361:      	je	0x7085f <f.2+0x180af>
   5a367:      	cmpq	$0x0, 0x1b6d9(%rip)     # 0x75a48 <g.3>
   5a36f:      	je	0x7085f <f.2+0x180af>
   5a375:      	movq	%rax, %rbp
   5a378:      	leaq	-0xd(%r12), %rsi
   5a37d:      	movq	$0x0, 0x48(%rsp)
   5a386:      	movq	$0x3, 0x30(%rsp)
   5a38f:      	xorl	%edi, %edi
   5a391:      	callq	0x70870 <f.3>
   5a396:      	subq	$0x8, %rsp
   5a39a:      	cmpb	$0x0, 0x1b6af(%rip)     # 0x75a50 <g.4>
   5a3a1:      	je	0x7085f <f.2+0x180af>
   5a3a7:      	cmpq	$0x0, 0x1b699(%rip)     # 0x75a48 <g.3>
   5a3af:      	je	0x7085f <f.2+0x180af>
   5a3b5:      	movq	%rax, %r13
   5a3b8:      	addq	%rbp, %r13
   5a3bb:      	cmpq	$0xd, %r12
   5a3bf:      	je	0x5a457 <f.2+0x1ca7>
   5a3c5:      	movq	$0x0, 0x48(%rsp)
   5a3ce:      	movq	$0x3, 0x30(%rsp)
   5a3d7:      	xorl	%edi, %edi
   5a3d9:      	leaq	-0xd(%r12), %rsi
   5a3de:      	callq	0x70870 <f.3>
   5a3e3:      	subq	$0x8, %rsp
   5a3e7:      	cmpb	$0x0, 0x1b662(%rip)     # 0x75a50 <g.4>
   5a3ee:      	je	0x7085f <f.2+0x180af>
   5a3f4:      	movq	%rax, 0x10(%rsp)
   5a3f9:      	cmpq	$0x0, 0x1b647(%rip)     # 0x75a48 <g.3>
   5a401:      	je	0x7085f <f.2+0x180af>
   5a407:      	leaq	-0xe(%r12), %rsi
   5a40c:      	movq	$0x0, 0x48(%rsp)
   5a415:      	movq	$0x3, 0x30(%rsp)
   5a41e:      	xorl	%edi, %edi
   5a420:      	callq	0x70870 <f.3>
   5a425:      	subq	$0x8, %rsp
   5a429:      	cmpb	$0x0, 0x1b620(%rip)     # 0x75a50 <g.4>
   5a430:      	je	0x7085f <f.2+0x180af>
   5a436:      	movq	%rax, %rbp
   5a439:      	addq	0x10(%rsp), %rbp
   5a43e:      	addq	%r13, %rbp
   5a441:      	jmp	0x5a45c <f.2+0x1cac>
   5a443:      	movl	$0x1, %r13d
   5a449:      	cmpq	$0x0, 0x1b5f7(%rip)     # 0x75a48 <g.3>
   5a451:      	je	0x7085f <f.2+0x180af>
   5a457:      	leaq	-0xc(%r12,%r13), %rbp
   5a45c:      	cmpq	$0x0, 0x1b5e4(%rip)     # 0x75a48 <g.3>
   5a464:      	je	0x7085f <f.2+0x180af>
   5a46a:      	cmpq	$0xc, %r12
   5a46e:      	ja	0x5a47a <f.2+0x1cca>
   5a470:      	leaq	-0xb(%r12), %r13
   5a475:      	jmp	0x5a599 <f.2+0x1de9>
   5a47a:      	cmpq	$0xd, %r12
   5a47e:      	jne	0x5a499 <f.2+0x1ce9>
   5a480:      	movl	$0x1, %r13d
   5a486:      	cmpq	$0x0, 0x1b5ba(%rip)     # 0x75a48 <g.3>
   5a48e:      	jne	0x5a526 <f.2+0x1d76>
   5a494:      	jmp	0x7085f <f.2+0x180af>
   5a499:      	leaq	-0xd(%r12), %rsi
   5a49e:      	movq	$0x0, 0x48(%rsp)
   5a4a7:      	movq	$0x3, 0x30(%rsp)
   5a4b0:      	xorl	%edi, %edi
   5a4b2:      	callq	0x70870 <f.3>
   5a4b7:      	subq	$0x8, %rsp
   5a4bb:      	cmpb	$0x0, 0x1b58e(%rip)     # 0x75a50 <g.4>
   5a4c2:      	je	0x7085f <f.2+0x180af>
   5a4c8:      	movq	%rax, 0x10(%rsp)
   5a4cd:      	cmpq	$0x0, 0x1b573(%rip)     # 0x75a48 <g.3>
   5a4d5:      	je	0x7085f <f.2+0x180af>
   5a4db:      	leaq	-0xe(%r12), %rsi
   5a4e0:      	movq	$0x0, 0x48(%rsp)
   5a4e9:      	movq	$0x3, 0x30(%rsp)
   5a4f2:      	xorl	%edi, %edi
   5a4f4:      	callq	0x70870 <f.3>
   5a4f9:      	subq	$0x8, %rsp
   5a4fd:      	cmpb	$0x0, 0x1b54c(%rip)     # 0x75a50 <g.4>
   5a504:      	je	0x7085f <f.2+0x180af>
   5a50a:      	cmpq	$0x0, 0x1b536(%rip)     # 0x75a48 <g.3>
   5a512:      	je	0x7085f <f.2+0x180af>
   5a518:      	movq	%rax, %r13
   5a51b:      	addq	0x10(%rsp), %r13
   5a520:      	cmpq	$0xe, %r12
   5a524:      	ja	0x5a52d <f.2+0x1d7d>
   5a526:      	leaq	-0xd(%r12), %rax
   5a52b:      	jmp	0x5a596 <f.2+0x1de6>
   5a52d:      	movq	$0x0, 0x48(%rsp)
   5a536:      	movq	$0x3, 0x30(%rsp)
   5a53f:      	xorl	%edi, %edi
   5a541:      	leaq	-0xe(%r12), %rsi
   5a546:      	callq	0x70870 <f.3>
   5a54b:      	subq	$0x8, %rsp
   5a54f:      	cmpb	$0x0, 0x1b4fa(%rip)     # 0x75a50 <g.4>
   5a556:      	je	0x7085f <f.2+0x180af>
   5a55c:      	movq	%rax, 0x10(%rsp)
   5a561:      	cmpq	$0x0, 0x1b4df(%rip)     # 0x75a48 <g.3>
   5a569:      	je	0x7085f <f.2+0x180af>
   5a56f:      	leaq	-0xf(%r12), %rsi
   5a574:      	movq	$0x0, 0x48(%rsp)
   5a57d:      	movq	$0x3, 0x30(%rsp)
   5a586:      	xorl	%edi, %edi
   5a588:      	callq	0x70870 <f.3>
   5a58d:      	subq	$0x8, %rsp
   5a591:      	addq	0x10(%rsp), %rax
   5a596:      	addq	%rax, %r13
   5a599:      	cmpb	$0x0, 0x1b4b0(%rip)     # 0x75a50 <g.4>
   5a5a0:      	je	0x7085f <f.2+0x180af>
   5a5a6:      	addq	%rbp, %r13
   5a5a9:      	addq	%r15, %r13
   5a5ac:      	cmpq	$0x0, 0x1b494(%rip)     # 0x75a48 <g.3>
   5a5b4:      	je	0x7085f <f.2+0x180af>
   5a5ba:      	cmpq	$0xa, %r12
   5a5be:      	je	0x5a5de <f.2+0x1e2e>
   5a5c0:      	cmpq	$0x9, %r12
   5a5c4:      	jne	0x5a5f6 <f.2+0x1e46>
   5a5c6:      	leaq	-0x8(%r12,%r13), %r15
   5a5cb:      	cmpq	$0x0, 0x1b475(%rip)     # 0x75a48 <g.3>
   5a5d3:      	jne	0x5ab72 <f.2+0x23c2>
   5a5d9:      	jmp	0x7085f <f.2+0x180af>
   5a5de:      	movl	$0x1, %ebp
   5a5e3:      	cmpq	$0x0, 0x1b45d(%rip)     # 0x75a48 <g.3>
   5a5eb:      	jne	0x5a8a1 <f.2+0x20f1>
   5a5f1:      	jmp	0x7085f <f.2+0x180af>
   5a5f6:      	cmpq	$0xc, %r12
   5a5fa:      	jb	0x5a616 <f.2+0x1e66>
   5a5fc:      	jne	0x5a62f <f.2+0x1e7f>
   5a5fe:      	movl	$0x1, %ebp
   5a603:      	cmpq	$0x0, 0x1b43d(%rip)     # 0x75a48 <g.3>
   5a60b:      	jne	0x5a6b8 <f.2+0x1f08>
   5a611:      	jmp	0x7085f <f.2+0x180af>
   5a616:      	movl	$0x1, %r15d
   5a61c:      	cmpq	$0x0, 0x1b424(%rip)     # 0x75a48 <g.3>
   5a624:      	jne	0x5a755 <f.2+0x1fa5>
   5a62a:      	jmp	0x7085f <f.2+0x180af>
   5a62f:      	leaq	-0xc(%r12), %rsi
   5a634:      	movq	$0x0, 0x48(%rsp)
   5a63d:      	movq	$0x3, 0x30(%rsp)
   5a646:      	xorl	%edi, %edi
   5a648:      	callq	0x70870 <f.3>
   5a64d:      	subq	$0x8, %rsp
   5a651:      	cmpb	$0x0, 0x1b3f8(%rip)     # 0x75a50 <g.4>
   5a658:      	je	0x7085f <f.2+0x180af>
   5a65e:      	cmpq	$0x0, 0x1b3e2(%rip)     # 0x75a48 <g.3>
   5a666:      	je	0x7085f <f.2+0x180af>
   5a66c:      	movq	%rax, %r15
   5a66f:      	leaq	-0xd(%r12), %rsi
   5a674:      	movq	$0x0, 0x48(%rsp)
   5a67d:      	movq	$0x3, 0x30(%rsp)
   5a686:      	xorl	%edi, %edi
   5a688:      	callq	0x70870 <f.3>
   5a68d:      	subq	$0x8, %rsp
   5a691:      	cmpb	$0x0, 0x1b3b8(%rip)     # 0x75a50 <g.4>
   5a698:      	je	0x7085f <f.2+0x180af>
   5a69e:      	cmpq	$0x0, 0x1b3a2(%rip)     # 0x75a48 <g.3>
   5a6a6:      	je	0x7085f <f.2+0x180af>
   5a6ac:      	movq	%rax, %rbp
   5a6af:      	addq	%r15, %rbp
   5a6b2:      	cmpq	$0xd, %r12
   5a6b6:      	ja	0x5a6bf <f.2+0x1f0f>
   5a6b8:      	leaq	-0xc(%r12,%rbp), %r15
   5a6bd:      	jmp	0x5a73b <f.2+0x1f8b>
   5a6bf:      	movq	$0x0, 0x48(%rsp)
   5a6c8:      	movq	$0x3, 0x30(%rsp)
   5a6d1:      	xorl	%edi, %edi
   5a6d3:      	leaq	-0xd(%r12), %rsi
   5a6d8:      	callq	0x70870 <f.3>
   5a6dd:      	subq	$0x8, %rsp
   5a6e1:      	cmpb	$0x0, 0x1b368(%rip)     # 0x75a50 <g.4>
   5a6e8:      	je	0x7085f <f.2+0x180af>
   5a6ee:      	movq	%rax, 0x10(%rsp)
   5a6f3:      	cmpq	$0x0, 0x1b34d(%rip)     # 0x75a48 <g.3>
   5a6fb:      	je	0x7085f <f.2+0x180af>
   5a701:      	leaq	-0xe(%r12), %rsi
   5a706:      	movq	$0x0, 0x48(%rsp)
   5a70f:      	movq	$0x3, 0x30(%rsp)
   5a718:      	xorl	%edi, %edi
   5a71a:      	callq	0x70870 <f.3>
   5a71f:      	subq	$0x8, %rsp
   5a723:      	cmpb	$0x0, 0x1b326(%rip)     # 0x75a50 <g.4>
   5a72a:      	je	0x7085f <f.2+0x180af>
   5a730:      	movq	%rax, %r15
   5a733:      	addq	0x10(%rsp), %r15
   5a738:      	addq	%rbp, %r15
   5a73b:      	cmpq	$0x0, 0x1b305(%rip)     # 0x75a48 <g.3>
   5a743:      	je	0x7085f <f.2+0x180af>
   5a749:      	cmpq	$0xd, %r12
   5a74d:      	je	0x5a75f <f.2+0x1faf>
   5a74f:      	cmpq	$0xc, %r12
   5a753:      	jne	0x5a777 <f.2+0x1fc7>
   5a755:      	leaq	-0xb(%r12,%r15), %rbp
   5a75a:      	jmp	0x5a88d <f.2+0x20dd>
   5a75f:      	movl	$0x1, %eax
   5a764:      	cmpq	$0x0, 0x1b2dc(%rip)     # 0x75a48 <g.3>
   5a76c:      	jne	0x5a7fd <f.2+0x204d>
   5a772:      	jmp	0x7085f <f.2+0x180af>
   5a777:      	leaq	-0xd(%r12), %rsi
   5a77c:      	movq	$0x0, 0x48(%rsp)
   5a785:      	movq	$0x3, 0x30(%rsp)
   5a78e:      	xorl	%edi, %edi
   5a790:      	callq	0x70870 <f.3>
   5a795:      	subq	$0x8, %rsp
   5a799:      	cmpb	$0x0, 0x1b2b0(%rip)     # 0x75a50 <g.4>
   5a7a0:      	je	0x7085f <f.2+0x180af>
   5a7a6:      	cmpq	$0x0, 0x1b29a(%rip)     # 0x75a48 <g.3>
   5a7ae:      	je	0x7085f <f.2+0x180af>
   5a7b4:      	movq	%rax, %rbp
   5a7b7:      	leaq	-0xe(%r12), %rsi
   5a7bc:      	movq	$0x0, 0x48(%rsp)
   5a7c5:      	movq	$0x3, 0x30(%rsp)
   5a7ce:      	xorl	%edi, %edi
   5a7d0:      	callq	0x70870 <f.3>
   5a7d5:      	subq	$0x8, %rsp
   5a7d9:      	cmpb	$0x0, 0x1b270(%rip)     # 0x75a50 <g.4>
   5a7e0:      	je	0x7085f <f.2+0x180af>
   5a7e6:      	cmpq	$0x0, 0x1b25a(%rip)     # 0x75a48 <g.3>
   5a7ee:      	je	0x7085f <f.2+0x180af>
   5a7f4:      	addq	%rbp, %rax
   5a7f7:      	cmpq	$0xe, %r12
   5a7fb:      	ja	0x5a804 <f.2+0x2054>
   5a7fd:      	leaq	-0xd(%r12), %rbp
   5a802:      	jmp	0x5a87a <f.2+0x20ca>
   5a804:      	movq	%rax, 0x10(%rsp)
   5a809:      	movq	$0x0, 0x48(%rsp)
   5a812:      	movq	$0x3, 0x30(%rsp)
   5a81b:      	xorl	%edi, %edi
   5a81d:      	leaq	-0xe(%r12), %rsi
   5a822:      	callq	0x70870 <f.3>
   5a827:      	subq	$0x8, %rsp
   5a82b:      	cmpb	$0x0, 0x1b21e(%rip)     # 0x75a50 <g.4>
   5a832:      	je	0x7085f <f.2+0x180af>
   5a838:      	movq	%rax, 0x18(%rsp)
   5a83d:      	cmpq	$0x0, 0x1b203(%rip)     # 0x75a48 <g.3>
   5a845:      	je	0x7085f <f.2+0x180af>
   5a84b:      	leaq	-0xf(%r12), %rsi
   5a850:      	movq	$0x0, 0x48(%rsp)
   5a859:      	movq	$0x3, 0x30(%rsp)
   5a862:      	xorl	%edi, %edi
   5a864:      	callq	0x70870 <f.3>
   5a869:      	subq	$0x8, %rsp
   5a86d:      	movq	%rax, %rbp
   5a870:      	addq	0x18(%rsp), %rbp
   5a875:      	movq	0x10(%rsp), %rax
   5a87a:      	cmpb	$0x0, 0x1b1cf(%rip)     # 0x75a50 <g.4>
   5a881:      	je	0x7085f <f.2+0x180af>
   5a887:      	addq	%rax, %rbp
   5a88a:      	addq	%r15, %rbp
   5a88d:      	cmpq	$0x0, 0x1b1b3(%rip)     # 0x75a48 <g.3>
   5a895:      	je	0x7085f <f.2+0x180af>
   5a89b:      	cmpq	$0xb, %r12
   5a89f:      	ja	0x5a8b8 <f.2+0x2108>
   5a8a1:      	leaq	-0xa(%r12), %r15
   5a8a6:      	cmpb	$0x0, 0x1b1a3(%rip)     # 0x75a50 <g.4>
   5a8ad:      	jne	0x5ab5e <f.2+0x23ae>
   5a8b3:      	jmp	0x7085f <f.2+0x180af>
   5a8b8:      	cmpq	$0xc, %r12
   5a8bc:      	jne	0x5a8d7 <f.2+0x2127>
   5a8be:      	movl	$0x1, %r15d
   5a8c4:      	cmpq	$0x0, 0x1b17c(%rip)     # 0x75a48 <g.3>
   5a8cc:      	jne	0x5aa1c <f.2+0x226c>
   5a8d2:      	jmp	0x7085f <f.2+0x180af>
   5a8d7:      	cmpq	$0xe, %r12
   5a8db:      	jb	0x5a9f0 <f.2+0x2240>
   5a8e1:      	leaq	-0xd(%r12), %rsi
   5a8e6:      	movq	$0x0, 0x48(%rsp)
   5a8ef:      	movq	$0x3, 0x30(%rsp)
   5a8f8:      	xorl	%edi, %edi
   5a8fa:      	callq	0x70870 <f.3>
   5a8ff:      	subq	$0x8, %rsp
   5a903:      	cmpb	$0x0, 0x1b146(%rip)     # 0x75a50 <g.4>
   5a90a:      	je	0x7085f <f.2+0x180af>
   5a910:      	cmpq	$0x0, 0x1b130(%rip)     # 0x75a48 <g.3>
   5a918:      	je	0x7085f <f.2+0x180af>
   5a91e:      	movq	%rax, %r15
   5a921:      	leaq	-0xe(%r12), %rsi
   5a926:      	movq	$0x0, 0x48(%rsp)
   5a92f:      	movq	$0x3, 0x30(%rsp)
   5a938:      	xorl	%edi, %edi
   5a93a:      	callq	0x70870 <f.3>
   5a93f:      	subq	$0x8, %rsp
   5a943:      	cmpb	$0x0, 0x1b106(%rip)     # 0x75a50 <g.4>
   5a94a:      	je	0x7085f <f.2+0x180af>
   5a950:      	cmpq	$0x0, 0x1b0f0(%rip)     # 0x75a48 <g.3>
   5a958:      	je	0x7085f <f.2+0x180af>
   5a95e:      	addq	%r15, %rax
   5a961:      	cmpq	$0xe, %r12
   5a965:      	je	0x5aa03 <f.2+0x2253>
   5a96b:      	movq	%rax, 0x10(%rsp)
   5a970:      	movq	$0x0, 0x48(%rsp)
   5a979:      	movq	$0x3, 0x30(%rsp)
   5a982:      	xorl	%edi, %edi
   5a984:      	leaq	-0xe(%r12), %rsi
   5a989:      	callq	0x70870 <f.3>
   5a98e:      	subq	$0x8, %rsp
   5a992:      	cmpb	$0x0, 0x1b0b7(%rip)     # 0x75a50 <g.4>
   5a999:      	je	0x7085f <f.2+0x180af>
   5a99f:      	movq	%rax, 0x18(%rsp)
   5a9a4:      	cmpq	$0x0, 0x1b09c(%rip)     # 0x75a48 <g.3>
   5a9ac:      	je	0x7085f <f.2+0x180af>
   5a9b2:      	leaq	-0xf(%r12), %rsi
   5a9b7:      	movq	$0x0, 0x48(%rsp)
   5a9c0:      	movq	$0x3, 0x30(%rsp)
   5a9c9:      	xorl	%edi, %edi
   5a9cb:      	callq	0x70870 <f.3>
   5a9d0:      	subq	$0x8, %rsp
   5a9d4:      	cmpb	$0x0, 0x1b075(%rip)     # 0x75a50 <g.4>
   5a9db:      	je	0x7085f <f.2+0x180af>
   5a9e1:      	movq	%rax, %r15
   5a9e4:      	addq	0x18(%rsp), %r15
   5a9e9:      	addq	0x10(%rsp), %r15
   5a9ee:      	jmp	0x5aa08 <f.2+0x2258>
   5a9f0:      	movl	$0x1, %eax
   5a9f5:      	cmpq	$0x0, 0x1b04b(%rip)     # 0x75a48 <g.3>
   5a9fd:      	je	0x7085f <f.2+0x180af>
   5aa03:      	leaq	-0xd(%r12,%rax), %r15
   5aa08:      	cmpq	$0x0, 0x1b038(%rip)     # 0x75a48 <g.3>
   5aa10:      	je	0x7085f <f.2+0x180af>
   5aa16:      	cmpq	$0xd, %r12
   5aa1a:      	ja	0x5aa26 <f.2+0x2276>
   5aa1c:      	leaq	-0xc(%r12), %rcx
   5aa21:      	jmp	0x5ab4e <f.2+0x239e>
   5aa26:      	cmpq	$0xe, %r12
   5aa2a:      	jne	0x5aa44 <f.2+0x2294>
   5aa2c:      	movl	$0x1, %ecx
   5aa31:      	cmpq	$0x0, 0x1b00f(%rip)     # 0x75a48 <g.3>
   5aa39:      	jne	0x5aad1 <f.2+0x2321>
   5aa3f:      	jmp	0x7085f <f.2+0x180af>
   5aa44:      	leaq	-0xe(%r12), %rsi
   5aa49:      	movq	$0x0, 0x48(%rsp)
   5aa52:      	movq	$0x3, 0x30(%rsp)
   5aa5b:      	xorl	%edi, %edi
   5aa5d:      	callq	0x70870 <f.3>
   5aa62:      	subq	$0x8, %rsp
   5aa66:      	cmpb	$0x0, 0x1afe3(%rip)     # 0x75a50 <g.4>
   5aa6d:      	je	0x7085f <f.2+0x180af>
   5aa73:      	movq	%rax, 0x10(%rsp)
   5aa78:      	cmpq	$0x0, 0x1afc8(%rip)     # 0x75a48 <g.3>
   5aa80:      	je	0x7085f <f.2+0x180af>
   5aa86:      	leaq	-0xf(%r12), %rsi
   5aa8b:      	movq	$0x0, 0x48(%rsp)
   5aa94:      	movq	$0x3, 0x30(%rsp)
   5aa9d:      	xorl	%edi, %edi
   5aa9f:      	callq	0x70870 <f.3>
   5aaa4:      	subq	$0x8, %rsp
   5aaa8:      	cmpb	$0x0, 0x1afa1(%rip)     # 0x75a50 <g.4>
   5aaaf:      	je	0x7085f <f.2+0x180af>
   5aab5:      	cmpq	$0x0, 0x1af8b(%rip)     # 0x75a48 <g.3>
   5aabd:      	je	0x7085f <f.2+0x180af>
   5aac3:      	movq	%rax, %rcx
   5aac6:      	addq	0x10(%rsp), %rcx
   5aacb:      	cmpq	$0xf, %r12
   5aacf:      	ja	0x5aad8 <f.2+0x2328>
   5aad1:      	leaq	-0xe(%r12), %rax
   5aad6:      	jmp	0x5ab4b <f.2+0x239b>
   5aad8:      	movq	%rcx, 0x10(%rsp)
   5aadd:      	movq	$0x0, 0x48(%rsp)
   5aae6:      	movq	$0x3, 0x30(%rsp)
   5aaef:      	xorl	%edi, %edi
   5aaf1:      	leaq	-0xf(%r12), %rsi
   5aaf6:      	callq	0x70870 <f.3>
   5aafb:      	subq	$0x8, %rsp
   5aaff:      	cmpb	$0x0, 0x1af4a(%rip)     # 0x75a50 <g.4>
   5ab06:      	je	0x7085f <f.2+0x180af>
   5ab0c:      	movq	%rax, 0x18(%rsp)
   5ab11:      	cmpq	$0x0, 0x1af2f(%rip)     # 0x75a48 <g.3>
   5ab19:      	je	0x7085f <f.2+0x180af>
   5ab1f:      	leaq	-0x10(%r12), %rsi
   5ab24:      	movq	$0x0, 0x48(%rsp)
   5ab2d:      	movq	$0x3, 0x30(%rsp)
   5ab36:      	xorl	%edi, %edi
   5ab38:      	callq	0x70870 <f.3>
   5ab3d:      	subq	$0x8, %rsp
   5ab41:      	addq	0x18(%rsp), %rax
   5ab46:      	movq	0x10(%rsp), %rcx
   5ab4b:      	addq	%rax, %rcx
   5ab4e:      	addq	%rcx, %r15
   5ab51:      	cmpb	$0x0, 0x1aef8(%rip)     # 0x75a50 <g.4>
   5ab58:      	je	0x7085f <f.2+0x180af>
   5ab5e:      	addq	%rbp, %r15
   5ab61:      	addq	%r13, %r15
   5ab64:      	cmpq	$0x0, 0x1aedc(%rip)     # 0x75a48 <g.3>
   5ab6c:      	je	0x7085f <f.2+0x180af>
   5ab72:      	cmpq	$0x8, %r12
   5ab76:      	ja	0x5ac1e <f.2+0x246e>
   5ab7c:      	leaq	-0x7(%r12), %r13
   5ab81:      	cmpb	$0x0, 0x1aec8(%rip)     # 0x75a50 <g.4>
   5ab88:      	je	0x7085f <f.2+0x180af>
   5ab8e:      	addq	%r15, %r13
   5ab91:      	addq	%r14, %r13
   5ab94:      	leaq	0x68(%rsp), %r15
   5ab99:      	cmpq	$0x0, 0x1aea7(%rip)     # 0x75a48 <g.3>
   5aba1:      	je	0x7085f <f.2+0x180af>
   5aba7:      	cmpq	$0x5, %r12
   5abab:      	ja	0x5abc5 <f.2+0x2415>
   5abad:      	leaq	-0x4(%r12,%r13), %rbp
   5abb2:      	cmpq	$0x0, 0x1ae8e(%rip)     # 0x75a48 <g.3>
   5abba:      	jne	0x5e668 <f.2+0x5eb8>
   5abc0:      	jmp	0x7085f <f.2+0x180af>
   5abc5:      	cmpq	$0x6, %r12
   5abc9:      	jne	0x5abe4 <f.2+0x2434>
   5abcb:      	movl	$0x1, %r14d
   5abd1:      	cmpq	$0x0, 0x1ae6f(%rip)     # 0x75a48 <g.3>
   5abd9:      	jne	0x5ceb6 <f.2+0x4706>
   5abdf:      	jmp	0x7085f <f.2+0x180af>
   5abe4:      	cmpq	$0x8, %r12
   5abe8:      	jb	0x5ac05 <f.2+0x2455>
   5abea:      	jne	0x5ac3d <f.2+0x248d>
   5abec:      	movl	$0x1, %r14d
   5abf2:      	cmpq	$0x0, 0x1ae4e(%rip)     # 0x75a48 <g.3>
   5abfa:      	jne	0x5b411 <f.2+0x2c61>
   5ac00:      	jmp	0x7085f <f.2+0x180af>
   5ac05:      	movl	$0x1, %r15d
   5ac0b:      	cmpq	$0x0, 0x1ae35(%rip)     # 0x75a48 <g.3>
   5ac13:      	jne	0x5c274 <f.2+0x3ac4>
   5ac19:      	jmp	0x7085f <f.2+0x180af>
   5ac1e:      	cmpq	$0x9, %r12
   5ac22:      	jne	0x5ac5e <f.2+0x24ae>
   5ac24:      	movl	$0x1, %r13d
   5ac2a:      	cmpq	$0x0, 0x1ae16(%rip)     # 0x75a48 <g.3>
   5ac32:      	jne	0x5bc9b <f.2+0x34eb>
   5ac38:      	jmp	0x7085f <f.2+0x180af>
   5ac3d:      	cmpq	$0xa, %r12
   5ac41:      	jb	0x5ac83 <f.2+0x24d3>
   5ac43:      	jne	0x5acb4 <f.2+0x2504>
   5ac45:      	movl	$0x1, %r14d
   5ac4b:      	cmpq	$0x0, 0x1adf5(%rip)     # 0x75a48 <g.3>
   5ac53:      	jne	0x5af0b <f.2+0x275b>
   5ac59:      	jmp	0x7085f <f.2+0x180af>
   5ac5e:      	cmpq	$0xb, %r12
   5ac62:      	jb	0x5ac9c <f.2+0x24ec>
   5ac64:      	jne	0x5adc9 <f.2+0x2619>
   5ac6a:      	movl	$0x1, %r13d
   5ac70:      	cmpq	$0x0, 0x1add0(%rip)     # 0x75a48 <g.3>
   5ac78:      	jne	0x5af5f <f.2+0x27af>
   5ac7e:      	jmp	0x7085f <f.2+0x180af>
   5ac83:      	movl	$0x1, %r15d
   5ac89:      	cmpq	$0x0, 0x1adb7(%rip)     # 0x75a48 <g.3>
   5ac91:      	jne	0x5b14f <f.2+0x299f>
   5ac97:      	jmp	0x7085f <f.2+0x180af>
   5ac9c:      	movl	$0x1, %ebp
   5aca1:      	cmpq	$0x0, 0x1ad9f(%rip)     # 0x75a48 <g.3>
   5aca9:      	jne	0x5b6ff <f.2+0x2f4f>
   5acaf:      	jmp	0x7085f <f.2+0x180af>
   5acb4:      	cmpq	$0xc, %r12
   5acb8:      	jb	0x5aede <f.2+0x272e>
   5acbe:      	leaq	-0xb(%r12), %rsi
   5acc3:      	movq	$0x0, 0x48(%rsp)
   5accc:      	movq	$0x3, 0x30(%rsp)
   5acd5:      	xorl	%edi, %edi
   5acd7:      	callq	0x70870 <f.3>
   5acdc:      	subq	$0x8, %rsp
   5ace0:      	cmpb	$0x0, 0x1ad69(%rip)     # 0x75a50 <g.4>
   5ace7:      	je	0x7085f <f.2+0x180af>
   5aced:      	cmpq	$0x0, 0x1ad53(%rip)     # 0x75a48 <g.3>
   5acf5:      	je	0x7085f <f.2+0x180af>
   5acfb:      	movq	%rax, %r14
   5acfe:      	leaq	-0xc(%r12), %rbp
   5ad03:      	movq	$0x0, 0x48(%rsp)
   5ad0c:      	movq	$0x3, 0x30(%rsp)
   5ad15:      	xorl	%edi, %edi
   5ad17:      	movq	%rbp, %rsi
   5ad1a:      	callq	0x70870 <f.3>
   5ad1f:      	subq	$0x8, %rsp
   5ad23:      	cmpb	$0x0, 0x1ad26(%rip)     # 0x75a50 <g.4>
   5ad2a:      	je	0x7085f <f.2+0x180af>
   5ad30:      	cmpq	$0x0, 0x1ad10(%rip)     # 0x75a48 <g.3>
   5ad38:      	je	0x7085f <f.2+0x180af>
   5ad3e:      	movq	%rax, %r15
   5ad41:      	addq	%r14, %r15
   5ad44:      	cmpq	$0xc, %r12
   5ad48:      	je	0x5aef2 <f.2+0x2742>
   5ad4e:      	movq	$0x0, 0x48(%rsp)
   5ad57:      	movq	$0x3, 0x30(%rsp)
   5ad60:      	xorl	%edi, %edi
   5ad62:      	movq	%rbp, %rsi
   5ad65:      	callq	0x70870 <f.3>
   5ad6a:      	subq	$0x8, %rsp
   5ad6e:      	cmpb	$0x0, 0x1acdb(%rip)     # 0x75a50 <g.4>
   5ad75:      	je	0x7085f <f.2+0x180af>
   5ad7b:      	cmpq	$0x0, 0x1acc5(%rip)     # 0x75a48 <g.3>
   5ad83:      	je	0x7085f <f.2+0x180af>
   5ad89:      	movq	%rax, %rbp
   5ad8c:      	leaq	-0xd(%r12), %rsi
   5ad91:      	movq	$0x0, 0x48(%rsp)
   5ad9a:      	movq	$0x3, 0x30(%rsp)
   5ada3:      	xorl	%edi, %edi
   5ada5:      	callq	0x70870 <f.3>
   5adaa:      	subq	$0x8, %rsp
   5adae:      	cmpb	$0x0, 0x1ac9b(%rip)     # 0x75a50 <g.4>
   5adb5:      	je	0x7085f <f.2+0x180af>
   5adbb:      	movq	%rax, %r14
   5adbe:      	addq	%rbp, %r14
   5adc1:      	addq	%r15, %r14
   5adc4:      	jmp	0x5aef7 <f.2+0x2747>
   5adc9:      	cmpq	$0xd, %r12
   5adcd:      	jb	0x5af33 <f.2+0x2783>
   5add3:      	leaq	-0xc(%r12), %rsi
   5add8:      	movq	$0x0, 0x48(%rsp)
   5ade1:      	movq	$0x3, 0x30(%rsp)
   5adea:      	xorl	%edi, %edi
   5adec:      	callq	0x70870 <f.3>
   5adf1:      	subq	$0x8, %rsp
   5adf5:      	cmpb	$0x0, 0x1ac54(%rip)     # 0x75a50 <g.4>
   5adfc:      	je	0x7085f <f.2+0x180af>
   5ae02:      	cmpq	$0x0, 0x1ac3e(%rip)     # 0x75a48 <g.3>
   5ae0a:      	je	0x7085f <f.2+0x180af>
   5ae10:      	movq	%rax, %r13
   5ae13:      	leaq	-0xd(%r12), %rsi
   5ae18:      	movq	$0x0, 0x48(%rsp)
   5ae21:      	movq	$0x3, 0x30(%rsp)
   5ae2a:      	xorl	%edi, %edi
   5ae2c:      	callq	0x70870 <f.3>
   5ae31:      	subq	$0x8, %rsp
   5ae35:      	cmpb	$0x0, 0x1ac14(%rip)     # 0x75a50 <g.4>
   5ae3c:      	je	0x7085f <f.2+0x180af>
   5ae42:      	cmpq	$0x0, 0x1abfe(%rip)     # 0x75a48 <g.3>
   5ae4a:      	je	0x7085f <f.2+0x180af>
   5ae50:      	movq	%rax, %rbp
   5ae53:      	addq	%r13, %rbp
   5ae56:      	cmpq	$0xd, %r12
   5ae5a:      	je	0x5af46 <f.2+0x2796>
   5ae60:      	movq	$0x0, 0x48(%rsp)
   5ae69:      	movq	$0x3, 0x30(%rsp)
   5ae72:      	xorl	%edi, %edi
   5ae74:      	leaq	-0xd(%r12), %rsi
   5ae79:      	callq	0x70870 <f.3>
   5ae7e:      	subq	$0x8, %rsp
   5ae82:      	cmpb	$0x0, 0x1abc7(%rip)     # 0x75a50 <g.4>
   5ae89:      	je	0x7085f <f.2+0x180af>
   5ae8f:      	movq	%rax, 0x10(%rsp)
   5ae94:      	cmpq	$0x0, 0x1abac(%rip)     # 0x75a48 <g.3>
   5ae9c:      	je	0x7085f <f.2+0x180af>
   5aea2:      	leaq	-0xe(%r12), %rsi
   5aea7:      	movq	$0x0, 0x48(%rsp)
   5aeb0:      	movq	$0x3, 0x30(%rsp)
   5aeb9:      	xorl	%edi, %edi
   5aebb:      	callq	0x70870 <f.3>
   5aec0:      	subq	$0x8, %rsp
   5aec4:      	cmpb	$0x0, 0x1ab85(%rip)     # 0x75a50 <g.4>
   5aecb:      	je	0x7085f <f.2+0x180af>
   5aed1:      	movq	%rax, %r13
   5aed4:      	addq	0x10(%rsp), %r13
   5aed9:      	addq	%rbp, %r13
   5aedc:      	jmp	0x5af4b <f.2+0x279b>
   5aede:      	movl	$0x1, %r15d
   5aee4:      	cmpq	$0x0, 0x1ab5c(%rip)     # 0x75a48 <g.3>
   5aeec:      	je	0x7085f <f.2+0x180af>
   5aef2:      	leaq	-0xb(%r12,%r15), %r14
   5aef7:      	cmpq	$0x0, 0x1ab49(%rip)     # 0x75a48 <g.3>
   5aeff:      	je	0x7085f <f.2+0x180af>
   5af05:      	cmpq	$0xb, %r12
   5af09:      	ja	0x5af15 <f.2+0x2765>
   5af0b:      	leaq	-0xa(%r12,%r14), %r15
   5af10:      	jmp	0x5b135 <f.2+0x2985>
   5af15:      	cmpq	$0xc, %r12
   5af19:      	jne	0x5af8b <f.2+0x27db>
   5af1b:      	movl	$0x1, %ebp
   5af20:      	cmpq	$0x0, 0x1ab20(%rip)     # 0x75a48 <g.3>
   5af28:      	jne	0x5b018 <f.2+0x2868>
   5af2e:      	jmp	0x7085f <f.2+0x180af>
   5af33:      	movl	$0x1, %ebp
   5af38:      	cmpq	$0x0, 0x1ab08(%rip)     # 0x75a48 <g.3>
   5af40:      	je	0x7085f <f.2+0x180af>
   5af46:      	leaq	-0xc(%r12,%rbp), %r13
   5af4b:      	cmpq	$0x0, 0x1aaf5(%rip)     # 0x75a48 <g.3>
   5af53:      	je	0x7085f <f.2+0x180af>
   5af59:      	cmpq	$0xc, %r12
   5af5d:      	ja	0x5af69 <f.2+0x27b9>
   5af5f:      	leaq	-0xb(%r12,%r13), %rbp
   5af64:      	jmp	0x5b6e5 <f.2+0x2f35>
   5af69:      	cmpq	$0xd, %r12
   5af6d:      	jne	0x5b022 <f.2+0x2872>
   5af73:      	movl	$0x1, %eax
   5af78:      	cmpq	$0x0, 0x1aac8(%rip)     # 0x75a48 <g.3>
   5af80:      	jne	0x5b0ac <f.2+0x28fc>
   5af86:      	jmp	0x7085f <f.2+0x180af>
   5af8b:      	leaq	-0xc(%r12), %rsi
   5af90:      	movq	$0x0, 0x48(%rsp)
   5af99:      	movq	$0x3, 0x30(%rsp)
   5afa2:      	xorl	%edi, %edi
   5afa4:      	callq	0x70870 <f.3>
   5afa9:      	subq	$0x8, %rsp
   5afad:      	cmpb	$0x0, 0x1aa9c(%rip)     # 0x75a50 <g.4>
   5afb4:      	je	0x7085f <f.2+0x180af>
   5afba:      	cmpq	$0x0, 0x1aa86(%rip)     # 0x75a48 <g.3>
   5afc2:      	je	0x7085f <f.2+0x180af>
   5afc8:      	movq	%rax, %r15
   5afcb:      	leaq	-0xd(%r12), %rsi
   5afd0:      	movq	$0x0, 0x48(%rsp)
   5afd9:      	movq	$0x3, 0x30(%rsp)
   5afe2:      	xorl	%edi, %edi
   5afe4:      	callq	0x70870 <f.3>
   5afe9:      	subq	$0x8, %rsp
   5afed:      	cmpb	$0x0, 0x1aa5c(%rip)     # 0x75a50 <g.4>
   5aff4:      	je	0x7085f <f.2+0x180af>
   5affa:      	cmpq	$0x0, 0x1aa46(%rip)     # 0x75a48 <g.3>
   5b002:      	je	0x7085f <f.2+0x180af>
   5b008:      	movq	%rax, %rbp
   5b00b:      	addq	%r15, %rbp
   5b00e:      	cmpq	$0xd, %r12
   5b012:      	ja	0x5b0b6 <f.2+0x2906>
   5b018:      	leaq	-0xc(%r12), %r15
   5b01d:      	jmp	0x5b122 <f.2+0x2972>
   5b022:      	leaq	-0xd(%r12), %rsi
   5b027:      	movq	$0x0, 0x48(%rsp)
   5b030:      	movq	$0x3, 0x30(%rsp)
   5b039:      	xorl	%edi, %edi
   5b03b:      	callq	0x70870 <f.3>
   5b040:      	subq	$0x8, %rsp
   5b044:      	cmpb	$0x0, 0x1aa05(%rip)     # 0x75a50 <g.4>
   5b04b:      	je	0x7085f <f.2+0x180af>
   5b051:      	cmpq	$0x0, 0x1a9ef(%rip)     # 0x75a48 <g.3>
   5b059:      	je	0x7085f <f.2+0x180af>
   5b05f:      	movq	%rax, %rbp
   5b062:      	leaq	-0xe(%r12), %rsi
   5b067:      	movq	$0x0, 0x48(%rsp)
   5b070:      	movq	$0x3, 0x30(%rsp)
   5b079:      	xorl	%edi, %edi
   5b07b:      	callq	0x70870 <f.3>
   5b080:      	subq	$0x8, %rsp
   5b084:      	cmpb	$0x0, 0x1a9c5(%rip)     # 0x75a50 <g.4>
   5b08b:      	je	0x7085f <f.2+0x180af>
   5b091:      	cmpq	$0x0, 0x1a9af(%rip)     # 0x75a48 <g.3>
   5b099:      	je	0x7085f <f.2+0x180af>
   5b09f:      	addq	%rbp, %rax
   5b0a2:      	cmpq	$0xe, %r12
   5b0a6:      	ja	0x5b65c <f.2+0x2eac>
   5b0ac:      	leaq	-0xd(%r12), %rbp
   5b0b1:      	jmp	0x5b6d2 <f.2+0x2f22>
   5b0b6:      	movq	$0x0, 0x48(%rsp)
   5b0bf:      	movq	$0x3, 0x30(%rsp)
   5b0c8:      	xorl	%edi, %edi
   5b0ca:      	leaq	-0xd(%r12), %rsi
   5b0cf:      	callq	0x70870 <f.3>
   5b0d4:      	subq	$0x8, %rsp
   5b0d8:      	cmpb	$0x0, 0x1a971(%rip)     # 0x75a50 <g.4>
   5b0df:      	je	0x7085f <f.2+0x180af>
   5b0e5:      	movq	%rax, 0x10(%rsp)
   5b0ea:      	cmpq	$0x0, 0x1a956(%rip)     # 0x75a48 <g.3>
   5b0f2:      	je	0x7085f <f.2+0x180af>
   5b0f8:      	leaq	-0xe(%r12), %rsi
   5b0fd:      	movq	$0x0, 0x48(%rsp)
   5b106:      	movq	$0x3, 0x30(%rsp)
   5b10f:      	xorl	%edi, %edi
   5b111:      	callq	0x70870 <f.3>
   5b116:      	subq	$0x8, %rsp
   5b11a:      	movq	%rax, %r15
   5b11d:      	addq	0x10(%rsp), %r15
   5b122:      	cmpb	$0x0, 0x1a927(%rip)     # 0x75a50 <g.4>
   5b129:      	je	0x7085f <f.2+0x180af>
   5b12f:      	addq	%rbp, %r15
   5b132:      	addq	%r14, %r15
   5b135:      	cmpq	$0x0, 0x1a90b(%rip)     # 0x75a48 <g.3>
   5b13d:      	je	0x7085f <f.2+0x180af>
   5b143:      	cmpq	$0xb, %r12
   5b147:      	je	0x5b167 <f.2+0x29b7>
   5b149:      	cmpq	$0xa, %r12
   5b14d:      	jne	0x5b17f <f.2+0x29cf>
   5b14f:      	leaq	-0x9(%r12,%r15), %r14
   5b154:      	cmpq	$0x0, 0x1a8ec(%rip)     # 0x75a48 <g.3>
   5b15c:      	jne	0x5b40b <f.2+0x2c5b>
   5b162:      	jmp	0x7085f <f.2+0x180af>
   5b167:      	movl	$0x1, %ebp
   5b16c:      	cmpq	$0x0, 0x1a8d4(%rip)     # 0x75a48 <g.3>
   5b174:      	jne	0x5b2c1 <f.2+0x2b11>
   5b17a:      	jmp	0x7085f <f.2+0x180af>
   5b17f:      	cmpq	$0xd, %r12
   5b183:      	jb	0x5b294 <f.2+0x2ae4>
   5b189:      	leaq	-0xc(%r12), %rsi
   5b18e:      	movq	$0x0, 0x48(%rsp)
   5b197:      	movq	$0x3, 0x30(%rsp)
   5b1a0:      	xorl	%edi, %edi
   5b1a2:      	callq	0x70870 <f.3>
   5b1a7:      	subq	$0x8, %rsp
   5b1ab:      	cmpb	$0x0, 0x1a89e(%rip)     # 0x75a50 <g.4>
   5b1b2:      	je	0x7085f <f.2+0x180af>
   5b1b8:      	cmpq	$0x0, 0x1a888(%rip)     # 0x75a48 <g.3>
   5b1c0:      	je	0x7085f <f.2+0x180af>
   5b1c6:      	movq	%rax, %rbp
   5b1c9:      	leaq	-0xd(%r12), %rsi
   5b1ce:      	movq	$0x0, 0x48(%rsp)
   5b1d7:      	movq	$0x3, 0x30(%rsp)
   5b1e0:      	xorl	%edi, %edi
   5b1e2:      	callq	0x70870 <f.3>
   5b1e7:      	subq	$0x8, %rsp
   5b1eb:      	cmpb	$0x0, 0x1a85e(%rip)     # 0x75a50 <g.4>
   5b1f2:      	je	0x7085f <f.2+0x180af>
   5b1f8:      	cmpq	$0x0, 0x1a848(%rip)     # 0x75a48 <g.3>
   5b200:      	je	0x7085f <f.2+0x180af>
   5b206:      	movq	%rax, %r14
   5b209:      	addq	%rbp, %r14
   5b20c:      	cmpq	$0xd, %r12
   5b210:      	je	0x5b2a8 <f.2+0x2af8>
   5b216:      	movq	$0x0, 0x48(%rsp)
   5b21f:      	movq	$0x3, 0x30(%rsp)
   5b228:      	xorl	%edi, %edi
   5b22a:      	leaq	-0xd(%r12), %rsi
   5b22f:      	callq	0x70870 <f.3>
   5b234:      	subq	$0x8, %rsp
   5b238:      	cmpb	$0x0, 0x1a811(%rip)     # 0x75a50 <g.4>
   5b23f:      	je	0x7085f <f.2+0x180af>
   5b245:      	movq	%rax, 0x10(%rsp)
   5b24a:      	cmpq	$0x0, 0x1a7f6(%rip)     # 0x75a48 <g.3>
   5b252:      	je	0x7085f <f.2+0x180af>
   5b258:      	leaq	-0xe(%r12), %rsi
   5b25d:      	movq	$0x0, 0x48(%rsp)
   5b266:      	movq	$0x3, 0x30(%rsp)
   5b26f:      	xorl	%edi, %edi
   5b271:      	callq	0x70870 <f.3>
   5b276:      	subq	$0x8, %rsp
   5b27a:      	cmpb	$0x0, 0x1a7cf(%rip)     # 0x75a50 <g.4>
   5b281:      	je	0x7085f <f.2+0x180af>
   5b287:      	movq	%rax, %rbp
   5b28a:      	addq	0x10(%rsp), %rbp
   5b28f:      	addq	%r14, %rbp
   5b292:      	jmp	0x5b2ad <f.2+0x2afd>
   5b294:      	movl	$0x1, %r14d
   5b29a:      	cmpq	$0x0, 0x1a7a6(%rip)     # 0x75a48 <g.3>
   5b2a2:      	je	0x7085f <f.2+0x180af>
   5b2a8:      	leaq	-0xc(%r12,%r14), %rbp
   5b2ad:      	cmpq	$0x0, 0x1a793(%rip)     # 0x75a48 <g.3>
   5b2b5:      	je	0x7085f <f.2+0x180af>
   5b2bb:      	cmpq	$0xc, %r12
   5b2bf:      	ja	0x5b2cb <f.2+0x2b1b>
   5b2c1:      	leaq	-0xb(%r12), %r14
   5b2c6:      	jmp	0x5b3ea <f.2+0x2c3a>
   5b2cb:      	cmpq	$0xd, %r12
   5b2cf:      	jne	0x5b2ea <f.2+0x2b3a>
   5b2d1:      	movl	$0x1, %r14d
   5b2d7:      	cmpq	$0x0, 0x1a769(%rip)     # 0x75a48 <g.3>
   5b2df:      	jne	0x5b377 <f.2+0x2bc7>
   5b2e5:      	jmp	0x7085f <f.2+0x180af>
   5b2ea:      	leaq	-0xd(%r12), %rsi
   5b2ef:      	movq	$0x0, 0x48(%rsp)
   5b2f8:      	movq	$0x3, 0x30(%rsp)
   5b301:      	xorl	%edi, %edi
   5b303:      	callq	0x70870 <f.3>
   5b308:      	subq	$0x8, %rsp
   5b30c:      	cmpb	$0x0, 0x1a73d(%rip)     # 0x75a50 <g.4>
   5b313:      	je	0x7085f <f.2+0x180af>
   5b319:      	movq	%rax, 0x10(%rsp)
   5b31e:      	cmpq	$0x0, 0x1a722(%rip)     # 0x75a48 <g.3>
   5b326:      	je	0x7085f <f.2+0x180af>
   5b32c:      	leaq	-0xe(%r12), %rsi
   5b331:      	movq	$0x0, 0x48(%rsp)
   5b33a:      	movq	$0x3, 0x30(%rsp)
   5b343:      	xorl	%edi, %edi
   5b345:      	callq	0x70870 <f.3>
   5b34a:      	subq	$0x8, %rsp
   5b34e:      	cmpb	$0x0, 0x1a6fb(%rip)     # 0x75a50 <g.4>
   5b355:      	je	0x7085f <f.2+0x180af>
   5b35b:      	cmpq	$0x0, 0x1a6e5(%rip)     # 0x75a48 <g.3>
   5b363:      	je	0x7085f <f.2+0x180af>
   5b369:      	movq	%rax, %r14
   5b36c:      	addq	0x10(%rsp), %r14
   5b371:      	cmpq	$0xe, %r12
   5b375:      	ja	0x5b37e <f.2+0x2bce>
   5b377:      	leaq	-0xd(%r12), %rax
   5b37c:      	jmp	0x5b3e7 <f.2+0x2c37>
   5b37e:      	movq	$0x0, 0x48(%rsp)
   5b387:      	movq	$0x3, 0x30(%rsp)
   5b390:      	xorl	%edi, %edi
   5b392:      	leaq	-0xe(%r12), %rsi
   5b397:      	callq	0x70870 <f.3>
   5b39c:      	subq	$0x8, %rsp
   5b3a0:      	cmpb	$0x0, 0x1a6a9(%rip)     # 0x75a50 <g.4>
   5b3a7:      	je	0x7085f <f.2+0x180af>
   5b3ad:      	movq	%rax, 0x10(%rsp)
   5b3b2:      	cmpq	$0x0, 0x1a68e(%rip)     # 0x75a48 <g.3>
   5b3ba:      	je	0x7085f <f.2+0x180af>
   5b3c0:      	leaq	-0xf(%r12), %rsi
   5b3c5:      	movq	$0x0, 0x48(%rsp)
   5b3ce:      	movq	$0x3, 0x30(%rsp)
   5b3d7:      	xorl	%edi, %edi
   5b3d9:      	callq	0x70870 <f.3>
   5b3de:      	subq	$0x8, %rsp
   5b3e2:      	addq	0x10(%rsp), %rax
   5b3e7:      	addq	%rax, %r14
   5b3ea:      	cmpb	$0x0, 0x1a65f(%rip)     # 0x75a50 <g.4>
   5b3f1:      	je	0x7085f <f.2+0x180af>
   5b3f7:      	addq	%rbp, %r14
   5b3fa:      	addq	%r15, %r14
   5b3fd:      	cmpq	$0x0, 0x1a643(%rip)     # 0x75a48 <g.3>
   5b405:      	je	0x7085f <f.2+0x180af>
   5b40b:      	cmpq	$0x9, %r12
   5b40f:      	ja	0x5b429 <f.2+0x2c79>
   5b411:      	leaq	-0x8(%r12,%r14), %r15
   5b416:      	cmpq	$0x0, 0x1a62a(%rip)     # 0x75a48 <g.3>
   5b41e:      	jne	0x5c268 <f.2+0x3ab8>
   5b424:      	jmp	0x7085f <f.2+0x180af>
   5b429:      	cmpq	$0xa, %r12
   5b42d:      	jne	0x5b447 <f.2+0x2c97>
   5b42f:      	movl	$0x1, %ebp
   5b434:      	cmpq	$0x0, 0x1a60c(%rip)     # 0x75a48 <g.3>
   5b43c:      	jne	0x5b9d2 <f.2+0x3222>
   5b442:      	jmp	0x7085f <f.2+0x180af>
   5b447:      	cmpq	$0xc, %r12
   5b44b:      	jb	0x5b467 <f.2+0x2cb7>
   5b44d:      	jne	0x5b480 <f.2+0x2cd0>
   5b44f:      	movl	$0x1, %ebp
   5b454:      	cmpq	$0x0, 0x1a5ec(%rip)     # 0x75a48 <g.3>
   5b45c:      	jne	0x5b509 <f.2+0x2d59>
   5b462:      	jmp	0x7085f <f.2+0x180af>
   5b467:      	movl	$0x1, %r15d
   5b46d:      	cmpq	$0x0, 0x1a5d3(%rip)     # 0x75a48 <g.3>
   5b475:      	jne	0x5b5a6 <f.2+0x2df6>
   5b47b:      	jmp	0x7085f <f.2+0x180af>
   5b480:      	leaq	-0xc(%r12), %rsi
   5b485:      	movq	$0x0, 0x48(%rsp)
   5b48e:      	movq	$0x3, 0x30(%rsp)
   5b497:      	xorl	%edi, %edi
   5b499:      	callq	0x70870 <f.3>
   5b49e:      	subq	$0x8, %rsp
   5b4a2:      	cmpb	$0x0, 0x1a5a7(%rip)     # 0x75a50 <g.4>
   5b4a9:      	je	0x7085f <f.2+0x180af>
   5b4af:      	cmpq	$0x0, 0x1a591(%rip)     # 0x75a48 <g.3>
   5b4b7:      	je	0x7085f <f.2+0x180af>
   5b4bd:      	movq	%rax, %r15
   5b4c0:      	leaq	-0xd(%r12), %rsi
   5b4c5:      	movq	$0x0, 0x48(%rsp)
   5b4ce:      	movq	$0x3, 0x30(%rsp)
   5b4d7:      	xorl	%edi, %edi
   5b4d9:      	callq	0x70870 <f.3>
   5b4de:      	subq	$0x8, %rsp
   5b4e2:      	cmpb	$0x0, 0x1a567(%rip)     # 0x75a50 <g.4>
   5b4e9:      	je	0x7085f <f.2+0x180af>
   5b4ef:      	cmpq	$0x0, 0x1a551(%rip)     # 0x75a48 <g.3>
   5b4f7:      	je	0x7085f <f.2+0x180af>
   5b4fd:      	movq	%rax, %rbp
   5b500:      	addq	%r15, %rbp
   5b503:      	cmpq	$0xd, %r12
   5b507:      	ja	0x5b510 <f.2+0x2d60>
   5b509:      	leaq	-0xc(%r12,%rbp), %r15
   5b50e:      	jmp	0x5b58c <f.2+0x2ddc>
   5b510:      	movq	$0x0, 0x48(%rsp)
   5b519:      	movq	$0x3, 0x30(%rsp)
   5b522:      	xorl	%edi, %edi
   5b524:      	leaq	-0xd(%r12), %rsi
   5b529:      	callq	0x70870 <f.3>
   5b52e:      	subq	$0x8, %rsp
   5b532:      	cmpb	$0x0, 0x1a517(%rip)     # 0x75a50 <g.4>
   5b539:      	je	0x7085f <f.2+0x180af>
   5b53f:      	movq	%rax, 0x10(%rsp)
   5b544:      	cmpq	$0x0, 0x1a4fc(%rip)     # 0x75a48 <g.3>
   5b54c:      	je	0x7085f <f.2+0x180af>
   5b552:      	leaq	-0xe(%r12), %rsi
   5b557:      	movq	$0x0, 0x48(%rsp)
   5b560:      	movq	$0x3, 0x30(%rsp)
   5b569:      	xorl	%edi, %edi
   5b56b:      	callq	0x70870 <f.3>
   5b570:      	subq	$0x8, %rsp
   5b574:      	cmpb	$0x0, 0x1a4d5(%rip)     # 0x75a50 <g.4>
   5b57b:      	je	0x7085f <f.2+0x180af>
   5b581:      	movq	%rax, %r15
   5b584:      	addq	0x10(%rsp), %r15
   5b589:      	addq	%rbp, %r15
   5b58c:      	cmpq	$0x0, 0x1a4b4(%rip)     # 0x75a48 <g.3>
   5b594:      	je	0x7085f <f.2+0x180af>
   5b59a:      	cmpq	$0xd, %r12
   5b59e:      	je	0x5b5b0 <f.2+0x2e00>
   5b5a0:      	cmpq	$0xc, %r12
   5b5a4:      	jne	0x5b5c8 <f.2+0x2e18>
   5b5a6:      	leaq	-0xb(%r12,%r15), %rbp
   5b5ab:      	jmp	0x5b9be <f.2+0x320e>
   5b5b0:      	movl	$0x1, %eax
   5b5b5:      	cmpq	$0x0, 0x1a48b(%rip)     # 0x75a48 <g.3>
   5b5bd:      	jne	0x5b652 <f.2+0x2ea2>
   5b5c3:      	jmp	0x7085f <f.2+0x180af>
   5b5c8:      	leaq	-0xd(%r12), %rsi
   5b5cd:      	movq	$0x0, 0x48(%rsp)
   5b5d6:      	movq	$0x3, 0x30(%rsp)
   5b5df:      	xorl	%edi, %edi
   5b5e1:      	callq	0x70870 <f.3>
   5b5e6:      	subq	$0x8, %rsp
   5b5ea:      	cmpb	$0x0, 0x1a45f(%rip)     # 0x75a50 <g.4>
   5b5f1:      	je	0x7085f <f.2+0x180af>
   5b5f7:      	cmpq	$0x0, 0x1a449(%rip)     # 0x75a48 <g.3>
   5b5ff:      	je	0x7085f <f.2+0x180af>
   5b605:      	movq	%rax, %rbp
   5b608:      	leaq	-0xe(%r12), %rsi
   5b60d:      	movq	$0x0, 0x48(%rsp)
   5b616:      	movq	$0x3, 0x30(%rsp)
   5b61f:      	xorl	%edi, %edi
   5b621:      	callq	0x70870 <f.3>
   5b626:      	subq	$0x8, %rsp
   5b62a:      	cmpb	$0x0, 0x1a41f(%rip)     # 0x75a50 <g.4>
   5b631:      	je	0x7085f <f.2+0x180af>
   5b637:      	cmpq	$0x0, 0x1a409(%rip)     # 0x75a48 <g.3>
   5b63f:      	je	0x7085f <f.2+0x180af>
   5b645:      	addq	%rbp, %rax
   5b648:      	cmpq	$0xe, %r12
   5b64c:      	ja	0x5b935 <f.2+0x3185>
   5b652:      	leaq	-0xd(%r12), %rbp
   5b657:      	jmp	0x5b9ab <f.2+0x31fb>
   5b65c:      	movq	%rax, 0x10(%rsp)
   5b661:      	movq	$0x0, 0x48(%rsp)
   5b66a:      	movq	$0x3, 0x30(%rsp)
   5b673:      	xorl	%edi, %edi
   5b675:      	leaq	-0xe(%r12), %rsi
   5b67a:      	callq	0x70870 <f.3>
   5b67f:      	subq	$0x8, %rsp
   5b683:      	cmpb	$0x0, 0x1a3c6(%rip)     # 0x75a50 <g.4>
   5b68a:      	je	0x7085f <f.2+0x180af>
   5b690:      	movq	%rax, 0x18(%rsp)
   5b695:      	cmpq	$0x0, 0x1a3ab(%rip)     # 0x75a48 <g.3>
   5b69d:      	je	0x7085f <f.2+0x180af>
   5b6a3:      	leaq	-0xf(%r12), %rsi
   5b6a8:      	movq	$0x0, 0x48(%rsp)
   5b6b1:      	movq	$0x3, 0x30(%rsp)
   5b6ba:      	xorl	%edi, %edi
   5b6bc:      	callq	0x70870 <f.3>
   5b6c1:      	subq	$0x8, %rsp
   5b6c5:      	movq	%rax, %rbp
   5b6c8:      	addq	0x18(%rsp), %rbp
   5b6cd:      	movq	0x10(%rsp), %rax
   5b6d2:      	cmpb	$0x0, 0x1a377(%rip)     # 0x75a50 <g.4>
   5b6d9:      	je	0x7085f <f.2+0x180af>
   5b6df:      	addq	%rax, %rbp
   5b6e2:      	addq	%r13, %rbp
   5b6e5:      	cmpq	$0x0, 0x1a35b(%rip)     # 0x75a48 <g.3>
   5b6ed:      	je	0x7085f <f.2+0x180af>
   5b6f3:      	cmpq	$0xc, %r12
   5b6f7:      	je	0x5b709 <f.2+0x2f59>
   5b6f9:      	cmpq	$0xb, %r12
   5b6fd:      	jne	0x5b721 <f.2+0x2f71>
   5b6ff:      	leaq	-0xa(%r12,%rbp), %r13
   5b704:      	jmp	0x5bc87 <f.2+0x34d7>
   5b709:      	movl	$0x1, %ecx
   5b70e:      	cmpq	$0x0, 0x1a332(%rip)     # 0x75a48 <g.3>
   5b716:      	jne	0x5b867 <f.2+0x30b7>
   5b71c:      	jmp	0x7085f <f.2+0x180af>
   5b721:      	cmpq	$0xe, %r12
   5b725:      	jb	0x5b83a <f.2+0x308a>
   5b72b:      	leaq	-0xd(%r12), %rsi
   5b730:      	movq	$0x0, 0x48(%rsp)
   5b739:      	movq	$0x3, 0x30(%rsp)
   5b742:      	xorl	%edi, %edi
   5b744:      	callq	0x70870 <f.3>
   5b749:      	subq	$0x8, %rsp
   5b74d:      	cmpb	$0x0, 0x1a2fc(%rip)     # 0x75a50 <g.4>
   5b754:      	je	0x7085f <f.2+0x180af>
   5b75a:      	movq	%rax, 0x10(%rsp)
   5b75f:      	cmpq	$0x0, 0x1a2e1(%rip)     # 0x75a48 <g.3>
   5b767:      	je	0x7085f <f.2+0x180af>
   5b76d:      	leaq	-0xe(%r12), %rsi
   5b772:      	movq	$0x0, 0x48(%rsp)
   5b77b:      	movq	$0x3, 0x30(%rsp)
   5b784:      	xorl	%edi, %edi
   5b786:      	callq	0x70870 <f.3>
   5b78b:      	subq	$0x8, %rsp
   5b78f:      	cmpb	$0x0, 0x1a2ba(%rip)     # 0x75a50 <g.4>
   5b796:      	je	0x7085f <f.2+0x180af>
   5b79c:      	cmpq	$0x0, 0x1a2a4(%rip)     # 0x75a48 <g.3>
   5b7a4:      	je	0x7085f <f.2+0x180af>
   5b7aa:      	movq	%rax, %r13
   5b7ad:      	addq	0x10(%rsp), %r13
   5b7b2:      	cmpq	$0xe, %r12
   5b7b6:      	je	0x5b84e <f.2+0x309e>
   5b7bc:      	movq	$0x0, 0x48(%rsp)
   5b7c5:      	movq	$0x3, 0x30(%rsp)
   5b7ce:      	xorl	%edi, %edi
   5b7d0:      	leaq	-0xe(%r12), %rsi
   5b7d5:      	callq	0x70870 <f.3>
   5b7da:      	subq	$0x8, %rsp
   5b7de:      	cmpb	$0x0, 0x1a26b(%rip)     # 0x75a50 <g.4>
   5b7e5:      	je	0x7085f <f.2+0x180af>
   5b7eb:      	movq	%rax, 0x10(%rsp)
   5b7f0:      	cmpq	$0x0, 0x1a250(%rip)     # 0x75a48 <g.3>
   5b7f8:      	je	0x7085f <f.2+0x180af>
   5b7fe:      	leaq	-0xf(%r12), %rsi
   5b803:      	movq	$0x0, 0x48(%rsp)
   5b80c:      	movq	$0x3, 0x30(%rsp)
   5b815:      	xorl	%edi, %edi
   5b817:      	callq	0x70870 <f.3>
   5b81c:      	subq	$0x8, %rsp
   5b820:      	cmpb	$0x0, 0x1a229(%rip)     # 0x75a50 <g.4>
   5b827:      	je	0x7085f <f.2+0x180af>
   5b82d:      	movq	%rax, %rcx
   5b830:      	addq	0x10(%rsp), %rcx
   5b835:      	addq	%r13, %rcx
   5b838:      	jmp	0x5b853 <f.2+0x30a3>
   5b83a:      	movl	$0x1, %r13d
   5b840:      	cmpq	$0x0, 0x1a200(%rip)     # 0x75a48 <g.3>
   5b848:      	je	0x7085f <f.2+0x180af>
   5b84e:      	leaq	-0xd(%r12,%r13), %rcx
   5b853:      	cmpq	$0x0, 0x1a1ed(%rip)     # 0x75a48 <g.3>
   5b85b:      	je	0x7085f <f.2+0x180af>
   5b861:      	cmpq	$0xd, %r12
   5b865:      	ja	0x5b871 <f.2+0x30c1>
   5b867:      	leaq	-0xc(%r12), %r13
   5b86c:      	jmp	0x5bc74 <f.2+0x34c4>
   5b871:      	cmpq	$0xe, %r12
   5b875:      	jne	0x5b890 <f.2+0x30e0>
   5b877:      	movl	$0x1, %r13d
   5b87d:      	cmpq	$0x0, 0x1a1c3(%rip)     # 0x75a48 <g.3>
   5b885:      	jne	0x5b92b <f.2+0x317b>
   5b88b:      	jmp	0x7085f <f.2+0x180af>
   5b890:      	movq	%rcx, 0x10(%rsp)
   5b895:      	leaq	-0xe(%r12), %rsi
   5b89a:      	movq	$0x0, 0x48(%rsp)
   5b8a3:      	movq	$0x3, 0x30(%rsp)
   5b8ac:      	xorl	%edi, %edi
   5b8ae:      	callq	0x70870 <f.3>
   5b8b3:      	subq	$0x8, %rsp
   5b8b7:      	cmpb	$0x0, 0x1a192(%rip)     # 0x75a50 <g.4>
   5b8be:      	je	0x7085f <f.2+0x180af>
   5b8c4:      	movq	%rax, 0x18(%rsp)
   5b8c9:      	cmpq	$0x0, 0x1a177(%rip)     # 0x75a48 <g.3>
   5b8d1:      	je	0x7085f <f.2+0x180af>
   5b8d7:      	leaq	-0xf(%r12), %rsi
   5b8dc:      	movq	$0x0, 0x48(%rsp)
   5b8e5:      	movq	$0x3, 0x30(%rsp)
   5b8ee:      	xorl	%edi, %edi
   5b8f0:      	callq	0x70870 <f.3>
   5b8f5:      	subq	$0x8, %rsp
   5b8f9:      	cmpb	$0x0, 0x1a150(%rip)     # 0x75a50 <g.4>
   5b900:      	je	0x7085f <f.2+0x180af>
   5b906:      	cmpq	$0x0, 0x1a13a(%rip)     # 0x75a48 <g.3>
   5b90e:      	movq	0x10(%rsp), %rcx
   5b913:      	je	0x7085f <f.2+0x180af>
   5b919:      	movq	%rax, %r13
   5b91c:      	addq	0x18(%rsp), %r13
   5b921:      	cmpq	$0xf, %r12
   5b925:      	ja	0x5bc03 <f.2+0x3453>
   5b92b:      	leaq	-0xe(%r12), %rax
   5b930:      	jmp	0x5bc71 <f.2+0x34c1>
   5b935:      	movq	%rax, 0x10(%rsp)
   5b93a:      	movq	$0x0, 0x48(%rsp)
   5b943:      	movq	$0x3, 0x30(%rsp)
   5b94c:      	xorl	%edi, %edi
   5b94e:      	leaq	-0xe(%r12), %rsi
   5b953:      	callq	0x70870 <f.3>
   5b958:      	subq	$0x8, %rsp
   5b95c:      	cmpb	$0x0, 0x1a0ed(%rip)     # 0x75a50 <g.4>
   5b963:      	je	0x7085f <f.2+0x180af>
   5b969:      	movq	%rax, 0x18(%rsp)
   5b96e:      	cmpq	$0x0, 0x1a0d2(%rip)     # 0x75a48 <g.3>
   5b976:      	je	0x7085f <f.2+0x180af>
   5b97c:      	leaq	-0xf(%r12), %rsi
   5b981:      	movq	$0x0, 0x48(%rsp)
   5b98a:      	movq	$0x3, 0x30(%rsp)
   5b993:      	xorl	%edi, %edi
   5b995:      	callq	0x70870 <f.3>
   5b99a:      	subq	$0x8, %rsp
   5b99e:      	movq	%rax, %rbp
   5b9a1:      	addq	0x18(%rsp), %rbp
   5b9a6:      	movq	0x10(%rsp), %rax
   5b9ab:      	cmpb	$0x0, 0x1a09e(%rip)     # 0x75a50 <g.4>
   5b9b2:      	je	0x7085f <f.2+0x180af>
   5b9b8:      	addq	%rax, %rbp
   5b9bb:      	addq	%r15, %rbp
   5b9be:      	cmpq	$0x0, 0x1a082(%rip)     # 0x75a48 <g.3>
   5b9c6:      	je	0x7085f <f.2+0x180af>
   5b9cc:      	cmpq	$0xb, %r12
   5b9d0:      	ja	0x5b9dc <f.2+0x322c>
   5b9d2:      	leaq	-0xa(%r12), %r15
   5b9d7:      	jmp	0x5c247 <f.2+0x3a97>
   5b9dc:      	cmpq	$0xc, %r12
   5b9e0:      	jne	0x5b9fb <f.2+0x324b>
   5b9e2:      	movl	$0x1, %r15d
   5b9e8:      	cmpq	$0x0, 0x1a058(%rip)     # 0x75a48 <g.3>
   5b9f0:      	jne	0x5bb40 <f.2+0x3390>
   5b9f6:      	jmp	0x7085f <f.2+0x180af>
   5b9fb:      	cmpq	$0xe, %r12
   5b9ff:      	jb	0x5bb14 <f.2+0x3364>
   5ba05:      	leaq	-0xd(%r12), %rsi
   5ba0a:      	movq	$0x0, 0x48(%rsp)
   5ba13:      	movq	$0x3, 0x30(%rsp)
   5ba1c:      	xorl	%edi, %edi
   5ba1e:      	callq	0x70870 <f.3>
   5ba23:      	subq	$0x8, %rsp
   5ba27:      	cmpb	$0x0, 0x1a022(%rip)     # 0x75a50 <g.4>
   5ba2e:      	je	0x7085f <f.2+0x180af>
   5ba34:      	cmpq	$0x0, 0x1a00c(%rip)     # 0x75a48 <g.3>
   5ba3c:      	je	0x7085f <f.2+0x180af>
   5ba42:      	movq	%rax, %r15
   5ba45:      	leaq	-0xe(%r12), %rsi
   5ba4a:      	movq	$0x0, 0x48(%rsp)
   5ba53:      	movq	$0x3, 0x30(%rsp)
   5ba5c:      	xorl	%edi, %edi
   5ba5e:      	callq	0x70870 <f.3>
   5ba63:      	subq	$0x8, %rsp
   5ba67:      	cmpb	$0x0, 0x19fe2(%rip)     # 0x75a50 <g.4>
   5ba6e:      	je	0x7085f <f.2+0x180af>
   5ba74:      	cmpq	$0x0, 0x19fcc(%rip)     # 0x75a48 <g.3>
   5ba7c:      	je	0x7085f <f.2+0x180af>
   5ba82:      	addq	%r15, %rax
   5ba85:      	cmpq	$0xe, %r12
   5ba89:      	je	0x5bb27 <f.2+0x3377>
   5ba8f:      	movq	%rax, 0x10(%rsp)
   5ba94:      	movq	$0x0, 0x48(%rsp)
   5ba9d:      	movq	$0x3, 0x30(%rsp)
   5baa6:      	xorl	%edi, %edi
   5baa8:      	leaq	-0xe(%r12), %rsi
   5baad:      	callq	0x70870 <f.3>
   5bab2:      	subq	$0x8, %rsp
   5bab6:      	cmpb	$0x0, 0x19f93(%rip)     # 0x75a50 <g.4>
   5babd:      	je	0x7085f <f.2+0x180af>
   5bac3:      	movq	%rax, 0x18(%rsp)
   5bac8:      	cmpq	$0x0, 0x19f78(%rip)     # 0x75a48 <g.3>
   5bad0:      	je	0x7085f <f.2+0x180af>
   5bad6:      	leaq	-0xf(%r12), %rsi
   5badb:      	movq	$0x0, 0x48(%rsp)
   5bae4:      	movq	$0x3, 0x30(%rsp)
   5baed:      	xorl	%edi, %edi
   5baef:      	callq	0x70870 <f.3>
   5baf4:      	subq	$0x8, %rsp
   5baf8:      	cmpb	$0x0, 0x19f51(%rip)     # 0x75a50 <g.4>
   5baff:      	je	0x7085f <f.2+0x180af>
   5bb05:      	movq	%rax, %r15
   5bb08:      	addq	0x18(%rsp), %r15
   5bb0d:      	addq	0x10(%rsp), %r15
   5bb12:      	jmp	0x5bb2c <f.2+0x337c>
   5bb14:      	movl	$0x1, %eax
   5bb19:      	cmpq	$0x0, 0x19f27(%rip)     # 0x75a48 <g.3>
   5bb21:      	je	0x7085f <f.2+0x180af>
   5bb27:      	leaq	-0xd(%r12,%rax), %r15
   5bb2c:      	cmpq	$0x0, 0x19f14(%rip)     # 0x75a48 <g.3>
   5bb34:      	je	0x7085f <f.2+0x180af>
   5bb3a:      	cmpq	$0xd, %r12
   5bb3e:      	ja	0x5bb4a <f.2+0x339a>
   5bb40:      	leaq	-0xc(%r12), %rcx
   5bb45:      	jmp	0x5c244 <f.2+0x3a94>
   5bb4a:      	cmpq	$0xe, %r12
   5bb4e:      	jne	0x5bb68 <f.2+0x33b8>
   5bb50:      	movl	$0x1, %ecx
   5bb55:      	cmpq	$0x0, 0x19eeb(%rip)     # 0x75a48 <g.3>
   5bb5d:      	jne	0x5bbf9 <f.2+0x3449>
   5bb63:      	jmp	0x7085f <f.2+0x180af>
   5bb68:      	leaq	-0xe(%r12), %rsi
   5bb6d:      	movq	$0x0, 0x48(%rsp)
   5bb76:      	movq	$0x3, 0x30(%rsp)
   5bb7f:      	xorl	%edi, %edi
   5bb81:      	callq	0x70870 <f.3>
   5bb86:      	subq	$0x8, %rsp
   5bb8a:      	cmpb	$0x0, 0x19ebf(%rip)     # 0x75a50 <g.4>
   5bb91:      	je	0x7085f <f.2+0x180af>
   5bb97:      	movq	%rax, 0x10(%rsp)
   5bb9c:      	cmpq	$0x0, 0x19ea4(%rip)     # 0x75a48 <g.3>
   5bba4:      	je	0x7085f <f.2+0x180af>
   5bbaa:      	leaq	-0xf(%r12), %rsi
   5bbaf:      	movq	$0x0, 0x48(%rsp)
   5bbb8:      	movq	$0x3, 0x30(%rsp)
   5bbc1:      	xorl	%edi, %edi
   5bbc3:      	callq	0x70870 <f.3>
   5bbc8:      	subq	$0x8, %rsp
   5bbcc:      	cmpb	$0x0, 0x19e7d(%rip)     # 0x75a50 <g.4>
   5bbd3:      	je	0x7085f <f.2+0x180af>
   5bbd9:      	cmpq	$0x0, 0x19e67(%rip)     # 0x75a48 <g.3>
   5bbe1:      	je	0x7085f <f.2+0x180af>
   5bbe7:      	movq	%rax, %rcx
   5bbea:      	addq	0x10(%rsp), %rcx
   5bbef:      	cmpq	$0xf, %r12
   5bbf3:      	ja	0x5c1ce <f.2+0x3a1e>
   5bbf9:      	leaq	-0xe(%r12), %rax
   5bbfe:      	jmp	0x5c241 <f.2+0x3a91>
   5bc03:      	movq	$0x0, 0x48(%rsp)
   5bc0c:      	movq	$0x3, 0x30(%rsp)
   5bc15:      	xorl	%edi, %edi
   5bc17:      	leaq	-0xf(%r12), %rsi
   5bc1c:      	callq	0x70870 <f.3>
   5bc21:      	subq	$0x8, %rsp
   5bc25:      	cmpb	$0x0, 0x19e24(%rip)     # 0x75a50 <g.4>
   5bc2c:      	je	0x7085f <f.2+0x180af>
   5bc32:      	movq	%rax, 0x18(%rsp)
   5bc37:      	cmpq	$0x0, 0x19e09(%rip)     # 0x75a48 <g.3>
   5bc3f:      	je	0x7085f <f.2+0x180af>
   5bc45:      	leaq	-0x10(%r12), %rsi
   5bc4a:      	movq	$0x0, 0x48(%rsp)
   5bc53:      	movq	$0x3, 0x30(%rsp)
   5bc5c:      	xorl	%edi, %edi
   5bc5e:      	callq	0x70870 <f.3>
   5bc63:      	subq	$0x8, %rsp
   5bc67:      	addq	0x18(%rsp), %rax
   5bc6c:      	movq	0x10(%rsp), %rcx
   5bc71:      	addq	%rax, %r13
   5bc74:      	cmpb	$0x0, 0x19dd5(%rip)     # 0x75a50 <g.4>
   5bc7b:      	je	0x7085f <f.2+0x180af>
   5bc81:      	addq	%rcx, %r13
   5bc84:      	addq	%rbp, %r13
   5bc87:      	cmpq	$0x0, 0x19db9(%rip)     # 0x75a48 <g.3>
   5bc8f:      	je	0x7085f <f.2+0x180af>
   5bc95:      	cmpq	$0xa, %r12
   5bc99:      	ja	0x5bcb5 <f.2+0x3505>
   5bc9b:      	leaq	-0x9(%r12), %rbp
   5bca0:      	addq	%rbp, %r13
   5bca3:      	cmpb	$0x0, 0x19da6(%rip)     # 0x75a50 <g.4>
   5bcaa:      	jne	0x5ab8e <f.2+0x23de>
   5bcb0:      	jmp	0x7085f <f.2+0x180af>
   5bcb5:      	cmpq	$0xb, %r12
   5bcb9:      	jne	0x5bcd3 <f.2+0x3523>
   5bcbb:      	movl	$0x1, %ebp
   5bcc0:      	cmpq	$0x0, 0x19d80(%rip)     # 0x75a48 <g.3>
   5bcc8:      	jne	0x5bf90 <f.2+0x37e0>
   5bcce:      	jmp	0x7085f <f.2+0x180af>
   5bcd3:      	cmpq	$0xd, %r12
   5bcd7:      	jb	0x5bcf3 <f.2+0x3543>
   5bcd9:      	jne	0x5bd0b <f.2+0x355b>
   5bcdb:      	movl	$0x1, %ebp
   5bce0:      	cmpq	$0x0, 0x19d60(%rip)     # 0x75a48 <g.3>
   5bce8:      	jne	0x5bd98 <f.2+0x35e8>
   5bcee:      	jmp	0x7085f <f.2+0x180af>
   5bcf3:      	movl	$0x1, %eax
   5bcf8:      	cmpq	$0x0, 0x19d48(%rip)     # 0x75a48 <g.3>
   5bd00:      	jne	0x5be32 <f.2+0x3682>
   5bd06:      	jmp	0x7085f <f.2+0x180af>
   5bd0b:      	leaq	-0xd(%r12), %rsi
   5bd10:      	movq	$0x0, 0x48(%rsp)
   5bd19:      	movq	$0x3, 0x30(%rsp)
   5bd22:      	xorl	%edi, %edi
   5bd24:      	callq	0x70870 <f.3>
   5bd29:      	subq	$0x8, %rsp
   5bd2d:      	cmpb	$0x0, 0x19d1c(%rip)     # 0x75a50 <g.4>
   5bd34:      	je	0x7085f <f.2+0x180af>
   5bd3a:      	movq	%rax, 0x10(%rsp)
   5bd3f:      	cmpq	$0x0, 0x19d01(%rip)     # 0x75a48 <g.3>
   5bd47:      	je	0x7085f <f.2+0x180af>
   5bd4d:      	leaq	-0xe(%r12), %rsi
   5bd52:      	movq	$0x0, 0x48(%rsp)
   5bd5b:      	movq	$0x3, 0x30(%rsp)
   5bd64:      	xorl	%edi, %edi
   5bd66:      	callq	0x70870 <f.3>
   5bd6b:      	subq	$0x8, %rsp
   5bd6f:      	cmpb	$0x0, 0x19cda(%rip)     # 0x75a50 <g.4>
   5bd76:      	je	0x7085f <f.2+0x180af>
   5bd7c:      	cmpq	$0x0, 0x19cc4(%rip)     # 0x75a48 <g.3>
   5bd84:      	je	0x7085f <f.2+0x180af>
   5bd8a:      	movq	%rax, %rbp
   5bd8d:      	addq	0x10(%rsp), %rbp
   5bd92:      	cmpq	$0xe, %r12
   5bd96:      	ja	0x5bd9f <f.2+0x35ef>
   5bd98:      	leaq	-0xd(%r12,%rbp), %rax
   5bd9d:      	jmp	0x5be18 <f.2+0x3668>
   5bd9f:      	movq	$0x0, 0x48(%rsp)
   5bda8:      	movq	$0x3, 0x30(%rsp)
   5bdb1:      	xorl	%edi, %edi
   5bdb3:      	leaq	-0xe(%r12), %rsi
   5bdb8:      	callq	0x70870 <f.3>
   5bdbd:      	subq	$0x8, %rsp
   5bdc1:      	cmpb	$0x0, 0x19c88(%rip)     # 0x75a50 <g.4>
   5bdc8:      	je	0x7085f <f.2+0x180af>
   5bdce:      	movq	%rax, 0x10(%rsp)
   5bdd3:      	cmpq	$0x0, 0x19c6d(%rip)     # 0x75a48 <g.3>
   5bddb:      	je	0x7085f <f.2+0x180af>
   5bde1:      	leaq	-0xf(%r12), %rsi
   5bde6:      	movq	$0x0, 0x48(%rsp)
   5bdef:      	movq	$0x3, 0x30(%rsp)
   5bdf8:      	xorl	%edi, %edi
   5bdfa:      	callq	0x70870 <f.3>
   5bdff:      	subq	$0x8, %rsp
   5be03:      	cmpb	$0x0, 0x19c46(%rip)     # 0x75a50 <g.4>
   5be0a:      	je	0x7085f <f.2+0x180af>
   5be10:      	addq	0x10(%rsp), %rax
   5be15:      	addq	%rbp, %rax
   5be18:      	cmpq	$0x0, 0x19c28(%rip)     # 0x75a48 <g.3>
   5be20:      	je	0x7085f <f.2+0x180af>
   5be26:      	cmpq	$0xe, %r12
   5be2a:      	je	0x5be3c <f.2+0x368c>
   5be2c:      	cmpq	$0xd, %r12
   5be30:      	jne	0x5be54 <f.2+0x36a4>
   5be32:      	leaq	-0xc(%r12,%rax), %rbp
   5be37:      	jmp	0x5bf7c <f.2+0x37cc>
   5be3c:      	movl	$0x1, %ecx
   5be41:      	cmpq	$0x0, 0x19bff(%rip)     # 0x75a48 <g.3>
   5be49:      	jne	0x5bee7 <f.2+0x3737>
   5be4f:      	jmp	0x7085f <f.2+0x180af>
   5be54:      	movq	%rax, 0x10(%rsp)
   5be59:      	leaq	-0xe(%r12), %rsi
   5be5e:      	movq	$0x0, 0x48(%rsp)
   5be67:      	movq	$0x3, 0x30(%rsp)
   5be70:      	xorl	%edi, %edi
   5be72:      	callq	0x70870 <f.3>
   5be77:      	subq	$0x8, %rsp
   5be7b:      	cmpb	$0x0, 0x19bce(%rip)     # 0x75a50 <g.4>
   5be82:      	je	0x7085f <f.2+0x180af>
   5be88:      	cmpq	$0x0, 0x19bb8(%rip)     # 0x75a48 <g.3>
   5be90:      	je	0x7085f <f.2+0x180af>
   5be96:      	movq	%rax, %rbp
   5be99:      	leaq	-0xf(%r12), %rsi
   5be9e:      	movq	$0x0, 0x48(%rsp)
   5bea7:      	movq	$0x3, 0x30(%rsp)
   5beb0:      	xorl	%edi, %edi
   5beb2:      	callq	0x70870 <f.3>
   5beb7:      	subq	$0x8, %rsp
   5bebb:      	cmpb	$0x0, 0x19b8e(%rip)     # 0x75a50 <g.4>
   5bec2:      	je	0x7085f <f.2+0x180af>
   5bec8:      	movq	%rax, %rcx
   5becb:      	cmpq	$0x0, 0x19b75(%rip)     # 0x75a48 <g.3>
   5bed3:      	movq	0x10(%rsp), %rax
   5bed8:      	je	0x7085f <f.2+0x180af>
   5bede:      	addq	%rbp, %rcx
   5bee1:      	cmpq	$0xf, %r12
   5bee5:      	ja	0x5beee <f.2+0x373e>
   5bee7:      	leaq	-0xe(%r12), %rbp
   5beec:      	jmp	0x5bf69 <f.2+0x37b9>
   5beee:      	movq	%rcx, 0x18(%rsp)
   5bef3:      	movq	$0x0, 0x48(%rsp)
   5befc:      	movq	$0x3, 0x30(%rsp)
   5bf05:      	xorl	%edi, %edi
   5bf07:      	leaq	-0xf(%r12), %rsi
   5bf0c:      	callq	0x70870 <f.3>
   5bf11:      	subq	$0x8, %rsp
   5bf15:      	cmpb	$0x0, 0x19b34(%rip)     # 0x75a50 <g.4>
   5bf1c:      	je	0x7085f <f.2+0x180af>
   5bf22:      	movq	%rax, 0x50(%rsp)
   5bf27:      	cmpq	$0x0, 0x19b19(%rip)     # 0x75a48 <g.3>
   5bf2f:      	je	0x7085f <f.2+0x180af>
   5bf35:      	leaq	-0x10(%r12), %rsi
   5bf3a:      	movq	$0x0, 0x48(%rsp)
   5bf43:      	movq	$0x3, 0x30(%rsp)
   5bf4c:      	xorl	%edi, %edi
   5bf4e:      	callq	0x70870 <f.3>
   5bf53:      	subq	$0x8, %rsp
   5bf57:      	movq	%rax, %rbp
   5bf5a:      	addq	0x50(%rsp), %rbp
   5bf5f:      	movq	0x10(%rsp), %rax
   5bf64:      	movq	0x18(%rsp), %rcx
   5bf69:      	cmpb	$0x0, 0x19ae0(%rip)     # 0x75a50 <g.4>
   5bf70:      	je	0x7085f <f.2+0x180af>
   5bf76:      	addq	%rcx, %rbp
   5bf79:      	addq	%rax, %rbp
   5bf7c:      	cmpq	$0x0, 0x19ac4(%rip)     # 0x75a48 <g.3>
   5bf84:      	je	0x7085f <f.2+0x180af>
   5bf8a:      	cmpq	$0xc, %r12
   5bf8e:      	ja	0x5bf9a <f.2+0x37ea>
   5bf90:      	leaq	-0xb(%r12), %rcx
   5bf95:      	jmp	0x5cdf1 <f.2+0x4641>
   5bf9a:      	cmpq	$0xd, %r12
   5bf9e:      	jne	0x5bfb8 <f.2+0x3808>
   5bfa0:      	movl	$0x1, %ecx
   5bfa5:      	cmpq	$0x0, 0x19a9b(%rip)     # 0x75a48 <g.3>
   5bfad:      	jne	0x5c101 <f.2+0x3951>
   5bfb3:      	jmp	0x7085f <f.2+0x180af>
   5bfb8:      	cmpq	$0xf, %r12
   5bfbc:      	jb	0x5c0d5 <f.2+0x3925>
   5bfc2:      	leaq	-0xe(%r12), %rsi
   5bfc7:      	movq	$0x0, 0x48(%rsp)
   5bfd0:      	movq	$0x3, 0x30(%rsp)
   5bfd9:      	xorl	%edi, %edi
   5bfdb:      	callq	0x70870 <f.3>
   5bfe0:      	subq	$0x8, %rsp
   5bfe4:      	cmpb	$0x0, 0x19a65(%rip)     # 0x75a50 <g.4>
   5bfeb:      	je	0x7085f <f.2+0x180af>
   5bff1:      	movq	%rax, 0x10(%rsp)
   5bff6:      	cmpq	$0x0, 0x19a4a(%rip)     # 0x75a48 <g.3>
   5bffe:      	je	0x7085f <f.2+0x180af>
   5c004:      	leaq	-0xf(%r12), %rsi
   5c009:      	movq	$0x0, 0x48(%rsp)
   5c012:      	movq	$0x3, 0x30(%rsp)
   5c01b:      	xorl	%edi, %edi
   5c01d:      	callq	0x70870 <f.3>
   5c022:      	subq	$0x8, %rsp
   5c026:      	cmpb	$0x0, 0x19a23(%rip)     # 0x75a50 <g.4>
   5c02d:      	je	0x7085f <f.2+0x180af>
   5c033:      	cmpq	$0x0, 0x19a0d(%rip)     # 0x75a48 <g.3>
   5c03b:      	je	0x7085f <f.2+0x180af>
   5c041:      	addq	0x10(%rsp), %rax
   5c046:      	cmpq	$0xf, %r12
   5c04a:      	je	0x5c0e8 <f.2+0x3938>
   5c050:      	movq	%rax, 0x10(%rsp)
   5c055:      	movq	$0x0, 0x48(%rsp)
   5c05e:      	movq	$0x3, 0x30(%rsp)
   5c067:      	xorl	%edi, %edi
   5c069:      	leaq	-0xf(%r12), %rsi
   5c06e:      	callq	0x70870 <f.3>
   5c073:      	subq	$0x8, %rsp
   5c077:      	cmpb	$0x0, 0x199d2(%rip)     # 0x75a50 <g.4>
   5c07e:      	je	0x7085f <f.2+0x180af>
   5c084:      	movq	%rax, 0x18(%rsp)
   5c089:      	cmpq	$0x0, 0x199b7(%rip)     # 0x75a48 <g.3>
   5c091:      	je	0x7085f <f.2+0x180af>
   5c097:      	leaq	-0x10(%r12), %rsi
   5c09c:      	movq	$0x0, 0x48(%rsp)
   5c0a5:      	movq	$0x3, 0x30(%rsp)
   5c0ae:      	xorl	%edi, %edi
   5c0b0:      	callq	0x70870 <f.3>
   5c0b5:      	subq	$0x8, %rsp
   5c0b9:      	cmpb	$0x0, 0x19990(%rip)     # 0x75a50 <g.4>
   5c0c0:      	je	0x7085f <f.2+0x180af>
   5c0c6:      	movq	%rax, %rcx
   5c0c9:      	addq	0x18(%rsp), %rcx
   5c0ce:      	addq	0x10(%rsp), %rcx
   5c0d3:      	jmp	0x5c0ed <f.2+0x393d>
   5c0d5:      	movl	$0x1, %eax
   5c0da:      	cmpq	$0x0, 0x19966(%rip)     # 0x75a48 <g.3>
   5c0e2:      	je	0x7085f <f.2+0x180af>
   5c0e8:      	leaq	-0xe(%r12,%rax), %rcx
   5c0ed:      	cmpq	$0x0, 0x19953(%rip)     # 0x75a48 <g.3>
   5c0f5:      	je	0x7085f <f.2+0x180af>
   5c0fb:      	cmpq	$0xe, %r12
   5c0ff:      	ja	0x5c10b <f.2+0x395b>
   5c101:      	leaq	-0xd(%r12), %rdx
   5c106:      	jmp	0x5cdee <f.2+0x463e>
   5c10b:      	cmpq	$0xf, %r12
   5c10f:      	jne	0x5c129 <f.2+0x3979>
   5c111:      	movl	$0x1, %edx
   5c116:      	cmpq	$0x0, 0x1992a(%rip)     # 0x75a48 <g.3>
   5c11e:      	jne	0x5c1c4 <f.2+0x3a14>
   5c124:      	jmp	0x7085f <f.2+0x180af>
   5c129:      	movq	%rcx, 0x10(%rsp)
   5c12e:      	leaq	-0xf(%r12), %rsi
   5c133:      	movq	$0x0, 0x48(%rsp)
   5c13c:      	movq	$0x3, 0x30(%rsp)
   5c145:      	xorl	%edi, %edi
   5c147:      	callq	0x70870 <f.3>
   5c14c:      	subq	$0x8, %rsp
   5c150:      	cmpb	$0x0, 0x198f9(%rip)     # 0x75a50 <g.4>
   5c157:      	je	0x7085f <f.2+0x180af>
   5c15d:      	movq	%rax, 0x18(%rsp)
   5c162:      	cmpq	$0x0, 0x198de(%rip)     # 0x75a48 <g.3>
   5c16a:      	je	0x7085f <f.2+0x180af>
   5c170:      	leaq	-0x10(%r12), %rsi
   5c175:      	movq	$0x0, 0x48(%rsp)
   5c17e:      	movq	$0x3, 0x30(%rsp)
   5c187:      	xorl	%edi, %edi
   5c189:      	callq	0x70870 <f.3>
   5c18e:      	subq	$0x8, %rsp
   5c192:      	cmpb	$0x0, 0x198b7(%rip)     # 0x75a50 <g.4>
   5c199:      	je	0x7085f <f.2+0x180af>
   5c19f:      	cmpq	$0x0, 0x198a1(%rip)     # 0x75a48 <g.3>
   5c1a7:      	movq	0x10(%rsp), %rcx
   5c1ac:      	je	0x7085f <f.2+0x180af>
   5c1b2:      	movq	%rax, %rdx
   5c1b5:      	addq	0x18(%rsp), %rdx
   5c1ba:      	cmpq	$0x10, %r12
   5c1be:      	ja	0x5cd73 <f.2+0x45c3>
   5c1c4:      	leaq	-0xf(%r12), %rax
   5c1c9:      	jmp	0x5cdeb <f.2+0x463b>
   5c1ce:      	movq	%rcx, 0x10(%rsp)
   5c1d3:      	movq	$0x0, 0x48(%rsp)
   5c1dc:      	movq	$0x3, 0x30(%rsp)
   5c1e5:      	xorl	%edi, %edi
   5c1e7:      	leaq	-0xf(%r12), %rsi
   5c1ec:      	callq	0x70870 <f.3>
   5c1f1:      	subq	$0x8, %rsp
   5c1f5:      	cmpb	$0x0, 0x19854(%rip)     # 0x75a50 <g.4>
   5c1fc:      	je	0x7085f <f.2+0x180af>
   5c202:      	movq	%rax, 0x18(%rsp)
   5c207:      	cmpq	$0x0, 0x19839(%rip)     # 0x75a48 <g.3>
   5c20f:      	je	0x7085f <f.2+0x180af>
   5c215:      	leaq	-0x10(%r12), %rsi
   5c21a:      	movq	$0x0, 0x48(%rsp)
   5c223:      	movq	$0x3, 0x30(%rsp)
   5c22c:      	xorl	%edi, %edi
   5c22e:      	callq	0x70870 <f.3>
   5c233:      	subq	$0x8, %rsp
   5c237:      	addq	0x18(%rsp), %rax
   5c23c:      	movq	0x10(%rsp), %rcx
   5c241:      	addq	%rax, %rcx
   5c244:      	addq	%rcx, %r15
   5c247:      	cmpb	$0x0, 0x19802(%rip)     # 0x75a50 <g.4>
   5c24e:      	je	0x7085f <f.2+0x180af>
   5c254:      	addq	%rbp, %r15
   5c257:      	addq	%r14, %r15
   5c25a:      	cmpq	$0x0, 0x197e6(%rip)     # 0x75a48 <g.3>
   5c262:      	je	0x7085f <f.2+0x180af>
   5c268:      	cmpq	$0x9, %r12
   5c26c:      	je	0x5c291 <f.2+0x3ae1>
   5c26e:      	cmpq	$0x8, %r12
   5c272:      	jne	0x5c2a9 <f.2+0x3af9>
   5c274:      	leaq	-0x7(%r12,%r15), %r14
   5c279:      	cmpq	$0x0, 0x197c7(%rip)     # 0x75a48 <g.3>
   5c281:      	leaq	0x68(%rsp), %r15
   5c286:      	jne	0x5ceb0 <f.2+0x4700>
   5c28c:      	jmp	0x7085f <f.2+0x180af>
   5c291:      	movl	$0x1, %ebp
   5c296:      	cmpq	$0x0, 0x197aa(%rip)     # 0x75a48 <g.3>
   5c29e:      	jne	0x5c841 <f.2+0x4091>
   5c2a4:      	jmp	0x7085f <f.2+0x180af>
   5c2a9:      	cmpq	$0xb, %r12
   5c2ad:      	jb	0x5c2c9 <f.2+0x3b19>
   5c2af:      	jne	0x5c2e2 <f.2+0x3b32>
   5c2b1:      	movl	$0x1, %ebp
   5c2b6:      	cmpq	$0x0, 0x1978a(%rip)     # 0x75a48 <g.3>
   5c2be:      	jne	0x5c424 <f.2+0x3c74>
   5c2c4:      	jmp	0x7085f <f.2+0x180af>
   5c2c9:      	movl	$0x1, %r14d
   5c2cf:      	cmpq	$0x0, 0x19771(%rip)     # 0x75a48 <g.3>
   5c2d7:      	jne	0x5c57c <f.2+0x3dcc>
   5c2dd:      	jmp	0x7085f <f.2+0x180af>
   5c2e2:      	cmpq	$0xd, %r12
   5c2e6:      	jb	0x5c3f7 <f.2+0x3c47>
   5c2ec:      	leaq	-0xc(%r12), %rsi
   5c2f1:      	movq	$0x0, 0x48(%rsp)
   5c2fa:      	movq	$0x3, 0x30(%rsp)
   5c303:      	xorl	%edi, %edi
   5c305:      	callq	0x70870 <f.3>
   5c30a:      	subq	$0x8, %rsp
   5c30e:      	cmpb	$0x0, 0x1973b(%rip)     # 0x75a50 <g.4>
   5c315:      	je	0x7085f <f.2+0x180af>
   5c31b:      	cmpq	$0x0, 0x19725(%rip)     # 0x75a48 <g.3>
   5c323:      	je	0x7085f <f.2+0x180af>
   5c329:      	movq	%rax, %rbp
   5c32c:      	leaq	-0xd(%r12), %rsi
   5c331:      	movq	$0x0, 0x48(%rsp)
   5c33a:      	movq	$0x3, 0x30(%rsp)
   5c343:      	xorl	%edi, %edi
   5c345:      	callq	0x70870 <f.3>
   5c34a:      	subq	$0x8, %rsp
   5c34e:      	cmpb	$0x0, 0x196fb(%rip)     # 0x75a50 <g.4>
   5c355:      	je	0x7085f <f.2+0x180af>
   5c35b:      	cmpq	$0x0, 0x196e5(%rip)     # 0x75a48 <g.3>
   5c363:      	je	0x7085f <f.2+0x180af>
   5c369:      	movq	%rax, %r14
   5c36c:      	addq	%rbp, %r14
   5c36f:      	cmpq	$0xd, %r12
   5c373:      	je	0x5c40b <f.2+0x3c5b>
   5c379:      	movq	$0x0, 0x48(%rsp)
   5c382:      	movq	$0x3, 0x30(%rsp)
   5c38b:      	xorl	%edi, %edi
   5c38d:      	leaq	-0xd(%r12), %rsi
   5c392:      	callq	0x70870 <f.3>
   5c397:      	subq	$0x8, %rsp
   5c39b:      	cmpb	$0x0, 0x196ae(%rip)     # 0x75a50 <g.4>
   5c3a2:      	je	0x7085f <f.2+0x180af>
   5c3a8:      	movq	%rax, 0x10(%rsp)
   5c3ad:      	cmpq	$0x0, 0x19693(%rip)     # 0x75a48 <g.3>
   5c3b5:      	je	0x7085f <f.2+0x180af>
   5c3bb:      	leaq	-0xe(%r12), %rsi
   5c3c0:      	movq	$0x0, 0x48(%rsp)
   5c3c9:      	movq	$0x3, 0x30(%rsp)
   5c3d2:      	xorl	%edi, %edi
   5c3d4:      	callq	0x70870 <f.3>
   5c3d9:      	subq	$0x8, %rsp
   5c3dd:      	cmpb	$0x0, 0x1966c(%rip)     # 0x75a50 <g.4>
   5c3e4:      	je	0x7085f <f.2+0x180af>
   5c3ea:      	movq	%rax, %rbp
   5c3ed:      	addq	0x10(%rsp), %rbp
   5c3f2:      	addq	%r14, %rbp
   5c3f5:      	jmp	0x5c410 <f.2+0x3c60>
   5c3f7:      	movl	$0x1, %r14d
   5c3fd:      	cmpq	$0x0, 0x19643(%rip)     # 0x75a48 <g.3>
   5c405:      	je	0x7085f <f.2+0x180af>
   5c40b:      	leaq	-0xc(%r12,%r14), %rbp
   5c410:      	cmpq	$0x0, 0x19630(%rip)     # 0x75a48 <g.3>
   5c418:      	je	0x7085f <f.2+0x180af>
   5c41e:      	cmpq	$0xc, %r12
   5c422:      	ja	0x5c42e <f.2+0x3c7e>
   5c424:      	leaq	-0xb(%r12,%rbp), %r14
   5c429:      	jmp	0x5c562 <f.2+0x3db2>
   5c42e:      	cmpq	$0xd, %r12
   5c432:      	jne	0x5c44c <f.2+0x3c9c>
   5c434:      	movl	$0x1, %eax
   5c439:      	cmpq	$0x0, 0x19607(%rip)     # 0x75a48 <g.3>
   5c441:      	jne	0x5c4d2 <f.2+0x3d22>
   5c447:      	jmp	0x7085f <f.2+0x180af>
   5c44c:      	leaq	-0xd(%r12), %rsi
   5c451:      	movq	$0x0, 0x48(%rsp)
   5c45a:      	movq	$0x3, 0x30(%rsp)
   5c463:      	xorl	%edi, %edi
   5c465:      	callq	0x70870 <f.3>
   5c46a:      	subq	$0x8, %rsp
   5c46e:      	cmpb	$0x0, 0x195db(%rip)     # 0x75a50 <g.4>
   5c475:      	je	0x7085f <f.2+0x180af>
   5c47b:      	cmpq	$0x0, 0x195c5(%rip)     # 0x75a48 <g.3>
   5c483:      	je	0x7085f <f.2+0x180af>
   5c489:      	movq	%rax, %r14
   5c48c:      	leaq	-0xe(%r12), %rsi
   5c491:      	movq	$0x0, 0x48(%rsp)
   5c49a:      	movq	$0x3, 0x30(%rsp)
   5c4a3:      	xorl	%edi, %edi
   5c4a5:      	callq	0x70870 <f.3>
   5c4aa:      	subq	$0x8, %rsp
   5c4ae:      	cmpb	$0x0, 0x1959b(%rip)     # 0x75a50 <g.4>
   5c4b5:      	je	0x7085f <f.2+0x180af>
   5c4bb:      	cmpq	$0x0, 0x19585(%rip)     # 0x75a48 <g.3>
   5c4c3:      	je	0x7085f <f.2+0x180af>
   5c4c9:      	addq	%r14, %rax
   5c4cc:      	cmpq	$0xe, %r12
   5c4d0:      	ja	0x5c4d9 <f.2+0x3d29>
   5c4d2:      	leaq	-0xd(%r12), %r14
   5c4d7:      	jmp	0x5c54f <f.2+0x3d9f>
   5c4d9:      	movq	%rax, 0x10(%rsp)
   5c4de:      	movq	$0x0, 0x48(%rsp)
   5c4e7:      	movq	$0x3, 0x30(%rsp)
   5c4f0:      	xorl	%edi, %edi
   5c4f2:      	leaq	-0xe(%r12), %rsi
   5c4f7:      	callq	0x70870 <f.3>
   5c4fc:      	subq	$0x8, %rsp
   5c500:      	cmpb	$0x0, 0x19549(%rip)     # 0x75a50 <g.4>
   5c507:      	je	0x7085f <f.2+0x180af>
   5c50d:      	movq	%rax, 0x18(%rsp)
   5c512:      	cmpq	$0x0, 0x1952e(%rip)     # 0x75a48 <g.3>
   5c51a:      	je	0x7085f <f.2+0x180af>
   5c520:      	leaq	-0xf(%r12), %rsi
   5c525:      	movq	$0x0, 0x48(%rsp)
   5c52e:      	movq	$0x3, 0x30(%rsp)
   5c537:      	xorl	%edi, %edi
   5c539:      	callq	0x70870 <f.3>
   5c53e:      	subq	$0x8, %rsp
   5c542:      	movq	%rax, %r14
   5c545:      	addq	0x18(%rsp), %r14
   5c54a:      	movq	0x10(%rsp), %rax
   5c54f:      	cmpb	$0x0, 0x194fa(%rip)     # 0x75a50 <g.4>
   5c556:      	je	0x7085f <f.2+0x180af>
   5c55c:      	addq	%rax, %r14
   5c55f:      	addq	%rbp, %r14
   5c562:      	cmpq	$0x0, 0x194de(%rip)     # 0x75a48 <g.3>
   5c56a:      	je	0x7085f <f.2+0x180af>
   5c570:      	cmpq	$0xc, %r12
   5c574:      	je	0x5c586 <f.2+0x3dd6>
   5c576:      	cmpq	$0xb, %r12
   5c57a:      	jne	0x5c59e <f.2+0x3dee>
   5c57c:      	leaq	-0xa(%r12,%r14), %rbp
   5c581:      	jmp	0x5c82d <f.2+0x407d>
   5c586:      	movl	$0x1, %ecx
   5c58b:      	cmpq	$0x0, 0x194b5(%rip)     # 0x75a48 <g.3>
   5c593:      	jne	0x5c6e3 <f.2+0x3f33>
   5c599:      	jmp	0x7085f <f.2+0x180af>
   5c59e:      	cmpq	$0xe, %r12
   5c5a2:      	jb	0x5c6b7 <f.2+0x3f07>
   5c5a8:      	leaq	-0xd(%r12), %rsi
   5c5ad:      	movq	$0x0, 0x48(%rsp)
   5c5b6:      	movq	$0x3, 0x30(%rsp)
   5c5bf:      	xorl	%edi, %edi
   5c5c1:      	callq	0x70870 <f.3>
   5c5c6:      	subq	$0x8, %rsp
   5c5ca:      	cmpb	$0x0, 0x1947f(%rip)     # 0x75a50 <g.4>
   5c5d1:      	je	0x7085f <f.2+0x180af>
   5c5d7:      	movq	%rax, 0x10(%rsp)
   5c5dc:      	cmpq	$0x0, 0x19464(%rip)     # 0x75a48 <g.3>
   5c5e4:      	je	0x7085f <f.2+0x180af>
   5c5ea:      	leaq	-0xe(%r12), %rsi
   5c5ef:      	movq	$0x0, 0x48(%rsp)
   5c5f8:      	movq	$0x3, 0x30(%rsp)
   5c601:      	xorl	%edi, %edi
   5c603:      	callq	0x70870 <f.3>
   5c608:      	subq	$0x8, %rsp
   5c60c:      	cmpb	$0x0, 0x1943d(%rip)     # 0x75a50 <g.4>
   5c613:      	je	0x7085f <f.2+0x180af>
   5c619:      	cmpq	$0x0, 0x19427(%rip)     # 0x75a48 <g.3>
   5c621:      	je	0x7085f <f.2+0x180af>
   5c627:      	movq	%rax, %rbp
   5c62a:      	addq	0x10(%rsp), %rbp
   5c62f:      	cmpq	$0xe, %r12
   5c633:      	je	0x5c6ca <f.2+0x3f1a>
   5c639:      	movq	$0x0, 0x48(%rsp)
   5c642:      	movq	$0x3, 0x30(%rsp)
   5c64b:      	xorl	%edi, %edi
   5c64d:      	leaq	-0xe(%r12), %rsi
   5c652:      	callq	0x70870 <f.3>
   5c657:      	subq	$0x8, %rsp
   5c65b:      	cmpb	$0x0, 0x193ee(%rip)     # 0x75a50 <g.4>
   5c662:      	je	0x7085f <f.2+0x180af>
   5c668:      	movq	%rax, 0x10(%rsp)
   5c66d:      	cmpq	$0x0, 0x193d3(%rip)     # 0x75a48 <g.3>
   5c675:      	je	0x7085f <f.2+0x180af>
   5c67b:      	leaq	-0xf(%r12), %rsi
   5c680:      	movq	$0x0, 0x48(%rsp)
   5c689:      	movq	$0x3, 0x30(%rsp)
   5c692:      	xorl	%edi, %edi
   5c694:      	callq	0x70870 <f.3>
   5c699:      	subq	$0x8, %rsp
   5c69d:      	cmpb	$0x0, 0x193ac(%rip)     # 0x75a50 <g.4>
   5c6a4:      	je	0x7085f <f.2+0x180af>
   5c6aa:      	movq	%rax, %rcx
   5c6ad:      	addq	0x10(%rsp), %rcx
   5c6b2:      	addq	%rbp, %rcx
   5c6b5:      	jmp	0x5c6cf <f.2+0x3f1f>
   5c6b7:      	movl	$0x1, %ebp
   5c6bc:      	cmpq	$0x0, 0x19384(%rip)     # 0x75a48 <g.3>
   5c6c4:      	je	0x7085f <f.2+0x180af>
   5c6ca:      	leaq	-0xd(%r12,%rbp), %rcx
   5c6cf:      	cmpq	$0x0, 0x19371(%rip)     # 0x75a48 <g.3>
   5c6d7:      	je	0x7085f <f.2+0x180af>
   5c6dd:      	cmpq	$0xd, %r12
   5c6e1:      	ja	0x5c6ed <f.2+0x3f3d>
   5c6e3:      	leaq	-0xc(%r12), %rbp
   5c6e8:      	jmp	0x5c81a <f.2+0x406a>
   5c6ed:      	cmpq	$0xe, %r12
   5c6f1:      	jne	0x5c70b <f.2+0x3f5b>
   5c6f3:      	movl	$0x1, %ebp
   5c6f8:      	cmpq	$0x0, 0x19348(%rip)     # 0x75a48 <g.3>
   5c700:      	jne	0x5c7a2 <f.2+0x3ff2>
   5c706:      	jmp	0x7085f <f.2+0x180af>
   5c70b:      	movq	%rcx, 0x10(%rsp)
   5c710:      	leaq	-0xe(%r12), %rsi
   5c715:      	movq	$0x0, 0x48(%rsp)
   5c71e:      	movq	$0x3, 0x30(%rsp)
   5c727:      	xorl	%edi, %edi
   5c729:      	callq	0x70870 <f.3>
   5c72e:      	subq	$0x8, %rsp
   5c732:      	cmpb	$0x0, 0x19317(%rip)     # 0x75a50 <g.4>
   5c739:      	je	0x7085f <f.2+0x180af>
   5c73f:      	movq	%rax, 0x18(%rsp)
   5c744:      	cmpq	$0x0, 0x192fc(%rip)     # 0x75a48 <g.3>
   5c74c:      	je	0x7085f <f.2+0x180af>
   5c752:      	leaq	-0xf(%r12), %rsi
   5c757:      	movq	$0x0, 0x48(%rsp)
   5c760:      	movq	$0x3, 0x30(%rsp)
   5c769:      	xorl	%edi, %edi
   5c76b:      	callq	0x70870 <f.3>
   5c770:      	subq	$0x8, %rsp
   5c774:      	cmpb	$0x0, 0x192d5(%rip)     # 0x75a50 <g.4>
   5c77b:      	je	0x7085f <f.2+0x180af>
   5c781:      	cmpq	$0x0, 0x192bf(%rip)     # 0x75a48 <g.3>
   5c789:      	movq	0x10(%rsp), %rcx
   5c78e:      	je	0x7085f <f.2+0x180af>
   5c794:      	movq	%rax, %rbp
   5c797:      	addq	0x18(%rsp), %rbp
   5c79c:      	cmpq	$0xf, %r12
   5c7a0:      	ja	0x5c7a9 <f.2+0x3ff9>
   5c7a2:      	leaq	-0xe(%r12), %rax
   5c7a7:      	jmp	0x5c817 <f.2+0x4067>
   5c7a9:      	movq	$0x0, 0x48(%rsp)
   5c7b2:      	movq	$0x3, 0x30(%rsp)
   5c7bb:      	xorl	%edi, %edi
   5c7bd:      	leaq	-0xf(%r12), %rsi
   5c7c2:      	callq	0x70870 <f.3>
   5c7c7:      	subq	$0x8, %rsp
   5c7cb:      	cmpb	$0x0, 0x1927e(%rip)     # 0x75a50 <g.4>
   5c7d2:      	je	0x7085f <f.2+0x180af>
   5c7d8:      	movq	%rax, 0x18(%rsp)
   5c7dd:      	cmpq	$0x0, 0x19263(%rip)     # 0x75a48 <g.3>
   5c7e5:      	je	0x7085f <f.2+0x180af>
   5c7eb:      	leaq	-0x10(%r12), %rsi
   5c7f0:      	movq	$0x0, 0x48(%rsp)
   5c7f9:      	movq	$0x3, 0x30(%rsp)
   5c802:      	xorl	%edi, %edi
   5c804:      	callq	0x70870 <f.3>
   5c809:      	subq	$0x8, %rsp
   5c80d:      	addq	0x18(%rsp), %rax
   5c812:      	movq	0x10(%rsp), %rcx
   5c817:      	addq	%rax, %rbp
   5c81a:      	cmpb	$0x0, 0x1922f(%rip)     # 0x75a50 <g.4>
   5c821:      	je	0x7085f <f.2+0x180af>
   5c827:      	addq	%rcx, %rbp
   5c82a:      	addq	%r14, %rbp
   5c82d:      	cmpq	$0x0, 0x19213(%rip)     # 0x75a48 <g.3>
   5c835:      	je	0x7085f <f.2+0x180af>
   5c83b:      	cmpq	$0xa, %r12
   5c83f:      	ja	0x5c858 <f.2+0x40a8>
   5c841:      	leaq	-0x9(%r12), %r14
   5c846:      	cmpb	$0x0, 0x19203(%rip)     # 0x75a50 <g.4>
   5c84d:      	jne	0x5ce97 <f.2+0x46e7>
   5c853:      	jmp	0x7085f <f.2+0x180af>
   5c858:      	cmpq	$0xb, %r12
   5c85c:      	jne	0x5c877 <f.2+0x40c7>
   5c85e:      	movl	$0x1, %r14d
   5c864:      	cmpq	$0x0, 0x191dc(%rip)     # 0x75a48 <g.3>
   5c86c:      	jne	0x5cb35 <f.2+0x4385>
   5c872:      	jmp	0x7085f <f.2+0x180af>
   5c877:      	cmpq	$0xd, %r12
   5c87b:      	jb	0x5c898 <f.2+0x40e8>
   5c87d:      	jne	0x5c8b0 <f.2+0x4100>
   5c87f:      	movl	$0x1, %r14d
   5c885:      	cmpq	$0x0, 0x191bb(%rip)     # 0x75a48 <g.3>
   5c88d:      	jne	0x5c93d <f.2+0x418d>
   5c893:      	jmp	0x7085f <f.2+0x180af>
   5c898:      	movl	$0x1, %eax
   5c89d:      	cmpq	$0x0, 0x191a3(%rip)     # 0x75a48 <g.3>
   5c8a5:      	jne	0x5c9d7 <f.2+0x4227>
   5c8ab:      	jmp	0x7085f <f.2+0x180af>
   5c8b0:      	leaq	-0xd(%r12), %rsi
   5c8b5:      	movq	$0x0, 0x48(%rsp)
   5c8be:      	movq	$0x3, 0x30(%rsp)
   5c8c7:      	xorl	%edi, %edi
   5c8c9:      	callq	0x70870 <f.3>
   5c8ce:      	subq	$0x8, %rsp
   5c8d2:      	cmpb	$0x0, 0x19177(%rip)     # 0x75a50 <g.4>
   5c8d9:      	je	0x7085f <f.2+0x180af>
   5c8df:      	movq	%rax, 0x10(%rsp)
   5c8e4:      	cmpq	$0x0, 0x1915c(%rip)     # 0x75a48 <g.3>
   5c8ec:      	je	0x7085f <f.2+0x180af>
   5c8f2:      	leaq	-0xe(%r12), %rsi
   5c8f7:      	movq	$0x0, 0x48(%rsp)
   5c900:      	movq	$0x3, 0x30(%rsp)
   5c909:      	xorl	%edi, %edi
   5c90b:      	callq	0x70870 <f.3>
   5c910:      	subq	$0x8, %rsp
   5c914:      	cmpb	$0x0, 0x19135(%rip)     # 0x75a50 <g.4>
   5c91b:      	je	0x7085f <f.2+0x180af>
   5c921:      	cmpq	$0x0, 0x1911f(%rip)     # 0x75a48 <g.3>
   5c929:      	je	0x7085f <f.2+0x180af>
   5c92f:      	movq	%rax, %r14
   5c932:      	addq	0x10(%rsp), %r14
   5c937:      	cmpq	$0xe, %r12
   5c93b:      	ja	0x5c944 <f.2+0x4194>
   5c93d:      	leaq	-0xd(%r12,%r14), %rax
   5c942:      	jmp	0x5c9bd <f.2+0x420d>
   5c944:      	movq	$0x0, 0x48(%rsp)
   5c94d:      	movq	$0x3, 0x30(%rsp)
   5c956:      	xorl	%edi, %edi
   5c958:      	leaq	-0xe(%r12), %rsi
   5c95d:      	callq	0x70870 <f.3>
   5c962:      	subq	$0x8, %rsp
   5c966:      	cmpb	$0x0, 0x190e3(%rip)     # 0x75a50 <g.4>
   5c96d:      	je	0x7085f <f.2+0x180af>
   5c973:      	movq	%rax, 0x10(%rsp)
   5c978:      	cmpq	$0x0, 0x190c8(%rip)     # 0x75a48 <g.3>
   5c980:      	je	0x7085f <f.2+0x180af>
   5c986:      	leaq	-0xf(%r12), %rsi
   5c98b:      	movq	$0x0, 0x48(%rsp)
   5c994:      	movq	$0x3, 0x30(%rsp)
   5c99d:      	xorl	%edi, %edi
   5c99f:      	callq	0x70870 <f.3>
   5c9a4:      	subq	$0x8, %rsp
   5c9a8:      	cmpb	$0x0, 0x190a1(%rip)     # 0x75a50 <g.4>
   5c9af:      	je	0x7085f <f.2+0x180af>
   5c9b5:      	addq	0x10(%rsp), %rax
   5c9ba:      	addq	%r14, %rax
   5c9bd:      	cmpq	$0x0, 0x19083(%rip)     # 0x75a48 <g.3>
   5c9c5:      	je	0x7085f <f.2+0x180af>
   5c9cb:      	cmpq	$0xe, %r12
   5c9cf:      	je	0x5c9e1 <f.2+0x4231>
   5c9d1:      	cmpq	$0xd, %r12
   5c9d5:      	jne	0x5c9f9 <f.2+0x4249>
   5c9d7:      	leaq	-0xc(%r12,%rax), %r14
   5c9dc:      	jmp	0x5cb21 <f.2+0x4371>
   5c9e1:      	movl	$0x1, %ecx
   5c9e6:      	cmpq	$0x0, 0x1905a(%rip)     # 0x75a48 <g.3>
   5c9ee:      	jne	0x5ca8c <f.2+0x42dc>
   5c9f4:      	jmp	0x7085f <f.2+0x180af>
   5c9f9:      	movq	%rax, 0x10(%rsp)
   5c9fe:      	leaq	-0xe(%r12), %rsi
   5ca03:      	movq	$0x0, 0x48(%rsp)
   5ca0c:      	movq	$0x3, 0x30(%rsp)
   5ca15:      	xorl	%edi, %edi
   5ca17:      	callq	0x70870 <f.3>
   5ca1c:      	subq	$0x8, %rsp
   5ca20:      	cmpb	$0x0, 0x19029(%rip)     # 0x75a50 <g.4>
   5ca27:      	je	0x7085f <f.2+0x180af>
   5ca2d:      	cmpq	$0x0, 0x19013(%rip)     # 0x75a48 <g.3>
   5ca35:      	je	0x7085f <f.2+0x180af>
   5ca3b:      	movq	%rax, %r14
   5ca3e:      	leaq	-0xf(%r12), %rsi
   5ca43:      	movq	$0x0, 0x48(%rsp)
   5ca4c:      	movq	$0x3, 0x30(%rsp)
   5ca55:      	xorl	%edi, %edi
   5ca57:      	callq	0x70870 <f.3>
   5ca5c:      	subq	$0x8, %rsp
   5ca60:      	cmpb	$0x0, 0x18fe9(%rip)     # 0x75a50 <g.4>
   5ca67:      	je	0x7085f <f.2+0x180af>
   5ca6d:      	movq	%rax, %rcx
   5ca70:      	cmpq	$0x0, 0x18fd0(%rip)     # 0x75a48 <g.3>
   5ca78:      	movq	0x10(%rsp), %rax
   5ca7d:      	je	0x7085f <f.2+0x180af>
   5ca83:      	addq	%r14, %rcx
   5ca86:      	cmpq	$0xf, %r12
   5ca8a:      	ja	0x5ca93 <f.2+0x42e3>
   5ca8c:      	leaq	-0xe(%r12), %r14
   5ca91:      	jmp	0x5cb0e <f.2+0x435e>
   5ca93:      	movq	%rcx, 0x18(%rsp)
   5ca98:      	movq	$0x0, 0x48(%rsp)
   5caa1:      	movq	$0x3, 0x30(%rsp)
   5caaa:      	xorl	%edi, %edi
   5caac:      	leaq	-0xf(%r12), %rsi
   5cab1:      	callq	0x70870 <f.3>
   5cab6:      	subq	$0x8, %rsp
   5caba:      	cmpb	$0x0, 0x18f8f(%rip)     # 0x75a50 <g.4>
   5cac1:      	je	0x7085f <f.2+0x180af>
   5cac7:      	movq	%rax, 0x50(%rsp)
   5cacc:      	cmpq	$0x0, 0x18f74(%rip)     # 0x75a48 <g.3>
   5cad4:      	je	0x7085f <f.2+0x180af>
   5cada:      	leaq	-0x10(%r12), %rsi
   5cadf:      	movq	$0x0, 0x48(%rsp)
   5cae8:      	movq	$0x3, 0x30(%rsp)
   5caf1:      	xorl	%edi, %edi
   5caf3:      	callq	0x70870 <f.3>
   5caf8:      	subq	$0x8, %rsp
   5cafc:      	movq	%rax, %r14
   5caff:      	addq	0x50(%rsp), %r14
   5cb04:      	movq	0x10(%rsp), %rax
   5cb09:      	movq	0x18(%rsp), %rcx
   5cb0e:      	cmpb	$0x0, 0x18f3b(%rip)     # 0x75a50 <g.4>
   5cb15:      	je	0x7085f <f.2+0x180af>
   5cb1b:      	addq	%rcx, %r14
   5cb1e:      	addq	%rax, %r14
   5cb21:      	cmpq	$0x0, 0x18f1f(%rip)     # 0x75a48 <g.3>
   5cb29:      	je	0x7085f <f.2+0x180af>
   5cb2f:      	cmpq	$0xc, %r12
   5cb33:      	ja	0x5cb3f <f.2+0x438f>
   5cb35:      	leaq	-0xb(%r12), %rcx
   5cb3a:      	jmp	0x5ce87 <f.2+0x46d7>
   5cb3f:      	cmpq	$0xd, %r12
   5cb43:      	jne	0x5cb5d <f.2+0x43ad>
   5cb45:      	movl	$0x1, %ecx
   5cb4a:      	cmpq	$0x0, 0x18ef6(%rip)     # 0x75a48 <g.3>
   5cb52:      	jne	0x5cca6 <f.2+0x44f6>
   5cb58:      	jmp	0x7085f <f.2+0x180af>
   5cb5d:      	cmpq	$0xf, %r12
   5cb61:      	jb	0x5cc7a <f.2+0x44ca>
   5cb67:      	leaq	-0xe(%r12), %rsi
   5cb6c:      	movq	$0x0, 0x48(%rsp)
   5cb75:      	movq	$0x3, 0x30(%rsp)
   5cb7e:      	xorl	%edi, %edi
   5cb80:      	callq	0x70870 <f.3>
   5cb85:      	subq	$0x8, %rsp
   5cb89:      	cmpb	$0x0, 0x18ec0(%rip)     # 0x75a50 <g.4>
   5cb90:      	je	0x7085f <f.2+0x180af>
   5cb96:      	movq	%rax, 0x10(%rsp)
   5cb9b:      	cmpq	$0x0, 0x18ea5(%rip)     # 0x75a48 <g.3>
   5cba3:      	je	0x7085f <f.2+0x180af>
   5cba9:      	leaq	-0xf(%r12), %rsi
   5cbae:      	movq	$0x0, 0x48(%rsp)
   5cbb7:      	movq	$0x3, 0x30(%rsp)
   5cbc0:      	xorl	%edi, %edi
   5cbc2:      	callq	0x70870 <f.3>
   5cbc7:      	subq	$0x8, %rsp
   5cbcb:      	cmpb	$0x0, 0x18e7e(%rip)     # 0x75a50 <g.4>
   5cbd2:      	je	0x7085f <f.2+0x180af>
   5cbd8:      	cmpq	$0x0, 0x18e68(%rip)     # 0x75a48 <g.3>
   5cbe0:      	je	0x7085f <f.2+0x180af>
   5cbe6:      	addq	0x10(%rsp), %rax
   5cbeb:      	cmpq	$0xf, %r12
   5cbef:      	je	0x5cc8d <f.2+0x44dd>
   5cbf5:      	movq	%rax, 0x10(%rsp)
   5cbfa:      	movq	$0x0, 0x48(%rsp)
   5cc03:      	movq	$0x3, 0x30(%rsp)
   5cc0c:      	xorl	%edi, %edi
   5cc0e:      	leaq	-0xf(%r12), %rsi
   5cc13:      	callq	0x70870 <f.3>
   5cc18:      	subq	$0x8, %rsp
   5cc1c:      	cmpb	$0x0, 0x18e2d(%rip)     # 0x75a50 <g.4>
   5cc23:      	je	0x7085f <f.2+0x180af>
   5cc29:      	movq	%rax, 0x18(%rsp)
   5cc2e:      	cmpq	$0x0, 0x18e12(%rip)     # 0x75a48 <g.3>
   5cc36:      	je	0x7085f <f.2+0x180af>
   5cc3c:      	leaq	-0x10(%r12), %rsi
   5cc41:      	movq	$0x0, 0x48(%rsp)
   5cc4a:      	movq	$0x3, 0x30(%rsp)
   5cc53:      	xorl	%edi, %edi
   5cc55:      	callq	0x70870 <f.3>
   5cc5a:      	subq	$0x8, %rsp
   5cc5e:      	cmpb	$0x0, 0x18deb(%rip)     # 0x75a50 <g.4>
   5cc65:      	je	0x7085f <f.2+0x180af>
   5cc6b:      	movq	%rax, %rcx
   5cc6e:      	addq	0x18(%rsp), %rcx
   5cc73:      	addq	0x10(%rsp), %rcx
   5cc78:      	jmp	0x5cc92 <f.2+0x44e2>
   5cc7a:      	movl	$0x1, %eax
   5cc7f:      	cmpq	$0x0, 0x18dc1(%rip)     # 0x75a48 <g.3>
   5cc87:      	je	0x7085f <f.2+0x180af>
   5cc8d:      	leaq	-0xe(%r12,%rax), %rcx
   5cc92:      	cmpq	$0x0, 0x18dae(%rip)     # 0x75a48 <g.3>
   5cc9a:      	je	0x7085f <f.2+0x180af>
   5cca0:      	cmpq	$0xe, %r12
   5cca4:      	ja	0x5ccb0 <f.2+0x4500>
   5cca6:      	leaq	-0xd(%r12), %rdx
   5ccab:      	jmp	0x5ce84 <f.2+0x46d4>
   5ccb0:      	cmpq	$0xf, %r12
   5ccb4:      	jne	0x5ccce <f.2+0x451e>
   5ccb6:      	movl	$0x1, %edx
   5ccbb:      	cmpq	$0x0, 0x18d85(%rip)     # 0x75a48 <g.3>
   5ccc3:      	jne	0x5cd69 <f.2+0x45b9>
   5ccc9:      	jmp	0x7085f <f.2+0x180af>
   5ccce:      	movq	%rcx, 0x10(%rsp)
   5ccd3:      	leaq	-0xf(%r12), %rsi
   5ccd8:      	movq	$0x0, 0x48(%rsp)
   5cce1:      	movq	$0x3, 0x30(%rsp)
   5ccea:      	xorl	%edi, %edi
   5ccec:      	callq	0x70870 <f.3>
   5ccf1:      	subq	$0x8, %rsp
   5ccf5:      	cmpb	$0x0, 0x18d54(%rip)     # 0x75a50 <g.4>
   5ccfc:      	je	0x7085f <f.2+0x180af>
   5cd02:      	movq	%rax, 0x18(%rsp)
   5cd07:      	cmpq	$0x0, 0x18d39(%rip)     # 0x75a48 <g.3>
   5cd0f:      	je	0x7085f <f.2+0x180af>
   5cd15:      	leaq	-0x10(%r12), %rsi
   5cd1a:      	movq	$0x0, 0x48(%rsp)
   5cd23:      	movq	$0x3, 0x30(%rsp)
   5cd2c:      	xorl	%edi, %edi
   5cd2e:      	callq	0x70870 <f.3>
   5cd33:      	subq	$0x8, %rsp
   5cd37:      	cmpb	$0x0, 0x18d12(%rip)     # 0x75a50 <g.4>
   5cd3e:      	je	0x7085f <f.2+0x180af>
   5cd44:      	cmpq	$0x0, 0x18cfc(%rip)     # 0x75a48 <g.3>
   5cd4c:      	movq	0x10(%rsp), %rcx
   5cd51:      	je	0x7085f <f.2+0x180af>
   5cd57:      	movq	%rax, %rdx
   5cd5a:      	addq	0x18(%rsp), %rdx
   5cd5f:      	cmpq	$0x10, %r12
   5cd63:      	ja	0x5ce09 <f.2+0x4659>
   5cd69:      	leaq	-0xf(%r12), %rax
   5cd6e:      	jmp	0x5ce81 <f.2+0x46d1>
   5cd73:      	movq	%rdx, 0x18(%rsp)
   5cd78:      	movq	$0x0, 0x48(%rsp)
   5cd81:      	movq	$0x3, 0x30(%rsp)
   5cd8a:      	xorl	%edi, %edi
   5cd8c:      	leaq	-0x10(%r12), %rsi
   5cd91:      	callq	0x70870 <f.3>
   5cd96:      	subq	$0x8, %rsp
   5cd9a:      	cmpb	$0x0, 0x18caf(%rip)     # 0x75a50 <g.4>
   5cda1:      	je	0x7085f <f.2+0x180af>
   5cda7:      	movq	%rax, 0x50(%rsp)
   5cdac:      	cmpq	$0x0, 0x18c94(%rip)     # 0x75a48 <g.3>
   5cdb4:      	je	0x7085f <f.2+0x180af>
   5cdba:      	leaq	-0x11(%r12), %rsi
   5cdbf:      	movq	$0x0, 0x48(%rsp)
   5cdc8:      	movq	$0x3, 0x30(%rsp)
   5cdd1:      	xorl	%edi, %edi
   5cdd3:      	callq	0x70870 <f.3>
   5cdd8:      	subq	$0x8, %rsp
   5cddc:      	addq	0x50(%rsp), %rax
   5cde1:      	movq	0x10(%rsp), %rcx
   5cde6:      	movq	0x18(%rsp), %rdx
   5cdeb:      	addq	%rax, %rdx
   5cdee:      	addq	%rdx, %rcx
   5cdf1:      	addq	%rcx, %rbp
   5cdf4:      	addq	%rbp, %r13
   5cdf7:      	cmpb	$0x0, 0x18c52(%rip)     # 0x75a50 <g.4>
   5cdfe:      	jne	0x5ab8e <f.2+0x23de>
   5ce04:      	jmp	0x7085f <f.2+0x180af>
   5ce09:      	movq	%rdx, 0x18(%rsp)
   5ce0e:      	movq	$0x0, 0x48(%rsp)
   5ce17:      	movq	$0x3, 0x30(%rsp)
   5ce20:      	xorl	%edi, %edi
   5ce22:      	leaq	-0x10(%r12), %rsi
   5ce27:      	callq	0x70870 <f.3>
   5ce2c:      	subq	$0x8, %rsp
   5ce30:      	cmpb	$0x0, 0x18c19(%rip)     # 0x75a50 <g.4>
   5ce37:      	je	0x7085f <f.2+0x180af>
   5ce3d:      	movq	%rax, 0x50(%rsp)
   5ce42:      	cmpq	$0x0, 0x18bfe(%rip)     # 0x75a48 <g.3>
   5ce4a:      	je	0x7085f <f.2+0x180af>
   5ce50:      	leaq	-0x11(%r12), %rsi
   5ce55:      	movq	$0x0, 0x48(%rsp)
   5ce5e:      	movq	$0x3, 0x30(%rsp)
   5ce67:      	xorl	%edi, %edi
   5ce69:      	callq	0x70870 <f.3>
   5ce6e:      	subq	$0x8, %rsp
   5ce72:      	addq	0x50(%rsp), %rax
   5ce77:      	movq	0x10(%rsp), %rcx
   5ce7c:      	movq	0x18(%rsp), %rdx
   5ce81:      	addq	%rax, %rdx
   5ce84:      	addq	%rdx, %rcx
   5ce87:      	addq	%rcx, %r14
   5ce8a:      	cmpb	$0x0, 0x18bbf(%rip)     # 0x75a50 <g.4>
   5ce91:      	je	0x7085f <f.2+0x180af>
   5ce97:      	addq	%rbp, %r14
   5ce9a:      	addq	%r15, %r14
   5ce9d:      	cmpq	$0x0, 0x18ba3(%rip)     # 0x75a48 <g.3>
   5cea5:      	leaq	0x68(%rsp), %r15
   5ceaa:      	je	0x7085f <f.2+0x180af>
   5ceb0:      	cmpq	$0x7, %r12
   5ceb4:      	ja	0x5cecd <f.2+0x471d>
   5ceb6:      	leaq	-0x6(%r12), %rbp
   5cebb:      	cmpb	$0x0, 0x18b8e(%rip)     # 0x75a50 <g.4>
   5cec2:      	jne	0x5e654 <f.2+0x5ea4>
   5cec8:      	jmp	0x7085f <f.2+0x180af>
   5cecd:      	cmpq	$0x8, %r12
   5ced1:      	jne	0x5ceeb <f.2+0x473b>
   5ced3:      	movl	$0x1, %ebp
   5ced8:      	cmpq	$0x0, 0x18b68(%rip)     # 0x75a48 <g.3>
   5cee0:      	jne	0x5da72 <f.2+0x52c2>
   5cee6:      	jmp	0x7085f <f.2+0x180af>
   5ceeb:      	cmpq	$0xa, %r12
   5ceef:      	jb	0x5cf0b <f.2+0x475b>
   5cef1:      	jne	0x5cf24 <f.2+0x4774>
   5cef3:      	movl	$0x1, %ebp
   5cef8:      	cmpq	$0x0, 0x18b48(%rip)     # 0x75a48 <g.3>
   5cf00:      	jne	0x5d1cf <f.2+0x4a1f>
   5cf06:      	jmp	0x7085f <f.2+0x180af>
   5cf0b:      	movl	$0x1, %r15d
   5cf11:      	cmpq	$0x0, 0x18b2f(%rip)     # 0x75a48 <g.3>
   5cf19:      	jne	0x5d4a2 <f.2+0x4cf2>
   5cf1f:      	jmp	0x7085f <f.2+0x180af>
   5cf24:      	cmpq	$0xc, %r12
   5cf28:      	jb	0x5cf44 <f.2+0x4794>
   5cf2a:      	jne	0x5cf5d <f.2+0x47ad>
   5cf2c:      	movl	$0x1, %ebp
   5cf31:      	cmpq	$0x0, 0x18b0f(%rip)     # 0x75a48 <g.3>
   5cf39:      	jne	0x5cfe6 <f.2+0x4836>
   5cf3f:      	jmp	0x7085f <f.2+0x180af>
   5cf44:      	movl	$0x1, %r15d
   5cf4a:      	cmpq	$0x0, 0x18af6(%rip)     # 0x75a48 <g.3>
   5cf52:      	jne	0x5d083 <f.2+0x48d3>
   5cf58:      	jmp	0x7085f <f.2+0x180af>
   5cf5d:      	leaq	-0xc(%r12), %rsi
   5cf62:      	movq	$0x0, 0x48(%rsp)
   5cf6b:      	movq	$0x3, 0x30(%rsp)
   5cf74:      	xorl	%edi, %edi
   5cf76:      	callq	0x70870 <f.3>
   5cf7b:      	subq	$0x8, %rsp
   5cf7f:      	cmpb	$0x0, 0x18aca(%rip)     # 0x75a50 <g.4>
   5cf86:      	je	0x7085f <f.2+0x180af>
   5cf8c:      	cmpq	$0x0, 0x18ab4(%rip)     # 0x75a48 <g.3>
   5cf94:      	je	0x7085f <f.2+0x180af>
   5cf9a:      	movq	%rax, %r15
   5cf9d:      	leaq	-0xd(%r12), %rsi
   5cfa2:      	movq	$0x0, 0x48(%rsp)
   5cfab:      	movq	$0x3, 0x30(%rsp)
   5cfb4:      	xorl	%edi, %edi
   5cfb6:      	callq	0x70870 <f.3>
   5cfbb:      	subq	$0x8, %rsp
   5cfbf:      	cmpb	$0x0, 0x18a8a(%rip)     # 0x75a50 <g.4>
   5cfc6:      	je	0x7085f <f.2+0x180af>
   5cfcc:      	cmpq	$0x0, 0x18a74(%rip)     # 0x75a48 <g.3>
   5cfd4:      	je	0x7085f <f.2+0x180af>
   5cfda:      	movq	%rax, %rbp
   5cfdd:      	addq	%r15, %rbp
   5cfe0:      	cmpq	$0xd, %r12
   5cfe4:      	ja	0x5cfed <f.2+0x483d>
   5cfe6:      	leaq	-0xc(%r12,%rbp), %r15
   5cfeb:      	jmp	0x5d069 <f.2+0x48b9>
   5cfed:      	movq	$0x0, 0x48(%rsp)
   5cff6:      	movq	$0x3, 0x30(%rsp)
   5cfff:      	xorl	%edi, %edi
   5d001:      	leaq	-0xd(%r12), %rsi
   5d006:      	callq	0x70870 <f.3>
   5d00b:      	subq	$0x8, %rsp
   5d00f:      	cmpb	$0x0, 0x18a3a(%rip)     # 0x75a50 <g.4>
   5d016:      	je	0x7085f <f.2+0x180af>
   5d01c:      	movq	%rax, 0x10(%rsp)
   5d021:      	cmpq	$0x0, 0x18a1f(%rip)     # 0x75a48 <g.3>
   5d029:      	je	0x7085f <f.2+0x180af>
   5d02f:      	leaq	-0xe(%r12), %rsi
   5d034:      	movq	$0x0, 0x48(%rsp)
   5d03d:      	movq	$0x3, 0x30(%rsp)
   5d046:      	xorl	%edi, %edi
   5d048:      	callq	0x70870 <f.3>
   5d04d:      	subq	$0x8, %rsp
   5d051:      	cmpb	$0x0, 0x189f8(%rip)     # 0x75a50 <g.4>
   5d058:      	je	0x7085f <f.2+0x180af>
   5d05e:      	movq	%rax, %r15
   5d061:      	addq	0x10(%rsp), %r15
   5d066:      	addq	%rbp, %r15
   5d069:      	cmpq	$0x0, 0x189d7(%rip)     # 0x75a48 <g.3>
   5d071:      	je	0x7085f <f.2+0x180af>
   5d077:      	cmpq	$0xd, %r12
   5d07b:      	je	0x5d08d <f.2+0x48dd>
   5d07d:      	cmpq	$0xc, %r12
   5d081:      	jne	0x5d0a5 <f.2+0x48f5>
   5d083:      	leaq	-0xb(%r12,%r15), %rbp
   5d088:      	jmp	0x5d1bb <f.2+0x4a0b>
   5d08d:      	movl	$0x1, %eax
   5d092:      	cmpq	$0x0, 0x189ae(%rip)     # 0x75a48 <g.3>
   5d09a:      	jne	0x5d12b <f.2+0x497b>
   5d0a0:      	jmp	0x7085f <f.2+0x180af>
   5d0a5:      	leaq	-0xd(%r12), %rsi
   5d0aa:      	movq	$0x0, 0x48(%rsp)
   5d0b3:      	movq	$0x3, 0x30(%rsp)
   5d0bc:      	xorl	%edi, %edi
   5d0be:      	callq	0x70870 <f.3>
   5d0c3:      	subq	$0x8, %rsp
   5d0c7:      	cmpb	$0x0, 0x18982(%rip)     # 0x75a50 <g.4>
   5d0ce:      	je	0x7085f <f.2+0x180af>
   5d0d4:      	cmpq	$0x0, 0x1896c(%rip)     # 0x75a48 <g.3>
   5d0dc:      	je	0x7085f <f.2+0x180af>
   5d0e2:      	movq	%rax, %rbp
   5d0e5:      	leaq	-0xe(%r12), %rsi
   5d0ea:      	movq	$0x0, 0x48(%rsp)
   5d0f3:      	movq	$0x3, 0x30(%rsp)
   5d0fc:      	xorl	%edi, %edi
   5d0fe:      	callq	0x70870 <f.3>
   5d103:      	subq	$0x8, %rsp
   5d107:      	cmpb	$0x0, 0x18942(%rip)     # 0x75a50 <g.4>
   5d10e:      	je	0x7085f <f.2+0x180af>
   5d114:      	cmpq	$0x0, 0x1892c(%rip)     # 0x75a48 <g.3>
   5d11c:      	je	0x7085f <f.2+0x180af>
   5d122:      	addq	%rbp, %rax
   5d125:      	cmpq	$0xe, %r12
   5d129:      	ja	0x5d132 <f.2+0x4982>
   5d12b:      	leaq	-0xd(%r12), %rbp
   5d130:      	jmp	0x5d1a8 <f.2+0x49f8>
   5d132:      	movq	%rax, 0x10(%rsp)
   5d137:      	movq	$0x0, 0x48(%rsp)
   5d140:      	movq	$0x3, 0x30(%rsp)
   5d149:      	xorl	%edi, %edi
   5d14b:      	leaq	-0xe(%r12), %rsi
   5d150:      	callq	0x70870 <f.3>
   5d155:      	subq	$0x8, %rsp
   5d159:      	cmpb	$0x0, 0x188f0(%rip)     # 0x75a50 <g.4>
   5d160:      	je	0x7085f <f.2+0x180af>
   5d166:      	movq	%rax, 0x18(%rsp)
   5d16b:      	cmpq	$0x0, 0x188d5(%rip)     # 0x75a48 <g.3>
   5d173:      	je	0x7085f <f.2+0x180af>
   5d179:      	leaq	-0xf(%r12), %rsi
   5d17e:      	movq	$0x0, 0x48(%rsp)
   5d187:      	movq	$0x3, 0x30(%rsp)
   5d190:      	xorl	%edi, %edi
   5d192:      	callq	0x70870 <f.3>
   5d197:      	subq	$0x8, %rsp
   5d19b:      	movq	%rax, %rbp
   5d19e:      	addq	0x18(%rsp), %rbp
   5d1a3:      	movq	0x10(%rsp), %rax
   5d1a8:      	cmpb	$0x0, 0x188a1(%rip)     # 0x75a50 <g.4>
   5d1af:      	je	0x7085f <f.2+0x180af>
   5d1b5:      	addq	%rax, %rbp
   5d1b8:      	addq	%r15, %rbp
   5d1bb:      	cmpq	$0x0, 0x18885(%rip)     # 0x75a48 <g.3>
   5d1c3:      	je	0x7085f <f.2+0x180af>
   5d1c9:      	cmpq	$0xb, %r12
   5d1cd:      	ja	0x5d1d9 <f.2+0x4a29>
   5d1cf:      	leaq	-0xa(%r12,%rbp), %r15
   5d1d4:      	jmp	0x5d488 <f.2+0x4cd8>
   5d1d9:      	cmpq	$0xc, %r12
   5d1dd:      	jne	0x5d1f7 <f.2+0x4a47>
   5d1df:      	movl	$0x1, %ecx
   5d1e4:      	cmpq	$0x0, 0x1885c(%rip)     # 0x75a48 <g.3>
   5d1ec:      	jne	0x5d33d <f.2+0x4b8d>
   5d1f2:      	jmp	0x7085f <f.2+0x180af>
   5d1f7:      	cmpq	$0xe, %r12
   5d1fb:      	jb	0x5d310 <f.2+0x4b60>
   5d201:      	leaq	-0xd(%r12), %rsi
   5d206:      	movq	$0x0, 0x48(%rsp)
   5d20f:      	movq	$0x3, 0x30(%rsp)
   5d218:      	xorl	%edi, %edi
   5d21a:      	callq	0x70870 <f.3>
   5d21f:      	subq	$0x8, %rsp
   5d223:      	cmpb	$0x0, 0x18826(%rip)     # 0x75a50 <g.4>
   5d22a:      	je	0x7085f <f.2+0x180af>
   5d230:      	movq	%rax, 0x10(%rsp)
   5d235:      	cmpq	$0x0, 0x1880b(%rip)     # 0x75a48 <g.3>
   5d23d:      	je	0x7085f <f.2+0x180af>
   5d243:      	leaq	-0xe(%r12), %rsi
   5d248:      	movq	$0x0, 0x48(%rsp)
   5d251:      	movq	$0x3, 0x30(%rsp)
   5d25a:      	xorl	%edi, %edi
   5d25c:      	callq	0x70870 <f.3>
   5d261:      	subq	$0x8, %rsp
   5d265:      	cmpb	$0x0, 0x187e4(%rip)     # 0x75a50 <g.4>
   5d26c:      	je	0x7085f <f.2+0x180af>
   5d272:      	cmpq	$0x0, 0x187ce(%rip)     # 0x75a48 <g.3>
   5d27a:      	je	0x7085f <f.2+0x180af>
   5d280:      	movq	%rax, %r15
   5d283:      	addq	0x10(%rsp), %r15
   5d288:      	cmpq	$0xe, %r12
   5d28c:      	je	0x5d324 <f.2+0x4b74>
   5d292:      	movq	$0x0, 0x48(%rsp)
   5d29b:      	movq	$0x3, 0x30(%rsp)
   5d2a4:      	xorl	%edi, %edi
   5d2a6:      	leaq	-0xe(%r12), %rsi
   5d2ab:      	callq	0x70870 <f.3>
   5d2b0:      	subq	$0x8, %rsp
   5d2b4:      	cmpb	$0x0, 0x18795(%rip)     # 0x75a50 <g.4>
   5d2bb:      	je	0x7085f <f.2+0x180af>
   5d2c1:      	movq	%rax, 0x10(%rsp)
   5d2c6:      	cmpq	$0x0, 0x1877a(%rip)     # 0x75a48 <g.3>
   5d2ce:      	je	0x7085f <f.2+0x180af>
   5d2d4:      	leaq	-0xf(%r12), %rsi
   5d2d9:      	movq	$0x0, 0x48(%rsp)
   5d2e2:      	movq	$0x3, 0x30(%rsp)
   5d2eb:      	xorl	%edi, %edi
   5d2ed:      	callq	0x70870 <f.3>
   5d2f2:      	subq	$0x8, %rsp
   5d2f6:      	cmpb	$0x0, 0x18753(%rip)     # 0x75a50 <g.4>
   5d2fd:      	je	0x7085f <f.2+0x180af>
   5d303:      	movq	%rax, %rcx
   5d306:      	addq	0x10(%rsp), %rcx
   5d30b:      	addq	%r15, %rcx
   5d30e:      	jmp	0x5d329 <f.2+0x4b79>
   5d310:      	movl	$0x1, %r15d
   5d316:      	cmpq	$0x0, 0x1872a(%rip)     # 0x75a48 <g.3>
   5d31e:      	je	0x7085f <f.2+0x180af>
   5d324:      	leaq	-0xd(%r12,%r15), %rcx
   5d329:      	cmpq	$0x0, 0x18717(%rip)     # 0x75a48 <g.3>
   5d331:      	je	0x7085f <f.2+0x180af>
   5d337:      	cmpq	$0xd, %r12
   5d33b:      	ja	0x5d347 <f.2+0x4b97>
   5d33d:      	leaq	-0xc(%r12), %r15
   5d342:      	jmp	0x5d475 <f.2+0x4cc5>
   5d347:      	cmpq	$0xe, %r12
   5d34b:      	jne	0x5d366 <f.2+0x4bb6>
   5d34d:      	movl	$0x1, %r15d
   5d353:      	cmpq	$0x0, 0x186ed(%rip)     # 0x75a48 <g.3>
   5d35b:      	jne	0x5d3fd <f.2+0x4c4d>
   5d361:      	jmp	0x7085f <f.2+0x180af>
   5d366:      	movq	%rcx, 0x10(%rsp)
   5d36b:      	leaq	-0xe(%r12), %rsi
   5d370:      	movq	$0x0, 0x48(%rsp)
   5d379:      	movq	$0x3, 0x30(%rsp)
   5d382:      	xorl	%edi, %edi
   5d384:      	callq	0x70870 <f.3>
   5d389:      	subq	$0x8, %rsp
   5d38d:      	cmpb	$0x0, 0x186bc(%rip)     # 0x75a50 <g.4>
   5d394:      	je	0x7085f <f.2+0x180af>
   5d39a:      	movq	%rax, 0x18(%rsp)
   5d39f:      	cmpq	$0x0, 0x186a1(%rip)     # 0x75a48 <g.3>
   5d3a7:      	je	0x7085f <f.2+0x180af>
   5d3ad:      	leaq	-0xf(%r12), %rsi
   5d3b2:      	movq	$0x0, 0x48(%rsp)
   5d3bb:      	movq	$0x3, 0x30(%rsp)
   5d3c4:      	xorl	%edi, %edi
   5d3c6:      	callq	0x70870 <f.3>
   5d3cb:      	subq	$0x8, %rsp
   5d3cf:      	cmpb	$0x0, 0x1867a(%rip)     # 0x75a50 <g.4>
   5d3d6:      	je	0x7085f <f.2+0x180af>
   5d3dc:      	cmpq	$0x0, 0x18664(%rip)     # 0x75a48 <g.3>
   5d3e4:      	movq	0x10(%rsp), %rcx
   5d3e9:      	je	0x7085f <f.2+0x180af>
   5d3ef:      	movq	%rax, %r15
   5d3f2:      	addq	0x18(%rsp), %r15
   5d3f7:      	cmpq	$0xf, %r12
   5d3fb:      	ja	0x5d404 <f.2+0x4c54>
   5d3fd:      	leaq	-0xe(%r12), %rax
   5d402:      	jmp	0x5d472 <f.2+0x4cc2>
   5d404:      	movq	$0x0, 0x48(%rsp)
   5d40d:      	movq	$0x3, 0x30(%rsp)
   5d416:      	xorl	%edi, %edi
   5d418:      	leaq	-0xf(%r12), %rsi
   5d41d:      	callq	0x70870 <f.3>
   5d422:      	subq	$0x8, %rsp
   5d426:      	cmpb	$0x0, 0x18623(%rip)     # 0x75a50 <g.4>
   5d42d:      	je	0x7085f <f.2+0x180af>
   5d433:      	movq	%rax, 0x18(%rsp)
   5d438:      	cmpq	$0x0, 0x18608(%rip)     # 0x75a48 <g.3>
   5d440:      	je	0x7085f <f.2+0x180af>
   5d446:      	leaq	-0x10(%r12), %rsi
   5d44b:      	movq	$0x0, 0x48(%rsp)
   5d454:      	movq	$0x3, 0x30(%rsp)
   5d45d:      	xorl	%edi, %edi
   5d45f:      	callq	0x70870 <f.3>
   5d464:      	subq	$0x8, %rsp
   5d468:      	addq	0x18(%rsp), %rax
   5d46d:      	movq	0x10(%rsp), %rcx
   5d472:      	addq	%rax, %r15
   5d475:      	cmpb	$0x0, 0x185d4(%rip)     # 0x75a50 <g.4>
   5d47c:      	je	0x7085f <f.2+0x180af>
   5d482:      	addq	%rcx, %r15
   5d485:      	addq	%rbp, %r15
   5d488:      	cmpq	$0x0, 0x185b8(%rip)     # 0x75a48 <g.3>
   5d490:      	je	0x7085f <f.2+0x180af>
   5d496:      	cmpq	$0xb, %r12
   5d49a:      	je	0x5d4ba <f.2+0x4d0a>
   5d49c:      	cmpq	$0xa, %r12
   5d4a0:      	jne	0x5d4d2 <f.2+0x4d22>
   5d4a2:      	leaq	-0x9(%r12,%r15), %rbp
   5d4a7:      	cmpq	$0x0, 0x18599(%rip)     # 0x75a48 <g.3>
   5d4af:      	jne	0x5da6c <f.2+0x52bc>
   5d4b5:      	jmp	0x7085f <f.2+0x180af>
   5d4ba:      	movl	$0x1, %ecx
   5d4bf:      	cmpq	$0x0, 0x18581(%rip)     # 0x75a48 <g.3>
   5d4c7:      	jne	0x5d78b <f.2+0x4fdb>
   5d4cd:      	jmp	0x7085f <f.2+0x180af>
   5d4d2:      	cmpq	$0xd, %r12
   5d4d6:      	jb	0x5d4f2 <f.2+0x4d42>
   5d4d8:      	jne	0x5d50a <f.2+0x4d5a>
   5d4da:      	movl	$0x1, %ebp
   5d4df:      	cmpq	$0x0, 0x18561(%rip)     # 0x75a48 <g.3>
   5d4e7:      	jne	0x5d597 <f.2+0x4de7>
   5d4ed:      	jmp	0x7085f <f.2+0x180af>
   5d4f2:      	movl	$0x1, %eax
   5d4f7:      	cmpq	$0x0, 0x18549(%rip)     # 0x75a48 <g.3>
   5d4ff:      	jne	0x5d631 <f.2+0x4e81>
   5d505:      	jmp	0x7085f <f.2+0x180af>
   5d50a:      	leaq	-0xd(%r12), %rsi
   5d50f:      	movq	$0x0, 0x48(%rsp)
   5d518:      	movq	$0x3, 0x30(%rsp)
   5d521:      	xorl	%edi, %edi
   5d523:      	callq	0x70870 <f.3>
   5d528:      	subq	$0x8, %rsp
   5d52c:      	cmpb	$0x0, 0x1851d(%rip)     # 0x75a50 <g.4>
   5d533:      	je	0x7085f <f.2+0x180af>
   5d539:      	movq	%rax, 0x10(%rsp)
   5d53e:      	cmpq	$0x0, 0x18502(%rip)     # 0x75a48 <g.3>
   5d546:      	je	0x7085f <f.2+0x180af>
   5d54c:      	leaq	-0xe(%r12), %rsi
   5d551:      	movq	$0x0, 0x48(%rsp)
   5d55a:      	movq	$0x3, 0x30(%rsp)
   5d563:      	xorl	%edi, %edi
   5d565:      	callq	0x70870 <f.3>
   5d56a:      	subq	$0x8, %rsp
   5d56e:      	cmpb	$0x0, 0x184db(%rip)     # 0x75a50 <g.4>
   5d575:      	je	0x7085f <f.2+0x180af>
   5d57b:      	cmpq	$0x0, 0x184c5(%rip)     # 0x75a48 <g.3>
   5d583:      	je	0x7085f <f.2+0x180af>
   5d589:      	movq	%rax, %rbp
   5d58c:      	addq	0x10(%rsp), %rbp
   5d591:      	cmpq	$0xe, %r12
   5d595:      	ja	0x5d59e <f.2+0x4dee>
   5d597:      	leaq	-0xd(%r12,%rbp), %rax
   5d59c:      	jmp	0x5d617 <f.2+0x4e67>
   5d59e:      	movq	$0x0, 0x48(%rsp)
   5d5a7:      	movq	$0x3, 0x30(%rsp)
   5d5b0:      	xorl	%edi, %edi
   5d5b2:      	leaq	-0xe(%r12), %rsi
   5d5b7:      	callq	0x70870 <f.3>
   5d5bc:      	subq	$0x8, %rsp
   5d5c0:      	cmpb	$0x0, 0x18489(%rip)     # 0x75a50 <g.4>
   5d5c7:      	je	0x7085f <f.2+0x180af>
   5d5cd:      	movq	%rax, 0x10(%rsp)
   5d5d2:      	cmpq	$0x0, 0x1846e(%rip)     # 0x75a48 <g.3>
   5d5da:      	je	0x7085f <f.2+0x180af>
   5d5e0:      	leaq	-0xf(%r12), %rsi
   5d5e5:      	movq	$0x0, 0x48(%rsp)
   5d5ee:      	movq	$0x3, 0x30(%rsp)
   5d5f7:      	xorl	%edi, %edi
   5d5f9:      	callq	0x70870 <f.3>
   5d5fe:      	subq	$0x8, %rsp
   5d602:      	cmpb	$0x0, 0x18447(%rip)     # 0x75a50 <g.4>
   5d609:      	je	0x7085f <f.2+0x180af>
   5d60f:      	addq	0x10(%rsp), %rax
   5d614:      	addq	%rbp, %rax
   5d617:      	cmpq	$0x0, 0x18429(%rip)     # 0x75a48 <g.3>
   5d61f:      	je	0x7085f <f.2+0x180af>
   5d625:      	cmpq	$0xe, %r12
   5d629:      	je	0x5d63b <f.2+0x4e8b>
   5d62b:      	cmpq	$0xd, %r12
   5d62f:      	jne	0x5d653 <f.2+0x4ea3>
   5d631:      	leaq	-0xc(%r12,%rax), %rcx
   5d636:      	jmp	0x5d777 <f.2+0x4fc7>
   5d63b:      	movl	$0x1, %edx
   5d640:      	cmpq	$0x0, 0x18400(%rip)     # 0x75a48 <g.3>
   5d648:      	jne	0x5d6e6 <f.2+0x4f36>
   5d64e:      	jmp	0x7085f <f.2+0x180af>
   5d653:      	movq	%rax, 0x10(%rsp)
   5d658:      	leaq	-0xe(%r12), %rsi
   5d65d:      	movq	$0x0, 0x48(%rsp)
   5d666:      	movq	$0x3, 0x30(%rsp)
   5d66f:      	xorl	%edi, %edi
   5d671:      	callq	0x70870 <f.3>
   5d676:      	subq	$0x8, %rsp
   5d67a:      	cmpb	$0x0, 0x183cf(%rip)     # 0x75a50 <g.4>
   5d681:      	je	0x7085f <f.2+0x180af>
   5d687:      	cmpq	$0x0, 0x183b9(%rip)     # 0x75a48 <g.3>
   5d68f:      	je	0x7085f <f.2+0x180af>
   5d695:      	movq	%rax, %rbp
   5d698:      	leaq	-0xf(%r12), %rsi
   5d69d:      	movq	$0x0, 0x48(%rsp)
   5d6a6:      	movq	$0x3, 0x30(%rsp)
   5d6af:      	xorl	%edi, %edi
   5d6b1:      	callq	0x70870 <f.3>
   5d6b6:      	subq	$0x8, %rsp
   5d6ba:      	cmpb	$0x0, 0x1838f(%rip)     # 0x75a50 <g.4>
   5d6c1:      	je	0x7085f <f.2+0x180af>
   5d6c7:      	movq	%rax, %rdx
   5d6ca:      	cmpq	$0x0, 0x18376(%rip)     # 0x75a48 <g.3>
   5d6d2:      	movq	0x10(%rsp), %rax
   5d6d7:      	je	0x7085f <f.2+0x180af>
   5d6dd:      	addq	%rbp, %rdx
   5d6e0:      	cmpq	$0xf, %r12
   5d6e4:      	ja	0x5d6ed <f.2+0x4f3d>
   5d6e6:      	leaq	-0xe(%r12), %rcx
   5d6eb:      	jmp	0x5d764 <f.2+0x4fb4>
   5d6ed:      	movq	%rdx, 0x18(%rsp)
   5d6f2:      	movq	$0x0, 0x48(%rsp)
   5d6fb:      	movq	$0x3, 0x30(%rsp)
   5d704:      	xorl	%edi, %edi
   5d706:      	leaq	-0xf(%r12), %rsi
   5d70b:      	callq	0x70870 <f.3>
   5d710:      	subq	$0x8, %rsp
   5d714:      	cmpb	$0x0, 0x18335(%rip)     # 0x75a50 <g.4>
   5d71b:      	je	0x7085f <f.2+0x180af>
   5d721:      	cmpq	$0x0, 0x1831f(%rip)     # 0x75a48 <g.3>
   5d729:      	je	0x7085f <f.2+0x180af>
   5d72f:      	movq	%rax, %rbp
   5d732:      	leaq	-0x10(%r12), %rsi
   5d737:      	movq	$0x0, 0x48(%rsp)
   5d740:      	movq	$0x3, 0x30(%rsp)
   5d749:      	xorl	%edi, %edi
   5d74b:      	callq	0x70870 <f.3>
   5d750:      	subq	$0x8, %rsp
   5d754:      	movq	%rax, %rcx
   5d757:      	addq	%rbp, %rcx
   5d75a:      	movq	0x10(%rsp), %rax
   5d75f:      	movq	0x18(%rsp), %rdx
   5d764:      	cmpb	$0x0, 0x182e5(%rip)     # 0x75a50 <g.4>
   5d76b:      	je	0x7085f <f.2+0x180af>
   5d771:      	addq	%rdx, %rcx
   5d774:      	addq	%rax, %rcx
   5d777:      	cmpq	$0x0, 0x182c9(%rip)     # 0x75a48 <g.3>
   5d77f:      	je	0x7085f <f.2+0x180af>
   5d785:      	cmpq	$0xc, %r12
   5d789:      	ja	0x5d795 <f.2+0x4fe5>
   5d78b:      	leaq	-0xb(%r12), %rbp
   5d790:      	jmp	0x5da4b <f.2+0x529b>
   5d795:      	cmpq	$0xd, %r12
   5d799:      	jne	0x5d7b3 <f.2+0x5003>
   5d79b:      	movl	$0x1, %ebp
   5d7a0:      	cmpq	$0x0, 0x182a0(%rip)     # 0x75a48 <g.3>
   5d7a8:      	jne	0x5d907 <f.2+0x5157>
   5d7ae:      	jmp	0x7085f <f.2+0x180af>
   5d7b3:      	cmpq	$0xf, %r12
   5d7b7:      	jb	0x5d8db <f.2+0x512b>
   5d7bd:      	movq	%rcx, 0x10(%rsp)
   5d7c2:      	leaq	-0xe(%r12), %rsi
   5d7c7:      	movq	$0x0, 0x48(%rsp)
   5d7d0:      	movq	$0x3, 0x30(%rsp)
   5d7d9:      	xorl	%edi, %edi
   5d7db:      	callq	0x70870 <f.3>
   5d7e0:      	subq	$0x8, %rsp
   5d7e4:      	cmpb	$0x0, 0x18265(%rip)     # 0x75a50 <g.4>
   5d7eb:      	je	0x7085f <f.2+0x180af>
   5d7f1:      	cmpq	$0x0, 0x1824f(%rip)     # 0x75a48 <g.3>
   5d7f9:      	je	0x7085f <f.2+0x180af>
   5d7ff:      	movq	%rax, %rbp
   5d802:      	leaq	-0xf(%r12), %rsi
   5d807:      	movq	$0x0, 0x48(%rsp)
   5d810:      	movq	$0x3, 0x30(%rsp)
   5d819:      	xorl	%edi, %edi
   5d81b:      	callq	0x70870 <f.3>
   5d820:      	subq	$0x8, %rsp
   5d824:      	cmpb	$0x0, 0x18225(%rip)     # 0x75a50 <g.4>
   5d82b:      	je	0x7085f <f.2+0x180af>
   5d831:      	cmpq	$0x0, 0x1820f(%rip)     # 0x75a48 <g.3>
   5d839:      	movq	0x10(%rsp), %rcx
   5d83e:      	je	0x7085f <f.2+0x180af>
   5d844:      	addq	%rbp, %rax
   5d847:      	cmpq	$0xf, %r12
   5d84b:      	je	0x5d8ee <f.2+0x513e>
   5d851:      	movq	%rax, 0x18(%rsp)
   5d856:      	movq	$0x0, 0x48(%rsp)
   5d85f:      	movq	$0x3, 0x30(%rsp)
   5d868:      	xorl	%edi, %edi
   5d86a:      	leaq	-0xf(%r12), %rsi
   5d86f:      	callq	0x70870 <f.3>
   5d874:      	subq	$0x8, %rsp
   5d878:      	cmpb	$0x0, 0x181d1(%rip)     # 0x75a50 <g.4>
   5d87f:      	je	0x7085f <f.2+0x180af>
   5d885:      	movq	%rax, 0x50(%rsp)
   5d88a:      	cmpq	$0x0, 0x181b6(%rip)     # 0x75a48 <g.3>
   5d892:      	je	0x7085f <f.2+0x180af>
   5d898:      	leaq	-0x10(%r12), %rsi
   5d89d:      	movq	$0x0, 0x48(%rsp)
   5d8a6:      	movq	$0x3, 0x30(%rsp)
   5d8af:      	xorl	%edi, %edi
   5d8b1:      	callq	0x70870 <f.3>
   5d8b6:      	subq	$0x8, %rsp
   5d8ba:      	cmpb	$0x0, 0x1818f(%rip)     # 0x75a50 <g.4>
   5d8c1:      	je	0x7085f <f.2+0x180af>
   5d8c7:      	movq	%rax, %rbp
   5d8ca:      	addq	0x50(%rsp), %rbp
   5d8cf:      	addq	0x18(%rsp), %rbp
   5d8d4:      	movq	0x10(%rsp), %rcx
   5d8d9:      	jmp	0x5d8f3 <f.2+0x5143>
   5d8db:      	movl	$0x1, %eax
   5d8e0:      	cmpq	$0x0, 0x18160(%rip)     # 0x75a48 <g.3>
   5d8e8:      	je	0x7085f <f.2+0x180af>
   5d8ee:      	leaq	-0xe(%r12,%rax), %rbp
   5d8f3:      	cmpq	$0x0, 0x1814d(%rip)     # 0x75a48 <g.3>
   5d8fb:      	je	0x7085f <f.2+0x180af>
   5d901:      	cmpq	$0xe, %r12
   5d905:      	ja	0x5d911 <f.2+0x5161>
   5d907:      	leaq	-0xd(%r12), %rdx
   5d90c:      	jmp	0x5da48 <f.2+0x5298>
   5d911:      	cmpq	$0xf, %r12
   5d915:      	jne	0x5d92f <f.2+0x517f>
   5d917:      	movl	$0x1, %edx
   5d91c:      	cmpq	$0x0, 0x18124(%rip)     # 0x75a48 <g.3>
   5d924:      	jne	0x5d9c6 <f.2+0x5216>
   5d92a:      	jmp	0x7085f <f.2+0x180af>
   5d92f:      	movq	%rcx, 0x10(%rsp)
   5d934:      	leaq	-0xf(%r12), %rsi
   5d939:      	movq	$0x0, 0x48(%rsp)
   5d942:      	movq	$0x3, 0x30(%rsp)
   5d94b:      	xorl	%edi, %edi
   5d94d:      	callq	0x70870 <f.3>
   5d952:      	subq	$0x8, %rsp
   5d956:      	cmpb	$0x0, 0x180f3(%rip)     # 0x75a50 <g.4>
   5d95d:      	je	0x7085f <f.2+0x180af>
   5d963:      	movq	%rax, 0x18(%rsp)
   5d968:      	cmpq	$0x0, 0x180d8(%rip)     # 0x75a48 <g.3>
   5d970:      	je	0x7085f <f.2+0x180af>
   5d976:      	leaq	-0x10(%r12), %rsi
   5d97b:      	movq	$0x0, 0x48(%rsp)
   5d984:      	movq	$0x3, 0x30(%rsp)
   5d98d:      	xorl	%edi, %edi
   5d98f:      	callq	0x70870 <f.3>
   5d994:      	subq	$0x8, %rsp
   5d998:      	cmpb	$0x0, 0x180b1(%rip)     # 0x75a50 <g.4>
   5d99f:      	je	0x7085f <f.2+0x180af>
   5d9a5:      	cmpq	$0x0, 0x1809b(%rip)     # 0x75a48 <g.3>
   5d9ad:      	movq	0x10(%rsp), %rcx
   5d9b2:      	je	0x7085f <f.2+0x180af>
   5d9b8:      	movq	%rax, %rdx
   5d9bb:      	addq	0x18(%rsp), %rdx
   5d9c0:      	cmpq	$0x10, %r12
   5d9c4:      	ja	0x5d9cd <f.2+0x521d>
   5d9c6:      	leaq	-0xf(%r12), %rax
   5d9cb:      	jmp	0x5da45 <f.2+0x5295>
   5d9cd:      	movq	%rdx, 0x18(%rsp)
   5d9d2:      	movq	$0x0, 0x48(%rsp)
   5d9db:      	movq	$0x3, 0x30(%rsp)
   5d9e4:      	xorl	%edi, %edi
   5d9e6:      	leaq	-0x10(%r12), %rsi
   5d9eb:      	callq	0x70870 <f.3>
   5d9f0:      	subq	$0x8, %rsp
   5d9f4:      	cmpb	$0x0, 0x18055(%rip)     # 0x75a50 <g.4>
   5d9fb:      	je	0x7085f <f.2+0x180af>
   5da01:      	movq	%rax, 0x50(%rsp)
   5da06:      	cmpq	$0x0, 0x1803a(%rip)     # 0x75a48 <g.3>
   5da0e:      	je	0x7085f <f.2+0x180af>
   5da14:      	leaq	-0x11(%r12), %rsi
   5da19:      	movq	$0x0, 0x48(%rsp)
   5da22:      	movq	$0x3, 0x30(%rsp)
   5da2b:      	xorl	%edi, %edi
   5da2d:      	callq	0x70870 <f.3>
   5da32:      	subq	$0x8, %rsp
   5da36:      	addq	0x50(%rsp), %rax
   5da3b:      	movq	0x10(%rsp), %rcx
   5da40:      	movq	0x18(%rsp), %rdx
   5da45:      	addq	%rax, %rdx
   5da48:      	addq	%rdx, %rbp
   5da4b:      	cmpb	$0x0, 0x17ffe(%rip)     # 0x75a50 <g.4>
   5da52:      	je	0x7085f <f.2+0x180af>
   5da58:      	addq	%rcx, %rbp
   5da5b:      	addq	%r15, %rbp
   5da5e:      	cmpq	$0x0, 0x17fe2(%rip)     # 0x75a48 <g.3>
   5da66:      	je	0x7085f <f.2+0x180af>
   5da6c:      	cmpq	$0x9, %r12
   5da70:      	ja	0x5da91 <f.2+0x52e1>
   5da72:      	leaq	-0x8(%r12), %r15
   5da77:      	addq	%r15, %rbp
   5da7a:      	leaq	0x68(%rsp), %r15
   5da7f:      	cmpb	$0x0, 0x17fca(%rip)     # 0x75a50 <g.4>
   5da86:      	jne	0x5e654 <f.2+0x5ea4>
   5da8c:      	jmp	0x7085f <f.2+0x180af>
   5da91:      	cmpq	$0xa, %r12
   5da95:      	jne	0x5dab0 <f.2+0x5300>
   5da97:      	movl	$0x1, %r15d
   5da9d:      	cmpq	$0x0, 0x17fa3(%rip)     # 0x75a48 <g.3>
   5daa5:      	jne	0x5e076 <f.2+0x58c6>
   5daab:      	jmp	0x7085f <f.2+0x180af>
   5dab0:      	cmpq	$0xc, %r12
   5dab4:      	jb	0x5dad0 <f.2+0x5320>
   5dab6:      	jne	0x5dae8 <f.2+0x5338>
   5dab8:      	movl	$0x1, %eax
   5dabd:      	cmpq	$0x0, 0x17f83(%rip)     # 0x75a48 <g.3>
   5dac5:      	jne	0x5dc2b <f.2+0x547b>
   5dacb:      	jmp	0x7085f <f.2+0x180af>
   5dad0:      	movl	$0x1, %ecx
   5dad5:      	cmpq	$0x0, 0x17f6b(%rip)     # 0x75a48 <g.3>
   5dadd:      	jne	0x5dd91 <f.2+0x55e1>
   5dae3:      	jmp	0x7085f <f.2+0x180af>
   5dae8:      	cmpq	$0xe, %r12
   5daec:      	jb	0x5dbfe <f.2+0x544e>
   5daf2:      	leaq	-0xd(%r12), %rsi
   5daf7:      	movq	$0x0, 0x48(%rsp)
   5db00:      	movq	$0x3, 0x30(%rsp)
   5db09:      	xorl	%edi, %edi
   5db0b:      	callq	0x70870 <f.3>
   5db10:      	subq	$0x8, %rsp
   5db14:      	cmpb	$0x0, 0x17f35(%rip)     # 0x75a50 <g.4>
   5db1b:      	je	0x7085f <f.2+0x180af>
   5db21:      	movq	%rax, 0x10(%rsp)
   5db26:      	cmpq	$0x0, 0x17f1a(%rip)     # 0x75a48 <g.3>
   5db2e:      	je	0x7085f <f.2+0x180af>
   5db34:      	leaq	-0xe(%r12), %rsi
   5db39:      	movq	$0x0, 0x48(%rsp)
   5db42:      	movq	$0x3, 0x30(%rsp)
   5db4b:      	xorl	%edi, %edi
   5db4d:      	callq	0x70870 <f.3>
   5db52:      	subq	$0x8, %rsp
   5db56:      	cmpb	$0x0, 0x17ef3(%rip)     # 0x75a50 <g.4>
   5db5d:      	je	0x7085f <f.2+0x180af>
   5db63:      	cmpq	$0x0, 0x17edd(%rip)     # 0x75a48 <g.3>
   5db6b:      	je	0x7085f <f.2+0x180af>
   5db71:      	movq	%rax, %r15
   5db74:      	addq	0x10(%rsp), %r15
   5db79:      	cmpq	$0xe, %r12
   5db7d:      	je	0x5dc12 <f.2+0x5462>
   5db83:      	movq	$0x0, 0x48(%rsp)
   5db8c:      	movq	$0x3, 0x30(%rsp)
   5db95:      	xorl	%edi, %edi
   5db97:      	leaq	-0xe(%r12), %rsi
   5db9c:      	callq	0x70870 <f.3>
   5dba1:      	subq	$0x8, %rsp
   5dba5:      	cmpb	$0x0, 0x17ea4(%rip)     # 0x75a50 <g.4>
   5dbac:      	je	0x7085f <f.2+0x180af>
   5dbb2:      	movq	%rax, 0x10(%rsp)
   5dbb7:      	cmpq	$0x0, 0x17e89(%rip)     # 0x75a48 <g.3>
   5dbbf:      	je	0x7085f <f.2+0x180af>
   5dbc5:      	leaq	-0xf(%r12), %rsi
   5dbca:      	movq	$0x0, 0x48(%rsp)
   5dbd3:      	movq	$0x3, 0x30(%rsp)
   5dbdc:      	xorl	%edi, %edi
   5dbde:      	callq	0x70870 <f.3>
   5dbe3:      	subq	$0x8, %rsp
   5dbe7:      	cmpb	$0x0, 0x17e62(%rip)     # 0x75a50 <g.4>
   5dbee:      	je	0x7085f <f.2+0x180af>
   5dbf4:      	addq	0x10(%rsp), %rax
   5dbf9:      	addq	%r15, %rax
   5dbfc:      	jmp	0x5dc17 <f.2+0x5467>
   5dbfe:      	movl	$0x1, %r15d
   5dc04:      	cmpq	$0x0, 0x17e3c(%rip)     # 0x75a48 <g.3>
   5dc0c:      	je	0x7085f <f.2+0x180af>
   5dc12:      	leaq	-0xd(%r12,%r15), %rax
   5dc17:      	cmpq	$0x0, 0x17e29(%rip)     # 0x75a48 <g.3>
   5dc1f:      	je	0x7085f <f.2+0x180af>
   5dc25:      	cmpq	$0xd, %r12
   5dc29:      	ja	0x5dc35 <f.2+0x5485>
   5dc2b:      	leaq	-0xc(%r12,%rax), %rcx
   5dc30:      	jmp	0x5dd77 <f.2+0x55c7>
   5dc35:      	cmpq	$0xe, %r12
   5dc39:      	jne	0x5dc53 <f.2+0x54a3>
   5dc3b:      	movl	$0x1, %edx
   5dc40:      	cmpq	$0x0, 0x17e00(%rip)     # 0x75a48 <g.3>
   5dc48:      	jne	0x5dce6 <f.2+0x5536>
   5dc4e:      	jmp	0x7085f <f.2+0x180af>
   5dc53:      	movq	%rax, 0x10(%rsp)
   5dc58:      	leaq	-0xe(%r12), %rsi
   5dc5d:      	movq	$0x0, 0x48(%rsp)
   5dc66:      	movq	$0x3, 0x30(%rsp)
   5dc6f:      	xorl	%edi, %edi
   5dc71:      	callq	0x70870 <f.3>
   5dc76:      	subq	$0x8, %rsp
   5dc7a:      	cmpb	$0x0, 0x17dcf(%rip)     # 0x75a50 <g.4>
   5dc81:      	je	0x7085f <f.2+0x180af>
   5dc87:      	cmpq	$0x0, 0x17db9(%rip)     # 0x75a48 <g.3>
   5dc8f:      	je	0x7085f <f.2+0x180af>
   5dc95:      	movq	%rax, %r15
   5dc98:      	leaq	-0xf(%r12), %rsi
   5dc9d:      	movq	$0x0, 0x48(%rsp)
   5dca6:      	movq	$0x3, 0x30(%rsp)
   5dcaf:      	xorl	%edi, %edi
   5dcb1:      	callq	0x70870 <f.3>
   5dcb6:      	subq	$0x8, %rsp
   5dcba:      	cmpb	$0x0, 0x17d8f(%rip)     # 0x75a50 <g.4>
   5dcc1:      	je	0x7085f <f.2+0x180af>
   5dcc7:      	movq	%rax, %rdx
   5dcca:      	cmpq	$0x0, 0x17d76(%rip)     # 0x75a48 <g.3>
   5dcd2:      	movq	0x10(%rsp), %rax
   5dcd7:      	je	0x7085f <f.2+0x180af>
   5dcdd:      	addq	%r15, %rdx
   5dce0:      	cmpq	$0xf, %r12
   5dce4:      	ja	0x5dced <f.2+0x553d>
   5dce6:      	leaq	-0xe(%r12), %rcx
   5dceb:      	jmp	0x5dd64 <f.2+0x55b4>
   5dced:      	movq	%rdx, 0x18(%rsp)
   5dcf2:      	movq	$0x0, 0x48(%rsp)
   5dcfb:      	movq	$0x3, 0x30(%rsp)
   5dd04:      	xorl	%edi, %edi
   5dd06:      	leaq	-0xf(%r12), %rsi
   5dd0b:      	callq	0x70870 <f.3>
   5dd10:      	subq	$0x8, %rsp
   5dd14:      	cmpb	$0x0, 0x17d35(%rip)     # 0x75a50 <g.4>
   5dd1b:      	je	0x7085f <f.2+0x180af>
   5dd21:      	cmpq	$0x0, 0x17d1f(%rip)     # 0x75a48 <g.3>
   5dd29:      	je	0x7085f <f.2+0x180af>
   5dd2f:      	movq	%rax, %r15
   5dd32:      	leaq	-0x10(%r12), %rsi
   5dd37:      	movq	$0x0, 0x48(%rsp)
   5dd40:      	movq	$0x3, 0x30(%rsp)
   5dd49:      	xorl	%edi, %edi
   5dd4b:      	callq	0x70870 <f.3>
   5dd50:      	subq	$0x8, %rsp
   5dd54:      	movq	%rax, %rcx
   5dd57:      	addq	%r15, %rcx
   5dd5a:      	movq	0x10(%rsp), %rax
   5dd5f:      	movq	0x18(%rsp), %rdx
   5dd64:      	cmpb	$0x0, 0x17ce5(%rip)     # 0x75a50 <g.4>
   5dd6b:      	je	0x7085f <f.2+0x180af>
   5dd71:      	addq	%rdx, %rcx
   5dd74:      	addq	%rax, %rcx
   5dd77:      	cmpq	$0x0, 0x17cc9(%rip)     # 0x75a48 <g.3>
   5dd7f:      	je	0x7085f <f.2+0x180af>
   5dd85:      	cmpq	$0xd, %r12
   5dd89:      	je	0x5dd9b <f.2+0x55eb>
   5dd8b:      	cmpq	$0xc, %r12
   5dd8f:      	jne	0x5ddb3 <f.2+0x5603>
   5dd91:      	leaq	-0xb(%r12,%rcx), %r15
   5dd96:      	jmp	0x5e062 <f.2+0x58b2>
   5dd9b:      	movl	$0x1, %edx
   5dda0:      	cmpq	$0x0, 0x17ca0(%rip)     # 0x75a48 <g.3>
   5dda8:      	jne	0x5df08 <f.2+0x5758>
   5ddae:      	jmp	0x7085f <f.2+0x180af>
   5ddb3:      	cmpq	$0xf, %r12
   5ddb7:      	jb	0x5dedb <f.2+0x572b>
   5ddbd:      	movq	%rcx, 0x10(%rsp)
   5ddc2:      	leaq	-0xe(%r12), %rsi
   5ddc7:      	movq	$0x0, 0x48(%rsp)
   5ddd0:      	movq	$0x3, 0x30(%rsp)
   5ddd9:      	xorl	%edi, %edi
   5dddb:      	callq	0x70870 <f.3>
   5dde0:      	subq	$0x8, %rsp
   5dde4:      	cmpb	$0x0, 0x17c65(%rip)     # 0x75a50 <g.4>
   5ddeb:      	je	0x7085f <f.2+0x180af>
   5ddf1:      	movq	%rax, 0x18(%rsp)
   5ddf6:      	cmpq	$0x0, 0x17c4a(%rip)     # 0x75a48 <g.3>
   5ddfe:      	je	0x7085f <f.2+0x180af>
   5de04:      	leaq	-0xf(%r12), %rsi
   5de09:      	movq	$0x0, 0x48(%rsp)
   5de12:      	movq	$0x3, 0x30(%rsp)
   5de1b:      	xorl	%edi, %edi
   5de1d:      	callq	0x70870 <f.3>
   5de22:      	subq	$0x8, %rsp
   5de26:      	cmpb	$0x0, 0x17c23(%rip)     # 0x75a50 <g.4>
   5de2d:      	je	0x7085f <f.2+0x180af>
   5de33:      	cmpq	$0x0, 0x17c0d(%rip)     # 0x75a48 <g.3>
   5de3b:      	movq	0x10(%rsp), %rcx
   5de40:      	je	0x7085f <f.2+0x180af>
   5de46:      	movq	%rax, %r15
   5de49:      	addq	0x18(%rsp), %r15
   5de4e:      	cmpq	$0xf, %r12
   5de52:      	je	0x5deef <f.2+0x573f>
   5de58:      	movq	$0x0, 0x48(%rsp)
   5de61:      	movq	$0x3, 0x30(%rsp)
   5de6a:      	xorl	%edi, %edi
   5de6c:      	leaq	-0xf(%r12), %rsi
   5de71:      	callq	0x70870 <f.3>
   5de76:      	subq	$0x8, %rsp
   5de7a:      	cmpb	$0x0, 0x17bcf(%rip)     # 0x75a50 <g.4>
   5de81:      	je	0x7085f <f.2+0x180af>
   5de87:      	movq	%rax, 0x18(%rsp)
   5de8c:      	cmpq	$0x0, 0x17bb4(%rip)     # 0x75a48 <g.3>
   5de94:      	je	0x7085f <f.2+0x180af>
   5de9a:      	leaq	-0x10(%r12), %rsi
   5de9f:      	movq	$0x0, 0x48(%rsp)
   5dea8:      	movq	$0x3, 0x30(%rsp)
   5deb1:      	xorl	%edi, %edi
   5deb3:      	callq	0x70870 <f.3>
   5deb8:      	subq	$0x8, %rsp
   5debc:      	cmpb	$0x0, 0x17b8d(%rip)     # 0x75a50 <g.4>
   5dec3:      	je	0x7085f <f.2+0x180af>
   5dec9:      	movq	%rax, %rdx
   5decc:      	addq	0x18(%rsp), %rdx
   5ded1:      	addq	%r15, %rdx
   5ded4:      	movq	0x10(%rsp), %rcx
   5ded9:      	jmp	0x5def4 <f.2+0x5744>
   5dedb:      	movl	$0x1, %r15d
   5dee1:      	cmpq	$0x0, 0x17b5f(%rip)     # 0x75a48 <g.3>
   5dee9:      	je	0x7085f <f.2+0x180af>
   5deef:      	leaq	-0xe(%r12,%r15), %rdx
   5def4:      	cmpq	$0x0, 0x17b4c(%rip)     # 0x75a48 <g.3>
   5defc:      	je	0x7085f <f.2+0x180af>
   5df02:      	cmpq	$0xe, %r12
   5df06:      	ja	0x5df12 <f.2+0x5762>
   5df08:      	leaq	-0xd(%r12), %r15
   5df0d:      	jmp	0x5e04f <f.2+0x589f>
   5df12:      	cmpq	$0xf, %r12
   5df16:      	jne	0x5df31 <f.2+0x5781>
   5df18:      	movl	$0x1, %r15d
   5df1e:      	cmpq	$0x0, 0x17b22(%rip)     # 0x75a48 <g.3>
   5df26:      	jne	0x5dfd2 <f.2+0x5822>
   5df2c:      	jmp	0x7085f <f.2+0x180af>
   5df31:      	movq	%rdx, 0x18(%rsp)
   5df36:      	movq	%rcx, 0x10(%rsp)
   5df3b:      	leaq	-0xf(%r12), %rsi
   5df40:      	movq	$0x0, 0x48(%rsp)
   5df49:      	movq	$0x3, 0x30(%rsp)
   5df52:      	xorl	%edi, %edi
   5df54:      	callq	0x70870 <f.3>
   5df59:      	subq	$0x8, %rsp
   5df5d:      	cmpb	$0x0, 0x17aec(%rip)     # 0x75a50 <g.4>
   5df64:      	je	0x7085f <f.2+0x180af>
   5df6a:      	movq	%rax, 0x50(%rsp)
   5df6f:      	cmpq	$0x0, 0x17ad1(%rip)     # 0x75a48 <g.3>
   5df77:      	je	0x7085f <f.2+0x180af>
   5df7d:      	leaq	-0x10(%r12), %rsi
   5df82:      	movq	$0x0, 0x48(%rsp)
   5df8b:      	movq	$0x3, 0x30(%rsp)
   5df94:      	xorl	%edi, %edi
   5df96:      	callq	0x70870 <f.3>
   5df9b:      	subq	$0x8, %rsp
   5df9f:      	cmpb	$0x0, 0x17aaa(%rip)     # 0x75a50 <g.4>
   5dfa6:      	je	0x7085f <f.2+0x180af>
   5dfac:      	cmpq	$0x0, 0x17a94(%rip)     # 0x75a48 <g.3>
   5dfb4:      	movq	0x10(%rsp), %rcx
   5dfb9:      	movq	0x18(%rsp), %rdx
   5dfbe:      	je	0x7085f <f.2+0x180af>
   5dfc4:      	movq	%rax, %r15
   5dfc7:      	addq	0x50(%rsp), %r15
   5dfcc:      	cmpq	$0x10, %r12
   5dfd0:      	ja	0x5dfd9 <f.2+0x5829>
   5dfd2:      	leaq	-0xf(%r12), %rax
   5dfd7:      	jmp	0x5e04c <f.2+0x589c>
   5dfd9:      	movq	$0x0, 0x48(%rsp)
   5dfe2:      	movq	$0x3, 0x30(%rsp)
   5dfeb:      	xorl	%edi, %edi
   5dfed:      	leaq	-0x10(%r12), %rsi
   5dff2:      	callq	0x70870 <f.3>
   5dff7:      	subq	$0x8, %rsp
   5dffb:      	cmpb	$0x0, 0x17a4e(%rip)     # 0x75a50 <g.4>
   5e002:      	je	0x7085f <f.2+0x180af>
   5e008:      	movq	%rax, 0x50(%rsp)
   5e00d:      	cmpq	$0x0, 0x17a33(%rip)     # 0x75a48 <g.3>
   5e015:      	je	0x7085f <f.2+0x180af>
   5e01b:      	leaq	-0x11(%r12), %rsi
   5e020:      	movq	$0x0, 0x48(%rsp)
   5e029:      	movq	$0x3, 0x30(%rsp)
   5e032:      	xorl	%edi, %edi
   5e034:      	callq	0x70870 <f.3>
   5e039:      	subq	$0x8, %rsp
   5e03d:      	addq	0x50(%rsp), %rax
   5e042:      	movq	0x10(%rsp), %rcx
   5e047:      	movq	0x18(%rsp), %rdx
   5e04c:      	addq	%rax, %r15
   5e04f:      	cmpb	$0x0, 0x179fa(%rip)     # 0x75a50 <g.4>
   5e056:      	je	0x7085f <f.2+0x180af>
   5e05c:      	addq	%rdx, %r15
   5e05f:      	addq	%rcx, %r15
   5e062:      	cmpq	$0x0, 0x179de(%rip)     # 0x75a48 <g.3>
   5e06a:      	je	0x7085f <f.2+0x180af>
   5e070:      	cmpq	$0xb, %r12
   5e074:      	ja	0x5e080 <f.2+0x58d0>
   5e076:      	leaq	-0xa(%r12), %rcx
   5e07b:      	jmp	0x5e63c <f.2+0x5e8c>
   5e080:      	cmpq	$0xc, %r12
   5e084:      	jne	0x5e09e <f.2+0x58ee>
   5e086:      	movl	$0x1, %ecx
   5e08b:      	cmpq	$0x0, 0x179b5(%rip)     # 0x75a48 <g.3>
   5e093:      	jne	0x5e366 <f.2+0x5bb6>
   5e099:      	jmp	0x7085f <f.2+0x180af>
   5e09e:      	cmpq	$0xe, %r12
   5e0a2:      	jb	0x5e0be <f.2+0x590e>
   5e0a4:      	jne	0x5e0d6 <f.2+0x5926>
   5e0a6:      	movl	$0x1, %eax
   5e0ab:      	cmpq	$0x0, 0x17995(%rip)     # 0x75a48 <g.3>
   5e0b3:      	jne	0x5e160 <f.2+0x59b0>
   5e0b9:      	jmp	0x7085f <f.2+0x180af>
   5e0be:      	movl	$0x1, %eax
   5e0c3:      	cmpq	$0x0, 0x1797d(%rip)     # 0x75a48 <g.3>
   5e0cb:      	jne	0x5e204 <f.2+0x5a54>
   5e0d1:      	jmp	0x7085f <f.2+0x180af>
   5e0d6:      	leaq	-0xe(%r12), %rsi
   5e0db:      	movq	$0x0, 0x48(%rsp)
   5e0e4:      	movq	$0x3, 0x30(%rsp)
   5e0ed:      	xorl	%edi, %edi
   5e0ef:      	callq	0x70870 <f.3>
   5e0f4:      	subq	$0x8, %rsp
   5e0f8:      	cmpb	$0x0, 0x17951(%rip)     # 0x75a50 <g.4>
   5e0ff:      	je	0x7085f <f.2+0x180af>
   5e105:      	movq	%rax, 0x10(%rsp)
   5e10a:      	cmpq	$0x0, 0x17936(%rip)     # 0x75a48 <g.3>
   5e112:      	je	0x7085f <f.2+0x180af>
   5e118:      	leaq	-0xf(%r12), %rsi
   5e11d:      	movq	$0x0, 0x48(%rsp)
   5e126:      	movq	$0x3, 0x30(%rsp)
   5e12f:      	xorl	%edi, %edi
   5e131:      	callq	0x70870 <f.3>
   5e136:      	subq	$0x8, %rsp
   5e13a:      	cmpb	$0x0, 0x1790f(%rip)     # 0x75a50 <g.4>
   5e141:      	je	0x7085f <f.2+0x180af>
   5e147:      	cmpq	$0x0, 0x178f9(%rip)     # 0x75a48 <g.3>
   5e14f:      	je	0x7085f <f.2+0x180af>
   5e155:      	addq	0x10(%rsp), %rax
   5e15a:      	cmpq	$0xf, %r12
   5e15e:      	ja	0x5e16a <f.2+0x59ba>
   5e160:      	leaq	-0xe(%r12,%rax), %rax
   5e165:      	jmp	0x5e1ea <f.2+0x5a3a>
   5e16a:      	movq	%rax, 0x10(%rsp)
   5e16f:      	movq	$0x0, 0x48(%rsp)
   5e178:      	movq	$0x3, 0x30(%rsp)
   5e181:      	xorl	%edi, %edi
   5e183:      	leaq	-0xf(%r12), %rsi
   5e188:      	callq	0x70870 <f.3>
   5e18d:      	subq	$0x8, %rsp
   5e191:      	cmpb	$0x0, 0x178b8(%rip)     # 0x75a50 <g.4>
   5e198:      	je	0x7085f <f.2+0x180af>
   5e19e:      	movq	%rax, 0x18(%rsp)
   5e1a3:      	cmpq	$0x0, 0x1789d(%rip)     # 0x75a48 <g.3>
   5e1ab:      	je	0x7085f <f.2+0x180af>
   5e1b1:      	leaq	-0x10(%r12), %rsi
   5e1b6:      	movq	$0x0, 0x48(%rsp)
   5e1bf:      	movq	$0x3, 0x30(%rsp)
   5e1c8:      	xorl	%edi, %edi
   5e1ca:      	callq	0x70870 <f.3>
   5e1cf:      	subq	$0x8, %rsp
   5e1d3:      	cmpb	$0x0, 0x17876(%rip)     # 0x75a50 <g.4>
   5e1da:      	je	0x7085f <f.2+0x180af>
   5e1e0:      	addq	0x18(%rsp), %rax
   5e1e5:      	addq	0x10(%rsp), %rax
   5e1ea:      	cmpq	$0x0, 0x17856(%rip)     # 0x75a48 <g.3>
   5e1f2:      	je	0x7085f <f.2+0x180af>
   5e1f8:      	cmpq	$0xf, %r12
   5e1fc:      	je	0x5e20e <f.2+0x5a5e>
   5e1fe:      	cmpq	$0xe, %r12
   5e202:      	jne	0x5e226 <f.2+0x5a76>
   5e204:      	leaq	-0xd(%r12,%rax), %rcx
   5e209:      	jmp	0x5e352 <f.2+0x5ba2>
   5e20e:      	movl	$0x1, %edx
   5e213:      	cmpq	$0x0, 0x1782d(%rip)     # 0x75a48 <g.3>
   5e21b:      	jne	0x5e2bd <f.2+0x5b0d>
   5e221:      	jmp	0x7085f <f.2+0x180af>
   5e226:      	movq	%rax, 0x10(%rsp)
   5e22b:      	leaq	-0xf(%r12), %rsi
   5e230:      	movq	$0x0, 0x48(%rsp)
   5e239:      	movq	$0x3, 0x30(%rsp)
   5e242:      	xorl	%edi, %edi
   5e244:      	callq	0x70870 <f.3>
   5e249:      	subq	$0x8, %rsp
   5e24d:      	cmpb	$0x0, 0x177fc(%rip)     # 0x75a50 <g.4>
   5e254:      	je	0x7085f <f.2+0x180af>
   5e25a:      	movq	%rax, 0x18(%rsp)
   5e25f:      	cmpq	$0x0, 0x177e1(%rip)     # 0x75a48 <g.3>
   5e267:      	je	0x7085f <f.2+0x180af>
   5e26d:      	leaq	-0x10(%r12), %rsi
   5e272:      	movq	$0x0, 0x48(%rsp)
   5e27b:      	movq	$0x3, 0x30(%rsp)
   5e284:      	xorl	%edi, %edi
   5e286:      	callq	0x70870 <f.3>
   5e28b:      	subq	$0x8, %rsp
   5e28f:      	cmpb	$0x0, 0x177ba(%rip)     # 0x75a50 <g.4>
   5e296:      	je	0x7085f <f.2+0x180af>
   5e29c:      	movq	%rax, %rdx
   5e29f:      	cmpq	$0x0, 0x177a1(%rip)     # 0x75a48 <g.3>
   5e2a7:      	movq	0x10(%rsp), %rax
   5e2ac:      	je	0x7085f <f.2+0x180af>
   5e2b2:      	addq	0x18(%rsp), %rdx
   5e2b7:      	cmpq	$0x10, %r12
   5e2bb:      	ja	0x5e2c4 <f.2+0x5b14>
   5e2bd:      	leaq	-0xf(%r12), %rcx
   5e2c2:      	jmp	0x5e33f <f.2+0x5b8f>
   5e2c4:      	movq	%rdx, 0x18(%rsp)
   5e2c9:      	movq	$0x0, 0x48(%rsp)
   5e2d2:      	movq	$0x3, 0x30(%rsp)
   5e2db:      	xorl	%edi, %edi
   5e2dd:      	leaq	-0x10(%r12), %rsi
   5e2e2:      	callq	0x70870 <f.3>
   5e2e7:      	subq	$0x8, %rsp
   5e2eb:      	cmpb	$0x0, 0x1775e(%rip)     # 0x75a50 <g.4>
   5e2f2:      	je	0x7085f <f.2+0x180af>
   5e2f8:      	movq	%rax, 0x50(%rsp)
   5e2fd:      	cmpq	$0x0, 0x17743(%rip)     # 0x75a48 <g.3>
   5e305:      	je	0x7085f <f.2+0x180af>
   5e30b:      	leaq	-0x11(%r12), %rsi
   5e310:      	movq	$0x0, 0x48(%rsp)
   5e319:      	movq	$0x3, 0x30(%rsp)
   5e322:      	xorl	%edi, %edi
   5e324:      	callq	0x70870 <f.3>
   5e329:      	subq	$0x8, %rsp
   5e32d:      	movq	%rax, %rcx
   5e330:      	addq	0x50(%rsp), %rcx
   5e335:      	movq	0x10(%rsp), %rax
   5e33a:      	movq	0x18(%rsp), %rdx
   5e33f:      	cmpb	$0x0, 0x1770a(%rip)     # 0x75a50 <g.4>
   5e346:      	je	0x7085f <f.2+0x180af>
   5e34c:      	addq	%rdx, %rcx
   5e34f:      	addq	%rax, %rcx
   5e352:      	cmpq	$0x0, 0x176ee(%rip)     # 0x75a48 <g.3>
   5e35a:      	je	0x7085f <f.2+0x180af>
   5e360:      	cmpq	$0xd, %r12
   5e364:      	ja	0x5e370 <f.2+0x5bc0>
   5e366:      	leaq	-0xc(%r12), %rdx
   5e36b:      	jmp	0x5e639 <f.2+0x5e89>
   5e370:      	cmpq	$0xe, %r12
   5e374:      	jne	0x5e38e <f.2+0x5bde>
   5e376:      	movl	$0x1, %edx
   5e37b:      	cmpq	$0x0, 0x176c5(%rip)     # 0x75a48 <g.3>
   5e383:      	jne	0x5e4e6 <f.2+0x5d36>
   5e389:      	jmp	0x7085f <f.2+0x180af>
   5e38e:      	cmpq	$0x10, %r12
   5e392:      	jb	0x5e4ba <f.2+0x5d0a>
   5e398:      	movq	%rcx, 0x10(%rsp)
   5e39d:      	leaq	-0xf(%r12), %rsi
   5e3a2:      	movq	$0x0, 0x48(%rsp)
   5e3ab:      	movq	$0x3, 0x30(%rsp)
   5e3b4:      	xorl	%edi, %edi
   5e3b6:      	callq	0x70870 <f.3>
   5e3bb:      	subq	$0x8, %rsp
   5e3bf:      	cmpb	$0x0, 0x1768a(%rip)     # 0x75a50 <g.4>
   5e3c6:      	je	0x7085f <f.2+0x180af>
   5e3cc:      	movq	%rax, 0x18(%rsp)
   5e3d1:      	cmpq	$0x0, 0x1766f(%rip)     # 0x75a48 <g.3>
   5e3d9:      	je	0x7085f <f.2+0x180af>
   5e3df:      	leaq	-0x10(%r12), %rsi
   5e3e4:      	movq	$0x0, 0x48(%rsp)
   5e3ed:      	movq	$0x3, 0x30(%rsp)
   5e3f6:      	xorl	%edi, %edi
   5e3f8:      	callq	0x70870 <f.3>
   5e3fd:      	subq	$0x8, %rsp
   5e401:      	cmpb	$0x0, 0x17648(%rip)     # 0x75a50 <g.4>
   5e408:      	je	0x7085f <f.2+0x180af>
   5e40e:      	cmpq	$0x0, 0x17632(%rip)     # 0x75a48 <g.3>
   5e416:      	movq	0x10(%rsp), %rcx
   5e41b:      	je	0x7085f <f.2+0x180af>
   5e421:      	addq	0x18(%rsp), %rax
   5e426:      	cmpq	$0x10, %r12
   5e42a:      	je	0x5e4cd <f.2+0x5d1d>
   5e430:      	movq	%rax, 0x18(%rsp)
   5e435:      	movq	$0x0, 0x48(%rsp)
   5e43e:      	movq	$0x3, 0x30(%rsp)
   5e447:      	xorl	%edi, %edi
   5e449:      	leaq	-0x10(%r12), %rsi
   5e44e:      	callq	0x70870 <f.3>
   5e453:      	subq	$0x8, %rsp
   5e457:      	cmpb	$0x0, 0x175f2(%rip)     # 0x75a50 <g.4>
   5e45e:      	je	0x7085f <f.2+0x180af>
   5e464:      	movq	%rax, 0x50(%rsp)
   5e469:      	cmpq	$0x0, 0x175d7(%rip)     # 0x75a48 <g.3>
   5e471:      	je	0x7085f <f.2+0x180af>
   5e477:      	leaq	-0x11(%r12), %rsi
   5e47c:      	movq	$0x0, 0x48(%rsp)
   5e485:      	movq	$0x3, 0x30(%rsp)
   5e48e:      	xorl	%edi, %edi
   5e490:      	callq	0x70870 <f.3>
   5e495:      	subq	$0x8, %rsp
   5e499:      	cmpb	$0x0, 0x175b0(%rip)     # 0x75a50 <g.4>
   5e4a0:      	je	0x7085f <f.2+0x180af>
   5e4a6:      	movq	%rax, %rdx
   5e4a9:      	addq	0x50(%rsp), %rdx
   5e4ae:      	addq	0x18(%rsp), %rdx
   5e4b3:      	movq	0x10(%rsp), %rcx
   5e4b8:      	jmp	0x5e4d2 <f.2+0x5d22>
   5e4ba:      	movl	$0x1, %eax
   5e4bf:      	cmpq	$0x0, 0x17581(%rip)     # 0x75a48 <g.3>
   5e4c7:      	je	0x7085f <f.2+0x180af>
   5e4cd:      	leaq	-0xf(%r12,%rax), %rdx
   5e4d2:      	cmpq	$0x0, 0x1756e(%rip)     # 0x75a48 <g.3>
   5e4da:      	je	0x7085f <f.2+0x180af>
   5e4e0:      	cmpq	$0xf, %r12
   5e4e4:      	ja	0x5e4f0 <f.2+0x5d40>
   5e4e6:      	leaq	-0xe(%r12), %rsi
   5e4eb:      	jmp	0x5e636 <f.2+0x5e86>
   5e4f0:      	cmpq	$0x10, %r12
   5e4f4:      	jne	0x5e50e <f.2+0x5d5e>
   5e4f6:      	movl	$0x1, %esi
   5e4fb:      	cmpq	$0x0, 0x17545(%rip)     # 0x75a48 <g.3>
   5e503:      	jne	0x5e5af <f.2+0x5dff>
   5e509:      	jmp	0x7085f <f.2+0x180af>
   5e50e:      	movq	%rdx, 0x18(%rsp)
   5e513:      	movq	%rcx, 0x10(%rsp)
   5e518:      	leaq	-0x10(%r12), %rsi
   5e51d:      	movq	$0x0, 0x48(%rsp)
   5e526:      	movq	$0x3, 0x30(%rsp)
   5e52f:      	xorl	%edi, %edi
   5e531:      	callq	0x70870 <f.3>
   5e536:      	subq	$0x8, %rsp
   5e53a:      	cmpb	$0x0, 0x1750f(%rip)     # 0x75a50 <g.4>
   5e541:      	je	0x7085f <f.2+0x180af>
   5e547:      	movq	%rax, 0x50(%rsp)
   5e54c:      	cmpq	$0x0, 0x174f4(%rip)     # 0x75a48 <g.3>
   5e554:      	je	0x7085f <f.2+0x180af>
   5e55a:      	leaq	-0x11(%r12), %rsi
   5e55f:      	movq	$0x0, 0x48(%rsp)
   5e568:      	movq	$0x3, 0x30(%rsp)
   5e571:      	xorl	%edi, %edi
   5e573:      	callq	0x70870 <f.3>
   5e578:      	subq	$0x8, %rsp
   5e57c:      	cmpb	$0x0, 0x174cd(%rip)     # 0x75a50 <g.4>
   5e583:      	je	0x7085f <f.2+0x180af>
   5e589:      	cmpq	$0x0, 0x174b7(%rip)     # 0x75a48 <g.3>
   5e591:      	movq	0x10(%rsp), %rcx
   5e596:      	movq	0x18(%rsp), %rdx
   5e59b:      	je	0x7085f <f.2+0x180af>
   5e5a1:      	movq	%rax, %rsi
   5e5a4:      	addq	0x50(%rsp), %rsi
   5e5a9:      	cmpq	$0x11, %r12
   5e5ad:      	ja	0x5e5b6 <f.2+0x5e06>
   5e5af:      	leaq	-0x10(%r12), %rax
   5e5b4:      	jmp	0x5e633 <f.2+0x5e83>
   5e5b6:      	movq	%rsi, 0x50(%rsp)
   5e5bb:      	movq	$0x0, 0x48(%rsp)
   5e5c4:      	movq	$0x3, 0x30(%rsp)
   5e5cd:      	xorl	%edi, %edi
   5e5cf:      	leaq	-0x11(%r12), %rsi
   5e5d4:      	callq	0x70870 <f.3>
   5e5d9:      	subq	$0x8, %rsp
   5e5dd:      	movq	%rax, 0x58(%rsp)
   5e5e2:      	cmpb	$0x0, 0x17467(%rip)     # 0x75a50 <g.4>
   5e5e9:      	je	0x7085f <f.2+0x180af>
   5e5ef:      	cmpq	$0x0, 0x17451(%rip)     # 0x75a48 <g.3>
   5e5f7:      	je	0x7085f <f.2+0x180af>
   5e5fd:      	leaq	-0x12(%r12), %rsi
   5e602:      	movq	$0x0, 0x48(%rsp)
   5e60b:      	movq	$0x3, 0x30(%rsp)
   5e614:      	xorl	%edi, %edi
   5e616:      	callq	0x70870 <f.3>
   5e61b:      	subq	$0x8, %rsp
   5e61f:      	addq	0x58(%rsp), %rax
   5e624:      	movq	0x10(%rsp), %rcx
   5e629:      	movq	0x18(%rsp), %rdx
   5e62e:      	movq	0x50(%rsp), %rsi
   5e633:      	addq	%rax, %rsi
   5e636:      	addq	%rsi, %rdx
   5e639:      	addq	%rdx, %rcx
   5e63c:      	addq	%rcx, %r15
   5e63f:      	addq	%r15, %rbp
   5e642:      	leaq	0x68(%rsp), %r15
   5e647:      	cmpb	$0x0, 0x17402(%rip)     # 0x75a50 <g.4>
   5e64e:      	je	0x7085f <f.2+0x180af>
   5e654:      	addq	%r14, %rbp
   5e657:      	addq	%r13, %rbp
   5e65a:      	cmpq	$0x0, 0x173e6(%rip)     # 0x75a48 <g.3>
   5e662:      	je	0x7085f <f.2+0x180af>
   5e668:      	cmpq	$0x5, %r12
   5e66c:      	je	0x5e68b <f.2+0x5edb>
   5e66e:      	cmpq	$0x4, %r12
   5e672:      	jne	0x5e6a4 <f.2+0x5ef4>
   5e674:      	leaq	-0x3(%r12), %r13
   5e679:      	cmpb	$0x0, 0x173d0(%rip)     # 0x75a50 <g.4>
   5e680:      	jne	0x64620 <f.2+0xbe70>
   5e686:      	jmp	0x7085f <f.2+0x180af>
   5e68b:      	movl	$0x1, %r13d
   5e691:      	cmpq	$0x0, 0x173af(%rip)     # 0x75a48 <g.3>
   5e699:      	jne	0x609f2 <f.2+0x8242>
   5e69f:      	jmp	0x7085f <f.2+0x180af>
   5e6a4:      	cmpq	$0x7, %r12
   5e6a8:      	jb	0x5e6c5 <f.2+0x5f15>
   5e6aa:      	jne	0x5e6de <f.2+0x5f2e>
   5e6ac:      	movl	$0x1, %r15d
   5e6b2:      	cmpq	$0x0, 0x1738e(%rip)     # 0x75a48 <g.3>
   5e6ba:      	jne	0x5f23e <f.2+0x6a8e>
   5e6c0:      	jmp	0x7085f <f.2+0x180af>
   5e6c5:      	movl	$0x1, %r14d
   5e6cb:      	cmpq	$0x0, 0x17375(%rip)     # 0x75a48 <g.3>
   5e6d3:      	jne	0x5fdf3 <f.2+0x7643>
   5e6d9:      	jmp	0x7085f <f.2+0x180af>
   5e6de:      	cmpq	$0x9, %r12
   5e6e2:      	jb	0x5e6ff <f.2+0x5f4f>
   5e6e4:      	jne	0x5e718 <f.2+0x5f68>
   5e6e6:      	movl	$0x1, %r15d
   5e6ec:      	cmpq	$0x0, 0x17354(%rip)     # 0x75a48 <g.3>
   5e6f4:      	jne	0x5e9bb <f.2+0x620b>
   5e6fa:      	jmp	0x7085f <f.2+0x180af>
   5e6ff:      	movl	$0x1, %r14d
   5e705:      	cmpq	$0x0, 0x1733b(%rip)     # 0x75a48 <g.3>
   5e70d:      	jne	0x5ec8a <f.2+0x64da>
   5e713:      	jmp	0x7085f <f.2+0x180af>
   5e718:      	cmpq	$0xb, %r12
   5e71c:      	jb	0x5e739 <f.2+0x5f89>
   5e71e:      	jne	0x5e752 <f.2+0x5fa2>
   5e720:      	movl	$0x1, %r15d
   5e726:      	cmpq	$0x0, 0x1731a(%rip)     # 0x75a48 <g.3>
   5e72e:      	jne	0x5e7de <f.2+0x602e>
   5e734:      	jmp	0x7085f <f.2+0x180af>
   5e739:      	movl	$0x1, %r14d
   5e73f:      	cmpq	$0x0, 0x17301(%rip)     # 0x75a48 <g.3>
   5e747:      	jne	0x5e875 <f.2+0x60c5>
   5e74d:      	jmp	0x7085f <f.2+0x180af>
   5e752:      	leaq	-0xb(%r12), %rsi
   5e757:      	movq	$0x0, 0x48(%rsp)
   5e760:      	movq	$0x3, 0x30(%rsp)
   5e769:      	xorl	%edi, %edi
   5e76b:      	callq	0x70870 <f.3>
   5e770:      	subq	$0x8, %rsp
   5e774:      	cmpb	$0x0, 0x172d5(%rip)     # 0x75a50 <g.4>
   5e77b:      	je	0x7085f <f.2+0x180af>
   5e781:      	cmpq	$0x0, 0x172bf(%rip)     # 0x75a48 <g.3>
   5e789:      	je	0x7085f <f.2+0x180af>
   5e78f:      	movq	%rax, %r14
   5e792:      	leaq	-0xc(%r12), %r13
   5e797:      	movq	$0x0, 0x48(%rsp)
   5e7a0:      	movq	$0x3, 0x30(%rsp)
   5e7a9:      	xorl	%edi, %edi
   5e7ab:      	movq	%r13, %rsi
   5e7ae:      	callq	0x70870 <f.3>
   5e7b3:      	subq	$0x8, %rsp
   5e7b7:      	cmpb	$0x0, 0x17292(%rip)     # 0x75a50 <g.4>
   5e7be:      	je	0x7085f <f.2+0x180af>
   5e7c4:      	cmpq	$0x0, 0x1727c(%rip)     # 0x75a48 <g.3>
   5e7cc:      	je	0x7085f <f.2+0x180af>
   5e7d2:      	movq	%rax, %r15
   5e7d5:      	addq	%r14, %r15
   5e7d8:      	cmpq	$0xc, %r12
   5e7dc:      	ja	0x5e7e5 <f.2+0x6035>
   5e7de:      	leaq	-0xb(%r12,%r15), %r14
   5e7e3:      	jmp	0x5e85b <f.2+0x60ab>
   5e7e5:      	movq	$0x0, 0x48(%rsp)
   5e7ee:      	movq	$0x3, 0x30(%rsp)
   5e7f7:      	xorl	%edi, %edi
   5e7f9:      	movq	%r13, %rsi
   5e7fc:      	callq	0x70870 <f.3>
   5e801:      	subq	$0x8, %rsp
   5e805:      	cmpb	$0x0, 0x17244(%rip)     # 0x75a50 <g.4>
   5e80c:      	je	0x7085f <f.2+0x180af>
   5e812:      	cmpq	$0x0, 0x1722e(%rip)     # 0x75a48 <g.3>
   5e81a:      	je	0x7085f <f.2+0x180af>
   5e820:      	movq	%rax, %r13
   5e823:      	leaq	-0xd(%r12), %rsi
   5e828:      	movq	$0x0, 0x48(%rsp)
   5e831:      	movq	$0x3, 0x30(%rsp)
   5e83a:      	xorl	%edi, %edi
   5e83c:      	callq	0x70870 <f.3>
   5e841:      	subq	$0x8, %rsp
   5e845:      	cmpb	$0x0, 0x17204(%rip)     # 0x75a50 <g.4>
   5e84c:      	je	0x7085f <f.2+0x180af>
   5e852:      	movq	%rax, %r14
   5e855:      	addq	%r13, %r14
   5e858:      	addq	%r15, %r14
   5e85b:      	cmpq	$0x0, 0x171e5(%rip)     # 0x75a48 <g.3>
   5e863:      	je	0x7085f <f.2+0x180af>
   5e869:      	cmpq	$0xc, %r12
   5e86d:      	je	0x5e87f <f.2+0x60cf>
   5e86f:      	cmpq	$0xb, %r12
   5e873:      	jne	0x5e898 <f.2+0x60e8>
   5e875:      	leaq	-0xa(%r12,%r14), %r15
   5e87a:      	jmp	0x5e9a7 <f.2+0x61f7>
   5e87f:      	movl	$0x1, %r13d
   5e885:      	cmpq	$0x0, 0x171bb(%rip)     # 0x75a48 <g.3>
   5e88d:      	jne	0x5e921 <f.2+0x6171>
   5e893:      	jmp	0x7085f <f.2+0x180af>
   5e898:      	leaq	-0xc(%r12), %rsi
   5e89d:      	movq	$0x0, 0x48(%rsp)
   5e8a6:      	movq	$0x3, 0x30(%rsp)
   5e8af:      	xorl	%edi, %edi
   5e8b1:      	callq	0x70870 <f.3>
   5e8b6:      	subq	$0x8, %rsp
   5e8ba:      	cmpb	$0x0, 0x1718f(%rip)     # 0x75a50 <g.4>
   5e8c1:      	je	0x7085f <f.2+0x180af>
   5e8c7:      	cmpq	$0x0, 0x17179(%rip)     # 0x75a48 <g.3>
   5e8cf:      	je	0x7085f <f.2+0x180af>
   5e8d5:      	movq	%rax, %r15
   5e8d8:      	leaq	-0xd(%r12), %rsi
   5e8dd:      	movq	$0x0, 0x48(%rsp)
   5e8e6:      	movq	$0x3, 0x30(%rsp)
   5e8ef:      	xorl	%edi, %edi
   5e8f1:      	callq	0x70870 <f.3>
   5e8f6:      	subq	$0x8, %rsp
   5e8fa:      	cmpb	$0x0, 0x1714f(%rip)     # 0x75a50 <g.4>
   5e901:      	je	0x7085f <f.2+0x180af>
   5e907:      	cmpq	$0x0, 0x17139(%rip)     # 0x75a48 <g.3>
   5e90f:      	je	0x7085f <f.2+0x180af>
   5e915:      	movq	%rax, %r13
   5e918:      	addq	%r15, %r13
   5e91b:      	cmpq	$0xd, %r12
   5e91f:      	ja	0x5e928 <f.2+0x6178>
   5e921:      	leaq	-0xc(%r12), %r15
   5e926:      	jmp	0x5e994 <f.2+0x61e4>
   5e928:      	movq	$0x0, 0x48(%rsp)
   5e931:      	movq	$0x3, 0x30(%rsp)
   5e93a:      	xorl	%edi, %edi
   5e93c:      	leaq	-0xd(%r12), %rsi
   5e941:      	callq	0x70870 <f.3>
   5e946:      	subq	$0x8, %rsp
   5e94a:      	cmpb	$0x0, 0x170ff(%rip)     # 0x75a50 <g.4>
   5e951:      	je	0x7085f <f.2+0x180af>
   5e957:      	movq	%rax, 0x10(%rsp)
   5e95c:      	cmpq	$0x0, 0x170e4(%rip)     # 0x75a48 <g.3>
   5e964:      	je	0x7085f <f.2+0x180af>
   5e96a:      	leaq	-0xe(%r12), %rsi
   5e96f:      	movq	$0x0, 0x48(%rsp)
   5e978:      	movq	$0x3, 0x30(%rsp)
   5e981:      	xorl	%edi, %edi
   5e983:      	callq	0x70870 <f.3>
   5e988:      	subq	$0x8, %rsp
   5e98c:      	movq	%rax, %r15
   5e98f:      	addq	0x10(%rsp), %r15
   5e994:      	cmpb	$0x0, 0x170b5(%rip)     # 0x75a50 <g.4>
   5e99b:      	je	0x7085f <f.2+0x180af>
   5e9a1:      	addq	%r13, %r15
   5e9a4:      	addq	%r14, %r15
   5e9a7:      	cmpq	$0x0, 0x17099(%rip)     # 0x75a48 <g.3>
   5e9af:      	je	0x7085f <f.2+0x180af>
   5e9b5:      	cmpq	$0xa, %r12
   5e9b9:      	ja	0x5e9d3 <f.2+0x6223>
   5e9bb:      	leaq	-0x9(%r12,%r15), %r14
   5e9c0:      	cmpq	$0x0, 0x17080(%rip)     # 0x75a48 <g.3>
   5e9c8:      	jne	0x5ec7e <f.2+0x64ce>
   5e9ce:      	jmp	0x7085f <f.2+0x180af>
   5e9d3:      	cmpq	$0xb, %r12
   5e9d7:      	jne	0x5e9f2 <f.2+0x6242>
   5e9d9:      	movl	$0x1, %r13d
   5e9df:      	cmpq	$0x0, 0x17061(%rip)     # 0x75a48 <g.3>
   5e9e7:      	jne	0x5eb34 <f.2+0x6384>
   5e9ed:      	jmp	0x7085f <f.2+0x180af>
   5e9f2:      	cmpq	$0xd, %r12
   5e9f6:      	jb	0x5eb07 <f.2+0x6357>
   5e9fc:      	leaq	-0xc(%r12), %rsi
   5ea01:      	movq	$0x0, 0x48(%rsp)
   5ea0a:      	movq	$0x3, 0x30(%rsp)
   5ea13:      	xorl	%edi, %edi
   5ea15:      	callq	0x70870 <f.3>
   5ea1a:      	subq	$0x8, %rsp
   5ea1e:      	cmpb	$0x0, 0x1702b(%rip)     # 0x75a50 <g.4>
   5ea25:      	je	0x7085f <f.2+0x180af>
   5ea2b:      	cmpq	$0x0, 0x17015(%rip)     # 0x75a48 <g.3>
   5ea33:      	je	0x7085f <f.2+0x180af>
   5ea39:      	movq	%rax, %r13
   5ea3c:      	leaq	-0xd(%r12), %rsi
   5ea41:      	movq	$0x0, 0x48(%rsp)
   5ea4a:      	movq	$0x3, 0x30(%rsp)
   5ea53:      	xorl	%edi, %edi
   5ea55:      	callq	0x70870 <f.3>
   5ea5a:      	subq	$0x8, %rsp
   5ea5e:      	cmpb	$0x0, 0x16feb(%rip)     # 0x75a50 <g.4>
   5ea65:      	je	0x7085f <f.2+0x180af>
   5ea6b:      	cmpq	$0x0, 0x16fd5(%rip)     # 0x75a48 <g.3>
   5ea73:      	je	0x7085f <f.2+0x180af>
   5ea79:      	movq	%rax, %r14
   5ea7c:      	addq	%r13, %r14
   5ea7f:      	cmpq	$0xd, %r12
   5ea83:      	je	0x5eb1b <f.2+0x636b>
   5ea89:      	movq	$0x0, 0x48(%rsp)
   5ea92:      	movq	$0x3, 0x30(%rsp)
   5ea9b:      	xorl	%edi, %edi
   5ea9d:      	leaq	-0xd(%r12), %rsi
   5eaa2:      	callq	0x70870 <f.3>
   5eaa7:      	subq	$0x8, %rsp
   5eaab:      	cmpb	$0x0, 0x16f9e(%rip)     # 0x75a50 <g.4>
   5eab2:      	je	0x7085f <f.2+0x180af>
   5eab8:      	movq	%rax, 0x10(%rsp)
   5eabd:      	cmpq	$0x0, 0x16f83(%rip)     # 0x75a48 <g.3>
   5eac5:      	je	0x7085f <f.2+0x180af>
   5eacb:      	leaq	-0xe(%r12), %rsi
   5ead0:      	movq	$0x0, 0x48(%rsp)
   5ead9:      	movq	$0x3, 0x30(%rsp)
   5eae2:      	xorl	%edi, %edi
   5eae4:      	callq	0x70870 <f.3>
   5eae9:      	subq	$0x8, %rsp
   5eaed:      	cmpb	$0x0, 0x16f5c(%rip)     # 0x75a50 <g.4>
   5eaf4:      	je	0x7085f <f.2+0x180af>
   5eafa:      	movq	%rax, %r13
   5eafd:      	addq	0x10(%rsp), %r13
   5eb02:      	addq	%r14, %r13
   5eb05:      	jmp	0x5eb20 <f.2+0x6370>
   5eb07:      	movl	$0x1, %r14d
   5eb0d:      	cmpq	$0x0, 0x16f33(%rip)     # 0x75a48 <g.3>
   5eb15:      	je	0x7085f <f.2+0x180af>
   5eb1b:      	leaq	-0xc(%r12,%r14), %r13
   5eb20:      	cmpq	$0x0, 0x16f20(%rip)     # 0x75a48 <g.3>
   5eb28:      	je	0x7085f <f.2+0x180af>
   5eb2e:      	cmpq	$0xc, %r12
   5eb32:      	ja	0x5eb3e <f.2+0x638e>
   5eb34:      	leaq	-0xb(%r12), %r14
   5eb39:      	jmp	0x5ec5d <f.2+0x64ad>
   5eb3e:      	cmpq	$0xd, %r12
   5eb42:      	jne	0x5eb5d <f.2+0x63ad>
   5eb44:      	movl	$0x1, %r14d
   5eb4a:      	cmpq	$0x0, 0x16ef6(%rip)     # 0x75a48 <g.3>
   5eb52:      	jne	0x5ebea <f.2+0x643a>
   5eb58:      	jmp	0x7085f <f.2+0x180af>
   5eb5d:      	leaq	-0xd(%r12), %rsi
   5eb62:      	movq	$0x0, 0x48(%rsp)
   5eb6b:      	movq	$0x3, 0x30(%rsp)
   5eb74:      	xorl	%edi, %edi
   5eb76:      	callq	0x70870 <f.3>
   5eb7b:      	subq	$0x8, %rsp
   5eb7f:      	cmpb	$0x0, 0x16eca(%rip)     # 0x75a50 <g.4>
   5eb86:      	je	0x7085f <f.2+0x180af>
   5eb8c:      	movq	%rax, 0x10(%rsp)
   5eb91:      	cmpq	$0x0, 0x16eaf(%rip)     # 0x75a48 <g.3>
   5eb99:      	je	0x7085f <f.2+0x180af>
   5eb9f:      	leaq	-0xe(%r12), %rsi
   5eba4:      	movq	$0x0, 0x48(%rsp)
   5ebad:      	movq	$0x3, 0x30(%rsp)
   5ebb6:      	xorl	%edi, %edi
   5ebb8:      	callq	0x70870 <f.3>
   5ebbd:      	subq	$0x8, %rsp
   5ebc1:      	cmpb	$0x0, 0x16e88(%rip)     # 0x75a50 <g.4>
   5ebc8:      	je	0x7085f <f.2+0x180af>
   5ebce:      	cmpq	$0x0, 0x16e72(%rip)     # 0x75a48 <g.3>
   5ebd6:      	je	0x7085f <f.2+0x180af>
   5ebdc:      	movq	%rax, %r14
   5ebdf:      	addq	0x10(%rsp), %r14
   5ebe4:      	cmpq	$0xe, %r12
   5ebe8:      	ja	0x5ebf1 <f.2+0x6441>
   5ebea:      	leaq	-0xd(%r12), %rax
   5ebef:      	jmp	0x5ec5a <f.2+0x64aa>
   5ebf1:      	movq	$0x0, 0x48(%rsp)
   5ebfa:      	movq	$0x3, 0x30(%rsp)
   5ec03:      	xorl	%edi, %edi
   5ec05:      	leaq	-0xe(%r12), %rsi
   5ec0a:      	callq	0x70870 <f.3>
   5ec0f:      	subq	$0x8, %rsp
   5ec13:      	cmpb	$0x0, 0x16e36(%rip)     # 0x75a50 <g.4>
   5ec1a:      	je	0x7085f <f.2+0x180af>
   5ec20:      	movq	%rax, 0x10(%rsp)
   5ec25:      	cmpq	$0x0, 0x16e1b(%rip)     # 0x75a48 <g.3>
   5ec2d:      	je	0x7085f <f.2+0x180af>
   5ec33:      	leaq	-0xf(%r12), %rsi
   5ec38:      	movq	$0x0, 0x48(%rsp)
   5ec41:      	movq	$0x3, 0x30(%rsp)
   5ec4a:      	xorl	%edi, %edi
   5ec4c:      	callq	0x70870 <f.3>
   5ec51:      	subq	$0x8, %rsp
   5ec55:      	addq	0x10(%rsp), %rax
   5ec5a:      	addq	%rax, %r14
   5ec5d:      	cmpb	$0x0, 0x16dec(%rip)     # 0x75a50 <g.4>
   5ec64:      	je	0x7085f <f.2+0x180af>
   5ec6a:      	addq	%r13, %r14
   5ec6d:      	addq	%r15, %r14
   5ec70:      	cmpq	$0x0, 0x16dd0(%rip)     # 0x75a48 <g.3>
   5ec78:      	je	0x7085f <f.2+0x180af>
   5ec7e:      	cmpq	$0xa, %r12
   5ec82:      	je	0x5eca2 <f.2+0x64f2>
   5ec84:      	cmpq	$0x9, %r12
   5ec88:      	jne	0x5ecbb <f.2+0x650b>
   5ec8a:      	leaq	-0x8(%r12,%r14), %r15
   5ec8f:      	cmpq	$0x0, 0x16db1(%rip)     # 0x75a48 <g.3>
   5ec97:      	jne	0x5f238 <f.2+0x6a88>
   5ec9d:      	jmp	0x7085f <f.2+0x180af>
   5eca2:      	movl	$0x1, %r13d
   5eca8:      	cmpq	$0x0, 0x16d98(%rip)     # 0x75a48 <g.3>
   5ecb0:      	jne	0x5ef67 <f.2+0x67b7>
   5ecb6:      	jmp	0x7085f <f.2+0x180af>
   5ecbb:      	cmpq	$0xc, %r12
   5ecbf:      	jb	0x5ecdc <f.2+0x652c>
   5ecc1:      	jne	0x5ecf5 <f.2+0x6545>
   5ecc3:      	movl	$0x1, %r13d
   5ecc9:      	cmpq	$0x0, 0x16d77(%rip)     # 0x75a48 <g.3>
   5ecd1:      	jne	0x5ed7e <f.2+0x65ce>
   5ecd7:      	jmp	0x7085f <f.2+0x180af>
   5ecdc:      	movl	$0x1, %r15d
   5ece2:      	cmpq	$0x0, 0x16d5e(%rip)     # 0x75a48 <g.3>
   5ecea:      	jne	0x5ee1b <f.2+0x666b>
   5ecf0:      	jmp	0x7085f <f.2+0x180af>
   5ecf5:      	leaq	-0xc(%r12), %rsi
   5ecfa:      	movq	$0x0, 0x48(%rsp)
   5ed03:      	movq	$0x3, 0x30(%rsp)
   5ed0c:      	xorl	%edi, %edi
   5ed0e:      	callq	0x70870 <f.3>
   5ed13:      	subq	$0x8, %rsp
   5ed17:      	cmpb	$0x0, 0x16d32(%rip)     # 0x75a50 <g.4>
   5ed1e:      	je	0x7085f <f.2+0x180af>
   5ed24:      	cmpq	$0x0, 0x16d1c(%rip)     # 0x75a48 <g.3>
   5ed2c:      	je	0x7085f <f.2+0x180af>
   5ed32:      	movq	%rax, %r15
   5ed35:      	leaq	-0xd(%r12), %rsi
   5ed3a:      	movq	$0x0, 0x48(%rsp)
   5ed43:      	movq	$0x3, 0x30(%rsp)
   5ed4c:      	xorl	%edi, %edi
   5ed4e:      	callq	0x70870 <f.3>
   5ed53:      	subq	$0x8, %rsp
   5ed57:      	cmpb	$0x0, 0x16cf2(%rip)     # 0x75a50 <g.4>
   5ed5e:      	je	0x7085f <f.2+0x180af>
   5ed64:      	cmpq	$0x0, 0x16cdc(%rip)     # 0x75a48 <g.3>
   5ed6c:      	je	0x7085f <f.2+0x180af>
   5ed72:      	movq	%rax, %r13
   5ed75:      	addq	%r15, %r13
   5ed78:      	cmpq	$0xd, %r12
   5ed7c:      	ja	0x5ed85 <f.2+0x65d5>
   5ed7e:      	leaq	-0xc(%r12,%r13), %r15
   5ed83:      	jmp	0x5ee01 <f.2+0x6651>
   5ed85:      	movq	$0x0, 0x48(%rsp)
   5ed8e:      	movq	$0x3, 0x30(%rsp)
   5ed97:      	xorl	%edi, %edi
   5ed99:      	leaq	-0xd(%r12), %rsi
   5ed9e:      	callq	0x70870 <f.3>
   5eda3:      	subq	$0x8, %rsp
   5eda7:      	cmpb	$0x0, 0x16ca2(%rip)     # 0x75a50 <g.4>
   5edae:      	je	0x7085f <f.2+0x180af>
   5edb4:      	movq	%rax, 0x10(%rsp)
   5edb9:      	cmpq	$0x0, 0x16c87(%rip)     # 0x75a48 <g.3>
   5edc1:      	je	0x7085f <f.2+0x180af>
   5edc7:      	leaq	-0xe(%r12), %rsi
   5edcc:      	movq	$0x0, 0x48(%rsp)
   5edd5:      	movq	$0x3, 0x30(%rsp)
   5edde:      	xorl	%edi, %edi
   5ede0:      	callq	0x70870 <f.3>
   5ede5:      	subq	$0x8, %rsp
   5ede9:      	cmpb	$0x0, 0x16c60(%rip)     # 0x75a50 <g.4>
   5edf0:      	je	0x7085f <f.2+0x180af>
   5edf6:      	movq	%rax, %r15
   5edf9:      	addq	0x10(%rsp), %r15
   5edfe:      	addq	%r13, %r15
   5ee01:      	cmpq	$0x0, 0x16c3f(%rip)     # 0x75a48 <g.3>
   5ee09:      	je	0x7085f <f.2+0x180af>
   5ee0f:      	cmpq	$0xd, %r12
   5ee13:      	je	0x5ee25 <f.2+0x6675>
   5ee15:      	cmpq	$0xc, %r12
   5ee19:      	jne	0x5ee3d <f.2+0x668d>
   5ee1b:      	leaq	-0xb(%r12,%r15), %r13
   5ee20:      	jmp	0x5ef53 <f.2+0x67a3>
   5ee25:      	movl	$0x1, %eax
   5ee2a:      	cmpq	$0x0, 0x16c16(%rip)     # 0x75a48 <g.3>
   5ee32:      	jne	0x5eec3 <f.2+0x6713>
   5ee38:      	jmp	0x7085f <f.2+0x180af>
   5ee3d:      	leaq	-0xd(%r12), %rsi
   5ee42:      	movq	$0x0, 0x48(%rsp)
   5ee4b:      	movq	$0x3, 0x30(%rsp)
   5ee54:      	xorl	%edi, %edi
   5ee56:      	callq	0x70870 <f.3>
   5ee5b:      	subq	$0x8, %rsp
   5ee5f:      	cmpb	$0x0, 0x16bea(%rip)     # 0x75a50 <g.4>
   5ee66:      	je	0x7085f <f.2+0x180af>
   5ee6c:      	cmpq	$0x0, 0x16bd4(%rip)     # 0x75a48 <g.3>
   5ee74:      	je	0x7085f <f.2+0x180af>
   5ee7a:      	movq	%rax, %r13
   5ee7d:      	leaq	-0xe(%r12), %rsi
   5ee82:      	movq	$0x0, 0x48(%rsp)
   5ee8b:      	movq	$0x3, 0x30(%rsp)
   5ee94:      	xorl	%edi, %edi
   5ee96:      	callq	0x70870 <f.3>
   5ee9b:      	subq	$0x8, %rsp
   5ee9f:      	cmpb	$0x0, 0x16baa(%rip)     # 0x75a50 <g.4>
   5eea6:      	je	0x7085f <f.2+0x180af>
   5eeac:      	cmpq	$0x0, 0x16b94(%rip)     # 0x75a48 <g.3>
   5eeb4:      	je	0x7085f <f.2+0x180af>
   5eeba:      	addq	%r13, %rax
   5eebd:      	cmpq	$0xe, %r12
   5eec1:      	ja	0x5eeca <f.2+0x671a>
   5eec3:      	leaq	-0xd(%r12), %r13
   5eec8:      	jmp	0x5ef40 <f.2+0x6790>
   5eeca:      	movq	%rax, 0x10(%rsp)
   5eecf:      	movq	$0x0, 0x48(%rsp)
   5eed8:      	movq	$0x3, 0x30(%rsp)
   5eee1:      	xorl	%edi, %edi
   5eee3:      	leaq	-0xe(%r12), %rsi
   5eee8:      	callq	0x70870 <f.3>
   5eeed:      	subq	$0x8, %rsp
   5eef1:      	cmpb	$0x0, 0x16b58(%rip)     # 0x75a50 <g.4>
   5eef8:      	je	0x7085f <f.2+0x180af>
   5eefe:      	movq	%rax, 0x18(%rsp)
   5ef03:      	cmpq	$0x0, 0x16b3d(%rip)     # 0x75a48 <g.3>
   5ef0b:      	je	0x7085f <f.2+0x180af>
   5ef11:      	leaq	-0xf(%r12), %rsi
   5ef16:      	movq	$0x0, 0x48(%rsp)
   5ef1f:      	movq	$0x3, 0x30(%rsp)
   5ef28:      	xorl	%edi, %edi
   5ef2a:      	callq	0x70870 <f.3>
   5ef2f:      	subq	$0x8, %rsp
   5ef33:      	movq	%rax, %r13
   5ef36:      	addq	0x18(%rsp), %r13
   5ef3b:      	movq	0x10(%rsp), %rax
   5ef40:      	cmpb	$0x0, 0x16b09(%rip)     # 0x75a50 <g.4>
   5ef47:      	je	0x7085f <f.2+0x180af>
   5ef4d:      	addq	%rax, %r13
   5ef50:      	addq	%r15, %r13
   5ef53:      	cmpq	$0x0, 0x16aed(%rip)     # 0x75a48 <g.3>
   5ef5b:      	je	0x7085f <f.2+0x180af>
   5ef61:      	cmpq	$0xb, %r12
   5ef65:      	ja	0x5ef7e <f.2+0x67ce>
   5ef67:      	leaq	-0xa(%r12), %r15
   5ef6c:      	cmpb	$0x0, 0x16add(%rip)     # 0x75a50 <g.4>
   5ef73:      	jne	0x5f224 <f.2+0x6a74>
   5ef79:      	jmp	0x7085f <f.2+0x180af>
   5ef7e:      	cmpq	$0xc, %r12
   5ef82:      	jne	0x5ef9d <f.2+0x67ed>
   5ef84:      	movl	$0x1, %r15d
   5ef8a:      	cmpq	$0x0, 0x16ab6(%rip)     # 0x75a48 <g.3>
   5ef92:      	jne	0x5f0e2 <f.2+0x6932>
   5ef98:      	jmp	0x7085f <f.2+0x180af>
   5ef9d:      	cmpq	$0xe, %r12
   5efa1:      	jb	0x5f0b6 <f.2+0x6906>
   5efa7:      	leaq	-0xd(%r12), %rsi
   5efac:      	movq	$0x0, 0x48(%rsp)
   5efb5:      	movq	$0x3, 0x30(%rsp)
   5efbe:      	xorl	%edi, %edi
   5efc0:      	callq	0x70870 <f.3>
   5efc5:      	subq	$0x8, %rsp
   5efc9:      	cmpb	$0x0, 0x16a80(%rip)     # 0x75a50 <g.4>
   5efd0:      	je	0x7085f <f.2+0x180af>
   5efd6:      	cmpq	$0x0, 0x16a6a(%rip)     # 0x75a48 <g.3>
   5efde:      	je	0x7085f <f.2+0x180af>
   5efe4:      	movq	%rax, %r15
   5efe7:      	leaq	-0xe(%r12), %rsi
   5efec:      	movq	$0x0, 0x48(%rsp)
   5eff5:      	movq	$0x3, 0x30(%rsp)
   5effe:      	xorl	%edi, %edi
   5f000:      	callq	0x70870 <f.3>
   5f005:      	subq	$0x8, %rsp
   5f009:      	cmpb	$0x0, 0x16a40(%rip)     # 0x75a50 <g.4>
   5f010:      	je	0x7085f <f.2+0x180af>
   5f016:      	cmpq	$0x0, 0x16a2a(%rip)     # 0x75a48 <g.3>
   5f01e:      	je	0x7085f <f.2+0x180af>
   5f024:      	addq	%r15, %rax
   5f027:      	cmpq	$0xe, %r12
   5f02b:      	je	0x5f0c9 <f.2+0x6919>
   5f031:      	movq	%rax, 0x10(%rsp)
   5f036:      	movq	$0x0, 0x48(%rsp)
   5f03f:      	movq	$0x3, 0x30(%rsp)
   5f048:      	xorl	%edi, %edi
   5f04a:      	leaq	-0xe(%r12), %rsi
   5f04f:      	callq	0x70870 <f.3>
   5f054:      	subq	$0x8, %rsp
   5f058:      	cmpb	$0x0, 0x169f1(%rip)     # 0x75a50 <g.4>
   5f05f:      	je	0x7085f <f.2+0x180af>
   5f065:      	movq	%rax, 0x18(%rsp)
   5f06a:      	cmpq	$0x0, 0x169d6(%rip)     # 0x75a48 <g.3>
   5f072:      	je	0x7085f <f.2+0x180af>
   5f078:      	leaq	-0xf(%r12), %rsi
   5f07d:      	movq	$0x0, 0x48(%rsp)
   5f086:      	movq	$0x3, 0x30(%rsp)
   5f08f:      	xorl	%edi, %edi
   5f091:      	callq	0x70870 <f.3>
   5f096:      	subq	$0x8, %rsp
   5f09a:      	cmpb	$0x0, 0x169af(%rip)     # 0x75a50 <g.4>
   5f0a1:      	je	0x7085f <f.2+0x180af>
   5f0a7:      	movq	%rax, %r15
   5f0aa:      	addq	0x18(%rsp), %r15
   5f0af:      	addq	0x10(%rsp), %r15
   5f0b4:      	jmp	0x5f0ce <f.2+0x691e>
   5f0b6:      	movl	$0x1, %eax
   5f0bb:      	cmpq	$0x0, 0x16985(%rip)     # 0x75a48 <g.3>
   5f0c3:      	je	0x7085f <f.2+0x180af>
   5f0c9:      	leaq	-0xd(%r12,%rax), %r15
   5f0ce:      	cmpq	$0x0, 0x16972(%rip)     # 0x75a48 <g.3>
   5f0d6:      	je	0x7085f <f.2+0x180af>
   5f0dc:      	cmpq	$0xd, %r12
   5f0e0:      	ja	0x5f0ec <f.2+0x693c>
   5f0e2:      	leaq	-0xc(%r12), %rcx
   5f0e7:      	jmp	0x5f214 <f.2+0x6a64>
   5f0ec:      	cmpq	$0xe, %r12
   5f0f0:      	jne	0x5f10a <f.2+0x695a>
   5f0f2:      	movl	$0x1, %ecx
   5f0f7:      	cmpq	$0x0, 0x16949(%rip)     # 0x75a48 <g.3>
   5f0ff:      	jne	0x5f197 <f.2+0x69e7>
   5f105:      	jmp	0x7085f <f.2+0x180af>
   5f10a:      	leaq	-0xe(%r12), %rsi
   5f10f:      	movq	$0x0, 0x48(%rsp)
   5f118:      	movq	$0x3, 0x30(%rsp)
   5f121:      	xorl	%edi, %edi
   5f123:      	callq	0x70870 <f.3>
   5f128:      	subq	$0x8, %rsp
   5f12c:      	cmpb	$0x0, 0x1691d(%rip)     # 0x75a50 <g.4>
   5f133:      	je	0x7085f <f.2+0x180af>
   5f139:      	movq	%rax, 0x10(%rsp)
   5f13e:      	cmpq	$0x0, 0x16902(%rip)     # 0x75a48 <g.3>
   5f146:      	je	0x7085f <f.2+0x180af>
   5f14c:      	leaq	-0xf(%r12), %rsi
   5f151:      	movq	$0x0, 0x48(%rsp)
   5f15a:      	movq	$0x3, 0x30(%rsp)
   5f163:      	xorl	%edi, %edi
   5f165:      	callq	0x70870 <f.3>
   5f16a:      	subq	$0x8, %rsp
   5f16e:      	cmpb	$0x0, 0x168db(%rip)     # 0x75a50 <g.4>
   5f175:      	je	0x7085f <f.2+0x180af>
   5f17b:      	cmpq	$0x0, 0x168c5(%rip)     # 0x75a48 <g.3>
   5f183:      	je	0x7085f <f.2+0x180af>
   5f189:      	movq	%rax, %rcx
   5f18c:      	addq	0x10(%rsp), %rcx
   5f191:      	cmpq	$0xf, %r12
   5f195:      	ja	0x5f19e <f.2+0x69ee>
   5f197:      	leaq	-0xe(%r12), %rax
   5f19c:      	jmp	0x5f211 <f.2+0x6a61>
   5f19e:      	movq	%rcx, 0x10(%rsp)
   5f1a3:      	movq	$0x0, 0x48(%rsp)
   5f1ac:      	movq	$0x3, 0x30(%rsp)
   5f1b5:      	xorl	%edi, %edi
   5f1b7:      	leaq	-0xf(%r12), %rsi
   5f1bc:      	callq	0x70870 <f.3>
   5f1c1:      	subq	$0x8, %rsp
   5f1c5:      	cmpb	$0x0, 0x16884(%rip)     # 0x75a50 <g.4>
   5f1cc:      	je	0x7085f <f.2+0x180af>
   5f1d2:      	movq	%rax, 0x18(%rsp)
   5f1d7:      	cmpq	$0x0, 0x16869(%rip)     # 0x75a48 <g.3>
   5f1df:      	je	0x7085f <f.2+0x180af>
   5f1e5:      	leaq	-0x10(%r12), %rsi
   5f1ea:      	movq	$0x0, 0x48(%rsp)
   5f1f3:      	movq	$0x3, 0x30(%rsp)
   5f1fc:      	xorl	%edi, %edi
   5f1fe:      	callq	0x70870 <f.3>
   5f203:      	subq	$0x8, %rsp
   5f207:      	addq	0x18(%rsp), %rax
   5f20c:      	movq	0x10(%rsp), %rcx
   5f211:      	addq	%rax, %rcx
   5f214:      	addq	%rcx, %r15
   5f217:      	cmpb	$0x0, 0x16832(%rip)     # 0x75a50 <g.4>
   5f21e:      	je	0x7085f <f.2+0x180af>
   5f224:      	addq	%r13, %r15
   5f227:      	addq	%r14, %r15
   5f22a:      	cmpq	$0x0, 0x16816(%rip)     # 0x75a48 <g.3>
   5f232:      	je	0x7085f <f.2+0x180af>
   5f238:      	cmpq	$0x8, %r12
   5f23c:      	ja	0x5f25b <f.2+0x6aab>
   5f23e:      	leaq	-0x7(%r12,%r15), %r14
   5f243:      	cmpq	$0x0, 0x167fd(%rip)     # 0x75a48 <g.3>
   5f24b:      	leaq	0x68(%rsp), %r15
   5f250:      	jne	0x5fde7 <f.2+0x7637>
   5f256:      	jmp	0x7085f <f.2+0x180af>
   5f25b:      	cmpq	$0x9, %r12
   5f25f:      	jne	0x5f27a <f.2+0x6aca>
   5f261:      	movl	$0x1, %r13d
   5f267:      	cmpq	$0x0, 0x167d9(%rip)     # 0x75a48 <g.3>
   5f26f:      	jne	0x5f815 <f.2+0x7065>
   5f275:      	jmp	0x7085f <f.2+0x180af>
   5f27a:      	cmpq	$0xb, %r12
   5f27e:      	jb	0x5f29b <f.2+0x6aeb>
   5f280:      	jne	0x5f2b4 <f.2+0x6b04>
   5f282:      	movl	$0x1, %r13d
   5f288:      	cmpq	$0x0, 0x167b8(%rip)     # 0x75a48 <g.3>
   5f290:      	jne	0x5f3f6 <f.2+0x6c46>
   5f296:      	jmp	0x7085f <f.2+0x180af>
   5f29b:      	movl	$0x1, %r14d
   5f2a1:      	cmpq	$0x0, 0x1679f(%rip)     # 0x75a48 <g.3>
   5f2a9:      	jne	0x5f54e <f.2+0x6d9e>
   5f2af:      	jmp	0x7085f <f.2+0x180af>
   5f2b4:      	cmpq	$0xd, %r12
   5f2b8:      	jb	0x5f3c9 <f.2+0x6c19>
   5f2be:      	leaq	-0xc(%r12), %rsi
   5f2c3:      	movq	$0x0, 0x48(%rsp)
   5f2cc:      	movq	$0x3, 0x30(%rsp)
   5f2d5:      	xorl	%edi, %edi
   5f2d7:      	callq	0x70870 <f.3>
   5f2dc:      	subq	$0x8, %rsp
   5f2e0:      	cmpb	$0x0, 0x16769(%rip)     # 0x75a50 <g.4>
   5f2e7:      	je	0x7085f <f.2+0x180af>
   5f2ed:      	cmpq	$0x0, 0x16753(%rip)     # 0x75a48 <g.3>
   5f2f5:      	je	0x7085f <f.2+0x180af>
   5f2fb:      	movq	%rax, %r13
   5f2fe:      	leaq	-0xd(%r12), %rsi
   5f303:      	movq	$0x0, 0x48(%rsp)
   5f30c:      	movq	$0x3, 0x30(%rsp)
   5f315:      	xorl	%edi, %edi
   5f317:      	callq	0x70870 <f.3>
   5f31c:      	subq	$0x8, %rsp
   5f320:      	cmpb	$0x0, 0x16729(%rip)     # 0x75a50 <g.4>
   5f327:      	je	0x7085f <f.2+0x180af>
   5f32d:      	cmpq	$0x0, 0x16713(%rip)     # 0x75a48 <g.3>
   5f335:      	je	0x7085f <f.2+0x180af>
   5f33b:      	movq	%rax, %r14
   5f33e:      	addq	%r13, %r14
   5f341:      	cmpq	$0xd, %r12
   5f345:      	je	0x5f3dd <f.2+0x6c2d>
   5f34b:      	movq	$0x0, 0x48(%rsp)
   5f354:      	movq	$0x3, 0x30(%rsp)
   5f35d:      	xorl	%edi, %edi
   5f35f:      	leaq	-0xd(%r12), %rsi
   5f364:      	callq	0x70870 <f.3>
   5f369:      	subq	$0x8, %rsp
   5f36d:      	cmpb	$0x0, 0x166dc(%rip)     # 0x75a50 <g.4>
   5f374:      	je	0x7085f <f.2+0x180af>
   5f37a:      	movq	%rax, 0x10(%rsp)
   5f37f:      	cmpq	$0x0, 0x166c1(%rip)     # 0x75a48 <g.3>
   5f387:      	je	0x7085f <f.2+0x180af>
   5f38d:      	leaq	-0xe(%r12), %rsi
   5f392:      	movq	$0x0, 0x48(%rsp)
   5f39b:      	movq	$0x3, 0x30(%rsp)
   5f3a4:      	xorl	%edi, %edi
   5f3a6:      	callq	0x70870 <f.3>
   5f3ab:      	subq	$0x8, %rsp
   5f3af:      	cmpb	$0x0, 0x1669a(%rip)     # 0x75a50 <g.4>
   5f3b6:      	je	0x7085f <f.2+0x180af>
   5f3bc:      	movq	%rax, %r13
   5f3bf:      	addq	0x10(%rsp), %r13
   5f3c4:      	addq	%r14, %r13
   5f3c7:      	jmp	0x5f3e2 <f.2+0x6c32>
   5f3c9:      	movl	$0x1, %r14d
   5f3cf:      	cmpq	$0x0, 0x16671(%rip)     # 0x75a48 <g.3>
   5f3d7:      	je	0x7085f <f.2+0x180af>
   5f3dd:      	leaq	-0xc(%r12,%r14), %r13
   5f3e2:      	cmpq	$0x0, 0x1665e(%rip)     # 0x75a48 <g.3>
   5f3ea:      	je	0x7085f <f.2+0x180af>
   5f3f0:      	cmpq	$0xc, %r12
   5f3f4:      	ja	0x5f400 <f.2+0x6c50>
   5f3f6:      	leaq	-0xb(%r12,%r13), %r14
   5f3fb:      	jmp	0x5f534 <f.2+0x6d84>
   5f400:      	cmpq	$0xd, %r12
   5f404:      	jne	0x5f41e <f.2+0x6c6e>
   5f406:      	movl	$0x1, %eax
   5f40b:      	cmpq	$0x0, 0x16635(%rip)     # 0x75a48 <g.3>
   5f413:      	jne	0x5f4a4 <f.2+0x6cf4>
   5f419:      	jmp	0x7085f <f.2+0x180af>
   5f41e:      	leaq	-0xd(%r12), %rsi
   5f423:      	movq	$0x0, 0x48(%rsp)
   5f42c:      	movq	$0x3, 0x30(%rsp)
   5f435:      	xorl	%edi, %edi
   5f437:      	callq	0x70870 <f.3>
   5f43c:      	subq	$0x8, %rsp
   5f440:      	cmpb	$0x0, 0x16609(%rip)     # 0x75a50 <g.4>
   5f447:      	je	0x7085f <f.2+0x180af>
   5f44d:      	cmpq	$0x0, 0x165f3(%rip)     # 0x75a48 <g.3>
   5f455:      	je	0x7085f <f.2+0x180af>
   5f45b:      	movq	%rax, %r14
   5f45e:      	leaq	-0xe(%r12), %rsi
   5f463:      	movq	$0x0, 0x48(%rsp)
   5f46c:      	movq	$0x3, 0x30(%rsp)
   5f475:      	xorl	%edi, %edi
   5f477:      	callq	0x70870 <f.3>
   5f47c:      	subq	$0x8, %rsp
   5f480:      	cmpb	$0x0, 0x165c9(%rip)     # 0x75a50 <g.4>
   5f487:      	je	0x7085f <f.2+0x180af>
   5f48d:      	cmpq	$0x0, 0x165b3(%rip)     # 0x75a48 <g.3>
   5f495:      	je	0x7085f <f.2+0x180af>
   5f49b:      	addq	%r14, %rax
   5f49e:      	cmpq	$0xe, %r12
   5f4a2:      	ja	0x5f4ab <f.2+0x6cfb>
   5f4a4:      	leaq	-0xd(%r12), %r14
   5f4a9:      	jmp	0x5f521 <f.2+0x6d71>
   5f4ab:      	movq	%rax, 0x10(%rsp)
   5f4b0:      	movq	$0x0, 0x48(%rsp)
   5f4b9:      	movq	$0x3, 0x30(%rsp)
   5f4c2:      	xorl	%edi, %edi
   5f4c4:      	leaq	-0xe(%r12), %rsi
   5f4c9:      	callq	0x70870 <f.3>
   5f4ce:      	subq	$0x8, %rsp
   5f4d2:      	cmpb	$0x0, 0x16577(%rip)     # 0x75a50 <g.4>
   5f4d9:      	je	0x7085f <f.2+0x180af>
   5f4df:      	movq	%rax, 0x18(%rsp)
   5f4e4:      	cmpq	$0x0, 0x1655c(%rip)     # 0x75a48 <g.3>
   5f4ec:      	je	0x7085f <f.2+0x180af>
   5f4f2:      	leaq	-0xf(%r12), %rsi
   5f4f7:      	movq	$0x0, 0x48(%rsp)
   5f500:      	movq	$0x3, 0x30(%rsp)
   5f509:      	xorl	%edi, %edi
   5f50b:      	callq	0x70870 <f.3>
   5f510:      	subq	$0x8, %rsp
   5f514:      	movq	%rax, %r14
   5f517:      	addq	0x18(%rsp), %r14
   5f51c:      	movq	0x10(%rsp), %rax
   5f521:      	cmpb	$0x0, 0x16528(%rip)     # 0x75a50 <g.4>
   5f528:      	je	0x7085f <f.2+0x180af>
   5f52e:      	addq	%rax, %r14
   5f531:      	addq	%r13, %r14
   5f534:      	cmpq	$0x0, 0x1650c(%rip)     # 0x75a48 <g.3>
   5f53c:      	je	0x7085f <f.2+0x180af>
   5f542:      	cmpq	$0xc, %r12
   5f546:      	je	0x5f558 <f.2+0x6da8>
   5f548:      	cmpq	$0xb, %r12
   5f54c:      	jne	0x5f570 <f.2+0x6dc0>
   5f54e:      	leaq	-0xa(%r12,%r14), %r13
   5f553:      	jmp	0x5f801 <f.2+0x7051>
   5f558:      	movl	$0x1, %ecx
   5f55d:      	cmpq	$0x0, 0x164e3(%rip)     # 0x75a48 <g.3>
   5f565:      	jne	0x5f6b6 <f.2+0x6f06>
   5f56b:      	jmp	0x7085f <f.2+0x180af>
   5f570:      	cmpq	$0xe, %r12
   5f574:      	jb	0x5f689 <f.2+0x6ed9>
   5f57a:      	leaq	-0xd(%r12), %rsi
   5f57f:      	movq	$0x0, 0x48(%rsp)
   5f588:      	movq	$0x3, 0x30(%rsp)
   5f591:      	xorl	%edi, %edi
   5f593:      	callq	0x70870 <f.3>
   5f598:      	subq	$0x8, %rsp
   5f59c:      	cmpb	$0x0, 0x164ad(%rip)     # 0x75a50 <g.4>
   5f5a3:      	je	0x7085f <f.2+0x180af>
   5f5a9:      	movq	%rax, 0x10(%rsp)
   5f5ae:      	cmpq	$0x0, 0x16492(%rip)     # 0x75a48 <g.3>
   5f5b6:      	je	0x7085f <f.2+0x180af>
   5f5bc:      	leaq	-0xe(%r12), %rsi
   5f5c1:      	movq	$0x0, 0x48(%rsp)
   5f5ca:      	movq	$0x3, 0x30(%rsp)
   5f5d3:      	xorl	%edi, %edi
   5f5d5:      	callq	0x70870 <f.3>
   5f5da:      	subq	$0x8, %rsp
   5f5de:      	cmpb	$0x0, 0x1646b(%rip)     # 0x75a50 <g.4>
   5f5e5:      	je	0x7085f <f.2+0x180af>
   5f5eb:      	cmpq	$0x0, 0x16455(%rip)     # 0x75a48 <g.3>
   5f5f3:      	je	0x7085f <f.2+0x180af>
   5f5f9:      	movq	%rax, %r13
   5f5fc:      	addq	0x10(%rsp), %r13
   5f601:      	cmpq	$0xe, %r12
   5f605:      	je	0x5f69d <f.2+0x6eed>
   5f60b:      	movq	$0x0, 0x48(%rsp)
   5f614:      	movq	$0x3, 0x30(%rsp)
   5f61d:      	xorl	%edi, %edi
   5f61f:      	leaq	-0xe(%r12), %rsi
   5f624:      	callq	0x70870 <f.3>
   5f629:      	subq	$0x8, %rsp
   5f62d:      	cmpb	$0x0, 0x1641c(%rip)     # 0x75a50 <g.4>
   5f634:      	je	0x7085f <f.2+0x180af>
   5f63a:      	movq	%rax, 0x10(%rsp)
   5f63f:      	cmpq	$0x0, 0x16401(%rip)     # 0x75a48 <g.3>
   5f647:      	je	0x7085f <f.2+0x180af>
   5f64d:      	leaq	-0xf(%r12), %rsi
   5f652:      	movq	$0x0, 0x48(%rsp)
   5f65b:      	movq	$0x3, 0x30(%rsp)
   5f664:      	xorl	%edi, %edi
   5f666:      	callq	0x70870 <f.3>
   5f66b:      	subq	$0x8, %rsp
   5f66f:      	cmpb	$0x0, 0x163da(%rip)     # 0x75a50 <g.4>
   5f676:      	je	0x7085f <f.2+0x180af>
   5f67c:      	movq	%rax, %rcx
   5f67f:      	addq	0x10(%rsp), %rcx
   5f684:      	addq	%r13, %rcx
   5f687:      	jmp	0x5f6a2 <f.2+0x6ef2>
   5f689:      	movl	$0x1, %r13d
   5f68f:      	cmpq	$0x0, 0x163b1(%rip)     # 0x75a48 <g.3>
   5f697:      	je	0x7085f <f.2+0x180af>
   5f69d:      	leaq	-0xd(%r12,%r13), %rcx
   5f6a2:      	cmpq	$0x0, 0x1639e(%rip)     # 0x75a48 <g.3>
   5f6aa:      	je	0x7085f <f.2+0x180af>
   5f6b0:      	cmpq	$0xd, %r12
   5f6b4:      	ja	0x5f6c0 <f.2+0x6f10>
   5f6b6:      	leaq	-0xc(%r12), %r13
   5f6bb:      	jmp	0x5f7ee <f.2+0x703e>
   5f6c0:      	cmpq	$0xe, %r12
   5f6c4:      	jne	0x5f6df <f.2+0x6f2f>
   5f6c6:      	movl	$0x1, %r13d
   5f6cc:      	cmpq	$0x0, 0x16374(%rip)     # 0x75a48 <g.3>
   5f6d4:      	jne	0x5f776 <f.2+0x6fc6>
   5f6da:      	jmp	0x7085f <f.2+0x180af>
   5f6df:      	movq	%rcx, 0x10(%rsp)
   5f6e4:      	leaq	-0xe(%r12), %rsi
   5f6e9:      	movq	$0x0, 0x48(%rsp)
   5f6f2:      	movq	$0x3, 0x30(%rsp)
   5f6fb:      	xorl	%edi, %edi
   5f6fd:      	callq	0x70870 <f.3>
   5f702:      	subq	$0x8, %rsp
   5f706:      	cmpb	$0x0, 0x16343(%rip)     # 0x75a50 <g.4>
   5f70d:      	je	0x7085f <f.2+0x180af>
   5f713:      	movq	%rax, 0x18(%rsp)
   5f718:      	cmpq	$0x0, 0x16328(%rip)     # 0x75a48 <g.3>
   5f720:      	je	0x7085f <f.2+0x180af>
   5f726:      	leaq	-0xf(%r12), %rsi
   5f72b:      	movq	$0x0, 0x48(%rsp)
   5f734:      	movq	$0x3, 0x30(%rsp)
   5f73d:      	xorl	%edi, %edi
   5f73f:      	callq	0x70870 <f.3>
   5f744:      	subq	$0x8, %rsp
   5f748:      	cmpb	$0x0, 0x16301(%rip)     # 0x75a50 <g.4>
   5f74f:      	je	0x7085f <f.2+0x180af>
   5f755:      	cmpq	$0x0, 0x162eb(%rip)     # 0x75a48 <g.3>
   5f75d:      	movq	0x10(%rsp), %rcx
   5f762:      	je	0x7085f <f.2+0x180af>
   5f768:      	movq	%rax, %r13
   5f76b:      	addq	0x18(%rsp), %r13
   5f770:      	cmpq	$0xf, %r12
   5f774:      	ja	0x5f77d <f.2+0x6fcd>
   5f776:      	leaq	-0xe(%r12), %rax
   5f77b:      	jmp	0x5f7eb <f.2+0x703b>
   5f77d:      	movq	$0x0, 0x48(%rsp)
   5f786:      	movq	$0x3, 0x30(%rsp)
   5f78f:      	xorl	%edi, %edi
   5f791:      	leaq	-0xf(%r12), %rsi
   5f796:      	callq	0x70870 <f.3>
   5f79b:      	subq	$0x8, %rsp
   5f79f:      	cmpb	$0x0, 0x162aa(%rip)     # 0x75a50 <g.4>
   5f7a6:      	je	0x7085f <f.2+0x180af>
   5f7ac:      	movq	%rax, 0x18(%rsp)
   5f7b1:      	cmpq	$0x0, 0x1628f(%rip)     # 0x75a48 <g.3>
   5f7b9:      	je	0x7085f <f.2+0x180af>
   5f7bf:      	leaq	-0x10(%r12), %rsi
   5f7c4:      	movq	$0x0, 0x48(%rsp)
   5f7cd:      	movq	$0x3, 0x30(%rsp)
   5f7d6:      	xorl	%edi, %edi
   5f7d8:      	callq	0x70870 <f.3>
   5f7dd:      	subq	$0x8, %rsp
   5f7e1:      	addq	0x18(%rsp), %rax
   5f7e6:      	movq	0x10(%rsp), %rcx
   5f7eb:      	addq	%rax, %r13
   5f7ee:      	cmpb	$0x0, 0x1625b(%rip)     # 0x75a50 <g.4>
   5f7f5:      	je	0x7085f <f.2+0x180af>
   5f7fb:      	addq	%rcx, %r13
   5f7fe:      	addq	%r14, %r13
   5f801:      	cmpq	$0x0, 0x1623f(%rip)     # 0x75a48 <g.3>
   5f809:      	je	0x7085f <f.2+0x180af>
   5f80f:      	cmpq	$0xa, %r12
   5f813:      	ja	0x5f82c <f.2+0x707c>
   5f815:      	leaq	-0x9(%r12), %r14
   5f81a:      	cmpb	$0x0, 0x1622f(%rip)     # 0x75a50 <g.4>
   5f821:      	jne	0x5fdce <f.2+0x761e>
   5f827:      	jmp	0x7085f <f.2+0x180af>
   5f82c:      	cmpq	$0xb, %r12
   5f830:      	jne	0x5f84b <f.2+0x709b>
   5f832:      	movl	$0x1, %r14d
   5f838:      	cmpq	$0x0, 0x16208(%rip)     # 0x75a48 <g.3>
   5f840:      	jne	0x5fb09 <f.2+0x7359>
   5f846:      	jmp	0x7085f <f.2+0x180af>
   5f84b:      	cmpq	$0xd, %r12
   5f84f:      	jb	0x5f86c <f.2+0x70bc>
   5f851:      	jne	0x5f884 <f.2+0x70d4>
   5f853:      	movl	$0x1, %r14d
   5f859:      	cmpq	$0x0, 0x161e7(%rip)     # 0x75a48 <g.3>
   5f861:      	jne	0x5f911 <f.2+0x7161>
   5f867:      	jmp	0x7085f <f.2+0x180af>
   5f86c:      	movl	$0x1, %eax
   5f871:      	cmpq	$0x0, 0x161cf(%rip)     # 0x75a48 <g.3>
   5f879:      	jne	0x5f9ab <f.2+0x71fb>
   5f87f:      	jmp	0x7085f <f.2+0x180af>
   5f884:      	leaq	-0xd(%r12), %rsi
   5f889:      	movq	$0x0, 0x48(%rsp)
   5f892:      	movq	$0x3, 0x30(%rsp)
   5f89b:      	xorl	%edi, %edi
   5f89d:      	callq	0x70870 <f.3>
   5f8a2:      	subq	$0x8, %rsp
   5f8a6:      	cmpb	$0x0, 0x161a3(%rip)     # 0x75a50 <g.4>
   5f8ad:      	je	0x7085f <f.2+0x180af>
   5f8b3:      	movq	%rax, 0x10(%rsp)
   5f8b8:      	cmpq	$0x0, 0x16188(%rip)     # 0x75a48 <g.3>
   5f8c0:      	je	0x7085f <f.2+0x180af>
   5f8c6:      	leaq	-0xe(%r12), %rsi
   5f8cb:      	movq	$0x0, 0x48(%rsp)
   5f8d4:      	movq	$0x3, 0x30(%rsp)
   5f8dd:      	xorl	%edi, %edi
   5f8df:      	callq	0x70870 <f.3>
   5f8e4:      	subq	$0x8, %rsp
   5f8e8:      	cmpb	$0x0, 0x16161(%rip)     # 0x75a50 <g.4>
   5f8ef:      	je	0x7085f <f.2+0x180af>
   5f8f5:      	cmpq	$0x0, 0x1614b(%rip)     # 0x75a48 <g.3>
   5f8fd:      	je	0x7085f <f.2+0x180af>
   5f903:      	movq	%rax, %r14
   5f906:      	addq	0x10(%rsp), %r14
   5f90b:      	cmpq	$0xe, %r12
   5f90f:      	ja	0x5f918 <f.2+0x7168>
   5f911:      	leaq	-0xd(%r12,%r14), %rax
   5f916:      	jmp	0x5f991 <f.2+0x71e1>
   5f918:      	movq	$0x0, 0x48(%rsp)
   5f921:      	movq	$0x3, 0x30(%rsp)
   5f92a:      	xorl	%edi, %edi
   5f92c:      	leaq	-0xe(%r12), %rsi
   5f931:      	callq	0x70870 <f.3>
   5f936:      	subq	$0x8, %rsp
   5f93a:      	cmpb	$0x0, 0x1610f(%rip)     # 0x75a50 <g.4>
   5f941:      	je	0x7085f <f.2+0x180af>
   5f947:      	movq	%rax, 0x10(%rsp)
   5f94c:      	cmpq	$0x0, 0x160f4(%rip)     # 0x75a48 <g.3>
   5f954:      	je	0x7085f <f.2+0x180af>
   5f95a:      	leaq	-0xf(%r12), %rsi
   5f95f:      	movq	$0x0, 0x48(%rsp)
   5f968:      	movq	$0x3, 0x30(%rsp)
   5f971:      	xorl	%edi, %edi
   5f973:      	callq	0x70870 <f.3>
   5f978:      	subq	$0x8, %rsp
   5f97c:      	cmpb	$0x0, 0x160cd(%rip)     # 0x75a50 <g.4>
   5f983:      	je	0x7085f <f.2+0x180af>
   5f989:      	addq	0x10(%rsp), %rax
   5f98e:      	addq	%r14, %rax
   5f991:      	cmpq	$0x0, 0x160af(%rip)     # 0x75a48 <g.3>
   5f999:      	je	0x7085f <f.2+0x180af>
   5f99f:      	cmpq	$0xe, %r12
   5f9a3:      	je	0x5f9b5 <f.2+0x7205>
   5f9a5:      	cmpq	$0xd, %r12
   5f9a9:      	jne	0x5f9cd <f.2+0x721d>
   5f9ab:      	leaq	-0xc(%r12,%rax), %r14
   5f9b0:      	jmp	0x5faf5 <f.2+0x7345>
   5f9b5:      	movl	$0x1, %ecx
   5f9ba:      	cmpq	$0x0, 0x16086(%rip)     # 0x75a48 <g.3>
   5f9c2:      	jne	0x5fa60 <f.2+0x72b0>
   5f9c8:      	jmp	0x7085f <f.2+0x180af>
   5f9cd:      	movq	%rax, 0x10(%rsp)
   5f9d2:      	leaq	-0xe(%r12), %rsi
   5f9d7:      	movq	$0x0, 0x48(%rsp)
   5f9e0:      	movq	$0x3, 0x30(%rsp)
   5f9e9:      	xorl	%edi, %edi
   5f9eb:      	callq	0x70870 <f.3>
   5f9f0:      	subq	$0x8, %rsp
   5f9f4:      	cmpb	$0x0, 0x16055(%rip)     # 0x75a50 <g.4>
   5f9fb:      	je	0x7085f <f.2+0x180af>
   5fa01:      	cmpq	$0x0, 0x1603f(%rip)     # 0x75a48 <g.3>
   5fa09:      	je	0x7085f <f.2+0x180af>
   5fa0f:      	movq	%rax, %r14
   5fa12:      	leaq	-0xf(%r12), %rsi
   5fa17:      	movq	$0x0, 0x48(%rsp)
   5fa20:      	movq	$0x3, 0x30(%rsp)
   5fa29:      	xorl	%edi, %edi
   5fa2b:      	callq	0x70870 <f.3>
   5fa30:      	subq	$0x8, %rsp
   5fa34:      	cmpb	$0x0, 0x16015(%rip)     # 0x75a50 <g.4>
   5fa3b:      	je	0x7085f <f.2+0x180af>
   5fa41:      	movq	%rax, %rcx
   5fa44:      	cmpq	$0x0, 0x15ffc(%rip)     # 0x75a48 <g.3>
   5fa4c:      	movq	0x10(%rsp), %rax
   5fa51:      	je	0x7085f <f.2+0x180af>
   5fa57:      	addq	%r14, %rcx
   5fa5a:      	cmpq	$0xf, %r12
   5fa5e:      	ja	0x5fa67 <f.2+0x72b7>
   5fa60:      	leaq	-0xe(%r12), %r14
   5fa65:      	jmp	0x5fae2 <f.2+0x7332>
   5fa67:      	movq	%rcx, 0x18(%rsp)
   5fa6c:      	movq	$0x0, 0x48(%rsp)
   5fa75:      	movq	$0x3, 0x30(%rsp)
   5fa7e:      	xorl	%edi, %edi
   5fa80:      	leaq	-0xf(%r12), %rsi
   5fa85:      	callq	0x70870 <f.3>
   5fa8a:      	subq	$0x8, %rsp
   5fa8e:      	cmpb	$0x0, 0x15fbb(%rip)     # 0x75a50 <g.4>
   5fa95:      	je	0x7085f <f.2+0x180af>
   5fa9b:      	movq	%rax, 0x50(%rsp)
   5faa0:      	cmpq	$0x0, 0x15fa0(%rip)     # 0x75a48 <g.3>
   5faa8:      	je	0x7085f <f.2+0x180af>
   5faae:      	leaq	-0x10(%r12), %rsi
   5fab3:      	movq	$0x0, 0x48(%rsp)
   5fabc:      	movq	$0x3, 0x30(%rsp)
   5fac5:      	xorl	%edi, %edi
   5fac7:      	callq	0x70870 <f.3>
   5facc:      	subq	$0x8, %rsp
   5fad0:      	movq	%rax, %r14
   5fad3:      	addq	0x50(%rsp), %r14
   5fad8:      	movq	0x10(%rsp), %rax
   5fadd:      	movq	0x18(%rsp), %rcx
   5fae2:      	cmpb	$0x0, 0x15f67(%rip)     # 0x75a50 <g.4>
   5fae9:      	je	0x7085f <f.2+0x180af>
   5faef:      	addq	%rcx, %r14
   5faf2:      	addq	%rax, %r14
   5faf5:      	cmpq	$0x0, 0x15f4b(%rip)     # 0x75a48 <g.3>
   5fafd:      	je	0x7085f <f.2+0x180af>
   5fb03:      	cmpq	$0xc, %r12
   5fb07:      	ja	0x5fb13 <f.2+0x7363>
   5fb09:      	leaq	-0xb(%r12), %rcx
   5fb0e:      	jmp	0x5fdbe <f.2+0x760e>
   5fb13:      	cmpq	$0xd, %r12
   5fb17:      	jne	0x5fb31 <f.2+0x7381>
   5fb19:      	movl	$0x1, %ecx
   5fb1e:      	cmpq	$0x0, 0x15f22(%rip)     # 0x75a48 <g.3>
   5fb26:      	jne	0x5fc7a <f.2+0x74ca>
   5fb2c:      	jmp	0x7085f <f.2+0x180af>
   5fb31:      	cmpq	$0xf, %r12
   5fb35:      	jb	0x5fc4e <f.2+0x749e>
   5fb3b:      	leaq	-0xe(%r12), %rsi
   5fb40:      	movq	$0x0, 0x48(%rsp)
   5fb49:      	movq	$0x3, 0x30(%rsp)
   5fb52:      	xorl	%edi, %edi
   5fb54:      	callq	0x70870 <f.3>
   5fb59:      	subq	$0x8, %rsp
   5fb5d:      	cmpb	$0x0, 0x15eec(%rip)     # 0x75a50 <g.4>
   5fb64:      	je	0x7085f <f.2+0x180af>
   5fb6a:      	movq	%rax, 0x10(%rsp)
   5fb6f:      	cmpq	$0x0, 0x15ed1(%rip)     # 0x75a48 <g.3>
   5fb77:      	je	0x7085f <f.2+0x180af>
   5fb7d:      	leaq	-0xf(%r12), %rsi
   5fb82:      	movq	$0x0, 0x48(%rsp)
   5fb8b:      	movq	$0x3, 0x30(%rsp)
   5fb94:      	xorl	%edi, %edi
   5fb96:      	callq	0x70870 <f.3>
   5fb9b:      	subq	$0x8, %rsp
   5fb9f:      	cmpb	$0x0, 0x15eaa(%rip)     # 0x75a50 <g.4>
   5fba6:      	je	0x7085f <f.2+0x180af>
   5fbac:      	cmpq	$0x0, 0x15e94(%rip)     # 0x75a48 <g.3>
   5fbb4:      	je	0x7085f <f.2+0x180af>
   5fbba:      	addq	0x10(%rsp), %rax
   5fbbf:      	cmpq	$0xf, %r12
   5fbc3:      	je	0x5fc61 <f.2+0x74b1>
   5fbc9:      	movq	%rax, 0x10(%rsp)
   5fbce:      	movq	$0x0, 0x48(%rsp)
   5fbd7:      	movq	$0x3, 0x30(%rsp)
   5fbe0:      	xorl	%edi, %edi
   5fbe2:      	leaq	-0xf(%r12), %rsi
   5fbe7:      	callq	0x70870 <f.3>
   5fbec:      	subq	$0x8, %rsp
   5fbf0:      	cmpb	$0x0, 0x15e59(%rip)     # 0x75a50 <g.4>
   5fbf7:      	je	0x7085f <f.2+0x180af>
   5fbfd:      	movq	%rax, 0x18(%rsp)
   5fc02:      	cmpq	$0x0, 0x15e3e(%rip)     # 0x75a48 <g.3>
   5fc0a:      	je	0x7085f <f.2+0x180af>
   5fc10:      	leaq	-0x10(%r12), %rsi
   5fc15:      	movq	$0x0, 0x48(%rsp)
   5fc1e:      	movq	$0x3, 0x30(%rsp)
   5fc27:      	xorl	%edi, %edi
   5fc29:      	callq	0x70870 <f.3>
   5fc2e:      	subq	$0x8, %rsp
   5fc32:      	cmpb	$0x0, 0x15e17(%rip)     # 0x75a50 <g.4>
   5fc39:      	je	0x7085f <f.2+0x180af>
   5fc3f:      	movq	%rax, %rcx
   5fc42:      	addq	0x18(%rsp), %rcx
   5fc47:      	addq	0x10(%rsp), %rcx
   5fc4c:      	jmp	0x5fc66 <f.2+0x74b6>
   5fc4e:      	movl	$0x1, %eax
   5fc53:      	cmpq	$0x0, 0x15ded(%rip)     # 0x75a48 <g.3>
   5fc5b:      	je	0x7085f <f.2+0x180af>
   5fc61:      	leaq	-0xe(%r12,%rax), %rcx
   5fc66:      	cmpq	$0x0, 0x15dda(%rip)     # 0x75a48 <g.3>
   5fc6e:      	je	0x7085f <f.2+0x180af>
   5fc74:      	cmpq	$0xe, %r12
   5fc78:      	ja	0x5fc84 <f.2+0x74d4>
   5fc7a:      	leaq	-0xd(%r12), %rdx
   5fc7f:      	jmp	0x5fdbb <f.2+0x760b>
   5fc84:      	cmpq	$0xf, %r12
   5fc88:      	jne	0x5fca2 <f.2+0x74f2>
   5fc8a:      	movl	$0x1, %edx
   5fc8f:      	cmpq	$0x0, 0x15db1(%rip)     # 0x75a48 <g.3>
   5fc97:      	jne	0x5fd39 <f.2+0x7589>
   5fc9d:      	jmp	0x7085f <f.2+0x180af>
   5fca2:      	movq	%rcx, 0x10(%rsp)
   5fca7:      	leaq	-0xf(%r12), %rsi
   5fcac:      	movq	$0x0, 0x48(%rsp)
   5fcb5:      	movq	$0x3, 0x30(%rsp)
   5fcbe:      	xorl	%edi, %edi
   5fcc0:      	callq	0x70870 <f.3>
   5fcc5:      	subq	$0x8, %rsp
   5fcc9:      	cmpb	$0x0, 0x15d80(%rip)     # 0x75a50 <g.4>
   5fcd0:      	je	0x7085f <f.2+0x180af>
   5fcd6:      	movq	%rax, 0x18(%rsp)
   5fcdb:      	cmpq	$0x0, 0x15d65(%rip)     # 0x75a48 <g.3>
   5fce3:      	je	0x7085f <f.2+0x180af>
   5fce9:      	leaq	-0x10(%r12), %rsi
   5fcee:      	movq	$0x0, 0x48(%rsp)
   5fcf7:      	movq	$0x3, 0x30(%rsp)
   5fd00:      	xorl	%edi, %edi
   5fd02:      	callq	0x70870 <f.3>
   5fd07:      	subq	$0x8, %rsp
   5fd0b:      	cmpb	$0x0, 0x15d3e(%rip)     # 0x75a50 <g.4>
   5fd12:      	je	0x7085f <f.2+0x180af>
   5fd18:      	cmpq	$0x0, 0x15d28(%rip)     # 0x75a48 <g.3>
   5fd20:      	movq	0x10(%rsp), %rcx
   5fd25:      	je	0x7085f <f.2+0x180af>
   5fd2b:      	movq	%rax, %rdx
   5fd2e:      	addq	0x18(%rsp), %rdx
   5fd33:      	cmpq	$0x10, %r12
   5fd37:      	ja	0x5fd40 <f.2+0x7590>
   5fd39:      	leaq	-0xf(%r12), %rax
   5fd3e:      	jmp	0x5fdb8 <f.2+0x7608>
   5fd40:      	movq	%rdx, 0x18(%rsp)
   5fd45:      	movq	$0x0, 0x48(%rsp)
   5fd4e:      	movq	$0x3, 0x30(%rsp)
   5fd57:      	xorl	%edi, %edi
   5fd59:      	leaq	-0x10(%r12), %rsi
   5fd5e:      	callq	0x70870 <f.3>
   5fd63:      	subq	$0x8, %rsp
   5fd67:      	cmpb	$0x0, 0x15ce2(%rip)     # 0x75a50 <g.4>
   5fd6e:      	je	0x7085f <f.2+0x180af>
   5fd74:      	movq	%rax, 0x50(%rsp)
   5fd79:      	cmpq	$0x0, 0x15cc7(%rip)     # 0x75a48 <g.3>
   5fd81:      	je	0x7085f <f.2+0x180af>
   5fd87:      	leaq	-0x11(%r12), %rsi
   5fd8c:      	movq	$0x0, 0x48(%rsp)
   5fd95:      	movq	$0x3, 0x30(%rsp)
   5fd9e:      	xorl	%edi, %edi
   5fda0:      	callq	0x70870 <f.3>
   5fda5:      	subq	$0x8, %rsp
   5fda9:      	addq	0x50(%rsp), %rax
   5fdae:      	movq	0x10(%rsp), %rcx
   5fdb3:      	movq	0x18(%rsp), %rdx
   5fdb8:      	addq	%rax, %rdx
   5fdbb:      	addq	%rdx, %rcx
   5fdbe:      	addq	%rcx, %r14
   5fdc1:      	cmpb	$0x0, 0x15c88(%rip)     # 0x75a50 <g.4>
   5fdc8:      	je	0x7085f <f.2+0x180af>
   5fdce:      	addq	%r13, %r14
   5fdd1:      	addq	%r15, %r14
   5fdd4:      	cmpq	$0x0, 0x15c6c(%rip)     # 0x75a48 <g.3>
   5fddc:      	leaq	0x68(%rsp), %r15
   5fde1:      	je	0x7085f <f.2+0x180af>
   5fde7:      	cmpq	$0x8, %r12
   5fdeb:      	je	0x5fe0b <f.2+0x765b>
   5fded:      	cmpq	$0x7, %r12
   5fdf1:      	jne	0x5fe24 <f.2+0x7674>
   5fdf3:      	leaq	-0x6(%r12,%r14), %r13
   5fdf8:      	cmpq	$0x0, 0x15c48(%rip)     # 0x75a48 <g.3>
   5fe00:      	jne	0x609ec <f.2+0x823c>
   5fe06:      	jmp	0x7085f <f.2+0x180af>
   5fe0b:      	movl	$0x1, %r15d
   5fe11:      	cmpq	$0x0, 0x15c2f(%rip)     # 0x75a48 <g.3>
   5fe19:      	jne	0x609c1 <f.2+0x8211>
   5fe1f:      	jmp	0x7085f <f.2+0x180af>
   5fe24:      	cmpq	$0xa, %r12
   5fe28:      	jb	0x5fe45 <f.2+0x7695>
   5fe2a:      	jne	0x5fe5e <f.2+0x76ae>
   5fe2c:      	movl	$0x1, %r15d
   5fe32:      	cmpq	$0x0, 0x15c0e(%rip)     # 0x75a48 <g.3>
   5fe3a:      	jne	0x6010a <f.2+0x795a>
   5fe40:      	jmp	0x7085f <f.2+0x180af>
   5fe45:      	movl	$0x1, %r13d
   5fe4b:      	cmpq	$0x0, 0x15bf5(%rip)     # 0x75a48 <g.3>
   5fe53:      	jne	0x603eb <f.2+0x7c3b>
   5fe59:      	jmp	0x7085f <f.2+0x180af>
   5fe5e:      	cmpq	$0xc, %r12
   5fe62:      	jb	0x5fe7f <f.2+0x76cf>
   5fe64:      	jne	0x5fe98 <f.2+0x76e8>
   5fe66:      	movl	$0x1, %r15d
   5fe6c:      	cmpq	$0x0, 0x15bd4(%rip)     # 0x75a48 <g.3>
   5fe74:      	jne	0x5ff21 <f.2+0x7771>
   5fe7a:      	jmp	0x7085f <f.2+0x180af>
   5fe7f:      	movl	$0x1, %r13d
   5fe85:      	cmpq	$0x0, 0x15bbb(%rip)     # 0x75a48 <g.3>
   5fe8d:      	jne	0x5ffbe <f.2+0x780e>
   5fe93:      	jmp	0x7085f <f.2+0x180af>
   5fe98:      	leaq	-0xc(%r12), %rsi
   5fe9d:      	movq	$0x0, 0x48(%rsp)
   5fea6:      	movq	$0x3, 0x30(%rsp)
   5feaf:      	xorl	%edi, %edi
   5feb1:      	callq	0x70870 <f.3>
   5feb6:      	subq	$0x8, %rsp
   5feba:      	cmpb	$0x0, 0x15b8f(%rip)     # 0x75a50 <g.4>
   5fec1:      	je	0x7085f <f.2+0x180af>
   5fec7:      	cmpq	$0x0, 0x15b79(%rip)     # 0x75a48 <g.3>
   5fecf:      	je	0x7085f <f.2+0x180af>
   5fed5:      	movq	%rax, %r13
   5fed8:      	leaq	-0xd(%r12), %rsi
   5fedd:      	movq	$0x0, 0x48(%rsp)
   5fee6:      	movq	$0x3, 0x30(%rsp)
   5feef:      	xorl	%edi, %edi
   5fef1:      	callq	0x70870 <f.3>
   5fef6:      	subq	$0x8, %rsp
   5fefa:      	cmpb	$0x0, 0x15b4f(%rip)     # 0x75a50 <g.4>
   5ff01:      	je	0x7085f <f.2+0x180af>
   5ff07:      	cmpq	$0x0, 0x15b39(%rip)     # 0x75a48 <g.3>
   5ff0f:      	je	0x7085f <f.2+0x180af>
   5ff15:      	movq	%rax, %r15
   5ff18:      	addq	%r13, %r15
   5ff1b:      	cmpq	$0xd, %r12
   5ff1f:      	ja	0x5ff28 <f.2+0x7778>
   5ff21:      	leaq	-0xc(%r12,%r15), %r13
   5ff26:      	jmp	0x5ffa4 <f.2+0x77f4>
   5ff28:      	movq	$0x0, 0x48(%rsp)
   5ff31:      	movq	$0x3, 0x30(%rsp)
   5ff3a:      	xorl	%edi, %edi
   5ff3c:      	leaq	-0xd(%r12), %rsi
   5ff41:      	callq	0x70870 <f.3>
   5ff46:      	subq	$0x8, %rsp
   5ff4a:      	cmpb	$0x0, 0x15aff(%rip)     # 0x75a50 <g.4>
   5ff51:      	je	0x7085f <f.2+0x180af>
   5ff57:      	movq	%rax, 0x10(%rsp)
   5ff5c:      	cmpq	$0x0, 0x15ae4(%rip)     # 0x75a48 <g.3>
   5ff64:      	je	0x7085f <f.2+0x180af>
   5ff6a:      	leaq	-0xe(%r12), %rsi
   5ff6f:      	movq	$0x0, 0x48(%rsp)
   5ff78:      	movq	$0x3, 0x30(%rsp)
   5ff81:      	xorl	%edi, %edi
   5ff83:      	callq	0x70870 <f.3>
   5ff88:      	subq	$0x8, %rsp
   5ff8c:      	cmpb	$0x0, 0x15abd(%rip)     # 0x75a50 <g.4>
   5ff93:      	je	0x7085f <f.2+0x180af>
   5ff99:      	movq	%rax, %r13
   5ff9c:      	addq	0x10(%rsp), %r13
   5ffa1:      	addq	%r15, %r13
   5ffa4:      	cmpq	$0x0, 0x15a9c(%rip)     # 0x75a48 <g.3>
   5ffac:      	je	0x7085f <f.2+0x180af>
   5ffb2:      	cmpq	$0xd, %r12
   5ffb6:      	je	0x5ffc8 <f.2+0x7818>
   5ffb8:      	cmpq	$0xc, %r12
   5ffbc:      	jne	0x5ffe0 <f.2+0x7830>
   5ffbe:      	leaq	-0xb(%r12,%r13), %r15
   5ffc3:      	jmp	0x600f6 <f.2+0x7946>
   5ffc8:      	movl	$0x1, %eax
   5ffcd:      	cmpq	$0x0, 0x15a73(%rip)     # 0x75a48 <g.3>
   5ffd5:      	jne	0x60066 <f.2+0x78b6>
   5ffdb:      	jmp	0x7085f <f.2+0x180af>
   5ffe0:      	leaq	-0xd(%r12), %rsi
   5ffe5:      	movq	$0x0, 0x48(%rsp)
   5ffee:      	movq	$0x3, 0x30(%rsp)
   5fff7:      	xorl	%edi, %edi
   5fff9:      	callq	0x70870 <f.3>
   5fffe:      	subq	$0x8, %rsp
   60002:      	cmpb	$0x0, 0x15a47(%rip)     # 0x75a50 <g.4>
   60009:      	je	0x7085f <f.2+0x180af>
   6000f:      	cmpq	$0x0, 0x15a31(%rip)     # 0x75a48 <g.3>
   60017:      	je	0x7085f <f.2+0x180af>
   6001d:      	movq	%rax, %r15
   60020:      	leaq	-0xe(%r12), %rsi
   60025:      	movq	$0x0, 0x48(%rsp)
   6002e:      	movq	$0x3, 0x30(%rsp)
   60037:      	xorl	%edi, %edi
   60039:      	callq	0x70870 <f.3>
   6003e:      	subq	$0x8, %rsp
   60042:      	cmpb	$0x0, 0x15a07(%rip)     # 0x75a50 <g.4>
   60049:      	je	0x7085f <f.2+0x180af>
   6004f:      	cmpq	$0x0, 0x159f1(%rip)     # 0x75a48 <g.3>
   60057:      	je	0x7085f <f.2+0x180af>
   6005d:      	addq	%r15, %rax
   60060:      	cmpq	$0xe, %r12
   60064:      	ja	0x6006d <f.2+0x78bd>
   60066:      	leaq	-0xd(%r12), %r15
   6006b:      	jmp	0x600e3 <f.2+0x7933>
   6006d:      	movq	%rax, 0x10(%rsp)
   60072:      	movq	$0x0, 0x48(%rsp)
   6007b:      	movq	$0x3, 0x30(%rsp)
   60084:      	xorl	%edi, %edi
   60086:      	leaq	-0xe(%r12), %rsi
   6008b:      	callq	0x70870 <f.3>
   60090:      	subq	$0x8, %rsp
   60094:      	cmpb	$0x0, 0x159b5(%rip)     # 0x75a50 <g.4>
   6009b:      	je	0x7085f <f.2+0x180af>
   600a1:      	movq	%rax, 0x18(%rsp)
   600a6:      	cmpq	$0x0, 0x1599a(%rip)     # 0x75a48 <g.3>
   600ae:      	je	0x7085f <f.2+0x180af>
   600b4:      	leaq	-0xf(%r12), %rsi
   600b9:      	movq	$0x0, 0x48(%rsp)
   600c2:      	movq	$0x3, 0x30(%rsp)
   600cb:      	xorl	%edi, %edi
   600cd:      	callq	0x70870 <f.3>
   600d2:      	subq	$0x8, %rsp
   600d6:      	movq	%rax, %r15
   600d9:      	addq	0x18(%rsp), %r15
   600de:      	movq	0x10(%rsp), %rax
   600e3:      	cmpb	$0x0, 0x15966(%rip)     # 0x75a50 <g.4>
   600ea:      	je	0x7085f <f.2+0x180af>
   600f0:      	addq	%rax, %r15
   600f3:      	addq	%r13, %r15
   600f6:      	cmpq	$0x0, 0x1594a(%rip)     # 0x75a48 <g.3>
   600fe:      	je	0x7085f <f.2+0x180af>
   60104:      	cmpq	$0xb, %r12
   60108:      	ja	0x60122 <f.2+0x7972>
   6010a:      	leaq	-0xa(%r12,%r15), %r13
   6010f:      	cmpq	$0x0, 0x15931(%rip)     # 0x75a48 <g.3>
   60117:      	jne	0x603df <f.2+0x7c2f>
   6011d:      	jmp	0x7085f <f.2+0x180af>
   60122:      	cmpq	$0xc, %r12
   60126:      	jne	0x60140 <f.2+0x7990>
   60128:      	movl	$0x1, %ecx
   6012d:      	cmpq	$0x0, 0x15913(%rip)     # 0x75a48 <g.3>
   60135:      	jne	0x60286 <f.2+0x7ad6>
   6013b:      	jmp	0x7085f <f.2+0x180af>
   60140:      	cmpq	$0xe, %r12
   60144:      	jb	0x60259 <f.2+0x7aa9>
   6014a:      	leaq	-0xd(%r12), %rsi
   6014f:      	movq	$0x0, 0x48(%rsp)
   60158:      	movq	$0x3, 0x30(%rsp)
   60161:      	xorl	%edi, %edi
   60163:      	callq	0x70870 <f.3>
   60168:      	subq	$0x8, %rsp
   6016c:      	cmpb	$0x0, 0x158dd(%rip)     # 0x75a50 <g.4>
   60173:      	je	0x7085f <f.2+0x180af>
   60179:      	movq	%rax, 0x10(%rsp)
   6017e:      	cmpq	$0x0, 0x158c2(%rip)     # 0x75a48 <g.3>
   60186:      	je	0x7085f <f.2+0x180af>
   6018c:      	leaq	-0xe(%r12), %rsi
   60191:      	movq	$0x0, 0x48(%rsp)
   6019a:      	movq	$0x3, 0x30(%rsp)
   601a3:      	xorl	%edi, %edi
   601a5:      	callq	0x70870 <f.3>
   601aa:      	subq	$0x8, %rsp
   601ae:      	cmpb	$0x0, 0x1589b(%rip)     # 0x75a50 <g.4>
   601b5:      	je	0x7085f <f.2+0x180af>
   601bb:      	cmpq	$0x0, 0x15885(%rip)     # 0x75a48 <g.3>
   601c3:      	je	0x7085f <f.2+0x180af>
   601c9:      	movq	%rax, %r13
   601cc:      	addq	0x10(%rsp), %r13
   601d1:      	cmpq	$0xe, %r12
   601d5:      	je	0x6026d <f.2+0x7abd>
   601db:      	movq	$0x0, 0x48(%rsp)
   601e4:      	movq	$0x3, 0x30(%rsp)
   601ed:      	xorl	%edi, %edi
   601ef:      	leaq	-0xe(%r12), %rsi
   601f4:      	callq	0x70870 <f.3>
   601f9:      	subq	$0x8, %rsp
   601fd:      	cmpb	$0x0, 0x1584c(%rip)     # 0x75a50 <g.4>
   60204:      	je	0x7085f <f.2+0x180af>
   6020a:      	movq	%rax, 0x10(%rsp)
   6020f:      	cmpq	$0x0, 0x15831(%rip)     # 0x75a48 <g.3>
   60217:      	je	0x7085f <f.2+0x180af>
   6021d:      	leaq	-0xf(%r12), %rsi
   60222:      	movq	$0x0, 0x48(%rsp)
   6022b:      	movq	$0x3, 0x30(%rsp)
   60234:      	xorl	%edi, %edi
   60236:      	callq	0x70870 <f.3>
   6023b:      	subq	$0x8, %rsp
   6023f:      	cmpb	$0x0, 0x1580a(%rip)     # 0x75a50 <g.4>
   60246:      	je	0x7085f <f.2+0x180af>
   6024c:      	movq	%rax, %rcx
   6024f:      	addq	0x10(%rsp), %rcx
   60254:      	addq	%r13, %rcx
   60257:      	jmp	0x60272 <f.2+0x7ac2>
   60259:      	movl	$0x1, %r13d
   6025f:      	cmpq	$0x0, 0x157e1(%rip)     # 0x75a48 <g.3>
   60267:      	je	0x7085f <f.2+0x180af>
   6026d:      	leaq	-0xd(%r12,%r13), %rcx
   60272:      	cmpq	$0x0, 0x157ce(%rip)     # 0x75a48 <g.3>
   6027a:      	je	0x7085f <f.2+0x180af>
   60280:      	cmpq	$0xd, %r12
   60284:      	ja	0x60290 <f.2+0x7ae0>
   60286:      	leaq	-0xc(%r12), %r13
   6028b:      	jmp	0x603be <f.2+0x7c0e>
   60290:      	cmpq	$0xe, %r12
   60294:      	jne	0x602af <f.2+0x7aff>
   60296:      	movl	$0x1, %r13d
   6029c:      	cmpq	$0x0, 0x157a4(%rip)     # 0x75a48 <g.3>
   602a4:      	jne	0x60346 <f.2+0x7b96>
   602aa:      	jmp	0x7085f <f.2+0x180af>
   602af:      	movq	%rcx, 0x10(%rsp)
   602b4:      	leaq	-0xe(%r12), %rsi
   602b9:      	movq	$0x0, 0x48(%rsp)
   602c2:      	movq	$0x3, 0x30(%rsp)
   602cb:      	xorl	%edi, %edi
   602cd:      	callq	0x70870 <f.3>
   602d2:      	subq	$0x8, %rsp
   602d6:      	cmpb	$0x0, 0x15773(%rip)     # 0x75a50 <g.4>
   602dd:      	je	0x7085f <f.2+0x180af>
   602e3:      	movq	%rax, 0x18(%rsp)
   602e8:      	cmpq	$0x0, 0x15758(%rip)     # 0x75a48 <g.3>
   602f0:      	je	0x7085f <f.2+0x180af>
   602f6:      	leaq	-0xf(%r12), %rsi
   602fb:      	movq	$0x0, 0x48(%rsp)
   60304:      	movq	$0x3, 0x30(%rsp)
   6030d:      	xorl	%edi, %edi
   6030f:      	callq	0x70870 <f.3>
   60314:      	subq	$0x8, %rsp
   60318:      	cmpb	$0x0, 0x15731(%rip)     # 0x75a50 <g.4>
   6031f:      	je	0x7085f <f.2+0x180af>
   60325:      	cmpq	$0x0, 0x1571b(%rip)     # 0x75a48 <g.3>
   6032d:      	movq	0x10(%rsp), %rcx
   60332:      	je	0x7085f <f.2+0x180af>
   60338:      	movq	%rax, %r13
   6033b:      	addq	0x18(%rsp), %r13
   60340:      	cmpq	$0xf, %r12
   60344:      	ja	0x6034d <f.2+0x7b9d>
   60346:      	leaq	-0xe(%r12), %rax
   6034b:      	jmp	0x603bb <f.2+0x7c0b>
   6034d:      	movq	$0x0, 0x48(%rsp)
   60356:      	movq	$0x3, 0x30(%rsp)
   6035f:      	xorl	%edi, %edi
   60361:      	leaq	-0xf(%r12), %rsi
   60366:      	callq	0x70870 <f.3>
   6036b:      	subq	$0x8, %rsp
   6036f:      	cmpb	$0x0, 0x156da(%rip)     # 0x75a50 <g.4>
   60376:      	je	0x7085f <f.2+0x180af>
   6037c:      	movq	%rax, 0x18(%rsp)
   60381:      	cmpq	$0x0, 0x156bf(%rip)     # 0x75a48 <g.3>
   60389:      	je	0x7085f <f.2+0x180af>
   6038f:      	leaq	-0x10(%r12), %rsi
   60394:      	movq	$0x0, 0x48(%rsp)
   6039d:      	movq	$0x3, 0x30(%rsp)
   603a6:      	xorl	%edi, %edi
   603a8:      	callq	0x70870 <f.3>
   603ad:      	subq	$0x8, %rsp
   603b1:      	addq	0x18(%rsp), %rax
   603b6:      	movq	0x10(%rsp), %rcx
   603bb:      	addq	%rax, %r13
   603be:      	cmpb	$0x0, 0x1568b(%rip)     # 0x75a50 <g.4>
   603c5:      	je	0x7085f <f.2+0x180af>
   603cb:      	addq	%rcx, %r13
   603ce:      	addq	%r15, %r13
   603d1:      	cmpq	$0x0, 0x1566f(%rip)     # 0x75a48 <g.3>
   603d9:      	je	0x7085f <f.2+0x180af>
   603df:      	cmpq	$0xb, %r12
   603e3:      	je	0x60403 <f.2+0x7c53>
   603e5:      	cmpq	$0xa, %r12
   603e9:      	jne	0x6041b <f.2+0x7c6b>
   603eb:      	leaq	-0x9(%r12,%r13), %r15
   603f0:      	cmpq	$0x0, 0x15650(%rip)     # 0x75a48 <g.3>
   603f8:      	jne	0x609b7 <f.2+0x8207>
   603fe:      	jmp	0x7085f <f.2+0x180af>
   60403:      	movl	$0x1, %ecx
   60408:      	cmpq	$0x0, 0x15638(%rip)     # 0x75a48 <g.3>
   60410:      	jne	0x606d5 <f.2+0x7f25>
   60416:      	jmp	0x7085f <f.2+0x180af>
   6041b:      	cmpq	$0xd, %r12
   6041f:      	jb	0x6043c <f.2+0x7c8c>
   60421:      	jne	0x60454 <f.2+0x7ca4>
   60423:      	movl	$0x1, %r15d
   60429:      	cmpq	$0x0, 0x15617(%rip)     # 0x75a48 <g.3>
   60431:      	jne	0x604e1 <f.2+0x7d31>
   60437:      	jmp	0x7085f <f.2+0x180af>
   6043c:      	movl	$0x1, %eax
   60441:      	cmpq	$0x0, 0x155ff(%rip)     # 0x75a48 <g.3>
   60449:      	jne	0x6057b <f.2+0x7dcb>
   6044f:      	jmp	0x7085f <f.2+0x180af>
   60454:      	leaq	-0xd(%r12), %rsi
   60459:      	movq	$0x0, 0x48(%rsp)
   60462:      	movq	$0x3, 0x30(%rsp)
   6046b:      	xorl	%edi, %edi
   6046d:      	callq	0x70870 <f.3>
   60472:      	subq	$0x8, %rsp
   60476:      	cmpb	$0x0, 0x155d3(%rip)     # 0x75a50 <g.4>
   6047d:      	je	0x7085f <f.2+0x180af>
   60483:      	movq	%rax, 0x10(%rsp)
   60488:      	cmpq	$0x0, 0x155b8(%rip)     # 0x75a48 <g.3>
   60490:      	je	0x7085f <f.2+0x180af>
   60496:      	leaq	-0xe(%r12), %rsi
   6049b:      	movq	$0x0, 0x48(%rsp)
   604a4:      	movq	$0x3, 0x30(%rsp)
   604ad:      	xorl	%edi, %edi
   604af:      	callq	0x70870 <f.3>
   604b4:      	subq	$0x8, %rsp
   604b8:      	cmpb	$0x0, 0x15591(%rip)     # 0x75a50 <g.4>
   604bf:      	je	0x7085f <f.2+0x180af>
   604c5:      	cmpq	$0x0, 0x1557b(%rip)     # 0x75a48 <g.3>
   604cd:      	je	0x7085f <f.2+0x180af>
   604d3:      	movq	%rax, %r15
   604d6:      	addq	0x10(%rsp), %r15
   604db:      	cmpq	$0xe, %r12
   604df:      	ja	0x604e8 <f.2+0x7d38>
   604e1:      	leaq	-0xd(%r12,%r15), %rax
   604e6:      	jmp	0x60561 <f.2+0x7db1>
   604e8:      	movq	$0x0, 0x48(%rsp)
   604f1:      	movq	$0x3, 0x30(%rsp)
   604fa:      	xorl	%edi, %edi
   604fc:      	leaq	-0xe(%r12), %rsi
   60501:      	callq	0x70870 <f.3>
   60506:      	subq	$0x8, %rsp
   6050a:      	cmpb	$0x0, 0x1553f(%rip)     # 0x75a50 <g.4>
   60511:      	je	0x7085f <f.2+0x180af>
   60517:      	movq	%rax, 0x10(%rsp)
   6051c:      	cmpq	$0x0, 0x15524(%rip)     # 0x75a48 <g.3>
   60524:      	je	0x7085f <f.2+0x180af>
   6052a:      	leaq	-0xf(%r12), %rsi
   6052f:      	movq	$0x0, 0x48(%rsp)
   60538:      	movq	$0x3, 0x30(%rsp)
   60541:      	xorl	%edi, %edi
   60543:      	callq	0x70870 <f.3>
   60548:      	subq	$0x8, %rsp
   6054c:      	cmpb	$0x0, 0x154fd(%rip)     # 0x75a50 <g.4>
   60553:      	je	0x7085f <f.2+0x180af>
   60559:      	addq	0x10(%rsp), %rax
   6055e:      	addq	%r15, %rax
   60561:      	cmpq	$0x0, 0x154df(%rip)     # 0x75a48 <g.3>
   60569:      	je	0x7085f <f.2+0x180af>
   6056f:      	cmpq	$0xe, %r12
   60573:      	je	0x60585 <f.2+0x7dd5>
   60575:      	cmpq	$0xd, %r12
   60579:      	jne	0x6059d <f.2+0x7ded>
   6057b:      	leaq	-0xc(%r12,%rax), %rcx
   60580:      	jmp	0x606c1 <f.2+0x7f11>
   60585:      	movl	$0x1, %edx
   6058a:      	cmpq	$0x0, 0x154b6(%rip)     # 0x75a48 <g.3>
   60592:      	jne	0x60630 <f.2+0x7e80>
   60598:      	jmp	0x7085f <f.2+0x180af>
   6059d:      	movq	%rax, 0x10(%rsp)
   605a2:      	leaq	-0xe(%r12), %rsi
   605a7:      	movq	$0x0, 0x48(%rsp)
   605b0:      	movq	$0x3, 0x30(%rsp)
   605b9:      	xorl	%edi, %edi
   605bb:      	callq	0x70870 <f.3>
   605c0:      	subq	$0x8, %rsp
   605c4:      	cmpb	$0x0, 0x15485(%rip)     # 0x75a50 <g.4>
   605cb:      	je	0x7085f <f.2+0x180af>
   605d1:      	cmpq	$0x0, 0x1546f(%rip)     # 0x75a48 <g.3>
   605d9:      	je	0x7085f <f.2+0x180af>
   605df:      	movq	%rax, %r15
   605e2:      	leaq	-0xf(%r12), %rsi
   605e7:      	movq	$0x0, 0x48(%rsp)
   605f0:      	movq	$0x3, 0x30(%rsp)
   605f9:      	xorl	%edi, %edi
   605fb:      	callq	0x70870 <f.3>
   60600:      	subq	$0x8, %rsp
   60604:      	cmpb	$0x0, 0x15445(%rip)     # 0x75a50 <g.4>
   6060b:      	je	0x7085f <f.2+0x180af>
   60611:      	movq	%rax, %rdx
   60614:      	cmpq	$0x0, 0x1542c(%rip)     # 0x75a48 <g.3>
   6061c:      	movq	0x10(%rsp), %rax
   60621:      	je	0x7085f <f.2+0x180af>
   60627:      	addq	%r15, %rdx
   6062a:      	cmpq	$0xf, %r12
   6062e:      	ja	0x60637 <f.2+0x7e87>
   60630:      	leaq	-0xe(%r12), %rcx
   60635:      	jmp	0x606ae <f.2+0x7efe>
   60637:      	movq	%rdx, 0x18(%rsp)
   6063c:      	movq	$0x0, 0x48(%rsp)
   60645:      	movq	$0x3, 0x30(%rsp)
   6064e:      	xorl	%edi, %edi
   60650:      	leaq	-0xf(%r12), %rsi
   60655:      	callq	0x70870 <f.3>
   6065a:      	subq	$0x8, %rsp
   6065e:      	cmpb	$0x0, 0x153eb(%rip)     # 0x75a50 <g.4>
   60665:      	je	0x7085f <f.2+0x180af>
   6066b:      	cmpq	$0x0, 0x153d5(%rip)     # 0x75a48 <g.3>
   60673:      	je	0x7085f <f.2+0x180af>
   60679:      	movq	%rax, %r15
   6067c:      	leaq	-0x10(%r12), %rsi
   60681:      	movq	$0x0, 0x48(%rsp)
   6068a:      	movq	$0x3, 0x30(%rsp)
   60693:      	xorl	%edi, %edi
   60695:      	callq	0x70870 <f.3>
   6069a:      	subq	$0x8, %rsp
   6069e:      	movq	%rax, %rcx
   606a1:      	addq	%r15, %rcx
   606a4:      	movq	0x10(%rsp), %rax
   606a9:      	movq	0x18(%rsp), %rdx
   606ae:      	cmpb	$0x0, 0x1539b(%rip)     # 0x75a50 <g.4>
   606b5:      	je	0x7085f <f.2+0x180af>
   606bb:      	addq	%rdx, %rcx
   606be:      	addq	%rax, %rcx
   606c1:      	cmpq	$0x0, 0x1537f(%rip)     # 0x75a48 <g.3>
   606c9:      	je	0x7085f <f.2+0x180af>
   606cf:      	cmpq	$0xc, %r12
   606d3:      	ja	0x606df <f.2+0x7f2f>
   606d5:      	leaq	-0xb(%r12), %r15
   606da:      	jmp	0x60996 <f.2+0x81e6>
   606df:      	cmpq	$0xd, %r12
   606e3:      	jne	0x606fe <f.2+0x7f4e>
   606e5:      	movl	$0x1, %r15d
   606eb:      	cmpq	$0x0, 0x15355(%rip)     # 0x75a48 <g.3>
   606f3:      	jne	0x60852 <f.2+0x80a2>
   606f9:      	jmp	0x7085f <f.2+0x180af>
   606fe:      	cmpq	$0xf, %r12
   60702:      	jb	0x60826 <f.2+0x8076>
   60708:      	movq	%rcx, 0x10(%rsp)
   6070d:      	leaq	-0xe(%r12), %rsi
   60712:      	movq	$0x0, 0x48(%rsp)
   6071b:      	movq	$0x3, 0x30(%rsp)
   60724:      	xorl	%edi, %edi
   60726:      	callq	0x70870 <f.3>
   6072b:      	subq	$0x8, %rsp
   6072f:      	cmpb	$0x0, 0x1531a(%rip)     # 0x75a50 <g.4>
   60736:      	je	0x7085f <f.2+0x180af>
   6073c:      	cmpq	$0x0, 0x15304(%rip)     # 0x75a48 <g.3>
   60744:      	je	0x7085f <f.2+0x180af>
   6074a:      	movq	%rax, %r15
   6074d:      	leaq	-0xf(%r12), %rsi
   60752:      	movq	$0x0, 0x48(%rsp)
   6075b:      	movq	$0x3, 0x30(%rsp)
   60764:      	xorl	%edi, %edi
   60766:      	callq	0x70870 <f.3>
   6076b:      	subq	$0x8, %rsp
   6076f:      	cmpb	$0x0, 0x152da(%rip)     # 0x75a50 <g.4>
   60776:      	je	0x7085f <f.2+0x180af>
   6077c:      	cmpq	$0x0, 0x152c4(%rip)     # 0x75a48 <g.3>
   60784:      	movq	0x10(%rsp), %rcx
   60789:      	je	0x7085f <f.2+0x180af>
   6078f:      	addq	%r15, %rax
   60792:      	cmpq	$0xf, %r12
   60796:      	je	0x60839 <f.2+0x8089>
   6079c:      	movq	%rax, 0x18(%rsp)
   607a1:      	movq	$0x0, 0x48(%rsp)
   607aa:      	movq	$0x3, 0x30(%rsp)
   607b3:      	xorl	%edi, %edi
   607b5:      	leaq	-0xf(%r12), %rsi
   607ba:      	callq	0x70870 <f.3>
   607bf:      	subq	$0x8, %rsp
   607c3:      	cmpb	$0x0, 0x15286(%rip)     # 0x75a50 <g.4>
   607ca:      	je	0x7085f <f.2+0x180af>
   607d0:      	movq	%rax, 0x50(%rsp)
   607d5:      	cmpq	$0x0, 0x1526b(%rip)     # 0x75a48 <g.3>
   607dd:      	je	0x7085f <f.2+0x180af>
   607e3:      	leaq	-0x10(%r12), %rsi
   607e8:      	movq	$0x0, 0x48(%rsp)
   607f1:      	movq	$0x3, 0x30(%rsp)
   607fa:      	xorl	%edi, %edi
   607fc:      	callq	0x70870 <f.3>
   60801:      	subq	$0x8, %rsp
   60805:      	cmpb	$0x0, 0x15244(%rip)     # 0x75a50 <g.4>
   6080c:      	je	0x7085f <f.2+0x180af>
   60812:      	movq	%rax, %r15
   60815:      	addq	0x50(%rsp), %r15
   6081a:      	addq	0x18(%rsp), %r15
   6081f:      	movq	0x10(%rsp), %rcx
   60824:      	jmp	0x6083e <f.2+0x808e>
   60826:      	movl	$0x1, %eax
   6082b:      	cmpq	$0x0, 0x15215(%rip)     # 0x75a48 <g.3>
   60833:      	je	0x7085f <f.2+0x180af>
   60839:      	leaq	-0xe(%r12,%rax), %r15
   6083e:      	cmpq	$0x0, 0x15202(%rip)     # 0x75a48 <g.3>
   60846:      	je	0x7085f <f.2+0x180af>
   6084c:      	cmpq	$0xe, %r12
   60850:      	ja	0x6085c <f.2+0x80ac>
   60852:      	leaq	-0xd(%r12), %rdx
   60857:      	jmp	0x60993 <f.2+0x81e3>
   6085c:      	cmpq	$0xf, %r12
   60860:      	jne	0x6087a <f.2+0x80ca>
   60862:      	movl	$0x1, %edx
   60867:      	cmpq	$0x0, 0x151d9(%rip)     # 0x75a48 <g.3>
   6086f:      	jne	0x60911 <f.2+0x8161>
   60875:      	jmp	0x7085f <f.2+0x180af>
   6087a:      	movq	%rcx, 0x10(%rsp)
   6087f:      	leaq	-0xf(%r12), %rsi
   60884:      	movq	$0x0, 0x48(%rsp)
   6088d:      	movq	$0x3, 0x30(%rsp)
   60896:      	xorl	%edi, %edi
   60898:      	callq	0x70870 <f.3>
   6089d:      	subq	$0x8, %rsp
   608a1:      	cmpb	$0x0, 0x151a8(%rip)     # 0x75a50 <g.4>
   608a8:      	je	0x7085f <f.2+0x180af>
   608ae:      	movq	%rax, 0x18(%rsp)
   608b3:      	cmpq	$0x0, 0x1518d(%rip)     # 0x75a48 <g.3>
   608bb:      	je	0x7085f <f.2+0x180af>
   608c1:      	leaq	-0x10(%r12), %rsi
   608c6:      	movq	$0x0, 0x48(%rsp)
   608cf:      	movq	$0x3, 0x30(%rsp)
   608d8:      	xorl	%edi, %edi
   608da:      	callq	0x70870 <f.3>
   608df:      	subq	$0x8, %rsp
   608e3:      	cmpb	$0x0, 0x15166(%rip)     # 0x75a50 <g.4>
   608ea:      	je	0x7085f <f.2+0x180af>
   608f0:      	cmpq	$0x0, 0x15150(%rip)     # 0x75a48 <g.3>
   608f8:      	movq	0x10(%rsp), %rcx
   608fd:      	je	0x7085f <f.2+0x180af>
   60903:      	movq	%rax, %rdx
   60906:      	addq	0x18(%rsp), %rdx
   6090b:      	cmpq	$0x10, %r12
   6090f:      	ja	0x60918 <f.2+0x8168>
   60911:      	leaq	-0xf(%r12), %rax
   60916:      	jmp	0x60990 <f.2+0x81e0>
   60918:      	movq	%rdx, 0x18(%rsp)
   6091d:      	movq	$0x0, 0x48(%rsp)
   60926:      	movq	$0x3, 0x30(%rsp)
   6092f:      	xorl	%edi, %edi
   60931:      	leaq	-0x10(%r12), %rsi
   60936:      	callq	0x70870 <f.3>
   6093b:      	subq	$0x8, %rsp
   6093f:      	cmpb	$0x0, 0x1510a(%rip)     # 0x75a50 <g.4>
   60946:      	je	0x7085f <f.2+0x180af>
   6094c:      	movq	%rax, 0x50(%rsp)
   60951:      	cmpq	$0x0, 0x150ef(%rip)     # 0x75a48 <g.3>
   60959:      	je	0x7085f <f.2+0x180af>
   6095f:      	leaq	-0x11(%r12), %rsi
   60964:      	movq	$0x0, 0x48(%rsp)
   6096d:      	movq	$0x3, 0x30(%rsp)
   60976:      	xorl	%edi, %edi
   60978:      	callq	0x70870 <f.3>
   6097d:      	subq	$0x8, %rsp
   60981:      	addq	0x50(%rsp), %rax
   60986:      	movq	0x10(%rsp), %rcx
   6098b:      	movq	0x18(%rsp), %rdx
   60990:      	addq	%rax, %rdx
   60993:      	addq	%rdx, %r15
   60996:      	cmpb	$0x0, 0x150b3(%rip)     # 0x75a50 <g.4>
   6099d:      	je	0x7085f <f.2+0x180af>
   609a3:      	addq	%rcx, %r15
   609a6:      	addq	%r13, %r15
   609a9:      	cmpq	$0x0, 0x15097(%rip)     # 0x75a48 <g.3>
   609b1:      	je	0x7085f <f.2+0x180af>
   609b7:      	cmpq	$0x9, %r12
   609bb:      	ja	0x60a65 <f.2+0x82b5>
   609c1:      	leaq	-0x8(%r12), %r13
   609c6:      	cmpb	$0x0, 0x15083(%rip)     # 0x75a50 <g.4>
   609cd:      	je	0x7085f <f.2+0x180af>
   609d3:      	addq	%r15, %r13
   609d6:      	addq	%r14, %r13
   609d9:      	leaq	0x68(%rsp), %r15
   609de:      	cmpq	$0x0, 0x15062(%rip)     # 0x75a48 <g.3>
   609e6:      	je	0x7085f <f.2+0x180af>
   609ec:      	cmpq	$0x6, %r12
   609f0:      	ja	0x60a0c <f.2+0x825c>
   609f2:      	leaq	-0x5(%r12), %r14
   609f7:      	addq	%r14, %r13
   609fa:      	cmpb	$0x0, 0x1504f(%rip)     # 0x75a50 <g.4>
   60a01:      	jne	0x64620 <f.2+0xbe70>
   60a07:      	jmp	0x7085f <f.2+0x180af>
   60a0c:      	cmpq	$0x7, %r12
   60a10:      	jne	0x60a2b <f.2+0x827b>
   60a12:      	movl	$0x1, %r14d
   60a18:      	cmpq	$0x0, 0x15028(%rip)     # 0x75a48 <g.3>
   60a20:      	jne	0x62de5 <f.2+0xa635>
   60a26:      	jmp	0x7085f <f.2+0x180af>
   60a2b:      	cmpq	$0x9, %r12
   60a2f:      	jb	0x60a4c <f.2+0x829c>
   60a31:      	jne	0x60a84 <f.2+0x82d4>
   60a33:      	movl	$0x1, %r14d
   60a39:      	cmpq	$0x0, 0x15007(%rip)     # 0x75a48 <g.3>
   60a41:      	jne	0x61275 <f.2+0x8ac5>
   60a47:      	jmp	0x7085f <f.2+0x180af>
   60a4c:      	movl	$0x1, %r15d
   60a52:      	cmpq	$0x0, 0x14fee(%rip)     # 0x75a48 <g.3>
   60a5a:      	jne	0x62148 <f.2+0x9998>
   60a60:      	jmp	0x7085f <f.2+0x180af>
   60a65:      	cmpq	$0xa, %r12
   60a69:      	jne	0x60aa5 <f.2+0x82f5>
   60a6b:      	movl	$0x1, %r13d
   60a71:      	cmpq	$0x0, 0x14fcf(%rip)     # 0x75a48 <g.3>
   60a79:      	jne	0x61b46 <f.2+0x9396>
   60a7f:      	jmp	0x7085f <f.2+0x180af>
   60a84:      	cmpq	$0xb, %r12
   60a88:      	jb	0x60ac9 <f.2+0x8319>
   60a8a:      	jne	0x60afa <f.2+0x834a>
   60a8c:      	movl	$0x1, %r14d
   60a92:      	cmpq	$0x0, 0x14fae(%rip)     # 0x75a48 <g.3>
   60a9a:      	jne	0x60d55 <f.2+0x85a5>
   60aa0:      	jmp	0x7085f <f.2+0x180af>
   60aa5:      	cmpq	$0xc, %r12
   60aa9:      	jb	0x60ae2 <f.2+0x8332>
   60aab:      	jne	0x60c12 <f.2+0x8462>
   60ab1:      	movl	$0x1, %eax
   60ab6:      	cmpq	$0x0, 0x14f8a(%rip)     # 0x75a48 <g.3>
   60abe:      	jne	0x60daa <f.2+0x85fa>
   60ac4:      	jmp	0x7085f <f.2+0x180af>
   60ac9:      	movl	$0x1, %r15d
   60acf:      	cmpq	$0x0, 0x14f71(%rip)     # 0x75a48 <g.3>
   60ad7:      	jne	0x60fae <f.2+0x87fe>
   60add:      	jmp	0x7085f <f.2+0x180af>
   60ae2:      	movl	$0x1, %ecx
   60ae7:      	cmpq	$0x0, 0x14f59(%rip)     # 0x75a48 <g.3>
   60aef:      	jne	0x61572 <f.2+0x8dc2>
   60af5:      	jmp	0x7085f <f.2+0x180af>
   60afa:      	cmpq	$0xd, %r12
   60afe:      	jb	0x60d28 <f.2+0x8578>
   60b04:      	leaq	-0xc(%r12), %rsi
   60b09:      	movq	$0x0, 0x48(%rsp)
   60b12:      	movq	$0x3, 0x30(%rsp)
   60b1b:      	xorl	%edi, %edi
   60b1d:      	callq	0x70870 <f.3>
   60b22:      	subq	$0x8, %rsp
   60b26:      	cmpb	$0x0, 0x14f23(%rip)     # 0x75a50 <g.4>
   60b2d:      	je	0x7085f <f.2+0x180af>
   60b33:      	cmpq	$0x0, 0x14f0d(%rip)     # 0x75a48 <g.3>
   60b3b:      	je	0x7085f <f.2+0x180af>
   60b41:      	movq	%rax, %r14
   60b44:      	leaq	-0xd(%r12), %rsi
   60b49:      	movq	$0x0, 0x48(%rsp)
   60b52:      	movq	$0x3, 0x30(%rsp)
   60b5b:      	xorl	%edi, %edi
   60b5d:      	callq	0x70870 <f.3>
   60b62:      	subq	$0x8, %rsp
   60b66:      	cmpb	$0x0, 0x14ee3(%rip)     # 0x75a50 <g.4>
   60b6d:      	je	0x7085f <f.2+0x180af>
   60b73:      	cmpq	$0x0, 0x14ecd(%rip)     # 0x75a48 <g.3>
   60b7b:      	je	0x7085f <f.2+0x180af>
   60b81:      	movq	%rax, %r15
   60b84:      	addq	%r14, %r15
   60b87:      	cmpq	$0xd, %r12
   60b8b:      	je	0x60d3c <f.2+0x858c>
   60b91:      	movq	$0x0, 0x48(%rsp)
   60b9a:      	movq	$0x3, 0x30(%rsp)
   60ba3:      	xorl	%edi, %edi
   60ba5:      	leaq	-0xd(%r12), %rsi
   60baa:      	callq	0x70870 <f.3>
   60baf:      	subq	$0x8, %rsp
   60bb3:      	cmpb	$0x0, 0x14e96(%rip)     # 0x75a50 <g.4>
   60bba:      	je	0x7085f <f.2+0x180af>
   60bc0:      	movq	%rax, 0x10(%rsp)
   60bc5:      	cmpq	$0x0, 0x14e7b(%rip)     # 0x75a48 <g.3>
   60bcd:      	je	0x7085f <f.2+0x180af>
   60bd3:      	leaq	-0xe(%r12), %rsi
   60bd8:      	movq	$0x0, 0x48(%rsp)
   60be1:      	movq	$0x3, 0x30(%rsp)
   60bea:      	xorl	%edi, %edi
   60bec:      	callq	0x70870 <f.3>
   60bf1:      	subq	$0x8, %rsp
   60bf5:      	cmpb	$0x0, 0x14e54(%rip)     # 0x75a50 <g.4>
   60bfc:      	je	0x7085f <f.2+0x180af>
   60c02:      	movq	%rax, %r14
   60c05:      	addq	0x10(%rsp), %r14
   60c0a:      	addq	%r15, %r14
   60c0d:      	jmp	0x60d41 <f.2+0x8591>
   60c12:      	cmpq	$0xe, %r12
   60c16:      	jb	0x60d7d <f.2+0x85cd>
   60c1c:      	leaq	-0xd(%r12), %rsi
   60c21:      	movq	$0x0, 0x48(%rsp)
   60c2a:      	movq	$0x3, 0x30(%rsp)
   60c33:      	xorl	%edi, %edi
   60c35:      	callq	0x70870 <f.3>
   60c3a:      	subq	$0x8, %rsp
   60c3e:      	cmpb	$0x0, 0x14e0b(%rip)     # 0x75a50 <g.4>
   60c45:      	je	0x7085f <f.2+0x180af>
   60c4b:      	movq	%rax, 0x10(%rsp)
   60c50:      	cmpq	$0x0, 0x14df0(%rip)     # 0x75a48 <g.3>
   60c58:      	je	0x7085f <f.2+0x180af>
   60c5e:      	leaq	-0xe(%r12), %rsi
   60c63:      	movq	$0x0, 0x48(%rsp)
   60c6c:      	movq	$0x3, 0x30(%rsp)
   60c75:      	xorl	%edi, %edi
   60c77:      	callq	0x70870 <f.3>
   60c7c:      	subq	$0x8, %rsp
   60c80:      	cmpb	$0x0, 0x14dc9(%rip)     # 0x75a50 <g.4>
   60c87:      	je	0x7085f <f.2+0x180af>
   60c8d:      	cmpq	$0x0, 0x14db3(%rip)     # 0x75a48 <g.3>
   60c95:      	je	0x7085f <f.2+0x180af>
   60c9b:      	movq	%rax, %r13
   60c9e:      	addq	0x10(%rsp), %r13
   60ca3:      	cmpq	$0xe, %r12
   60ca7:      	je	0x60d91 <f.2+0x85e1>
   60cad:      	movq	$0x0, 0x48(%rsp)
   60cb6:      	movq	$0x3, 0x30(%rsp)
   60cbf:      	xorl	%edi, %edi
   60cc1:      	leaq	-0xe(%r12), %rsi
   60cc6:      	callq	0x70870 <f.3>
   60ccb:      	subq	$0x8, %rsp
   60ccf:      	cmpb	$0x0, 0x14d7a(%rip)     # 0x75a50 <g.4>
   60cd6:      	je	0x7085f <f.2+0x180af>
   60cdc:      	movq	%rax, 0x10(%rsp)
   60ce1:      	cmpq	$0x0, 0x14d5f(%rip)     # 0x75a48 <g.3>
   60ce9:      	je	0x7085f <f.2+0x180af>
   60cef:      	leaq	-0xf(%r12), %rsi
   60cf4:      	movq	$0x0, 0x48(%rsp)
   60cfd:      	movq	$0x3, 0x30(%rsp)
   60d06:      	xorl	%edi, %edi
   60d08:      	callq	0x70870 <f.3>
   60d0d:      	subq	$0x8, %rsp
   60d11:      	cmpb	$0x0, 0x14d38(%rip)     # 0x75a50 <g.4>
   60d18:      	je	0x7085f <f.2+0x180af>
   60d1e:      	addq	0x10(%rsp), %rax
   60d23:      	addq	%r13, %rax
   60d26:      	jmp	0x60d96 <f.2+0x85e6>
   60d28:      	movl	$0x1, %r15d
   60d2e:      	cmpq	$0x0, 0x14d12(%rip)     # 0x75a48 <g.3>
   60d36:      	je	0x7085f <f.2+0x180af>
   60d3c:      	leaq	-0xc(%r12,%r15), %r14
   60d41:      	cmpq	$0x0, 0x14cff(%rip)     # 0x75a48 <g.3>
   60d49:      	je	0x7085f <f.2+0x180af>
   60d4f:      	cmpq	$0xc, %r12
   60d53:      	ja	0x60d5f <f.2+0x85af>
   60d55:      	leaq	-0xb(%r12,%r14), %r15
   60d5a:      	jmp	0x60f94 <f.2+0x87e4>
   60d5f:      	cmpq	$0xd, %r12
   60d63:      	jne	0x60dd6 <f.2+0x8626>
   60d65:      	movl	$0x1, %eax
   60d6a:      	cmpq	$0x0, 0x14cd6(%rip)     # 0x75a48 <g.3>
   60d72:      	jne	0x60e60 <f.2+0x86b0>
   60d78:      	jmp	0x7085f <f.2+0x180af>
   60d7d:      	movl	$0x1, %r13d
   60d83:      	cmpq	$0x0, 0x14cbd(%rip)     # 0x75a48 <g.3>
   60d8b:      	je	0x7085f <f.2+0x180af>
   60d91:      	leaq	-0xd(%r12,%r13), %rax
   60d96:      	cmpq	$0x0, 0x14caa(%rip)     # 0x75a48 <g.3>
   60d9e:      	je	0x7085f <f.2+0x180af>
   60da4:      	cmpq	$0xd, %r12
   60da8:      	ja	0x60db4 <f.2+0x8604>
   60daa:      	leaq	-0xc(%r12,%rax), %rcx
   60daf:      	jmp	0x61558 <f.2+0x8da8>
   60db4:      	cmpq	$0xe, %r12
   60db8:      	jne	0x60e6a <f.2+0x86ba>
   60dbe:      	movl	$0x1, %edx
   60dc3:      	cmpq	$0x0, 0x14c7d(%rip)     # 0x75a48 <g.3>
   60dcb:      	jne	0x60f01 <f.2+0x8751>
   60dd1:      	jmp	0x7085f <f.2+0x180af>
   60dd6:      	leaq	-0xd(%r12), %rsi
   60ddb:      	movq	$0x0, 0x48(%rsp)
   60de4:      	movq	$0x3, 0x30(%rsp)
   60ded:      	xorl	%edi, %edi
   60def:      	callq	0x70870 <f.3>
   60df4:      	subq	$0x8, %rsp
   60df8:      	cmpb	$0x0, 0x14c51(%rip)     # 0x75a50 <g.4>
   60dff:      	je	0x7085f <f.2+0x180af>
   60e05:      	cmpq	$0x0, 0x14c3b(%rip)     # 0x75a48 <g.3>
   60e0d:      	je	0x7085f <f.2+0x180af>
   60e13:      	movq	%rax, %r15
   60e16:      	leaq	-0xe(%r12), %rsi
   60e1b:      	movq	$0x0, 0x48(%rsp)
   60e24:      	movq	$0x3, 0x30(%rsp)
   60e2d:      	xorl	%edi, %edi
   60e2f:      	callq	0x70870 <f.3>
   60e34:      	subq	$0x8, %rsp
   60e38:      	cmpb	$0x0, 0x14c11(%rip)     # 0x75a50 <g.4>
   60e3f:      	je	0x7085f <f.2+0x180af>
   60e45:      	cmpq	$0x0, 0x14bfb(%rip)     # 0x75a48 <g.3>
   60e4d:      	je	0x7085f <f.2+0x180af>
   60e53:      	addq	%r15, %rax
   60e56:      	cmpq	$0xe, %r12
   60e5a:      	ja	0x60f0b <f.2+0x875b>
   60e60:      	leaq	-0xd(%r12), %r15
   60e65:      	jmp	0x60f81 <f.2+0x87d1>
   60e6a:      	movq	%rax, 0x10(%rsp)
   60e6f:      	leaq	-0xe(%r12), %rsi
   60e74:      	movq	$0x0, 0x48(%rsp)
   60e7d:      	movq	$0x3, 0x30(%rsp)
   60e86:      	xorl	%edi, %edi
   60e88:      	callq	0x70870 <f.3>
   60e8d:      	subq	$0x8, %rsp
   60e91:      	cmpb	$0x0, 0x14bb8(%rip)     # 0x75a50 <g.4>
   60e98:      	je	0x7085f <f.2+0x180af>
   60e9e:      	cmpq	$0x0, 0x14ba2(%rip)     # 0x75a48 <g.3>
   60ea6:      	je	0x7085f <f.2+0x180af>
   60eac:      	movq	%rax, %r13
   60eaf:      	leaq	-0xf(%r12), %rsi
   60eb4:      	movq	$0x0, 0x48(%rsp)
   60ebd:      	movq	$0x3, 0x30(%rsp)
   60ec6:      	xorl	%edi, %edi
   60ec8:      	callq	0x70870 <f.3>
   60ecd:      	subq	$0x8, %rsp
   60ed1:      	cmpb	$0x0, 0x14b78(%rip)     # 0x75a50 <g.4>
   60ed8:      	je	0x7085f <f.2+0x180af>
   60ede:      	movq	%rax, %rdx
   60ee1:      	cmpq	$0x0, 0x14b5f(%rip)     # 0x75a48 <g.3>
   60ee9:      	movq	0x10(%rsp), %rax
   60eee:      	je	0x7085f <f.2+0x180af>
   60ef4:      	addq	%r13, %rdx
   60ef7:      	cmpq	$0xf, %r12
   60efb:      	ja	0x614ce <f.2+0x8d1e>
   60f01:      	leaq	-0xe(%r12), %rcx
   60f06:      	jmp	0x61545 <f.2+0x8d95>
   60f0b:      	movq	%rax, 0x10(%rsp)
   60f10:      	movq	$0x0, 0x48(%rsp)
   60f19:      	movq	$0x3, 0x30(%rsp)
   60f22:      	xorl	%edi, %edi
   60f24:      	leaq	-0xe(%r12), %rsi
   60f29:      	callq	0x70870 <f.3>
   60f2e:      	subq	$0x8, %rsp
   60f32:      	cmpb	$0x0, 0x14b17(%rip)     # 0x75a50 <g.4>
   60f39:      	je	0x7085f <f.2+0x180af>
   60f3f:      	movq	%rax, 0x18(%rsp)
   60f44:      	cmpq	$0x0, 0x14afc(%rip)     # 0x75a48 <g.3>
   60f4c:      	je	0x7085f <f.2+0x180af>
   60f52:      	leaq	-0xf(%r12), %rsi
   60f57:      	movq	$0x0, 0x48(%rsp)
   60f60:      	movq	$0x3, 0x30(%rsp)
   60f69:      	xorl	%edi, %edi
   60f6b:      	callq	0x70870 <f.3>
   60f70:      	subq	$0x8, %rsp
   60f74:      	movq	%rax, %r15
   60f77:      	addq	0x18(%rsp), %r15
   60f7c:      	movq	0x10(%rsp), %rax
   60f81:      	cmpb	$0x0, 0x14ac8(%rip)     # 0x75a50 <g.4>
   60f88:      	je	0x7085f <f.2+0x180af>
   60f8e:      	addq	%rax, %r15
   60f91:      	addq	%r14, %r15
   60f94:      	cmpq	$0x0, 0x14aac(%rip)     # 0x75a48 <g.3>
   60f9c:      	je	0x7085f <f.2+0x180af>
   60fa2:      	cmpq	$0xc, %r12
   60fa6:      	je	0x60fb8 <f.2+0x8808>
   60fa8:      	cmpq	$0xb, %r12
   60fac:      	jne	0x60fd0 <f.2+0x8820>
   60fae:      	leaq	-0xa(%r12,%r15), %r14
   60fb3:      	jmp	0x61261 <f.2+0x8ab1>
   60fb8:      	movl	$0x1, %ecx
   60fbd:      	cmpq	$0x0, 0x14a83(%rip)     # 0x75a48 <g.3>
   60fc5:      	jne	0x61116 <f.2+0x8966>
   60fcb:      	jmp	0x7085f <f.2+0x180af>
   60fd0:      	cmpq	$0xe, %r12
   60fd4:      	jb	0x610e9 <f.2+0x8939>
   60fda:      	leaq	-0xd(%r12), %rsi
   60fdf:      	movq	$0x0, 0x48(%rsp)
   60fe8:      	movq	$0x3, 0x30(%rsp)
   60ff1:      	xorl	%edi, %edi
   60ff3:      	callq	0x70870 <f.3>
   60ff8:      	subq	$0x8, %rsp
   60ffc:      	cmpb	$0x0, 0x14a4d(%rip)     # 0x75a50 <g.4>
   61003:      	je	0x7085f <f.2+0x180af>
   61009:      	movq	%rax, 0x10(%rsp)
   6100e:      	cmpq	$0x0, 0x14a32(%rip)     # 0x75a48 <g.3>
   61016:      	je	0x7085f <f.2+0x180af>
   6101c:      	leaq	-0xe(%r12), %rsi
   61021:      	movq	$0x0, 0x48(%rsp)
   6102a:      	movq	$0x3, 0x30(%rsp)
   61033:      	xorl	%edi, %edi
   61035:      	callq	0x70870 <f.3>
   6103a:      	subq	$0x8, %rsp
   6103e:      	cmpb	$0x0, 0x14a0b(%rip)     # 0x75a50 <g.4>
   61045:      	je	0x7085f <f.2+0x180af>
   6104b:      	cmpq	$0x0, 0x149f5(%rip)     # 0x75a48 <g.3>
   61053:      	je	0x7085f <f.2+0x180af>
   61059:      	movq	%rax, %r14
   6105c:      	addq	0x10(%rsp), %r14
   61061:      	cmpq	$0xe, %r12
   61065:      	je	0x610fd <f.2+0x894d>
   6106b:      	movq	$0x0, 0x48(%rsp)
   61074:      	movq	$0x3, 0x30(%rsp)
   6107d:      	xorl	%edi, %edi
   6107f:      	leaq	-0xe(%r12), %rsi
   61084:      	callq	0x70870 <f.3>
   61089:      	subq	$0x8, %rsp
   6108d:      	cmpb	$0x0, 0x149bc(%rip)     # 0x75a50 <g.4>
   61094:      	je	0x7085f <f.2+0x180af>
   6109a:      	movq	%rax, 0x10(%rsp)
   6109f:      	cmpq	$0x0, 0x149a1(%rip)     # 0x75a48 <g.3>
   610a7:      	je	0x7085f <f.2+0x180af>
   610ad:      	leaq	-0xf(%r12), %rsi
   610b2:      	movq	$0x0, 0x48(%rsp)
   610bb:      	movq	$0x3, 0x30(%rsp)
   610c4:      	xorl	%edi, %edi
   610c6:      	callq	0x70870 <f.3>
   610cb:      	subq	$0x8, %rsp
   610cf:      	cmpb	$0x0, 0x1497a(%rip)     # 0x75a50 <g.4>
   610d6:      	je	0x7085f <f.2+0x180af>
   610dc:      	movq	%rax, %rcx
   610df:      	addq	0x10(%rsp), %rcx
   610e4:      	addq	%r14, %rcx
   610e7:      	jmp	0x61102 <f.2+0x8952>
   610e9:      	movl	$0x1, %r14d
   610ef:      	cmpq	$0x0, 0x14951(%rip)     # 0x75a48 <g.3>
   610f7:      	je	0x7085f <f.2+0x180af>
   610fd:      	leaq	-0xd(%r12,%r14), %rcx
   61102:      	cmpq	$0x0, 0x1493e(%rip)     # 0x75a48 <g.3>
   6110a:      	je	0x7085f <f.2+0x180af>
   61110:      	cmpq	$0xd, %r12
   61114:      	ja	0x61120 <f.2+0x8970>
   61116:      	leaq	-0xc(%r12), %r14
   6111b:      	jmp	0x6124e <f.2+0x8a9e>
   61120:      	cmpq	$0xe, %r12
   61124:      	jne	0x6113f <f.2+0x898f>
   61126:      	movl	$0x1, %r14d
   6112c:      	cmpq	$0x0, 0x14914(%rip)     # 0x75a48 <g.3>
   61134:      	jne	0x611d6 <f.2+0x8a26>
   6113a:      	jmp	0x7085f <f.2+0x180af>
   6113f:      	movq	%rcx, 0x10(%rsp)
   61144:      	leaq	-0xe(%r12), %rsi
   61149:      	movq	$0x0, 0x48(%rsp)
   61152:      	movq	$0x3, 0x30(%rsp)
   6115b:      	xorl	%edi, %edi
   6115d:      	callq	0x70870 <f.3>
   61162:      	subq	$0x8, %rsp
   61166:      	cmpb	$0x0, 0x148e3(%rip)     # 0x75a50 <g.4>
   6116d:      	je	0x7085f <f.2+0x180af>
   61173:      	movq	%rax, 0x18(%rsp)
   61178:      	cmpq	$0x0, 0x148c8(%rip)     # 0x75a48 <g.3>
   61180:      	je	0x7085f <f.2+0x180af>
   61186:      	leaq	-0xf(%r12), %rsi
   6118b:      	movq	$0x0, 0x48(%rsp)
   61194:      	movq	$0x3, 0x30(%rsp)
   6119d:      	xorl	%edi, %edi
   6119f:      	callq	0x70870 <f.3>
   611a4:      	subq	$0x8, %rsp
   611a8:      	cmpb	$0x0, 0x148a1(%rip)     # 0x75a50 <g.4>
   611af:      	je	0x7085f <f.2+0x180af>
   611b5:      	cmpq	$0x0, 0x1488b(%rip)     # 0x75a48 <g.3>
   611bd:      	movq	0x10(%rsp), %rcx
   611c2:      	je	0x7085f <f.2+0x180af>
   611c8:      	movq	%rax, %r14
   611cb:      	addq	0x18(%rsp), %r14
   611d0:      	cmpq	$0xf, %r12
   611d4:      	ja	0x611dd <f.2+0x8a2d>
   611d6:      	leaq	-0xe(%r12), %rax
   611db:      	jmp	0x6124b <f.2+0x8a9b>
   611dd:      	movq	$0x0, 0x48(%rsp)
   611e6:      	movq	$0x3, 0x30(%rsp)
   611ef:      	xorl	%edi, %edi
   611f1:      	leaq	-0xf(%r12), %rsi
   611f6:      	callq	0x70870 <f.3>
   611fb:      	subq	$0x8, %rsp
   611ff:      	cmpb	$0x0, 0x1484a(%rip)     # 0x75a50 <g.4>
   61206:      	je	0x7085f <f.2+0x180af>
   6120c:      	movq	%rax, 0x18(%rsp)
   61211:      	cmpq	$0x0, 0x1482f(%rip)     # 0x75a48 <g.3>
   61219:      	je	0x7085f <f.2+0x180af>
   6121f:      	leaq	-0x10(%r12), %rsi
   61224:      	movq	$0x0, 0x48(%rsp)
   6122d:      	movq	$0x3, 0x30(%rsp)
   61236:      	xorl	%edi, %edi
   61238:      	callq	0x70870 <f.3>
   6123d:      	subq	$0x8, %rsp
   61241:      	addq	0x18(%rsp), %rax
   61246:      	movq	0x10(%rsp), %rcx
   6124b:      	addq	%rax, %r14
   6124e:      	cmpb	$0x0, 0x147fb(%rip)     # 0x75a50 <g.4>
   61255:      	je	0x7085f <f.2+0x180af>
   6125b:      	addq	%rcx, %r14
   6125e:      	addq	%r15, %r14
   61261:      	cmpq	$0x0, 0x147df(%rip)     # 0x75a48 <g.3>
   61269:      	je	0x7085f <f.2+0x180af>
   6126f:      	cmpq	$0xa, %r12
   61273:      	ja	0x6128d <f.2+0x8add>
   61275:      	leaq	-0x9(%r12,%r14), %r15
   6127a:      	cmpq	$0x0, 0x147c6(%rip)     # 0x75a48 <g.3>
   61282:      	jne	0x6213c <f.2+0x998c>
   61288:      	jmp	0x7085f <f.2+0x180af>
   6128d:      	cmpq	$0xb, %r12
   61291:      	jne	0x612ab <f.2+0x8afb>
   61293:      	movl	$0x1, %ecx
   61298:      	cmpq	$0x0, 0x147a8(%rip)     # 0x75a48 <g.3>
   612a0:      	jne	0x6185f <f.2+0x90af>
   612a6:      	jmp	0x7085f <f.2+0x180af>
   612ab:      	cmpq	$0xd, %r12
   612af:      	jb	0x612cc <f.2+0x8b1c>
   612b1:      	jne	0x612e4 <f.2+0x8b34>
   612b3:      	movl	$0x1, %r15d
   612b9:      	cmpq	$0x0, 0x14787(%rip)     # 0x75a48 <g.3>
   612c1:      	jne	0x61371 <f.2+0x8bc1>
   612c7:      	jmp	0x7085f <f.2+0x180af>
   612cc:      	movl	$0x1, %eax
   612d1:      	cmpq	$0x0, 0x1476f(%rip)     # 0x75a48 <g.3>
   612d9:      	jne	0x6140b <f.2+0x8c5b>
   612df:      	jmp	0x7085f <f.2+0x180af>
   612e4:      	leaq	-0xd(%r12), %rsi
   612e9:      	movq	$0x0, 0x48(%rsp)
   612f2:      	movq	$0x3, 0x30(%rsp)
   612fb:      	xorl	%edi, %edi
   612fd:      	callq	0x70870 <f.3>
   61302:      	subq	$0x8, %rsp
   61306:      	cmpb	$0x0, 0x14743(%rip)     # 0x75a50 <g.4>
   6130d:      	je	0x7085f <f.2+0x180af>
   61313:      	movq	%rax, 0x10(%rsp)
   61318:      	cmpq	$0x0, 0x14728(%rip)     # 0x75a48 <g.3>
   61320:      	je	0x7085f <f.2+0x180af>
   61326:      	leaq	-0xe(%r12), %rsi
   6132b:      	movq	$0x0, 0x48(%rsp)
   61334:      	movq	$0x3, 0x30(%rsp)
   6133d:      	xorl	%edi, %edi
   6133f:      	callq	0x70870 <f.3>
   61344:      	subq	$0x8, %rsp
   61348:      	cmpb	$0x0, 0x14701(%rip)     # 0x75a50 <g.4>
   6134f:      	je	0x7085f <f.2+0x180af>
   61355:      	cmpq	$0x0, 0x146eb(%rip)     # 0x75a48 <g.3>
   6135d:      	je	0x7085f <f.2+0x180af>
   61363:      	movq	%rax, %r15
   61366:      	addq	0x10(%rsp), %r15
   6136b:      	cmpq	$0xe, %r12
   6136f:      	ja	0x61378 <f.2+0x8bc8>
   61371:      	leaq	-0xd(%r12,%r15), %rax
   61376:      	jmp	0x613f1 <f.2+0x8c41>
   61378:      	movq	$0x0, 0x48(%rsp)
   61381:      	movq	$0x3, 0x30(%rsp)
   6138a:      	xorl	%edi, %edi
   6138c:      	leaq	-0xe(%r12), %rsi
   61391:      	callq	0x70870 <f.3>
   61396:      	subq	$0x8, %rsp
   6139a:      	cmpb	$0x0, 0x146af(%rip)     # 0x75a50 <g.4>
   613a1:      	je	0x7085f <f.2+0x180af>
   613a7:      	movq	%rax, 0x10(%rsp)
   613ac:      	cmpq	$0x0, 0x14694(%rip)     # 0x75a48 <g.3>
   613b4:      	je	0x7085f <f.2+0x180af>
   613ba:      	leaq	-0xf(%r12), %rsi
   613bf:      	movq	$0x0, 0x48(%rsp)
   613c8:      	movq	$0x3, 0x30(%rsp)
   613d1:      	xorl	%edi, %edi
   613d3:      	callq	0x70870 <f.3>
   613d8:      	subq	$0x8, %rsp
   613dc:      	cmpb	$0x0, 0x1466d(%rip)     # 0x75a50 <g.4>
   613e3:      	je	0x7085f <f.2+0x180af>
   613e9:      	addq	0x10(%rsp), %rax
   613ee:      	addq	%r15, %rax
   613f1:      	cmpq	$0x0, 0x1464f(%rip)     # 0x75a48 <g.3>
   613f9:      	je	0x7085f <f.2+0x180af>
   613ff:      	cmpq	$0xe, %r12
   61403:      	je	0x61415 <f.2+0x8c65>
   61405:      	cmpq	$0xd, %r12
   61409:      	jne	0x6142d <f.2+0x8c7d>
   6140b:      	leaq	-0xc(%r12,%rax), %rcx
   61410:      	jmp	0x6184b <f.2+0x909b>
   61415:      	movl	$0x1, %edx
   6141a:      	cmpq	$0x0, 0x14626(%rip)     # 0x75a48 <g.3>
   61422:      	jne	0x614c4 <f.2+0x8d14>
   61428:      	jmp	0x7085f <f.2+0x180af>
   6142d:      	movq	%rax, 0x10(%rsp)
   61432:      	leaq	-0xe(%r12), %rsi
   61437:      	movq	$0x0, 0x48(%rsp)
   61440:      	movq	$0x3, 0x30(%rsp)
   61449:      	xorl	%edi, %edi
   6144b:      	callq	0x70870 <f.3>
   61450:      	subq	$0x8, %rsp
   61454:      	cmpb	$0x0, 0x145f5(%rip)     # 0x75a50 <g.4>
   6145b:      	je	0x7085f <f.2+0x180af>
   61461:      	cmpq	$0x0, 0x145df(%rip)     # 0x75a48 <g.3>
   61469:      	je	0x7085f <f.2+0x180af>
   6146f:      	movq	%rax, %r15
   61472:      	leaq	-0xf(%r12), %rsi
   61477:      	movq	$0x0, 0x48(%rsp)
   61480:      	movq	$0x3, 0x30(%rsp)
   61489:      	xorl	%edi, %edi
   6148b:      	callq	0x70870 <f.3>
   61490:      	subq	$0x8, %rsp
   61494:      	cmpb	$0x0, 0x145b5(%rip)     # 0x75a50 <g.4>
   6149b:      	je	0x7085f <f.2+0x180af>
   614a1:      	movq	%rax, %rdx
   614a4:      	cmpq	$0x0, 0x1459c(%rip)     # 0x75a48 <g.3>
   614ac:      	movq	0x10(%rsp), %rax
   614b1:      	je	0x7085f <f.2+0x180af>
   614b7:      	addq	%r15, %rdx
   614ba:      	cmpq	$0xf, %r12
   614be:      	ja	0x617c1 <f.2+0x9011>
   614c4:      	leaq	-0xe(%r12), %rcx
   614c9:      	jmp	0x61838 <f.2+0x9088>
   614ce:      	movq	%rdx, 0x18(%rsp)
   614d3:      	movq	$0x0, 0x48(%rsp)
   614dc:      	movq	$0x3, 0x30(%rsp)
   614e5:      	xorl	%edi, %edi
   614e7:      	leaq	-0xf(%r12), %rsi
   614ec:      	callq	0x70870 <f.3>
   614f1:      	subq	$0x8, %rsp
   614f5:      	cmpb	$0x0, 0x14554(%rip)     # 0x75a50 <g.4>
   614fc:      	je	0x7085f <f.2+0x180af>
   61502:      	cmpq	$0x0, 0x1453e(%rip)     # 0x75a48 <g.3>
   6150a:      	je	0x7085f <f.2+0x180af>
   61510:      	movq	%rax, %r13
   61513:      	leaq	-0x10(%r12), %rsi
   61518:      	movq	$0x0, 0x48(%rsp)
   61521:      	movq	$0x3, 0x30(%rsp)
   6152a:      	xorl	%edi, %edi
   6152c:      	callq	0x70870 <f.3>
   61531:      	subq	$0x8, %rsp
   61535:      	movq	%rax, %rcx
   61538:      	addq	%r13, %rcx
   6153b:      	movq	0x10(%rsp), %rax
   61540:      	movq	0x18(%rsp), %rdx
   61545:      	cmpb	$0x0, 0x14504(%rip)     # 0x75a50 <g.4>
   6154c:      	je	0x7085f <f.2+0x180af>
   61552:      	addq	%rdx, %rcx
   61555:      	addq	%rax, %rcx
   61558:      	cmpq	$0x0, 0x144e8(%rip)     # 0x75a48 <g.3>
   61560:      	je	0x7085f <f.2+0x180af>
   61566:      	cmpq	$0xd, %r12
   6156a:      	je	0x6157c <f.2+0x8dcc>
   6156c:      	cmpq	$0xc, %r12
   61570:      	jne	0x61594 <f.2+0x8de4>
   61572:      	leaq	-0xb(%r12,%rcx), %r13
   61577:      	jmp	0x61b32 <f.2+0x9382>
   6157c:      	movl	$0x1, %edx
   61581:      	cmpq	$0x0, 0x144bf(%rip)     # 0x75a48 <g.3>
   61589:      	jne	0x616e9 <f.2+0x8f39>
   6158f:      	jmp	0x7085f <f.2+0x180af>
   61594:      	cmpq	$0xf, %r12
   61598:      	jb	0x616bc <f.2+0x8f0c>
   6159e:      	movq	%rcx, 0x10(%rsp)
   615a3:      	leaq	-0xe(%r12), %rsi
   615a8:      	movq	$0x0, 0x48(%rsp)
   615b1:      	movq	$0x3, 0x30(%rsp)
   615ba:      	xorl	%edi, %edi
   615bc:      	callq	0x70870 <f.3>
   615c1:      	subq	$0x8, %rsp
   615c5:      	cmpb	$0x0, 0x14484(%rip)     # 0x75a50 <g.4>
   615cc:      	je	0x7085f <f.2+0x180af>
   615d2:      	movq	%rax, 0x18(%rsp)
   615d7:      	cmpq	$0x0, 0x14469(%rip)     # 0x75a48 <g.3>
   615df:      	je	0x7085f <f.2+0x180af>
   615e5:      	leaq	-0xf(%r12), %rsi
   615ea:      	movq	$0x0, 0x48(%rsp)
   615f3:      	movq	$0x3, 0x30(%rsp)
   615fc:      	xorl	%edi, %edi
   615fe:      	callq	0x70870 <f.3>
   61603:      	subq	$0x8, %rsp
   61607:      	cmpb	$0x0, 0x14442(%rip)     # 0x75a50 <g.4>
   6160e:      	je	0x7085f <f.2+0x180af>
   61614:      	cmpq	$0x0, 0x1442c(%rip)     # 0x75a48 <g.3>
   6161c:      	movq	0x10(%rsp), %rcx
   61621:      	je	0x7085f <f.2+0x180af>
   61627:      	movq	%rax, %r13
   6162a:      	addq	0x18(%rsp), %r13
   6162f:      	cmpq	$0xf, %r12
   61633:      	je	0x616d0 <f.2+0x8f20>
   61639:      	movq	$0x0, 0x48(%rsp)
   61642:      	movq	$0x3, 0x30(%rsp)
   6164b:      	xorl	%edi, %edi
   6164d:      	leaq	-0xf(%r12), %rsi
   61652:      	callq	0x70870 <f.3>
   61657:      	subq	$0x8, %rsp
   6165b:      	cmpb	$0x0, 0x143ee(%rip)     # 0x75a50 <g.4>
   61662:      	je	0x7085f <f.2+0x180af>
   61668:      	movq	%rax, 0x18(%rsp)
   6166d:      	cmpq	$0x0, 0x143d3(%rip)     # 0x75a48 <g.3>
   61675:      	je	0x7085f <f.2+0x180af>
   6167b:      	leaq	-0x10(%r12), %rsi
   61680:      	movq	$0x0, 0x48(%rsp)
   61689:      	movq	$0x3, 0x30(%rsp)
   61692:      	xorl	%edi, %edi
   61694:      	callq	0x70870 <f.3>
   61699:      	subq	$0x8, %rsp
   6169d:      	cmpb	$0x0, 0x143ac(%rip)     # 0x75a50 <g.4>
   616a4:      	je	0x7085f <f.2+0x180af>
   616aa:      	movq	%rax, %rdx
   616ad:      	addq	0x18(%rsp), %rdx
   616b2:      	addq	%r13, %rdx
   616b5:      	movq	0x10(%rsp), %rcx
   616ba:      	jmp	0x616d5 <f.2+0x8f25>
   616bc:      	movl	$0x1, %r13d
   616c2:      	cmpq	$0x0, 0x1437e(%rip)     # 0x75a48 <g.3>
   616ca:      	je	0x7085f <f.2+0x180af>
   616d0:      	leaq	-0xe(%r12,%r13), %rdx
   616d5:      	cmpq	$0x0, 0x1436b(%rip)     # 0x75a48 <g.3>
   616dd:      	je	0x7085f <f.2+0x180af>
   616e3:      	cmpq	$0xe, %r12
   616e7:      	ja	0x616f3 <f.2+0x8f43>
   616e9:      	leaq	-0xd(%r12), %r13
   616ee:      	jmp	0x61b1f <f.2+0x936f>
   616f3:      	cmpq	$0xf, %r12
   616f7:      	jne	0x61712 <f.2+0x8f62>
   616f9:      	movl	$0x1, %r13d
   616ff:      	cmpq	$0x0, 0x14341(%rip)     # 0x75a48 <g.3>
   61707:      	jne	0x617b7 <f.2+0x9007>
   6170d:      	jmp	0x7085f <f.2+0x180af>
   61712:      	movq	%rdx, 0x18(%rsp)
   61717:      	movq	%rcx, 0x10(%rsp)
   6171c:      	leaq	-0xf(%r12), %rsi
   61721:      	movq	$0x0, 0x48(%rsp)
   6172a:      	movq	$0x3, 0x30(%rsp)
   61733:      	xorl	%edi, %edi
   61735:      	callq	0x70870 <f.3>
   6173a:      	subq	$0x8, %rsp
   6173e:      	cmpb	$0x0, 0x1430b(%rip)     # 0x75a50 <g.4>
   61745:      	je	0x7085f <f.2+0x180af>
   6174b:      	movq	%rax, 0x50(%rsp)
   61750:      	cmpq	$0x0, 0x142f0(%rip)     # 0x75a48 <g.3>
   61758:      	je	0x7085f <f.2+0x180af>
   6175e:      	leaq	-0x10(%r12), %rsi
   61763:      	movq	$0x0, 0x48(%rsp)
   6176c:      	movq	$0x3, 0x30(%rsp)
   61775:      	xorl	%edi, %edi
   61777:      	callq	0x70870 <f.3>
   6177c:      	subq	$0x8, %rsp
   61780:      	cmpb	$0x0, 0x142c9(%rip)     # 0x75a50 <g.4>
   61787:      	je	0x7085f <f.2+0x180af>
   6178d:      	cmpq	$0x0, 0x142b3(%rip)     # 0x75a48 <g.3>
   61795:      	movq	0x10(%rsp), %rcx
   6179a:      	movq	0x18(%rsp), %rdx
   6179f:      	je	0x7085f <f.2+0x180af>
   617a5:      	movq	%rax, %r13
   617a8:      	addq	0x50(%rsp), %r13
   617ad:      	cmpq	$0x10, %r12
   617b1:      	ja	0x61aa9 <f.2+0x92f9>
   617b7:      	leaq	-0xf(%r12), %rax
   617bc:      	jmp	0x61b1c <f.2+0x936c>
   617c1:      	movq	%rdx, 0x18(%rsp)
   617c6:      	movq	$0x0, 0x48(%rsp)
   617cf:      	movq	$0x3, 0x30(%rsp)
   617d8:      	xorl	%edi, %edi
   617da:      	leaq	-0xf(%r12), %rsi
   617df:      	callq	0x70870 <f.3>
   617e4:      	subq	$0x8, %rsp
   617e8:      	cmpb	$0x0, 0x14261(%rip)     # 0x75a50 <g.4>
   617ef:      	je	0x7085f <f.2+0x180af>
   617f5:      	cmpq	$0x0, 0x1424b(%rip)     # 0x75a48 <g.3>
   617fd:      	je	0x7085f <f.2+0x180af>
   61803:      	movq	%rax, %r15
   61806:      	leaq	-0x10(%r12), %rsi
   6180b:      	movq	$0x0, 0x48(%rsp)
   61814:      	movq	$0x3, 0x30(%rsp)
   6181d:      	xorl	%edi, %edi
   6181f:      	callq	0x70870 <f.3>
   61824:      	subq	$0x8, %rsp
   61828:      	movq	%rax, %rcx
   6182b:      	addq	%r15, %rcx
   6182e:      	movq	0x10(%rsp), %rax
   61833:      	movq	0x18(%rsp), %rdx
   61838:      	cmpb	$0x0, 0x14211(%rip)     # 0x75a50 <g.4>
   6183f:      	je	0x7085f <f.2+0x180af>
   61845:      	addq	%rdx, %rcx
   61848:      	addq	%rax, %rcx
   6184b:      	cmpq	$0x0, 0x141f5(%rip)     # 0x75a48 <g.3>
   61853:      	je	0x7085f <f.2+0x180af>
   61859:      	cmpq	$0xc, %r12
   6185d:      	ja	0x61869 <f.2+0x90b9>
   6185f:      	leaq	-0xb(%r12), %r15
   61864:      	jmp	0x6211b <f.2+0x996b>
   61869:      	cmpq	$0xd, %r12
   6186d:      	jne	0x61888 <f.2+0x90d8>
   6186f:      	movl	$0x1, %r15d
   61875:      	cmpq	$0x0, 0x141cb(%rip)     # 0x75a48 <g.3>
   6187d:      	jne	0x619dc <f.2+0x922c>
   61883:      	jmp	0x7085f <f.2+0x180af>
   61888:      	cmpq	$0xf, %r12
   6188c:      	jb	0x619b0 <f.2+0x9200>
   61892:      	movq	%rcx, 0x10(%rsp)
   61897:      	leaq	-0xe(%r12), %rsi
   6189c:      	movq	$0x0, 0x48(%rsp)
   618a5:      	movq	$0x3, 0x30(%rsp)
   618ae:      	xorl	%edi, %edi
   618b0:      	callq	0x70870 <f.3>
   618b5:      	subq	$0x8, %rsp
   618b9:      	cmpb	$0x0, 0x14190(%rip)     # 0x75a50 <g.4>
   618c0:      	je	0x7085f <f.2+0x180af>
   618c6:      	cmpq	$0x0, 0x1417a(%rip)     # 0x75a48 <g.3>
   618ce:      	je	0x7085f <f.2+0x180af>
   618d4:      	movq	%rax, %r15
   618d7:      	leaq	-0xf(%r12), %rsi
   618dc:      	movq	$0x0, 0x48(%rsp)
   618e5:      	movq	$0x3, 0x30(%rsp)
   618ee:      	xorl	%edi, %edi
   618f0:      	callq	0x70870 <f.3>
   618f5:      	subq	$0x8, %rsp
   618f9:      	cmpb	$0x0, 0x14150(%rip)     # 0x75a50 <g.4>
   61900:      	je	0x7085f <f.2+0x180af>
   61906:      	cmpq	$0x0, 0x1413a(%rip)     # 0x75a48 <g.3>
   6190e:      	movq	0x10(%rsp), %rcx
   61913:      	je	0x7085f <f.2+0x180af>
   61919:      	addq	%r15, %rax
   6191c:      	cmpq	$0xf, %r12
   61920:      	je	0x619c3 <f.2+0x9213>
   61926:      	movq	%rax, 0x18(%rsp)
   6192b:      	movq	$0x0, 0x48(%rsp)
   61934:      	movq	$0x3, 0x30(%rsp)
   6193d:      	xorl	%edi, %edi
   6193f:      	leaq	-0xf(%r12), %rsi
   61944:      	callq	0x70870 <f.3>
   61949:      	subq	$0x8, %rsp
   6194d:      	cmpb	$0x0, 0x140fc(%rip)     # 0x75a50 <g.4>
   61954:      	je	0x7085f <f.2+0x180af>
   6195a:      	movq	%rax, 0x50(%rsp)
   6195f:      	cmpq	$0x0, 0x140e1(%rip)     # 0x75a48 <g.3>
   61967:      	je	0x7085f <f.2+0x180af>
   6196d:      	leaq	-0x10(%r12), %rsi
   61972:      	movq	$0x0, 0x48(%rsp)
   6197b:      	movq	$0x3, 0x30(%rsp)
   61984:      	xorl	%edi, %edi
   61986:      	callq	0x70870 <f.3>
   6198b:      	subq	$0x8, %rsp
   6198f:      	cmpb	$0x0, 0x140ba(%rip)     # 0x75a50 <g.4>
   61996:      	je	0x7085f <f.2+0x180af>
   6199c:      	movq	%rax, %r15
   6199f:      	addq	0x50(%rsp), %r15
   619a4:      	addq	0x18(%rsp), %r15
   619a9:      	movq	0x10(%rsp), %rcx
   619ae:      	jmp	0x619c8 <f.2+0x9218>
   619b0:      	movl	$0x1, %eax
   619b5:      	cmpq	$0x0, 0x1408b(%rip)     # 0x75a48 <g.3>
   619bd:      	je	0x7085f <f.2+0x180af>
   619c3:      	leaq	-0xe(%r12,%rax), %r15
   619c8:      	cmpq	$0x0, 0x14078(%rip)     # 0x75a48 <g.3>
   619d0:      	je	0x7085f <f.2+0x180af>
   619d6:      	cmpq	$0xe, %r12
   619da:      	ja	0x619e6 <f.2+0x9236>
   619dc:      	leaq	-0xd(%r12), %rdx
   619e1:      	jmp	0x62118 <f.2+0x9968>
   619e6:      	cmpq	$0xf, %r12
   619ea:      	jne	0x61a04 <f.2+0x9254>
   619ec:      	movl	$0x1, %edx
   619f1:      	cmpq	$0x0, 0x1404f(%rip)     # 0x75a48 <g.3>
   619f9:      	jne	0x61a9f <f.2+0x92ef>
   619ff:      	jmp	0x7085f <f.2+0x180af>
   61a04:      	movq	%rcx, 0x10(%rsp)
   61a09:      	leaq	-0xf(%r12), %rsi
   61a0e:      	movq	$0x0, 0x48(%rsp)
   61a17:      	movq	$0x3, 0x30(%rsp)
   61a20:      	xorl	%edi, %edi
   61a22:      	callq	0x70870 <f.3>
   61a27:      	subq	$0x8, %rsp
   61a2b:      	cmpb	$0x0, 0x1401e(%rip)     # 0x75a50 <g.4>
   61a32:      	je	0x7085f <f.2+0x180af>
   61a38:      	movq	%rax, 0x18(%rsp)
   61a3d:      	cmpq	$0x0, 0x14003(%rip)     # 0x75a48 <g.3>
   61a45:      	je	0x7085f <f.2+0x180af>
   61a4b:      	leaq	-0x10(%r12), %rsi
   61a50:      	movq	$0x0, 0x48(%rsp)
   61a59:      	movq	$0x3, 0x30(%rsp)
   61a62:      	xorl	%edi, %edi
   61a64:      	callq	0x70870 <f.3>
   61a69:      	subq	$0x8, %rsp
   61a6d:      	cmpb	$0x0, 0x13fdc(%rip)     # 0x75a50 <g.4>
   61a74:      	je	0x7085f <f.2+0x180af>
   61a7a:      	cmpq	$0x0, 0x13fc6(%rip)     # 0x75a48 <g.3>
   61a82:      	movq	0x10(%rsp), %rcx
   61a87:      	je	0x7085f <f.2+0x180af>
   61a8d:      	movq	%rax, %rdx
   61a90:      	addq	0x18(%rsp), %rdx
   61a95:      	cmpq	$0x10, %r12
   61a99:      	ja	0x6209d <f.2+0x98ed>
   61a9f:      	leaq	-0xf(%r12), %rax
   61aa4:      	jmp	0x62115 <f.2+0x9965>
   61aa9:      	movq	$0x0, 0x48(%rsp)
   61ab2:      	movq	$0x3, 0x30(%rsp)
   61abb:      	xorl	%edi, %edi
   61abd:      	leaq	-0x10(%r12), %rsi
   61ac2:      	callq	0x70870 <f.3>
   61ac7:      	subq	$0x8, %rsp
   61acb:      	cmpb	$0x0, 0x13f7e(%rip)     # 0x75a50 <g.4>
   61ad2:      	je	0x7085f <f.2+0x180af>
   61ad8:      	movq	%rax, 0x50(%rsp)
   61add:      	cmpq	$0x0, 0x13f63(%rip)     # 0x75a48 <g.3>
   61ae5:      	je	0x7085f <f.2+0x180af>
   61aeb:      	leaq	-0x11(%r12), %rsi
   61af0:      	movq	$0x0, 0x48(%rsp)
   61af9:      	movq	$0x3, 0x30(%rsp)
   61b02:      	xorl	%edi, %edi
   61b04:      	callq	0x70870 <f.3>
   61b09:      	subq	$0x8, %rsp
   61b0d:      	addq	0x50(%rsp), %rax
   61b12:      	movq	0x10(%rsp), %rcx
   61b17:      	movq	0x18(%rsp), %rdx
   61b1c:      	addq	%rax, %r13
   61b1f:      	cmpb	$0x0, 0x13f2a(%rip)     # 0x75a50 <g.4>
   61b26:      	je	0x7085f <f.2+0x180af>
   61b2c:      	addq	%rdx, %r13
   61b2f:      	addq	%rcx, %r13
   61b32:      	cmpq	$0x0, 0x13f0e(%rip)     # 0x75a48 <g.3>
   61b3a:      	je	0x7085f <f.2+0x180af>
   61b40:      	cmpq	$0xb, %r12
   61b44:      	ja	0x61b60 <f.2+0x93b0>
   61b46:      	leaq	-0xa(%r12), %rcx
   61b4b:      	addq	%rcx, %r13
   61b4e:      	cmpb	$0x0, 0x13efb(%rip)     # 0x75a50 <g.4>
   61b55:      	jne	0x609d3 <f.2+0x8223>
   61b5b:      	jmp	0x7085f <f.2+0x180af>
   61b60:      	cmpq	$0xc, %r12
   61b64:      	jne	0x61b7e <f.2+0x93ce>
   61b66:      	movl	$0x1, %ecx
   61b6b:      	cmpq	$0x0, 0x13ed5(%rip)     # 0x75a48 <g.3>
   61b73:      	jne	0x61e46 <f.2+0x9696>
   61b79:      	jmp	0x7085f <f.2+0x180af>
   61b7e:      	cmpq	$0xe, %r12
   61b82:      	jb	0x61b9e <f.2+0x93ee>
   61b84:      	jne	0x61bb6 <f.2+0x9406>
   61b86:      	movl	$0x1, %eax
   61b8b:      	cmpq	$0x0, 0x13eb5(%rip)     # 0x75a48 <g.3>
   61b93:      	jne	0x61c40 <f.2+0x9490>
   61b99:      	jmp	0x7085f <f.2+0x180af>
   61b9e:      	movl	$0x1, %eax
   61ba3:      	cmpq	$0x0, 0x13e9d(%rip)     # 0x75a48 <g.3>
   61bab:      	jne	0x61ce4 <f.2+0x9534>
   61bb1:      	jmp	0x7085f <f.2+0x180af>
   61bb6:      	leaq	-0xe(%r12), %rsi
   61bbb:      	movq	$0x0, 0x48(%rsp)
   61bc4:      	movq	$0x3, 0x30(%rsp)
   61bcd:      	xorl	%edi, %edi
   61bcf:      	callq	0x70870 <f.3>
   61bd4:      	subq	$0x8, %rsp
   61bd8:      	cmpb	$0x0, 0x13e71(%rip)     # 0x75a50 <g.4>
   61bdf:      	je	0x7085f <f.2+0x180af>
   61be5:      	movq	%rax, 0x10(%rsp)
   61bea:      	cmpq	$0x0, 0x13e56(%rip)     # 0x75a48 <g.3>
   61bf2:      	je	0x7085f <f.2+0x180af>
   61bf8:      	leaq	-0xf(%r12), %rsi
   61bfd:      	movq	$0x0, 0x48(%rsp)
   61c06:      	movq	$0x3, 0x30(%rsp)
   61c0f:      	xorl	%edi, %edi
   61c11:      	callq	0x70870 <f.3>
   61c16:      	subq	$0x8, %rsp
   61c1a:      	cmpb	$0x0, 0x13e2f(%rip)     # 0x75a50 <g.4>
   61c21:      	je	0x7085f <f.2+0x180af>
   61c27:      	cmpq	$0x0, 0x13e19(%rip)     # 0x75a48 <g.3>
   61c2f:      	je	0x7085f <f.2+0x180af>
   61c35:      	addq	0x10(%rsp), %rax
   61c3a:      	cmpq	$0xf, %r12
   61c3e:      	ja	0x61c4a <f.2+0x949a>
   61c40:      	leaq	-0xe(%r12,%rax), %rax
   61c45:      	jmp	0x61cca <f.2+0x951a>
   61c4a:      	movq	%rax, 0x10(%rsp)
   61c4f:      	movq	$0x0, 0x48(%rsp)
   61c58:      	movq	$0x3, 0x30(%rsp)
   61c61:      	xorl	%edi, %edi
   61c63:      	leaq	-0xf(%r12), %rsi
   61c68:      	callq	0x70870 <f.3>
   61c6d:      	subq	$0x8, %rsp
   61c71:      	cmpb	$0x0, 0x13dd8(%rip)     # 0x75a50 <g.4>
   61c78:      	je	0x7085f <f.2+0x180af>
   61c7e:      	movq	%rax, 0x18(%rsp)
   61c83:      	cmpq	$0x0, 0x13dbd(%rip)     # 0x75a48 <g.3>
   61c8b:      	je	0x7085f <f.2+0x180af>
   61c91:      	leaq	-0x10(%r12), %rsi
   61c96:      	movq	$0x0, 0x48(%rsp)
   61c9f:      	movq	$0x3, 0x30(%rsp)
   61ca8:      	xorl	%edi, %edi
   61caa:      	callq	0x70870 <f.3>
   61caf:      	subq	$0x8, %rsp
   61cb3:      	cmpb	$0x0, 0x13d96(%rip)     # 0x75a50 <g.4>
   61cba:      	je	0x7085f <f.2+0x180af>
   61cc0:      	addq	0x18(%rsp), %rax
   61cc5:      	addq	0x10(%rsp), %rax
   61cca:      	cmpq	$0x0, 0x13d76(%rip)     # 0x75a48 <g.3>
   61cd2:      	je	0x7085f <f.2+0x180af>
   61cd8:      	cmpq	$0xf, %r12
   61cdc:      	je	0x61cee <f.2+0x953e>
   61cde:      	cmpq	$0xe, %r12
   61ce2:      	jne	0x61d06 <f.2+0x9556>
   61ce4:      	leaq	-0xd(%r12,%rax), %rcx
   61ce9:      	jmp	0x61e32 <f.2+0x9682>
   61cee:      	movl	$0x1, %edx
   61cf3:      	cmpq	$0x0, 0x13d4d(%rip)     # 0x75a48 <g.3>
   61cfb:      	jne	0x61d9d <f.2+0x95ed>
   61d01:      	jmp	0x7085f <f.2+0x180af>
   61d06:      	movq	%rax, 0x10(%rsp)
   61d0b:      	leaq	-0xf(%r12), %rsi
   61d10:      	movq	$0x0, 0x48(%rsp)
   61d19:      	movq	$0x3, 0x30(%rsp)
   61d22:      	xorl	%edi, %edi
   61d24:      	callq	0x70870 <f.3>
   61d29:      	subq	$0x8, %rsp
   61d2d:      	cmpb	$0x0, 0x13d1c(%rip)     # 0x75a50 <g.4>
   61d34:      	je	0x7085f <f.2+0x180af>
   61d3a:      	movq	%rax, 0x18(%rsp)
   61d3f:      	cmpq	$0x0, 0x13d01(%rip)     # 0x75a48 <g.3>
   61d47:      	je	0x7085f <f.2+0x180af>
   61d4d:      	leaq	-0x10(%r12), %rsi
   61d52:      	movq	$0x0, 0x48(%rsp)
   61d5b:      	movq	$0x3, 0x30(%rsp)
   61d64:      	xorl	%edi, %edi
   61d66:      	callq	0x70870 <f.3>
   61d6b:      	subq	$0x8, %rsp
   61d6f:      	cmpb	$0x0, 0x13cda(%rip)     # 0x75a50 <g.4>
   61d76:      	je	0x7085f <f.2+0x180af>
   61d7c:      	movq	%rax, %rdx
   61d7f:      	cmpq	$0x0, 0x13cc1(%rip)     # 0x75a48 <g.3>
   61d87:      	movq	0x10(%rsp), %rax
   61d8c:      	je	0x7085f <f.2+0x180af>
   61d92:      	addq	0x18(%rsp), %rdx
   61d97:      	cmpq	$0x10, %r12
   61d9b:      	ja	0x61da4 <f.2+0x95f4>
   61d9d:      	leaq	-0xf(%r12), %rcx
   61da2:      	jmp	0x61e1f <f.2+0x966f>
   61da4:      	movq	%rdx, 0x18(%rsp)
   61da9:      	movq	$0x0, 0x48(%rsp)
   61db2:      	movq	$0x3, 0x30(%rsp)
   61dbb:      	xorl	%edi, %edi
   61dbd:      	leaq	-0x10(%r12), %rsi
   61dc2:      	callq	0x70870 <f.3>
   61dc7:      	subq	$0x8, %rsp
   61dcb:      	cmpb	$0x0, 0x13c7e(%rip)     # 0x75a50 <g.4>
   61dd2:      	je	0x7085f <f.2+0x180af>
   61dd8:      	movq	%rax, 0x50(%rsp)
   61ddd:      	cmpq	$0x0, 0x13c63(%rip)     # 0x75a48 <g.3>
   61de5:      	je	0x7085f <f.2+0x180af>
   61deb:      	leaq	-0x11(%r12), %rsi
   61df0:      	movq	$0x0, 0x48(%rsp)
   61df9:      	movq	$0x3, 0x30(%rsp)
   61e02:      	xorl	%edi, %edi
   61e04:      	callq	0x70870 <f.3>
   61e09:      	subq	$0x8, %rsp
   61e0d:      	movq	%rax, %rcx
   61e10:      	addq	0x50(%rsp), %rcx
   61e15:      	movq	0x10(%rsp), %rax
   61e1a:      	movq	0x18(%rsp), %rdx
   61e1f:      	cmpb	$0x0, 0x13c2a(%rip)     # 0x75a50 <g.4>
   61e26:      	je	0x7085f <f.2+0x180af>
   61e2c:      	addq	%rdx, %rcx
   61e2f:      	addq	%rax, %rcx
   61e32:      	cmpq	$0x0, 0x13c0e(%rip)     # 0x75a48 <g.3>
   61e3a:      	je	0x7085f <f.2+0x180af>
   61e40:      	cmpq	$0xd, %r12
   61e44:      	ja	0x61e50 <f.2+0x96a0>
   61e46:      	leaq	-0xc(%r12), %rdx
   61e4b:      	jmp	0x62d20 <f.2+0xa570>
   61e50:      	cmpq	$0xe, %r12
   61e54:      	jne	0x61e6e <f.2+0x96be>
   61e56:      	movl	$0x1, %edx
   61e5b:      	cmpq	$0x0, 0x13be5(%rip)     # 0x75a48 <g.3>
   61e63:      	jne	0x61fc6 <f.2+0x9816>
   61e69:      	jmp	0x7085f <f.2+0x180af>
   61e6e:      	cmpq	$0x10, %r12
   61e72:      	jb	0x61f9a <f.2+0x97ea>
   61e78:      	movq	%rcx, 0x10(%rsp)
   61e7d:      	leaq	-0xf(%r12), %rsi
   61e82:      	movq	$0x0, 0x48(%rsp)
   61e8b:      	movq	$0x3, 0x30(%rsp)
   61e94:      	xorl	%edi, %edi
   61e96:      	callq	0x70870 <f.3>
   61e9b:      	subq	$0x8, %rsp
   61e9f:      	cmpb	$0x0, 0x13baa(%rip)     # 0x75a50 <g.4>
   61ea6:      	je	0x7085f <f.2+0x180af>
   61eac:      	movq	%rax, 0x18(%rsp)
   61eb1:      	cmpq	$0x0, 0x13b8f(%rip)     # 0x75a48 <g.3>
   61eb9:      	je	0x7085f <f.2+0x180af>
   61ebf:      	leaq	-0x10(%r12), %rsi
   61ec4:      	movq	$0x0, 0x48(%rsp)
   61ecd:      	movq	$0x3, 0x30(%rsp)
   61ed6:      	xorl	%edi, %edi
   61ed8:      	callq	0x70870 <f.3>
   61edd:      	subq	$0x8, %rsp
   61ee1:      	cmpb	$0x0, 0x13b68(%rip)     # 0x75a50 <g.4>
   61ee8:      	je	0x7085f <f.2+0x180af>
   61eee:      	cmpq	$0x0, 0x13b52(%rip)     # 0x75a48 <g.3>
   61ef6:      	movq	0x10(%rsp), %rcx
   61efb:      	je	0x7085f <f.2+0x180af>
   61f01:      	addq	0x18(%rsp), %rax
   61f06:      	cmpq	$0x10, %r12
   61f0a:      	je	0x61fad <f.2+0x97fd>
   61f10:      	movq	%rax, 0x18(%rsp)
   61f15:      	movq	$0x0, 0x48(%rsp)
   61f1e:      	movq	$0x3, 0x30(%rsp)
   61f27:      	xorl	%edi, %edi
   61f29:      	leaq	-0x10(%r12), %rsi
   61f2e:      	callq	0x70870 <f.3>
   61f33:      	subq	$0x8, %rsp
   61f37:      	cmpb	$0x0, 0x13b12(%rip)     # 0x75a50 <g.4>
   61f3e:      	je	0x7085f <f.2+0x180af>
   61f44:      	movq	%rax, 0x50(%rsp)
   61f49:      	cmpq	$0x0, 0x13af7(%rip)     # 0x75a48 <g.3>
   61f51:      	je	0x7085f <f.2+0x180af>
   61f57:      	leaq	-0x11(%r12), %rsi
   61f5c:      	movq	$0x0, 0x48(%rsp)
   61f65:      	movq	$0x3, 0x30(%rsp)
   61f6e:      	xorl	%edi, %edi
   61f70:      	callq	0x70870 <f.3>
   61f75:      	subq	$0x8, %rsp
   61f79:      	cmpb	$0x0, 0x13ad0(%rip)     # 0x75a50 <g.4>
   61f80:      	je	0x7085f <f.2+0x180af>
   61f86:      	movq	%rax, %rdx
   61f89:      	addq	0x50(%rsp), %rdx
   61f8e:      	addq	0x18(%rsp), %rdx
   61f93:      	movq	0x10(%rsp), %rcx
   61f98:      	jmp	0x61fb2 <f.2+0x9802>
   61f9a:      	movl	$0x1, %eax
   61f9f:      	cmpq	$0x0, 0x13aa1(%rip)     # 0x75a48 <g.3>
   61fa7:      	je	0x7085f <f.2+0x180af>
   61fad:      	leaq	-0xf(%r12,%rax), %rdx
   61fb2:      	cmpq	$0x0, 0x13a8e(%rip)     # 0x75a48 <g.3>
   61fba:      	je	0x7085f <f.2+0x180af>
   61fc0:      	cmpq	$0xf, %r12
   61fc4:      	ja	0x61fd0 <f.2+0x9820>
   61fc6:      	leaq	-0xe(%r12), %rsi
   61fcb:      	jmp	0x62d1d <f.2+0xa56d>
   61fd0:      	cmpq	$0x10, %r12
   61fd4:      	jne	0x61fee <f.2+0x983e>
   61fd6:      	movl	$0x1, %esi
   61fdb:      	cmpq	$0x0, 0x13a65(%rip)     # 0x75a48 <g.3>
   61fe3:      	jne	0x62093 <f.2+0x98e3>
   61fe9:      	jmp	0x7085f <f.2+0x180af>
   61fee:      	movq	%rdx, 0x18(%rsp)
   61ff3:      	movq	%rcx, 0x10(%rsp)
   61ff8:      	leaq	-0x10(%r12), %rsi
   61ffd:      	movq	$0x0, 0x48(%rsp)
   62006:      	movq	$0x3, 0x30(%rsp)
   6200f:      	xorl	%edi, %edi
   62011:      	callq	0x70870 <f.3>
   62016:      	subq	$0x8, %rsp
   6201a:      	cmpb	$0x0, 0x13a2f(%rip)     # 0x75a50 <g.4>
   62021:      	je	0x7085f <f.2+0x180af>
   62027:      	movq	%rax, 0x50(%rsp)
   6202c:      	cmpq	$0x0, 0x13a14(%rip)     # 0x75a48 <g.3>
   62034:      	je	0x7085f <f.2+0x180af>
   6203a:      	leaq	-0x11(%r12), %rsi
   6203f:      	movq	$0x0, 0x48(%rsp)
   62048:      	movq	$0x3, 0x30(%rsp)
   62051:      	xorl	%edi, %edi
   62053:      	callq	0x70870 <f.3>
   62058:      	subq	$0x8, %rsp
   6205c:      	cmpb	$0x0, 0x139ed(%rip)     # 0x75a50 <g.4>
   62063:      	je	0x7085f <f.2+0x180af>
   62069:      	cmpq	$0x0, 0x139d7(%rip)     # 0x75a48 <g.3>
   62071:      	movq	0x10(%rsp), %rcx
   62076:      	movq	0x18(%rsp), %rdx
   6207b:      	je	0x7085f <f.2+0x180af>
   62081:      	movq	%rax, %rsi
   62084:      	addq	0x50(%rsp), %rsi
   62089:      	cmpq	$0x11, %r12
   6208d:      	ja	0x62c9d <f.2+0xa4ed>
   62093:      	leaq	-0x10(%r12), %rax
   62098:      	jmp	0x62d1a <f.2+0xa56a>
   6209d:      	movq	%rdx, 0x18(%rsp)
   620a2:      	movq	$0x0, 0x48(%rsp)
   620ab:      	movq	$0x3, 0x30(%rsp)
   620b4:      	xorl	%edi, %edi
   620b6:      	leaq	-0x10(%r12), %rsi
   620bb:      	callq	0x70870 <f.3>
   620c0:      	subq	$0x8, %rsp
   620c4:      	cmpb	$0x0, 0x13985(%rip)     # 0x75a50 <g.4>
   620cb:      	je	0x7085f <f.2+0x180af>
   620d1:      	movq	%rax, 0x50(%rsp)
   620d6:      	cmpq	$0x0, 0x1396a(%rip)     # 0x75a48 <g.3>
   620de:      	je	0x7085f <f.2+0x180af>
   620e4:      	leaq	-0x11(%r12), %rsi
   620e9:      	movq	$0x0, 0x48(%rsp)
   620f2:      	movq	$0x3, 0x30(%rsp)
   620fb:      	xorl	%edi, %edi
   620fd:      	callq	0x70870 <f.3>
   62102:      	subq	$0x8, %rsp
   62106:      	addq	0x50(%rsp), %rax
   6210b:      	movq	0x10(%rsp), %rcx
   62110:      	movq	0x18(%rsp), %rdx
   62115:      	addq	%rax, %rdx
   62118:      	addq	%rdx, %r15
   6211b:      	cmpb	$0x0, 0x1392e(%rip)     # 0x75a50 <g.4>
   62122:      	je	0x7085f <f.2+0x180af>
   62128:      	addq	%rcx, %r15
   6212b:      	addq	%r14, %r15
   6212e:      	cmpq	$0x0, 0x13912(%rip)     # 0x75a48 <g.3>
   62136:      	je	0x7085f <f.2+0x180af>
   6213c:      	cmpq	$0xa, %r12
   62140:      	je	0x62160 <f.2+0x99b0>
   62142:      	cmpq	$0x9, %r12
   62146:      	jne	0x62178 <f.2+0x99c8>
   62148:      	leaq	-0x8(%r12,%r15), %r14
   6214d:      	cmpq	$0x0, 0x138f3(%rip)     # 0x75a48 <g.3>
   62155:      	jne	0x62ddf <f.2+0xa62f>
   6215b:      	jmp	0x7085f <f.2+0x180af>
   62160:      	movl	$0x1, %ecx
   62165:      	cmpq	$0x0, 0x138db(%rip)     # 0x75a48 <g.3>
   6216d:      	jne	0x62731 <f.2+0x9f81>
   62173:      	jmp	0x7085f <f.2+0x180af>
   62178:      	cmpq	$0xc, %r12
   6217c:      	jb	0x62198 <f.2+0x99e8>
   6217e:      	jne	0x621b1 <f.2+0x9a01>
   62180:      	movl	$0x1, %eax
   62185:      	cmpq	$0x0, 0x138bb(%rip)     # 0x75a48 <g.3>
   6218d:      	jne	0x622f4 <f.2+0x9b44>
   62193:      	jmp	0x7085f <f.2+0x180af>
   62198:      	movl	$0x1, %r14d
   6219e:      	cmpq	$0x0, 0x138a2(%rip)     # 0x75a48 <g.3>
   621a6:      	jne	0x6245e <f.2+0x9cae>
   621ac:      	jmp	0x7085f <f.2+0x180af>
   621b1:      	cmpq	$0xe, %r12
   621b5:      	jb	0x622c7 <f.2+0x9b17>
   621bb:      	leaq	-0xd(%r12), %rsi
   621c0:      	movq	$0x0, 0x48(%rsp)
   621c9:      	movq	$0x3, 0x30(%rsp)
   621d2:      	xorl	%edi, %edi
   621d4:      	callq	0x70870 <f.3>
   621d9:      	subq	$0x8, %rsp
   621dd:      	cmpb	$0x0, 0x1386c(%rip)     # 0x75a50 <g.4>
   621e4:      	je	0x7085f <f.2+0x180af>
   621ea:      	movq	%rax, 0x10(%rsp)
   621ef:      	cmpq	$0x0, 0x13851(%rip)     # 0x75a48 <g.3>
   621f7:      	je	0x7085f <f.2+0x180af>
   621fd:      	leaq	-0xe(%r12), %rsi
   62202:      	movq	$0x0, 0x48(%rsp)
   6220b:      	movq	$0x3, 0x30(%rsp)
   62214:      	xorl	%edi, %edi
   62216:      	callq	0x70870 <f.3>
   6221b:      	subq	$0x8, %rsp
   6221f:      	cmpb	$0x0, 0x1382a(%rip)     # 0x75a50 <g.4>
   62226:      	je	0x7085f <f.2+0x180af>
   6222c:      	cmpq	$0x0, 0x13814(%rip)     # 0x75a48 <g.3>
   62234:      	je	0x7085f <f.2+0x180af>
   6223a:      	movq	%rax, %r14
   6223d:      	addq	0x10(%rsp), %r14
   62242:      	cmpq	$0xe, %r12
   62246:      	je	0x622db <f.2+0x9b2b>
   6224c:      	movq	$0x0, 0x48(%rsp)
   62255:      	movq	$0x3, 0x30(%rsp)
   6225e:      	xorl	%edi, %edi
   62260:      	leaq	-0xe(%r12), %rsi
   62265:      	callq	0x70870 <f.3>
   6226a:      	subq	$0x8, %rsp
   6226e:      	cmpb	$0x0, 0x137db(%rip)     # 0x75a50 <g.4>
   62275:      	je	0x7085f <f.2+0x180af>
   6227b:      	movq	%rax, 0x10(%rsp)
   62280:      	cmpq	$0x0, 0x137c0(%rip)     # 0x75a48 <g.3>
   62288:      	je	0x7085f <f.2+0x180af>
   6228e:      	leaq	-0xf(%r12), %rsi
   62293:      	movq	$0x0, 0x48(%rsp)
   6229c:      	movq	$0x3, 0x30(%rsp)
   622a5:      	xorl	%edi, %edi
   622a7:      	callq	0x70870 <f.3>
   622ac:      	subq	$0x8, %rsp
   622b0:      	cmpb	$0x0, 0x13799(%rip)     # 0x75a50 <g.4>
   622b7:      	je	0x7085f <f.2+0x180af>
   622bd:      	addq	0x10(%rsp), %rax
   622c2:      	addq	%r14, %rax
   622c5:      	jmp	0x622e0 <f.2+0x9b30>
   622c7:      	movl	$0x1, %r14d
   622cd:      	cmpq	$0x0, 0x13773(%rip)     # 0x75a48 <g.3>
   622d5:      	je	0x7085f <f.2+0x180af>
   622db:      	leaq	-0xd(%r12,%r14), %rax
   622e0:      	cmpq	$0x0, 0x13760(%rip)     # 0x75a48 <g.3>
   622e8:      	je	0x7085f <f.2+0x180af>
   622ee:      	cmpq	$0xd, %r12
   622f2:      	ja	0x622fe <f.2+0x9b4e>
   622f4:      	leaq	-0xc(%r12,%rax), %r14
   622f9:      	jmp	0x62444 <f.2+0x9c94>
   622fe:      	cmpq	$0xe, %r12
   62302:      	jne	0x6231c <f.2+0x9b6c>
   62304:      	movl	$0x1, %ecx
   62309:      	cmpq	$0x0, 0x13737(%rip)     # 0x75a48 <g.3>
   62311:      	jne	0x623af <f.2+0x9bff>
   62317:      	jmp	0x7085f <f.2+0x180af>
   6231c:      	movq	%rax, 0x10(%rsp)
   62321:      	leaq	-0xe(%r12), %rsi
   62326:      	movq	$0x0, 0x48(%rsp)
   6232f:      	movq	$0x3, 0x30(%rsp)
   62338:      	xorl	%edi, %edi
   6233a:      	callq	0x70870 <f.3>
   6233f:      	subq	$0x8, %rsp
   62343:      	cmpb	$0x0, 0x13706(%rip)     # 0x75a50 <g.4>
   6234a:      	je	0x7085f <f.2+0x180af>
   62350:      	cmpq	$0x0, 0x136f0(%rip)     # 0x75a48 <g.3>
   62358:      	je	0x7085f <f.2+0x180af>
   6235e:      	movq	%rax, %r14
   62361:      	leaq	-0xf(%r12), %rsi
   62366:      	movq	$0x0, 0x48(%rsp)
   6236f:      	movq	$0x3, 0x30(%rsp)
   62378:      	xorl	%edi, %edi
   6237a:      	callq	0x70870 <f.3>
   6237f:      	subq	$0x8, %rsp
   62383:      	cmpb	$0x0, 0x136c6(%rip)     # 0x75a50 <g.4>
   6238a:      	je	0x7085f <f.2+0x180af>
   62390:      	movq	%rax, %rcx
   62393:      	cmpq	$0x0, 0x136ad(%rip)     # 0x75a48 <g.3>
   6239b:      	movq	0x10(%rsp), %rax
   623a0:      	je	0x7085f <f.2+0x180af>
   623a6:      	addq	%r14, %rcx
   623a9:      	cmpq	$0xf, %r12
   623ad:      	ja	0x623b6 <f.2+0x9c06>
   623af:      	leaq	-0xe(%r12), %r14
   623b4:      	jmp	0x62431 <f.2+0x9c81>
   623b6:      	movq	%rcx, 0x18(%rsp)
   623bb:      	movq	$0x0, 0x48(%rsp)
   623c4:      	movq	$0x3, 0x30(%rsp)
   623cd:      	xorl	%edi, %edi
   623cf:      	leaq	-0xf(%r12), %rsi
   623d4:      	callq	0x70870 <f.3>
   623d9:      	subq	$0x8, %rsp
   623dd:      	cmpb	$0x0, 0x1366c(%rip)     # 0x75a50 <g.4>
   623e4:      	je	0x7085f <f.2+0x180af>
   623ea:      	movq	%rax, 0x50(%rsp)
   623ef:      	cmpq	$0x0, 0x13651(%rip)     # 0x75a48 <g.3>
   623f7:      	je	0x7085f <f.2+0x180af>
   623fd:      	leaq	-0x10(%r12), %rsi
   62402:      	movq	$0x0, 0x48(%rsp)
   6240b:      	movq	$0x3, 0x30(%rsp)
   62414:      	xorl	%edi, %edi
   62416:      	callq	0x70870 <f.3>
   6241b:      	subq	$0x8, %rsp
   6241f:      	movq	%rax, %r14
   62422:      	addq	0x50(%rsp), %r14
   62427:      	movq	0x10(%rsp), %rax
   6242c:      	movq	0x18(%rsp), %rcx
   62431:      	cmpb	$0x0, 0x13618(%rip)     # 0x75a50 <g.4>
   62438:      	je	0x7085f <f.2+0x180af>
   6243e:      	addq	%rcx, %r14
   62441:      	addq	%rax, %r14
   62444:      	cmpq	$0x0, 0x135fc(%rip)     # 0x75a48 <g.3>
   6244c:      	je	0x7085f <f.2+0x180af>
   62452:      	cmpq	$0xd, %r12
   62456:      	je	0x62468 <f.2+0x9cb8>
   62458:      	cmpq	$0xc, %r12
   6245c:      	jne	0x62480 <f.2+0x9cd0>
   6245e:      	leaq	-0xb(%r12,%r14), %rcx
   62463:      	jmp	0x6271d <f.2+0x9f6d>
   62468:      	movl	$0x1, %edx
   6246d:      	cmpq	$0x0, 0x135d3(%rip)     # 0x75a48 <g.3>
   62475:      	jne	0x625c9 <f.2+0x9e19>
   6247b:      	jmp	0x7085f <f.2+0x180af>
   62480:      	cmpq	$0xf, %r12
   62484:      	jb	0x6259d <f.2+0x9ded>
   6248a:      	leaq	-0xe(%r12), %rsi
   6248f:      	movq	$0x0, 0x48(%rsp)
   62498:      	movq	$0x3, 0x30(%rsp)
   624a1:      	xorl	%edi, %edi
   624a3:      	callq	0x70870 <f.3>
   624a8:      	subq	$0x8, %rsp
   624ac:      	cmpb	$0x0, 0x1359d(%rip)     # 0x75a50 <g.4>
   624b3:      	je	0x7085f <f.2+0x180af>
   624b9:      	movq	%rax, 0x10(%rsp)
   624be:      	cmpq	$0x0, 0x13582(%rip)     # 0x75a48 <g.3>
   624c6:      	je	0x7085f <f.2+0x180af>
   624cc:      	leaq	-0xf(%r12), %rsi
   624d1:      	movq	$0x0, 0x48(%rsp)
   624da:      	movq	$0x3, 0x30(%rsp)
   624e3:      	xorl	%edi, %edi
   624e5:      	callq	0x70870 <f.3>
   624ea:      	subq	$0x8, %rsp
   624ee:      	cmpb	$0x0, 0x1355b(%rip)     # 0x75a50 <g.4>
   624f5:      	je	0x7085f <f.2+0x180af>
   624fb:      	cmpq	$0x0, 0x13545(%rip)     # 0x75a48 <g.3>
   62503:      	je	0x7085f <f.2+0x180af>
   62509:      	addq	0x10(%rsp), %rax
   6250e:      	cmpq	$0xf, %r12
   62512:      	je	0x625b0 <f.2+0x9e00>
   62518:      	movq	%rax, 0x10(%rsp)
   6251d:      	movq	$0x0, 0x48(%rsp)
   62526:      	movq	$0x3, 0x30(%rsp)
   6252f:      	xorl	%edi, %edi
   62531:      	leaq	-0xf(%r12), %rsi
   62536:      	callq	0x70870 <f.3>
   6253b:      	subq	$0x8, %rsp
   6253f:      	cmpb	$0x0, 0x1350a(%rip)     # 0x75a50 <g.4>
   62546:      	je	0x7085f <f.2+0x180af>
   6254c:      	movq	%rax, 0x18(%rsp)
   62551:      	cmpq	$0x0, 0x134ef(%rip)     # 0x75a48 <g.3>
   62559:      	je	0x7085f <f.2+0x180af>
   6255f:      	leaq	-0x10(%r12), %rsi
   62564:      	movq	$0x0, 0x48(%rsp)
   6256d:      	movq	$0x3, 0x30(%rsp)
   62576:      	xorl	%edi, %edi
   62578:      	callq	0x70870 <f.3>
   6257d:      	subq	$0x8, %rsp
   62581:      	cmpb	$0x0, 0x134c8(%rip)     # 0x75a50 <g.4>
   62588:      	je	0x7085f <f.2+0x180af>
   6258e:      	movq	%rax, %rdx
   62591:      	addq	0x18(%rsp), %rdx
   62596:      	addq	0x10(%rsp), %rdx
   6259b:      	jmp	0x625b5 <f.2+0x9e05>
   6259d:      	movl	$0x1, %eax
   625a2:      	cmpq	$0x0, 0x1349e(%rip)     # 0x75a48 <g.3>
   625aa:      	je	0x7085f <f.2+0x180af>
   625b0:      	leaq	-0xe(%r12,%rax), %rdx
   625b5:      	cmpq	$0x0, 0x1348b(%rip)     # 0x75a48 <g.3>
   625bd:      	je	0x7085f <f.2+0x180af>
   625c3:      	cmpq	$0xe, %r12
   625c7:      	ja	0x625d3 <f.2+0x9e23>
   625c9:      	leaq	-0xd(%r12), %rcx
   625ce:      	jmp	0x6270a <f.2+0x9f5a>
   625d3:      	cmpq	$0xf, %r12
   625d7:      	jne	0x625f1 <f.2+0x9e41>
   625d9:      	movl	$0x1, %ecx
   625de:      	cmpq	$0x0, 0x13462(%rip)     # 0x75a48 <g.3>
   625e6:      	jne	0x62688 <f.2+0x9ed8>
   625ec:      	jmp	0x7085f <f.2+0x180af>
   625f1:      	movq	%rdx, 0x18(%rsp)
   625f6:      	leaq	-0xf(%r12), %rsi
   625fb:      	movq	$0x0, 0x48(%rsp)
   62604:      	movq	$0x3, 0x30(%rsp)
   6260d:      	xorl	%edi, %edi
   6260f:      	callq	0x70870 <f.3>
   62614:      	subq	$0x8, %rsp
   62618:      	cmpb	$0x0, 0x13431(%rip)     # 0x75a50 <g.4>
   6261f:      	je	0x7085f <f.2+0x180af>
   62625:      	movq	%rax, 0x10(%rsp)
   6262a:      	cmpq	$0x0, 0x13416(%rip)     # 0x75a48 <g.3>
   62632:      	je	0x7085f <f.2+0x180af>
   62638:      	leaq	-0x10(%r12), %rsi
   6263d:      	movq	$0x0, 0x48(%rsp)
   62646:      	movq	$0x3, 0x30(%rsp)
   6264f:      	xorl	%edi, %edi
   62651:      	callq	0x70870 <f.3>
   62656:      	subq	$0x8, %rsp
   6265a:      	cmpb	$0x0, 0x133ef(%rip)     # 0x75a50 <g.4>
   62661:      	je	0x7085f <f.2+0x180af>
   62667:      	cmpq	$0x0, 0x133d9(%rip)     # 0x75a48 <g.3>
   6266f:      	movq	0x18(%rsp), %rdx
   62674:      	je	0x7085f <f.2+0x180af>
   6267a:      	movq	%rax, %rcx
   6267d:      	addq	0x10(%rsp), %rcx
   62682:      	cmpq	$0x10, %r12
   62686:      	ja	0x6268f <f.2+0x9edf>
   62688:      	leaq	-0xf(%r12), %rax
   6268d:      	jmp	0x62707 <f.2+0x9f57>
   6268f:      	movq	%rcx, 0x10(%rsp)
   62694:      	movq	$0x0, 0x48(%rsp)
   6269d:      	movq	$0x3, 0x30(%rsp)
   626a6:      	xorl	%edi, %edi
   626a8:      	leaq	-0x10(%r12), %rsi
   626ad:      	callq	0x70870 <f.3>
   626b2:      	subq	$0x8, %rsp
   626b6:      	cmpb	$0x0, 0x13393(%rip)     # 0x75a50 <g.4>
   626bd:      	je	0x7085f <f.2+0x180af>
   626c3:      	movq	%rax, 0x50(%rsp)
   626c8:      	cmpq	$0x0, 0x13378(%rip)     # 0x75a48 <g.3>
   626d0:      	je	0x7085f <f.2+0x180af>
   626d6:      	leaq	-0x11(%r12), %rsi
   626db:      	movq	$0x0, 0x48(%rsp)
   626e4:      	movq	$0x3, 0x30(%rsp)
   626ed:      	xorl	%edi, %edi
   626ef:      	callq	0x70870 <f.3>
   626f4:      	subq	$0x8, %rsp
   626f8:      	addq	0x50(%rsp), %rax
   626fd:      	movq	0x10(%rsp), %rcx
   62702:      	movq	0x18(%rsp), %rdx
   62707:      	addq	%rax, %rcx
   6270a:      	cmpb	$0x0, 0x1333f(%rip)     # 0x75a50 <g.4>
   62711:      	je	0x7085f <f.2+0x180af>
   62717:      	addq	%rdx, %rcx
   6271a:      	addq	%r14, %rcx
   6271d:      	cmpq	$0x0, 0x13323(%rip)     # 0x75a48 <g.3>
   62725:      	je	0x7085f <f.2+0x180af>
   6272b:      	cmpq	$0xb, %r12
   6272f:      	ja	0x62748 <f.2+0x9f98>
   62731:      	leaq	-0xa(%r12), %r14
   62736:      	cmpb	$0x0, 0x13313(%rip)     # 0x75a50 <g.4>
   6273d:      	jne	0x62dcb <f.2+0xa61b>
   62743:      	jmp	0x7085f <f.2+0x180af>
   62748:      	cmpq	$0xc, %r12
   6274c:      	jne	0x62767 <f.2+0x9fb7>
   6274e:      	movl	$0x1, %r14d
   62754:      	cmpq	$0x0, 0x132ec(%rip)     # 0x75a48 <g.3>
   6275c:      	jne	0x62a46 <f.2+0xa296>
   62762:      	jmp	0x7085f <f.2+0x180af>
   62767:      	cmpq	$0xe, %r12
   6276b:      	jb	0x62788 <f.2+0x9fd8>
   6276d:      	jne	0x627a0 <f.2+0x9ff0>
   6276f:      	movl	$0x1, %r14d
   62775:      	cmpq	$0x0, 0x132cb(%rip)     # 0x75a48 <g.3>
   6277d:      	jne	0x62837 <f.2+0xa087>
   62783:      	jmp	0x7085f <f.2+0x180af>
   62788:      	movl	$0x1, %eax
   6278d:      	cmpq	$0x0, 0x132b3(%rip)     # 0x75a48 <g.3>
   62795:      	jne	0x628d6 <f.2+0xa126>
   6279b:      	jmp	0x7085f <f.2+0x180af>
   627a0:      	movq	%rcx, 0x10(%rsp)
   627a5:      	leaq	-0xe(%r12), %rsi
   627aa:      	movq	$0x0, 0x48(%rsp)
   627b3:      	movq	$0x3, 0x30(%rsp)
   627bc:      	xorl	%edi, %edi
   627be:      	callq	0x70870 <f.3>
   627c3:      	subq	$0x8, %rsp
   627c7:      	cmpb	$0x0, 0x13282(%rip)     # 0x75a50 <g.4>
   627ce:      	je	0x7085f <f.2+0x180af>
   627d4:      	movq	%rax, 0x18(%rsp)
   627d9:      	cmpq	$0x0, 0x13267(%rip)     # 0x75a48 <g.3>
   627e1:      	je	0x7085f <f.2+0x180af>
   627e7:      	leaq	-0xf(%r12), %rsi
   627ec:      	movq	$0x0, 0x48(%rsp)
   627f5:      	movq	$0x3, 0x30(%rsp)
   627fe:      	xorl	%edi, %edi
   62800:      	callq	0x70870 <f.3>
   62805:      	subq	$0x8, %rsp
   62809:      	cmpb	$0x0, 0x13240(%rip)     # 0x75a50 <g.4>
   62810:      	je	0x7085f <f.2+0x180af>
   62816:      	cmpq	$0x0, 0x1322a(%rip)     # 0x75a48 <g.3>
   6281e:      	movq	0x10(%rsp), %rcx
   62823:      	je	0x7085f <f.2+0x180af>
   62829:      	movq	%rax, %r14
   6282c:      	addq	0x18(%rsp), %r14
   62831:      	cmpq	$0xf, %r12
   62835:      	ja	0x6283e <f.2+0xa08e>
   62837:      	leaq	-0xe(%r12,%r14), %rax
   6283c:      	jmp	0x628bc <f.2+0xa10c>
   6283e:      	movq	$0x0, 0x48(%rsp)
   62847:      	movq	$0x3, 0x30(%rsp)
   62850:      	xorl	%edi, %edi
   62852:      	leaq	-0xf(%r12), %rsi
   62857:      	callq	0x70870 <f.3>
   6285c:      	subq	$0x8, %rsp
   62860:      	cmpb	$0x0, 0x131e9(%rip)     # 0x75a50 <g.4>
   62867:      	je	0x7085f <f.2+0x180af>
   6286d:      	movq	%rax, 0x18(%rsp)
   62872:      	cmpq	$0x0, 0x131ce(%rip)     # 0x75a48 <g.3>
   6287a:      	je	0x7085f <f.2+0x180af>
   62880:      	leaq	-0x10(%r12), %rsi
   62885:      	movq	$0x0, 0x48(%rsp)
   6288e:      	movq	$0x3, 0x30(%rsp)
   62897:      	xorl	%edi, %edi
   62899:      	callq	0x70870 <f.3>
   6289e:      	subq	$0x8, %rsp
   628a2:      	cmpb	$0x0, 0x131a7(%rip)     # 0x75a50 <g.4>
   628a9:      	je	0x7085f <f.2+0x180af>
   628af:      	addq	0x18(%rsp), %rax
   628b4:      	addq	%r14, %rax
   628b7:      	movq	0x10(%rsp), %rcx
   628bc:      	cmpq	$0x0, 0x13184(%rip)     # 0x75a48 <g.3>
   628c4:      	je	0x7085f <f.2+0x180af>
   628ca:      	cmpq	$0xf, %r12
   628ce:      	je	0x628e0 <f.2+0xa130>
   628d0:      	cmpq	$0xe, %r12
   628d4:      	jne	0x628f8 <f.2+0xa148>
   628d6:      	leaq	-0xd(%r12,%rax), %r14
   628db:      	jmp	0x62a32 <f.2+0xa282>
   628e0:      	movl	$0x1, %edx
   628e5:      	cmpq	$0x0, 0x1315b(%rip)     # 0x75a48 <g.3>
   628ed:      	jne	0x62995 <f.2+0xa1e5>
   628f3:      	jmp	0x7085f <f.2+0x180af>
   628f8:      	movq	%rax, 0x18(%rsp)
   628fd:      	movq	%rcx, 0x10(%rsp)
   62902:      	leaq	-0xf(%r12), %rsi
   62907:      	movq	$0x0, 0x48(%rsp)
   62910:      	movq	$0x3, 0x30(%rsp)
   62919:      	xorl	%edi, %edi
   6291b:      	callq	0x70870 <f.3>
   62920:      	subq	$0x8, %rsp
   62924:      	cmpb	$0x0, 0x13125(%rip)     # 0x75a50 <g.4>
   6292b:      	je	0x7085f <f.2+0x180af>
   62931:      	cmpq	$0x0, 0x1310f(%rip)     # 0x75a48 <g.3>
   62939:      	je	0x7085f <f.2+0x180af>
   6293f:      	movq	%rax, %r14
   62942:      	leaq	-0x10(%r12), %rsi
   62947:      	movq	$0x0, 0x48(%rsp)
   62950:      	movq	$0x3, 0x30(%rsp)
   62959:      	xorl	%edi, %edi
   6295b:      	callq	0x70870 <f.3>
   62960:      	subq	$0x8, %rsp
   62964:      	cmpb	$0x0, 0x130e5(%rip)     # 0x75a50 <g.4>
   6296b:      	je	0x7085f <f.2+0x180af>
   62971:      	movq	%rax, %rdx
   62974:      	cmpq	$0x0, 0x130cc(%rip)     # 0x75a48 <g.3>
   6297c:      	movq	0x10(%rsp), %rcx
   62981:      	movq	0x18(%rsp), %rax
   62986:      	je	0x7085f <f.2+0x180af>
   6298c:      	addq	%r14, %rdx
   6298f:      	cmpq	$0x10, %r12
   62993:      	ja	0x6299f <f.2+0xa1ef>
   62995:      	leaq	-0xf(%r12), %r14
   6299a:      	jmp	0x62a1f <f.2+0xa26f>
   6299f:      	movq	%rdx, 0x50(%rsp)
   629a4:      	movq	$0x0, 0x48(%rsp)
   629ad:      	movq	$0x3, 0x30(%rsp)
   629b6:      	xorl	%edi, %edi
   629b8:      	leaq	-0x10(%r12), %rsi
   629bd:      	callq	0x70870 <f.3>
   629c2:      	subq	$0x8, %rsp
   629c6:      	cmpb	$0x0, 0x13083(%rip)     # 0x75a50 <g.4>
   629cd:      	je	0x7085f <f.2+0x180af>
   629d3:      	movq	%rax, 0x58(%rsp)
   629d8:      	cmpq	$0x0, 0x13068(%rip)     # 0x75a48 <g.3>
   629e0:      	je	0x7085f <f.2+0x180af>
   629e6:      	leaq	-0x11(%r12), %rsi
   629eb:      	movq	$0x0, 0x48(%rsp)
   629f4:      	movq	$0x3, 0x30(%rsp)
   629fd:      	xorl	%edi, %edi
   629ff:      	callq	0x70870 <f.3>
   62a04:      	subq	$0x8, %rsp
   62a08:      	movq	%rax, %r14
   62a0b:      	addq	0x58(%rsp), %r14
   62a10:      	movq	0x10(%rsp), %rcx
   62a15:      	movq	0x18(%rsp), %rax
   62a1a:      	movq	0x50(%rsp), %rdx
   62a1f:      	cmpb	$0x0, 0x1302a(%rip)     # 0x75a50 <g.4>
   62a26:      	je	0x7085f <f.2+0x180af>
   62a2c:      	addq	%rdx, %r14
   62a2f:      	addq	%rax, %r14
   62a32:      	cmpq	$0x0, 0x1300e(%rip)     # 0x75a48 <g.3>
   62a3a:      	je	0x7085f <f.2+0x180af>
   62a40:      	cmpq	$0xd, %r12
   62a44:      	ja	0x62a50 <f.2+0xa2a0>
   62a46:      	leaq	-0xc(%r12), %rdx
   62a4b:      	jmp	0x62dbb <f.2+0xa60b>
   62a50:      	cmpq	$0xe, %r12
   62a54:      	jne	0x62a6e <f.2+0xa2be>
   62a56:      	movl	$0x1, %edx
   62a5b:      	cmpq	$0x0, 0x12fe5(%rip)     # 0x75a48 <g.3>
   62a63:      	jne	0x62bc6 <f.2+0xa416>
   62a69:      	jmp	0x7085f <f.2+0x180af>
   62a6e:      	cmpq	$0x10, %r12
   62a72:      	jb	0x62b9a <f.2+0xa3ea>
   62a78:      	movq	%rcx, 0x10(%rsp)
   62a7d:      	leaq	-0xf(%r12), %rsi
   62a82:      	movq	$0x0, 0x48(%rsp)
   62a8b:      	movq	$0x3, 0x30(%rsp)
   62a94:      	xorl	%edi, %edi
   62a96:      	callq	0x70870 <f.3>
   62a9b:      	subq	$0x8, %rsp
   62a9f:      	cmpb	$0x0, 0x12faa(%rip)     # 0x75a50 <g.4>
   62aa6:      	je	0x7085f <f.2+0x180af>
   62aac:      	movq	%rax, 0x18(%rsp)
   62ab1:      	cmpq	$0x0, 0x12f8f(%rip)     # 0x75a48 <g.3>
   62ab9:      	je	0x7085f <f.2+0x180af>
   62abf:      	leaq	-0x10(%r12), %rsi
   62ac4:      	movq	$0x0, 0x48(%rsp)
   62acd:      	movq	$0x3, 0x30(%rsp)
   62ad6:      	xorl	%edi, %edi
   62ad8:      	callq	0x70870 <f.3>
   62add:      	subq	$0x8, %rsp
   62ae1:      	cmpb	$0x0, 0x12f68(%rip)     # 0x75a50 <g.4>
   62ae8:      	je	0x7085f <f.2+0x180af>
   62aee:      	cmpq	$0x0, 0x12f52(%rip)     # 0x75a48 <g.3>
   62af6:      	movq	0x10(%rsp), %rcx
   62afb:      	je	0x7085f <f.2+0x180af>
   62b01:      	addq	0x18(%rsp), %rax
   62b06:      	cmpq	$0x10, %r12
   62b0a:      	je	0x62bad <f.2+0xa3fd>
   62b10:      	movq	%rax, 0x18(%rsp)
   62b15:      	movq	$0x0, 0x48(%rsp)
   62b1e:      	movq	$0x3, 0x30(%rsp)
   62b27:      	xorl	%edi, %edi
   62b29:      	leaq	-0x10(%r12), %rsi
   62b2e:      	callq	0x70870 <f.3>
   62b33:      	subq	$0x8, %rsp
   62b37:      	cmpb	$0x0, 0x12f12(%rip)     # 0x75a50 <g.4>
   62b3e:      	je	0x7085f <f.2+0x180af>
   62b44:      	movq	%rax, 0x50(%rsp)
   62b49:      	cmpq	$0x0, 0x12ef7(%rip)     # 0x75a48 <g.3>
   62b51:      	je	0x7085f <f.2+0x180af>
   62b57:      	leaq	-0x11(%r12), %rsi
   62b5c:      	movq	$0x0, 0x48(%rsp)
   62b65:      	movq	$0x3, 0x30(%rsp)
   62b6e:      	xorl	%edi, %edi
   62b70:      	callq	0x70870 <f.3>
   62b75:      	subq	$0x8, %rsp
   62b79:      	cmpb	$0x0, 0x12ed0(%rip)     # 0x75a50 <g.4>
   62b80:      	je	0x7085f <f.2+0x180af>
   62b86:      	movq	%rax, %rdx
   62b89:      	addq	0x50(%rsp), %rdx
   62b8e:      	addq	0x18(%rsp), %rdx
   62b93:      	movq	0x10(%rsp), %rcx
   62b98:      	jmp	0x62bb2 <f.2+0xa402>
   62b9a:      	movl	$0x1, %eax
   62b9f:      	cmpq	$0x0, 0x12ea1(%rip)     # 0x75a48 <g.3>
   62ba7:      	je	0x7085f <f.2+0x180af>
   62bad:      	leaq	-0xf(%r12,%rax), %rdx
   62bb2:      	cmpq	$0x0, 0x12e8e(%rip)     # 0x75a48 <g.3>
   62bba:      	je	0x7085f <f.2+0x180af>
   62bc0:      	cmpq	$0xf, %r12
   62bc4:      	ja	0x62bd0 <f.2+0xa420>
   62bc6:      	leaq	-0xe(%r12), %rsi
   62bcb:      	jmp	0x62db8 <f.2+0xa608>
   62bd0:      	cmpq	$0x10, %r12
   62bd4:      	jne	0x62bee <f.2+0xa43e>
   62bd6:      	movl	$0x1, %esi
   62bdb:      	cmpq	$0x0, 0x12e65(%rip)     # 0x75a48 <g.3>
   62be3:      	jne	0x62c93 <f.2+0xa4e3>
   62be9:      	jmp	0x7085f <f.2+0x180af>
   62bee:      	movq	%rdx, 0x18(%rsp)
   62bf3:      	movq	%rcx, 0x10(%rsp)
   62bf8:      	leaq	-0x10(%r12), %rsi
   62bfd:      	movq	$0x0, 0x48(%rsp)
   62c06:      	movq	$0x3, 0x30(%rsp)
   62c0f:      	xorl	%edi, %edi
   62c11:      	callq	0x70870 <f.3>
   62c16:      	subq	$0x8, %rsp
   62c1a:      	cmpb	$0x0, 0x12e2f(%rip)     # 0x75a50 <g.4>
   62c21:      	je	0x7085f <f.2+0x180af>
   62c27:      	movq	%rax, 0x50(%rsp)
   62c2c:      	cmpq	$0x0, 0x12e14(%rip)     # 0x75a48 <g.3>
   62c34:      	je	0x7085f <f.2+0x180af>
   62c3a:      	leaq	-0x11(%r12), %rsi
   62c3f:      	movq	$0x0, 0x48(%rsp)
   62c48:      	movq	$0x3, 0x30(%rsp)
   62c51:      	xorl	%edi, %edi
   62c53:      	callq	0x70870 <f.3>
   62c58:      	subq	$0x8, %rsp
   62c5c:      	cmpb	$0x0, 0x12ded(%rip)     # 0x75a50 <g.4>
   62c63:      	je	0x7085f <f.2+0x180af>
   62c69:      	cmpq	$0x0, 0x12dd7(%rip)     # 0x75a48 <g.3>
   62c71:      	movq	0x10(%rsp), %rcx
   62c76:      	movq	0x18(%rsp), %rdx
   62c7b:      	je	0x7085f <f.2+0x180af>
   62c81:      	movq	%rax, %rsi
   62c84:      	addq	0x50(%rsp), %rsi
   62c89:      	cmpq	$0x11, %r12
   62c8d:      	ja	0x62d38 <f.2+0xa588>
   62c93:      	leaq	-0x10(%r12), %rax
   62c98:      	jmp	0x62db5 <f.2+0xa605>
   62c9d:      	movq	%rsi, 0x50(%rsp)
   62ca2:      	movq	$0x0, 0x48(%rsp)
   62cab:      	movq	$0x3, 0x30(%rsp)
   62cb4:      	xorl	%edi, %edi
   62cb6:      	leaq	-0x11(%r12), %rsi
   62cbb:      	callq	0x70870 <f.3>
   62cc0:      	subq	$0x8, %rsp
   62cc4:      	cmpb	$0x0, 0x12d85(%rip)     # 0x75a50 <g.4>
   62ccb:      	je	0x7085f <f.2+0x180af>
   62cd1:      	movq	%rax, 0x58(%rsp)
   62cd6:      	cmpq	$0x0, 0x12d6a(%rip)     # 0x75a48 <g.3>
   62cde:      	je	0x7085f <f.2+0x180af>
   62ce4:      	leaq	-0x12(%r12), %rsi
   62ce9:      	movq	$0x0, 0x48(%rsp)
   62cf2:      	movq	$0x3, 0x30(%rsp)
   62cfb:      	xorl	%edi, %edi
   62cfd:      	callq	0x70870 <f.3>
   62d02:      	subq	$0x8, %rsp
   62d06:      	addq	0x58(%rsp), %rax
   62d0b:      	movq	0x10(%rsp), %rcx
   62d10:      	movq	0x18(%rsp), %rdx
   62d15:      	movq	0x50(%rsp), %rsi
   62d1a:      	addq	%rax, %rsi
   62d1d:      	addq	%rsi, %rdx
   62d20:      	addq	%rdx, %rcx
   62d23:      	addq	%rcx, %r13
   62d26:      	cmpb	$0x0, 0x12d23(%rip)     # 0x75a50 <g.4>
   62d2d:      	jne	0x609d3 <f.2+0x8223>
   62d33:      	jmp	0x7085f <f.2+0x180af>
   62d38:      	movq	%rsi, 0x50(%rsp)
   62d3d:      	movq	$0x0, 0x48(%rsp)
   62d46:      	movq	$0x3, 0x30(%rsp)
   62d4f:      	xorl	%edi, %edi
   62d51:      	leaq	-0x11(%r12), %rsi
   62d56:      	callq	0x70870 <f.3>
   62d5b:      	subq	$0x8, %rsp
   62d5f:      	cmpb	$0x0, 0x12cea(%rip)     # 0x75a50 <g.4>
   62d66:      	je	0x7085f <f.2+0x180af>
   62d6c:      	movq	%rax, 0x58(%rsp)
   62d71:      	cmpq	$0x0, 0x12ccf(%rip)     # 0x75a48 <g.3>
   62d79:      	je	0x7085f <f.2+0x180af>
   62d7f:      	leaq	-0x12(%r12), %rsi
   62d84:      	movq	$0x0, 0x48(%rsp)
   62d8d:      	movq	$0x3, 0x30(%rsp)
   62d96:      	xorl	%edi, %edi
   62d98:      	callq	0x70870 <f.3>
   62d9d:      	subq	$0x8, %rsp
   62da1:      	addq	0x58(%rsp), %rax
   62da6:      	movq	0x10(%rsp), %rcx
   62dab:      	movq	0x18(%rsp), %rdx
   62db0:      	movq	0x50(%rsp), %rsi
   62db5:      	addq	%rax, %rsi
   62db8:      	addq	%rsi, %rdx
   62dbb:      	addq	%rdx, %r14
   62dbe:      	cmpb	$0x0, 0x12c8b(%rip)     # 0x75a50 <g.4>
   62dc5:      	je	0x7085f <f.2+0x180af>
   62dcb:      	addq	%rcx, %r14
   62dce:      	addq	%r15, %r14
   62dd1:      	cmpq	$0x0, 0x12c6f(%rip)     # 0x75a48 <g.3>
   62dd9:      	je	0x7085f <f.2+0x180af>
   62ddf:      	cmpq	$0x8, %r12
   62de3:      	ja	0x62def <f.2+0xa63f>
   62de5:      	leaq	-0x7(%r12), %r15
   62dea:      	jmp	0x645fa <f.2+0xbe4a>
   62def:      	cmpq	$0x9, %r12
   62df3:      	jne	0x62e0e <f.2+0xa65e>
   62df5:      	movl	$0x1, %r15d
   62dfb:      	cmpq	$0x0, 0x12c45(%rip)     # 0x75a48 <g.3>
   62e03:      	jne	0x639e4 <f.2+0xb234>
   62e09:      	jmp	0x7085f <f.2+0x180af>
   62e0e:      	cmpq	$0xb, %r12
   62e12:      	jb	0x62e2f <f.2+0xa67f>
   62e14:      	jne	0x62e47 <f.2+0xa697>
   62e16:      	movl	$0x1, %r15d
   62e1c:      	cmpq	$0x0, 0x12c24(%rip)     # 0x75a48 <g.3>
   62e24:      	jne	0x63105 <f.2+0xa955>
   62e2a:      	jmp	0x7085f <f.2+0x180af>
   62e2f:      	movl	$0x1, %ecx
   62e34:      	cmpq	$0x0, 0x12c0c(%rip)     # 0x75a48 <g.3>
   62e3c:      	jne	0x633e4 <f.2+0xac34>
   62e42:      	jmp	0x7085f <f.2+0x180af>
   62e47:      	cmpq	$0xd, %r12
   62e4b:      	jb	0x62e68 <f.2+0xa6b8>
   62e4d:      	jne	0x62e80 <f.2+0xa6d0>
   62e4f:      	movl	$0x1, %r15d
   62e55:      	cmpq	$0x0, 0x12beb(%rip)     # 0x75a48 <g.3>
   62e5d:      	jne	0x62f0d <f.2+0xa75d>
   62e63:      	jmp	0x7085f <f.2+0x180af>
   62e68:      	movl	$0x1, %eax
   62e6d:      	cmpq	$0x0, 0x12bd3(%rip)     # 0x75a48 <g.3>
   62e75:      	jne	0x62fa7 <f.2+0xa7f7>
   62e7b:      	jmp	0x7085f <f.2+0x180af>
   62e80:      	leaq	-0xd(%r12), %rsi
   62e85:      	movq	$0x0, 0x48(%rsp)
   62e8e:      	movq	$0x3, 0x30(%rsp)
   62e97:      	xorl	%edi, %edi
   62e99:      	callq	0x70870 <f.3>
   62e9e:      	subq	$0x8, %rsp
   62ea2:      	cmpb	$0x0, 0x12ba7(%rip)     # 0x75a50 <g.4>
   62ea9:      	je	0x7085f <f.2+0x180af>
   62eaf:      	movq	%rax, 0x10(%rsp)
   62eb4:      	cmpq	$0x0, 0x12b8c(%rip)     # 0x75a48 <g.3>
   62ebc:      	je	0x7085f <f.2+0x180af>
   62ec2:      	leaq	-0xe(%r12), %rsi
   62ec7:      	movq	$0x0, 0x48(%rsp)
   62ed0:      	movq	$0x3, 0x30(%rsp)
   62ed9:      	xorl	%edi, %edi
   62edb:      	callq	0x70870 <f.3>
   62ee0:      	subq	$0x8, %rsp
   62ee4:      	cmpb	$0x0, 0x12b65(%rip)     # 0x75a50 <g.4>
   62eeb:      	je	0x7085f <f.2+0x180af>
   62ef1:      	cmpq	$0x0, 0x12b4f(%rip)     # 0x75a48 <g.3>
   62ef9:      	je	0x7085f <f.2+0x180af>
   62eff:      	movq	%rax, %r15
   62f02:      	addq	0x10(%rsp), %r15
   62f07:      	cmpq	$0xe, %r12
   62f0b:      	ja	0x62f14 <f.2+0xa764>
   62f0d:      	leaq	-0xd(%r12,%r15), %rax
   62f12:      	jmp	0x62f8d <f.2+0xa7dd>
   62f14:      	movq	$0x0, 0x48(%rsp)
   62f1d:      	movq	$0x3, 0x30(%rsp)
   62f26:      	xorl	%edi, %edi
   62f28:      	leaq	-0xe(%r12), %rsi
   62f2d:      	callq	0x70870 <f.3>
   62f32:      	subq	$0x8, %rsp
   62f36:      	cmpb	$0x0, 0x12b13(%rip)     # 0x75a50 <g.4>
   62f3d:      	je	0x7085f <f.2+0x180af>
   62f43:      	movq	%rax, 0x10(%rsp)
   62f48:      	cmpq	$0x0, 0x12af8(%rip)     # 0x75a48 <g.3>
   62f50:      	je	0x7085f <f.2+0x180af>
   62f56:      	leaq	-0xf(%r12), %rsi
   62f5b:      	movq	$0x0, 0x48(%rsp)
   62f64:      	movq	$0x3, 0x30(%rsp)
   62f6d:      	xorl	%edi, %edi
   62f6f:      	callq	0x70870 <f.3>
   62f74:      	subq	$0x8, %rsp
   62f78:      	cmpb	$0x0, 0x12ad1(%rip)     # 0x75a50 <g.4>
   62f7f:      	je	0x7085f <f.2+0x180af>
   62f85:      	addq	0x10(%rsp), %rax
   62f8a:      	addq	%r15, %rax
   62f8d:      	cmpq	$0x0, 0x12ab3(%rip)     # 0x75a48 <g.3>
   62f95:      	je	0x7085f <f.2+0x180af>
   62f9b:      	cmpq	$0xe, %r12
   62f9f:      	je	0x62fb1 <f.2+0xa801>
   62fa1:      	cmpq	$0xd, %r12
   62fa5:      	jne	0x62fc9 <f.2+0xa819>
   62fa7:      	leaq	-0xc(%r12,%rax), %r15
   62fac:      	jmp	0x630f1 <f.2+0xa941>
   62fb1:      	movl	$0x1, %ecx
   62fb6:      	cmpq	$0x0, 0x12a8a(%rip)     # 0x75a48 <g.3>
   62fbe:      	jne	0x6305c <f.2+0xa8ac>
   62fc4:      	jmp	0x7085f <f.2+0x180af>
   62fc9:      	movq	%rax, 0x10(%rsp)
   62fce:      	leaq	-0xe(%r12), %rsi
   62fd3:      	movq	$0x0, 0x48(%rsp)
   62fdc:      	movq	$0x3, 0x30(%rsp)
   62fe5:      	xorl	%edi, %edi
   62fe7:      	callq	0x70870 <f.3>
   62fec:      	subq	$0x8, %rsp
   62ff0:      	cmpb	$0x0, 0x12a59(%rip)     # 0x75a50 <g.4>
   62ff7:      	je	0x7085f <f.2+0x180af>
   62ffd:      	cmpq	$0x0, 0x12a43(%rip)     # 0x75a48 <g.3>
   63005:      	je	0x7085f <f.2+0x180af>
   6300b:      	movq	%rax, %r15
   6300e:      	leaq	-0xf(%r12), %rsi
   63013:      	movq	$0x0, 0x48(%rsp)
   6301c:      	movq	$0x3, 0x30(%rsp)
   63025:      	xorl	%edi, %edi
   63027:      	callq	0x70870 <f.3>
   6302c:      	subq	$0x8, %rsp
   63030:      	cmpb	$0x0, 0x12a19(%rip)     # 0x75a50 <g.4>
   63037:      	je	0x7085f <f.2+0x180af>
   6303d:      	movq	%rax, %rcx
   63040:      	cmpq	$0x0, 0x12a00(%rip)     # 0x75a48 <g.3>
   63048:      	movq	0x10(%rsp), %rax
   6304d:      	je	0x7085f <f.2+0x180af>
   63053:      	addq	%r15, %rcx
   63056:      	cmpq	$0xf, %r12
   6305a:      	ja	0x63063 <f.2+0xa8b3>
   6305c:      	leaq	-0xe(%r12), %r15
   63061:      	jmp	0x630de <f.2+0xa92e>
   63063:      	movq	%rcx, 0x18(%rsp)
   63068:      	movq	$0x0, 0x48(%rsp)
   63071:      	movq	$0x3, 0x30(%rsp)
   6307a:      	xorl	%edi, %edi
   6307c:      	leaq	-0xf(%r12), %rsi
   63081:      	callq	0x70870 <f.3>
   63086:      	subq	$0x8, %rsp
   6308a:      	cmpb	$0x0, 0x129bf(%rip)     # 0x75a50 <g.4>
   63091:      	je	0x7085f <f.2+0x180af>
   63097:      	movq	%rax, 0x50(%rsp)
   6309c:      	cmpq	$0x0, 0x129a4(%rip)     # 0x75a48 <g.3>
   630a4:      	je	0x7085f <f.2+0x180af>
   630aa:      	leaq	-0x10(%r12), %rsi
   630af:      	movq	$0x0, 0x48(%rsp)
   630b8:      	movq	$0x3, 0x30(%rsp)
   630c1:      	xorl	%edi, %edi
   630c3:      	callq	0x70870 <f.3>
   630c8:      	subq	$0x8, %rsp
   630cc:      	movq	%rax, %r15
   630cf:      	addq	0x50(%rsp), %r15
   630d4:      	movq	0x10(%rsp), %rax
   630d9:      	movq	0x18(%rsp), %rcx
   630de:      	cmpb	$0x0, 0x1296b(%rip)     # 0x75a50 <g.4>
   630e5:      	je	0x7085f <f.2+0x180af>
   630eb:      	addq	%rcx, %r15
   630ee:      	addq	%rax, %r15
   630f1:      	cmpq	$0x0, 0x1294f(%rip)     # 0x75a48 <g.3>
   630f9:      	je	0x7085f <f.2+0x180af>
   630ff:      	cmpq	$0xc, %r12
   63103:      	ja	0x6310f <f.2+0xa95f>
   63105:      	leaq	-0xb(%r12,%r15), %rcx
   6310a:      	jmp	0x633ca <f.2+0xac1a>
   6310f:      	cmpq	$0xd, %r12
   63113:      	jne	0x6312d <f.2+0xa97d>
   63115:      	movl	$0x1, %edx
   6311a:      	cmpq	$0x0, 0x12926(%rip)     # 0x75a48 <g.3>
   63122:      	jne	0x63276 <f.2+0xaac6>
   63128:      	jmp	0x7085f <f.2+0x180af>
   6312d:      	cmpq	$0xf, %r12
   63131:      	jb	0x6324a <f.2+0xaa9a>
   63137:      	leaq	-0xe(%r12), %rsi
   6313c:      	movq	$0x0, 0x48(%rsp)
   63145:      	movq	$0x3, 0x30(%rsp)
   6314e:      	xorl	%edi, %edi
   63150:      	callq	0x70870 <f.3>
   63155:      	subq	$0x8, %rsp
   63159:      	cmpb	$0x0, 0x128f0(%rip)     # 0x75a50 <g.4>
   63160:      	je	0x7085f <f.2+0x180af>
   63166:      	movq	%rax, 0x10(%rsp)
   6316b:      	cmpq	$0x0, 0x128d5(%rip)     # 0x75a48 <g.3>
   63173:      	je	0x7085f <f.2+0x180af>
   63179:      	leaq	-0xf(%r12), %rsi
   6317e:      	movq	$0x0, 0x48(%rsp)
   63187:      	movq	$0x3, 0x30(%rsp)
   63190:      	xorl	%edi, %edi
   63192:      	callq	0x70870 <f.3>
   63197:      	subq	$0x8, %rsp
   6319b:      	cmpb	$0x0, 0x128ae(%rip)     # 0x75a50 <g.4>
   631a2:      	je	0x7085f <f.2+0x180af>
   631a8:      	cmpq	$0x0, 0x12898(%rip)     # 0x75a48 <g.3>
   631b0:      	je	0x7085f <f.2+0x180af>
   631b6:      	addq	0x10(%rsp), %rax
   631bb:      	cmpq	$0xf, %r12
   631bf:      	je	0x6325d <f.2+0xaaad>
   631c5:      	movq	%rax, 0x10(%rsp)
   631ca:      	movq	$0x0, 0x48(%rsp)
   631d3:      	movq	$0x3, 0x30(%rsp)
   631dc:      	xorl	%edi, %edi
   631de:      	leaq	-0xf(%r12), %rsi
   631e3:      	callq	0x70870 <f.3>
   631e8:      	subq	$0x8, %rsp
   631ec:      	cmpb	$0x0, 0x1285d(%rip)     # 0x75a50 <g.4>
   631f3:      	je	0x7085f <f.2+0x180af>
   631f9:      	movq	%rax, 0x18(%rsp)
   631fe:      	cmpq	$0x0, 0x12842(%rip)     # 0x75a48 <g.3>
   63206:      	je	0x7085f <f.2+0x180af>
   6320c:      	leaq	-0x10(%r12), %rsi
   63211:      	movq	$0x0, 0x48(%rsp)
   6321a:      	movq	$0x3, 0x30(%rsp)
   63223:      	xorl	%edi, %edi
   63225:      	callq	0x70870 <f.3>
   6322a:      	subq	$0x8, %rsp
   6322e:      	cmpb	$0x0, 0x1281b(%rip)     # 0x75a50 <g.4>
   63235:      	je	0x7085f <f.2+0x180af>
   6323b:      	movq	%rax, %rdx
   6323e:      	addq	0x18(%rsp), %rdx
   63243:      	addq	0x10(%rsp), %rdx
   63248:      	jmp	0x63262 <f.2+0xaab2>
   6324a:      	movl	$0x1, %eax
   6324f:      	cmpq	$0x0, 0x127f1(%rip)     # 0x75a48 <g.3>
   63257:      	je	0x7085f <f.2+0x180af>
   6325d:      	leaq	-0xe(%r12,%rax), %rdx
   63262:      	cmpq	$0x0, 0x127de(%rip)     # 0x75a48 <g.3>
   6326a:      	je	0x7085f <f.2+0x180af>
   63270:      	cmpq	$0xe, %r12
   63274:      	ja	0x63280 <f.2+0xaad0>
   63276:      	leaq	-0xd(%r12), %rcx
   6327b:      	jmp	0x633b7 <f.2+0xac07>
   63280:      	cmpq	$0xf, %r12
   63284:      	jne	0x6329e <f.2+0xaaee>
   63286:      	movl	$0x1, %ecx
   6328b:      	cmpq	$0x0, 0x127b5(%rip)     # 0x75a48 <g.3>
   63293:      	jne	0x63335 <f.2+0xab85>
   63299:      	jmp	0x7085f <f.2+0x180af>
   6329e:      	movq	%rdx, 0x18(%rsp)
   632a3:      	leaq	-0xf(%r12), %rsi
   632a8:      	movq	$0x0, 0x48(%rsp)
   632b1:      	movq	$0x3, 0x30(%rsp)
   632ba:      	xorl	%edi, %edi
   632bc:      	callq	0x70870 <f.3>
   632c1:      	subq	$0x8, %rsp
   632c5:      	cmpb	$0x0, 0x12784(%rip)     # 0x75a50 <g.4>
   632cc:      	je	0x7085f <f.2+0x180af>
   632d2:      	movq	%rax, 0x10(%rsp)
   632d7:      	cmpq	$0x0, 0x12769(%rip)     # 0x75a48 <g.3>
   632df:      	je	0x7085f <f.2+0x180af>
   632e5:      	leaq	-0x10(%r12), %rsi
   632ea:      	movq	$0x0, 0x48(%rsp)
   632f3:      	movq	$0x3, 0x30(%rsp)
   632fc:      	xorl	%edi, %edi
   632fe:      	callq	0x70870 <f.3>
   63303:      	subq	$0x8, %rsp
   63307:      	cmpb	$0x0, 0x12742(%rip)     # 0x75a50 <g.4>
   6330e:      	je	0x7085f <f.2+0x180af>
   63314:      	cmpq	$0x0, 0x1272c(%rip)     # 0x75a48 <g.3>
   6331c:      	movq	0x18(%rsp), %rdx
   63321:      	je	0x7085f <f.2+0x180af>
   63327:      	movq	%rax, %rcx
   6332a:      	addq	0x10(%rsp), %rcx
   6332f:      	cmpq	$0x10, %r12
   63333:      	ja	0x6333c <f.2+0xab8c>
   63335:      	leaq	-0xf(%r12), %rax
   6333a:      	jmp	0x633b4 <f.2+0xac04>
   6333c:      	movq	%rcx, 0x10(%rsp)
   63341:      	movq	$0x0, 0x48(%rsp)
   6334a:      	movq	$0x3, 0x30(%rsp)
   63353:      	xorl	%edi, %edi
   63355:      	leaq	-0x10(%r12), %rsi
   6335a:      	callq	0x70870 <f.3>
   6335f:      	subq	$0x8, %rsp
   63363:      	cmpb	$0x0, 0x126e6(%rip)     # 0x75a50 <g.4>
   6336a:      	je	0x7085f <f.2+0x180af>
   63370:      	movq	%rax, 0x50(%rsp)
   63375:      	cmpq	$0x0, 0x126cb(%rip)     # 0x75a48 <g.3>
   6337d:      	je	0x7085f <f.2+0x180af>
   63383:      	leaq	-0x11(%r12), %rsi
   63388:      	movq	$0x0, 0x48(%rsp)
   63391:      	movq	$0x3, 0x30(%rsp)
   6339a:      	xorl	%edi, %edi
   6339c:      	callq	0x70870 <f.3>
   633a1:      	subq	$0x8, %rsp
   633a5:      	addq	0x50(%rsp), %rax
   633aa:      	movq	0x10(%rsp), %rcx
   633af:      	movq	0x18(%rsp), %rdx
   633b4:      	addq	%rax, %rcx
   633b7:      	cmpb	$0x0, 0x12692(%rip)     # 0x75a50 <g.4>
   633be:      	je	0x7085f <f.2+0x180af>
   633c4:      	addq	%rdx, %rcx
   633c7:      	addq	%r15, %rcx
   633ca:      	cmpq	$0x0, 0x12676(%rip)     # 0x75a48 <g.3>
   633d2:      	je	0x7085f <f.2+0x180af>
   633d8:      	cmpq	$0xc, %r12
   633dc:      	je	0x633ee <f.2+0xac3e>
   633de:      	cmpq	$0xb, %r12
   633e2:      	jne	0x63406 <f.2+0xac56>
   633e4:      	leaq	-0xa(%r12,%rcx), %r15
   633e9:      	jmp	0x639d0 <f.2+0xb220>
   633ee:      	movl	$0x1, %edx
   633f3:      	cmpq	$0x0, 0x1264d(%rip)     # 0x75a48 <g.3>
   633fb:      	jne	0x636de <f.2+0xaf2e>
   63401:      	jmp	0x7085f <f.2+0x180af>
   63406:      	cmpq	$0xe, %r12
   6340a:      	jb	0x63427 <f.2+0xac77>
   6340c:      	jne	0x6343f <f.2+0xac8f>
   6340e:      	movl	$0x1, %r15d
   63414:      	cmpq	$0x0, 0x1262c(%rip)     # 0x75a48 <g.3>
   6341c:      	jne	0x634d6 <f.2+0xad26>
   63422:      	jmp	0x7085f <f.2+0x180af>
   63427:      	movl	$0x1, %eax
   6342c:      	cmpq	$0x0, 0x12614(%rip)     # 0x75a48 <g.3>
   63434:      	jne	0x63575 <f.2+0xadc5>
   6343a:      	jmp	0x7085f <f.2+0x180af>
   6343f:      	movq	%rcx, 0x10(%rsp)
   63444:      	leaq	-0xe(%r12), %rsi
   63449:      	movq	$0x0, 0x48(%rsp)
   63452:      	movq	$0x3, 0x30(%rsp)
   6345b:      	xorl	%edi, %edi
   6345d:      	callq	0x70870 <f.3>
   63462:      	subq	$0x8, %rsp
   63466:      	cmpb	$0x0, 0x125e3(%rip)     # 0x75a50 <g.4>
   6346d:      	je	0x7085f <f.2+0x180af>
   63473:      	movq	%rax, 0x18(%rsp)
   63478:      	cmpq	$0x0, 0x125c8(%rip)     # 0x75a48 <g.3>
   63480:      	je	0x7085f <f.2+0x180af>
   63486:      	leaq	-0xf(%r12), %rsi
   6348b:      	movq	$0x0, 0x48(%rsp)
   63494:      	movq	$0x3, 0x30(%rsp)
   6349d:      	xorl	%edi, %edi
   6349f:      	callq	0x70870 <f.3>
   634a4:      	subq	$0x8, %rsp
   634a8:      	cmpb	$0x0, 0x125a1(%rip)     # 0x75a50 <g.4>
   634af:      	je	0x7085f <f.2+0x180af>
   634b5:      	cmpq	$0x0, 0x1258b(%rip)     # 0x75a48 <g.3>
   634bd:      	movq	0x10(%rsp), %rcx
   634c2:      	je	0x7085f <f.2+0x180af>
   634c8:      	movq	%rax, %r15
   634cb:      	addq	0x18(%rsp), %r15
   634d0:      	cmpq	$0xf, %r12
   634d4:      	ja	0x634dd <f.2+0xad2d>
   634d6:      	leaq	-0xe(%r12,%r15), %rax
   634db:      	jmp	0x6355b <f.2+0xadab>
   634dd:      	movq	$0x0, 0x48(%rsp)
   634e6:      	movq	$0x3, 0x30(%rsp)
   634ef:      	xorl	%edi, %edi
   634f1:      	leaq	-0xf(%r12), %rsi
   634f6:      	callq	0x70870 <f.3>
   634fb:      	subq	$0x8, %rsp
   634ff:      	cmpb	$0x0, 0x1254a(%rip)     # 0x75a50 <g.4>
   63506:      	je	0x7085f <f.2+0x180af>
   6350c:      	movq	%rax, 0x18(%rsp)
   63511:      	cmpq	$0x0, 0x1252f(%rip)     # 0x75a48 <g.3>
   63519:      	je	0x7085f <f.2+0x180af>
   6351f:      	leaq	-0x10(%r12), %rsi
   63524:      	movq	$0x0, 0x48(%rsp)
   6352d:      	movq	$0x3, 0x30(%rsp)
   63536:      	xorl	%edi, %edi
   63538:      	callq	0x70870 <f.3>
   6353d:      	subq	$0x8, %rsp
   63541:      	cmpb	$0x0, 0x12508(%rip)     # 0x75a50 <g.4>
   63548:      	je	0x7085f <f.2+0x180af>
   6354e:      	addq	0x18(%rsp), %rax
   63553:      	addq	%r15, %rax
   63556:      	movq	0x10(%rsp), %rcx
   6355b:      	cmpq	$0x0, 0x124e5(%rip)     # 0x75a48 <g.3>
   63563:      	je	0x7085f <f.2+0x180af>
   63569:      	cmpq	$0xf, %r12
   6356d:      	je	0x6357f <f.2+0xadcf>
   6356f:      	cmpq	$0xe, %r12
   63573:      	jne	0x63597 <f.2+0xade7>
   63575:      	leaq	-0xd(%r12,%rax), %rdx
   6357a:      	jmp	0x636ca <f.2+0xaf1a>
   6357f:      	movl	$0x1, %esi
   63584:      	cmpq	$0x0, 0x124bc(%rip)     # 0x75a48 <g.3>
   6358c:      	jne	0x63634 <f.2+0xae84>
   63592:      	jmp	0x7085f <f.2+0x180af>
   63597:      	movq	%rax, 0x18(%rsp)
   6359c:      	movq	%rcx, 0x10(%rsp)
   635a1:      	leaq	-0xf(%r12), %rsi
   635a6:      	movq	$0x0, 0x48(%rsp)
   635af:      	movq	$0x3, 0x30(%rsp)
   635b8:      	xorl	%edi, %edi
   635ba:      	callq	0x70870 <f.3>
   635bf:      	subq	$0x8, %rsp
   635c3:      	cmpb	$0x0, 0x12486(%rip)     # 0x75a50 <g.4>
   635ca:      	je	0x7085f <f.2+0x180af>
   635d0:      	cmpq	$0x0, 0x12470(%rip)     # 0x75a48 <g.3>
   635d8:      	je	0x7085f <f.2+0x180af>
   635de:      	movq	%rax, %r15
   635e1:      	leaq	-0x10(%r12), %rsi
   635e6:      	movq	$0x0, 0x48(%rsp)
   635ef:      	movq	$0x3, 0x30(%rsp)
   635f8:      	xorl	%edi, %edi
   635fa:      	callq	0x70870 <f.3>
   635ff:      	subq	$0x8, %rsp
   63603:      	cmpb	$0x0, 0x12446(%rip)     # 0x75a50 <g.4>
   6360a:      	je	0x7085f <f.2+0x180af>
   63610:      	movq	%rax, %rsi
   63613:      	cmpq	$0x0, 0x1242d(%rip)     # 0x75a48 <g.3>
   6361b:      	movq	0x10(%rsp), %rcx
   63620:      	movq	0x18(%rsp), %rax
   63625:      	je	0x7085f <f.2+0x180af>
   6362b:      	addq	%r15, %rsi
   6362e:      	cmpq	$0x10, %r12
   63632:      	ja	0x6363b <f.2+0xae8b>
   63634:      	leaq	-0xf(%r12), %rdx
   63639:      	jmp	0x636b7 <f.2+0xaf07>
   6363b:      	movq	%rsi, 0x50(%rsp)
   63640:      	movq	$0x0, 0x48(%rsp)
   63649:      	movq	$0x3, 0x30(%rsp)
   63652:      	xorl	%edi, %edi
   63654:      	leaq	-0x10(%r12), %rsi
   63659:      	callq	0x70870 <f.3>
   6365e:      	subq	$0x8, %rsp
   63662:      	cmpb	$0x0, 0x123e7(%rip)     # 0x75a50 <g.4>
   63669:      	je	0x7085f <f.2+0x180af>
   6366f:      	cmpq	$0x0, 0x123d1(%rip)     # 0x75a48 <g.3>
   63677:      	je	0x7085f <f.2+0x180af>
   6367d:      	movq	%rax, %r15
   63680:      	leaq	-0x11(%r12), %rsi
   63685:      	movq	$0x0, 0x48(%rsp)
   6368e:      	movq	$0x3, 0x30(%rsp)
   63697:      	xorl	%edi, %edi
   63699:      	callq	0x70870 <f.3>
   6369e:      	subq	$0x8, %rsp
   636a2:      	movq	%rax, %rdx
   636a5:      	addq	%r15, %rdx
   636a8:      	movq	0x10(%rsp), %rcx
   636ad:      	movq	0x18(%rsp), %rax
   636b2:      	movq	0x50(%rsp), %rsi
   636b7:      	cmpb	$0x0, 0x12392(%rip)     # 0x75a50 <g.4>
   636be:      	je	0x7085f <f.2+0x180af>
   636c4:      	addq	%rsi, %rdx
   636c7:      	addq	%rax, %rdx
   636ca:      	cmpq	$0x0, 0x12376(%rip)     # 0x75a48 <g.3>
   636d2:      	je	0x7085f <f.2+0x180af>
   636d8:      	cmpq	$0xd, %r12
   636dc:      	ja	0x636e8 <f.2+0xaf38>
   636de:      	leaq	-0xc(%r12), %r15
   636e3:      	jmp	0x639bd <f.2+0xb20d>
   636e8:      	cmpq	$0xe, %r12
   636ec:      	jne	0x63707 <f.2+0xaf57>
   636ee:      	movl	$0x1, %r15d
   636f4:      	cmpq	$0x0, 0x1234c(%rip)     # 0x75a48 <g.3>
   636fc:      	jne	0x6386a <f.2+0xb0ba>
   63702:      	jmp	0x7085f <f.2+0x180af>
   63707:      	cmpq	$0x10, %r12
   6370b:      	jb	0x6383e <f.2+0xb08e>
   63711:      	movq	%rdx, 0x18(%rsp)
   63716:      	movq	%rcx, 0x10(%rsp)
   6371b:      	leaq	-0xf(%r12), %rsi
   63720:      	movq	$0x0, 0x48(%rsp)
   63729:      	movq	$0x3, 0x30(%rsp)
   63732:      	xorl	%edi, %edi
   63734:      	callq	0x70870 <f.3>
   63739:      	subq	$0x8, %rsp
   6373d:      	cmpb	$0x0, 0x1230c(%rip)     # 0x75a50 <g.4>
   63744:      	je	0x7085f <f.2+0x180af>
   6374a:      	cmpq	$0x0, 0x122f6(%rip)     # 0x75a48 <g.3>
   63752:      	je	0x7085f <f.2+0x180af>
   63758:      	movq	%rax, %r15
   6375b:      	leaq	-0x10(%r12), %rsi
   63760:      	movq	$0x0, 0x48(%rsp)
   63769:      	movq	$0x3, 0x30(%rsp)
   63772:      	xorl	%edi, %edi
   63774:      	callq	0x70870 <f.3>
   63779:      	subq	$0x8, %rsp
   6377d:      	cmpb	$0x0, 0x122cc(%rip)     # 0x75a50 <g.4>
   63784:      	je	0x7085f <f.2+0x180af>
   6378a:      	cmpq	$0x0, 0x122b6(%rip)     # 0x75a48 <g.3>
   63792:      	movq	0x10(%rsp), %rcx
   63797:      	movq	0x18(%rsp), %rdx
   6379c:      	je	0x7085f <f.2+0x180af>
   637a2:      	addq	%r15, %rax
   637a5:      	cmpq	$0x10, %r12
   637a9:      	je	0x63851 <f.2+0xb0a1>
   637af:      	movq	%rax, 0x50(%rsp)
   637b4:      	movq	$0x0, 0x48(%rsp)
   637bd:      	movq	$0x3, 0x30(%rsp)
   637c6:      	xorl	%edi, %edi
   637c8:      	leaq	-0x10(%r12), %rsi
   637cd:      	callq	0x70870 <f.3>
   637d2:      	subq	$0x8, %rsp
   637d6:      	cmpb	$0x0, 0x12273(%rip)     # 0x75a50 <g.4>
   637dd:      	je	0x7085f <f.2+0x180af>
   637e3:      	movq	%rax, 0x58(%rsp)
   637e8:      	cmpq	$0x0, 0x12258(%rip)     # 0x75a48 <g.3>
   637f0:      	je	0x7085f <f.2+0x180af>
   637f6:      	leaq	-0x11(%r12), %rsi
   637fb:      	movq	$0x0, 0x48(%rsp)
   63804:      	movq	$0x3, 0x30(%rsp)
   6380d:      	xorl	%edi, %edi
   6380f:      	callq	0x70870 <f.3>
   63814:      	subq	$0x8, %rsp
   63818:      	cmpb	$0x0, 0x12231(%rip)     # 0x75a50 <g.4>
   6381f:      	je	0x7085f <f.2+0x180af>
   63825:      	movq	%rax, %r15
   63828:      	addq	0x58(%rsp), %r15
   6382d:      	addq	0x50(%rsp), %r15
   63832:      	movq	0x10(%rsp), %rcx
   63837:      	movq	0x18(%rsp), %rdx
   6383c:      	jmp	0x63856 <f.2+0xb0a6>
   6383e:      	movl	$0x1, %eax
   63843:      	cmpq	$0x0, 0x121fd(%rip)     # 0x75a48 <g.3>
   6384b:      	je	0x7085f <f.2+0x180af>
   63851:      	leaq	-0xf(%r12,%rax), %r15
   63856:      	cmpq	$0x0, 0x121ea(%rip)     # 0x75a48 <g.3>
   6385e:      	je	0x7085f <f.2+0x180af>
   63864:      	cmpq	$0xf, %r12
   63868:      	ja	0x63874 <f.2+0xb0c4>
   6386a:      	leaq	-0xe(%r12), %rsi
   6386f:      	jmp	0x639ba <f.2+0xb20a>
   63874:      	cmpq	$0x10, %r12
   63878:      	jne	0x63892 <f.2+0xb0e2>
   6387a:      	movl	$0x1, %esi
   6387f:      	cmpq	$0x0, 0x121c1(%rip)     # 0x75a48 <g.3>
   63887:      	jne	0x63933 <f.2+0xb183>
   6388d:      	jmp	0x7085f <f.2+0x180af>
   63892:      	movq	%rdx, 0x18(%rsp)
   63897:      	movq	%rcx, 0x10(%rsp)
   6389c:      	leaq	-0x10(%r12), %rsi
   638a1:      	movq	$0x0, 0x48(%rsp)
   638aa:      	movq	$0x3, 0x30(%rsp)
   638b3:      	xorl	%edi, %edi
   638b5:      	callq	0x70870 <f.3>
   638ba:      	subq	$0x8, %rsp
   638be:      	cmpb	$0x0, 0x1218b(%rip)     # 0x75a50 <g.4>
   638c5:      	je	0x7085f <f.2+0x180af>
   638cb:      	movq	%rax, 0x50(%rsp)
   638d0:      	cmpq	$0x0, 0x12170(%rip)     # 0x75a48 <g.3>
   638d8:      	je	0x7085f <f.2+0x180af>
   638de:      	leaq	-0x11(%r12), %rsi
   638e3:      	movq	$0x0, 0x48(%rsp)
   638ec:      	movq	$0x3, 0x30(%rsp)
   638f5:      	xorl	%edi, %edi
   638f7:      	callq	0x70870 <f.3>
   638fc:      	subq	$0x8, %rsp
   63900:      	cmpb	$0x0, 0x12149(%rip)     # 0x75a50 <g.4>
   63907:      	je	0x7085f <f.2+0x180af>
   6390d:      	cmpq	$0x0, 0x12133(%rip)     # 0x75a48 <g.3>
   63915:      	movq	0x10(%rsp), %rcx
   6391a:      	movq	0x18(%rsp), %rdx
   6391f:      	je	0x7085f <f.2+0x180af>
   63925:      	movq	%rax, %rsi
   63928:      	addq	0x50(%rsp), %rsi
   6392d:      	cmpq	$0x11, %r12
   63931:      	ja	0x6393a <f.2+0xb18a>
   63933:      	leaq	-0x10(%r12), %rax
   63938:      	jmp	0x639b7 <f.2+0xb207>
   6393a:      	movq	%rsi, 0x50(%rsp)
   6393f:      	movq	$0x0, 0x48(%rsp)
   63948:      	movq	$0x3, 0x30(%rsp)
   63951:      	xorl	%edi, %edi
   63953:      	leaq	-0x11(%r12), %rsi
   63958:      	callq	0x70870 <f.3>
   6395d:      	subq	$0x8, %rsp
   63961:      	cmpb	$0x0, 0x120e8(%rip)     # 0x75a50 <g.4>
   63968:      	je	0x7085f <f.2+0x180af>
   6396e:      	movq	%rax, 0x58(%rsp)
   63973:      	cmpq	$0x0, 0x120cd(%rip)     # 0x75a48 <g.3>
   6397b:      	je	0x7085f <f.2+0x180af>
   63981:      	leaq	-0x12(%r12), %rsi
   63986:      	movq	$0x0, 0x48(%rsp)
   6398f:      	movq	$0x3, 0x30(%rsp)
   63998:      	xorl	%edi, %edi
   6399a:      	callq	0x70870 <f.3>
   6399f:      	subq	$0x8, %rsp
   639a3:      	addq	0x58(%rsp), %rax
   639a8:      	movq	0x10(%rsp), %rcx
   639ad:      	movq	0x18(%rsp), %rdx
   639b2:      	movq	0x50(%rsp), %rsi
   639b7:      	addq	%rax, %rsi
   639ba:      	addq	%rsi, %r15
   639bd:      	cmpb	$0x0, 0x1208c(%rip)     # 0x75a50 <g.4>
   639c4:      	je	0x7085f <f.2+0x180af>
   639ca:      	addq	%rdx, %r15
   639cd:      	addq	%rcx, %r15
   639d0:      	cmpq	$0x0, 0x12070(%rip)     # 0x75a48 <g.3>
   639d8:      	je	0x7085f <f.2+0x180af>
   639de:      	cmpq	$0xa, %r12
   639e2:      	ja	0x639ee <f.2+0xb23e>
   639e4:      	leaq	-0x9(%r12), %rcx
   639e9:      	jmp	0x645f7 <f.2+0xbe47>
   639ee:      	cmpq	$0xb, %r12
   639f2:      	jne	0x63a0c <f.2+0xb25c>
   639f4:      	movl	$0x1, %ecx
   639f9:      	cmpq	$0x0, 0x12047(%rip)     # 0x75a48 <g.3>
   63a01:      	jne	0x63fec <f.2+0xb83c>
   63a07:      	jmp	0x7085f <f.2+0x180af>
   63a0c:      	cmpq	$0xd, %r12
   63a10:      	jb	0x63a2c <f.2+0xb27c>
   63a12:      	jne	0x63a44 <f.2+0xb294>
   63a14:      	movl	$0x1, %eax
   63a19:      	cmpq	$0x0, 0x12027(%rip)     # 0x75a48 <g.3>
   63a21:      	jne	0x63b8a <f.2+0xb3da>
   63a27:      	jmp	0x7085f <f.2+0x180af>
   63a2c:      	movl	$0x1, %edx
   63a31:      	cmpq	$0x0, 0x1200f(%rip)     # 0x75a48 <g.3>
   63a39:      	jne	0x63cf8 <f.2+0xb548>
   63a3f:      	jmp	0x7085f <f.2+0x180af>
   63a44:      	cmpq	$0xf, %r12
   63a48:      	jb	0x63b5e <f.2+0xb3ae>
   63a4e:      	leaq	-0xe(%r12), %rsi
   63a53:      	movq	$0x0, 0x48(%rsp)
   63a5c:      	movq	$0x3, 0x30(%rsp)
   63a65:      	xorl	%edi, %edi
   63a67:      	callq	0x70870 <f.3>
   63a6c:      	subq	$0x8, %rsp
   63a70:      	cmpb	$0x0, 0x11fd9(%rip)     # 0x75a50 <g.4>
   63a77:      	je	0x7085f <f.2+0x180af>
   63a7d:      	movq	%rax, 0x10(%rsp)
   63a82:      	cmpq	$0x0, 0x11fbe(%rip)     # 0x75a48 <g.3>
   63a8a:      	je	0x7085f <f.2+0x180af>
   63a90:      	leaq	-0xf(%r12), %rsi
   63a95:      	movq	$0x0, 0x48(%rsp)
   63a9e:      	movq	$0x3, 0x30(%rsp)
   63aa7:      	xorl	%edi, %edi
   63aa9:      	callq	0x70870 <f.3>
   63aae:      	subq	$0x8, %rsp
   63ab2:      	cmpb	$0x0, 0x11f97(%rip)     # 0x75a50 <g.4>
   63ab9:      	je	0x7085f <f.2+0x180af>
   63abf:      	cmpq	$0x0, 0x11f81(%rip)     # 0x75a48 <g.3>
   63ac7:      	je	0x7085f <f.2+0x180af>
   63acd:      	addq	0x10(%rsp), %rax
   63ad2:      	cmpq	$0xf, %r12
   63ad6:      	je	0x63b71 <f.2+0xb3c1>
   63adc:      	movq	%rax, 0x10(%rsp)
   63ae1:      	movq	$0x0, 0x48(%rsp)
   63aea:      	movq	$0x3, 0x30(%rsp)
   63af3:      	xorl	%edi, %edi
   63af5:      	leaq	-0xf(%r12), %rsi
   63afa:      	callq	0x70870 <f.3>
   63aff:      	subq	$0x8, %rsp
   63b03:      	cmpb	$0x0, 0x11f46(%rip)     # 0x75a50 <g.4>
   63b0a:      	je	0x7085f <f.2+0x180af>
   63b10:      	movq	%rax, 0x18(%rsp)
   63b15:      	cmpq	$0x0, 0x11f2b(%rip)     # 0x75a48 <g.3>
   63b1d:      	je	0x7085f <f.2+0x180af>
   63b23:      	leaq	-0x10(%r12), %rsi
   63b28:      	movq	$0x0, 0x48(%rsp)
   63b31:      	movq	$0x3, 0x30(%rsp)
   63b3a:      	xorl	%edi, %edi
   63b3c:      	callq	0x70870 <f.3>
   63b41:      	subq	$0x8, %rsp
   63b45:      	cmpb	$0x0, 0x11f04(%rip)     # 0x75a50 <g.4>
   63b4c:      	je	0x7085f <f.2+0x180af>
   63b52:      	addq	0x18(%rsp), %rax
   63b57:      	addq	0x10(%rsp), %rax
   63b5c:      	jmp	0x63b76 <f.2+0xb3c6>
   63b5e:      	movl	$0x1, %eax
   63b63:      	cmpq	$0x0, 0x11edd(%rip)     # 0x75a48 <g.3>
   63b6b:      	je	0x7085f <f.2+0x180af>
   63b71:      	leaq	-0xe(%r12,%rax), %rax
   63b76:      	cmpq	$0x0, 0x11eca(%rip)     # 0x75a48 <g.3>
   63b7e:      	je	0x7085f <f.2+0x180af>
   63b84:      	cmpq	$0xe, %r12
   63b88:      	ja	0x63b94 <f.2+0xb3e4>
   63b8a:      	leaq	-0xd(%r12,%rax), %rdx
   63b8f:      	jmp	0x63cde <f.2+0xb52e>
   63b94:      	cmpq	$0xf, %r12
   63b98:      	jne	0x63bb2 <f.2+0xb402>
   63b9a:      	movl	$0x1, %ecx
   63b9f:      	cmpq	$0x0, 0x11ea1(%rip)     # 0x75a48 <g.3>
   63ba7:      	jne	0x63c49 <f.2+0xb499>
   63bad:      	jmp	0x7085f <f.2+0x180af>
   63bb2:      	movq	%rax, 0x10(%rsp)
   63bb7:      	leaq	-0xf(%r12), %rsi
   63bbc:      	movq	$0x0, 0x48(%rsp)
   63bc5:      	movq	$0x3, 0x30(%rsp)
   63bce:      	xorl	%edi, %edi
   63bd0:      	callq	0x70870 <f.3>
   63bd5:      	subq	$0x8, %rsp
   63bd9:      	cmpb	$0x0, 0x11e70(%rip)     # 0x75a50 <g.4>
   63be0:      	je	0x7085f <f.2+0x180af>
   63be6:      	movq	%rax, 0x18(%rsp)
   63beb:      	cmpq	$0x0, 0x11e55(%rip)     # 0x75a48 <g.3>
   63bf3:      	je	0x7085f <f.2+0x180af>
   63bf9:      	leaq	-0x10(%r12), %rsi
   63bfe:      	movq	$0x0, 0x48(%rsp)
   63c07:      	movq	$0x3, 0x30(%rsp)
   63c10:      	xorl	%edi, %edi
   63c12:      	callq	0x70870 <f.3>
   63c17:      	subq	$0x8, %rsp
   63c1b:      	cmpb	$0x0, 0x11e2e(%rip)     # 0x75a50 <g.4>
   63c22:      	je	0x7085f <f.2+0x180af>
   63c28:      	movq	%rax, %rcx
   63c2b:      	cmpq	$0x0, 0x11e15(%rip)     # 0x75a48 <g.3>
   63c33:      	movq	0x10(%rsp), %rax
   63c38:      	je	0x7085f <f.2+0x180af>
   63c3e:      	addq	0x18(%rsp), %rcx
   63c43:      	cmpq	$0x10, %r12
   63c47:      	ja	0x63c50 <f.2+0xb4a0>
   63c49:      	leaq	-0xf(%r12), %rdx
   63c4e:      	jmp	0x63ccb <f.2+0xb51b>
   63c50:      	movq	%rcx, 0x18(%rsp)
   63c55:      	movq	$0x0, 0x48(%rsp)
   63c5e:      	movq	$0x3, 0x30(%rsp)
   63c67:      	xorl	%edi, %edi
   63c69:      	leaq	-0x10(%r12), %rsi
   63c6e:      	callq	0x70870 <f.3>
   63c73:      	subq	$0x8, %rsp
   63c77:      	cmpb	$0x0, 0x11dd2(%rip)     # 0x75a50 <g.4>
   63c7e:      	je	0x7085f <f.2+0x180af>
   63c84:      	movq	%rax, 0x50(%rsp)
   63c89:      	cmpq	$0x0, 0x11db7(%rip)     # 0x75a48 <g.3>
   63c91:      	je	0x7085f <f.2+0x180af>
   63c97:      	leaq	-0x11(%r12), %rsi
   63c9c:      	movq	$0x0, 0x48(%rsp)
   63ca5:      	movq	$0x3, 0x30(%rsp)
   63cae:      	xorl	%edi, %edi
   63cb0:      	callq	0x70870 <f.3>
   63cb5:      	subq	$0x8, %rsp
   63cb9:      	movq	%rax, %rdx
   63cbc:      	addq	0x50(%rsp), %rdx
   63cc1:      	movq	0x10(%rsp), %rax
   63cc6:      	movq	0x18(%rsp), %rcx
   63ccb:      	cmpb	$0x0, 0x11d7e(%rip)     # 0x75a50 <g.4>
   63cd2:      	je	0x7085f <f.2+0x180af>
   63cd8:      	addq	%rcx, %rdx
   63cdb:      	addq	%rax, %rdx
   63cde:      	cmpq	$0x0, 0x11d62(%rip)     # 0x75a48 <g.3>
   63ce6:      	je	0x7085f <f.2+0x180af>
   63cec:      	cmpq	$0xe, %r12
   63cf0:      	je	0x63d02 <f.2+0xb552>
   63cf2:      	cmpq	$0xd, %r12
   63cf6:      	jne	0x63d1a <f.2+0xb56a>
   63cf8:      	leaq	-0xc(%r12), %rcx
   63cfd:      	jmp	0x63fc8 <f.2+0xb818>
   63d02:      	movl	$0x1, %ecx
   63d07:      	cmpq	$0x0, 0x11d39(%rip)     # 0x75a48 <g.3>
   63d0f:      	jne	0x63e75 <f.2+0xb6c5>
   63d15:      	jmp	0x7085f <f.2+0x180af>
   63d1a:      	cmpq	$0x10, %r12
   63d1e:      	jb	0x63e39 <f.2+0xb689>
   63d24:      	movq	%rdx, 0x18(%rsp)
   63d29:      	leaq	-0xf(%r12), %rsi
   63d2e:      	movq	$0x0, 0x48(%rsp)
   63d37:      	movq	$0x3, 0x30(%rsp)
   63d40:      	xorl	%edi, %edi
   63d42:      	callq	0x70870 <f.3>
   63d47:      	subq	$0x8, %rsp
   63d4b:      	cmpb	$0x0, 0x11cfe(%rip)     # 0x75a50 <g.4>
   63d52:      	je	0x7085f <f.2+0x180af>
   63d58:      	movq	%rax, 0x10(%rsp)
   63d5d:      	cmpq	$0x0, 0x11ce3(%rip)     # 0x75a48 <g.3>
   63d65:      	je	0x7085f <f.2+0x180af>
   63d6b:      	leaq	-0x10(%r12), %rsi
   63d70:      	movq	$0x0, 0x48(%rsp)
   63d79:      	movq	$0x3, 0x30(%rsp)
   63d82:      	xorl	%edi, %edi
   63d84:      	callq	0x70870 <f.3>
   63d89:      	subq	$0x8, %rsp
   63d8d:      	cmpb	$0x0, 0x11cbc(%rip)     # 0x75a50 <g.4>
   63d94:      	je	0x7085f <f.2+0x180af>
   63d9a:      	cmpq	$0x0, 0x11ca6(%rip)     # 0x75a48 <g.3>
   63da2:      	movq	0x18(%rsp), %rdx
   63da7:      	je	0x7085f <f.2+0x180af>
   63dad:      	addq	0x10(%rsp), %rax
   63db2:      	cmpq	$0x10, %r12
   63db6:      	je	0x63e4c <f.2+0xb69c>
   63dbc:      	movq	%rax, 0x10(%rsp)
   63dc1:      	movq	$0x0, 0x48(%rsp)
   63dca:      	movq	$0x3, 0x30(%rsp)
   63dd3:      	xorl	%edi, %edi
   63dd5:      	leaq	-0x10(%r12), %rsi
   63dda:      	callq	0x70870 <f.3>
   63ddf:      	subq	$0x8, %rsp
   63de3:      	cmpb	$0x0, 0x11c66(%rip)     # 0x75a50 <g.4>
   63dea:      	je	0x7085f <f.2+0x180af>
   63df0:      	movq	%rax, 0x50(%rsp)
   63df5:      	cmpq	$0x0, 0x11c4b(%rip)     # 0x75a48 <g.3>
   63dfd:      	je	0x7085f <f.2+0x180af>
   63e03:      	leaq	-0x11(%r12), %rsi
   63e08:      	movq	$0x0, 0x48(%rsp)
   63e11:      	movq	$0x3, 0x30(%rsp)
   63e1a:      	xorl	%edi, %edi
   63e1c:      	callq	0x70870 <f.3>
   63e21:      	subq	$0x8, %rsp
   63e25:      	movq	%rax, %rcx
   63e28:      	addq	0x50(%rsp), %rcx
   63e2d:      	movq	0x18(%rsp), %rdx
   63e32:      	movq	0x10(%rsp), %rax
   63e37:      	jmp	0x63e51 <f.2+0xb6a1>
   63e39:      	movl	$0x1, %eax
   63e3e:      	cmpq	$0x0, 0x11c02(%rip)     # 0x75a48 <g.3>
   63e46:      	je	0x7085f <f.2+0x180af>
   63e4c:      	leaq	-0xf(%r12), %rcx
   63e51:      	cmpb	$0x0, 0x11bf8(%rip)     # 0x75a50 <g.4>
   63e58:      	je	0x7085f <f.2+0x180af>
   63e5e:      	cmpq	$0x0, 0x11be2(%rip)     # 0x75a48 <g.3>
   63e66:      	je	0x7085f <f.2+0x180af>
   63e6c:      	addq	%rax, %rcx
   63e6f:      	cmpq	$0xf, %r12
   63e73:      	ja	0x63e7f <f.2+0xb6cf>
   63e75:      	leaq	-0xe(%r12), %rsi
   63e7a:      	jmp	0x63fc5 <f.2+0xb815>
   63e7f:      	cmpq	$0x10, %r12
   63e83:      	jne	0x63e9d <f.2+0xb6ed>
   63e85:      	movl	$0x1, %esi
   63e8a:      	cmpq	$0x0, 0x11bb6(%rip)     # 0x75a48 <g.3>
   63e92:      	jne	0x63f3e <f.2+0xb78e>
   63e98:      	jmp	0x7085f <f.2+0x180af>
   63e9d:      	movq	%rdx, 0x18(%rsp)
   63ea2:      	movq	%rcx, 0x10(%rsp)
   63ea7:      	leaq	-0x10(%r12), %rsi
   63eac:      	movq	$0x0, 0x48(%rsp)
   63eb5:      	movq	$0x3, 0x30(%rsp)
   63ebe:      	xorl	%edi, %edi
   63ec0:      	callq	0x70870 <f.3>
   63ec5:      	subq	$0x8, %rsp
   63ec9:      	cmpb	$0x0, 0x11b80(%rip)     # 0x75a50 <g.4>
   63ed0:      	je	0x7085f <f.2+0x180af>
   63ed6:      	movq	%rax, 0x50(%rsp)
   63edb:      	cmpq	$0x0, 0x11b65(%rip)     # 0x75a48 <g.3>
   63ee3:      	je	0x7085f <f.2+0x180af>
   63ee9:      	leaq	-0x11(%r12), %rsi
   63eee:      	movq	$0x0, 0x48(%rsp)
   63ef7:      	movq	$0x3, 0x30(%rsp)
   63f00:      	xorl	%edi, %edi
   63f02:      	callq	0x70870 <f.3>
   63f07:      	subq	$0x8, %rsp
   63f0b:      	cmpb	$0x0, 0x11b3e(%rip)     # 0x75a50 <g.4>
   63f12:      	je	0x7085f <f.2+0x180af>
   63f18:      	cmpq	$0x0, 0x11b28(%rip)     # 0x75a48 <g.3>
   63f20:      	movq	0x10(%rsp), %rcx
   63f25:      	movq	0x18(%rsp), %rdx
   63f2a:      	je	0x7085f <f.2+0x180af>
   63f30:      	movq	%rax, %rsi
   63f33:      	addq	0x50(%rsp), %rsi
   63f38:      	cmpq	$0x11, %r12
   63f3c:      	ja	0x63f45 <f.2+0xb795>
   63f3e:      	leaq	-0x10(%r12), %rax
   63f43:      	jmp	0x63fc2 <f.2+0xb812>
   63f45:      	movq	%rsi, 0x50(%rsp)
   63f4a:      	movq	$0x0, 0x48(%rsp)
   63f53:      	movq	$0x3, 0x30(%rsp)
   63f5c:      	xorl	%edi, %edi
   63f5e:      	leaq	-0x11(%r12), %rsi
   63f63:      	callq	0x70870 <f.3>
   63f68:      	subq	$0x8, %rsp
   63f6c:      	cmpb	$0x0, 0x11add(%rip)     # 0x75a50 <g.4>
   63f73:      	je	0x7085f <f.2+0x180af>
   63f79:      	movq	%rax, 0x58(%rsp)
   63f7e:      	cmpq	$0x0, 0x11ac2(%rip)     # 0x75a48 <g.3>
   63f86:      	je	0x7085f <f.2+0x180af>
   63f8c:      	leaq	-0x12(%r12), %rsi
   63f91:      	movq	$0x0, 0x48(%rsp)
   63f9a:      	movq	$0x3, 0x30(%rsp)
   63fa3:      	xorl	%edi, %edi
   63fa5:      	callq	0x70870 <f.3>
   63faa:      	subq	$0x8, %rsp
   63fae:      	addq	0x58(%rsp), %rax
   63fb3:      	movq	0x10(%rsp), %rcx
   63fb8:      	movq	0x18(%rsp), %rdx
   63fbd:      	movq	0x50(%rsp), %rsi
   63fc2:      	addq	%rax, %rsi
   63fc5:      	addq	%rsi, %rcx
   63fc8:      	cmpb	$0x0, 0x11a81(%rip)     # 0x75a50 <g.4>
   63fcf:      	je	0x7085f <f.2+0x180af>
   63fd5:      	cmpq	$0x0, 0x11a6b(%rip)     # 0x75a48 <g.3>
   63fdd:      	je	0x7085f <f.2+0x180af>
   63fe3:      	addq	%rdx, %rcx
   63fe6:      	cmpq	$0xc, %r12
   63fea:      	ja	0x63ff6 <f.2+0xb846>
   63fec:      	leaq	-0xb(%r12), %rdx
   63ff1:      	jmp	0x645f4 <f.2+0xbe44>
   63ff6:      	cmpq	$0xd, %r12
   63ffa:      	jne	0x64014 <f.2+0xb864>
   63ffc:      	movl	$0x1, %edx
   64001:      	cmpq	$0x0, 0x11a3f(%rip)     # 0x75a48 <g.3>
   64009:      	jne	0x642fa <f.2+0xbb4a>
   6400f:      	jmp	0x7085f <f.2+0x180af>
   64014:      	cmpq	$0xf, %r12
   64018:      	jb	0x64034 <f.2+0xb884>
   6401a:      	jne	0x6404c <f.2+0xb89c>
   6401c:      	movl	$0x1, %eax
   64021:      	cmpq	$0x0, 0x11a1f(%rip)     # 0x75a48 <g.3>
   64029:      	jne	0x640e0 <f.2+0xb930>
   6402f:      	jmp	0x7085f <f.2+0x180af>
   64034:      	movl	$0x1, %esi
   64039:      	cmpq	$0x0, 0x11a07(%rip)     # 0x75a48 <g.3>
   64041:      	jne	0x6418c <f.2+0xb9dc>
   64047:      	jmp	0x7085f <f.2+0x180af>
   6404c:      	movq	%rcx, 0x10(%rsp)
   64051:      	leaq	-0xf(%r12), %rsi
   64056:      	movq	$0x0, 0x48(%rsp)
   6405f:      	movq	$0x3, 0x30(%rsp)
   64068:      	xorl	%edi, %edi
   6406a:      	callq	0x70870 <f.3>
   6406f:      	subq	$0x8, %rsp
   64073:      	cmpb	$0x0, 0x119d6(%rip)     # 0x75a50 <g.4>
   6407a:      	je	0x7085f <f.2+0x180af>
   64080:      	movq	%rax, 0x18(%rsp)
   64085:      	cmpq	$0x0, 0x119bb(%rip)     # 0x75a48 <g.3>
   6408d:      	je	0x7085f <f.2+0x180af>
   64093:      	leaq	-0x10(%r12), %rsi
   64098:      	movq	$0x0, 0x48(%rsp)
   640a1:      	movq	$0x3, 0x30(%rsp)
   640aa:      	xorl	%edi, %edi
   640ac:      	callq	0x70870 <f.3>
   640b1:      	subq	$0x8, %rsp
   640b5:      	cmpb	$0x0, 0x11994(%rip)     # 0x75a50 <g.4>
   640bc:      	je	0x7085f <f.2+0x180af>
   640c2:      	cmpq	$0x0, 0x1197e(%rip)     # 0x75a48 <g.3>
   640ca:      	movq	0x10(%rsp), %rcx
   640cf:      	je	0x7085f <f.2+0x180af>
   640d5:      	addq	0x18(%rsp), %rax
   640da:      	cmpq	$0x10, %r12
   640de:      	ja	0x640e7 <f.2+0xb937>
   640e0:      	leaq	-0xf(%r12), %rsi
   640e5:      	jmp	0x64162 <f.2+0xb9b2>
   640e7:      	movq	%rax, 0x18(%rsp)
   640ec:      	movq	$0x0, 0x48(%rsp)
   640f5:      	movq	$0x3, 0x30(%rsp)
   640fe:      	xorl	%edi, %edi
   64100:      	leaq	-0x10(%r12), %rsi
   64105:      	callq	0x70870 <f.3>
   6410a:      	subq	$0x8, %rsp
   6410e:      	cmpb	$0x0, 0x1193b(%rip)     # 0x75a50 <g.4>
   64115:      	je	0x7085f <f.2+0x180af>
   6411b:      	movq	%rax, 0x50(%rsp)
   64120:      	cmpq	$0x0, 0x11920(%rip)     # 0x75a48 <g.3>
   64128:      	je	0x7085f <f.2+0x180af>
   6412e:      	leaq	-0x11(%r12), %rsi
   64133:      	movq	$0x0, 0x48(%rsp)
   6413c:      	movq	$0x3, 0x30(%rsp)
   64145:      	xorl	%edi, %edi
   64147:      	callq	0x70870 <f.3>
   6414c:      	subq	$0x8, %rsp
   64150:      	movq	%rax, %rsi
   64153:      	addq	0x50(%rsp), %rsi
   64158:      	movq	0x10(%rsp), %rcx
   6415d:      	movq	0x18(%rsp), %rax
   64162:      	cmpb	$0x0, 0x118e7(%rip)     # 0x75a50 <g.4>
   64169:      	je	0x7085f <f.2+0x180af>
   6416f:      	cmpq	$0x0, 0x118d1(%rip)     # 0x75a48 <g.3>
   64177:      	je	0x7085f <f.2+0x180af>
   6417d:      	addq	%rax, %rsi
   64180:      	cmpq	$0x10, %r12
   64184:      	je	0x64196 <f.2+0xb9e6>
   64186:      	cmpq	$0xf, %r12
   6418a:      	jne	0x641ae <f.2+0xb9fe>
   6418c:      	leaq	-0xe(%r12), %rdx
   64191:      	jmp	0x642d6 <f.2+0xbb26>
   64196:      	movl	$0x1, %edx
   6419b:      	cmpq	$0x0, 0x118a5(%rip)     # 0x75a48 <g.3>
   641a3:      	jne	0x6424f <f.2+0xba9f>
   641a9:      	jmp	0x7085f <f.2+0x180af>
   641ae:      	movq	%rsi, 0x50(%rsp)
   641b3:      	movq	%rcx, 0x10(%rsp)
   641b8:      	leaq	-0x10(%r12), %rsi
   641bd:      	movq	$0x0, 0x48(%rsp)
   641c6:      	movq	$0x3, 0x30(%rsp)
   641cf:      	xorl	%edi, %edi
   641d1:      	callq	0x70870 <f.3>
   641d6:      	subq	$0x8, %rsp
   641da:      	cmpb	$0x0, 0x1186f(%rip)     # 0x75a50 <g.4>
   641e1:      	je	0x7085f <f.2+0x180af>
   641e7:      	movq	%rax, 0x18(%rsp)
   641ec:      	cmpq	$0x0, 0x11854(%rip)     # 0x75a48 <g.3>
   641f4:      	je	0x7085f <f.2+0x180af>
   641fa:      	leaq	-0x11(%r12), %rsi
   641ff:      	movq	$0x0, 0x48(%rsp)
   64208:      	movq	$0x3, 0x30(%rsp)
   64211:      	xorl	%edi, %edi
   64213:      	callq	0x70870 <f.3>
   64218:      	subq	$0x8, %rsp
   6421c:      	cmpb	$0x0, 0x1182d(%rip)     # 0x75a50 <g.4>
   64223:      	je	0x7085f <f.2+0x180af>
   64229:      	cmpq	$0x0, 0x11817(%rip)     # 0x75a48 <g.3>
   64231:      	movq	0x10(%rsp), %rcx
   64236:      	movq	0x50(%rsp), %rsi
   6423b:      	je	0x7085f <f.2+0x180af>
   64241:      	movq	%rax, %rdx
   64244:      	addq	0x18(%rsp), %rdx
   64249:      	cmpq	$0x11, %r12
   6424d:      	ja	0x64256 <f.2+0xbaa6>
   6424f:      	leaq	-0x10(%r12), %rax
   64254:      	jmp	0x642d3 <f.2+0xbb23>
   64256:      	movq	%rdx, 0x18(%rsp)
   6425b:      	movq	$0x0, 0x48(%rsp)
   64264:      	movq	$0x3, 0x30(%rsp)
   6426d:      	xorl	%edi, %edi
   6426f:      	leaq	-0x11(%r12), %rsi
   64274:      	callq	0x70870 <f.3>
   64279:      	subq	$0x8, %rsp
   6427d:      	cmpb	$0x0, 0x117cc(%rip)     # 0x75a50 <g.4>
   64284:      	je	0x7085f <f.2+0x180af>
   6428a:      	movq	%rax, 0x58(%rsp)
   6428f:      	cmpq	$0x0, 0x117b1(%rip)     # 0x75a48 <g.3>
   64297:      	je	0x7085f <f.2+0x180af>
   6429d:      	leaq	-0x12(%r12), %rsi
   642a2:      	movq	$0x0, 0x48(%rsp)
   642ab:      	movq	$0x3, 0x30(%rsp)
   642b4:      	xorl	%edi, %edi
   642b6:      	callq	0x70870 <f.3>
   642bb:      	subq	$0x8, %rsp
   642bf:      	addq	0x58(%rsp), %rax
   642c4:      	movq	0x10(%rsp), %rcx
   642c9:      	movq	0x18(%rsp), %rdx
   642ce:      	movq	0x50(%rsp), %rsi
   642d3:      	addq	%rax, %rdx
   642d6:      	cmpb	$0x0, 0x11773(%rip)     # 0x75a50 <g.4>
   642dd:      	je	0x7085f <f.2+0x180af>
   642e3:      	cmpq	$0x0, 0x1175d(%rip)     # 0x75a48 <g.3>
   642eb:      	je	0x7085f <f.2+0x180af>
   642f1:      	addq	%rsi, %rdx
   642f4:      	cmpq	$0xe, %r12
   642f8:      	ja	0x64304 <f.2+0xbb54>
   642fa:      	leaq	-0xd(%r12), %rsi
   642ff:      	jmp	0x645f1 <f.2+0xbe41>
   64304:      	cmpq	$0xf, %r12
   64308:      	jne	0x64322 <f.2+0xbb72>
   6430a:      	movl	$0x1, %esi
   6430f:      	cmpq	$0x0, 0x11731(%rip)     # 0x75a48 <g.3>
   64317:      	jne	0x6448c <f.2+0xbcdc>
   6431d:      	jmp	0x7085f <f.2+0x180af>
   64322:      	cmpq	$0x11, %r12
   64326:      	jb	0x64450 <f.2+0xbca0>
   6432c:      	movq	%rdx, 0x18(%rsp)
   64331:      	movq	%rcx, 0x10(%rsp)
   64336:      	leaq	-0x10(%r12), %rsi
   6433b:      	movq	$0x0, 0x48(%rsp)
   64344:      	movq	$0x3, 0x30(%rsp)
   6434d:      	xorl	%edi, %edi
   6434f:      	callq	0x70870 <f.3>
   64354:      	subq	$0x8, %rsp
   64358:      	cmpb	$0x0, 0x116f1(%rip)     # 0x75a50 <g.4>
   6435f:      	je	0x7085f <f.2+0x180af>
   64365:      	movq	%rax, 0x50(%rsp)
   6436a:      	cmpq	$0x0, 0x116d6(%rip)     # 0x75a48 <g.3>
   64372:      	je	0x7085f <f.2+0x180af>
   64378:      	leaq	-0x11(%r12), %rsi
   6437d:      	movq	$0x0, 0x48(%rsp)
   64386:      	movq	$0x3, 0x30(%rsp)
   6438f:      	xorl	%edi, %edi
   64391:      	callq	0x70870 <f.3>
   64396:      	subq	$0x8, %rsp
   6439a:      	cmpb	$0x0, 0x116af(%rip)     # 0x75a50 <g.4>
   643a1:      	je	0x7085f <f.2+0x180af>
   643a7:      	cmpq	$0x0, 0x11699(%rip)     # 0x75a48 <g.3>
   643af:      	movq	0x10(%rsp), %rcx
   643b4:      	movq	0x18(%rsp), %rdx
   643b9:      	je	0x7085f <f.2+0x180af>
   643bf:      	addq	0x50(%rsp), %rax
   643c4:      	cmpq	$0x11, %r12
   643c8:      	je	0x64463 <f.2+0xbcb3>
   643ce:      	movq	%rax, 0x50(%rsp)
   643d3:      	movq	$0x0, 0x48(%rsp)
   643dc:      	movq	$0x3, 0x30(%rsp)
   643e5:      	xorl	%edi, %edi
   643e7:      	leaq	-0x11(%r12), %rsi
   643ec:      	callq	0x70870 <f.3>
   643f1:      	subq	$0x8, %rsp
   643f5:      	cmpb	$0x0, 0x11654(%rip)     # 0x75a50 <g.4>
   643fc:      	je	0x7085f <f.2+0x180af>
   64402:      	movq	%rax, 0x58(%rsp)
   64407:      	cmpq	$0x0, 0x11639(%rip)     # 0x75a48 <g.3>
   6440f:      	je	0x7085f <f.2+0x180af>
   64415:      	leaq	-0x12(%r12), %rsi
   6441a:      	movq	$0x0, 0x48(%rsp)
   64423:      	movq	$0x3, 0x30(%rsp)
   6442c:      	xorl	%edi, %edi
   6442e:      	callq	0x70870 <f.3>
   64433:      	subq	$0x8, %rsp
   64437:      	movq	%rax, %rsi
   6443a:      	addq	0x58(%rsp), %rsi
   6443f:      	movq	0x10(%rsp), %rcx
   64444:      	movq	0x18(%rsp), %rdx
   64449:      	movq	0x50(%rsp), %rax
   6444e:      	jmp	0x64468 <f.2+0xbcb8>
   64450:      	movl	$0x1, %eax
   64455:      	cmpq	$0x0, 0x115eb(%rip)     # 0x75a48 <g.3>
   6445d:      	je	0x7085f <f.2+0x180af>
   64463:      	leaq	-0x10(%r12), %rsi
   64468:      	cmpb	$0x0, 0x115e1(%rip)     # 0x75a50 <g.4>
   6446f:      	je	0x7085f <f.2+0x180af>
   64475:      	cmpq	$0x0, 0x115cb(%rip)     # 0x75a48 <g.3>
   6447d:      	je	0x7085f <f.2+0x180af>
   64483:      	addq	%rax, %rsi
   64486:      	cmpq	$0x10, %r12
   6448a:      	ja	0x64496 <f.2+0xbce6>
   6448c:      	leaq	-0xf(%r12), %rdi
   64491:      	jmp	0x645ee <f.2+0xbe3e>
   64496:      	cmpq	$0x11, %r12
   6449a:      	jne	0x644b4 <f.2+0xbd04>
   6449c:      	movl	$0x1, %edi
   644a1:      	cmpq	$0x0, 0x1159f(%rip)     # 0x75a48 <g.3>
   644a9:      	jne	0x6455f <f.2+0xbdaf>
   644af:      	jmp	0x7085f <f.2+0x180af>
   644b4:      	movq	%rsi, 0x50(%rsp)
   644b9:      	movq	%rdx, 0x18(%rsp)
   644be:      	movq	%rcx, 0x10(%rsp)
   644c3:      	leaq	-0x11(%r12), %rsi
   644c8:      	movq	$0x0, 0x48(%rsp)
   644d1:      	movq	$0x3, 0x30(%rsp)
   644da:      	xorl	%edi, %edi
   644dc:      	callq	0x70870 <f.3>
   644e1:      	subq	$0x8, %rsp
   644e5:      	cmpb	$0x0, 0x11564(%rip)     # 0x75a50 <g.4>
   644ec:      	je	0x7085f <f.2+0x180af>
   644f2:      	movq	%rax, 0x58(%rsp)
   644f7:      	cmpq	$0x0, 0x11549(%rip)     # 0x75a48 <g.3>
   644ff:      	je	0x7085f <f.2+0x180af>
   64505:      	leaq	-0x12(%r12), %rsi
   6450a:      	movq	$0x0, 0x48(%rsp)
   64513:      	movq	$0x3, 0x30(%rsp)
   6451c:      	xorl	%edi, %edi
   6451e:      	callq	0x70870 <f.3>
   64523:      	subq	$0x8, %rsp
   64527:      	cmpb	$0x0, 0x11522(%rip)     # 0x75a50 <g.4>
   6452e:      	je	0x7085f <f.2+0x180af>
   64534:      	cmpq	$0x0, 0x1150c(%rip)     # 0x75a48 <g.3>
   6453c:      	movq	0x10(%rsp), %rcx
   64541:      	movq	0x18(%rsp), %rdx
   64546:      	movq	0x50(%rsp), %rsi
   6454b:      	je	0x7085f <f.2+0x180af>
   64551:      	movq	%rax, %rdi
   64554:      	addq	0x58(%rsp), %rdi
   64559:      	cmpq	$0x12, %r12
   6455d:      	ja	0x64569 <f.2+0xbdb9>
   6455f:      	leaq	-0x11(%r12), %rax
   64564:      	jmp	0x645eb <f.2+0xbe3b>
   64569:      	movq	%rdi, 0x58(%rsp)
   6456e:      	movq	$0x0, 0x48(%rsp)
   64577:      	movq	$0x3, 0x30(%rsp)
   64580:      	xorl	%edi, %edi
   64582:      	leaq	-0x12(%r12), %rsi
   64587:      	callq	0x70870 <f.3>
   6458c:      	subq	$0x8, %rsp
   64590:      	movq	%rax, 0x60(%rsp)
   64595:      	cmpb	$0x0, 0x114b4(%rip)     # 0x75a50 <g.4>
   6459c:      	je	0x7085f <f.2+0x180af>
   645a2:      	cmpq	$0x0, 0x1149e(%rip)     # 0x75a48 <g.3>
   645aa:      	je	0x7085f <f.2+0x180af>
   645b0:      	leaq	-0x13(%r12), %rsi
   645b5:      	movq	$0x0, 0x48(%rsp)
   645be:      	movq	$0x3, 0x30(%rsp)
   645c7:      	xorl	%edi, %edi
   645c9:      	callq	0x70870 <f.3>
   645ce:      	subq	$0x8, %rsp
   645d2:      	addq	0x60(%rsp), %rax
   645d7:      	movq	0x10(%rsp), %rcx
   645dc:      	movq	0x18(%rsp), %rdx
   645e1:      	movq	0x50(%rsp), %rsi
   645e6:      	movq	0x58(%rsp), %rdi
   645eb:      	addq	%rax, %rdi
   645ee:      	addq	%rdi, %rsi
   645f1:      	addq	%rsi, %rdx
   645f4:      	addq	%rdx, %rcx
   645f7:      	addq	%rcx, %r15
   645fa:      	addq	%r15, %r14
   645fd:      	leaq	0x68(%rsp), %r15
   64602:      	addq	%r14, %r13
   64605:      	cmpb	$0x0, 0x11444(%rip)     # 0x75a50 <g.4>
   6460c:      	je	0x7085f <f.2+0x180af>
   64612:      	nopw	%cs:(%rax,%rax)
   6461c:      	nopl	(%rax)
   64620:      	cmpq	$0x0, 0x11420(%rip)     # 0x75a48 <g.3>
   64628:      	je	0x7085f <f.2+0x180af>
   6462e:      	addq	%rbp, %r13
   64631:      	cmpq	$0x3, %r12
   64635:      	ja	0x64640 <f.2+0xbe90>
   64637:      	addq	$-0x2, %r12
   6463b:      	jmp	0x707ea <f.2+0x1803a>
   64640:      	cmpq	$0x4, %r12
   64644:      	jne	0x6465e <f.2+0xbeae>
   64646:      	movl	$0x1, %ebp
   6464b:      	cmpq	$0x0, 0x113f5(%rip)     # 0x75a48 <g.3>
   64653:      	jne	0x68d72 <f.2+0x105c2>
   64659:      	jmp	0x7085f <f.2+0x180af>
   6465e:      	cmpq	$0x6, %r12
   64662:      	jb	0x6467f <f.2+0xbecf>
   64664:      	jne	0x64698 <f.2+0xbee8>
   64666:      	movl	$0x1, %r15d
   6466c:      	cmpq	$0x0, 0x113d4(%rip)     # 0x75a48 <g.3>
   64674:      	jne	0x65daa <f.2+0xd5fa>
   6467a:      	jmp	0x7085f <f.2+0x180af>
   6467f:      	movl	$0x1, %r14d
   64685:      	cmpq	$0x0, 0x113bb(%rip)     # 0x75a48 <g.3>
   6468d:      	jne	0x67563 <f.2+0xedb3>
   64693:      	jmp	0x7085f <f.2+0x180af>
   64698:      	cmpq	$0x8, %r12
   6469c:      	jb	0x646b9 <f.2+0xbf09>
   6469e:      	jne	0x646d2 <f.2+0xbf22>
   646a0:      	movl	$0x1, %r15d
   646a6:      	cmpq	$0x0, 0x1139a(%rip)     # 0x75a48 <g.3>
   646ae:      	jne	0x64c5e <f.2+0xc4ae>
   646b4:      	jmp	0x7085f <f.2+0x180af>
   646b9:      	movl	$0x1, %r14d
   646bf:      	cmpq	$0x0, 0x11381(%rip)     # 0x75a48 <g.3>
   646c7:      	jne	0x6520f <f.2+0xca5f>
   646cd:      	jmp	0x7085f <f.2+0x180af>
   646d2:      	cmpq	$0xa, %r12
   646d6:      	jb	0x646f3 <f.2+0xbf43>
   646d8:      	jne	0x6470c <f.2+0xbf5c>
   646da:      	movl	$0x1, %r15d
   646e0:      	cmpq	$0x0, 0x11360(%rip)     # 0x75a48 <g.3>
   646e8:      	jne	0x6484b <f.2+0xc09b>
   646ee:      	jmp	0x7085f <f.2+0x180af>
   646f3:      	movl	$0x1, %r14d
   646f9:      	cmpq	$0x0, 0x11347(%rip)     # 0x75a48 <g.3>
   64701:      	jne	0x6499c <f.2+0xc1ec>
   64707:      	jmp	0x7085f <f.2+0x180af>
   6470c:      	cmpq	$0xc, %r12
   64710:      	jb	0x6481e <f.2+0xc06e>
   64716:      	leaq	-0xb(%r12), %rsi
   6471b:      	movq	$0x0, 0x48(%rsp)
   64724:      	movq	$0x3, 0x30(%rsp)
   6472d:      	xorl	%edi, %edi
   6472f:      	callq	0x70870 <f.3>
   64734:      	subq	$0x8, %rsp
   64738:      	cmpb	$0x0, 0x11311(%rip)     # 0x75a50 <g.4>
   6473f:      	je	0x7085f <f.2+0x180af>
   64745:      	cmpq	$0x0, 0x112fb(%rip)     # 0x75a48 <g.3>
   6474d:      	je	0x7085f <f.2+0x180af>
   64753:      	movq	%rax, %r15
   64756:      	leaq	-0xc(%r12), %rbp
   6475b:      	movq	$0x0, 0x48(%rsp)
   64764:      	movq	$0x3, 0x30(%rsp)
   6476d:      	xorl	%edi, %edi
   6476f:      	movq	%rbp, %rsi
   64772:      	callq	0x70870 <f.3>
   64777:      	subq	$0x8, %rsp
   6477b:      	cmpb	$0x0, 0x112ce(%rip)     # 0x75a50 <g.4>
   64782:      	je	0x7085f <f.2+0x180af>
   64788:      	cmpq	$0x0, 0x112b8(%rip)     # 0x75a48 <g.3>
   64790:      	je	0x7085f <f.2+0x180af>
   64796:      	movq	%rax, %r14
   64799:      	addq	%r15, %r14
   6479c:      	cmpq	$0xc, %r12
   647a0:      	je	0x64832 <f.2+0xc082>
   647a6:      	movq	$0x0, 0x48(%rsp)
   647af:      	movq	$0x3, 0x30(%rsp)
   647b8:      	xorl	%edi, %edi
   647ba:      	movq	%rbp, %rsi
   647bd:      	callq	0x70870 <f.3>
   647c2:      	subq	$0x8, %rsp
   647c6:      	cmpb	$0x0, 0x11283(%rip)     # 0x75a50 <g.4>
   647cd:      	je	0x7085f <f.2+0x180af>
   647d3:      	cmpq	$0x0, 0x1126d(%rip)     # 0x75a48 <g.3>
   647db:      	je	0x7085f <f.2+0x180af>
   647e1:      	movq	%rax, %rbp
   647e4:      	leaq	-0xd(%r12), %rsi
   647e9:      	movq	$0x0, 0x48(%rsp)
   647f2:      	movq	$0x3, 0x30(%rsp)
   647fb:      	xorl	%edi, %edi
   647fd:      	callq	0x70870 <f.3>
   64802:      	subq	$0x8, %rsp
   64806:      	cmpb	$0x0, 0x11243(%rip)     # 0x75a50 <g.4>
   6480d:      	je	0x7085f <f.2+0x180af>
   64813:      	movq	%rax, %r15
   64816:      	addq	%rbp, %r15
   64819:      	addq	%r14, %r15
   6481c:      	jmp	0x64837 <f.2+0xc087>
   6481e:      	movl	$0x1, %r14d
   64824:      	cmpq	$0x0, 0x1121c(%rip)     # 0x75a48 <g.3>
   6482c:      	je	0x7085f <f.2+0x180af>
   64832:      	leaq	-0xb(%r12,%r14), %r15
   64837:      	cmpq	$0x0, 0x11209(%rip)     # 0x75a48 <g.3>
   6483f:      	je	0x7085f <f.2+0x180af>
   64845:      	cmpq	$0xb, %r12
   64849:      	ja	0x64855 <f.2+0xc0a5>
   6484b:      	leaq	-0xa(%r12,%r15), %r14
   64850:      	jmp	0x64982 <f.2+0xc1d2>
   64855:      	cmpq	$0xc, %r12
   64859:      	jne	0x64873 <f.2+0xc0c3>
   6485b:      	movl	$0x1, %ebp
   64860:      	cmpq	$0x0, 0x111e0(%rip)     # 0x75a48 <g.3>
   64868:      	jne	0x648fc <f.2+0xc14c>
   6486e:      	jmp	0x7085f <f.2+0x180af>
   64873:      	leaq	-0xc(%r12), %rsi
   64878:      	movq	$0x0, 0x48(%rsp)
   64881:      	movq	$0x3, 0x30(%rsp)
   6488a:      	xorl	%edi, %edi
   6488c:      	callq	0x70870 <f.3>
   64891:      	subq	$0x8, %rsp
   64895:      	cmpb	$0x0, 0x111b4(%rip)     # 0x75a50 <g.4>
   6489c:      	je	0x7085f <f.2+0x180af>
   648a2:      	cmpq	$0x0, 0x1119e(%rip)     # 0x75a48 <g.3>
   648aa:      	je	0x7085f <f.2+0x180af>
   648b0:      	movq	%rax, %r14
   648b3:      	leaq	-0xd(%r12), %rsi
   648b8:      	movq	$0x0, 0x48(%rsp)
   648c1:      	movq	$0x3, 0x30(%rsp)
   648ca:      	xorl	%edi, %edi
   648cc:      	callq	0x70870 <f.3>
   648d1:      	subq	$0x8, %rsp
   648d5:      	cmpb	$0x0, 0x11174(%rip)     # 0x75a50 <g.4>
   648dc:      	je	0x7085f <f.2+0x180af>
   648e2:      	cmpq	$0x0, 0x1115e(%rip)     # 0x75a48 <g.3>
   648ea:      	je	0x7085f <f.2+0x180af>
   648f0:      	movq	%rax, %rbp
   648f3:      	addq	%r14, %rbp
   648f6:      	cmpq	$0xd, %r12
   648fa:      	ja	0x64903 <f.2+0xc153>
   648fc:      	leaq	-0xc(%r12), %r14
   64901:      	jmp	0x6496f <f.2+0xc1bf>
   64903:      	movq	$0x0, 0x48(%rsp)
   6490c:      	movq	$0x3, 0x30(%rsp)
   64915:      	xorl	%edi, %edi
   64917:      	leaq	-0xd(%r12), %rsi
   6491c:      	callq	0x70870 <f.3>
   64921:      	subq	$0x8, %rsp
   64925:      	cmpb	$0x0, 0x11124(%rip)     # 0x75a50 <g.4>
   6492c:      	je	0x7085f <f.2+0x180af>
   64932:      	movq	%rax, 0x10(%rsp)
   64937:      	cmpq	$0x0, 0x11109(%rip)     # 0x75a48 <g.3>
   6493f:      	je	0x7085f <f.2+0x180af>
   64945:      	leaq	-0xe(%r12), %rsi
   6494a:      	movq	$0x0, 0x48(%rsp)
   64953:      	movq	$0x3, 0x30(%rsp)
   6495c:      	xorl	%edi, %edi
   6495e:      	callq	0x70870 <f.3>
   64963:      	subq	$0x8, %rsp
   64967:      	movq	%rax, %r14
   6496a:      	addq	0x10(%rsp), %r14
   6496f:      	cmpb	$0x0, 0x110da(%rip)     # 0x75a50 <g.4>
   64976:      	je	0x7085f <f.2+0x180af>
   6497c:      	addq	%rbp, %r14
   6497f:      	addq	%r15, %r14
   64982:      	cmpq	$0x0, 0x110be(%rip)     # 0x75a48 <g.3>
   6498a:      	je	0x7085f <f.2+0x180af>
   64990:      	cmpq	$0xb, %r12
   64994:      	je	0x649b4 <f.2+0xc204>
   64996:      	cmpq	$0xa, %r12
   6499a:      	jne	0x649cc <f.2+0xc21c>
   6499c:      	leaq	-0x9(%r12,%r14), %r15
   649a1:      	cmpq	$0x0, 0x1109f(%rip)     # 0x75a48 <g.3>
   649a9:      	jne	0x64c58 <f.2+0xc4a8>
   649af:      	jmp	0x7085f <f.2+0x180af>
   649b4:      	movl	$0x1, %ebp
   649b9:      	cmpq	$0x0, 0x11087(%rip)     # 0x75a48 <g.3>
   649c1:      	jne	0x64b0e <f.2+0xc35e>
   649c7:      	jmp	0x7085f <f.2+0x180af>
   649cc:      	cmpq	$0xd, %r12
   649d0:      	jb	0x64ae1 <f.2+0xc331>
   649d6:      	leaq	-0xc(%r12), %rsi
   649db:      	movq	$0x0, 0x48(%rsp)
   649e4:      	movq	$0x3, 0x30(%rsp)
   649ed:      	xorl	%edi, %edi
   649ef:      	callq	0x70870 <f.3>
   649f4:      	subq	$0x8, %rsp
   649f8:      	cmpb	$0x0, 0x11051(%rip)     # 0x75a50 <g.4>
   649ff:      	je	0x7085f <f.2+0x180af>
   64a05:      	cmpq	$0x0, 0x1103b(%rip)     # 0x75a48 <g.3>
   64a0d:      	je	0x7085f <f.2+0x180af>
   64a13:      	movq	%rax, %rbp
   64a16:      	leaq	-0xd(%r12), %rsi
   64a1b:      	movq	$0x0, 0x48(%rsp)
   64a24:      	movq	$0x3, 0x30(%rsp)
   64a2d:      	xorl	%edi, %edi
   64a2f:      	callq	0x70870 <f.3>
   64a34:      	subq	$0x8, %rsp
   64a38:      	cmpb	$0x0, 0x11011(%rip)     # 0x75a50 <g.4>
   64a3f:      	je	0x7085f <f.2+0x180af>
   64a45:      	cmpq	$0x0, 0x10ffb(%rip)     # 0x75a48 <g.3>
   64a4d:      	je	0x7085f <f.2+0x180af>
   64a53:      	movq	%rax, %r15
   64a56:      	addq	%rbp, %r15
   64a59:      	cmpq	$0xd, %r12
   64a5d:      	je	0x64af5 <f.2+0xc345>
   64a63:      	movq	$0x0, 0x48(%rsp)
   64a6c:      	movq	$0x3, 0x30(%rsp)
   64a75:      	xorl	%edi, %edi
   64a77:      	leaq	-0xd(%r12), %rsi
   64a7c:      	callq	0x70870 <f.3>
   64a81:      	subq	$0x8, %rsp
   64a85:      	cmpb	$0x0, 0x10fc4(%rip)     # 0x75a50 <g.4>
   64a8c:      	je	0x7085f <f.2+0x180af>
   64a92:      	movq	%rax, 0x10(%rsp)
   64a97:      	cmpq	$0x0, 0x10fa9(%rip)     # 0x75a48 <g.3>
   64a9f:      	je	0x7085f <f.2+0x180af>
   64aa5:      	leaq	-0xe(%r12), %rsi
   64aaa:      	movq	$0x0, 0x48(%rsp)
   64ab3:      	movq	$0x3, 0x30(%rsp)
   64abc:      	xorl	%edi, %edi
   64abe:      	callq	0x70870 <f.3>
   64ac3:      	subq	$0x8, %rsp
   64ac7:      	cmpb	$0x0, 0x10f82(%rip)     # 0x75a50 <g.4>
   64ace:      	je	0x7085f <f.2+0x180af>
   64ad4:      	movq	%rax, %rbp
   64ad7:      	addq	0x10(%rsp), %rbp
   64adc:      	addq	%r15, %rbp
   64adf:      	jmp	0x64afa <f.2+0xc34a>
   64ae1:      	movl	$0x1, %r15d
   64ae7:      	cmpq	$0x0, 0x10f59(%rip)     # 0x75a48 <g.3>
   64aef:      	je	0x7085f <f.2+0x180af>
   64af5:      	leaq	-0xc(%r12,%r15), %rbp
   64afa:      	cmpq	$0x0, 0x10f46(%rip)     # 0x75a48 <g.3>
   64b02:      	je	0x7085f <f.2+0x180af>
   64b08:      	cmpq	$0xc, %r12
   64b0c:      	ja	0x64b18 <f.2+0xc368>
   64b0e:      	leaq	-0xb(%r12), %r15
   64b13:      	jmp	0x64c37 <f.2+0xc487>
   64b18:      	cmpq	$0xd, %r12
   64b1c:      	jne	0x64b37 <f.2+0xc387>
   64b1e:      	movl	$0x1, %r15d
   64b24:      	cmpq	$0x0, 0x10f1c(%rip)     # 0x75a48 <g.3>
   64b2c:      	jne	0x64bc4 <f.2+0xc414>
   64b32:      	jmp	0x7085f <f.2+0x180af>
   64b37:      	leaq	-0xd(%r12), %rsi
   64b3c:      	movq	$0x0, 0x48(%rsp)
   64b45:      	movq	$0x3, 0x30(%rsp)
   64b4e:      	xorl	%edi, %edi
   64b50:      	callq	0x70870 <f.3>
   64b55:      	subq	$0x8, %rsp
   64b59:      	cmpb	$0x0, 0x10ef0(%rip)     # 0x75a50 <g.4>
   64b60:      	je	0x7085f <f.2+0x180af>
   64b66:      	movq	%rax, 0x10(%rsp)
   64b6b:      	cmpq	$0x0, 0x10ed5(%rip)     # 0x75a48 <g.3>
   64b73:      	je	0x7085f <f.2+0x180af>
   64b79:      	leaq	-0xe(%r12), %rsi
   64b7e:      	movq	$0x0, 0x48(%rsp)
   64b87:      	movq	$0x3, 0x30(%rsp)
   64b90:      	xorl	%edi, %edi
   64b92:      	callq	0x70870 <f.3>
   64b97:      	subq	$0x8, %rsp
   64b9b:      	cmpb	$0x0, 0x10eae(%rip)     # 0x75a50 <g.4>
   64ba2:      	je	0x7085f <f.2+0x180af>
   64ba8:      	cmpq	$0x0, 0x10e98(%rip)     # 0x75a48 <g.3>
   64bb0:      	je	0x7085f <f.2+0x180af>
   64bb6:      	movq	%rax, %r15
   64bb9:      	addq	0x10(%rsp), %r15
   64bbe:      	cmpq	$0xe, %r12
   64bc2:      	ja	0x64bcb <f.2+0xc41b>
   64bc4:      	leaq	-0xd(%r12), %rax
   64bc9:      	jmp	0x64c34 <f.2+0xc484>
   64bcb:      	movq	$0x0, 0x48(%rsp)
   64bd4:      	movq	$0x3, 0x30(%rsp)
   64bdd:      	xorl	%edi, %edi
   64bdf:      	leaq	-0xe(%r12), %rsi
   64be4:      	callq	0x70870 <f.3>
   64be9:      	subq	$0x8, %rsp
   64bed:      	cmpb	$0x0, 0x10e5c(%rip)     # 0x75a50 <g.4>
   64bf4:      	je	0x7085f <f.2+0x180af>
   64bfa:      	movq	%rax, 0x10(%rsp)
   64bff:      	cmpq	$0x0, 0x10e41(%rip)     # 0x75a48 <g.3>
   64c07:      	je	0x7085f <f.2+0x180af>
   64c0d:      	leaq	-0xf(%r12), %rsi
   64c12:      	movq	$0x0, 0x48(%rsp)
   64c1b:      	movq	$0x3, 0x30(%rsp)
   64c24:      	xorl	%edi, %edi
   64c26:      	callq	0x70870 <f.3>
   64c2b:      	subq	$0x8, %rsp
   64c2f:      	addq	0x10(%rsp), %rax
   64c34:      	addq	%rax, %r15
   64c37:      	cmpb	$0x0, 0x10e12(%rip)     # 0x75a50 <g.4>
   64c3e:      	je	0x7085f <f.2+0x180af>
   64c44:      	addq	%rbp, %r15
   64c47:      	addq	%r14, %r15
   64c4a:      	cmpq	$0x0, 0x10df6(%rip)     # 0x75a48 <g.3>
   64c52:      	je	0x7085f <f.2+0x180af>
   64c58:      	cmpq	$0x9, %r12
   64c5c:      	ja	0x64c76 <f.2+0xc4c6>
   64c5e:      	leaq	-0x8(%r12,%r15), %r14
   64c63:      	cmpq	$0x0, 0x10ddd(%rip)     # 0x75a48 <g.3>
   64c6b:      	jne	0x65203 <f.2+0xca53>
   64c71:      	jmp	0x7085f <f.2+0x180af>
   64c76:      	cmpq	$0xa, %r12
   64c7a:      	jne	0x64c94 <f.2+0xc4e4>
   64c7c:      	movl	$0x1, %ebp
   64c81:      	cmpq	$0x0, 0x10dbf(%rip)     # 0x75a48 <g.3>
   64c89:      	jne	0x64f3f <f.2+0xc78f>
   64c8f:      	jmp	0x7085f <f.2+0x180af>
   64c94:      	cmpq	$0xc, %r12
   64c98:      	jb	0x64cb4 <f.2+0xc504>
   64c9a:      	jne	0x64ccd <f.2+0xc51d>
   64c9c:      	movl	$0x1, %ebp
   64ca1:      	cmpq	$0x0, 0x10d9f(%rip)     # 0x75a48 <g.3>
   64ca9:      	jne	0x64d56 <f.2+0xc5a6>
   64caf:      	jmp	0x7085f <f.2+0x180af>
   64cb4:      	movl	$0x1, %r14d
   64cba:      	cmpq	$0x0, 0x10d86(%rip)     # 0x75a48 <g.3>
   64cc2:      	jne	0x64df3 <f.2+0xc643>
   64cc8:      	jmp	0x7085f <f.2+0x180af>
   64ccd:      	leaq	-0xc(%r12), %rsi
   64cd2:      	movq	$0x0, 0x48(%rsp)
   64cdb:      	movq	$0x3, 0x30(%rsp)
   64ce4:      	xorl	%edi, %edi
   64ce6:      	callq	0x70870 <f.3>
   64ceb:      	subq	$0x8, %rsp
   64cef:      	cmpb	$0x0, 0x10d5a(%rip)     # 0x75a50 <g.4>
   64cf6:      	je	0x7085f <f.2+0x180af>
   64cfc:      	cmpq	$0x0, 0x10d44(%rip)     # 0x75a48 <g.3>
   64d04:      	je	0x7085f <f.2+0x180af>
   64d0a:      	movq	%rax, %r14
   64d0d:      	leaq	-0xd(%r12), %rsi
   64d12:      	movq	$0x0, 0x48(%rsp)
   64d1b:      	movq	$0x3, 0x30(%rsp)
   64d24:      	xorl	%edi, %edi
   64d26:      	callq	0x70870 <f.3>
   64d2b:      	subq	$0x8, %rsp
   64d2f:      	cmpb	$0x0, 0x10d1a(%rip)     # 0x75a50 <g.4>
   64d36:      	je	0x7085f <f.2+0x180af>
   64d3c:      	cmpq	$0x0, 0x10d04(%rip)     # 0x75a48 <g.3>
   64d44:      	je	0x7085f <f.2+0x180af>
   64d4a:      	movq	%rax, %rbp
   64d4d:      	addq	%r14, %rbp
   64d50:      	cmpq	$0xd, %r12
   64d54:      	ja	0x64d5d <f.2+0xc5ad>
   64d56:      	leaq	-0xc(%r12,%rbp), %r14
   64d5b:      	jmp	0x64dd9 <f.2+0xc629>
   64d5d:      	movq	$0x0, 0x48(%rsp)
   64d66:      	movq	$0x3, 0x30(%rsp)
   64d6f:      	xorl	%edi, %edi
   64d71:      	leaq	-0xd(%r12), %rsi
   64d76:      	callq	0x70870 <f.3>
   64d7b:      	subq	$0x8, %rsp
   64d7f:      	cmpb	$0x0, 0x10cca(%rip)     # 0x75a50 <g.4>
   64d86:      	je	0x7085f <f.2+0x180af>
   64d8c:      	movq	%rax, 0x10(%rsp)
   64d91:      	cmpq	$0x0, 0x10caf(%rip)     # 0x75a48 <g.3>
   64d99:      	je	0x7085f <f.2+0x180af>
   64d9f:      	leaq	-0xe(%r12), %rsi
   64da4:      	movq	$0x0, 0x48(%rsp)
   64dad:      	movq	$0x3, 0x30(%rsp)
   64db6:      	xorl	%edi, %edi
   64db8:      	callq	0x70870 <f.3>
   64dbd:      	subq	$0x8, %rsp
   64dc1:      	cmpb	$0x0, 0x10c88(%rip)     # 0x75a50 <g.4>
   64dc8:      	je	0x7085f <f.2+0x180af>
   64dce:      	movq	%rax, %r14
   64dd1:      	addq	0x10(%rsp), %r14
   64dd6:      	addq	%rbp, %r14
   64dd9:      	cmpq	$0x0, 0x10c67(%rip)     # 0x75a48 <g.3>
   64de1:      	je	0x7085f <f.2+0x180af>
   64de7:      	cmpq	$0xd, %r12
   64deb:      	je	0x64dfd <f.2+0xc64d>
   64ded:      	cmpq	$0xc, %r12
   64df1:      	jne	0x64e15 <f.2+0xc665>
   64df3:      	leaq	-0xb(%r12,%r14), %rbp
   64df8:      	jmp	0x64f2b <f.2+0xc77b>
   64dfd:      	movl	$0x1, %eax
   64e02:      	cmpq	$0x0, 0x10c3e(%rip)     # 0x75a48 <g.3>
   64e0a:      	jne	0x64e9b <f.2+0xc6eb>
   64e10:      	jmp	0x7085f <f.2+0x180af>
   64e15:      	leaq	-0xd(%r12), %rsi
   64e1a:      	movq	$0x0, 0x48(%rsp)
   64e23:      	movq	$0x3, 0x30(%rsp)
   64e2c:      	xorl	%edi, %edi
   64e2e:      	callq	0x70870 <f.3>
   64e33:      	subq	$0x8, %rsp
   64e37:      	cmpb	$0x0, 0x10c12(%rip)     # 0x75a50 <g.4>
   64e3e:      	je	0x7085f <f.2+0x180af>
   64e44:      	cmpq	$0x0, 0x10bfc(%rip)     # 0x75a48 <g.3>
   64e4c:      	je	0x7085f <f.2+0x180af>
   64e52:      	movq	%rax, %rbp
   64e55:      	leaq	-0xe(%r12), %rsi
   64e5a:      	movq	$0x0, 0x48(%rsp)
   64e63:      	movq	$0x3, 0x30(%rsp)
   64e6c:      	xorl	%edi, %edi
   64e6e:      	callq	0x70870 <f.3>
   64e73:      	subq	$0x8, %rsp
   64e77:      	cmpb	$0x0, 0x10bd2(%rip)     # 0x75a50 <g.4>
   64e7e:      	je	0x7085f <f.2+0x180af>
   64e84:      	cmpq	$0x0, 0x10bbc(%rip)     # 0x75a48 <g.3>
   64e8c:      	je	0x7085f <f.2+0x180af>
   64e92:      	addq	%rbp, %rax
   64e95:      	cmpq	$0xe, %r12
   64e99:      	ja	0x64ea2 <f.2+0xc6f2>
   64e9b:      	leaq	-0xd(%r12), %rbp
   64ea0:      	jmp	0x64f18 <f.2+0xc768>
   64ea2:      	movq	%rax, 0x10(%rsp)
   64ea7:      	movq	$0x0, 0x48(%rsp)
   64eb0:      	movq	$0x3, 0x30(%rsp)
   64eb9:      	xorl	%edi, %edi
   64ebb:      	leaq	-0xe(%r12), %rsi
   64ec0:      	callq	0x70870 <f.3>
   64ec5:      	subq	$0x8, %rsp
   64ec9:      	cmpb	$0x0, 0x10b80(%rip)     # 0x75a50 <g.4>
   64ed0:      	je	0x7085f <f.2+0x180af>
   64ed6:      	movq	%rax, 0x18(%rsp)
   64edb:      	cmpq	$0x0, 0x10b65(%rip)     # 0x75a48 <g.3>
   64ee3:      	je	0x7085f <f.2+0x180af>
   64ee9:      	leaq	-0xf(%r12), %rsi
   64eee:      	movq	$0x0, 0x48(%rsp)
   64ef7:      	movq	$0x3, 0x30(%rsp)
   64f00:      	xorl	%edi, %edi
   64f02:      	callq	0x70870 <f.3>
   64f07:      	subq	$0x8, %rsp
   64f0b:      	movq	%rax, %rbp
   64f0e:      	addq	0x18(%rsp), %rbp
   64f13:      	movq	0x10(%rsp), %rax
   64f18:      	cmpb	$0x0, 0x10b31(%rip)     # 0x75a50 <g.4>
   64f1f:      	je	0x7085f <f.2+0x180af>
   64f25:      	addq	%rax, %rbp
   64f28:      	addq	%r14, %rbp
   64f2b:      	cmpq	$0x0, 0x10b15(%rip)     # 0x75a48 <g.3>
   64f33:      	je	0x7085f <f.2+0x180af>
   64f39:      	cmpq	$0xb, %r12
   64f3d:      	ja	0x64f49 <f.2+0xc799>
   64f3f:      	leaq	-0xa(%r12), %r14
   64f44:      	jmp	0x651e2 <f.2+0xca32>
   64f49:      	cmpq	$0xc, %r12
   64f4d:      	jne	0x64f68 <f.2+0xc7b8>
   64f4f:      	movl	$0x1, %r14d
   64f55:      	cmpq	$0x0, 0x10aeb(%rip)     # 0x75a48 <g.3>
   64f5d:      	jne	0x650ad <f.2+0xc8fd>
   64f63:      	jmp	0x7085f <f.2+0x180af>
   64f68:      	cmpq	$0xe, %r12
   64f6c:      	jb	0x65081 <f.2+0xc8d1>
   64f72:      	leaq	-0xd(%r12), %rsi
   64f77:      	movq	$0x0, 0x48(%rsp)
   64f80:      	movq	$0x3, 0x30(%rsp)
   64f89:      	xorl	%edi, %edi
   64f8b:      	callq	0x70870 <f.3>
   64f90:      	subq	$0x8, %rsp
   64f94:      	cmpb	$0x0, 0x10ab5(%rip)     # 0x75a50 <g.4>
   64f9b:      	je	0x7085f <f.2+0x180af>
   64fa1:      	cmpq	$0x0, 0x10a9f(%rip)     # 0x75a48 <g.3>
   64fa9:      	je	0x7085f <f.2+0x180af>
   64faf:      	movq	%rax, %r14
   64fb2:      	leaq	-0xe(%r12), %rsi
   64fb7:      	movq	$0x0, 0x48(%rsp)
   64fc0:      	movq	$0x3, 0x30(%rsp)
   64fc9:      	xorl	%edi, %edi
   64fcb:      	callq	0x70870 <f.3>
   64fd0:      	subq	$0x8, %rsp
   64fd4:      	cmpb	$0x0, 0x10a75(%rip)     # 0x75a50 <g.4>
   64fdb:      	je	0x7085f <f.2+0x180af>
   64fe1:      	cmpq	$0x0, 0x10a5f(%rip)     # 0x75a48 <g.3>
   64fe9:      	je	0x7085f <f.2+0x180af>
   64fef:      	addq	%r14, %rax
   64ff2:      	cmpq	$0xe, %r12
   64ff6:      	je	0x65094 <f.2+0xc8e4>
   64ffc:      	movq	%rax, 0x10(%rsp)
   65001:      	movq	$0x0, 0x48(%rsp)
   6500a:      	movq	$0x3, 0x30(%rsp)
   65013:      	xorl	%edi, %edi
   65015:      	leaq	-0xe(%r12), %rsi
   6501a:      	callq	0x70870 <f.3>
   6501f:      	subq	$0x8, %rsp
   65023:      	cmpb	$0x0, 0x10a26(%rip)     # 0x75a50 <g.4>
   6502a:      	je	0x7085f <f.2+0x180af>
   65030:      	movq	%rax, 0x18(%rsp)
   65035:      	cmpq	$0x0, 0x10a0b(%rip)     # 0x75a48 <g.3>
   6503d:      	je	0x7085f <f.2+0x180af>
   65043:      	leaq	-0xf(%r12), %rsi
   65048:      	movq	$0x0, 0x48(%rsp)
   65051:      	movq	$0x3, 0x30(%rsp)
   6505a:      	xorl	%edi, %edi
   6505c:      	callq	0x70870 <f.3>
   65061:      	subq	$0x8, %rsp
   65065:      	cmpb	$0x0, 0x109e4(%rip)     # 0x75a50 <g.4>
   6506c:      	je	0x7085f <f.2+0x180af>
   65072:      	movq	%rax, %r14
   65075:      	addq	0x18(%rsp), %r14
   6507a:      	addq	0x10(%rsp), %r14
   6507f:      	jmp	0x65099 <f.2+0xc8e9>
   65081:      	movl	$0x1, %eax
   65086:      	cmpq	$0x0, 0x109ba(%rip)     # 0x75a48 <g.3>
   6508e:      	je	0x7085f <f.2+0x180af>
   65094:      	leaq	-0xd(%r12,%rax), %r14
   65099:      	cmpq	$0x0, 0x109a7(%rip)     # 0x75a48 <g.3>
   650a1:      	je	0x7085f <f.2+0x180af>
   650a7:      	cmpq	$0xd, %r12
   650ab:      	ja	0x650b7 <f.2+0xc907>
   650ad:      	leaq	-0xc(%r12), %rcx
   650b2:      	jmp	0x651df <f.2+0xca2f>
   650b7:      	cmpq	$0xe, %r12
   650bb:      	jne	0x650d5 <f.2+0xc925>
   650bd:      	movl	$0x1, %ecx
   650c2:      	cmpq	$0x0, 0x1097e(%rip)     # 0x75a48 <g.3>
   650ca:      	jne	0x65162 <f.2+0xc9b2>
   650d0:      	jmp	0x7085f <f.2+0x180af>
   650d5:      	leaq	-0xe(%r12), %rsi
   650da:      	movq	$0x0, 0x48(%rsp)
   650e3:      	movq	$0x3, 0x30(%rsp)
   650ec:      	xorl	%edi, %edi
   650ee:      	callq	0x70870 <f.3>
   650f3:      	subq	$0x8, %rsp
   650f7:      	cmpb	$0x0, 0x10952(%rip)     # 0x75a50 <g.4>
   650fe:      	je	0x7085f <f.2+0x180af>
   65104:      	movq	%rax, 0x10(%rsp)
   65109:      	cmpq	$0x0, 0x10937(%rip)     # 0x75a48 <g.3>
   65111:      	je	0x7085f <f.2+0x180af>
   65117:      	leaq	-0xf(%r12), %rsi
   6511c:      	movq	$0x0, 0x48(%rsp)
   65125:      	movq	$0x3, 0x30(%rsp)
   6512e:      	xorl	%edi, %edi
   65130:      	callq	0x70870 <f.3>
   65135:      	subq	$0x8, %rsp
   65139:      	cmpb	$0x0, 0x10910(%rip)     # 0x75a50 <g.4>
   65140:      	je	0x7085f <f.2+0x180af>
   65146:      	cmpq	$0x0, 0x108fa(%rip)     # 0x75a48 <g.3>
   6514e:      	je	0x7085f <f.2+0x180af>
   65154:      	movq	%rax, %rcx
   65157:      	addq	0x10(%rsp), %rcx
   6515c:      	cmpq	$0xf, %r12
   65160:      	ja	0x65169 <f.2+0xc9b9>
   65162:      	leaq	-0xe(%r12), %rax
   65167:      	jmp	0x651dc <f.2+0xca2c>
   65169:      	movq	%rcx, 0x10(%rsp)
   6516e:      	movq	$0x0, 0x48(%rsp)
   65177:      	movq	$0x3, 0x30(%rsp)
   65180:      	xorl	%edi, %edi
   65182:      	leaq	-0xf(%r12), %rsi
   65187:      	callq	0x70870 <f.3>
   6518c:      	subq	$0x8, %rsp
   65190:      	cmpb	$0x0, 0x108b9(%rip)     # 0x75a50 <g.4>
   65197:      	je	0x7085f <f.2+0x180af>
   6519d:      	movq	%rax, 0x18(%rsp)
   651a2:      	cmpq	$0x0, 0x1089e(%rip)     # 0x75a48 <g.3>
   651aa:      	je	0x7085f <f.2+0x180af>
   651b0:      	leaq	-0x10(%r12), %rsi
   651b5:      	movq	$0x0, 0x48(%rsp)
   651be:      	movq	$0x3, 0x30(%rsp)
   651c7:      	xorl	%edi, %edi
   651c9:      	callq	0x70870 <f.3>
   651ce:      	subq	$0x8, %rsp
   651d2:      	addq	0x18(%rsp), %rax
   651d7:      	movq	0x10(%rsp), %rcx
   651dc:      	addq	%rax, %rcx
   651df:      	addq	%rcx, %r14
   651e2:      	cmpb	$0x0, 0x10867(%rip)     # 0x75a50 <g.4>
   651e9:      	je	0x7085f <f.2+0x180af>
   651ef:      	addq	%rbp, %r14
   651f2:      	addq	%r15, %r14
   651f5:      	cmpq	$0x0, 0x1084b(%rip)     # 0x75a48 <g.3>
   651fd:      	je	0x7085f <f.2+0x180af>
   65203:      	cmpq	$0x9, %r12
   65207:      	je	0x65227 <f.2+0xca77>
   65209:      	cmpq	$0x8, %r12
   6520d:      	jne	0x6523f <f.2+0xca8f>
   6520f:      	leaq	-0x7(%r12,%r14), %r15
   65214:      	cmpq	$0x0, 0x1082c(%rip)     # 0x75a48 <g.3>
   6521c:      	jne	0x65da4 <f.2+0xd5f4>
   65222:      	jmp	0x7085f <f.2+0x180af>
   65227:      	movl	$0x1, %ebp
   6522c:      	cmpq	$0x0, 0x10814(%rip)     # 0x75a48 <g.3>
   65234:      	jne	0x657d7 <f.2+0xd027>
   6523a:      	jmp	0x7085f <f.2+0x180af>
   6523f:      	cmpq	$0xb, %r12
   65243:      	jb	0x6525f <f.2+0xcaaf>
   65245:      	jne	0x65278 <f.2+0xcac8>
   65247:      	movl	$0x1, %ebp
   6524c:      	cmpq	$0x0, 0x107f4(%rip)     # 0x75a48 <g.3>
   65254:      	jne	0x653ba <f.2+0xcc0a>
   6525a:      	jmp	0x7085f <f.2+0x180af>
   6525f:      	movl	$0x1, %r15d
   65265:      	cmpq	$0x0, 0x107db(%rip)     # 0x75a48 <g.3>
   6526d:      	jne	0x65512 <f.2+0xcd62>
   65273:      	jmp	0x7085f <f.2+0x180af>
   65278:      	cmpq	$0xd, %r12
   6527c:      	jb	0x6538d <f.2+0xcbdd>
   65282:      	leaq	-0xc(%r12), %rsi
   65287:      	movq	$0x0, 0x48(%rsp)
   65290:      	movq	$0x3, 0x30(%rsp)
   65299:      	xorl	%edi, %edi
   6529b:      	callq	0x70870 <f.3>
   652a0:      	subq	$0x8, %rsp
   652a4:      	cmpb	$0x0, 0x107a5(%rip)     # 0x75a50 <g.4>
   652ab:      	je	0x7085f <f.2+0x180af>
   652b1:      	cmpq	$0x0, 0x1078f(%rip)     # 0x75a48 <g.3>
   652b9:      	je	0x7085f <f.2+0x180af>
   652bf:      	movq	%rax, %rbp
   652c2:      	leaq	-0xd(%r12), %rsi
   652c7:      	movq	$0x0, 0x48(%rsp)
   652d0:      	movq	$0x3, 0x30(%rsp)
   652d9:      	xorl	%edi, %edi
   652db:      	callq	0x70870 <f.3>
   652e0:      	subq	$0x8, %rsp
   652e4:      	cmpb	$0x0, 0x10765(%rip)     # 0x75a50 <g.4>
   652eb:      	je	0x7085f <f.2+0x180af>
   652f1:      	cmpq	$0x0, 0x1074f(%rip)     # 0x75a48 <g.3>
   652f9:      	je	0x7085f <f.2+0x180af>
   652ff:      	movq	%rax, %r15
   65302:      	addq	%rbp, %r15
   65305:      	cmpq	$0xd, %r12
   65309:      	je	0x653a1 <f.2+0xcbf1>
   6530f:      	movq	$0x0, 0x48(%rsp)
   65318:      	movq	$0x3, 0x30(%rsp)
   65321:      	xorl	%edi, %edi
   65323:      	leaq	-0xd(%r12), %rsi
   65328:      	callq	0x70870 <f.3>
   6532d:      	subq	$0x8, %rsp
   65331:      	cmpb	$0x0, 0x10718(%rip)     # 0x75a50 <g.4>
   65338:      	je	0x7085f <f.2+0x180af>
   6533e:      	movq	%rax, 0x10(%rsp)
   65343:      	cmpq	$0x0, 0x106fd(%rip)     # 0x75a48 <g.3>
   6534b:      	je	0x7085f <f.2+0x180af>
   65351:      	leaq	-0xe(%r12), %rsi
   65356:      	movq	$0x0, 0x48(%rsp)
   6535f:      	movq	$0x3, 0x30(%rsp)
   65368:      	xorl	%edi, %edi
   6536a:      	callq	0x70870 <f.3>
   6536f:      	subq	$0x8, %rsp
   65373:      	cmpb	$0x0, 0x106d6(%rip)     # 0x75a50 <g.4>
   6537a:      	je	0x7085f <f.2+0x180af>
   65380:      	movq	%rax, %rbp
   65383:      	addq	0x10(%rsp), %rbp
   65388:      	addq	%r15, %rbp
   6538b:      	jmp	0x653a6 <f.2+0xcbf6>
   6538d:      	movl	$0x1, %r15d
   65393:      	cmpq	$0x0, 0x106ad(%rip)     # 0x75a48 <g.3>
   6539b:      	je	0x7085f <f.2+0x180af>
   653a1:      	leaq	-0xc(%r12,%r15), %rbp
   653a6:      	cmpq	$0x0, 0x1069a(%rip)     # 0x75a48 <g.3>
   653ae:      	je	0x7085f <f.2+0x180af>
   653b4:      	cmpq	$0xc, %r12
   653b8:      	ja	0x653c4 <f.2+0xcc14>
   653ba:      	leaq	-0xb(%r12,%rbp), %r15
   653bf:      	jmp	0x654f8 <f.2+0xcd48>
   653c4:      	cmpq	$0xd, %r12
   653c8:      	jne	0x653e2 <f.2+0xcc32>
   653ca:      	movl	$0x1, %eax
   653cf:      	cmpq	$0x0, 0x10671(%rip)     # 0x75a48 <g.3>
   653d7:      	jne	0x65468 <f.2+0xccb8>
   653dd:      	jmp	0x7085f <f.2+0x180af>
   653e2:      	leaq	-0xd(%r12), %rsi
   653e7:      	movq	$0x0, 0x48(%rsp)
   653f0:      	movq	$0x3, 0x30(%rsp)
   653f9:      	xorl	%edi, %edi
   653fb:      	callq	0x70870 <f.3>
   65400:      	subq	$0x8, %rsp
   65404:      	cmpb	$0x0, 0x10645(%rip)     # 0x75a50 <g.4>
   6540b:      	je	0x7085f <f.2+0x180af>
   65411:      	cmpq	$0x0, 0x1062f(%rip)     # 0x75a48 <g.3>
   65419:      	je	0x7085f <f.2+0x180af>
   6541f:      	movq	%rax, %r15
   65422:      	leaq	-0xe(%r12), %rsi
   65427:      	movq	$0x0, 0x48(%rsp)
   65430:      	movq	$0x3, 0x30(%rsp)
   65439:      	xorl	%edi, %edi
   6543b:      	callq	0x70870 <f.3>
   65440:      	subq	$0x8, %rsp
   65444:      	cmpb	$0x0, 0x10605(%rip)     # 0x75a50 <g.4>
   6544b:      	je	0x7085f <f.2+0x180af>
   65451:      	cmpq	$0x0, 0x105ef(%rip)     # 0x75a48 <g.3>
   65459:      	je	0x7085f <f.2+0x180af>
   6545f:      	addq	%r15, %rax
   65462:      	cmpq	$0xe, %r12
   65466:      	ja	0x6546f <f.2+0xccbf>
   65468:      	leaq	-0xd(%r12), %r15
   6546d:      	jmp	0x654e5 <f.2+0xcd35>
   6546f:      	movq	%rax, 0x10(%rsp)
   65474:      	movq	$0x0, 0x48(%rsp)
   6547d:      	movq	$0x3, 0x30(%rsp)
   65486:      	xorl	%edi, %edi
   65488:      	leaq	-0xe(%r12), %rsi
   6548d:      	callq	0x70870 <f.3>
   65492:      	subq	$0x8, %rsp
   65496:      	cmpb	$0x0, 0x105b3(%rip)     # 0x75a50 <g.4>
   6549d:      	je	0x7085f <f.2+0x180af>
   654a3:      	movq	%rax, 0x18(%rsp)
   654a8:      	cmpq	$0x0, 0x10598(%rip)     # 0x75a48 <g.3>
   654b0:      	je	0x7085f <f.2+0x180af>
   654b6:      	leaq	-0xf(%r12), %rsi
   654bb:      	movq	$0x0, 0x48(%rsp)
   654c4:      	movq	$0x3, 0x30(%rsp)
   654cd:      	xorl	%edi, %edi
   654cf:      	callq	0x70870 <f.3>
   654d4:      	subq	$0x8, %rsp
   654d8:      	movq	%rax, %r15
   654db:      	addq	0x18(%rsp), %r15
   654e0:      	movq	0x10(%rsp), %rax
   654e5:      	cmpb	$0x0, 0x10564(%rip)     # 0x75a50 <g.4>
   654ec:      	je	0x7085f <f.2+0x180af>
   654f2:      	addq	%rax, %r15
   654f5:      	addq	%rbp, %r15
   654f8:      	cmpq	$0x0, 0x10548(%rip)     # 0x75a48 <g.3>
   65500:      	je	0x7085f <f.2+0x180af>
   65506:      	cmpq	$0xc, %r12
   6550a:      	je	0x6551c <f.2+0xcd6c>
   6550c:      	cmpq	$0xb, %r12
   65510:      	jne	0x65534 <f.2+0xcd84>
   65512:      	leaq	-0xa(%r12,%r15), %rbp
   65517:      	jmp	0x657c3 <f.2+0xd013>
   6551c:      	movl	$0x1, %ecx
   65521:      	cmpq	$0x0, 0x1051f(%rip)     # 0x75a48 <g.3>
   65529:      	jne	0x65679 <f.2+0xcec9>
   6552f:      	jmp	0x7085f <f.2+0x180af>
   65534:      	cmpq	$0xe, %r12
   65538:      	jb	0x6564d <f.2+0xce9d>
   6553e:      	leaq	-0xd(%r12), %rsi
   65543:      	movq	$0x0, 0x48(%rsp)
   6554c:      	movq	$0x3, 0x30(%rsp)
   65555:      	xorl	%edi, %edi
   65557:      	callq	0x70870 <f.3>
   6555c:      	subq	$0x8, %rsp
   65560:      	cmpb	$0x0, 0x104e9(%rip)     # 0x75a50 <g.4>
   65567:      	je	0x7085f <f.2+0x180af>
   6556d:      	movq	%rax, 0x10(%rsp)
   65572:      	cmpq	$0x0, 0x104ce(%rip)     # 0x75a48 <g.3>
   6557a:      	je	0x7085f <f.2+0x180af>
   65580:      	leaq	-0xe(%r12), %rsi
   65585:      	movq	$0x0, 0x48(%rsp)
   6558e:      	movq	$0x3, 0x30(%rsp)
   65597:      	xorl	%edi, %edi
   65599:      	callq	0x70870 <f.3>
   6559e:      	subq	$0x8, %rsp
   655a2:      	cmpb	$0x0, 0x104a7(%rip)     # 0x75a50 <g.4>
   655a9:      	je	0x7085f <f.2+0x180af>
   655af:      	cmpq	$0x0, 0x10491(%rip)     # 0x75a48 <g.3>
   655b7:      	je	0x7085f <f.2+0x180af>
   655bd:      	movq	%rax, %rbp
   655c0:      	addq	0x10(%rsp), %rbp
   655c5:      	cmpq	$0xe, %r12
   655c9:      	je	0x65660 <f.2+0xceb0>
   655cf:      	movq	$0x0, 0x48(%rsp)
   655d8:      	movq	$0x3, 0x30(%rsp)
   655e1:      	xorl	%edi, %edi
   655e3:      	leaq	-0xe(%r12), %rsi
   655e8:      	callq	0x70870 <f.3>
   655ed:      	subq	$0x8, %rsp
   655f1:      	cmpb	$0x0, 0x10458(%rip)     # 0x75a50 <g.4>
   655f8:      	je	0x7085f <f.2+0x180af>
   655fe:      	movq	%rax, 0x10(%rsp)
   65603:      	cmpq	$0x0, 0x1043d(%rip)     # 0x75a48 <g.3>
   6560b:      	je	0x7085f <f.2+0x180af>
   65611:      	leaq	-0xf(%r12), %rsi
   65616:      	movq	$0x0, 0x48(%rsp)
   6561f:      	movq	$0x3, 0x30(%rsp)
   65628:      	xorl	%edi, %edi
   6562a:      	callq	0x70870 <f.3>
   6562f:      	subq	$0x8, %rsp
   65633:      	cmpb	$0x0, 0x10416(%rip)     # 0x75a50 <g.4>
   6563a:      	je	0x7085f <f.2+0x180af>
   65640:      	movq	%rax, %rcx
   65643:      	addq	0x10(%rsp), %rcx
   65648:      	addq	%rbp, %rcx
   6564b:      	jmp	0x65665 <f.2+0xceb5>
   6564d:      	movl	$0x1, %ebp
   65652:      	cmpq	$0x0, 0x103ee(%rip)     # 0x75a48 <g.3>
   6565a:      	je	0x7085f <f.2+0x180af>
   65660:      	leaq	-0xd(%r12,%rbp), %rcx
   65665:      	cmpq	$0x0, 0x103db(%rip)     # 0x75a48 <g.3>
   6566d:      	je	0x7085f <f.2+0x180af>
   65673:      	cmpq	$0xd, %r12
   65677:      	ja	0x65683 <f.2+0xced3>
   65679:      	leaq	-0xc(%r12), %rbp
   6567e:      	jmp	0x657b0 <f.2+0xd000>
   65683:      	cmpq	$0xe, %r12
   65687:      	jne	0x656a1 <f.2+0xcef1>
   65689:      	movl	$0x1, %ebp
   6568e:      	cmpq	$0x0, 0x103b2(%rip)     # 0x75a48 <g.3>
   65696:      	jne	0x65738 <f.2+0xcf88>
   6569c:      	jmp	0x7085f <f.2+0x180af>
   656a1:      	movq	%rcx, 0x10(%rsp)
   656a6:      	leaq	-0xe(%r12), %rsi
   656ab:      	movq	$0x0, 0x48(%rsp)
   656b4:      	movq	$0x3, 0x30(%rsp)
   656bd:      	xorl	%edi, %edi
   656bf:      	callq	0x70870 <f.3>
   656c4:      	subq	$0x8, %rsp
   656c8:      	cmpb	$0x0, 0x10381(%rip)     # 0x75a50 <g.4>
   656cf:      	je	0x7085f <f.2+0x180af>
   656d5:      	movq	%rax, 0x18(%rsp)
   656da:      	cmpq	$0x0, 0x10366(%rip)     # 0x75a48 <g.3>
   656e2:      	je	0x7085f <f.2+0x180af>
   656e8:      	leaq	-0xf(%r12), %rsi
   656ed:      	movq	$0x0, 0x48(%rsp)
   656f6:      	movq	$0x3, 0x30(%rsp)
   656ff:      	xorl	%edi, %edi
   65701:      	callq	0x70870 <f.3>
   65706:      	subq	$0x8, %rsp
   6570a:      	cmpb	$0x0, 0x1033f(%rip)     # 0x75a50 <g.4>
   65711:      	je	0x7085f <f.2+0x180af>
   65717:      	cmpq	$0x0, 0x10329(%rip)     # 0x75a48 <g.3>
   6571f:      	movq	0x10(%rsp), %rcx
   65724:      	je	0x7085f <f.2+0x180af>
   6572a:      	movq	%rax, %rbp
   6572d:      	addq	0x18(%rsp), %rbp
   65732:      	cmpq	$0xf, %r12
   65736:      	ja	0x6573f <f.2+0xcf8f>
   65738:      	leaq	-0xe(%r12), %rax
   6573d:      	jmp	0x657ad <f.2+0xcffd>
   6573f:      	movq	$0x0, 0x48(%rsp)
   65748:      	movq	$0x3, 0x30(%rsp)
   65751:      	xorl	%edi, %edi
   65753:      	leaq	-0xf(%r12), %rsi
   65758:      	callq	0x70870 <f.3>
   6575d:      	subq	$0x8, %rsp
   65761:      	cmpb	$0x0, 0x102e8(%rip)     # 0x75a50 <g.4>
   65768:      	je	0x7085f <f.2+0x180af>
   6576e:      	movq	%rax, 0x18(%rsp)
   65773:      	cmpq	$0x0, 0x102cd(%rip)     # 0x75a48 <g.3>
   6577b:      	je	0x7085f <f.2+0x180af>
   65781:      	leaq	-0x10(%r12), %rsi
   65786:      	movq	$0x0, 0x48(%rsp)
   6578f:      	movq	$0x3, 0x30(%rsp)
   65798:      	xorl	%edi, %edi
   6579a:      	callq	0x70870 <f.3>
   6579f:      	subq	$0x8, %rsp
   657a3:      	addq	0x18(%rsp), %rax
   657a8:      	movq	0x10(%rsp), %rcx
   657ad:      	addq	%rax, %rbp
   657b0:      	cmpb	$0x0, 0x10299(%rip)     # 0x75a50 <g.4>
   657b7:      	je	0x7085f <f.2+0x180af>
   657bd:      	addq	%rcx, %rbp
   657c0:      	addq	%r15, %rbp
   657c3:      	cmpq	$0x0, 0x1027d(%rip)     # 0x75a48 <g.3>
   657cb:      	je	0x7085f <f.2+0x180af>
   657d1:      	cmpq	$0xa, %r12
   657d5:      	ja	0x657ee <f.2+0xd03e>
   657d7:      	leaq	-0x9(%r12), %r15
   657dc:      	cmpb	$0x0, 0x1026d(%rip)     # 0x75a50 <g.4>
   657e3:      	jne	0x65d90 <f.2+0xd5e0>
   657e9:      	jmp	0x7085f <f.2+0x180af>
   657ee:      	cmpq	$0xb, %r12
   657f2:      	jne	0x6580d <f.2+0xd05d>
   657f4:      	movl	$0x1, %r15d
   657fa:      	cmpq	$0x0, 0x10246(%rip)     # 0x75a48 <g.3>
   65802:      	jne	0x65acb <f.2+0xd31b>
   65808:      	jmp	0x7085f <f.2+0x180af>
   6580d:      	cmpq	$0xd, %r12
   65811:      	jb	0x6582e <f.2+0xd07e>
   65813:      	jne	0x65846 <f.2+0xd096>
   65815:      	movl	$0x1, %r15d
   6581b:      	cmpq	$0x0, 0x10225(%rip)     # 0x75a48 <g.3>
   65823:      	jne	0x658d3 <f.2+0xd123>
   65829:      	jmp	0x7085f <f.2+0x180af>
   6582e:      	movl	$0x1, %eax
   65833:      	cmpq	$0x0, 0x1020d(%rip)     # 0x75a48 <g.3>
   6583b:      	jne	0x6596d <f.2+0xd1bd>
   65841:      	jmp	0x7085f <f.2+0x180af>
   65846:      	leaq	-0xd(%r12), %rsi
   6584b:      	movq	$0x0, 0x48(%rsp)
   65854:      	movq	$0x3, 0x30(%rsp)
   6585d:      	xorl	%edi, %edi
   6585f:      	callq	0x70870 <f.3>
   65864:      	subq	$0x8, %rsp
   65868:      	cmpb	$0x0, 0x101e1(%rip)     # 0x75a50 <g.4>
   6586f:      	je	0x7085f <f.2+0x180af>
   65875:      	movq	%rax, 0x10(%rsp)
   6587a:      	cmpq	$0x0, 0x101c6(%rip)     # 0x75a48 <g.3>
   65882:      	je	0x7085f <f.2+0x180af>
   65888:      	leaq	-0xe(%r12), %rsi
   6588d:      	movq	$0x0, 0x48(%rsp)
   65896:      	movq	$0x3, 0x30(%rsp)
   6589f:      	xorl	%edi, %edi
   658a1:      	callq	0x70870 <f.3>
   658a6:      	subq	$0x8, %rsp
   658aa:      	cmpb	$0x0, 0x1019f(%rip)     # 0x75a50 <g.4>
   658b1:      	je	0x7085f <f.2+0x180af>
   658b7:      	cmpq	$0x0, 0x10189(%rip)     # 0x75a48 <g.3>
   658bf:      	je	0x7085f <f.2+0x180af>
   658c5:      	movq	%rax, %r15
   658c8:      	addq	0x10(%rsp), %r15
   658cd:      	cmpq	$0xe, %r12
   658d1:      	ja	0x658da <f.2+0xd12a>
   658d3:      	leaq	-0xd(%r12,%r15), %rax
   658d8:      	jmp	0x65953 <f.2+0xd1a3>
   658da:      	movq	$0x0, 0x48(%rsp)
   658e3:      	movq	$0x3, 0x30(%rsp)
   658ec:      	xorl	%edi, %edi
   658ee:      	leaq	-0xe(%r12), %rsi
   658f3:      	callq	0x70870 <f.3>
   658f8:      	subq	$0x8, %rsp
   658fc:      	cmpb	$0x0, 0x1014d(%rip)     # 0x75a50 <g.4>
   65903:      	je	0x7085f <f.2+0x180af>
   65909:      	movq	%rax, 0x10(%rsp)
   6590e:      	cmpq	$0x0, 0x10132(%rip)     # 0x75a48 <g.3>
   65916:      	je	0x7085f <f.2+0x180af>
   6591c:      	leaq	-0xf(%r12), %rsi
   65921:      	movq	$0x0, 0x48(%rsp)
   6592a:      	movq	$0x3, 0x30(%rsp)
   65933:      	xorl	%edi, %edi
   65935:      	callq	0x70870 <f.3>
   6593a:      	subq	$0x8, %rsp
   6593e:      	cmpb	$0x0, 0x1010b(%rip)     # 0x75a50 <g.4>
   65945:      	je	0x7085f <f.2+0x180af>
   6594b:      	addq	0x10(%rsp), %rax
   65950:      	addq	%r15, %rax
   65953:      	cmpq	$0x0, 0x100ed(%rip)     # 0x75a48 <g.3>
   6595b:      	je	0x7085f <f.2+0x180af>
   65961:      	cmpq	$0xe, %r12
   65965:      	je	0x65977 <f.2+0xd1c7>
   65967:      	cmpq	$0xd, %r12
   6596b:      	jne	0x6598f <f.2+0xd1df>
   6596d:      	leaq	-0xc(%r12,%rax), %r15
   65972:      	jmp	0x65ab7 <f.2+0xd307>
   65977:      	movl	$0x1, %ecx
   6597c:      	cmpq	$0x0, 0x100c4(%rip)     # 0x75a48 <g.3>
   65984:      	jne	0x65a22 <f.2+0xd272>
   6598a:      	jmp	0x7085f <f.2+0x180af>
   6598f:      	movq	%rax, 0x10(%rsp)
   65994:      	leaq	-0xe(%r12), %rsi
   65999:      	movq	$0x0, 0x48(%rsp)
   659a2:      	movq	$0x3, 0x30(%rsp)
   659ab:      	xorl	%edi, %edi
   659ad:      	callq	0x70870 <f.3>
   659b2:      	subq	$0x8, %rsp
   659b6:      	cmpb	$0x0, 0x10093(%rip)     # 0x75a50 <g.4>
   659bd:      	je	0x7085f <f.2+0x180af>
   659c3:      	cmpq	$0x0, 0x1007d(%rip)     # 0x75a48 <g.3>
   659cb:      	je	0x7085f <f.2+0x180af>
   659d1:      	movq	%rax, %r15
   659d4:      	leaq	-0xf(%r12), %rsi
   659d9:      	movq	$0x0, 0x48(%rsp)
   659e2:      	movq	$0x3, 0x30(%rsp)
   659eb:      	xorl	%edi, %edi
   659ed:      	callq	0x70870 <f.3>
   659f2:      	subq	$0x8, %rsp
   659f6:      	cmpb	$0x0, 0x10053(%rip)     # 0x75a50 <g.4>
   659fd:      	je	0x7085f <f.2+0x180af>
   65a03:      	movq	%rax, %rcx
   65a06:      	cmpq	$0x0, 0x1003a(%rip)     # 0x75a48 <g.3>
   65a0e:      	movq	0x10(%rsp), %rax
   65a13:      	je	0x7085f <f.2+0x180af>
   65a19:      	addq	%r15, %rcx
   65a1c:      	cmpq	$0xf, %r12
   65a20:      	ja	0x65a29 <f.2+0xd279>
   65a22:      	leaq	-0xe(%r12), %r15
   65a27:      	jmp	0x65aa4 <f.2+0xd2f4>
   65a29:      	movq	%rcx, 0x18(%rsp)
   65a2e:      	movq	$0x0, 0x48(%rsp)
   65a37:      	movq	$0x3, 0x30(%rsp)
   65a40:      	xorl	%edi, %edi
   65a42:      	leaq	-0xf(%r12), %rsi
   65a47:      	callq	0x70870 <f.3>
   65a4c:      	subq	$0x8, %rsp
   65a50:      	cmpb	$0x0, 0xfff9(%rip)      # 0x75a50 <g.4>
   65a57:      	je	0x7085f <f.2+0x180af>
   65a5d:      	movq	%rax, 0x50(%rsp)
   65a62:      	cmpq	$0x0, 0xffde(%rip)      # 0x75a48 <g.3>
   65a6a:      	je	0x7085f <f.2+0x180af>
   65a70:      	leaq	-0x10(%r12), %rsi
   65a75:      	movq	$0x0, 0x48(%rsp)
   65a7e:      	movq	$0x3, 0x30(%rsp)
   65a87:      	xorl	%edi, %edi
   65a89:      	callq	0x70870 <f.3>
   65a8e:      	subq	$0x8, %rsp
   65a92:      	movq	%rax, %r15
   65a95:      	addq	0x50(%rsp), %r15
   65a9a:      	movq	0x10(%rsp), %rax
   65a9f:      	movq	0x18(%rsp), %rcx
   65aa4:      	cmpb	$0x0, 0xffa5(%rip)      # 0x75a50 <g.4>
   65aab:      	je	0x7085f <f.2+0x180af>
   65ab1:      	addq	%rcx, %r15
   65ab4:      	addq	%rax, %r15
   65ab7:      	cmpq	$0x0, 0xff89(%rip)      # 0x75a48 <g.3>
   65abf:      	je	0x7085f <f.2+0x180af>
   65ac5:      	cmpq	$0xc, %r12
   65ac9:      	ja	0x65ad5 <f.2+0xd325>
   65acb:      	leaq	-0xb(%r12), %rcx
   65ad0:      	jmp	0x65d80 <f.2+0xd5d0>
   65ad5:      	cmpq	$0xd, %r12
   65ad9:      	jne	0x65af3 <f.2+0xd343>
   65adb:      	movl	$0x1, %ecx
   65ae0:      	cmpq	$0x0, 0xff60(%rip)      # 0x75a48 <g.3>
   65ae8:      	jne	0x65c3c <f.2+0xd48c>
   65aee:      	jmp	0x7085f <f.2+0x180af>
   65af3:      	cmpq	$0xf, %r12
   65af7:      	jb	0x65c10 <f.2+0xd460>
   65afd:      	leaq	-0xe(%r12), %rsi
   65b02:      	movq	$0x0, 0x48(%rsp)
   65b0b:      	movq	$0x3, 0x30(%rsp)
   65b14:      	xorl	%edi, %edi
   65b16:      	callq	0x70870 <f.3>
   65b1b:      	subq	$0x8, %rsp
   65b1f:      	cmpb	$0x0, 0xff2a(%rip)      # 0x75a50 <g.4>
   65b26:      	je	0x7085f <f.2+0x180af>
   65b2c:      	movq	%rax, 0x10(%rsp)
   65b31:      	cmpq	$0x0, 0xff0f(%rip)      # 0x75a48 <g.3>
   65b39:      	je	0x7085f <f.2+0x180af>
   65b3f:      	leaq	-0xf(%r12), %rsi
   65b44:      	movq	$0x0, 0x48(%rsp)
   65b4d:      	movq	$0x3, 0x30(%rsp)
   65b56:      	xorl	%edi, %edi
   65b58:      	callq	0x70870 <f.3>
   65b5d:      	subq	$0x8, %rsp
   65b61:      	cmpb	$0x0, 0xfee8(%rip)      # 0x75a50 <g.4>
   65b68:      	je	0x7085f <f.2+0x180af>
   65b6e:      	cmpq	$0x0, 0xfed2(%rip)      # 0x75a48 <g.3>
   65b76:      	je	0x7085f <f.2+0x180af>
   65b7c:      	addq	0x10(%rsp), %rax
   65b81:      	cmpq	$0xf, %r12
   65b85:      	je	0x65c23 <f.2+0xd473>
   65b8b:      	movq	%rax, 0x10(%rsp)
   65b90:      	movq	$0x0, 0x48(%rsp)
   65b99:      	movq	$0x3, 0x30(%rsp)
   65ba2:      	xorl	%edi, %edi
   65ba4:      	leaq	-0xf(%r12), %rsi
   65ba9:      	callq	0x70870 <f.3>
   65bae:      	subq	$0x8, %rsp
   65bb2:      	cmpb	$0x0, 0xfe97(%rip)      # 0x75a50 <g.4>
   65bb9:      	je	0x7085f <f.2+0x180af>
   65bbf:      	movq	%rax, 0x18(%rsp)
   65bc4:      	cmpq	$0x0, 0xfe7c(%rip)      # 0x75a48 <g.3>
   65bcc:      	je	0x7085f <f.2+0x180af>
   65bd2:      	leaq	-0x10(%r12), %rsi
   65bd7:      	movq	$0x0, 0x48(%rsp)
   65be0:      	movq	$0x3, 0x30(%rsp)
   65be9:      	xorl	%edi, %edi
   65beb:      	callq	0x70870 <f.3>
   65bf0:      	subq	$0x8, %rsp
   65bf4:      	cmpb	$0x0, 0xfe55(%rip)      # 0x75a50 <g.4>
   65bfb:      	je	0x7085f <f.2+0x180af>
   65c01:      	movq	%rax, %rcx
   65c04:      	addq	0x18(%rsp), %rcx
   65c09:      	addq	0x10(%rsp), %rcx
   65c0e:      	jmp	0x65c28 <f.2+0xd478>
   65c10:      	movl	$0x1, %eax
   65c15:      	cmpq	$0x0, 0xfe2b(%rip)      # 0x75a48 <g.3>
   65c1d:      	je	0x7085f <f.2+0x180af>
   65c23:      	leaq	-0xe(%r12,%rax), %rcx
   65c28:      	cmpq	$0x0, 0xfe18(%rip)      # 0x75a48 <g.3>
   65c30:      	je	0x7085f <f.2+0x180af>
   65c36:      	cmpq	$0xe, %r12
   65c3a:      	ja	0x65c46 <f.2+0xd496>
   65c3c:      	leaq	-0xd(%r12), %rdx
   65c41:      	jmp	0x65d7d <f.2+0xd5cd>
   65c46:      	cmpq	$0xf, %r12
   65c4a:      	jne	0x65c64 <f.2+0xd4b4>
   65c4c:      	movl	$0x1, %edx
   65c51:      	cmpq	$0x0, 0xfdef(%rip)      # 0x75a48 <g.3>
   65c59:      	jne	0x65cfb <f.2+0xd54b>
   65c5f:      	jmp	0x7085f <f.2+0x180af>
   65c64:      	movq	%rcx, 0x10(%rsp)
   65c69:      	leaq	-0xf(%r12), %rsi
   65c6e:      	movq	$0x0, 0x48(%rsp)
   65c77:      	movq	$0x3, 0x30(%rsp)
   65c80:      	xorl	%edi, %edi
   65c82:      	callq	0x70870 <f.3>
   65c87:      	subq	$0x8, %rsp
   65c8b:      	cmpb	$0x0, 0xfdbe(%rip)      # 0x75a50 <g.4>
   65c92:      	je	0x7085f <f.2+0x180af>
   65c98:      	movq	%rax, 0x18(%rsp)
   65c9d:      	cmpq	$0x0, 0xfda3(%rip)      # 0x75a48 <g.3>
   65ca5:      	je	0x7085f <f.2+0x180af>
   65cab:      	leaq	-0x10(%r12), %rsi
   65cb0:      	movq	$0x0, 0x48(%rsp)
   65cb9:      	movq	$0x3, 0x30(%rsp)
   65cc2:      	xorl	%edi, %edi
   65cc4:      	callq	0x70870 <f.3>
   65cc9:      	subq	$0x8, %rsp
   65ccd:      	cmpb	$0x0, 0xfd7c(%rip)      # 0x75a50 <g.4>
   65cd4:      	je	0x7085f <f.2+0x180af>
   65cda:      	cmpq	$0x0, 0xfd66(%rip)      # 0x75a48 <g.3>
   65ce2:      	movq	0x10(%rsp), %rcx
   65ce7:      	je	0x7085f <f.2+0x180af>
   65ced:      	movq	%rax, %rdx
   65cf0:      	addq	0x18(%rsp), %rdx
   65cf5:      	cmpq	$0x10, %r12
   65cf9:      	ja	0x65d02 <f.2+0xd552>
   65cfb:      	leaq	-0xf(%r12), %rax
   65d00:      	jmp	0x65d7a <f.2+0xd5ca>
   65d02:      	movq	%rdx, 0x18(%rsp)
   65d07:      	movq	$0x0, 0x48(%rsp)
   65d10:      	movq	$0x3, 0x30(%rsp)
   65d19:      	xorl	%edi, %edi
   65d1b:      	leaq	-0x10(%r12), %rsi
   65d20:      	callq	0x70870 <f.3>
   65d25:      	subq	$0x8, %rsp
   65d29:      	cmpb	$0x0, 0xfd20(%rip)      # 0x75a50 <g.4>
   65d30:      	je	0x7085f <f.2+0x180af>
   65d36:      	movq	%rax, 0x50(%rsp)
   65d3b:      	cmpq	$0x0, 0xfd05(%rip)      # 0x75a48 <g.3>
   65d43:      	je	0x7085f <f.2+0x180af>
   65d49:      	leaq	-0x11(%r12), %rsi
   65d4e:      	movq	$0x0, 0x48(%rsp)
   65d57:      	movq	$0x3, 0x30(%rsp)
   65d60:      	xorl	%edi, %edi
   65d62:      	callq	0x70870 <f.3>
   65d67:      	subq	$0x8, %rsp
   65d6b:      	addq	0x50(%rsp), %rax
   65d70:      	movq	0x10(%rsp), %rcx
   65d75:      	movq	0x18(%rsp), %rdx
   65d7a:      	addq	%rax, %rdx
   65d7d:      	addq	%rdx, %rcx
   65d80:      	addq	%rcx, %r15
   65d83:      	cmpb	$0x0, 0xfcc6(%rip)      # 0x75a50 <g.4>
   65d8a:      	je	0x7085f <f.2+0x180af>
   65d90:      	addq	%rbp, %r15
   65d93:      	addq	%r14, %r15
   65d96:      	cmpq	$0x0, 0xfcaa(%rip)      # 0x75a48 <g.3>
   65d9e:      	je	0x7085f <f.2+0x180af>
   65da4:      	cmpq	$0x7, %r12
   65da8:      	ja	0x65dc7 <f.2+0xd617>
   65daa:      	leaq	-0x6(%r12,%r15), %r14
   65daf:      	cmpq	$0x0, 0xfc91(%rip)      # 0x75a48 <g.3>
   65db7:      	leaq	0x68(%rsp), %r15
   65dbc:      	jne	0x67557 <f.2+0xeda7>
   65dc2:      	jmp	0x7085f <f.2+0x180af>
   65dc7:      	cmpq	$0x8, %r12
   65dcb:      	jne	0x65de5 <f.2+0xd635>
   65dcd:      	movl	$0x1, %ebp
   65dd2:      	cmpq	$0x0, 0xfc6e(%rip)      # 0x75a48 <g.3>
   65dda:      	jne	0x6696c <f.2+0xe1bc>
   65de0:      	jmp	0x7085f <f.2+0x180af>
   65de5:      	cmpq	$0xa, %r12
   65de9:      	jb	0x65e05 <f.2+0xd655>
   65deb:      	jne	0x65e1e <f.2+0xd66e>
   65ded:      	movl	$0x1, %ebp
   65df2:      	cmpq	$0x0, 0xfc4e(%rip)      # 0x75a48 <g.3>
   65dfa:      	jne	0x660c9 <f.2+0xd919>
   65e00:      	jmp	0x7085f <f.2+0x180af>
   65e05:      	movl	$0x1, %r14d
   65e0b:      	cmpq	$0x0, 0xfc35(%rip)      # 0x75a48 <g.3>
   65e13:      	jne	0x6639c <f.2+0xdbec>
   65e19:      	jmp	0x7085f <f.2+0x180af>
   65e1e:      	cmpq	$0xc, %r12
   65e22:      	jb	0x65e3e <f.2+0xd68e>
   65e24:      	jne	0x65e57 <f.2+0xd6a7>
   65e26:      	movl	$0x1, %ebp
   65e2b:      	cmpq	$0x0, 0xfc15(%rip)      # 0x75a48 <g.3>
   65e33:      	jne	0x65ee0 <f.2+0xd730>
   65e39:      	jmp	0x7085f <f.2+0x180af>
   65e3e:      	movl	$0x1, %r14d
   65e44:      	cmpq	$0x0, 0xfbfc(%rip)      # 0x75a48 <g.3>
   65e4c:      	jne	0x65f7d <f.2+0xd7cd>
   65e52:      	jmp	0x7085f <f.2+0x180af>
   65e57:      	leaq	-0xc(%r12), %rsi
   65e5c:      	movq	$0x0, 0x48(%rsp)
   65e65:      	movq	$0x3, 0x30(%rsp)
   65e6e:      	xorl	%edi, %edi
   65e70:      	callq	0x70870 <f.3>
   65e75:      	subq	$0x8, %rsp
   65e79:      	cmpb	$0x0, 0xfbd0(%rip)      # 0x75a50 <g.4>
   65e80:      	je	0x7085f <f.2+0x180af>
   65e86:      	cmpq	$0x0, 0xfbba(%rip)      # 0x75a48 <g.3>
   65e8e:      	je	0x7085f <f.2+0x180af>
   65e94:      	movq	%rax, %r14
   65e97:      	leaq	-0xd(%r12), %rsi
   65e9c:      	movq	$0x0, 0x48(%rsp)
   65ea5:      	movq	$0x3, 0x30(%rsp)
   65eae:      	xorl	%edi, %edi
   65eb0:      	callq	0x70870 <f.3>
   65eb5:      	subq	$0x8, %rsp
   65eb9:      	cmpb	$0x0, 0xfb90(%rip)      # 0x75a50 <g.4>
   65ec0:      	je	0x7085f <f.2+0x180af>
   65ec6:      	cmpq	$0x0, 0xfb7a(%rip)      # 0x75a48 <g.3>
   65ece:      	je	0x7085f <f.2+0x180af>
   65ed4:      	movq	%rax, %rbp
   65ed7:      	addq	%r14, %rbp
   65eda:      	cmpq	$0xd, %r12
   65ede:      	ja	0x65ee7 <f.2+0xd737>
   65ee0:      	leaq	-0xc(%r12,%rbp), %r14
   65ee5:      	jmp	0x65f63 <f.2+0xd7b3>
   65ee7:      	movq	$0x0, 0x48(%rsp)
   65ef0:      	movq	$0x3, 0x30(%rsp)
   65ef9:      	xorl	%edi, %edi
   65efb:      	leaq	-0xd(%r12), %rsi
   65f00:      	callq	0x70870 <f.3>
   65f05:      	subq	$0x8, %rsp
   65f09:      	cmpb	$0x0, 0xfb40(%rip)      # 0x75a50 <g.4>
   65f10:      	je	0x7085f <f.2+0x180af>
   65f16:      	movq	%rax, 0x10(%rsp)
   65f1b:      	cmpq	$0x0, 0xfb25(%rip)      # 0x75a48 <g.3>
   65f23:      	je	0x7085f <f.2+0x180af>
   65f29:      	leaq	-0xe(%r12), %rsi
   65f2e:      	movq	$0x0, 0x48(%rsp)
   65f37:      	movq	$0x3, 0x30(%rsp)
   65f40:      	xorl	%edi, %edi
   65f42:      	callq	0x70870 <f.3>
   65f47:      	subq	$0x8, %rsp
   65f4b:      	cmpb	$0x0, 0xfafe(%rip)      # 0x75a50 <g.4>
   65f52:      	je	0x7085f <f.2+0x180af>
   65f58:      	movq	%rax, %r14
   65f5b:      	addq	0x10(%rsp), %r14
   65f60:      	addq	%rbp, %r14
   65f63:      	cmpq	$0x0, 0xfadd(%rip)      # 0x75a48 <g.3>
   65f6b:      	je	0x7085f <f.2+0x180af>
   65f71:      	cmpq	$0xd, %r12
   65f75:      	je	0x65f87 <f.2+0xd7d7>
   65f77:      	cmpq	$0xc, %r12
   65f7b:      	jne	0x65f9f <f.2+0xd7ef>
   65f7d:      	leaq	-0xb(%r12,%r14), %rbp
   65f82:      	jmp	0x660b5 <f.2+0xd905>
   65f87:      	movl	$0x1, %eax
   65f8c:      	cmpq	$0x0, 0xfab4(%rip)      # 0x75a48 <g.3>
   65f94:      	jne	0x66025 <f.2+0xd875>
   65f9a:      	jmp	0x7085f <f.2+0x180af>
   65f9f:      	leaq	-0xd(%r12), %rsi
   65fa4:      	movq	$0x0, 0x48(%rsp)
   65fad:      	movq	$0x3, 0x30(%rsp)
   65fb6:      	xorl	%edi, %edi
   65fb8:      	callq	0x70870 <f.3>
   65fbd:      	subq	$0x8, %rsp
   65fc1:      	cmpb	$0x0, 0xfa88(%rip)      # 0x75a50 <g.4>
   65fc8:      	je	0x7085f <f.2+0x180af>
   65fce:      	cmpq	$0x0, 0xfa72(%rip)      # 0x75a48 <g.3>
   65fd6:      	je	0x7085f <f.2+0x180af>
   65fdc:      	movq	%rax, %rbp
   65fdf:      	leaq	-0xe(%r12), %rsi
   65fe4:      	movq	$0x0, 0x48(%rsp)
   65fed:      	movq	$0x3, 0x30(%rsp)
   65ff6:      	xorl	%edi, %edi
   65ff8:      	callq	0x70870 <f.3>
   65ffd:      	subq	$0x8, %rsp
   66001:      	cmpb	$0x0, 0xfa48(%rip)      # 0x75a50 <g.4>
   66008:      	je	0x7085f <f.2+0x180af>
   6600e:      	cmpq	$0x0, 0xfa32(%rip)      # 0x75a48 <g.3>
   66016:      	je	0x7085f <f.2+0x180af>
   6601c:      	addq	%rbp, %rax
   6601f:      	cmpq	$0xe, %r12
   66023:      	ja	0x6602c <f.2+0xd87c>
   66025:      	leaq	-0xd(%r12), %rbp
   6602a:      	jmp	0x660a2 <f.2+0xd8f2>
   6602c:      	movq	%rax, 0x10(%rsp)
   66031:      	movq	$0x0, 0x48(%rsp)
   6603a:      	movq	$0x3, 0x30(%rsp)
   66043:      	xorl	%edi, %edi
   66045:      	leaq	-0xe(%r12), %rsi
   6604a:      	callq	0x70870 <f.3>
   6604f:      	subq	$0x8, %rsp
   66053:      	cmpb	$0x0, 0xf9f6(%rip)      # 0x75a50 <g.4>
   6605a:      	je	0x7085f <f.2+0x180af>
   66060:      	movq	%rax, 0x18(%rsp)
   66065:      	cmpq	$0x0, 0xf9db(%rip)      # 0x75a48 <g.3>
   6606d:      	je	0x7085f <f.2+0x180af>
   66073:      	leaq	-0xf(%r12), %rsi
   66078:      	movq	$0x0, 0x48(%rsp)
   66081:      	movq	$0x3, 0x30(%rsp)
   6608a:      	xorl	%edi, %edi
   6608c:      	callq	0x70870 <f.3>
   66091:      	subq	$0x8, %rsp
   66095:      	movq	%rax, %rbp
   66098:      	addq	0x18(%rsp), %rbp
   6609d:      	movq	0x10(%rsp), %rax
   660a2:      	cmpb	$0x0, 0xf9a7(%rip)      # 0x75a50 <g.4>
   660a9:      	je	0x7085f <f.2+0x180af>
   660af:      	addq	%rax, %rbp
   660b2:      	addq	%r14, %rbp
   660b5:      	cmpq	$0x0, 0xf98b(%rip)      # 0x75a48 <g.3>
   660bd:      	je	0x7085f <f.2+0x180af>
   660c3:      	cmpq	$0xb, %r12
   660c7:      	ja	0x660d3 <f.2+0xd923>
   660c9:      	leaq	-0xa(%r12,%rbp), %r14
   660ce:      	jmp	0x66382 <f.2+0xdbd2>
   660d3:      	cmpq	$0xc, %r12
   660d7:      	jne	0x660f1 <f.2+0xd941>
   660d9:      	movl	$0x1, %ecx
   660de:      	cmpq	$0x0, 0xf962(%rip)      # 0x75a48 <g.3>
   660e6:      	jne	0x66237 <f.2+0xda87>
   660ec:      	jmp	0x7085f <f.2+0x180af>
   660f1:      	cmpq	$0xe, %r12
   660f5:      	jb	0x6620a <f.2+0xda5a>
   660fb:      	leaq	-0xd(%r12), %rsi
   66100:      	movq	$0x0, 0x48(%rsp)
   66109:      	movq	$0x3, 0x30(%rsp)
   66112:      	xorl	%edi, %edi
   66114:      	callq	0x70870 <f.3>
   66119:      	subq	$0x8, %rsp
   6611d:      	cmpb	$0x0, 0xf92c(%rip)      # 0x75a50 <g.4>
   66124:      	je	0x7085f <f.2+0x180af>
   6612a:      	movq	%rax, 0x10(%rsp)
   6612f:      	cmpq	$0x0, 0xf911(%rip)      # 0x75a48 <g.3>
   66137:      	je	0x7085f <f.2+0x180af>
   6613d:      	leaq	-0xe(%r12), %rsi
   66142:      	movq	$0x0, 0x48(%rsp)
   6614b:      	movq	$0x3, 0x30(%rsp)
   66154:      	xorl	%edi, %edi
   66156:      	callq	0x70870 <f.3>
   6615b:      	subq	$0x8, %rsp
   6615f:      	cmpb	$0x0, 0xf8ea(%rip)      # 0x75a50 <g.4>
   66166:      	je	0x7085f <f.2+0x180af>
   6616c:      	cmpq	$0x0, 0xf8d4(%rip)      # 0x75a48 <g.3>
   66174:      	je	0x7085f <f.2+0x180af>
   6617a:      	movq	%rax, %r14
   6617d:      	addq	0x10(%rsp), %r14
   66182:      	cmpq	$0xe, %r12
   66186:      	je	0x6621e <f.2+0xda6e>
   6618c:      	movq	$0x0, 0x48(%rsp)
   66195:      	movq	$0x3, 0x30(%rsp)
   6619e:      	xorl	%edi, %edi
   661a0:      	leaq	-0xe(%r12), %rsi
   661a5:      	callq	0x70870 <f.3>
   661aa:      	subq	$0x8, %rsp
   661ae:      	cmpb	$0x0, 0xf89b(%rip)      # 0x75a50 <g.4>
   661b5:      	je	0x7085f <f.2+0x180af>
   661bb:      	movq	%rax, 0x10(%rsp)
   661c0:      	cmpq	$0x0, 0xf880(%rip)      # 0x75a48 <g.3>
   661c8:      	je	0x7085f <f.2+0x180af>
   661ce:      	leaq	-0xf(%r12), %rsi
   661d3:      	movq	$0x0, 0x48(%rsp)
   661dc:      	movq	$0x3, 0x30(%rsp)
   661e5:      	xorl	%edi, %edi
   661e7:      	callq	0x70870 <f.3>
   661ec:      	subq	$0x8, %rsp
   661f0:      	cmpb	$0x0, 0xf859(%rip)      # 0x75a50 <g.4>
   661f7:      	je	0x7085f <f.2+0x180af>
   661fd:      	movq	%rax, %rcx
   66200:      	addq	0x10(%rsp), %rcx
   66205:      	addq	%r14, %rcx
   66208:      	jmp	0x66223 <f.2+0xda73>
   6620a:      	movl	$0x1, %r14d
   66210:      	cmpq	$0x0, 0xf830(%rip)      # 0x75a48 <g.3>
   66218:      	je	0x7085f <f.2+0x180af>
   6621e:      	leaq	-0xd(%r12,%r14), %rcx
   66223:      	cmpq	$0x0, 0xf81d(%rip)      # 0x75a48 <g.3>
   6622b:      	je	0x7085f <f.2+0x180af>
   66231:      	cmpq	$0xd, %r12
   66235:      	ja	0x66241 <f.2+0xda91>
   66237:      	leaq	-0xc(%r12), %r14
   6623c:      	jmp	0x6636f <f.2+0xdbbf>
   66241:      	cmpq	$0xe, %r12
   66245:      	jne	0x66260 <f.2+0xdab0>
   66247:      	movl	$0x1, %r14d
   6624d:      	cmpq	$0x0, 0xf7f3(%rip)      # 0x75a48 <g.3>
   66255:      	jne	0x662f7 <f.2+0xdb47>
   6625b:      	jmp	0x7085f <f.2+0x180af>
   66260:      	movq	%rcx, 0x10(%rsp)
   66265:      	leaq	-0xe(%r12), %rsi
   6626a:      	movq	$0x0, 0x48(%rsp)
   66273:      	movq	$0x3, 0x30(%rsp)
   6627c:      	xorl	%edi, %edi
   6627e:      	callq	0x70870 <f.3>
   66283:      	subq	$0x8, %rsp
   66287:      	cmpb	$0x0, 0xf7c2(%rip)      # 0x75a50 <g.4>
   6628e:      	je	0x7085f <f.2+0x180af>
   66294:      	movq	%rax, 0x18(%rsp)
   66299:      	cmpq	$0x0, 0xf7a7(%rip)      # 0x75a48 <g.3>
   662a1:      	je	0x7085f <f.2+0x180af>
   662a7:      	leaq	-0xf(%r12), %rsi
   662ac:      	movq	$0x0, 0x48(%rsp)
   662b5:      	movq	$0x3, 0x30(%rsp)
   662be:      	xorl	%edi, %edi
   662c0:      	callq	0x70870 <f.3>
   662c5:      	subq	$0x8, %rsp
   662c9:      	cmpb	$0x0, 0xf780(%rip)      # 0x75a50 <g.4>
   662d0:      	je	0x7085f <f.2+0x180af>
   662d6:      	cmpq	$0x0, 0xf76a(%rip)      # 0x75a48 <g.3>
   662de:      	movq	0x10(%rsp), %rcx
   662e3:      	je	0x7085f <f.2+0x180af>
   662e9:      	movq	%rax, %r14
   662ec:      	addq	0x18(%rsp), %r14
   662f1:      	cmpq	$0xf, %r12
   662f5:      	ja	0x662fe <f.2+0xdb4e>
   662f7:      	leaq	-0xe(%r12), %rax
   662fc:      	jmp	0x6636c <f.2+0xdbbc>
   662fe:      	movq	$0x0, 0x48(%rsp)
   66307:      	movq	$0x3, 0x30(%rsp)
   66310:      	xorl	%edi, %edi
   66312:      	leaq	-0xf(%r12), %rsi
   66317:      	callq	0x70870 <f.3>
   6631c:      	subq	$0x8, %rsp
   66320:      	cmpb	$0x0, 0xf729(%rip)      # 0x75a50 <g.4>
   66327:      	je	0x7085f <f.2+0x180af>
   6632d:      	movq	%rax, 0x18(%rsp)
   66332:      	cmpq	$0x0, 0xf70e(%rip)      # 0x75a48 <g.3>
   6633a:      	je	0x7085f <f.2+0x180af>
   66340:      	leaq	-0x10(%r12), %rsi
   66345:      	movq	$0x0, 0x48(%rsp)
   6634e:      	movq	$0x3, 0x30(%rsp)
   66357:      	xorl	%edi, %edi
   66359:      	callq	0x70870 <f.3>
   6635e:      	subq	$0x8, %rsp
   66362:      	addq	0x18(%rsp), %rax
   66367:      	movq	0x10(%rsp), %rcx
   6636c:      	addq	%rax, %r14
   6636f:      	cmpb	$0x0, 0xf6da(%rip)      # 0x75a50 <g.4>
   66376:      	je	0x7085f <f.2+0x180af>
   6637c:      	addq	%rcx, %r14
   6637f:      	addq	%rbp, %r14
   66382:      	cmpq	$0x0, 0xf6be(%rip)      # 0x75a48 <g.3>
   6638a:      	je	0x7085f <f.2+0x180af>
   66390:      	cmpq	$0xb, %r12
   66394:      	je	0x663b4 <f.2+0xdc04>
   66396:      	cmpq	$0xa, %r12
   6639a:      	jne	0x663cc <f.2+0xdc1c>
   6639c:      	leaq	-0x9(%r12,%r14), %rbp
   663a1:      	cmpq	$0x0, 0xf69f(%rip)      # 0x75a48 <g.3>
   663a9:      	jne	0x66966 <f.2+0xe1b6>
   663af:      	jmp	0x7085f <f.2+0x180af>
   663b4:      	movl	$0x1, %ecx
   663b9:      	cmpq	$0x0, 0xf687(%rip)      # 0x75a48 <g.3>
   663c1:      	jne	0x66685 <f.2+0xded5>
   663c7:      	jmp	0x7085f <f.2+0x180af>
   663cc:      	cmpq	$0xd, %r12
   663d0:      	jb	0x663ec <f.2+0xdc3c>
   663d2:      	jne	0x66404 <f.2+0xdc54>
   663d4:      	movl	$0x1, %ebp
   663d9:      	cmpq	$0x0, 0xf667(%rip)      # 0x75a48 <g.3>
   663e1:      	jne	0x66491 <f.2+0xdce1>
   663e7:      	jmp	0x7085f <f.2+0x180af>
   663ec:      	movl	$0x1, %eax
   663f1:      	cmpq	$0x0, 0xf64f(%rip)      # 0x75a48 <g.3>
   663f9:      	jne	0x6652b <f.2+0xdd7b>
   663ff:      	jmp	0x7085f <f.2+0x180af>
   66404:      	leaq	-0xd(%r12), %rsi
   66409:      	movq	$0x0, 0x48(%rsp)
   66412:      	movq	$0x3, 0x30(%rsp)
   6641b:      	xorl	%edi, %edi
   6641d:      	callq	0x70870 <f.3>
   66422:      	subq	$0x8, %rsp
   66426:      	cmpb	$0x0, 0xf623(%rip)      # 0x75a50 <g.4>
   6642d:      	je	0x7085f <f.2+0x180af>
   66433:      	movq	%rax, 0x10(%rsp)
   66438:      	cmpq	$0x0, 0xf608(%rip)      # 0x75a48 <g.3>
   66440:      	je	0x7085f <f.2+0x180af>
   66446:      	leaq	-0xe(%r12), %rsi
   6644b:      	movq	$0x0, 0x48(%rsp)
   66454:      	movq	$0x3, 0x30(%rsp)
   6645d:      	xorl	%edi, %edi
   6645f:      	callq	0x70870 <f.3>
   66464:      	subq	$0x8, %rsp
   66468:      	cmpb	$0x0, 0xf5e1(%rip)      # 0x75a50 <g.4>
   6646f:      	je	0x7085f <f.2+0x180af>
   66475:      	cmpq	$0x0, 0xf5cb(%rip)      # 0x75a48 <g.3>
   6647d:      	je	0x7085f <f.2+0x180af>
   66483:      	movq	%rax, %rbp
   66486:      	addq	0x10(%rsp), %rbp
   6648b:      	cmpq	$0xe, %r12
   6648f:      	ja	0x66498 <f.2+0xdce8>
   66491:      	leaq	-0xd(%r12,%rbp), %rax
   66496:      	jmp	0x66511 <f.2+0xdd61>
   66498:      	movq	$0x0, 0x48(%rsp)
   664a1:      	movq	$0x3, 0x30(%rsp)
   664aa:      	xorl	%edi, %edi
   664ac:      	leaq	-0xe(%r12), %rsi
   664b1:      	callq	0x70870 <f.3>
   664b6:      	subq	$0x8, %rsp
   664ba:      	cmpb	$0x0, 0xf58f(%rip)      # 0x75a50 <g.4>
   664c1:      	je	0x7085f <f.2+0x180af>
   664c7:      	movq	%rax, 0x10(%rsp)
   664cc:      	cmpq	$0x0, 0xf574(%rip)      # 0x75a48 <g.3>
   664d4:      	je	0x7085f <f.2+0x180af>
   664da:      	leaq	-0xf(%r12), %rsi
   664df:      	movq	$0x0, 0x48(%rsp)
   664e8:      	movq	$0x3, 0x30(%rsp)
   664f1:      	xorl	%edi, %edi
   664f3:      	callq	0x70870 <f.3>
   664f8:      	subq	$0x8, %rsp
   664fc:      	cmpb	$0x0, 0xf54d(%rip)      # 0x75a50 <g.4>
   66503:      	je	0x7085f <f.2+0x180af>
   66509:      	addq	0x10(%rsp), %rax
   6650e:      	addq	%rbp, %rax
   66511:      	cmpq	$0x0, 0xf52f(%rip)      # 0x75a48 <g.3>
   66519:      	je	0x7085f <f.2+0x180af>
   6651f:      	cmpq	$0xe, %r12
   66523:      	je	0x66535 <f.2+0xdd85>
   66525:      	cmpq	$0xd, %r12
   66529:      	jne	0x6654d <f.2+0xdd9d>
   6652b:      	leaq	-0xc(%r12,%rax), %rcx
   66530:      	jmp	0x66671 <f.2+0xdec1>
   66535:      	movl	$0x1, %edx
   6653a:      	cmpq	$0x0, 0xf506(%rip)      # 0x75a48 <g.3>
   66542:      	jne	0x665e0 <f.2+0xde30>
   66548:      	jmp	0x7085f <f.2+0x180af>
   6654d:      	movq	%rax, 0x10(%rsp)
   66552:      	leaq	-0xe(%r12), %rsi
   66557:      	movq	$0x0, 0x48(%rsp)
   66560:      	movq	$0x3, 0x30(%rsp)
   66569:      	xorl	%edi, %edi
   6656b:      	callq	0x70870 <f.3>
   66570:      	subq	$0x8, %rsp
   66574:      	cmpb	$0x0, 0xf4d5(%rip)      # 0x75a50 <g.4>
   6657b:      	je	0x7085f <f.2+0x180af>
   66581:      	cmpq	$0x0, 0xf4bf(%rip)      # 0x75a48 <g.3>
   66589:      	je	0x7085f <f.2+0x180af>
   6658f:      	movq	%rax, %rbp
   66592:      	leaq	-0xf(%r12), %rsi
   66597:      	movq	$0x0, 0x48(%rsp)
   665a0:      	movq	$0x3, 0x30(%rsp)
   665a9:      	xorl	%edi, %edi
   665ab:      	callq	0x70870 <f.3>
   665b0:      	subq	$0x8, %rsp
   665b4:      	cmpb	$0x0, 0xf495(%rip)      # 0x75a50 <g.4>
   665bb:      	je	0x7085f <f.2+0x180af>
   665c1:      	movq	%rax, %rdx
   665c4:      	cmpq	$0x0, 0xf47c(%rip)      # 0x75a48 <g.3>
   665cc:      	movq	0x10(%rsp), %rax
   665d1:      	je	0x7085f <f.2+0x180af>
   665d7:      	addq	%rbp, %rdx
   665da:      	cmpq	$0xf, %r12
   665de:      	ja	0x665e7 <f.2+0xde37>
   665e0:      	leaq	-0xe(%r12), %rcx
   665e5:      	jmp	0x6665e <f.2+0xdeae>
   665e7:      	movq	%rdx, 0x18(%rsp)
   665ec:      	movq	$0x0, 0x48(%rsp)
   665f5:      	movq	$0x3, 0x30(%rsp)
   665fe:      	xorl	%edi, %edi
   66600:      	leaq	-0xf(%r12), %rsi
   66605:      	callq	0x70870 <f.3>
   6660a:      	subq	$0x8, %rsp
   6660e:      	cmpb	$0x0, 0xf43b(%rip)      # 0x75a50 <g.4>
   66615:      	je	0x7085f <f.2+0x180af>
   6661b:      	cmpq	$0x0, 0xf425(%rip)      # 0x75a48 <g.3>
   66623:      	je	0x7085f <f.2+0x180af>
   66629:      	movq	%rax, %rbp
   6662c:      	leaq	-0x10(%r12), %rsi
   66631:      	movq	$0x0, 0x48(%rsp)
   6663a:      	movq	$0x3, 0x30(%rsp)
   66643:      	xorl	%edi, %edi
   66645:      	callq	0x70870 <f.3>
   6664a:      	subq	$0x8, %rsp
   6664e:      	movq	%rax, %rcx
   66651:      	addq	%rbp, %rcx
   66654:      	movq	0x10(%rsp), %rax
   66659:      	movq	0x18(%rsp), %rdx
   6665e:      	cmpb	$0x0, 0xf3eb(%rip)      # 0x75a50 <g.4>
   66665:      	je	0x7085f <f.2+0x180af>
   6666b:      	addq	%rdx, %rcx
   6666e:      	addq	%rax, %rcx
   66671:      	cmpq	$0x0, 0xf3cf(%rip)      # 0x75a48 <g.3>
   66679:      	je	0x7085f <f.2+0x180af>
   6667f:      	cmpq	$0xc, %r12
   66683:      	ja	0x6668f <f.2+0xdedf>
   66685:      	leaq	-0xb(%r12), %rbp
   6668a:      	jmp	0x66945 <f.2+0xe195>
   6668f:      	cmpq	$0xd, %r12
   66693:      	jne	0x666ad <f.2+0xdefd>
   66695:      	movl	$0x1, %ebp
   6669a:      	cmpq	$0x0, 0xf3a6(%rip)      # 0x75a48 <g.3>
   666a2:      	jne	0x66801 <f.2+0xe051>
   666a8:      	jmp	0x7085f <f.2+0x180af>
   666ad:      	cmpq	$0xf, %r12
   666b1:      	jb	0x667d5 <f.2+0xe025>
   666b7:      	movq	%rcx, 0x10(%rsp)
   666bc:      	leaq	-0xe(%r12), %rsi
   666c1:      	movq	$0x0, 0x48(%rsp)
   666ca:      	movq	$0x3, 0x30(%rsp)
   666d3:      	xorl	%edi, %edi
   666d5:      	callq	0x70870 <f.3>
   666da:      	subq	$0x8, %rsp
   666de:      	cmpb	$0x0, 0xf36b(%rip)      # 0x75a50 <g.4>
   666e5:      	je	0x7085f <f.2+0x180af>
   666eb:      	cmpq	$0x0, 0xf355(%rip)      # 0x75a48 <g.3>
   666f3:      	je	0x7085f <f.2+0x180af>
   666f9:      	movq	%rax, %rbp
   666fc:      	leaq	-0xf(%r12), %rsi
   66701:      	movq	$0x0, 0x48(%rsp)
   6670a:      	movq	$0x3, 0x30(%rsp)
   66713:      	xorl	%edi, %edi
   66715:      	callq	0x70870 <f.3>
   6671a:      	subq	$0x8, %rsp
   6671e:      	cmpb	$0x0, 0xf32b(%rip)      # 0x75a50 <g.4>
   66725:      	je	0x7085f <f.2+0x180af>
   6672b:      	cmpq	$0x0, 0xf315(%rip)      # 0x75a48 <g.3>
   66733:      	movq	0x10(%rsp), %rcx
   66738:      	je	0x7085f <f.2+0x180af>
   6673e:      	addq	%rbp, %rax
   66741:      	cmpq	$0xf, %r12
   66745:      	je	0x667e8 <f.2+0xe038>
   6674b:      	movq	%rax, 0x18(%rsp)
   66750:      	movq	$0x0, 0x48(%rsp)
   66759:      	movq	$0x3, 0x30(%rsp)
   66762:      	xorl	%edi, %edi
   66764:      	leaq	-0xf(%r12), %rsi
   66769:      	callq	0x70870 <f.3>
   6676e:      	subq	$0x8, %rsp
   66772:      	cmpb	$0x0, 0xf2d7(%rip)      # 0x75a50 <g.4>
   66779:      	je	0x7085f <f.2+0x180af>
   6677f:      	movq	%rax, 0x50(%rsp)
   66784:      	cmpq	$0x0, 0xf2bc(%rip)      # 0x75a48 <g.3>
   6678c:      	je	0x7085f <f.2+0x180af>
   66792:      	leaq	-0x10(%r12), %rsi
   66797:      	movq	$0x0, 0x48(%rsp)
   667a0:      	movq	$0x3, 0x30(%rsp)
   667a9:      	xorl	%edi, %edi
   667ab:      	callq	0x70870 <f.3>
   667b0:      	subq	$0x8, %rsp
   667b4:      	cmpb	$0x0, 0xf295(%rip)      # 0x75a50 <g.4>
   667bb:      	je	0x7085f <f.2+0x180af>
   667c1:      	movq	%rax, %rbp
   667c4:      	addq	0x50(%rsp), %rbp
   667c9:      	addq	0x18(%rsp), %rbp
   667ce:      	movq	0x10(%rsp), %rcx
   667d3:      	jmp	0x667ed <f.2+0xe03d>
   667d5:      	movl	$0x1, %eax
   667da:      	cmpq	$0x0, 0xf266(%rip)      # 0x75a48 <g.3>
   667e2:      	je	0x7085f <f.2+0x180af>
   667e8:      	leaq	-0xe(%r12,%rax), %rbp
   667ed:      	cmpq	$0x0, 0xf253(%rip)      # 0x75a48 <g.3>
   667f5:      	je	0x7085f <f.2+0x180af>
   667fb:      	cmpq	$0xe, %r12
   667ff:      	ja	0x6680b <f.2+0xe05b>
   66801:      	leaq	-0xd(%r12), %rdx
   66806:      	jmp	0x66942 <f.2+0xe192>
   6680b:      	cmpq	$0xf, %r12
   6680f:      	jne	0x66829 <f.2+0xe079>
   66811:      	movl	$0x1, %edx
   66816:      	cmpq	$0x0, 0xf22a(%rip)      # 0x75a48 <g.3>
   6681e:      	jne	0x668c0 <f.2+0xe110>
   66824:      	jmp	0x7085f <f.2+0x180af>
   66829:      	movq	%rcx, 0x10(%rsp)
   6682e:      	leaq	-0xf(%r12), %rsi
   66833:      	movq	$0x0, 0x48(%rsp)
   6683c:      	movq	$0x3, 0x30(%rsp)
   66845:      	xorl	%edi, %edi
   66847:      	callq	0x70870 <f.3>
   6684c:      	subq	$0x8, %rsp
   66850:      	cmpb	$0x0, 0xf1f9(%rip)      # 0x75a50 <g.4>
   66857:      	je	0x7085f <f.2+0x180af>
   6685d:      	movq	%rax, 0x18(%rsp)
   66862:      	cmpq	$0x0, 0xf1de(%rip)      # 0x75a48 <g.3>
   6686a:      	je	0x7085f <f.2+0x180af>
   66870:      	leaq	-0x10(%r12), %rsi
   66875:      	movq	$0x0, 0x48(%rsp)
   6687e:      	movq	$0x3, 0x30(%rsp)
   66887:      	xorl	%edi, %edi
   66889:      	callq	0x70870 <f.3>
   6688e:      	subq	$0x8, %rsp
   66892:      	cmpb	$0x0, 0xf1b7(%rip)      # 0x75a50 <g.4>
   66899:      	je	0x7085f <f.2+0x180af>
   6689f:      	cmpq	$0x0, 0xf1a1(%rip)      # 0x75a48 <g.3>
   668a7:      	movq	0x10(%rsp), %rcx
   668ac:      	je	0x7085f <f.2+0x180af>
   668b2:      	movq	%rax, %rdx
   668b5:      	addq	0x18(%rsp), %rdx
   668ba:      	cmpq	$0x10, %r12
   668be:      	ja	0x668c7 <f.2+0xe117>
   668c0:      	leaq	-0xf(%r12), %rax
   668c5:      	jmp	0x6693f <f.2+0xe18f>
   668c7:      	movq	%rdx, 0x18(%rsp)
   668cc:      	movq	$0x0, 0x48(%rsp)
   668d5:      	movq	$0x3, 0x30(%rsp)
   668de:      	xorl	%edi, %edi
   668e0:      	leaq	-0x10(%r12), %rsi
   668e5:      	callq	0x70870 <f.3>
   668ea:      	subq	$0x8, %rsp
   668ee:      	cmpb	$0x0, 0xf15b(%rip)      # 0x75a50 <g.4>
   668f5:      	je	0x7085f <f.2+0x180af>
   668fb:      	movq	%rax, 0x50(%rsp)
   66900:      	cmpq	$0x0, 0xf140(%rip)      # 0x75a48 <g.3>
   66908:      	je	0x7085f <f.2+0x180af>
   6690e:      	leaq	-0x11(%r12), %rsi
   66913:      	movq	$0x0, 0x48(%rsp)
   6691c:      	movq	$0x3, 0x30(%rsp)
   66925:      	xorl	%edi, %edi
   66927:      	callq	0x70870 <f.3>
   6692c:      	subq	$0x8, %rsp
   66930:      	addq	0x50(%rsp), %rax
   66935:      	movq	0x10(%rsp), %rcx
   6693a:      	movq	0x18(%rsp), %rdx
   6693f:      	addq	%rax, %rdx
   66942:      	addq	%rdx, %rbp
   66945:      	cmpb	$0x0, 0xf104(%rip)      # 0x75a50 <g.4>
   6694c:      	je	0x7085f <f.2+0x180af>
   66952:      	addq	%rcx, %rbp
   66955:      	addq	%r14, %rbp
   66958:      	cmpq	$0x0, 0xf0e8(%rip)      # 0x75a48 <g.3>
   66960:      	je	0x7085f <f.2+0x180af>
   66966:      	cmpq	$0x9, %r12
   6696a:      	ja	0x66983 <f.2+0xe1d3>
   6696c:      	leaq	-0x8(%r12), %r14
   66971:      	cmpb	$0x0, 0xf0d8(%rip)      # 0x75a50 <g.4>
   66978:      	jne	0x6753e <f.2+0xed8e>
   6697e:      	jmp	0x7085f <f.2+0x180af>
   66983:      	cmpq	$0xa, %r12
   66987:      	jne	0x669a2 <f.2+0xe1f2>
   66989:      	movl	$0x1, %r14d
   6698f:      	cmpq	$0x0, 0xf0b1(%rip)      # 0x75a48 <g.3>
   66997:      	jne	0x66f68 <f.2+0xe7b8>
   6699d:      	jmp	0x7085f <f.2+0x180af>
   669a2:      	cmpq	$0xc, %r12
   669a6:      	jb	0x669c2 <f.2+0xe212>
   669a8:      	jne	0x669da <f.2+0xe22a>
   669aa:      	movl	$0x1, %eax
   669af:      	cmpq	$0x0, 0xf091(%rip)      # 0x75a48 <g.3>
   669b7:      	jne	0x66b1d <f.2+0xe36d>
   669bd:      	jmp	0x7085f <f.2+0x180af>
   669c2:      	movl	$0x1, %ecx
   669c7:      	cmpq	$0x0, 0xf079(%rip)      # 0x75a48 <g.3>
   669cf:      	jne	0x66c83 <f.2+0xe4d3>
   669d5:      	jmp	0x7085f <f.2+0x180af>
   669da:      	cmpq	$0xe, %r12
   669de:      	jb	0x66af0 <f.2+0xe340>
   669e4:      	leaq	-0xd(%r12), %rsi
   669e9:      	movq	$0x0, 0x48(%rsp)
   669f2:      	movq	$0x3, 0x30(%rsp)
   669fb:      	xorl	%edi, %edi
   669fd:      	callq	0x70870 <f.3>
   66a02:      	subq	$0x8, %rsp
   66a06:      	cmpb	$0x0, 0xf043(%rip)      # 0x75a50 <g.4>
   66a0d:      	je	0x7085f <f.2+0x180af>
   66a13:      	movq	%rax, 0x10(%rsp)
   66a18:      	cmpq	$0x0, 0xf028(%rip)      # 0x75a48 <g.3>
   66a20:      	je	0x7085f <f.2+0x180af>
   66a26:      	leaq	-0xe(%r12), %rsi
   66a2b:      	movq	$0x0, 0x48(%rsp)
   66a34:      	movq	$0x3, 0x30(%rsp)
   66a3d:      	xorl	%edi, %edi
   66a3f:      	callq	0x70870 <f.3>
   66a44:      	subq	$0x8, %rsp
   66a48:      	cmpb	$0x0, 0xf001(%rip)      # 0x75a50 <g.4>
   66a4f:      	je	0x7085f <f.2+0x180af>
   66a55:      	cmpq	$0x0, 0xefeb(%rip)      # 0x75a48 <g.3>
   66a5d:      	je	0x7085f <f.2+0x180af>
   66a63:      	movq	%rax, %r14
   66a66:      	addq	0x10(%rsp), %r14
   66a6b:      	cmpq	$0xe, %r12
   66a6f:      	je	0x66b04 <f.2+0xe354>
   66a75:      	movq	$0x0, 0x48(%rsp)
   66a7e:      	movq	$0x3, 0x30(%rsp)
   66a87:      	xorl	%edi, %edi
   66a89:      	leaq	-0xe(%r12), %rsi
   66a8e:      	callq	0x70870 <f.3>
   66a93:      	subq	$0x8, %rsp
   66a97:      	cmpb	$0x0, 0xefb2(%rip)      # 0x75a50 <g.4>
   66a9e:      	je	0x7085f <f.2+0x180af>
   66aa4:      	movq	%rax, 0x10(%rsp)
   66aa9:      	cmpq	$0x0, 0xef97(%rip)      # 0x75a48 <g.3>
   66ab1:      	je	0x7085f <f.2+0x180af>
   66ab7:      	leaq	-0xf(%r12), %rsi
   66abc:      	movq	$0x0, 0x48(%rsp)
   66ac5:      	movq	$0x3, 0x30(%rsp)
   66ace:      	xorl	%edi, %edi
   66ad0:      	callq	0x70870 <f.3>
   66ad5:      	subq	$0x8, %rsp
   66ad9:      	cmpb	$0x0, 0xef70(%rip)      # 0x75a50 <g.4>
   66ae0:      	je	0x7085f <f.2+0x180af>
   66ae6:      	addq	0x10(%rsp), %rax
   66aeb:      	addq	%r14, %rax
   66aee:      	jmp	0x66b09 <f.2+0xe359>
   66af0:      	movl	$0x1, %r14d
   66af6:      	cmpq	$0x0, 0xef4a(%rip)      # 0x75a48 <g.3>
   66afe:      	je	0x7085f <f.2+0x180af>
   66b04:      	leaq	-0xd(%r12,%r14), %rax
   66b09:      	cmpq	$0x0, 0xef37(%rip)      # 0x75a48 <g.3>
   66b11:      	je	0x7085f <f.2+0x180af>
   66b17:      	cmpq	$0xd, %r12
   66b1b:      	ja	0x66b27 <f.2+0xe377>
   66b1d:      	leaq	-0xc(%r12,%rax), %rcx
   66b22:      	jmp	0x66c69 <f.2+0xe4b9>
   66b27:      	cmpq	$0xe, %r12
   66b2b:      	jne	0x66b45 <f.2+0xe395>
   66b2d:      	movl	$0x1, %edx
   66b32:      	cmpq	$0x0, 0xef0e(%rip)      # 0x75a48 <g.3>
   66b3a:      	jne	0x66bd8 <f.2+0xe428>
   66b40:      	jmp	0x7085f <f.2+0x180af>
   66b45:      	movq	%rax, 0x10(%rsp)
   66b4a:      	leaq	-0xe(%r12), %rsi
   66b4f:      	movq	$0x0, 0x48(%rsp)
   66b58:      	movq	$0x3, 0x30(%rsp)
   66b61:      	xorl	%edi, %edi
   66b63:      	callq	0x70870 <f.3>
   66b68:      	subq	$0x8, %rsp
   66b6c:      	cmpb	$0x0, 0xeedd(%rip)      # 0x75a50 <g.4>
   66b73:      	je	0x7085f <f.2+0x180af>
   66b79:      	cmpq	$0x0, 0xeec7(%rip)      # 0x75a48 <g.3>
   66b81:      	je	0x7085f <f.2+0x180af>
   66b87:      	movq	%rax, %r14
   66b8a:      	leaq	-0xf(%r12), %rsi
   66b8f:      	movq	$0x0, 0x48(%rsp)
   66b98:      	movq	$0x3, 0x30(%rsp)
   66ba1:      	xorl	%edi, %edi
   66ba3:      	callq	0x70870 <f.3>
   66ba8:      	subq	$0x8, %rsp
   66bac:      	cmpb	$0x0, 0xee9d(%rip)      # 0x75a50 <g.4>
   66bb3:      	je	0x7085f <f.2+0x180af>
   66bb9:      	movq	%rax, %rdx
   66bbc:      	cmpq	$0x0, 0xee84(%rip)      # 0x75a48 <g.3>
   66bc4:      	movq	0x10(%rsp), %rax
   66bc9:      	je	0x7085f <f.2+0x180af>
   66bcf:      	addq	%r14, %rdx
   66bd2:      	cmpq	$0xf, %r12
   66bd6:      	ja	0x66bdf <f.2+0xe42f>
   66bd8:      	leaq	-0xe(%r12), %rcx
   66bdd:      	jmp	0x66c56 <f.2+0xe4a6>
   66bdf:      	movq	%rdx, 0x18(%rsp)
   66be4:      	movq	$0x0, 0x48(%rsp)
   66bed:      	movq	$0x3, 0x30(%rsp)
   66bf6:      	xorl	%edi, %edi
   66bf8:      	leaq	-0xf(%r12), %rsi
   66bfd:      	callq	0x70870 <f.3>
   66c02:      	subq	$0x8, %rsp
   66c06:      	cmpb	$0x0, 0xee43(%rip)      # 0x75a50 <g.4>
   66c0d:      	je	0x7085f <f.2+0x180af>
   66c13:      	cmpq	$0x0, 0xee2d(%rip)      # 0x75a48 <g.3>
   66c1b:      	je	0x7085f <f.2+0x180af>
   66c21:      	movq	%rax, %r14
   66c24:      	leaq	-0x10(%r12), %rsi
   66c29:      	movq	$0x0, 0x48(%rsp)
   66c32:      	movq	$0x3, 0x30(%rsp)
   66c3b:      	xorl	%edi, %edi
   66c3d:      	callq	0x70870 <f.3>
   66c42:      	subq	$0x8, %rsp
   66c46:      	movq	%rax, %rcx
   66c49:      	addq	%r14, %rcx
   66c4c:      	movq	0x10(%rsp), %rax
   66c51:      	movq	0x18(%rsp), %rdx
   66c56:      	cmpb	$0x0, 0xedf3(%rip)      # 0x75a50 <g.4>
   66c5d:      	je	0x7085f <f.2+0x180af>
   66c63:      	addq	%rdx, %rcx
   66c66:      	addq	%rax, %rcx
   66c69:      	cmpq	$0x0, 0xedd7(%rip)      # 0x75a48 <g.3>
   66c71:      	je	0x7085f <f.2+0x180af>
   66c77:      	cmpq	$0xd, %r12
   66c7b:      	je	0x66c8d <f.2+0xe4dd>
   66c7d:      	cmpq	$0xc, %r12
   66c81:      	jne	0x66ca5 <f.2+0xe4f5>
   66c83:      	leaq	-0xb(%r12,%rcx), %r14
   66c88:      	jmp	0x66f54 <f.2+0xe7a4>
   66c8d:      	movl	$0x1, %edx
   66c92:      	cmpq	$0x0, 0xedae(%rip)      # 0x75a48 <g.3>
   66c9a:      	jne	0x66dfa <f.2+0xe64a>
   66ca0:      	jmp	0x7085f <f.2+0x180af>
   66ca5:      	cmpq	$0xf, %r12
   66ca9:      	jb	0x66dcd <f.2+0xe61d>
   66caf:      	movq	%rcx, 0x10(%rsp)
   66cb4:      	leaq	-0xe(%r12), %rsi
   66cb9:      	movq	$0x0, 0x48(%rsp)
   66cc2:      	movq	$0x3, 0x30(%rsp)
   66ccb:      	xorl	%edi, %edi
   66ccd:      	callq	0x70870 <f.3>
   66cd2:      	subq	$0x8, %rsp
   66cd6:      	cmpb	$0x0, 0xed73(%rip)      # 0x75a50 <g.4>
   66cdd:      	je	0x7085f <f.2+0x180af>
   66ce3:      	movq	%rax, 0x18(%rsp)
   66ce8:      	cmpq	$0x0, 0xed58(%rip)      # 0x75a48 <g.3>
   66cf0:      	je	0x7085f <f.2+0x180af>
   66cf6:      	leaq	-0xf(%r12), %rsi
   66cfb:      	movq	$0x0, 0x48(%rsp)
   66d04:      	movq	$0x3, 0x30(%rsp)
   66d0d:      	xorl	%edi, %edi
   66d0f:      	callq	0x70870 <f.3>
   66d14:      	subq	$0x8, %rsp
   66d18:      	cmpb	$0x0, 0xed31(%rip)      # 0x75a50 <g.4>
   66d1f:      	je	0x7085f <f.2+0x180af>
   66d25:      	cmpq	$0x0, 0xed1b(%rip)      # 0x75a48 <g.3>
   66d2d:      	movq	0x10(%rsp), %rcx
   66d32:      	je	0x7085f <f.2+0x180af>
   66d38:      	movq	%rax, %r14
   66d3b:      	addq	0x18(%rsp), %r14
   66d40:      	cmpq	$0xf, %r12
   66d44:      	je	0x66de1 <f.2+0xe631>
   66d4a:      	movq	$0x0, 0x48(%rsp)
   66d53:      	movq	$0x3, 0x30(%rsp)
   66d5c:      	xorl	%edi, %edi
   66d5e:      	leaq	-0xf(%r12), %rsi
   66d63:      	callq	0x70870 <f.3>
   66d68:      	subq	$0x8, %rsp
   66d6c:      	cmpb	$0x0, 0xecdd(%rip)      # 0x75a50 <g.4>
   66d73:      	je	0x7085f <f.2+0x180af>
   66d79:      	movq	%rax, 0x18(%rsp)
   66d7e:      	cmpq	$0x0, 0xecc2(%rip)      # 0x75a48 <g.3>
   66d86:      	je	0x7085f <f.2+0x180af>
   66d8c:      	leaq	-0x10(%r12), %rsi
   66d91:      	movq	$0x0, 0x48(%rsp)
   66d9a:      	movq	$0x3, 0x30(%rsp)
   66da3:      	xorl	%edi, %edi
   66da5:      	callq	0x70870 <f.3>
   66daa:      	subq	$0x8, %rsp
   66dae:      	cmpb	$0x0, 0xec9b(%rip)      # 0x75a50 <g.4>
   66db5:      	je	0x7085f <f.2+0x180af>
   66dbb:      	movq	%rax, %rdx
   66dbe:      	addq	0x18(%rsp), %rdx
   66dc3:      	addq	%r14, %rdx
   66dc6:      	movq	0x10(%rsp), %rcx
   66dcb:      	jmp	0x66de6 <f.2+0xe636>
   66dcd:      	movl	$0x1, %r14d
   66dd3:      	cmpq	$0x0, 0xec6d(%rip)      # 0x75a48 <g.3>
   66ddb:      	je	0x7085f <f.2+0x180af>
   66de1:      	leaq	-0xe(%r12,%r14), %rdx
   66de6:      	cmpq	$0x0, 0xec5a(%rip)      # 0x75a48 <g.3>
   66dee:      	je	0x7085f <f.2+0x180af>
   66df4:      	cmpq	$0xe, %r12
   66df8:      	ja	0x66e04 <f.2+0xe654>
   66dfa:      	leaq	-0xd(%r12), %r14
   66dff:      	jmp	0x66f41 <f.2+0xe791>
   66e04:      	cmpq	$0xf, %r12
   66e08:      	jne	0x66e23 <f.2+0xe673>
   66e0a:      	movl	$0x1, %r14d
   66e10:      	cmpq	$0x0, 0xec30(%rip)      # 0x75a48 <g.3>
   66e18:      	jne	0x66ec4 <f.2+0xe714>
   66e1e:      	jmp	0x7085f <f.2+0x180af>
   66e23:      	movq	%rdx, 0x18(%rsp)
   66e28:      	movq	%rcx, 0x10(%rsp)
   66e2d:      	leaq	-0xf(%r12), %rsi
   66e32:      	movq	$0x0, 0x48(%rsp)
   66e3b:      	movq	$0x3, 0x30(%rsp)
   66e44:      	xorl	%edi, %edi
   66e46:      	callq	0x70870 <f.3>
   66e4b:      	subq	$0x8, %rsp
   66e4f:      	cmpb	$0x0, 0xebfa(%rip)      # 0x75a50 <g.4>
   66e56:      	je	0x7085f <f.2+0x180af>
   66e5c:      	movq	%rax, 0x50(%rsp)
   66e61:      	cmpq	$0x0, 0xebdf(%rip)      # 0x75a48 <g.3>
   66e69:      	je	0x7085f <f.2+0x180af>
   66e6f:      	leaq	-0x10(%r12), %rsi
   66e74:      	movq	$0x0, 0x48(%rsp)
   66e7d:      	movq	$0x3, 0x30(%rsp)
   66e86:      	xorl	%edi, %edi
   66e88:      	callq	0x70870 <f.3>
   66e8d:      	subq	$0x8, %rsp
   66e91:      	cmpb	$0x0, 0xebb8(%rip)      # 0x75a50 <g.4>
   66e98:      	je	0x7085f <f.2+0x180af>
   66e9e:      	cmpq	$0x0, 0xeba2(%rip)      # 0x75a48 <g.3>
   66ea6:      	movq	0x10(%rsp), %rcx
   66eab:      	movq	0x18(%rsp), %rdx
   66eb0:      	je	0x7085f <f.2+0x180af>
   66eb6:      	movq	%rax, %r14
   66eb9:      	addq	0x50(%rsp), %r14
   66ebe:      	cmpq	$0x10, %r12
   66ec2:      	ja	0x66ecb <f.2+0xe71b>
   66ec4:      	leaq	-0xf(%r12), %rax
   66ec9:      	jmp	0x66f3e <f.2+0xe78e>
   66ecb:      	movq	$0x0, 0x48(%rsp)
   66ed4:      	movq	$0x3, 0x30(%rsp)
   66edd:      	xorl	%edi, %edi
   66edf:      	leaq	-0x10(%r12), %rsi
   66ee4:      	callq	0x70870 <f.3>
   66ee9:      	subq	$0x8, %rsp
   66eed:      	cmpb	$0x0, 0xeb5c(%rip)      # 0x75a50 <g.4>
   66ef4:      	je	0x7085f <f.2+0x180af>
   66efa:      	movq	%rax, 0x50(%rsp)
   66eff:      	cmpq	$0x0, 0xeb41(%rip)      # 0x75a48 <g.3>
   66f07:      	je	0x7085f <f.2+0x180af>
   66f0d:      	leaq	-0x11(%r12), %rsi
   66f12:      	movq	$0x0, 0x48(%rsp)
   66f1b:      	movq	$0x3, 0x30(%rsp)
   66f24:      	xorl	%edi, %edi
   66f26:      	callq	0x70870 <f.3>
   66f2b:      	subq	$0x8, %rsp
   66f2f:      	addq	0x50(%rsp), %rax
   66f34:      	movq	0x10(%rsp), %rcx
   66f39:      	movq	0x18(%rsp), %rdx
   66f3e:      	addq	%rax, %r14
   66f41:      	cmpb	$0x0, 0xeb08(%rip)      # 0x75a50 <g.4>
   66f48:      	je	0x7085f <f.2+0x180af>
   66f4e:      	addq	%rdx, %r14
   66f51:      	addq	%rcx, %r14
   66f54:      	cmpq	$0x0, 0xeaec(%rip)      # 0x75a48 <g.3>
   66f5c:      	je	0x7085f <f.2+0x180af>
   66f62:      	cmpq	$0xb, %r12
   66f66:      	ja	0x66f72 <f.2+0xe7c2>
   66f68:      	leaq	-0xa(%r12), %rcx
   66f6d:      	jmp	0x6752e <f.2+0xed7e>
   66f72:      	cmpq	$0xc, %r12
   66f76:      	jne	0x66f90 <f.2+0xe7e0>
   66f78:      	movl	$0x1, %ecx
   66f7d:      	cmpq	$0x0, 0xeac3(%rip)      # 0x75a48 <g.3>
   66f85:      	jne	0x67258 <f.2+0xeaa8>
   66f8b:      	jmp	0x7085f <f.2+0x180af>
   66f90:      	cmpq	$0xe, %r12
   66f94:      	jb	0x66fb0 <f.2+0xe800>
   66f96:      	jne	0x66fc8 <f.2+0xe818>
   66f98:      	movl	$0x1, %eax
   66f9d:      	cmpq	$0x0, 0xeaa3(%rip)      # 0x75a48 <g.3>
   66fa5:      	jne	0x67052 <f.2+0xe8a2>
   66fab:      	jmp	0x7085f <f.2+0x180af>
   66fb0:      	movl	$0x1, %eax
   66fb5:      	cmpq	$0x0, 0xea8b(%rip)      # 0x75a48 <g.3>
   66fbd:      	jne	0x670f6 <f.2+0xe946>
   66fc3:      	jmp	0x7085f <f.2+0x180af>
   66fc8:      	leaq	-0xe(%r12), %rsi
   66fcd:      	movq	$0x0, 0x48(%rsp)
   66fd6:      	movq	$0x3, 0x30(%rsp)
   66fdf:      	xorl	%edi, %edi
   66fe1:      	callq	0x70870 <f.3>
   66fe6:      	subq	$0x8, %rsp
   66fea:      	cmpb	$0x0, 0xea5f(%rip)      # 0x75a50 <g.4>
   66ff1:      	je	0x7085f <f.2+0x180af>
   66ff7:      	movq	%rax, 0x10(%rsp)
   66ffc:      	cmpq	$0x0, 0xea44(%rip)      # 0x75a48 <g.3>
   67004:      	je	0x7085f <f.2+0x180af>
   6700a:      	leaq	-0xf(%r12), %rsi
   6700f:      	movq	$0x0, 0x48(%rsp)
   67018:      	movq	$0x3, 0x30(%rsp)
   67021:      	xorl	%edi, %edi
   67023:      	callq	0x70870 <f.3>
   67028:      	subq	$0x8, %rsp
   6702c:      	cmpb	$0x0, 0xea1d(%rip)      # 0x75a50 <g.4>
   67033:      	je	0x7085f <f.2+0x180af>
   67039:      	cmpq	$0x0, 0xea07(%rip)      # 0x75a48 <g.3>
   67041:      	je	0x7085f <f.2+0x180af>
   67047:      	addq	0x10(%rsp), %rax
   6704c:      	cmpq	$0xf, %r12
   67050:      	ja	0x6705c <f.2+0xe8ac>
   67052:      	leaq	-0xe(%r12,%rax), %rax
   67057:      	jmp	0x670dc <f.2+0xe92c>
   6705c:      	movq	%rax, 0x10(%rsp)
   67061:      	movq	$0x0, 0x48(%rsp)
   6706a:      	movq	$0x3, 0x30(%rsp)
   67073:      	xorl	%edi, %edi
   67075:      	leaq	-0xf(%r12), %rsi
   6707a:      	callq	0x70870 <f.3>
   6707f:      	subq	$0x8, %rsp
   67083:      	cmpb	$0x0, 0xe9c6(%rip)      # 0x75a50 <g.4>
   6708a:      	je	0x7085f <f.2+0x180af>
   67090:      	movq	%rax, 0x18(%rsp)
   67095:      	cmpq	$0x0, 0xe9ab(%rip)      # 0x75a48 <g.3>
   6709d:      	je	0x7085f <f.2+0x180af>
   670a3:      	leaq	-0x10(%r12), %rsi
   670a8:      	movq	$0x0, 0x48(%rsp)
   670b1:      	movq	$0x3, 0x30(%rsp)
   670ba:      	xorl	%edi, %edi
   670bc:      	callq	0x70870 <f.3>
   670c1:      	subq	$0x8, %rsp
   670c5:      	cmpb	$0x0, 0xe984(%rip)      # 0x75a50 <g.4>
   670cc:      	je	0x7085f <f.2+0x180af>
   670d2:      	addq	0x18(%rsp), %rax
   670d7:      	addq	0x10(%rsp), %rax
   670dc:      	cmpq	$0x0, 0xe964(%rip)      # 0x75a48 <g.3>
   670e4:      	je	0x7085f <f.2+0x180af>
   670ea:      	cmpq	$0xf, %r12
   670ee:      	je	0x67100 <f.2+0xe950>
   670f0:      	cmpq	$0xe, %r12
   670f4:      	jne	0x67118 <f.2+0xe968>
   670f6:      	leaq	-0xd(%r12,%rax), %rcx
   670fb:      	jmp	0x67244 <f.2+0xea94>
   67100:      	movl	$0x1, %edx
   67105:      	cmpq	$0x0, 0xe93b(%rip)      # 0x75a48 <g.3>
   6710d:      	jne	0x671af <f.2+0xe9ff>
   67113:      	jmp	0x7085f <f.2+0x180af>
   67118:      	movq	%rax, 0x10(%rsp)
   6711d:      	leaq	-0xf(%r12), %rsi
   67122:      	movq	$0x0, 0x48(%rsp)
   6712b:      	movq	$0x3, 0x30(%rsp)
   67134:      	xorl	%edi, %edi
   67136:      	callq	0x70870 <f.3>
   6713b:      	subq	$0x8, %rsp
   6713f:      	cmpb	$0x0, 0xe90a(%rip)      # 0x75a50 <g.4>
   67146:      	je	0x7085f <f.2+0x180af>
   6714c:      	movq	%rax, 0x18(%rsp)
   67151:      	cmpq	$0x0, 0xe8ef(%rip)      # 0x75a48 <g.3>
   67159:      	je	0x7085f <f.2+0x180af>
   6715f:      	leaq	-0x10(%r12), %rsi
   67164:      	movq	$0x0, 0x48(%rsp)
   6716d:      	movq	$0x3, 0x30(%rsp)
   67176:      	xorl	%edi, %edi
   67178:      	callq	0x70870 <f.3>
   6717d:      	subq	$0x8, %rsp
   67181:      	cmpb	$0x0, 0xe8c8(%rip)      # 0x75a50 <g.4>
   67188:      	je	0x7085f <f.2+0x180af>
   6718e:      	movq	%rax, %rdx
   67191:      	cmpq	$0x0, 0xe8af(%rip)      # 0x75a48 <g.3>
   67199:      	movq	0x10(%rsp), %rax
   6719e:      	je	0x7085f <f.2+0x180af>
   671a4:      	addq	0x18(%rsp), %rdx
   671a9:      	cmpq	$0x10, %r12
   671ad:      	ja	0x671b6 <f.2+0xea06>
   671af:      	leaq	-0xf(%r12), %rcx
   671b4:      	jmp	0x67231 <f.2+0xea81>
   671b6:      	movq	%rdx, 0x18(%rsp)
   671bb:      	movq	$0x0, 0x48(%rsp)
   671c4:      	movq	$0x3, 0x30(%rsp)
   671cd:      	xorl	%edi, %edi
   671cf:      	leaq	-0x10(%r12), %rsi
   671d4:      	callq	0x70870 <f.3>
   671d9:      	subq	$0x8, %rsp
   671dd:      	cmpb	$0x0, 0xe86c(%rip)      # 0x75a50 <g.4>
   671e4:      	je	0x7085f <f.2+0x180af>
   671ea:      	movq	%rax, 0x50(%rsp)
   671ef:      	cmpq	$0x0, 0xe851(%rip)      # 0x75a48 <g.3>
   671f7:      	je	0x7085f <f.2+0x180af>
   671fd:      	leaq	-0x11(%r12), %rsi
   67202:      	movq	$0x0, 0x48(%rsp)
   6720b:      	movq	$0x3, 0x30(%rsp)
   67214:      	xorl	%edi, %edi
   67216:      	callq	0x70870 <f.3>
   6721b:      	subq	$0x8, %rsp
   6721f:      	movq	%rax, %rcx
   67222:      	addq	0x50(%rsp), %rcx
   67227:      	movq	0x10(%rsp), %rax
   6722c:      	movq	0x18(%rsp), %rdx
   67231:      	cmpb	$0x0, 0xe818(%rip)      # 0x75a50 <g.4>
   67238:      	je	0x7085f <f.2+0x180af>
   6723e:      	addq	%rdx, %rcx
   67241:      	addq	%rax, %rcx
   67244:      	cmpq	$0x0, 0xe7fc(%rip)      # 0x75a48 <g.3>
   6724c:      	je	0x7085f <f.2+0x180af>
   67252:      	cmpq	$0xd, %r12
   67256:      	ja	0x67262 <f.2+0xeab2>
   67258:      	leaq	-0xc(%r12), %rdx
   6725d:      	jmp	0x6752b <f.2+0xed7b>
   67262:      	cmpq	$0xe, %r12
   67266:      	jne	0x67280 <f.2+0xead0>
   67268:      	movl	$0x1, %edx
   6726d:      	cmpq	$0x0, 0xe7d3(%rip)      # 0x75a48 <g.3>
   67275:      	jne	0x673d8 <f.2+0xec28>
   6727b:      	jmp	0x7085f <f.2+0x180af>
   67280:      	cmpq	$0x10, %r12
   67284:      	jb	0x673ac <f.2+0xebfc>
   6728a:      	movq	%rcx, 0x10(%rsp)
   6728f:      	leaq	-0xf(%r12), %rsi
   67294:      	movq	$0x0, 0x48(%rsp)
   6729d:      	movq	$0x3, 0x30(%rsp)
   672a6:      	xorl	%edi, %edi
   672a8:      	callq	0x70870 <f.3>
   672ad:      	subq	$0x8, %rsp
   672b1:      	cmpb	$0x0, 0xe798(%rip)      # 0x75a50 <g.4>
   672b8:      	je	0x7085f <f.2+0x180af>
   672be:      	movq	%rax, 0x18(%rsp)
   672c3:      	cmpq	$0x0, 0xe77d(%rip)      # 0x75a48 <g.3>
   672cb:      	je	0x7085f <f.2+0x180af>
   672d1:      	leaq	-0x10(%r12), %rsi
   672d6:      	movq	$0x0, 0x48(%rsp)
   672df:      	movq	$0x3, 0x30(%rsp)
   672e8:      	xorl	%edi, %edi
   672ea:      	callq	0x70870 <f.3>
   672ef:      	subq	$0x8, %rsp
   672f3:      	cmpb	$0x0, 0xe756(%rip)      # 0x75a50 <g.4>
   672fa:      	je	0x7085f <f.2+0x180af>
   67300:      	cmpq	$0x0, 0xe740(%rip)      # 0x75a48 <g.3>
   67308:      	movq	0x10(%rsp), %rcx
   6730d:      	je	0x7085f <f.2+0x180af>
   67313:      	addq	0x18(%rsp), %rax
   67318:      	cmpq	$0x10, %r12
   6731c:      	je	0x673bf <f.2+0xec0f>
   67322:      	movq	%rax, 0x18(%rsp)
   67327:      	movq	$0x0, 0x48(%rsp)
   67330:      	movq	$0x3, 0x30(%rsp)
   67339:      	xorl	%edi, %edi
   6733b:      	leaq	-0x10(%r12), %rsi
   67340:      	callq	0x70870 <f.3>
   67345:      	subq	$0x8, %rsp
   67349:      	cmpb	$0x0, 0xe700(%rip)      # 0x75a50 <g.4>
   67350:      	je	0x7085f <f.2+0x180af>
   67356:      	movq	%rax, 0x50(%rsp)
   6735b:      	cmpq	$0x0, 0xe6e5(%rip)      # 0x75a48 <g.3>
   67363:      	je	0x7085f <f.2+0x180af>
   67369:      	leaq	-0x11(%r12), %rsi
   6736e:      	movq	$0x0, 0x48(%rsp)
   67377:      	movq	$0x3, 0x30(%rsp)
   67380:      	xorl	%edi, %edi
   67382:      	callq	0x70870 <f.3>
   67387:      	subq	$0x8, %rsp
   6738b:      	cmpb	$0x0, 0xe6be(%rip)      # 0x75a50 <g.4>
   67392:      	je	0x7085f <f.2+0x180af>
   67398:      	movq	%rax, %rdx
   6739b:      	addq	0x50(%rsp), %rdx
   673a0:      	addq	0x18(%rsp), %rdx
   673a5:      	movq	0x10(%rsp), %rcx
   673aa:      	jmp	0x673c4 <f.2+0xec14>
   673ac:      	movl	$0x1, %eax
   673b1:      	cmpq	$0x0, 0xe68f(%rip)      # 0x75a48 <g.3>
   673b9:      	je	0x7085f <f.2+0x180af>
   673bf:      	leaq	-0xf(%r12,%rax), %rdx
   673c4:      	cmpq	$0x0, 0xe67c(%rip)      # 0x75a48 <g.3>
   673cc:      	je	0x7085f <f.2+0x180af>
   673d2:      	cmpq	$0xf, %r12
   673d6:      	ja	0x673e2 <f.2+0xec32>
   673d8:      	leaq	-0xe(%r12), %rsi
   673dd:      	jmp	0x67528 <f.2+0xed78>
   673e2:      	cmpq	$0x10, %r12
   673e6:      	jne	0x67400 <f.2+0xec50>
   673e8:      	movl	$0x1, %esi
   673ed:      	cmpq	$0x0, 0xe653(%rip)      # 0x75a48 <g.3>
   673f5:      	jne	0x674a1 <f.2+0xecf1>
   673fb:      	jmp	0x7085f <f.2+0x180af>
   67400:      	movq	%rdx, 0x18(%rsp)
   67405:      	movq	%rcx, 0x10(%rsp)
   6740a:      	leaq	-0x10(%r12), %rsi
   6740f:      	movq	$0x0, 0x48(%rsp)
   67418:      	movq	$0x3, 0x30(%rsp)
   67421:      	xorl	%edi, %edi
   67423:      	callq	0x70870 <f.3>
   67428:      	subq	$0x8, %rsp
   6742c:      	cmpb	$0x0, 0xe61d(%rip)      # 0x75a50 <g.4>
   67433:      	je	0x7085f <f.2+0x180af>
   67439:      	movq	%rax, 0x50(%rsp)
   6743e:      	cmpq	$0x0, 0xe602(%rip)      # 0x75a48 <g.3>
   67446:      	je	0x7085f <f.2+0x180af>
   6744c:      	leaq	-0x11(%r12), %rsi
   67451:      	movq	$0x0, 0x48(%rsp)
   6745a:      	movq	$0x3, 0x30(%rsp)
   67463:      	xorl	%edi, %edi
   67465:      	callq	0x70870 <f.3>
   6746a:      	subq	$0x8, %rsp
   6746e:      	cmpb	$0x0, 0xe5db(%rip)      # 0x75a50 <g.4>
   67475:      	je	0x7085f <f.2+0x180af>
   6747b:      	cmpq	$0x0, 0xe5c5(%rip)      # 0x75a48 <g.3>
   67483:      	movq	0x10(%rsp), %rcx
   67488:      	movq	0x18(%rsp), %rdx
   6748d:      	je	0x7085f <f.2+0x180af>
   67493:      	movq	%rax, %rsi
   67496:      	addq	0x50(%rsp), %rsi
   6749b:      	cmpq	$0x11, %r12
   6749f:      	ja	0x674a8 <f.2+0xecf8>
   674a1:      	leaq	-0x10(%r12), %rax
   674a6:      	jmp	0x67525 <f.2+0xed75>
   674a8:      	movq	%rsi, 0x50(%rsp)
   674ad:      	movq	$0x0, 0x48(%rsp)
   674b6:      	movq	$0x3, 0x30(%rsp)
   674bf:      	xorl	%edi, %edi
   674c1:      	leaq	-0x11(%r12), %rsi
   674c6:      	callq	0x70870 <f.3>
   674cb:      	subq	$0x8, %rsp
   674cf:      	movq	%rax, 0x58(%rsp)
   674d4:      	cmpb	$0x0, 0xe575(%rip)      # 0x75a50 <g.4>
   674db:      	je	0x7085f <f.2+0x180af>
   674e1:      	cmpq	$0x0, 0xe55f(%rip)      # 0x75a48 <g.3>
   674e9:      	je	0x7085f <f.2+0x180af>
   674ef:      	leaq	-0x12(%r12), %rsi
   674f4:      	movq	$0x0, 0x48(%rsp)
   674fd:      	movq	$0x3, 0x30(%rsp)
   67506:      	xorl	%edi, %edi
   67508:      	callq	0x70870 <f.3>
   6750d:      	subq	$0x8, %rsp
   67511:      	addq	0x58(%rsp), %rax
   67516:      	movq	0x10(%rsp), %rcx
   6751b:      	movq	0x18(%rsp), %rdx
   67520:      	movq	0x50(%rsp), %rsi
   67525:      	addq	%rax, %rsi
   67528:      	addq	%rsi, %rdx
   6752b:      	addq	%rdx, %rcx
   6752e:      	addq	%rcx, %r14
   67531:      	cmpb	$0x0, 0xe518(%rip)      # 0x75a50 <g.4>
   67538:      	je	0x7085f <f.2+0x180af>
   6753e:      	addq	%rbp, %r14
   67541:      	addq	%r15, %r14
   67544:      	cmpq	$0x0, 0xe4fc(%rip)      # 0x75a48 <g.3>
   6754c:      	leaq	0x68(%rsp), %r15
   67551:      	je	0x7085f <f.2+0x180af>
   67557:      	cmpq	$0x7, %r12
   6755b:      	je	0x6757b <f.2+0xedcb>
   6755d:      	cmpq	$0x6, %r12
   67561:      	jne	0x67594 <f.2+0xede4>
   67563:      	leaq	-0x5(%r12,%r14), %rbp
   67568:      	cmpq	$0x0, 0xe4d8(%rip)      # 0x75a48 <g.3>
   67570:      	jne	0x68d6c <f.2+0x105bc>
   67576:      	jmp	0x7085f <f.2+0x180af>
   6757b:      	movl	$0x1, %r15d
   67581:      	cmpq	$0x0, 0xe4bf(%rip)      # 0x75a48 <g.3>
   67589:      	jne	0x68d41 <f.2+0x10591>
   6758f:      	jmp	0x7085f <f.2+0x180af>
   67594:      	cmpq	$0x9, %r12
   67598:      	jb	0x675b5 <f.2+0xee05>
   6759a:      	jne	0x675cd <f.2+0xee1d>
   6759c:      	movl	$0x1, %r15d
   675a2:      	cmpq	$0x0, 0xe49e(%rip)      # 0x75a48 <g.3>
   675aa:      	jne	0x67b66 <f.2+0xf3b6>
   675b0:      	jmp	0x7085f <f.2+0x180af>
   675b5:      	movl	$0x1, %ebp
   675ba:      	cmpq	$0x0, 0xe486(%rip)      # 0x75a48 <g.3>
   675c2:      	jne	0x68142 <f.2+0xf992>
   675c8:      	jmp	0x7085f <f.2+0x180af>
   675cd:      	cmpq	$0xb, %r12
   675d1:      	jb	0x675ee <f.2+0xee3e>
   675d3:      	jne	0x67606 <f.2+0xee56>
   675d5:      	movl	$0x1, %r15d
   675db:      	cmpq	$0x0, 0xe465(%rip)      # 0x75a48 <g.3>
   675e3:      	jne	0x67747 <f.2+0xef97>
   675e9:      	jmp	0x7085f <f.2+0x180af>
   675ee:      	movl	$0x1, %ebp
   675f3:      	cmpq	$0x0, 0xe44d(%rip)      # 0x75a48 <g.3>
   675fb:      	jne	0x6789f <f.2+0xf0ef>
   67601:      	jmp	0x7085f <f.2+0x180af>
   67606:      	cmpq	$0xd, %r12
   6760a:      	jb	0x6771b <f.2+0xef6b>
   67610:      	leaq	-0xc(%r12), %rsi
   67615:      	movq	$0x0, 0x48(%rsp)
   6761e:      	movq	$0x3, 0x30(%rsp)
   67627:      	xorl	%edi, %edi
   67629:      	callq	0x70870 <f.3>
   6762e:      	subq	$0x8, %rsp
   67632:      	cmpb	$0x0, 0xe417(%rip)      # 0x75a50 <g.4>
   67639:      	je	0x7085f <f.2+0x180af>
   6763f:      	cmpq	$0x0, 0xe401(%rip)      # 0x75a48 <g.3>
   67647:      	je	0x7085f <f.2+0x180af>
   6764d:      	movq	%rax, %r15
   67650:      	leaq	-0xd(%r12), %rsi
   67655:      	movq	$0x0, 0x48(%rsp)
   6765e:      	movq	$0x3, 0x30(%rsp)
   67667:      	xorl	%edi, %edi
   67669:      	callq	0x70870 <f.3>
   6766e:      	subq	$0x8, %rsp
   67672:      	cmpb	$0x0, 0xe3d7(%rip)      # 0x75a50 <g.4>
   67679:      	je	0x7085f <f.2+0x180af>
   6767f:      	cmpq	$0x0, 0xe3c1(%rip)      # 0x75a48 <g.3>
   67687:      	je	0x7085f <f.2+0x180af>
   6768d:      	movq	%rax, %rbp
   67690:      	addq	%r15, %rbp
   67693:      	cmpq	$0xd, %r12
   67697:      	je	0x6772e <f.2+0xef7e>
   6769d:      	movq	$0x0, 0x48(%rsp)
   676a6:      	movq	$0x3, 0x30(%rsp)
   676af:      	xorl	%edi, %edi
   676b1:      	leaq	-0xd(%r12), %rsi
   676b6:      	callq	0x70870 <f.3>
   676bb:      	subq	$0x8, %rsp
   676bf:      	cmpb	$0x0, 0xe38a(%rip)      # 0x75a50 <g.4>
   676c6:      	je	0x7085f <f.2+0x180af>
   676cc:      	movq	%rax, 0x10(%rsp)
   676d1:      	cmpq	$0x0, 0xe36f(%rip)      # 0x75a48 <g.3>
   676d9:      	je	0x7085f <f.2+0x180af>
   676df:      	leaq	-0xe(%r12), %rsi
   676e4:      	movq	$0x0, 0x48(%rsp)
   676ed:      	movq	$0x3, 0x30(%rsp)
   676f6:      	xorl	%edi, %edi
   676f8:      	callq	0x70870 <f.3>
   676fd:      	subq	$0x8, %rsp
   67701:      	cmpb	$0x0, 0xe348(%rip)      # 0x75a50 <g.4>
   67708:      	je	0x7085f <f.2+0x180af>
   6770e:      	movq	%rax, %r15
   67711:      	addq	0x10(%rsp), %r15
   67716:      	addq	%rbp, %r15
   67719:      	jmp	0x67733 <f.2+0xef83>
   6771b:      	movl	$0x1, %ebp
   67720:      	cmpq	$0x0, 0xe320(%rip)      # 0x75a48 <g.3>
   67728:      	je	0x7085f <f.2+0x180af>
   6772e:      	leaq	-0xc(%r12,%rbp), %r15
   67733:      	cmpq	$0x0, 0xe30d(%rip)      # 0x75a48 <g.3>
   6773b:      	je	0x7085f <f.2+0x180af>
   67741:      	cmpq	$0xc, %r12
   67745:      	ja	0x67751 <f.2+0xefa1>
   67747:      	leaq	-0xb(%r12,%r15), %rbp
   6774c:      	jmp	0x67885 <f.2+0xf0d5>
   67751:      	cmpq	$0xd, %r12
   67755:      	jne	0x6776f <f.2+0xefbf>
   67757:      	movl	$0x1, %eax
   6775c:      	cmpq	$0x0, 0xe2e4(%rip)      # 0x75a48 <g.3>
   67764:      	jne	0x677f5 <f.2+0xf045>
   6776a:      	jmp	0x7085f <f.2+0x180af>
   6776f:      	leaq	-0xd(%r12), %rsi
   67774:      	movq	$0x0, 0x48(%rsp)
   6777d:      	movq	$0x3, 0x30(%rsp)
   67786:      	xorl	%edi, %edi
   67788:      	callq	0x70870 <f.3>
   6778d:      	subq	$0x8, %rsp
   67791:      	cmpb	$0x0, 0xe2b8(%rip)      # 0x75a50 <g.4>
   67798:      	je	0x7085f <f.2+0x180af>
   6779e:      	cmpq	$0x0, 0xe2a2(%rip)      # 0x75a48 <g.3>
   677a6:      	je	0x7085f <f.2+0x180af>
   677ac:      	movq	%rax, %rbp
   677af:      	leaq	-0xe(%r12), %rsi
   677b4:      	movq	$0x0, 0x48(%rsp)
   677bd:      	movq	$0x3, 0x30(%rsp)
   677c6:      	xorl	%edi, %edi
   677c8:      	callq	0x70870 <f.3>
   677cd:      	subq	$0x8, %rsp
   677d1:      	cmpb	$0x0, 0xe278(%rip)      # 0x75a50 <g.4>
   677d8:      	je	0x7085f <f.2+0x180af>
   677de:      	cmpq	$0x0, 0xe262(%rip)      # 0x75a48 <g.3>
   677e6:      	je	0x7085f <f.2+0x180af>
   677ec:      	addq	%rbp, %rax
   677ef:      	cmpq	$0xe, %r12
   677f3:      	ja	0x677fc <f.2+0xf04c>
   677f5:      	leaq	-0xd(%r12), %rbp
   677fa:      	jmp	0x67872 <f.2+0xf0c2>
   677fc:      	movq	%rax, 0x10(%rsp)
   67801:      	movq	$0x0, 0x48(%rsp)
   6780a:      	movq	$0x3, 0x30(%rsp)
   67813:      	xorl	%edi, %edi
   67815:      	leaq	-0xe(%r12), %rsi
   6781a:      	callq	0x70870 <f.3>
   6781f:      	subq	$0x8, %rsp
   67823:      	cmpb	$0x0, 0xe226(%rip)      # 0x75a50 <g.4>
   6782a:      	je	0x7085f <f.2+0x180af>
   67830:      	movq	%rax, 0x18(%rsp)
   67835:      	cmpq	$0x0, 0xe20b(%rip)      # 0x75a48 <g.3>
   6783d:      	je	0x7085f <f.2+0x180af>
   67843:      	leaq	-0xf(%r12), %rsi
   67848:      	movq	$0x0, 0x48(%rsp)
   67851:      	movq	$0x3, 0x30(%rsp)
   6785a:      	xorl	%edi, %edi
   6785c:      	callq	0x70870 <f.3>
   67861:      	subq	$0x8, %rsp
   67865:      	movq	%rax, %rbp
   67868:      	addq	0x18(%rsp), %rbp
   6786d:      	movq	0x10(%rsp), %rax
   67872:      	cmpb	$0x0, 0xe1d7(%rip)      # 0x75a50 <g.4>
   67879:      	je	0x7085f <f.2+0x180af>
   6787f:      	addq	%rax, %rbp
   67882:      	addq	%r15, %rbp
   67885:      	cmpq	$0x0, 0xe1bb(%rip)      # 0x75a48 <g.3>
   6788d:      	je	0x7085f <f.2+0x180af>
   67893:      	cmpq	$0xc, %r12
   67897:      	je	0x678a9 <f.2+0xf0f9>
   67899:      	cmpq	$0xb, %r12
   6789d:      	jne	0x678c1 <f.2+0xf111>
   6789f:      	leaq	-0xa(%r12,%rbp), %r15
   678a4:      	jmp	0x67b52 <f.2+0xf3a2>
   678a9:      	movl	$0x1, %ecx
   678ae:      	cmpq	$0x0, 0xe192(%rip)      # 0x75a48 <g.3>
   678b6:      	jne	0x67a07 <f.2+0xf257>
   678bc:      	jmp	0x7085f <f.2+0x180af>
   678c1:      	cmpq	$0xe, %r12
   678c5:      	jb	0x679da <f.2+0xf22a>
   678cb:      	leaq	-0xd(%r12), %rsi
   678d0:      	movq	$0x0, 0x48(%rsp)
   678d9:      	movq	$0x3, 0x30(%rsp)
   678e2:      	xorl	%edi, %edi
   678e4:      	callq	0x70870 <f.3>
   678e9:      	subq	$0x8, %rsp
   678ed:      	cmpb	$0x0, 0xe15c(%rip)      # 0x75a50 <g.4>
   678f4:      	je	0x7085f <f.2+0x180af>
   678fa:      	movq	%rax, 0x10(%rsp)
   678ff:      	cmpq	$0x0, 0xe141(%rip)      # 0x75a48 <g.3>
   67907:      	je	0x7085f <f.2+0x180af>
   6790d:      	leaq	-0xe(%r12), %rsi
   67912:      	movq	$0x0, 0x48(%rsp)
   6791b:      	movq	$0x3, 0x30(%rsp)
   67924:      	xorl	%edi, %edi
   67926:      	callq	0x70870 <f.3>
   6792b:      	subq	$0x8, %rsp
   6792f:      	cmpb	$0x0, 0xe11a(%rip)      # 0x75a50 <g.4>
   67936:      	je	0x7085f <f.2+0x180af>
   6793c:      	cmpq	$0x0, 0xe104(%rip)      # 0x75a48 <g.3>
   67944:      	je	0x7085f <f.2+0x180af>
   6794a:      	movq	%rax, %r15
   6794d:      	addq	0x10(%rsp), %r15
   67952:      	cmpq	$0xe, %r12
   67956:      	je	0x679ee <f.2+0xf23e>
   6795c:      	movq	$0x0, 0x48(%rsp)
   67965:      	movq	$0x3, 0x30(%rsp)
   6796e:      	xorl	%edi, %edi
   67970:      	leaq	-0xe(%r12), %rsi
   67975:      	callq	0x70870 <f.3>
   6797a:      	subq	$0x8, %rsp
   6797e:      	cmpb	$0x0, 0xe0cb(%rip)      # 0x75a50 <g.4>
   67985:      	je	0x7085f <f.2+0x180af>
   6798b:      	movq	%rax, 0x10(%rsp)
   67990:      	cmpq	$0x0, 0xe0b0(%rip)      # 0x75a48 <g.3>
   67998:      	je	0x7085f <f.2+0x180af>
   6799e:      	leaq	-0xf(%r12), %rsi
   679a3:      	movq	$0x0, 0x48(%rsp)
   679ac:      	movq	$0x3, 0x30(%rsp)
   679b5:      	xorl	%edi, %edi
   679b7:      	callq	0x70870 <f.3>
   679bc:      	subq	$0x8, %rsp
   679c0:      	cmpb	$0x0, 0xe089(%rip)      # 0x75a50 <g.4>
   679c7:      	je	0x7085f <f.2+0x180af>
   679cd:      	movq	%rax, %rcx
   679d0:      	addq	0x10(%rsp), %rcx
   679d5:      	addq	%r15, %rcx
   679d8:      	jmp	0x679f3 <f.2+0xf243>
   679da:      	movl	$0x1, %r15d
   679e0:      	cmpq	$0x0, 0xe060(%rip)      # 0x75a48 <g.3>
   679e8:      	je	0x7085f <f.2+0x180af>
   679ee:      	leaq	-0xd(%r12,%r15), %rcx
   679f3:      	cmpq	$0x0, 0xe04d(%rip)      # 0x75a48 <g.3>
   679fb:      	je	0x7085f <f.2+0x180af>
   67a01:      	cmpq	$0xd, %r12
   67a05:      	ja	0x67a11 <f.2+0xf261>
   67a07:      	leaq	-0xc(%r12), %r15
   67a0c:      	jmp	0x67b3f <f.2+0xf38f>
   67a11:      	cmpq	$0xe, %r12
   67a15:      	jne	0x67a30 <f.2+0xf280>
   67a17:      	movl	$0x1, %r15d
   67a1d:      	cmpq	$0x0, 0xe023(%rip)      # 0x75a48 <g.3>
   67a25:      	jne	0x67ac7 <f.2+0xf317>
   67a2b:      	jmp	0x7085f <f.2+0x180af>
   67a30:      	movq	%rcx, 0x10(%rsp)
   67a35:      	leaq	-0xe(%r12), %rsi
   67a3a:      	movq	$0x0, 0x48(%rsp)
   67a43:      	movq	$0x3, 0x30(%rsp)
   67a4c:      	xorl	%edi, %edi
   67a4e:      	callq	0x70870 <f.3>
   67a53:      	subq	$0x8, %rsp
   67a57:      	cmpb	$0x0, 0xdff2(%rip)      # 0x75a50 <g.4>
   67a5e:      	je	0x7085f <f.2+0x180af>
   67a64:      	movq	%rax, 0x18(%rsp)
   67a69:      	cmpq	$0x0, 0xdfd7(%rip)      # 0x75a48 <g.3>
   67a71:      	je	0x7085f <f.2+0x180af>
   67a77:      	leaq	-0xf(%r12), %rsi
   67a7c:      	movq	$0x0, 0x48(%rsp)
   67a85:      	movq	$0x3, 0x30(%rsp)
   67a8e:      	xorl	%edi, %edi
   67a90:      	callq	0x70870 <f.3>
   67a95:      	subq	$0x8, %rsp
   67a99:      	cmpb	$0x0, 0xdfb0(%rip)      # 0x75a50 <g.4>
   67aa0:      	je	0x7085f <f.2+0x180af>
   67aa6:      	cmpq	$0x0, 0xdf9a(%rip)      # 0x75a48 <g.3>
   67aae:      	movq	0x10(%rsp), %rcx
   67ab3:      	je	0x7085f <f.2+0x180af>
   67ab9:      	movq	%rax, %r15
   67abc:      	addq	0x18(%rsp), %r15
   67ac1:      	cmpq	$0xf, %r12
   67ac5:      	ja	0x67ace <f.2+0xf31e>
   67ac7:      	leaq	-0xe(%r12), %rax
   67acc:      	jmp	0x67b3c <f.2+0xf38c>
   67ace:      	movq	$0x0, 0x48(%rsp)
   67ad7:      	movq	$0x3, 0x30(%rsp)
   67ae0:      	xorl	%edi, %edi
   67ae2:      	leaq	-0xf(%r12), %rsi
   67ae7:      	callq	0x70870 <f.3>
   67aec:      	subq	$0x8, %rsp
   67af0:      	cmpb	$0x0, 0xdf59(%rip)      # 0x75a50 <g.4>
   67af7:      	je	0x7085f <f.2+0x180af>
   67afd:      	movq	%rax, 0x18(%rsp)
   67b02:      	cmpq	$0x0, 0xdf3e(%rip)      # 0x75a48 <g.3>
   67b0a:      	je	0x7085f <f.2+0x180af>
   67b10:      	leaq	-0x10(%r12), %rsi
   67b15:      	movq	$0x0, 0x48(%rsp)
   67b1e:      	movq	$0x3, 0x30(%rsp)
   67b27:      	xorl	%edi, %edi
   67b29:      	callq	0x70870 <f.3>
   67b2e:      	subq	$0x8, %rsp
   67b32:      	addq	0x18(%rsp), %rax
   67b37:      	movq	0x10(%rsp), %rcx
   67b3c:      	addq	%rax, %r15
   67b3f:      	cmpb	$0x0, 0xdf0a(%rip)      # 0x75a50 <g.4>
   67b46:      	je	0x7085f <f.2+0x180af>
   67b4c:      	addq	%rcx, %r15
   67b4f:      	addq	%rbp, %r15
   67b52:      	cmpq	$0x0, 0xdeee(%rip)      # 0x75a48 <g.3>
   67b5a:      	je	0x7085f <f.2+0x180af>
   67b60:      	cmpq	$0xa, %r12
   67b64:      	ja	0x67b7e <f.2+0xf3ce>
   67b66:      	leaq	-0x9(%r12,%r15), %rbp
   67b6b:      	cmpq	$0x0, 0xded5(%rip)      # 0x75a48 <g.3>
   67b73:      	jne	0x68136 <f.2+0xf986>
   67b79:      	jmp	0x7085f <f.2+0x180af>
   67b7e:      	cmpq	$0xb, %r12
   67b82:      	jne	0x67b9c <f.2+0xf3ec>
   67b84:      	movl	$0x1, %ecx
   67b89:      	cmpq	$0x0, 0xdeb7(%rip)      # 0x75a48 <g.3>
   67b91:      	jne	0x67e55 <f.2+0xf6a5>
   67b97:      	jmp	0x7085f <f.2+0x180af>
   67b9c:      	cmpq	$0xd, %r12
   67ba0:      	jb	0x67bbc <f.2+0xf40c>
   67ba2:      	jne	0x67bd4 <f.2+0xf424>
   67ba4:      	movl	$0x1, %ebp
   67ba9:      	cmpq	$0x0, 0xde97(%rip)      # 0x75a48 <g.3>
   67bb1:      	jne	0x67c61 <f.2+0xf4b1>
   67bb7:      	jmp	0x7085f <f.2+0x180af>
   67bbc:      	movl	$0x1, %eax
   67bc1:      	cmpq	$0x0, 0xde7f(%rip)      # 0x75a48 <g.3>
   67bc9:      	jne	0x67cfb <f.2+0xf54b>
   67bcf:      	jmp	0x7085f <f.2+0x180af>
   67bd4:      	leaq	-0xd(%r12), %rsi
   67bd9:      	movq	$0x0, 0x48(%rsp)
   67be2:      	movq	$0x3, 0x30(%rsp)
   67beb:      	xorl	%edi, %edi
   67bed:      	callq	0x70870 <f.3>
   67bf2:      	subq	$0x8, %rsp
   67bf6:      	cmpb	$0x0, 0xde53(%rip)      # 0x75a50 <g.4>
   67bfd:      	je	0x7085f <f.2+0x180af>
   67c03:      	movq	%rax, 0x10(%rsp)
   67c08:      	cmpq	$0x0, 0xde38(%rip)      # 0x75a48 <g.3>
   67c10:      	je	0x7085f <f.2+0x180af>
   67c16:      	leaq	-0xe(%r12), %rsi
   67c1b:      	movq	$0x0, 0x48(%rsp)
   67c24:      	movq	$0x3, 0x30(%rsp)
   67c2d:      	xorl	%edi, %edi
   67c2f:      	callq	0x70870 <f.3>
   67c34:      	subq	$0x8, %rsp
   67c38:      	cmpb	$0x0, 0xde11(%rip)      # 0x75a50 <g.4>
   67c3f:      	je	0x7085f <f.2+0x180af>
   67c45:      	cmpq	$0x0, 0xddfb(%rip)      # 0x75a48 <g.3>
   67c4d:      	je	0x7085f <f.2+0x180af>
   67c53:      	movq	%rax, %rbp
   67c56:      	addq	0x10(%rsp), %rbp
   67c5b:      	cmpq	$0xe, %r12
   67c5f:      	ja	0x67c68 <f.2+0xf4b8>
   67c61:      	leaq	-0xd(%r12,%rbp), %rax
   67c66:      	jmp	0x67ce1 <f.2+0xf531>
   67c68:      	movq	$0x0, 0x48(%rsp)
   67c71:      	movq	$0x3, 0x30(%rsp)
   67c7a:      	xorl	%edi, %edi
   67c7c:      	leaq	-0xe(%r12), %rsi
   67c81:      	callq	0x70870 <f.3>
   67c86:      	subq	$0x8, %rsp
   67c8a:      	cmpb	$0x0, 0xddbf(%rip)      # 0x75a50 <g.4>
   67c91:      	je	0x7085f <f.2+0x180af>
   67c97:      	movq	%rax, 0x10(%rsp)
   67c9c:      	cmpq	$0x0, 0xdda4(%rip)      # 0x75a48 <g.3>
   67ca4:      	je	0x7085f <f.2+0x180af>
   67caa:      	leaq	-0xf(%r12), %rsi
   67caf:      	movq	$0x0, 0x48(%rsp)
   67cb8:      	movq	$0x3, 0x30(%rsp)
   67cc1:      	xorl	%edi, %edi
   67cc3:      	callq	0x70870 <f.3>
   67cc8:      	subq	$0x8, %rsp
   67ccc:      	cmpb	$0x0, 0xdd7d(%rip)      # 0x75a50 <g.4>
   67cd3:      	je	0x7085f <f.2+0x180af>
   67cd9:      	addq	0x10(%rsp), %rax
   67cde:      	addq	%rbp, %rax
   67ce1:      	cmpq	$0x0, 0xdd5f(%rip)      # 0x75a48 <g.3>
   67ce9:      	je	0x7085f <f.2+0x180af>
   67cef:      	cmpq	$0xe, %r12
   67cf3:      	je	0x67d05 <f.2+0xf555>
   67cf5:      	cmpq	$0xd, %r12
   67cf9:      	jne	0x67d1d <f.2+0xf56d>
   67cfb:      	leaq	-0xc(%r12,%rax), %rcx
   67d00:      	jmp	0x67e41 <f.2+0xf691>
   67d05:      	movl	$0x1, %edx
   67d0a:      	cmpq	$0x0, 0xdd36(%rip)      # 0x75a48 <g.3>
   67d12:      	jne	0x67db0 <f.2+0xf600>
   67d18:      	jmp	0x7085f <f.2+0x180af>
   67d1d:      	movq	%rax, 0x10(%rsp)
   67d22:      	leaq	-0xe(%r12), %rsi
   67d27:      	movq	$0x0, 0x48(%rsp)
   67d30:      	movq	$0x3, 0x30(%rsp)
   67d39:      	xorl	%edi, %edi
   67d3b:      	callq	0x70870 <f.3>
   67d40:      	subq	$0x8, %rsp
   67d44:      	cmpb	$0x0, 0xdd05(%rip)      # 0x75a50 <g.4>
   67d4b:      	je	0x7085f <f.2+0x180af>
   67d51:      	cmpq	$0x0, 0xdcef(%rip)      # 0x75a48 <g.3>
   67d59:      	je	0x7085f <f.2+0x180af>
   67d5f:      	movq	%rax, %rbp
   67d62:      	leaq	-0xf(%r12), %rsi
   67d67:      	movq	$0x0, 0x48(%rsp)
   67d70:      	movq	$0x3, 0x30(%rsp)
   67d79:      	xorl	%edi, %edi
   67d7b:      	callq	0x70870 <f.3>
   67d80:      	subq	$0x8, %rsp
   67d84:      	cmpb	$0x0, 0xdcc5(%rip)      # 0x75a50 <g.4>
   67d8b:      	je	0x7085f <f.2+0x180af>
   67d91:      	movq	%rax, %rdx
   67d94:      	cmpq	$0x0, 0xdcac(%rip)      # 0x75a48 <g.3>
   67d9c:      	movq	0x10(%rsp), %rax
   67da1:      	je	0x7085f <f.2+0x180af>
   67da7:      	addq	%rbp, %rdx
   67daa:      	cmpq	$0xf, %r12
   67dae:      	ja	0x67db7 <f.2+0xf607>
   67db0:      	leaq	-0xe(%r12), %rcx
   67db5:      	jmp	0x67e2e <f.2+0xf67e>
   67db7:      	movq	%rdx, 0x18(%rsp)
   67dbc:      	movq	$0x0, 0x48(%rsp)
   67dc5:      	movq	$0x3, 0x30(%rsp)
   67dce:      	xorl	%edi, %edi
   67dd0:      	leaq	-0xf(%r12), %rsi
   67dd5:      	callq	0x70870 <f.3>
   67dda:      	subq	$0x8, %rsp
   67dde:      	cmpb	$0x0, 0xdc6b(%rip)      # 0x75a50 <g.4>
   67de5:      	je	0x7085f <f.2+0x180af>
   67deb:      	cmpq	$0x0, 0xdc55(%rip)      # 0x75a48 <g.3>
   67df3:      	je	0x7085f <f.2+0x180af>
   67df9:      	movq	%rax, %rbp
   67dfc:      	leaq	-0x10(%r12), %rsi
   67e01:      	movq	$0x0, 0x48(%rsp)
   67e0a:      	movq	$0x3, 0x30(%rsp)
   67e13:      	xorl	%edi, %edi
   67e15:      	callq	0x70870 <f.3>
   67e1a:      	subq	$0x8, %rsp
   67e1e:      	movq	%rax, %rcx
   67e21:      	addq	%rbp, %rcx
   67e24:      	movq	0x10(%rsp), %rax
   67e29:      	movq	0x18(%rsp), %rdx
   67e2e:      	cmpb	$0x0, 0xdc1b(%rip)      # 0x75a50 <g.4>
   67e35:      	je	0x7085f <f.2+0x180af>
   67e3b:      	addq	%rdx, %rcx
   67e3e:      	addq	%rax, %rcx
   67e41:      	cmpq	$0x0, 0xdbff(%rip)      # 0x75a48 <g.3>
   67e49:      	je	0x7085f <f.2+0x180af>
   67e4f:      	cmpq	$0xc, %r12
   67e53:      	ja	0x67e5f <f.2+0xf6af>
   67e55:      	leaq	-0xb(%r12), %rbp
   67e5a:      	jmp	0x68115 <f.2+0xf965>
   67e5f:      	cmpq	$0xd, %r12
   67e63:      	jne	0x67e7d <f.2+0xf6cd>
   67e65:      	movl	$0x1, %ebp
   67e6a:      	cmpq	$0x0, 0xdbd6(%rip)      # 0x75a48 <g.3>
   67e72:      	jne	0x67fd1 <f.2+0xf821>
   67e78:      	jmp	0x7085f <f.2+0x180af>
   67e7d:      	cmpq	$0xf, %r12
   67e81:      	jb	0x67fa5 <f.2+0xf7f5>
   67e87:      	movq	%rcx, 0x10(%rsp)
   67e8c:      	leaq	-0xe(%r12), %rsi
   67e91:      	movq	$0x0, 0x48(%rsp)
   67e9a:      	movq	$0x3, 0x30(%rsp)
   67ea3:      	xorl	%edi, %edi
   67ea5:      	callq	0x70870 <f.3>
   67eaa:      	subq	$0x8, %rsp
   67eae:      	cmpb	$0x0, 0xdb9b(%rip)      # 0x75a50 <g.4>
   67eb5:      	je	0x7085f <f.2+0x180af>
   67ebb:      	cmpq	$0x0, 0xdb85(%rip)      # 0x75a48 <g.3>
   67ec3:      	je	0x7085f <f.2+0x180af>
   67ec9:      	movq	%rax, %rbp
   67ecc:      	leaq	-0xf(%r12), %rsi
   67ed1:      	movq	$0x0, 0x48(%rsp)
   67eda:      	movq	$0x3, 0x30(%rsp)
   67ee3:      	xorl	%edi, %edi
   67ee5:      	callq	0x70870 <f.3>
   67eea:      	subq	$0x8, %rsp
   67eee:      	cmpb	$0x0, 0xdb5b(%rip)      # 0x75a50 <g.4>
   67ef5:      	je	0x7085f <f.2+0x180af>
   67efb:      	cmpq	$0x0, 0xdb45(%rip)      # 0x75a48 <g.3>
   67f03:      	movq	0x10(%rsp), %rcx
   67f08:      	je	0x7085f <f.2+0x180af>
   67f0e:      	addq	%rbp, %rax
   67f11:      	cmpq	$0xf, %r12
   67f15:      	je	0x67fb8 <f.2+0xf808>
   67f1b:      	movq	%rax, 0x18(%rsp)
   67f20:      	movq	$0x0, 0x48(%rsp)
   67f29:      	movq	$0x3, 0x30(%rsp)
   67f32:      	xorl	%edi, %edi
   67f34:      	leaq	-0xf(%r12), %rsi
   67f39:      	callq	0x70870 <f.3>
   67f3e:      	subq	$0x8, %rsp
   67f42:      	cmpb	$0x0, 0xdb07(%rip)      # 0x75a50 <g.4>
   67f49:      	je	0x7085f <f.2+0x180af>
   67f4f:      	movq	%rax, 0x50(%rsp)
   67f54:      	cmpq	$0x0, 0xdaec(%rip)      # 0x75a48 <g.3>
   67f5c:      	je	0x7085f <f.2+0x180af>
   67f62:      	leaq	-0x10(%r12), %rsi
   67f67:      	movq	$0x0, 0x48(%rsp)
   67f70:      	movq	$0x3, 0x30(%rsp)
   67f79:      	xorl	%edi, %edi
   67f7b:      	callq	0x70870 <f.3>
   67f80:      	subq	$0x8, %rsp
   67f84:      	cmpb	$0x0, 0xdac5(%rip)      # 0x75a50 <g.4>
   67f8b:      	je	0x7085f <f.2+0x180af>
   67f91:      	movq	%rax, %rbp
   67f94:      	addq	0x50(%rsp), %rbp
   67f99:      	addq	0x18(%rsp), %rbp
   67f9e:      	movq	0x10(%rsp), %rcx
   67fa3:      	jmp	0x67fbd <f.2+0xf80d>
   67fa5:      	movl	$0x1, %eax
   67faa:      	cmpq	$0x0, 0xda96(%rip)      # 0x75a48 <g.3>
   67fb2:      	je	0x7085f <f.2+0x180af>
   67fb8:      	leaq	-0xe(%r12,%rax), %rbp
   67fbd:      	cmpq	$0x0, 0xda83(%rip)      # 0x75a48 <g.3>
   67fc5:      	je	0x7085f <f.2+0x180af>
   67fcb:      	cmpq	$0xe, %r12
   67fcf:      	ja	0x67fdb <f.2+0xf82b>
   67fd1:      	leaq	-0xd(%r12), %rdx
   67fd6:      	jmp	0x68112 <f.2+0xf962>
   67fdb:      	cmpq	$0xf, %r12
   67fdf:      	jne	0x67ff9 <f.2+0xf849>
   67fe1:      	movl	$0x1, %edx
   67fe6:      	cmpq	$0x0, 0xda5a(%rip)      # 0x75a48 <g.3>
   67fee:      	jne	0x68090 <f.2+0xf8e0>
   67ff4:      	jmp	0x7085f <f.2+0x180af>
   67ff9:      	movq	%rcx, 0x10(%rsp)
   67ffe:      	leaq	-0xf(%r12), %rsi
   68003:      	movq	$0x0, 0x48(%rsp)
   6800c:      	movq	$0x3, 0x30(%rsp)
   68015:      	xorl	%edi, %edi
   68017:      	callq	0x70870 <f.3>
   6801c:      	subq	$0x8, %rsp
   68020:      	cmpb	$0x0, 0xda29(%rip)      # 0x75a50 <g.4>
   68027:      	je	0x7085f <f.2+0x180af>
   6802d:      	movq	%rax, 0x18(%rsp)
   68032:      	cmpq	$0x0, 0xda0e(%rip)      # 0x75a48 <g.3>
   6803a:      	je	0x7085f <f.2+0x180af>
   68040:      	leaq	-0x10(%r12), %rsi
   68045:      	movq	$0x0, 0x48(%rsp)
   6804e:      	movq	$0x3, 0x30(%rsp)
   68057:      	xorl	%edi, %edi
   68059:      	callq	0x70870 <f.3>
   6805e:      	subq	$0x8, %rsp
   68062:      	cmpb	$0x0, 0xd9e7(%rip)      # 0x75a50 <g.4>
   68069:      	je	0x7085f <f.2+0x180af>
   6806f:      	cmpq	$0x0, 0xd9d1(%rip)      # 0x75a48 <g.3>
   68077:      	movq	0x10(%rsp), %rcx
   6807c:      	je	0x7085f <f.2+0x180af>
   68082:      	movq	%rax, %rdx
   68085:      	addq	0x18(%rsp), %rdx
   6808a:      	cmpq	$0x10, %r12
   6808e:      	ja	0x68097 <f.2+0xf8e7>
   68090:      	leaq	-0xf(%r12), %rax
   68095:      	jmp	0x6810f <f.2+0xf95f>
   68097:      	movq	%rdx, 0x18(%rsp)
   6809c:      	movq	$0x0, 0x48(%rsp)
   680a5:      	movq	$0x3, 0x30(%rsp)
   680ae:      	xorl	%edi, %edi
   680b0:      	leaq	-0x10(%r12), %rsi
   680b5:      	callq	0x70870 <f.3>
   680ba:      	subq	$0x8, %rsp
   680be:      	cmpb	$0x0, 0xd98b(%rip)      # 0x75a50 <g.4>
   680c5:      	je	0x7085f <f.2+0x180af>
   680cb:      	movq	%rax, 0x50(%rsp)
   680d0:      	cmpq	$0x0, 0xd970(%rip)      # 0x75a48 <g.3>
   680d8:      	je	0x7085f <f.2+0x180af>
   680de:      	leaq	-0x11(%r12), %rsi
   680e3:      	movq	$0x0, 0x48(%rsp)
   680ec:      	movq	$0x3, 0x30(%rsp)
   680f5:      	xorl	%edi, %edi
   680f7:      	callq	0x70870 <f.3>
   680fc:      	subq	$0x8, %rsp
   68100:      	addq	0x50(%rsp), %rax
   68105:      	movq	0x10(%rsp), %rcx
   6810a:      	movq	0x18(%rsp), %rdx
   6810f:      	addq	%rax, %rdx
   68112:      	addq	%rdx, %rbp
   68115:      	cmpb	$0x0, 0xd934(%rip)      # 0x75a50 <g.4>
   6811c:      	je	0x7085f <f.2+0x180af>
   68122:      	addq	%rcx, %rbp
   68125:      	addq	%r15, %rbp
   68128:      	cmpq	$0x0, 0xd918(%rip)      # 0x75a48 <g.3>
   68130:      	je	0x7085f <f.2+0x180af>
   68136:      	cmpq	$0xa, %r12
   6813a:      	je	0x6815a <f.2+0xf9aa>
   6813c:      	cmpq	$0x9, %r12
   68140:      	jne	0x68172 <f.2+0xf9c2>
   68142:      	leaq	-0x8(%r12,%rbp), %r15
   68147:      	cmpq	$0x0, 0xd8f9(%rip)      # 0x75a48 <g.3>
   6814f:      	jne	0x68d37 <f.2+0x10587>
   68155:      	jmp	0x7085f <f.2+0x180af>
   6815a:      	movl	$0x1, %ecx
   6815f:      	cmpq	$0x0, 0xd8e1(%rip)      # 0x75a48 <g.3>
   68167:      	jne	0x6872b <f.2+0xff7b>
   6816d:      	jmp	0x7085f <f.2+0x180af>
   68172:      	cmpq	$0xc, %r12
   68176:      	jb	0x68192 <f.2+0xf9e2>
   68178:      	jne	0x681ab <f.2+0xf9fb>
   6817a:      	movl	$0x1, %eax
   6817f:      	cmpq	$0x0, 0xd8c1(%rip)      # 0x75a48 <g.3>
   68187:      	jne	0x682ee <f.2+0xfb3e>
   6818d:      	jmp	0x7085f <f.2+0x180af>
   68192:      	movl	$0x1, %r15d
   68198:      	cmpq	$0x0, 0xd8a8(%rip)      # 0x75a48 <g.3>
   681a0:      	jne	0x68458 <f.2+0xfca8>
   681a6:      	jmp	0x7085f <f.2+0x180af>
   681ab:      	cmpq	$0xe, %r12
   681af:      	jb	0x682c1 <f.2+0xfb11>
   681b5:      	leaq	-0xd(%r12), %rsi
   681ba:      	movq	$0x0, 0x48(%rsp)
   681c3:      	movq	$0x3, 0x30(%rsp)
   681cc:      	xorl	%edi, %edi
   681ce:      	callq	0x70870 <f.3>
   681d3:      	subq	$0x8, %rsp
   681d7:      	cmpb	$0x0, 0xd872(%rip)      # 0x75a50 <g.4>
   681de:      	je	0x7085f <f.2+0x180af>
   681e4:      	movq	%rax, 0x10(%rsp)
   681e9:      	cmpq	$0x0, 0xd857(%rip)      # 0x75a48 <g.3>
   681f1:      	je	0x7085f <f.2+0x180af>
   681f7:      	leaq	-0xe(%r12), %rsi
   681fc:      	movq	$0x0, 0x48(%rsp)
   68205:      	movq	$0x3, 0x30(%rsp)
   6820e:      	xorl	%edi, %edi
   68210:      	callq	0x70870 <f.3>
   68215:      	subq	$0x8, %rsp
   68219:      	cmpb	$0x0, 0xd830(%rip)      # 0x75a50 <g.4>
   68220:      	je	0x7085f <f.2+0x180af>
   68226:      	cmpq	$0x0, 0xd81a(%rip)      # 0x75a48 <g.3>
   6822e:      	je	0x7085f <f.2+0x180af>
   68234:      	movq	%rax, %r15
   68237:      	addq	0x10(%rsp), %r15
   6823c:      	cmpq	$0xe, %r12
   68240:      	je	0x682d5 <f.2+0xfb25>
   68246:      	movq	$0x0, 0x48(%rsp)
   6824f:      	movq	$0x3, 0x30(%rsp)
   68258:      	xorl	%edi, %edi
   6825a:      	leaq	-0xe(%r12), %rsi
   6825f:      	callq	0x70870 <f.3>
   68264:      	subq	$0x8, %rsp
   68268:      	cmpb	$0x0, 0xd7e1(%rip)      # 0x75a50 <g.4>
   6826f:      	je	0x7085f <f.2+0x180af>
   68275:      	movq	%rax, 0x10(%rsp)
   6827a:      	cmpq	$0x0, 0xd7c6(%rip)      # 0x75a48 <g.3>
   68282:      	je	0x7085f <f.2+0x180af>
   68288:      	leaq	-0xf(%r12), %rsi
   6828d:      	movq	$0x0, 0x48(%rsp)
   68296:      	movq	$0x3, 0x30(%rsp)
   6829f:      	xorl	%edi, %edi
   682a1:      	callq	0x70870 <f.3>
   682a6:      	subq	$0x8, %rsp
   682aa:      	cmpb	$0x0, 0xd79f(%rip)      # 0x75a50 <g.4>
   682b1:      	je	0x7085f <f.2+0x180af>
   682b7:      	addq	0x10(%rsp), %rax
   682bc:      	addq	%r15, %rax
   682bf:      	jmp	0x682da <f.2+0xfb2a>
   682c1:      	movl	$0x1, %r15d
   682c7:      	cmpq	$0x0, 0xd779(%rip)      # 0x75a48 <g.3>
   682cf:      	je	0x7085f <f.2+0x180af>
   682d5:      	leaq	-0xd(%r12,%r15), %rax
   682da:      	cmpq	$0x0, 0xd766(%rip)      # 0x75a48 <g.3>
   682e2:      	je	0x7085f <f.2+0x180af>
   682e8:      	cmpq	$0xd, %r12
   682ec:      	ja	0x682f8 <f.2+0xfb48>
   682ee:      	leaq	-0xc(%r12,%rax), %r15
   682f3:      	jmp	0x6843e <f.2+0xfc8e>
   682f8:      	cmpq	$0xe, %r12
   682fc:      	jne	0x68316 <f.2+0xfb66>
   682fe:      	movl	$0x1, %ecx
   68303:      	cmpq	$0x0, 0xd73d(%rip)      # 0x75a48 <g.3>
   6830b:      	jne	0x683a9 <f.2+0xfbf9>
   68311:      	jmp	0x7085f <f.2+0x180af>
   68316:      	movq	%rax, 0x10(%rsp)
   6831b:      	leaq	-0xe(%r12), %rsi
   68320:      	movq	$0x0, 0x48(%rsp)
   68329:      	movq	$0x3, 0x30(%rsp)
   68332:      	xorl	%edi, %edi
   68334:      	callq	0x70870 <f.3>
   68339:      	subq	$0x8, %rsp
   6833d:      	cmpb	$0x0, 0xd70c(%rip)      # 0x75a50 <g.4>
   68344:      	je	0x7085f <f.2+0x180af>
   6834a:      	cmpq	$0x0, 0xd6f6(%rip)      # 0x75a48 <g.3>
   68352:      	je	0x7085f <f.2+0x180af>
   68358:      	movq	%rax, %r15
   6835b:      	leaq	-0xf(%r12), %rsi
   68360:      	movq	$0x0, 0x48(%rsp)
   68369:      	movq	$0x3, 0x30(%rsp)
   68372:      	xorl	%edi, %edi
   68374:      	callq	0x70870 <f.3>
   68379:      	subq	$0x8, %rsp
   6837d:      	cmpb	$0x0, 0xd6cc(%rip)      # 0x75a50 <g.4>
   68384:      	je	0x7085f <f.2+0x180af>
   6838a:      	movq	%rax, %rcx
   6838d:      	cmpq	$0x0, 0xd6b3(%rip)      # 0x75a48 <g.3>
   68395:      	movq	0x10(%rsp), %rax
   6839a:      	je	0x7085f <f.2+0x180af>
   683a0:      	addq	%r15, %rcx
   683a3:      	cmpq	$0xf, %r12
   683a7:      	ja	0x683b0 <f.2+0xfc00>
   683a9:      	leaq	-0xe(%r12), %r15
   683ae:      	jmp	0x6842b <f.2+0xfc7b>
   683b0:      	movq	%rcx, 0x18(%rsp)
   683b5:      	movq	$0x0, 0x48(%rsp)
   683be:      	movq	$0x3, 0x30(%rsp)
   683c7:      	xorl	%edi, %edi
   683c9:      	leaq	-0xf(%r12), %rsi
   683ce:      	callq	0x70870 <f.3>
   683d3:      	subq	$0x8, %rsp
   683d7:      	cmpb	$0x0, 0xd672(%rip)      # 0x75a50 <g.4>
   683de:      	je	0x7085f <f.2+0x180af>
   683e4:      	movq	%rax, 0x50(%rsp)
   683e9:      	cmpq	$0x0, 0xd657(%rip)      # 0x75a48 <g.3>
   683f1:      	je	0x7085f <f.2+0x180af>
   683f7:      	leaq	-0x10(%r12), %rsi
   683fc:      	movq	$0x0, 0x48(%rsp)
   68405:      	movq	$0x3, 0x30(%rsp)
   6840e:      	xorl	%edi, %edi
   68410:      	callq	0x70870 <f.3>
   68415:      	subq	$0x8, %rsp
   68419:      	movq	%rax, %r15
   6841c:      	addq	0x50(%rsp), %r15
   68421:      	movq	0x10(%rsp), %rax
   68426:      	movq	0x18(%rsp), %rcx
   6842b:      	cmpb	$0x0, 0xd61e(%rip)      # 0x75a50 <g.4>
   68432:      	je	0x7085f <f.2+0x180af>
   68438:      	addq	%rcx, %r15
   6843b:      	addq	%rax, %r15
   6843e:      	cmpq	$0x0, 0xd602(%rip)      # 0x75a48 <g.3>
   68446:      	je	0x7085f <f.2+0x180af>
   6844c:      	cmpq	$0xd, %r12
   68450:      	je	0x68462 <f.2+0xfcb2>
   68452:      	cmpq	$0xc, %r12
   68456:      	jne	0x6847a <f.2+0xfcca>
   68458:      	leaq	-0xb(%r12,%r15), %rcx
   6845d:      	jmp	0x68717 <f.2+0xff67>
   68462:      	movl	$0x1, %edx
   68467:      	cmpq	$0x0, 0xd5d9(%rip)      # 0x75a48 <g.3>
   6846f:      	jne	0x685c3 <f.2+0xfe13>
   68475:      	jmp	0x7085f <f.2+0x180af>
   6847a:      	cmpq	$0xf, %r12
   6847e:      	jb	0x68597 <f.2+0xfde7>
   68484:      	leaq	-0xe(%r12), %rsi
   68489:      	movq	$0x0, 0x48(%rsp)
   68492:      	movq	$0x3, 0x30(%rsp)
   6849b:      	xorl	%edi, %edi
   6849d:      	callq	0x70870 <f.3>
   684a2:      	subq	$0x8, %rsp
   684a6:      	cmpb	$0x0, 0xd5a3(%rip)      # 0x75a50 <g.4>
   684ad:      	je	0x7085f <f.2+0x180af>
   684b3:      	movq	%rax, 0x10(%rsp)
   684b8:      	cmpq	$0x0, 0xd588(%rip)      # 0x75a48 <g.3>
   684c0:      	je	0x7085f <f.2+0x180af>
   684c6:      	leaq	-0xf(%r12), %rsi
   684cb:      	movq	$0x0, 0x48(%rsp)
   684d4:      	movq	$0x3, 0x30(%rsp)
   684dd:      	xorl	%edi, %edi
   684df:      	callq	0x70870 <f.3>
   684e4:      	subq	$0x8, %rsp
   684e8:      	cmpb	$0x0, 0xd561(%rip)      # 0x75a50 <g.4>
   684ef:      	je	0x7085f <f.2+0x180af>
   684f5:      	cmpq	$0x0, 0xd54b(%rip)      # 0x75a48 <g.3>
   684fd:      	je	0x7085f <f.2+0x180af>
   68503:      	addq	0x10(%rsp), %rax
   68508:      	cmpq	$0xf, %r12
   6850c:      	je	0x685aa <f.2+0xfdfa>
   68512:      	movq	%rax, 0x10(%rsp)
   68517:      	movq	$0x0, 0x48(%rsp)
   68520:      	movq	$0x3, 0x30(%rsp)
   68529:      	xorl	%edi, %edi
   6852b:      	leaq	-0xf(%r12), %rsi
   68530:      	callq	0x70870 <f.3>
   68535:      	subq	$0x8, %rsp
   68539:      	cmpb	$0x0, 0xd510(%rip)      # 0x75a50 <g.4>
   68540:      	je	0x7085f <f.2+0x180af>
   68546:      	movq	%rax, 0x18(%rsp)
   6854b:      	cmpq	$0x0, 0xd4f5(%rip)      # 0x75a48 <g.3>
   68553:      	je	0x7085f <f.2+0x180af>
   68559:      	leaq	-0x10(%r12), %rsi
   6855e:      	movq	$0x0, 0x48(%rsp)
   68567:      	movq	$0x3, 0x30(%rsp)
   68570:      	xorl	%edi, %edi
   68572:      	callq	0x70870 <f.3>
   68577:      	subq	$0x8, %rsp
   6857b:      	cmpb	$0x0, 0xd4ce(%rip)      # 0x75a50 <g.4>
   68582:      	je	0x7085f <f.2+0x180af>
   68588:      	movq	%rax, %rdx
   6858b:      	addq	0x18(%rsp), %rdx
   68590:      	addq	0x10(%rsp), %rdx
   68595:      	jmp	0x685af <f.2+0xfdff>
   68597:      	movl	$0x1, %eax
   6859c:      	cmpq	$0x0, 0xd4a4(%rip)      # 0x75a48 <g.3>
   685a4:      	je	0x7085f <f.2+0x180af>
   685aa:      	leaq	-0xe(%r12,%rax), %rdx
   685af:      	cmpq	$0x0, 0xd491(%rip)      # 0x75a48 <g.3>
   685b7:      	je	0x7085f <f.2+0x180af>
   685bd:      	cmpq	$0xe, %r12
   685c1:      	ja	0x685cd <f.2+0xfe1d>
   685c3:      	leaq	-0xd(%r12), %rcx
   685c8:      	jmp	0x68704 <f.2+0xff54>
   685cd:      	cmpq	$0xf, %r12
   685d1:      	jne	0x685eb <f.2+0xfe3b>
   685d3:      	movl	$0x1, %ecx
   685d8:      	cmpq	$0x0, 0xd468(%rip)      # 0x75a48 <g.3>
   685e0:      	jne	0x68682 <f.2+0xfed2>
   685e6:      	jmp	0x7085f <f.2+0x180af>
   685eb:      	movq	%rdx, 0x18(%rsp)
   685f0:      	leaq	-0xf(%r12), %rsi
   685f5:      	movq	$0x0, 0x48(%rsp)
   685fe:      	movq	$0x3, 0x30(%rsp)
   68607:      	xorl	%edi, %edi
   68609:      	callq	0x70870 <f.3>
   6860e:      	subq	$0x8, %rsp
   68612:      	cmpb	$0x0, 0xd437(%rip)      # 0x75a50 <g.4>
   68619:      	je	0x7085f <f.2+0x180af>
   6861f:      	movq	%rax, 0x10(%rsp)
   68624:      	cmpq	$0x0, 0xd41c(%rip)      # 0x75a48 <g.3>
   6862c:      	je	0x7085f <f.2+0x180af>
   68632:      	leaq	-0x10(%r12), %rsi
   68637:      	movq	$0x0, 0x48(%rsp)
   68640:      	movq	$0x3, 0x30(%rsp)
   68649:      	xorl	%edi, %edi
   6864b:      	callq	0x70870 <f.3>
   68650:      	subq	$0x8, %rsp
   68654:      	cmpb	$0x0, 0xd3f5(%rip)      # 0x75a50 <g.4>
   6865b:      	je	0x7085f <f.2+0x180af>
   68661:      	cmpq	$0x0, 0xd3df(%rip)      # 0x75a48 <g.3>
   68669:      	movq	0x18(%rsp), %rdx
   6866e:      	je	0x7085f <f.2+0x180af>
   68674:      	movq	%rax, %rcx
   68677:      	addq	0x10(%rsp), %rcx
   6867c:      	cmpq	$0x10, %r12
   68680:      	ja	0x68689 <f.2+0xfed9>
   68682:      	leaq	-0xf(%r12), %rax
   68687:      	jmp	0x68701 <f.2+0xff51>
   68689:      	movq	%rcx, 0x10(%rsp)
   6868e:      	movq	$0x0, 0x48(%rsp)
   68697:      	movq	$0x3, 0x30(%rsp)
   686a0:      	xorl	%edi, %edi
   686a2:      	leaq	-0x10(%r12), %rsi
   686a7:      	callq	0x70870 <f.3>
   686ac:      	subq	$0x8, %rsp
   686b0:      	cmpb	$0x0, 0xd399(%rip)      # 0x75a50 <g.4>
   686b7:      	je	0x7085f <f.2+0x180af>
   686bd:      	movq	%rax, 0x50(%rsp)
   686c2:      	cmpq	$0x0, 0xd37e(%rip)      # 0x75a48 <g.3>
   686ca:      	je	0x7085f <f.2+0x180af>
   686d0:      	leaq	-0x11(%r12), %rsi
   686d5:      	movq	$0x0, 0x48(%rsp)
   686de:      	movq	$0x3, 0x30(%rsp)
   686e7:      	xorl	%edi, %edi
   686e9:      	callq	0x70870 <f.3>
   686ee:      	subq	$0x8, %rsp
   686f2:      	addq	0x50(%rsp), %rax
   686f7:      	movq	0x10(%rsp), %rcx
   686fc:      	movq	0x18(%rsp), %rdx
   68701:      	addq	%rax, %rcx
   68704:      	cmpb	$0x0, 0xd345(%rip)      # 0x75a50 <g.4>
   6870b:      	je	0x7085f <f.2+0x180af>
   68711:      	addq	%rdx, %rcx
   68714:      	addq	%r15, %rcx
   68717:      	cmpq	$0x0, 0xd329(%rip)      # 0x75a48 <g.3>
   6871f:      	je	0x7085f <f.2+0x180af>
   68725:      	cmpq	$0xb, %r12
   68729:      	ja	0x68742 <f.2+0xff92>
   6872b:      	leaq	-0xa(%r12), %r15
   68730:      	cmpb	$0x0, 0xd319(%rip)      # 0x75a50 <g.4>
   68737:      	jne	0x68d23 <f.2+0x10573>
   6873d:      	jmp	0x7085f <f.2+0x180af>
   68742:      	cmpq	$0xc, %r12
   68746:      	jne	0x68761 <f.2+0xffb1>
   68748:      	movl	$0x1, %r15d
   6874e:      	cmpq	$0x0, 0xd2f2(%rip)      # 0x75a48 <g.3>
   68756:      	jne	0x68a40 <f.2+0x10290>
   6875c:      	jmp	0x7085f <f.2+0x180af>
   68761:      	cmpq	$0xe, %r12
   68765:      	jb	0x68782 <f.2+0xffd2>
   68767:      	jne	0x6879a <f.2+0xffea>
   68769:      	movl	$0x1, %r15d
   6876f:      	cmpq	$0x0, 0xd2d1(%rip)      # 0x75a48 <g.3>
   68777:      	jne	0x68831 <f.2+0x10081>
   6877d:      	jmp	0x7085f <f.2+0x180af>
   68782:      	movl	$0x1, %eax
   68787:      	cmpq	$0x0, 0xd2b9(%rip)      # 0x75a48 <g.3>
   6878f:      	jne	0x688d0 <f.2+0x10120>
   68795:      	jmp	0x7085f <f.2+0x180af>
   6879a:      	movq	%rcx, 0x10(%rsp)
   6879f:      	leaq	-0xe(%r12), %rsi
   687a4:      	movq	$0x0, 0x48(%rsp)
   687ad:      	movq	$0x3, 0x30(%rsp)
   687b6:      	xorl	%edi, %edi
   687b8:      	callq	0x70870 <f.3>
   687bd:      	subq	$0x8, %rsp
   687c1:      	cmpb	$0x0, 0xd288(%rip)      # 0x75a50 <g.4>
   687c8:      	je	0x7085f <f.2+0x180af>
   687ce:      	movq	%rax, 0x18(%rsp)
   687d3:      	cmpq	$0x0, 0xd26d(%rip)      # 0x75a48 <g.3>
   687db:      	je	0x7085f <f.2+0x180af>
   687e1:      	leaq	-0xf(%r12), %rsi
   687e6:      	movq	$0x0, 0x48(%rsp)
   687ef:      	movq	$0x3, 0x30(%rsp)
   687f8:      	xorl	%edi, %edi
   687fa:      	callq	0x70870 <f.3>
   687ff:      	subq	$0x8, %rsp
   68803:      	cmpb	$0x0, 0xd246(%rip)      # 0x75a50 <g.4>
   6880a:      	je	0x7085f <f.2+0x180af>
   68810:      	cmpq	$0x0, 0xd230(%rip)      # 0x75a48 <g.3>
   68818:      	movq	0x10(%rsp), %rcx
   6881d:      	je	0x7085f <f.2+0x180af>
   68823:      	movq	%rax, %r15
   68826:      	addq	0x18(%rsp), %r15
   6882b:      	cmpq	$0xf, %r12
   6882f:      	ja	0x68838 <f.2+0x10088>
   68831:      	leaq	-0xe(%r12,%r15), %rax
   68836:      	jmp	0x688b6 <f.2+0x10106>
   68838:      	movq	$0x0, 0x48(%rsp)
   68841:      	movq	$0x3, 0x30(%rsp)
   6884a:      	xorl	%edi, %edi
   6884c:      	leaq	-0xf(%r12), %rsi
   68851:      	callq	0x70870 <f.3>
   68856:      	subq	$0x8, %rsp
   6885a:      	cmpb	$0x0, 0xd1ef(%rip)      # 0x75a50 <g.4>
   68861:      	je	0x7085f <f.2+0x180af>
   68867:      	movq	%rax, 0x18(%rsp)
   6886c:      	cmpq	$0x0, 0xd1d4(%rip)      # 0x75a48 <g.3>
   68874:      	je	0x7085f <f.2+0x180af>
   6887a:      	leaq	-0x10(%r12), %rsi
   6887f:      	movq	$0x0, 0x48(%rsp)
   68888:      	movq	$0x3, 0x30(%rsp)
   68891:      	xorl	%edi, %edi
   68893:      	callq	0x70870 <f.3>
   68898:      	subq	$0x8, %rsp
   6889c:      	cmpb	$0x0, 0xd1ad(%rip)      # 0x75a50 <g.4>
   688a3:      	je	0x7085f <f.2+0x180af>
   688a9:      	addq	0x18(%rsp), %rax
   688ae:      	addq	%r15, %rax
   688b1:      	movq	0x10(%rsp), %rcx
   688b6:      	cmpq	$0x0, 0xd18a(%rip)      # 0x75a48 <g.3>
   688be:      	je	0x7085f <f.2+0x180af>
   688c4:      	cmpq	$0xf, %r12
   688c8:      	je	0x688da <f.2+0x1012a>
   688ca:      	cmpq	$0xe, %r12
   688ce:      	jne	0x688f2 <f.2+0x10142>
   688d0:      	leaq	-0xd(%r12,%rax), %r15
   688d5:      	jmp	0x68a2c <f.2+0x1027c>
   688da:      	movl	$0x1, %edx
   688df:      	cmpq	$0x0, 0xd161(%rip)      # 0x75a48 <g.3>
   688e7:      	jne	0x6898f <f.2+0x101df>
   688ed:      	jmp	0x7085f <f.2+0x180af>
   688f2:      	movq	%rax, 0x18(%rsp)
   688f7:      	movq	%rcx, 0x10(%rsp)
   688fc:      	leaq	-0xf(%r12), %rsi
   68901:      	movq	$0x0, 0x48(%rsp)
   6890a:      	movq	$0x3, 0x30(%rsp)
   68913:      	xorl	%edi, %edi
   68915:      	callq	0x70870 <f.3>
   6891a:      	subq	$0x8, %rsp
   6891e:      	cmpb	$0x0, 0xd12b(%rip)      # 0x75a50 <g.4>
   68925:      	je	0x7085f <f.2+0x180af>
   6892b:      	cmpq	$0x0, 0xd115(%rip)      # 0x75a48 <g.3>
   68933:      	je	0x7085f <f.2+0x180af>
   68939:      	movq	%rax, %r15
   6893c:      	leaq	-0x10(%r12), %rsi
   68941:      	movq	$0x0, 0x48(%rsp)
   6894a:      	movq	$0x3, 0x30(%rsp)
   68953:      	xorl	%edi, %edi
   68955:      	callq	0x70870 <f.3>
   6895a:      	subq	$0x8, %rsp
   6895e:      	cmpb	$0x0, 0xd0eb(%rip)      # 0x75a50 <g.4>
   68965:      	je	0x7085f <f.2+0x180af>
   6896b:      	movq	%rax, %rdx
   6896e:      	cmpq	$0x0, 0xd0d2(%rip)      # 0x75a48 <g.3>
   68976:      	movq	0x10(%rsp), %rcx
   6897b:      	movq	0x18(%rsp), %rax
   68980:      	je	0x7085f <f.2+0x180af>
   68986:      	addq	%r15, %rdx
   68989:      	cmpq	$0x10, %r12
   6898d:      	ja	0x68999 <f.2+0x101e9>
   6898f:      	leaq	-0xf(%r12), %r15
   68994:      	jmp	0x68a19 <f.2+0x10269>
   68999:      	movq	%rdx, 0x50(%rsp)
   6899e:      	movq	$0x0, 0x48(%rsp)
   689a7:      	movq	$0x3, 0x30(%rsp)
   689b0:      	xorl	%edi, %edi
   689b2:      	leaq	-0x10(%r12), %rsi
   689b7:      	callq	0x70870 <f.3>
   689bc:      	subq	$0x8, %rsp
   689c0:      	cmpb	$0x0, 0xd089(%rip)      # 0x75a50 <g.4>
   689c7:      	je	0x7085f <f.2+0x180af>
   689cd:      	movq	%rax, 0x58(%rsp)
   689d2:      	cmpq	$0x0, 0xd06e(%rip)      # 0x75a48 <g.3>
   689da:      	je	0x7085f <f.2+0x180af>
   689e0:      	leaq	-0x11(%r12), %rsi
   689e5:      	movq	$0x0, 0x48(%rsp)
   689ee:      	movq	$0x3, 0x30(%rsp)
   689f7:      	xorl	%edi, %edi
   689f9:      	callq	0x70870 <f.3>
   689fe:      	subq	$0x8, %rsp
   68a02:      	movq	%rax, %r15
   68a05:      	addq	0x58(%rsp), %r15
   68a0a:      	movq	0x10(%rsp), %rcx
   68a0f:      	movq	0x18(%rsp), %rax
   68a14:      	movq	0x50(%rsp), %rdx
   68a19:      	cmpb	$0x0, 0xd030(%rip)      # 0x75a50 <g.4>
   68a20:      	je	0x7085f <f.2+0x180af>
   68a26:      	addq	%rdx, %r15
   68a29:      	addq	%rax, %r15
   68a2c:      	cmpq	$0x0, 0xd014(%rip)      # 0x75a48 <g.3>
   68a34:      	je	0x7085f <f.2+0x180af>
   68a3a:      	cmpq	$0xd, %r12
   68a3e:      	ja	0x68a4a <f.2+0x1029a>
   68a40:      	leaq	-0xc(%r12), %rdx
   68a45:      	jmp	0x68d13 <f.2+0x10563>
   68a4a:      	cmpq	$0xe, %r12
   68a4e:      	jne	0x68a68 <f.2+0x102b8>
   68a50:      	movl	$0x1, %edx
   68a55:      	cmpq	$0x0, 0xcfeb(%rip)      # 0x75a48 <g.3>
   68a5d:      	jne	0x68bc0 <f.2+0x10410>
   68a63:      	jmp	0x7085f <f.2+0x180af>
   68a68:      	cmpq	$0x10, %r12
   68a6c:      	jb	0x68b94 <f.2+0x103e4>
   68a72:      	movq	%rcx, 0x10(%rsp)
   68a77:      	leaq	-0xf(%r12), %rsi
   68a7c:      	movq	$0x0, 0x48(%rsp)
   68a85:      	movq	$0x3, 0x30(%rsp)
   68a8e:      	xorl	%edi, %edi
   68a90:      	callq	0x70870 <f.3>
   68a95:      	subq	$0x8, %rsp
   68a99:      	cmpb	$0x0, 0xcfb0(%rip)      # 0x75a50 <g.4>
   68aa0:      	je	0x7085f <f.2+0x180af>
   68aa6:      	movq	%rax, 0x18(%rsp)
   68aab:      	cmpq	$0x0, 0xcf95(%rip)      # 0x75a48 <g.3>
   68ab3:      	je	0x7085f <f.2+0x180af>
   68ab9:      	leaq	-0x10(%r12), %rsi
   68abe:      	movq	$0x0, 0x48(%rsp)
   68ac7:      	movq	$0x3, 0x30(%rsp)
   68ad0:      	xorl	%edi, %edi
   68ad2:      	callq	0x70870 <f.3>
   68ad7:      	subq	$0x8, %rsp
   68adb:      	cmpb	$0x0, 0xcf6e(%rip)      # 0x75a50 <g.4>
   68ae2:      	je	0x7085f <f.2+0x180af>
   68ae8:      	cmpq	$0x0, 0xcf58(%rip)      # 0x75a48 <g.3>
   68af0:      	movq	0x10(%rsp), %rcx
   68af5:      	je	0x7085f <f.2+0x180af>
   68afb:      	addq	0x18(%rsp), %rax
   68b00:      	cmpq	$0x10, %r12
   68b04:      	je	0x68ba7 <f.2+0x103f7>
   68b0a:      	movq	%rax, 0x18(%rsp)
   68b0f:      	movq	$0x0, 0x48(%rsp)
   68b18:      	movq	$0x3, 0x30(%rsp)
   68b21:      	xorl	%edi, %edi
   68b23:      	leaq	-0x10(%r12), %rsi
   68b28:      	callq	0x70870 <f.3>
   68b2d:      	subq	$0x8, %rsp
   68b31:      	cmpb	$0x0, 0xcf18(%rip)      # 0x75a50 <g.4>
   68b38:      	je	0x7085f <f.2+0x180af>
   68b3e:      	movq	%rax, 0x50(%rsp)
   68b43:      	cmpq	$0x0, 0xcefd(%rip)      # 0x75a48 <g.3>
   68b4b:      	je	0x7085f <f.2+0x180af>
   68b51:      	leaq	-0x11(%r12), %rsi
   68b56:      	movq	$0x0, 0x48(%rsp)
   68b5f:      	movq	$0x3, 0x30(%rsp)
   68b68:      	xorl	%edi, %edi
   68b6a:      	callq	0x70870 <f.3>
   68b6f:      	subq	$0x8, %rsp
   68b73:      	cmpb	$0x0, 0xced6(%rip)      # 0x75a50 <g.4>
   68b7a:      	je	0x7085f <f.2+0x180af>
   68b80:      	movq	%rax, %rdx
   68b83:      	addq	0x50(%rsp), %rdx
   68b88:      	addq	0x18(%rsp), %rdx
   68b8d:      	movq	0x10(%rsp), %rcx
   68b92:      	jmp	0x68bac <f.2+0x103fc>
   68b94:      	movl	$0x1, %eax
   68b99:      	cmpq	$0x0, 0xcea7(%rip)      # 0x75a48 <g.3>
   68ba1:      	je	0x7085f <f.2+0x180af>
   68ba7:      	leaq	-0xf(%r12,%rax), %rdx
   68bac:      	cmpq	$0x0, 0xce94(%rip)      # 0x75a48 <g.3>
   68bb4:      	je	0x7085f <f.2+0x180af>
   68bba:      	cmpq	$0xf, %r12
   68bbe:      	ja	0x68bca <f.2+0x1041a>
   68bc0:      	leaq	-0xe(%r12), %rsi
   68bc5:      	jmp	0x68d10 <f.2+0x10560>
   68bca:      	cmpq	$0x10, %r12
   68bce:      	jne	0x68be8 <f.2+0x10438>
   68bd0:      	movl	$0x1, %esi
   68bd5:      	cmpq	$0x0, 0xce6b(%rip)      # 0x75a48 <g.3>
   68bdd:      	jne	0x68c89 <f.2+0x104d9>
   68be3:      	jmp	0x7085f <f.2+0x180af>
   68be8:      	movq	%rdx, 0x18(%rsp)
   68bed:      	movq	%rcx, 0x10(%rsp)
   68bf2:      	leaq	-0x10(%r12), %rsi
   68bf7:      	movq	$0x0, 0x48(%rsp)
   68c00:      	movq	$0x3, 0x30(%rsp)
   68c09:      	xorl	%edi, %edi
   68c0b:      	callq	0x70870 <f.3>
   68c10:      	subq	$0x8, %rsp
   68c14:      	cmpb	$0x0, 0xce35(%rip)      # 0x75a50 <g.4>
   68c1b:      	je	0x7085f <f.2+0x180af>
   68c21:      	movq	%rax, 0x50(%rsp)
   68c26:      	cmpq	$0x0, 0xce1a(%rip)      # 0x75a48 <g.3>
   68c2e:      	je	0x7085f <f.2+0x180af>
   68c34:      	leaq	-0x11(%r12), %rsi
   68c39:      	movq	$0x0, 0x48(%rsp)
   68c42:      	movq	$0x3, 0x30(%rsp)
   68c4b:      	xorl	%edi, %edi
   68c4d:      	callq	0x70870 <f.3>
   68c52:      	subq	$0x8, %rsp
   68c56:      	cmpb	$0x0, 0xcdf3(%rip)      # 0x75a50 <g.4>
   68c5d:      	je	0x7085f <f.2+0x180af>
   68c63:      	cmpq	$0x0, 0xcddd(%rip)      # 0x75a48 <g.3>
   68c6b:      	movq	0x10(%rsp), %rcx
   68c70:      	movq	0x18(%rsp), %rdx
   68c75:      	je	0x7085f <f.2+0x180af>
   68c7b:      	movq	%rax, %rsi
   68c7e:      	addq	0x50(%rsp), %rsi
   68c83:      	cmpq	$0x11, %r12
   68c87:      	ja	0x68c90 <f.2+0x104e0>
   68c89:      	leaq	-0x10(%r12), %rax
   68c8e:      	jmp	0x68d0d <f.2+0x1055d>
   68c90:      	movq	%rsi, 0x50(%rsp)
   68c95:      	movq	$0x0, 0x48(%rsp)
   68c9e:      	movq	$0x3, 0x30(%rsp)
   68ca7:      	xorl	%edi, %edi
   68ca9:      	leaq	-0x11(%r12), %rsi
   68cae:      	callq	0x70870 <f.3>
   68cb3:      	subq	$0x8, %rsp
   68cb7:      	cmpb	$0x0, 0xcd92(%rip)      # 0x75a50 <g.4>
   68cbe:      	je	0x7085f <f.2+0x180af>
   68cc4:      	movq	%rax, 0x58(%rsp)
   68cc9:      	cmpq	$0x0, 0xcd77(%rip)      # 0x75a48 <g.3>
   68cd1:      	je	0x7085f <f.2+0x180af>
   68cd7:      	leaq	-0x12(%r12), %rsi
   68cdc:      	movq	$0x0, 0x48(%rsp)
   68ce5:      	movq	$0x3, 0x30(%rsp)
   68cee:      	xorl	%edi, %edi
   68cf0:      	callq	0x70870 <f.3>
   68cf5:      	subq	$0x8, %rsp
   68cf9:      	addq	0x58(%rsp), %rax
   68cfe:      	movq	0x10(%rsp), %rcx
   68d03:      	movq	0x18(%rsp), %rdx
   68d08:      	movq	0x50(%rsp), %rsi
   68d0d:      	addq	%rax, %rsi
   68d10:      	addq	%rsi, %rdx
   68d13:      	addq	%rdx, %r15
   68d16:      	cmpb	$0x0, 0xcd33(%rip)      # 0x75a50 <g.4>
   68d1d:      	je	0x7085f <f.2+0x180af>
   68d23:      	addq	%rcx, %r15
   68d26:      	addq	%rbp, %r15
   68d29:      	cmpq	$0x0, 0xcd17(%rip)      # 0x75a48 <g.3>
   68d31:      	je	0x7085f <f.2+0x180af>
   68d37:      	cmpq	$0x8, %r12
   68d3b:      	ja	0x68dd3 <f.2+0x10623>
   68d41:      	leaq	-0x7(%r12), %rbp
   68d46:      	cmpb	$0x0, 0xcd03(%rip)      # 0x75a50 <g.4>
   68d4d:      	je	0x7085f <f.2+0x180af>
   68d53:      	addq	%r15, %rbp
   68d56:      	addq	%r14, %rbp
   68d59:      	leaq	0x68(%rsp), %r15
   68d5e:      	cmpq	$0x0, 0xcce2(%rip)      # 0x75a48 <g.3>
   68d66:      	je	0x7085f <f.2+0x180af>
   68d6c:      	cmpq	$0x5, %r12
   68d70:      	ja	0x68d7b <f.2+0x105cb>
   68d72:      	addq	$-0x4, %r12
   68d76:      	jmp	0x707e7 <f.2+0x18037>
   68d7b:      	cmpq	$0x6, %r12
   68d7f:      	jne	0x68d99 <f.2+0x105e9>
   68d81:      	movl	$0x1, %ecx
   68d86:      	cmpq	$0x0, 0xccba(%rip)      # 0x75a48 <g.3>
   68d8e:      	jne	0x6d61c <f.2+0x14e6c>
   68d94:      	jmp	0x7085f <f.2+0x180af>
   68d99:      	cmpq	$0x8, %r12
   68d9d:      	jb	0x68dba <f.2+0x1060a>
   68d9f:      	jne	0x68df1 <f.2+0x10641>
   68da1:      	movl	$0x1, %r15d
   68da7:      	cmpq	$0x0, 0xcc99(%rip)      # 0x75a48 <g.3>
   68daf:      	jne	0x69ed3 <f.2+0x11723>
   68db5:      	jmp	0x7085f <f.2+0x180af>
   68dba:      	movl	$0x1, %r14d
   68dc0:      	cmpq	$0x0, 0xcc80(%rip)      # 0x75a48 <g.3>
   68dc8:      	jne	0x6bd25 <f.2+0x13575>
   68dce:      	jmp	0x7085f <f.2+0x180af>
   68dd3:      	cmpq	$0x9, %r12
   68dd7:      	jne	0x68e12 <f.2+0x10662>
   68dd9:      	movl	$0x1, %ebp
   68dde:      	cmpq	$0x0, 0xcc62(%rip)      # 0x75a48 <g.3>
   68de6:      	jne	0x6b0d7 <f.2+0x12927>
   68dec:      	jmp	0x7085f <f.2+0x180af>
   68df1:      	cmpq	$0xa, %r12
   68df5:      	jb	0x68e32 <f.2+0x10682>
   68df7:      	jne	0x68e63 <f.2+0x106b3>
   68df9:      	movl	$0x1, %r15d
   68dff:      	cmpq	$0x0, 0xcc41(%rip)      # 0x75a48 <g.3>
   68e07:      	jne	0x691ed <f.2+0x10a3d>
   68e0d:      	jmp	0x7085f <f.2+0x180af>
   68e12:      	cmpq	$0xb, %r12
   68e16:      	jb	0x68e4b <f.2+0x1069b>
   68e18:      	jne	0x68e84 <f.2+0x106d4>
   68e1a:      	movl	$0x1, %ebp
   68e1f:      	cmpq	$0x0, 0xcc21(%rip)      # 0x75a48 <g.3>
   68e27:      	jne	0x69625 <f.2+0x10e75>
   68e2d:      	jmp	0x7085f <f.2+0x180af>
   68e32:      	movl	$0x1, %r14d
   68e38:      	cmpq	$0x0, 0xcc08(%rip)      # 0x75a48 <g.3>
   68e40:      	jne	0x69901 <f.2+0x11151>
   68e46:      	jmp	0x7085f <f.2+0x180af>
   68e4b:      	movl	$0x1, %ecx
   68e50:      	cmpq	$0x0, 0xcbf0(%rip)      # 0x75a48 <g.3>
   68e58:      	jne	0x6a7d4 <f.2+0x12024>
   68e5e:      	jmp	0x7085f <f.2+0x180af>
   68e63:      	cmpq	$0xc, %r12
   68e67:      	jb	0x68ea8 <f.2+0x106f8>
   68e69:      	jne	0x68ed9 <f.2+0x10729>
   68e6b:      	movl	$0x1, %r15d
   68e71:      	cmpq	$0x0, 0xcbcf(%rip)      # 0x75a48 <g.3>
   68e79:      	jne	0x68f66 <f.2+0x107b6>
   68e7f:      	jmp	0x7085f <f.2+0x180af>
   68e84:      	cmpq	$0xd, %r12
   68e88:      	jb	0x68ec1 <f.2+0x10711>
   68e8a:      	jne	0x68f70 <f.2+0x107c0>
   68e90:      	movl	$0x1, %ebp
   68e95:      	cmpq	$0x0, 0xcbab(%rip)      # 0x75a48 <g.3>
   68e9d:      	jne	0x69001 <f.2+0x10851>
   68ea3:      	jmp	0x7085f <f.2+0x180af>
   68ea8:      	movl	$0x1, %r14d
   68eae:      	cmpq	$0x0, 0xcb92(%rip)      # 0x75a48 <g.3>
   68eb6:      	jne	0x690a1 <f.2+0x108f1>
   68ebc:      	jmp	0x7085f <f.2+0x180af>
   68ec1:      	movl	$0x1, %eax
   68ec6:      	cmpq	$0x0, 0xcb7a(%rip)      # 0x75a48 <g.3>
   68ece:      	jne	0x6941b <f.2+0x10c6b>
   68ed4:      	jmp	0x7085f <f.2+0x180af>
   68ed9:      	leaq	-0xc(%r12), %rsi
   68ede:      	movq	$0x0, 0x48(%rsp)
   68ee7:      	movq	$0x3, 0x30(%rsp)
   68ef0:      	xorl	%edi, %edi
   68ef2:      	callq	0x70870 <f.3>
   68ef7:      	subq	$0x8, %rsp
   68efb:      	cmpb	$0x0, 0xcb4e(%rip)      # 0x75a50 <g.4>
   68f02:      	je	0x7085f <f.2+0x180af>
   68f08:      	cmpq	$0x0, 0xcb38(%rip)      # 0x75a48 <g.3>
   68f10:      	je	0x7085f <f.2+0x180af>
   68f16:      	movq	%rax, %r14
   68f19:      	leaq	-0xd(%r12), %rsi
   68f1e:      	movq	$0x0, 0x48(%rsp)
   68f27:      	movq	$0x3, 0x30(%rsp)
   68f30:      	xorl	%edi, %edi
   68f32:      	callq	0x70870 <f.3>
   68f37:      	subq	$0x8, %rsp
   68f3b:      	cmpb	$0x0, 0xcb0e(%rip)      # 0x75a50 <g.4>
   68f42:      	je	0x7085f <f.2+0x180af>
   68f48:      	cmpq	$0x0, 0xcaf8(%rip)      # 0x75a48 <g.3>
   68f50:      	je	0x7085f <f.2+0x180af>
   68f56:      	movq	%rax, %r15
   68f59:      	addq	%r14, %r15
   68f5c:      	cmpq	$0xd, %r12
   68f60:      	ja	0x6900b <f.2+0x1085b>
   68f66:      	leaq	-0xc(%r12,%r15), %r14
   68f6b:      	jmp	0x69087 <f.2+0x108d7>
   68f70:      	leaq	-0xd(%r12), %rsi
   68f75:      	movq	$0x0, 0x48(%rsp)
   68f7e:      	movq	$0x3, 0x30(%rsp)
   68f87:      	xorl	%edi, %edi
   68f89:      	callq	0x70870 <f.3>
   68f8e:      	subq	$0x8, %rsp
   68f92:      	cmpb	$0x0, 0xcab7(%rip)      # 0x75a50 <g.4>
   68f99:      	je	0x7085f <f.2+0x180af>
   68f9f:      	movq	%rax, 0x10(%rsp)
   68fa4:      	cmpq	$0x0, 0xca9c(%rip)      # 0x75a48 <g.3>
   68fac:      	je	0x7085f <f.2+0x180af>
   68fb2:      	leaq	-0xe(%r12), %rsi
   68fb7:      	movq	$0x0, 0x48(%rsp)
   68fc0:      	movq	$0x3, 0x30(%rsp)
   68fc9:      	xorl	%edi, %edi
   68fcb:      	callq	0x70870 <f.3>
   68fd0:      	subq	$0x8, %rsp
   68fd4:      	cmpb	$0x0, 0xca75(%rip)      # 0x75a50 <g.4>
   68fdb:      	je	0x7085f <f.2+0x180af>
   68fe1:      	cmpq	$0x0, 0xca5f(%rip)      # 0x75a48 <g.3>
   68fe9:      	je	0x7085f <f.2+0x180af>
   68fef:      	movq	%rax, %rbp
   68ff2:      	addq	0x10(%rsp), %rbp
   68ff7:      	cmpq	$0xe, %r12
   68ffb:      	ja	0x69388 <f.2+0x10bd8>
   69001:      	leaq	-0xd(%r12,%rbp), %rax
   69006:      	jmp	0x69401 <f.2+0x10c51>
   6900b:      	movq	$0x0, 0x48(%rsp)
   69014:      	movq	$0x3, 0x30(%rsp)
   6901d:      	xorl	%edi, %edi
   6901f:      	leaq	-0xd(%r12), %rsi
   69024:      	callq	0x70870 <f.3>
   69029:      	subq	$0x8, %rsp
   6902d:      	cmpb	$0x0, 0xca1c(%rip)      # 0x75a50 <g.4>
   69034:      	je	0x7085f <f.2+0x180af>
   6903a:      	movq	%rax, 0x10(%rsp)
   6903f:      	cmpq	$0x0, 0xca01(%rip)      # 0x75a48 <g.3>
   69047:      	je	0x7085f <f.2+0x180af>
   6904d:      	leaq	-0xe(%r12), %rsi
   69052:      	movq	$0x0, 0x48(%rsp)
   6905b:      	movq	$0x3, 0x30(%rsp)
   69064:      	xorl	%edi, %edi
   69066:      	callq	0x70870 <f.3>
   6906b:      	subq	$0x8, %rsp
   6906f:      	cmpb	$0x0, 0xc9da(%rip)      # 0x75a50 <g.4>
   69076:      	je	0x7085f <f.2+0x180af>
   6907c:      	movq	%rax, %r14
   6907f:      	addq	0x10(%rsp), %r14
   69084:      	addq	%r15, %r14
   69087:      	cmpq	$0x0, 0xc9b9(%rip)      # 0x75a48 <g.3>
   6908f:      	je	0x7085f <f.2+0x180af>
   69095:      	cmpq	$0xd, %r12
   69099:      	je	0x690ab <f.2+0x108fb>
   6909b:      	cmpq	$0xc, %r12
   6909f:      	jne	0x690c3 <f.2+0x10913>
   690a1:      	leaq	-0xb(%r12,%r14), %r15
   690a6:      	jmp	0x691d9 <f.2+0x10a29>
   690ab:      	movl	$0x1, %eax
   690b0:      	cmpq	$0x0, 0xc990(%rip)      # 0x75a48 <g.3>
   690b8:      	jne	0x69149 <f.2+0x10999>
   690be:      	jmp	0x7085f <f.2+0x180af>
   690c3:      	leaq	-0xd(%r12), %rsi
   690c8:      	movq	$0x0, 0x48(%rsp)
   690d1:      	movq	$0x3, 0x30(%rsp)
   690da:      	xorl	%edi, %edi
   690dc:      	callq	0x70870 <f.3>
   690e1:      	subq	$0x8, %rsp
   690e5:      	cmpb	$0x0, 0xc964(%rip)      # 0x75a50 <g.4>
   690ec:      	je	0x7085f <f.2+0x180af>
   690f2:      	cmpq	$0x0, 0xc94e(%rip)      # 0x75a48 <g.3>
   690fa:      	je	0x7085f <f.2+0x180af>
   69100:      	movq	%rax, %r15
   69103:      	leaq	-0xe(%r12), %rsi
   69108:      	movq	$0x0, 0x48(%rsp)
   69111:      	movq	$0x3, 0x30(%rsp)
   6911a:      	xorl	%edi, %edi
   6911c:      	callq	0x70870 <f.3>
   69121:      	subq	$0x8, %rsp
   69125:      	cmpb	$0x0, 0xc924(%rip)      # 0x75a50 <g.4>
   6912c:      	je	0x7085f <f.2+0x180af>
   69132:      	cmpq	$0x0, 0xc90e(%rip)      # 0x75a48 <g.3>
   6913a:      	je	0x7085f <f.2+0x180af>
   69140:      	addq	%r15, %rax
   69143:      	cmpq	$0xe, %r12
   69147:      	ja	0x69150 <f.2+0x109a0>
   69149:      	leaq	-0xd(%r12), %r15
   6914e:      	jmp	0x691c6 <f.2+0x10a16>
   69150:      	movq	%rax, 0x10(%rsp)
   69155:      	movq	$0x0, 0x48(%rsp)
   6915e:      	movq	$0x3, 0x30(%rsp)
   69167:      	xorl	%edi, %edi
   69169:      	leaq	-0xe(%r12), %rsi
   6916e:      	callq	0x70870 <f.3>
   69173:      	subq	$0x8, %rsp
   69177:      	cmpb	$0x0, 0xc8d2(%rip)      # 0x75a50 <g.4>
   6917e:      	je	0x7085f <f.2+0x180af>
   69184:      	movq	%rax, 0x18(%rsp)
   69189:      	cmpq	$0x0, 0xc8b7(%rip)      # 0x75a48 <g.3>
   69191:      	je	0x7085f <f.2+0x180af>
   69197:      	leaq	-0xf(%r12), %rsi
   6919c:      	movq	$0x0, 0x48(%rsp)
   691a5:      	movq	$0x3, 0x30(%rsp)
   691ae:      	xorl	%edi, %edi
   691b0:      	callq	0x70870 <f.3>
   691b5:      	subq	$0x8, %rsp
   691b9:      	movq	%rax, %r15
   691bc:      	addq	0x18(%rsp), %r15
   691c1:      	movq	0x10(%rsp), %rax
   691c6:      	cmpb	$0x0, 0xc883(%rip)      # 0x75a50 <g.4>
   691cd:      	je	0x7085f <f.2+0x180af>
   691d3:      	addq	%rax, %r15
   691d6:      	addq	%r14, %r15
   691d9:      	cmpq	$0x0, 0xc867(%rip)      # 0x75a48 <g.3>
   691e1:      	je	0x7085f <f.2+0x180af>
   691e7:      	cmpq	$0xb, %r12
   691eb:      	ja	0x691f7 <f.2+0x10a47>
   691ed:      	leaq	-0xa(%r12,%r15), %r14
   691f2:      	jmp	0x698e7 <f.2+0x11137>
   691f7:      	cmpq	$0xc, %r12
   691fb:      	jne	0x69215 <f.2+0x10a65>
   691fd:      	movl	$0x1, %ecx
   69202:      	cmpq	$0x0, 0xc83e(%rip)      # 0x75a48 <g.3>
   6920a:      	jne	0x6935b <f.2+0x10bab>
   69210:      	jmp	0x7085f <f.2+0x180af>
   69215:      	cmpq	$0xe, %r12
   69219:      	jb	0x6932e <f.2+0x10b7e>
   6921f:      	leaq	-0xd(%r12), %rsi
   69224:      	movq	$0x0, 0x48(%rsp)
   6922d:      	movq	$0x3, 0x30(%rsp)
   69236:      	xorl	%edi, %edi
   69238:      	callq	0x70870 <f.3>
   6923d:      	subq	$0x8, %rsp
   69241:      	cmpb	$0x0, 0xc808(%rip)      # 0x75a50 <g.4>
   69248:      	je	0x7085f <f.2+0x180af>
   6924e:      	movq	%rax, 0x10(%rsp)
   69253:      	cmpq	$0x0, 0xc7ed(%rip)      # 0x75a48 <g.3>
   6925b:      	je	0x7085f <f.2+0x180af>
   69261:      	leaq	-0xe(%r12), %rsi
   69266:      	movq	$0x0, 0x48(%rsp)
   6926f:      	movq	$0x3, 0x30(%rsp)
   69278:      	xorl	%edi, %edi
   6927a:      	callq	0x70870 <f.3>
   6927f:      	subq	$0x8, %rsp
   69283:      	cmpb	$0x0, 0xc7c6(%rip)      # 0x75a50 <g.4>
   6928a:      	je	0x7085f <f.2+0x180af>
   69290:      	cmpq	$0x0, 0xc7b0(%rip)      # 0x75a48 <g.3>
   69298:      	je	0x7085f <f.2+0x180af>
   6929e:      	movq	%rax, %r14
   692a1:      	addq	0x10(%rsp), %r14
   692a6:      	cmpq	$0xe, %r12
   692aa:      	je	0x69342 <f.2+0x10b92>
   692b0:      	movq	$0x0, 0x48(%rsp)
   692b9:      	movq	$0x3, 0x30(%rsp)
   692c2:      	xorl	%edi, %edi
   692c4:      	leaq	-0xe(%r12), %rsi
   692c9:      	callq	0x70870 <f.3>
   692ce:      	subq	$0x8, %rsp
   692d2:      	cmpb	$0x0, 0xc777(%rip)      # 0x75a50 <g.4>
   692d9:      	je	0x7085f <f.2+0x180af>
   692df:      	movq	%rax, 0x10(%rsp)
   692e4:      	cmpq	$0x0, 0xc75c(%rip)      # 0x75a48 <g.3>
   692ec:      	je	0x7085f <f.2+0x180af>
   692f2:      	leaq	-0xf(%r12), %rsi
   692f7:      	movq	$0x0, 0x48(%rsp)
   69300:      	movq	$0x3, 0x30(%rsp)
   69309:      	xorl	%edi, %edi
   6930b:      	callq	0x70870 <f.3>
   69310:      	subq	$0x8, %rsp
   69314:      	cmpb	$0x0, 0xc735(%rip)      # 0x75a50 <g.4>
   6931b:      	je	0x7085f <f.2+0x180af>
   69321:      	movq	%rax, %rcx
   69324:      	addq	0x10(%rsp), %rcx
   69329:      	addq	%r14, %rcx
   6932c:      	jmp	0x69347 <f.2+0x10b97>
   6932e:      	movl	$0x1, %r14d
   69334:      	cmpq	$0x0, 0xc70c(%rip)      # 0x75a48 <g.3>
   6933c:      	je	0x7085f <f.2+0x180af>
   69342:      	leaq	-0xd(%r12,%r14), %rcx
   69347:      	cmpq	$0x0, 0xc6f9(%rip)      # 0x75a48 <g.3>
   6934f:      	je	0x7085f <f.2+0x180af>
   69355:      	cmpq	$0xd, %r12
   69359:      	ja	0x69365 <f.2+0x10bb5>
   6935b:      	leaq	-0xc(%r12), %r14
   69360:      	jmp	0x698d4 <f.2+0x11124>
   69365:      	cmpq	$0xe, %r12
   69369:      	jne	0x694de <f.2+0x10d2e>
   6936f:      	movl	$0x1, %r14d
   69375:      	cmpq	$0x0, 0xc6cb(%rip)      # 0x75a48 <g.3>
   6937d:      	jne	0x69579 <f.2+0x10dc9>
   69383:      	jmp	0x7085f <f.2+0x180af>
   69388:      	movq	$0x0, 0x48(%rsp)
   69391:      	movq	$0x3, 0x30(%rsp)
   6939a:      	xorl	%edi, %edi
   6939c:      	leaq	-0xe(%r12), %rsi
   693a1:      	callq	0x70870 <f.3>
   693a6:      	subq	$0x8, %rsp
   693aa:      	cmpb	$0x0, 0xc69f(%rip)      # 0x75a50 <g.4>
   693b1:      	je	0x7085f <f.2+0x180af>
   693b7:      	movq	%rax, 0x10(%rsp)
   693bc:      	cmpq	$0x0, 0xc684(%rip)      # 0x75a48 <g.3>
   693c4:      	je	0x7085f <f.2+0x180af>
   693ca:      	leaq	-0xf(%r12), %rsi
   693cf:      	movq	$0x0, 0x48(%rsp)
   693d8:      	movq	$0x3, 0x30(%rsp)
   693e1:      	xorl	%edi, %edi
   693e3:      	callq	0x70870 <f.3>
   693e8:      	subq	$0x8, %rsp
   693ec:      	cmpb	$0x0, 0xc65d(%rip)      # 0x75a50 <g.4>
   693f3:      	je	0x7085f <f.2+0x180af>
   693f9:      	addq	0x10(%rsp), %rax
   693fe:      	addq	%rbp, %rax
   69401:      	cmpq	$0x0, 0xc63f(%rip)      # 0x75a48 <g.3>
   69409:      	je	0x7085f <f.2+0x180af>
   6940f:      	cmpq	$0xe, %r12
   69413:      	je	0x69425 <f.2+0x10c75>
   69415:      	cmpq	$0xd, %r12
   69419:      	jne	0x6943d <f.2+0x10c8d>
   6941b:      	leaq	-0xc(%r12,%rax), %rbp
   69420:      	jmp	0x69611 <f.2+0x10e61>
   69425:      	movl	$0x1, %ecx
   6942a:      	cmpq	$0x0, 0xc616(%rip)      # 0x75a48 <g.3>
   69432:      	jne	0x694d4 <f.2+0x10d24>
   69438:      	jmp	0x7085f <f.2+0x180af>
   6943d:      	movq	%rax, 0x10(%rsp)
   69442:      	leaq	-0xe(%r12), %rsi
   69447:      	movq	$0x0, 0x48(%rsp)
   69450:      	movq	$0x3, 0x30(%rsp)
   69459:      	xorl	%edi, %edi
   6945b:      	callq	0x70870 <f.3>
   69460:      	subq	$0x8, %rsp
   69464:      	cmpb	$0x0, 0xc5e5(%rip)      # 0x75a50 <g.4>
   6946b:      	je	0x7085f <f.2+0x180af>
   69471:      	cmpq	$0x0, 0xc5cf(%rip)      # 0x75a48 <g.3>
   69479:      	je	0x7085f <f.2+0x180af>
   6947f:      	movq	%rax, %rbp
   69482:      	leaq	-0xf(%r12), %rsi
   69487:      	movq	$0x0, 0x48(%rsp)
   69490:      	movq	$0x3, 0x30(%rsp)
   69499:      	xorl	%edi, %edi
   6949b:      	callq	0x70870 <f.3>
   694a0:      	subq	$0x8, %rsp
   694a4:      	cmpb	$0x0, 0xc5a5(%rip)      # 0x75a50 <g.4>
   694ab:      	je	0x7085f <f.2+0x180af>
   694b1:      	movq	%rax, %rcx
   694b4:      	cmpq	$0x0, 0xc58c(%rip)      # 0x75a48 <g.3>
   694bc:      	movq	0x10(%rsp), %rax
   694c1:      	je	0x7085f <f.2+0x180af>
   694c7:      	addq	%rbp, %rcx
   694ca:      	cmpq	$0xf, %r12
   694ce:      	ja	0x69583 <f.2+0x10dd3>
   694d4:      	leaq	-0xe(%r12), %rbp
   694d9:      	jmp	0x695fe <f.2+0x10e4e>
   694de:      	movq	%rcx, 0x10(%rsp)
   694e3:      	leaq	-0xe(%r12), %rsi
   694e8:      	movq	$0x0, 0x48(%rsp)
   694f1:      	movq	$0x3, 0x30(%rsp)
   694fa:      	xorl	%edi, %edi
   694fc:      	callq	0x70870 <f.3>
   69501:      	subq	$0x8, %rsp
   69505:      	cmpb	$0x0, 0xc544(%rip)      # 0x75a50 <g.4>
   6950c:      	je	0x7085f <f.2+0x180af>
   69512:      	movq	%rax, 0x18(%rsp)
   69517:      	cmpq	$0x0, 0xc529(%rip)      # 0x75a48 <g.3>
   6951f:      	je	0x7085f <f.2+0x180af>
   69525:      	leaq	-0xf(%r12), %rsi
   6952a:      	movq	$0x0, 0x48(%rsp)
   69533:      	movq	$0x3, 0x30(%rsp)
   6953c:      	xorl	%edi, %edi
   6953e:      	callq	0x70870 <f.3>
   69543:      	subq	$0x8, %rsp
   69547:      	cmpb	$0x0, 0xc502(%rip)      # 0x75a50 <g.4>
   6954e:      	je	0x7085f <f.2+0x180af>
   69554:      	cmpq	$0x0, 0xc4ec(%rip)      # 0x75a48 <g.3>
   6955c:      	movq	0x10(%rsp), %rcx
   69561:      	je	0x7085f <f.2+0x180af>
   69567:      	movq	%rax, %r14
   6956a:      	addq	0x18(%rsp), %r14
   6956f:      	cmpq	$0xf, %r12
   69573:      	ja	0x69863 <f.2+0x110b3>
   69579:      	leaq	-0xe(%r12), %rax
   6957e:      	jmp	0x698d1 <f.2+0x11121>
   69583:      	movq	%rcx, 0x18(%rsp)
   69588:      	movq	$0x0, 0x48(%rsp)
   69591:      	movq	$0x3, 0x30(%rsp)
   6959a:      	xorl	%edi, %edi
   6959c:      	leaq	-0xf(%r12), %rsi
   695a1:      	callq	0x70870 <f.3>
   695a6:      	subq	$0x8, %rsp
   695aa:      	cmpb	$0x0, 0xc49f(%rip)      # 0x75a50 <g.4>
   695b1:      	je	0x7085f <f.2+0x180af>
   695b7:      	movq	%rax, 0x50(%rsp)
   695bc:      	cmpq	$0x0, 0xc484(%rip)      # 0x75a48 <g.3>
   695c4:      	je	0x7085f <f.2+0x180af>
   695ca:      	leaq	-0x10(%r12), %rsi
   695cf:      	movq	$0x0, 0x48(%rsp)
   695d8:      	movq	$0x3, 0x30(%rsp)
   695e1:      	xorl	%edi, %edi
   695e3:      	callq	0x70870 <f.3>
   695e8:      	subq	$0x8, %rsp
   695ec:      	movq	%rax, %rbp
   695ef:      	addq	0x50(%rsp), %rbp
   695f4:      	movq	0x10(%rsp), %rax
   695f9:      	movq	0x18(%rsp), %rcx
   695fe:      	cmpb	$0x0, 0xc44b(%rip)      # 0x75a50 <g.4>
   69605:      	je	0x7085f <f.2+0x180af>
   6960b:      	addq	%rcx, %rbp
   6960e:      	addq	%rax, %rbp
   69611:      	cmpq	$0x0, 0xc42f(%rip)      # 0x75a48 <g.3>
   69619:      	je	0x7085f <f.2+0x180af>
   6961f:      	cmpq	$0xc, %r12
   69623:      	ja	0x6962f <f.2+0x10e7f>
   69625:      	leaq	-0xb(%r12,%rbp), %rcx
   6962a:      	jmp	0x6a7ba <f.2+0x1200a>
   6962f:      	cmpq	$0xd, %r12
   69633:      	jne	0x6964d <f.2+0x10e9d>
   69635:      	movl	$0x1, %edx
   6963a:      	cmpq	$0x0, 0xc406(%rip)      # 0x75a48 <g.3>
   69642:      	jne	0x69796 <f.2+0x10fe6>
   69648:      	jmp	0x7085f <f.2+0x180af>
   6964d:      	cmpq	$0xf, %r12
   69651:      	jb	0x6976a <f.2+0x10fba>
   69657:      	leaq	-0xe(%r12), %rsi
   6965c:      	movq	$0x0, 0x48(%rsp)
   69665:      	movq	$0x3, 0x30(%rsp)
   6966e:      	xorl	%edi, %edi
   69670:      	callq	0x70870 <f.3>
   69675:      	subq	$0x8, %rsp
   69679:      	cmpb	$0x0, 0xc3d0(%rip)      # 0x75a50 <g.4>
   69680:      	je	0x7085f <f.2+0x180af>
   69686:      	movq	%rax, 0x10(%rsp)
   6968b:      	cmpq	$0x0, 0xc3b5(%rip)      # 0x75a48 <g.3>
   69693:      	je	0x7085f <f.2+0x180af>
   69699:      	leaq	-0xf(%r12), %rsi
   6969e:      	movq	$0x0, 0x48(%rsp)
   696a7:      	movq	$0x3, 0x30(%rsp)
   696b0:      	xorl	%edi, %edi
   696b2:      	callq	0x70870 <f.3>
   696b7:      	subq	$0x8, %rsp
   696bb:      	cmpb	$0x0, 0xc38e(%rip)      # 0x75a50 <g.4>
   696c2:      	je	0x7085f <f.2+0x180af>
   696c8:      	cmpq	$0x0, 0xc378(%rip)      # 0x75a48 <g.3>
   696d0:      	je	0x7085f <f.2+0x180af>
   696d6:      	addq	0x10(%rsp), %rax
   696db:      	cmpq	$0xf, %r12
   696df:      	je	0x6977d <f.2+0x10fcd>
   696e5:      	movq	%rax, 0x10(%rsp)
   696ea:      	movq	$0x0, 0x48(%rsp)
   696f3:      	movq	$0x3, 0x30(%rsp)
   696fc:      	xorl	%edi, %edi
   696fe:      	leaq	-0xf(%r12), %rsi
   69703:      	callq	0x70870 <f.3>
   69708:      	subq	$0x8, %rsp
   6970c:      	cmpb	$0x0, 0xc33d(%rip)      # 0x75a50 <g.4>
   69713:      	je	0x7085f <f.2+0x180af>
   69719:      	movq	%rax, 0x18(%rsp)
   6971e:      	cmpq	$0x0, 0xc322(%rip)      # 0x75a48 <g.3>
   69726:      	je	0x7085f <f.2+0x180af>
   6972c:      	leaq	-0x10(%r12), %rsi
   69731:      	movq	$0x0, 0x48(%rsp)
   6973a:      	movq	$0x3, 0x30(%rsp)
   69743:      	xorl	%edi, %edi
   69745:      	callq	0x70870 <f.3>
   6974a:      	subq	$0x8, %rsp
   6974e:      	cmpb	$0x0, 0xc2fb(%rip)      # 0x75a50 <g.4>
   69755:      	je	0x7085f <f.2+0x180af>
   6975b:      	movq	%rax, %rdx
   6975e:      	addq	0x18(%rsp), %rdx
   69763:      	addq	0x10(%rsp), %rdx
   69768:      	jmp	0x69782 <f.2+0x10fd2>
   6976a:      	movl	$0x1, %eax
   6976f:      	cmpq	$0x0, 0xc2d1(%rip)      # 0x75a48 <g.3>
   69777:      	je	0x7085f <f.2+0x180af>
   6977d:      	leaq	-0xe(%r12,%rax), %rdx
   69782:      	cmpq	$0x0, 0xc2be(%rip)      # 0x75a48 <g.3>
   6978a:      	je	0x7085f <f.2+0x180af>
   69790:      	cmpq	$0xe, %r12
   69794:      	ja	0x697a0 <f.2+0x10ff0>
   69796:      	leaq	-0xd(%r12), %rcx
   6979b:      	jmp	0x6a7a7 <f.2+0x11ff7>
   697a0:      	cmpq	$0xf, %r12
   697a4:      	jne	0x697be <f.2+0x1100e>
   697a6:      	movl	$0x1, %ecx
   697ab:      	cmpq	$0x0, 0xc295(%rip)      # 0x75a48 <g.3>
   697b3:      	jne	0x69859 <f.2+0x110a9>
   697b9:      	jmp	0x7085f <f.2+0x180af>
   697be:      	movq	%rdx, 0x18(%rsp)
   697c3:      	leaq	-0xf(%r12), %rsi
   697c8:      	movq	$0x0, 0x48(%rsp)
   697d1:      	movq	$0x3, 0x30(%rsp)
   697da:      	xorl	%edi, %edi
   697dc:      	callq	0x70870 <f.3>
   697e1:      	subq	$0x8, %rsp
   697e5:      	cmpb	$0x0, 0xc264(%rip)      # 0x75a50 <g.4>
   697ec:      	je	0x7085f <f.2+0x180af>
   697f2:      	movq	%rax, 0x10(%rsp)
   697f7:      	cmpq	$0x0, 0xc249(%rip)      # 0x75a48 <g.3>
   697ff:      	je	0x7085f <f.2+0x180af>
   69805:      	leaq	-0x10(%r12), %rsi
   6980a:      	movq	$0x0, 0x48(%rsp)
   69813:      	movq	$0x3, 0x30(%rsp)
   6981c:      	xorl	%edi, %edi
   6981e:      	callq	0x70870 <f.3>
   69823:      	subq	$0x8, %rsp
   69827:      	cmpb	$0x0, 0xc222(%rip)      # 0x75a50 <g.4>
   6982e:      	je	0x7085f <f.2+0x180af>
   69834:      	cmpq	$0x0, 0xc20c(%rip)      # 0x75a48 <g.3>
   6983c:      	movq	0x18(%rsp), %rdx
   69841:      	je	0x7085f <f.2+0x180af>
   69847:      	movq	%rax, %rcx
   6984a:      	addq	0x10(%rsp), %rcx
   6984f:      	cmpq	$0x10, %r12
   69853:      	ja	0x6a72c <f.2+0x11f7c>
   69859:      	leaq	-0xf(%r12), %rax
   6985e:      	jmp	0x6a7a4 <f.2+0x11ff4>
   69863:      	movq	$0x0, 0x48(%rsp)
   6986c:      	movq	$0x3, 0x30(%rsp)
   69875:      	xorl	%edi, %edi
   69877:      	leaq	-0xf(%r12), %rsi
   6987c:      	callq	0x70870 <f.3>
   69881:      	subq	$0x8, %rsp
   69885:      	cmpb	$0x0, 0xc1c4(%rip)      # 0x75a50 <g.4>
   6988c:      	je	0x7085f <f.2+0x180af>
   69892:      	movq	%rax, 0x18(%rsp)
   69897:      	cmpq	$0x0, 0xc1a9(%rip)      # 0x75a48 <g.3>
   6989f:      	je	0x7085f <f.2+0x180af>
   698a5:      	leaq	-0x10(%r12), %rsi
   698aa:      	movq	$0x0, 0x48(%rsp)
   698b3:      	movq	$0x3, 0x30(%rsp)
   698bc:      	xorl	%edi, %edi
   698be:      	callq	0x70870 <f.3>
   698c3:      	subq	$0x8, %rsp
   698c7:      	addq	0x18(%rsp), %rax
   698cc:      	movq	0x10(%rsp), %rcx
   698d1:      	addq	%rax, %r14
   698d4:      	cmpb	$0x0, 0xc175(%rip)      # 0x75a50 <g.4>
   698db:      	je	0x7085f <f.2+0x180af>
   698e1:      	addq	%rcx, %r14
   698e4:      	addq	%r15, %r14
   698e7:      	cmpq	$0x0, 0xc159(%rip)      # 0x75a48 <g.3>
   698ef:      	je	0x7085f <f.2+0x180af>
   698f5:      	cmpq	$0xb, %r12
   698f9:      	je	0x69919 <f.2+0x11169>
   698fb:      	cmpq	$0xa, %r12
   698ff:      	jne	0x69931 <f.2+0x11181>
   69901:      	leaq	-0x9(%r12,%r14), %r15
   69906:      	cmpq	$0x0, 0xc13a(%rip)      # 0x75a48 <g.3>
   6990e:      	jne	0x69ecd <f.2+0x1171d>
   69914:      	jmp	0x7085f <f.2+0x180af>
   69919:      	movl	$0x1, %ecx
   6991e:      	cmpq	$0x0, 0xc122(%rip)      # 0x75a48 <g.3>
   69926:      	jne	0x69beb <f.2+0x1143b>
   6992c:      	jmp	0x7085f <f.2+0x180af>
   69931:      	cmpq	$0xd, %r12
   69935:      	jb	0x69952 <f.2+0x111a2>
   69937:      	jne	0x6996a <f.2+0x111ba>
   69939:      	movl	$0x1, %r15d
   6993f:      	cmpq	$0x0, 0xc101(%rip)      # 0x75a48 <g.3>
   69947:      	jne	0x699f7 <f.2+0x11247>
   6994d:      	jmp	0x7085f <f.2+0x180af>
   69952:      	movl	$0x1, %eax
   69957:      	cmpq	$0x0, 0xc0e9(%rip)      # 0x75a48 <g.3>
   6995f:      	jne	0x69a91 <f.2+0x112e1>
   69965:      	jmp	0x7085f <f.2+0x180af>
   6996a:      	leaq	-0xd(%r12), %rsi
   6996f:      	movq	$0x0, 0x48(%rsp)
   69978:      	movq	$0x3, 0x30(%rsp)
   69981:      	xorl	%edi, %edi
   69983:      	callq	0x70870 <f.3>
   69988:      	subq	$0x8, %rsp
   6998c:      	cmpb	$0x0, 0xc0bd(%rip)      # 0x75a50 <g.4>
   69993:      	je	0x7085f <f.2+0x180af>
   69999:      	movq	%rax, 0x10(%rsp)
   6999e:      	cmpq	$0x0, 0xc0a2(%rip)      # 0x75a48 <g.3>
   699a6:      	je	0x7085f <f.2+0x180af>
   699ac:      	leaq	-0xe(%r12), %rsi
   699b1:      	movq	$0x0, 0x48(%rsp)
   699ba:      	movq	$0x3, 0x30(%rsp)
   699c3:      	xorl	%edi, %edi
   699c5:      	callq	0x70870 <f.3>
   699ca:      	subq	$0x8, %rsp
   699ce:      	cmpb	$0x0, 0xc07b(%rip)      # 0x75a50 <g.4>
   699d5:      	je	0x7085f <f.2+0x180af>
   699db:      	cmpq	$0x0, 0xc065(%rip)      # 0x75a48 <g.3>
   699e3:      	je	0x7085f <f.2+0x180af>
   699e9:      	movq	%rax, %r15
   699ec:      	addq	0x10(%rsp), %r15
   699f1:      	cmpq	$0xe, %r12
   699f5:      	ja	0x699fe <f.2+0x1124e>
   699f7:      	leaq	-0xd(%r12,%r15), %rax
   699fc:      	jmp	0x69a77 <f.2+0x112c7>
   699fe:      	movq	$0x0, 0x48(%rsp)
   69a07:      	movq	$0x3, 0x30(%rsp)
   69a10:      	xorl	%edi, %edi
   69a12:      	leaq	-0xe(%r12), %rsi
   69a17:      	callq	0x70870 <f.3>
   69a1c:      	subq	$0x8, %rsp
   69a20:      	cmpb	$0x0, 0xc029(%rip)      # 0x75a50 <g.4>
   69a27:      	je	0x7085f <f.2+0x180af>
   69a2d:      	movq	%rax, 0x10(%rsp)
   69a32:      	cmpq	$0x0, 0xc00e(%rip)      # 0x75a48 <g.3>
   69a3a:      	je	0x7085f <f.2+0x180af>
   69a40:      	leaq	-0xf(%r12), %rsi
   69a45:      	movq	$0x0, 0x48(%rsp)
   69a4e:      	movq	$0x3, 0x30(%rsp)
   69a57:      	xorl	%edi, %edi
   69a59:      	callq	0x70870 <f.3>
   69a5e:      	subq	$0x8, %rsp
   69a62:      	cmpb	$0x0, 0xbfe7(%rip)      # 0x75a50 <g.4>
   69a69:      	je	0x7085f <f.2+0x180af>
   69a6f:      	addq	0x10(%rsp), %rax
   69a74:      	addq	%r15, %rax
   69a77:      	cmpq	$0x0, 0xbfc9(%rip)      # 0x75a48 <g.3>
   69a7f:      	je	0x7085f <f.2+0x180af>
   69a85:      	cmpq	$0xe, %r12
   69a89:      	je	0x69a9b <f.2+0x112eb>
   69a8b:      	cmpq	$0xd, %r12
   69a8f:      	jne	0x69ab3 <f.2+0x11303>
   69a91:      	leaq	-0xc(%r12,%rax), %rcx
   69a96:      	jmp	0x69bd7 <f.2+0x11427>
   69a9b:      	movl	$0x1, %edx
   69aa0:      	cmpq	$0x0, 0xbfa0(%rip)      # 0x75a48 <g.3>
   69aa8:      	jne	0x69b46 <f.2+0x11396>
   69aae:      	jmp	0x7085f <f.2+0x180af>
   69ab3:      	movq	%rax, 0x10(%rsp)
   69ab8:      	leaq	-0xe(%r12), %rsi
   69abd:      	movq	$0x0, 0x48(%rsp)
   69ac6:      	movq	$0x3, 0x30(%rsp)
   69acf:      	xorl	%edi, %edi
   69ad1:      	callq	0x70870 <f.3>
   69ad6:      	subq	$0x8, %rsp
   69ada:      	cmpb	$0x0, 0xbf6f(%rip)      # 0x75a50 <g.4>
   69ae1:      	je	0x7085f <f.2+0x180af>
   69ae7:      	cmpq	$0x0, 0xbf59(%rip)      # 0x75a48 <g.3>
   69aef:      	je	0x7085f <f.2+0x180af>
   69af5:      	movq	%rax, %r15
   69af8:      	leaq	-0xf(%r12), %rsi
   69afd:      	movq	$0x0, 0x48(%rsp)
   69b06:      	movq	$0x3, 0x30(%rsp)
   69b0f:      	xorl	%edi, %edi
   69b11:      	callq	0x70870 <f.3>
   69b16:      	subq	$0x8, %rsp
   69b1a:      	cmpb	$0x0, 0xbf2f(%rip)      # 0x75a50 <g.4>
   69b21:      	je	0x7085f <f.2+0x180af>
   69b27:      	movq	%rax, %rdx
   69b2a:      	cmpq	$0x0, 0xbf16(%rip)      # 0x75a48 <g.3>
   69b32:      	movq	0x10(%rsp), %rax
   69b37:      	je	0x7085f <f.2+0x180af>
   69b3d:      	addq	%r15, %rdx
   69b40:      	cmpq	$0xf, %r12
   69b44:      	ja	0x69b4d <f.2+0x1139d>
   69b46:      	leaq	-0xe(%r12), %rcx
   69b4b:      	jmp	0x69bc4 <f.2+0x11414>
   69b4d:      	movq	%rdx, 0x18(%rsp)
   69b52:      	movq	$0x0, 0x48(%rsp)
   69b5b:      	movq	$0x3, 0x30(%rsp)
   69b64:      	xorl	%edi, %edi
   69b66:      	leaq	-0xf(%r12), %rsi
   69b6b:      	callq	0x70870 <f.3>
   69b70:      	subq	$0x8, %rsp
   69b74:      	cmpb	$0x0, 0xbed5(%rip)      # 0x75a50 <g.4>
   69b7b:      	je	0x7085f <f.2+0x180af>
   69b81:      	cmpq	$0x0, 0xbebf(%rip)      # 0x75a48 <g.3>
   69b89:      	je	0x7085f <f.2+0x180af>
   69b8f:      	movq	%rax, %r15
   69b92:      	leaq	-0x10(%r12), %rsi
   69b97:      	movq	$0x0, 0x48(%rsp)
   69ba0:      	movq	$0x3, 0x30(%rsp)
   69ba9:      	xorl	%edi, %edi
   69bab:      	callq	0x70870 <f.3>
   69bb0:      	subq	$0x8, %rsp
   69bb4:      	movq	%rax, %rcx
   69bb7:      	addq	%r15, %rcx
   69bba:      	movq	0x10(%rsp), %rax
   69bbf:      	movq	0x18(%rsp), %rdx
   69bc4:      	cmpb	$0x0, 0xbe85(%rip)      # 0x75a50 <g.4>
   69bcb:      	je	0x7085f <f.2+0x180af>
   69bd1:      	addq	%rdx, %rcx
   69bd4:      	addq	%rax, %rcx
   69bd7:      	cmpq	$0x0, 0xbe69(%rip)      # 0x75a48 <g.3>
   69bdf:      	je	0x7085f <f.2+0x180af>
   69be5:      	cmpq	$0xc, %r12
   69be9:      	ja	0x69bf5 <f.2+0x11445>
   69beb:      	leaq	-0xb(%r12), %r15
   69bf0:      	jmp	0x69eac <f.2+0x116fc>
   69bf5:      	cmpq	$0xd, %r12
   69bf9:      	jne	0x69c14 <f.2+0x11464>
   69bfb:      	movl	$0x1, %r15d
   69c01:      	cmpq	$0x0, 0xbe3f(%rip)      # 0x75a48 <g.3>
   69c09:      	jne	0x69d68 <f.2+0x115b8>
   69c0f:      	jmp	0x7085f <f.2+0x180af>
   69c14:      	cmpq	$0xf, %r12
   69c18:      	jb	0x69d3c <f.2+0x1158c>
   69c1e:      	movq	%rcx, 0x10(%rsp)
   69c23:      	leaq	-0xe(%r12), %rsi
   69c28:      	movq	$0x0, 0x48(%rsp)
   69c31:      	movq	$0x3, 0x30(%rsp)
   69c3a:      	xorl	%edi, %edi
   69c3c:      	callq	0x70870 <f.3>
   69c41:      	subq	$0x8, %rsp
   69c45:      	cmpb	$0x0, 0xbe04(%rip)      # 0x75a50 <g.4>
   69c4c:      	je	0x7085f <f.2+0x180af>
   69c52:      	cmpq	$0x0, 0xbdee(%rip)      # 0x75a48 <g.3>
   69c5a:      	je	0x7085f <f.2+0x180af>
   69c60:      	movq	%rax, %r15
   69c63:      	leaq	-0xf(%r12), %rsi
   69c68:      	movq	$0x0, 0x48(%rsp)
   69c71:      	movq	$0x3, 0x30(%rsp)
   69c7a:      	xorl	%edi, %edi
   69c7c:      	callq	0x70870 <f.3>
   69c81:      	subq	$0x8, %rsp
   69c85:      	cmpb	$0x0, 0xbdc4(%rip)      # 0x75a50 <g.4>
   69c8c:      	je	0x7085f <f.2+0x180af>
   69c92:      	cmpq	$0x0, 0xbdae(%rip)      # 0x75a48 <g.3>
   69c9a:      	movq	0x10(%rsp), %rcx
   69c9f:      	je	0x7085f <f.2+0x180af>
   69ca5:      	addq	%r15, %rax
   69ca8:      	cmpq	$0xf, %r12
   69cac:      	je	0x69d4f <f.2+0x1159f>
   69cb2:      	movq	%rax, 0x18(%rsp)
   69cb7:      	movq	$0x0, 0x48(%rsp)
   69cc0:      	movq	$0x3, 0x30(%rsp)
   69cc9:      	xorl	%edi, %edi
   69ccb:      	leaq	-0xf(%r12), %rsi
   69cd0:      	callq	0x70870 <f.3>
   69cd5:      	subq	$0x8, %rsp
   69cd9:      	cmpb	$0x0, 0xbd70(%rip)      # 0x75a50 <g.4>
   69ce0:      	je	0x7085f <f.2+0x180af>
   69ce6:      	movq	%rax, 0x50(%rsp)
   69ceb:      	cmpq	$0x0, 0xbd55(%rip)      # 0x75a48 <g.3>
   69cf3:      	je	0x7085f <f.2+0x180af>
   69cf9:      	leaq	-0x10(%r12), %rsi
   69cfe:      	movq	$0x0, 0x48(%rsp)
   69d07:      	movq	$0x3, 0x30(%rsp)
   69d10:      	xorl	%edi, %edi
   69d12:      	callq	0x70870 <f.3>
   69d17:      	subq	$0x8, %rsp
   69d1b:      	cmpb	$0x0, 0xbd2e(%rip)      # 0x75a50 <g.4>
   69d22:      	je	0x7085f <f.2+0x180af>
   69d28:      	movq	%rax, %r15
   69d2b:      	addq	0x50(%rsp), %r15
   69d30:      	addq	0x18(%rsp), %r15
   69d35:      	movq	0x10(%rsp), %rcx
   69d3a:      	jmp	0x69d54 <f.2+0x115a4>
   69d3c:      	movl	$0x1, %eax
   69d41:      	cmpq	$0x0, 0xbcff(%rip)      # 0x75a48 <g.3>
   69d49:      	je	0x7085f <f.2+0x180af>
   69d4f:      	leaq	-0xe(%r12,%rax), %r15
   69d54:      	cmpq	$0x0, 0xbcec(%rip)      # 0x75a48 <g.3>
   69d5c:      	je	0x7085f <f.2+0x180af>
   69d62:      	cmpq	$0xe, %r12
   69d66:      	ja	0x69d72 <f.2+0x115c2>
   69d68:      	leaq	-0xd(%r12), %rdx
   69d6d:      	jmp	0x69ea9 <f.2+0x116f9>
   69d72:      	cmpq	$0xf, %r12
   69d76:      	jne	0x69d90 <f.2+0x115e0>
   69d78:      	movl	$0x1, %edx
   69d7d:      	cmpq	$0x0, 0xbcc3(%rip)      # 0x75a48 <g.3>
   69d85:      	jne	0x69e27 <f.2+0x11677>
   69d8b:      	jmp	0x7085f <f.2+0x180af>
   69d90:      	movq	%rcx, 0x10(%rsp)
   69d95:      	leaq	-0xf(%r12), %rsi
   69d9a:      	movq	$0x0, 0x48(%rsp)
   69da3:      	movq	$0x3, 0x30(%rsp)
   69dac:      	xorl	%edi, %edi
   69dae:      	callq	0x70870 <f.3>
   69db3:      	subq	$0x8, %rsp
   69db7:      	cmpb	$0x0, 0xbc92(%rip)      # 0x75a50 <g.4>
   69dbe:      	je	0x7085f <f.2+0x180af>
   69dc4:      	movq	%rax, 0x18(%rsp)
   69dc9:      	cmpq	$0x0, 0xbc77(%rip)      # 0x75a48 <g.3>
   69dd1:      	je	0x7085f <f.2+0x180af>
   69dd7:      	leaq	-0x10(%r12), %rsi
   69ddc:      	movq	$0x0, 0x48(%rsp)
   69de5:      	movq	$0x3, 0x30(%rsp)
   69dee:      	xorl	%edi, %edi
   69df0:      	callq	0x70870 <f.3>
   69df5:      	subq	$0x8, %rsp
   69df9:      	cmpb	$0x0, 0xbc50(%rip)      # 0x75a50 <g.4>
   69e00:      	je	0x7085f <f.2+0x180af>
   69e06:      	cmpq	$0x0, 0xbc3a(%rip)      # 0x75a48 <g.3>
   69e0e:      	movq	0x10(%rsp), %rcx
   69e13:      	je	0x7085f <f.2+0x180af>
   69e19:      	movq	%rax, %rdx
   69e1c:      	addq	0x18(%rsp), %rdx
   69e21:      	cmpq	$0x10, %r12
   69e25:      	ja	0x69e2e <f.2+0x1167e>
   69e27:      	leaq	-0xf(%r12), %rax
   69e2c:      	jmp	0x69ea6 <f.2+0x116f6>
   69e2e:      	movq	%rdx, 0x18(%rsp)
   69e33:      	movq	$0x0, 0x48(%rsp)
   69e3c:      	movq	$0x3, 0x30(%rsp)
   69e45:      	xorl	%edi, %edi
   69e47:      	leaq	-0x10(%r12), %rsi
   69e4c:      	callq	0x70870 <f.3>
   69e51:      	subq	$0x8, %rsp
   69e55:      	cmpb	$0x0, 0xbbf4(%rip)      # 0x75a50 <g.4>
   69e5c:      	je	0x7085f <f.2+0x180af>
   69e62:      	movq	%rax, 0x50(%rsp)
   69e67:      	cmpq	$0x0, 0xbbd9(%rip)      # 0x75a48 <g.3>
   69e6f:      	je	0x7085f <f.2+0x180af>
   69e75:      	leaq	-0x11(%r12), %rsi
   69e7a:      	movq	$0x0, 0x48(%rsp)
   69e83:      	movq	$0x3, 0x30(%rsp)
   69e8c:      	xorl	%edi, %edi
   69e8e:      	callq	0x70870 <f.3>
   69e93:      	subq	$0x8, %rsp
   69e97:      	addq	0x50(%rsp), %rax
   69e9c:      	movq	0x10(%rsp), %rcx
   69ea1:      	movq	0x18(%rsp), %rdx
   69ea6:      	addq	%rax, %rdx
   69ea9:      	addq	%rdx, %r15
   69eac:      	cmpb	$0x0, 0xbb9d(%rip)      # 0x75a50 <g.4>
   69eb3:      	je	0x7085f <f.2+0x180af>
   69eb9:      	addq	%rcx, %r15
   69ebc:      	addq	%r14, %r15
   69ebf:      	cmpq	$0x0, 0xbb81(%rip)      # 0x75a48 <g.3>
   69ec7:      	je	0x7085f <f.2+0x180af>
   69ecd:      	cmpq	$0x9, %r12
   69ed1:      	ja	0x69ef0 <f.2+0x11740>
   69ed3:      	leaq	-0x8(%r12,%r15), %r14
   69ed8:      	cmpq	$0x0, 0xbb68(%rip)      # 0x75a48 <g.3>
   69ee0:      	leaq	0x68(%rsp), %r15
   69ee5:      	jne	0x6bd19 <f.2+0x13569>
   69eeb:      	jmp	0x7085f <f.2+0x180af>
   69ef0:      	cmpq	$0xa, %r12
   69ef4:      	jne	0x69f0e <f.2+0x1175e>
   69ef6:      	movl	$0x1, %ecx
   69efb:      	cmpq	$0x0, 0xbb45(%rip)      # 0x75a48 <g.3>
   69f03:      	jne	0x6a4c7 <f.2+0x11d17>
   69f09:      	jmp	0x7085f <f.2+0x180af>
   69f0e:      	cmpq	$0xc, %r12
   69f12:      	jb	0x69f2e <f.2+0x1177e>
   69f14:      	jne	0x69f47 <f.2+0x11797>
   69f16:      	movl	$0x1, %eax
   69f1b:      	cmpq	$0x0, 0xbb25(%rip)      # 0x75a48 <g.3>
   69f23:      	jne	0x6a08a <f.2+0x118da>
   69f29:      	jmp	0x7085f <f.2+0x180af>
   69f2e:      	movl	$0x1, %r14d
   69f34:      	cmpq	$0x0, 0xbb0c(%rip)      # 0x75a48 <g.3>
   69f3c:      	jne	0x6a1f4 <f.2+0x11a44>
   69f42:      	jmp	0x7085f <f.2+0x180af>
   69f47:      	cmpq	$0xe, %r12
   69f4b:      	jb	0x6a05d <f.2+0x118ad>
   69f51:      	leaq	-0xd(%r12), %rsi
   69f56:      	movq	$0x0, 0x48(%rsp)
   69f5f:      	movq	$0x3, 0x30(%rsp)
   69f68:      	xorl	%edi, %edi
   69f6a:      	callq	0x70870 <f.3>
   69f6f:      	subq	$0x8, %rsp
   69f73:      	cmpb	$0x0, 0xbad6(%rip)      # 0x75a50 <g.4>
   69f7a:      	je	0x7085f <f.2+0x180af>
   69f80:      	movq	%rax, 0x10(%rsp)
   69f85:      	cmpq	$0x0, 0xbabb(%rip)      # 0x75a48 <g.3>
   69f8d:      	je	0x7085f <f.2+0x180af>
   69f93:      	leaq	-0xe(%r12), %rsi
   69f98:      	movq	$0x0, 0x48(%rsp)
   69fa1:      	movq	$0x3, 0x30(%rsp)
   69faa:      	xorl	%edi, %edi
   69fac:      	callq	0x70870 <f.3>
   69fb1:      	subq	$0x8, %rsp
   69fb5:      	cmpb	$0x0, 0xba94(%rip)      # 0x75a50 <g.4>
   69fbc:      	je	0x7085f <f.2+0x180af>
   69fc2:      	cmpq	$0x0, 0xba7e(%rip)      # 0x75a48 <g.3>
   69fca:      	je	0x7085f <f.2+0x180af>
   69fd0:      	movq	%rax, %r14
   69fd3:      	addq	0x10(%rsp), %r14
   69fd8:      	cmpq	$0xe, %r12
   69fdc:      	je	0x6a071 <f.2+0x118c1>
   69fe2:      	movq	$0x0, 0x48(%rsp)
   69feb:      	movq	$0x3, 0x30(%rsp)
   69ff4:      	xorl	%edi, %edi
   69ff6:      	leaq	-0xe(%r12), %rsi
   69ffb:      	callq	0x70870 <f.3>
   6a000:      	subq	$0x8, %rsp
   6a004:      	cmpb	$0x0, 0xba45(%rip)      # 0x75a50 <g.4>
   6a00b:      	je	0x7085f <f.2+0x180af>
   6a011:      	movq	%rax, 0x10(%rsp)
   6a016:      	cmpq	$0x0, 0xba2a(%rip)      # 0x75a48 <g.3>
   6a01e:      	je	0x7085f <f.2+0x180af>
   6a024:      	leaq	-0xf(%r12), %rsi
   6a029:      	movq	$0x0, 0x48(%rsp)
   6a032:      	movq	$0x3, 0x30(%rsp)
   6a03b:      	xorl	%edi, %edi
   6a03d:      	callq	0x70870 <f.3>
   6a042:      	subq	$0x8, %rsp
   6a046:      	cmpb	$0x0, 0xba03(%rip)      # 0x75a50 <g.4>
   6a04d:      	je	0x7085f <f.2+0x180af>
   6a053:      	addq	0x10(%rsp), %rax
   6a058:      	addq	%r14, %rax
   6a05b:      	jmp	0x6a076 <f.2+0x118c6>
   6a05d:      	movl	$0x1, %r14d
   6a063:      	cmpq	$0x0, 0xb9dd(%rip)      # 0x75a48 <g.3>
   6a06b:      	je	0x7085f <f.2+0x180af>
   6a071:      	leaq	-0xd(%r12,%r14), %rax
   6a076:      	cmpq	$0x0, 0xb9ca(%rip)      # 0x75a48 <g.3>
   6a07e:      	je	0x7085f <f.2+0x180af>
   6a084:      	cmpq	$0xd, %r12
   6a088:      	ja	0x6a094 <f.2+0x118e4>
   6a08a:      	leaq	-0xc(%r12,%rax), %r14
   6a08f:      	jmp	0x6a1da <f.2+0x11a2a>
   6a094:      	cmpq	$0xe, %r12
   6a098:      	jne	0x6a0b2 <f.2+0x11902>
   6a09a:      	movl	$0x1, %ecx
   6a09f:      	cmpq	$0x0, 0xb9a1(%rip)      # 0x75a48 <g.3>
   6a0a7:      	jne	0x6a145 <f.2+0x11995>
   6a0ad:      	jmp	0x7085f <f.2+0x180af>
   6a0b2:      	movq	%rax, 0x10(%rsp)
   6a0b7:      	leaq	-0xe(%r12), %rsi
   6a0bc:      	movq	$0x0, 0x48(%rsp)
   6a0c5:      	movq	$0x3, 0x30(%rsp)
   6a0ce:      	xorl	%edi, %edi
   6a0d0:      	callq	0x70870 <f.3>
   6a0d5:      	subq	$0x8, %rsp
   6a0d9:      	cmpb	$0x0, 0xb970(%rip)      # 0x75a50 <g.4>
   6a0e0:      	je	0x7085f <f.2+0x180af>
   6a0e6:      	cmpq	$0x0, 0xb95a(%rip)      # 0x75a48 <g.3>
   6a0ee:      	je	0x7085f <f.2+0x180af>
   6a0f4:      	movq	%rax, %r14
   6a0f7:      	leaq	-0xf(%r12), %rsi
   6a0fc:      	movq	$0x0, 0x48(%rsp)
   6a105:      	movq	$0x3, 0x30(%rsp)
   6a10e:      	xorl	%edi, %edi
   6a110:      	callq	0x70870 <f.3>
   6a115:      	subq	$0x8, %rsp
   6a119:      	cmpb	$0x0, 0xb930(%rip)      # 0x75a50 <g.4>
   6a120:      	je	0x7085f <f.2+0x180af>
   6a126:      	movq	%rax, %rcx
   6a129:      	cmpq	$0x0, 0xb917(%rip)      # 0x75a48 <g.3>
   6a131:      	movq	0x10(%rsp), %rax
   6a136:      	je	0x7085f <f.2+0x180af>
   6a13c:      	addq	%r14, %rcx
   6a13f:      	cmpq	$0xf, %r12
   6a143:      	ja	0x6a14c <f.2+0x1199c>
   6a145:      	leaq	-0xe(%r12), %r14
   6a14a:      	jmp	0x6a1c7 <f.2+0x11a17>
   6a14c:      	movq	%rcx, 0x18(%rsp)
   6a151:      	movq	$0x0, 0x48(%rsp)
   6a15a:      	movq	$0x3, 0x30(%rsp)
   6a163:      	xorl	%edi, %edi
   6a165:      	leaq	-0xf(%r12), %rsi
   6a16a:      	callq	0x70870 <f.3>
   6a16f:      	subq	$0x8, %rsp
   6a173:      	cmpb	$0x0, 0xb8d6(%rip)      # 0x75a50 <g.4>
   6a17a:      	je	0x7085f <f.2+0x180af>
   6a180:      	movq	%rax, 0x50(%rsp)
   6a185:      	cmpq	$0x0, 0xb8bb(%rip)      # 0x75a48 <g.3>
   6a18d:      	je	0x7085f <f.2+0x180af>
   6a193:      	leaq	-0x10(%r12), %rsi
   6a198:      	movq	$0x0, 0x48(%rsp)
   6a1a1:      	movq	$0x3, 0x30(%rsp)
   6a1aa:      	xorl	%edi, %edi
   6a1ac:      	callq	0x70870 <f.3>
   6a1b1:      	subq	$0x8, %rsp
   6a1b5:      	movq	%rax, %r14
   6a1b8:      	addq	0x50(%rsp), %r14
   6a1bd:      	movq	0x10(%rsp), %rax
   6a1c2:      	movq	0x18(%rsp), %rcx
   6a1c7:      	cmpb	$0x0, 0xb882(%rip)      # 0x75a50 <g.4>
   6a1ce:      	je	0x7085f <f.2+0x180af>
   6a1d4:      	addq	%rcx, %r14
   6a1d7:      	addq	%rax, %r14
   6a1da:      	cmpq	$0x0, 0xb866(%rip)      # 0x75a48 <g.3>
   6a1e2:      	je	0x7085f <f.2+0x180af>
   6a1e8:      	cmpq	$0xd, %r12
   6a1ec:      	je	0x6a1fe <f.2+0x11a4e>
   6a1ee:      	cmpq	$0xc, %r12
   6a1f2:      	jne	0x6a216 <f.2+0x11a66>
   6a1f4:      	leaq	-0xb(%r12,%r14), %rcx
   6a1f9:      	jmp	0x6a4b3 <f.2+0x11d03>
   6a1fe:      	movl	$0x1, %edx
   6a203:      	cmpq	$0x0, 0xb83d(%rip)      # 0x75a48 <g.3>
   6a20b:      	jne	0x6a35f <f.2+0x11baf>
   6a211:      	jmp	0x7085f <f.2+0x180af>
   6a216:      	cmpq	$0xf, %r12
   6a21a:      	jb	0x6a333 <f.2+0x11b83>
   6a220:      	leaq	-0xe(%r12), %rsi
   6a225:      	movq	$0x0, 0x48(%rsp)
   6a22e:      	movq	$0x3, 0x30(%rsp)
   6a237:      	xorl	%edi, %edi
   6a239:      	callq	0x70870 <f.3>
   6a23e:      	subq	$0x8, %rsp
   6a242:      	cmpb	$0x0, 0xb807(%rip)      # 0x75a50 <g.4>
   6a249:      	je	0x7085f <f.2+0x180af>
   6a24f:      	movq	%rax, 0x10(%rsp)
   6a254:      	cmpq	$0x0, 0xb7ec(%rip)      # 0x75a48 <g.3>
   6a25c:      	je	0x7085f <f.2+0x180af>
   6a262:      	leaq	-0xf(%r12), %rsi
   6a267:      	movq	$0x0, 0x48(%rsp)
   6a270:      	movq	$0x3, 0x30(%rsp)
   6a279:      	xorl	%edi, %edi
   6a27b:      	callq	0x70870 <f.3>
   6a280:      	subq	$0x8, %rsp
   6a284:      	cmpb	$0x0, 0xb7c5(%rip)      # 0x75a50 <g.4>
   6a28b:      	je	0x7085f <f.2+0x180af>
   6a291:      	cmpq	$0x0, 0xb7af(%rip)      # 0x75a48 <g.3>
   6a299:      	je	0x7085f <f.2+0x180af>
   6a29f:      	addq	0x10(%rsp), %rax
   6a2a4:      	cmpq	$0xf, %r12
   6a2a8:      	je	0x6a346 <f.2+0x11b96>
   6a2ae:      	movq	%rax, 0x10(%rsp)
   6a2b3:      	movq	$0x0, 0x48(%rsp)
   6a2bc:      	movq	$0x3, 0x30(%rsp)
   6a2c5:      	xorl	%edi, %edi
   6a2c7:      	leaq	-0xf(%r12), %rsi
   6a2cc:      	callq	0x70870 <f.3>
   6a2d1:      	subq	$0x8, %rsp
   6a2d5:      	cmpb	$0x0, 0xb774(%rip)      # 0x75a50 <g.4>
   6a2dc:      	je	0x7085f <f.2+0x180af>
   6a2e2:      	movq	%rax, 0x18(%rsp)
   6a2e7:      	cmpq	$0x0, 0xb759(%rip)      # 0x75a48 <g.3>
   6a2ef:      	je	0x7085f <f.2+0x180af>
   6a2f5:      	leaq	-0x10(%r12), %rsi
   6a2fa:      	movq	$0x0, 0x48(%rsp)
   6a303:      	movq	$0x3, 0x30(%rsp)
   6a30c:      	xorl	%edi, %edi
   6a30e:      	callq	0x70870 <f.3>
   6a313:      	subq	$0x8, %rsp
   6a317:      	cmpb	$0x0, 0xb732(%rip)      # 0x75a50 <g.4>
   6a31e:      	je	0x7085f <f.2+0x180af>
   6a324:      	movq	%rax, %rdx
   6a327:      	addq	0x18(%rsp), %rdx
   6a32c:      	addq	0x10(%rsp), %rdx
   6a331:      	jmp	0x6a34b <f.2+0x11b9b>
   6a333:      	movl	$0x1, %eax
   6a338:      	cmpq	$0x0, 0xb708(%rip)      # 0x75a48 <g.3>
   6a340:      	je	0x7085f <f.2+0x180af>
   6a346:      	leaq	-0xe(%r12,%rax), %rdx
   6a34b:      	cmpq	$0x0, 0xb6f5(%rip)      # 0x75a48 <g.3>
   6a353:      	je	0x7085f <f.2+0x180af>
   6a359:      	cmpq	$0xe, %r12
   6a35d:      	ja	0x6a369 <f.2+0x11bb9>
   6a35f:      	leaq	-0xd(%r12), %rcx
   6a364:      	jmp	0x6a4a0 <f.2+0x11cf0>
   6a369:      	cmpq	$0xf, %r12
   6a36d:      	jne	0x6a387 <f.2+0x11bd7>
   6a36f:      	movl	$0x1, %ecx
   6a374:      	cmpq	$0x0, 0xb6cc(%rip)      # 0x75a48 <g.3>
   6a37c:      	jne	0x6a41e <f.2+0x11c6e>
   6a382:      	jmp	0x7085f <f.2+0x180af>
   6a387:      	movq	%rdx, 0x18(%rsp)
   6a38c:      	leaq	-0xf(%r12), %rsi
   6a391:      	movq	$0x0, 0x48(%rsp)
   6a39a:      	movq	$0x3, 0x30(%rsp)
   6a3a3:      	xorl	%edi, %edi
   6a3a5:      	callq	0x70870 <f.3>
   6a3aa:      	subq	$0x8, %rsp
   6a3ae:      	cmpb	$0x0, 0xb69b(%rip)      # 0x75a50 <g.4>
   6a3b5:      	je	0x7085f <f.2+0x180af>
   6a3bb:      	movq	%rax, 0x10(%rsp)
   6a3c0:      	cmpq	$0x0, 0xb680(%rip)      # 0x75a48 <g.3>
   6a3c8:      	je	0x7085f <f.2+0x180af>
   6a3ce:      	leaq	-0x10(%r12), %rsi
   6a3d3:      	movq	$0x0, 0x48(%rsp)
   6a3dc:      	movq	$0x3, 0x30(%rsp)
   6a3e5:      	xorl	%edi, %edi
   6a3e7:      	callq	0x70870 <f.3>
   6a3ec:      	subq	$0x8, %rsp
   6a3f0:      	cmpb	$0x0, 0xb659(%rip)      # 0x75a50 <g.4>
   6a3f7:      	je	0x7085f <f.2+0x180af>
   6a3fd:      	cmpq	$0x0, 0xb643(%rip)      # 0x75a48 <g.3>
   6a405:      	movq	0x18(%rsp), %rdx
   6a40a:      	je	0x7085f <f.2+0x180af>
   6a410:      	movq	%rax, %rcx
   6a413:      	addq	0x10(%rsp), %rcx
   6a418:      	cmpq	$0x10, %r12
   6a41c:      	ja	0x6a425 <f.2+0x11c75>
   6a41e:      	leaq	-0xf(%r12), %rax
   6a423:      	jmp	0x6a49d <f.2+0x11ced>
   6a425:      	movq	%rcx, 0x10(%rsp)
   6a42a:      	movq	$0x0, 0x48(%rsp)
   6a433:      	movq	$0x3, 0x30(%rsp)
   6a43c:      	xorl	%edi, %edi
   6a43e:      	leaq	-0x10(%r12), %rsi
   6a443:      	callq	0x70870 <f.3>
   6a448:      	subq	$0x8, %rsp
   6a44c:      	cmpb	$0x0, 0xb5fd(%rip)      # 0x75a50 <g.4>
   6a453:      	je	0x7085f <f.2+0x180af>
   6a459:      	movq	%rax, 0x50(%rsp)
   6a45e:      	cmpq	$0x0, 0xb5e2(%rip)      # 0x75a48 <g.3>
   6a466:      	je	0x7085f <f.2+0x180af>
   6a46c:      	leaq	-0x11(%r12), %rsi
   6a471:      	movq	$0x0, 0x48(%rsp)
   6a47a:      	movq	$0x3, 0x30(%rsp)
   6a483:      	xorl	%edi, %edi
   6a485:      	callq	0x70870 <f.3>
   6a48a:      	subq	$0x8, %rsp
   6a48e:      	addq	0x50(%rsp), %rax
   6a493:      	movq	0x10(%rsp), %rcx
   6a498:      	movq	0x18(%rsp), %rdx
   6a49d:      	addq	%rax, %rcx
   6a4a0:      	cmpb	$0x0, 0xb5a9(%rip)      # 0x75a50 <g.4>
   6a4a7:      	je	0x7085f <f.2+0x180af>
   6a4ad:      	addq	%rdx, %rcx
   6a4b0:      	addq	%r14, %rcx
   6a4b3:      	cmpq	$0x0, 0xb58d(%rip)      # 0x75a48 <g.3>
   6a4bb:      	je	0x7085f <f.2+0x180af>
   6a4c1:      	cmpq	$0xb, %r12
   6a4c5:      	ja	0x6a4d1 <f.2+0x11d21>
   6a4c7:      	leaq	-0xa(%r12), %r14
   6a4cc:      	jmp	0x6bcf3 <f.2+0x13543>
   6a4d1:      	cmpq	$0xc, %r12
   6a4d5:      	jne	0x6a4f0 <f.2+0x11d40>
   6a4d7:      	movl	$0x1, %r14d
   6a4dd:      	cmpq	$0x0, 0xb563(%rip)      # 0x75a48 <g.3>
   6a4e5:      	jne	0x6add6 <f.2+0x12626>
   6a4eb:      	jmp	0x7085f <f.2+0x180af>
   6a4f0:      	cmpq	$0xe, %r12
   6a4f4:      	jb	0x6a511 <f.2+0x11d61>
   6a4f6:      	jne	0x6a529 <f.2+0x11d79>
   6a4f8:      	movl	$0x1, %r14d
   6a4fe:      	cmpq	$0x0, 0xb542(%rip)      # 0x75a48 <g.3>
   6a506:      	jne	0x6a5c0 <f.2+0x11e10>
   6a50c:      	jmp	0x7085f <f.2+0x180af>
   6a511:      	movl	$0x1, %eax
   6a516:      	cmpq	$0x0, 0xb52a(%rip)      # 0x75a48 <g.3>
   6a51e:      	jne	0x6a65f <f.2+0x11eaf>
   6a524:      	jmp	0x7085f <f.2+0x180af>
   6a529:      	movq	%rcx, 0x10(%rsp)
   6a52e:      	leaq	-0xe(%r12), %rsi
   6a533:      	movq	$0x0, 0x48(%rsp)
   6a53c:      	movq	$0x3, 0x30(%rsp)
   6a545:      	xorl	%edi, %edi
   6a547:      	callq	0x70870 <f.3>
   6a54c:      	subq	$0x8, %rsp
   6a550:      	cmpb	$0x0, 0xb4f9(%rip)      # 0x75a50 <g.4>
   6a557:      	je	0x7085f <f.2+0x180af>
   6a55d:      	movq	%rax, 0x18(%rsp)
   6a562:      	cmpq	$0x0, 0xb4de(%rip)      # 0x75a48 <g.3>
   6a56a:      	je	0x7085f <f.2+0x180af>
   6a570:      	leaq	-0xf(%r12), %rsi
   6a575:      	movq	$0x0, 0x48(%rsp)
   6a57e:      	movq	$0x3, 0x30(%rsp)
   6a587:      	xorl	%edi, %edi
   6a589:      	callq	0x70870 <f.3>
   6a58e:      	subq	$0x8, %rsp
   6a592:      	cmpb	$0x0, 0xb4b7(%rip)      # 0x75a50 <g.4>
   6a599:      	je	0x7085f <f.2+0x180af>
   6a59f:      	cmpq	$0x0, 0xb4a1(%rip)      # 0x75a48 <g.3>
   6a5a7:      	movq	0x10(%rsp), %rcx
   6a5ac:      	je	0x7085f <f.2+0x180af>
   6a5b2:      	movq	%rax, %r14
   6a5b5:      	addq	0x18(%rsp), %r14
   6a5ba:      	cmpq	$0xf, %r12
   6a5be:      	ja	0x6a5c7 <f.2+0x11e17>
   6a5c0:      	leaq	-0xe(%r12,%r14), %rax
   6a5c5:      	jmp	0x6a645 <f.2+0x11e95>
   6a5c7:      	movq	$0x0, 0x48(%rsp)
   6a5d0:      	movq	$0x3, 0x30(%rsp)
   6a5d9:      	xorl	%edi, %edi
   6a5db:      	leaq	-0xf(%r12), %rsi
   6a5e0:      	callq	0x70870 <f.3>
   6a5e5:      	subq	$0x8, %rsp
   6a5e9:      	cmpb	$0x0, 0xb460(%rip)      # 0x75a50 <g.4>
   6a5f0:      	je	0x7085f <f.2+0x180af>
   6a5f6:      	movq	%rax, 0x18(%rsp)
   6a5fb:      	cmpq	$0x0, 0xb445(%rip)      # 0x75a48 <g.3>
   6a603:      	je	0x7085f <f.2+0x180af>
   6a609:      	leaq	-0x10(%r12), %rsi
   6a60e:      	movq	$0x0, 0x48(%rsp)
   6a617:      	movq	$0x3, 0x30(%rsp)
   6a620:      	xorl	%edi, %edi
   6a622:      	callq	0x70870 <f.3>
   6a627:      	subq	$0x8, %rsp
   6a62b:      	cmpb	$0x0, 0xb41e(%rip)      # 0x75a50 <g.4>
   6a632:      	je	0x7085f <f.2+0x180af>
   6a638:      	addq	0x18(%rsp), %rax
   6a63d:      	addq	%r14, %rax
   6a640:      	movq	0x10(%rsp), %rcx
   6a645:      	cmpq	$0x0, 0xb3fb(%rip)      # 0x75a48 <g.3>
   6a64d:      	je	0x7085f <f.2+0x180af>
   6a653:      	cmpq	$0xf, %r12
   6a657:      	je	0x6a669 <f.2+0x11eb9>
   6a659:      	cmpq	$0xe, %r12
   6a65d:      	jne	0x6a681 <f.2+0x11ed1>
   6a65f:      	leaq	-0xd(%r12,%rax), %r14
   6a664:      	jmp	0x6adc2 <f.2+0x12612>
   6a669:      	movl	$0x1, %edx
   6a66e:      	cmpq	$0x0, 0xb3d2(%rip)      # 0x75a48 <g.3>
   6a676:      	jne	0x6a722 <f.2+0x11f72>
   6a67c:      	jmp	0x7085f <f.2+0x180af>
   6a681:      	movq	%rax, 0x18(%rsp)
   6a686:      	movq	%rcx, 0x10(%rsp)
   6a68b:      	leaq	-0xf(%r12), %rsi
   6a690:      	movq	$0x0, 0x48(%rsp)
   6a699:      	movq	$0x3, 0x30(%rsp)
   6a6a2:      	xorl	%edi, %edi
   6a6a4:      	callq	0x70870 <f.3>
   6a6a9:      	subq	$0x8, %rsp
   6a6ad:      	cmpb	$0x0, 0xb39c(%rip)      # 0x75a50 <g.4>
   6a6b4:      	je	0x7085f <f.2+0x180af>
   6a6ba:      	cmpq	$0x0, 0xb386(%rip)      # 0x75a48 <g.3>
   6a6c2:      	je	0x7085f <f.2+0x180af>
   6a6c8:      	movq	%rax, %r14
   6a6cb:      	leaq	-0x10(%r12), %rsi
   6a6d0:      	movq	$0x0, 0x48(%rsp)
   6a6d9:      	movq	$0x3, 0x30(%rsp)
   6a6e2:      	xorl	%edi, %edi
   6a6e4:      	callq	0x70870 <f.3>
   6a6e9:      	subq	$0x8, %rsp
   6a6ed:      	cmpb	$0x0, 0xb35c(%rip)      # 0x75a50 <g.4>
   6a6f4:      	je	0x7085f <f.2+0x180af>
   6a6fa:      	movq	%rax, %rdx
   6a6fd:      	cmpq	$0x0, 0xb343(%rip)      # 0x75a48 <g.3>
   6a705:      	movq	0x10(%rsp), %rcx
   6a70a:      	movq	0x18(%rsp), %rax
   6a70f:      	je	0x7085f <f.2+0x180af>
   6a715:      	addq	%r14, %rdx
   6a718:      	cmpq	$0x10, %r12
   6a71c:      	ja	0x6ad2f <f.2+0x1257f>
   6a722:      	leaq	-0xf(%r12), %r14
   6a727:      	jmp	0x6adaf <f.2+0x125ff>
   6a72c:      	movq	%rcx, 0x10(%rsp)
   6a731:      	movq	$0x0, 0x48(%rsp)
   6a73a:      	movq	$0x3, 0x30(%rsp)
   6a743:      	xorl	%edi, %edi
   6a745:      	leaq	-0x10(%r12), %rsi
   6a74a:      	callq	0x70870 <f.3>
   6a74f:      	subq	$0x8, %rsp
   6a753:      	cmpb	$0x0, 0xb2f6(%rip)      # 0x75a50 <g.4>
   6a75a:      	je	0x7085f <f.2+0x180af>
   6a760:      	movq	%rax, 0x50(%rsp)
   6a765:      	cmpq	$0x0, 0xb2db(%rip)      # 0x75a48 <g.3>
   6a76d:      	je	0x7085f <f.2+0x180af>
   6a773:      	leaq	-0x11(%r12), %rsi
   6a778:      	movq	$0x0, 0x48(%rsp)
   6a781:      	movq	$0x3, 0x30(%rsp)
   6a78a:      	xorl	%edi, %edi
   6a78c:      	callq	0x70870 <f.3>
   6a791:      	subq	$0x8, %rsp
   6a795:      	addq	0x50(%rsp), %rax
   6a79a:      	movq	0x10(%rsp), %rcx
   6a79f:      	movq	0x18(%rsp), %rdx
   6a7a4:      	addq	%rax, %rcx
   6a7a7:      	cmpb	$0x0, 0xb2a2(%rip)      # 0x75a50 <g.4>
   6a7ae:      	je	0x7085f <f.2+0x180af>
   6a7b4:      	addq	%rdx, %rcx
   6a7b7:      	addq	%rbp, %rcx
   6a7ba:      	cmpq	$0x0, 0xb286(%rip)      # 0x75a48 <g.3>
   6a7c2:      	je	0x7085f <f.2+0x180af>
   6a7c8:      	cmpq	$0xc, %r12
   6a7cc:      	je	0x6a7de <f.2+0x1202e>
   6a7ce:      	cmpq	$0xb, %r12
   6a7d2:      	jne	0x6a7f6 <f.2+0x12046>
   6a7d4:      	leaq	-0xa(%r12,%rcx), %rbp
   6a7d9:      	jmp	0x6b0c3 <f.2+0x12913>
   6a7de:      	movl	$0x1, %edx
   6a7e3:      	cmpq	$0x0, 0xb25d(%rip)      # 0x75a48 <g.3>
   6a7eb:      	jne	0x6aacd <f.2+0x1231d>
   6a7f1:      	jmp	0x7085f <f.2+0x180af>
   6a7f6:      	cmpq	$0xe, %r12
   6a7fa:      	jb	0x6a816 <f.2+0x12066>
   6a7fc:      	jne	0x6a82e <f.2+0x1207e>
   6a7fe:      	movl	$0x1, %ebp
   6a803:      	cmpq	$0x0, 0xb23d(%rip)      # 0x75a48 <g.3>
   6a80b:      	jne	0x6a8c5 <f.2+0x12115>
   6a811:      	jmp	0x7085f <f.2+0x180af>
   6a816:      	movl	$0x1, %eax
   6a81b:      	cmpq	$0x0, 0xb225(%rip)      # 0x75a48 <g.3>
   6a823:      	jne	0x6a964 <f.2+0x121b4>
   6a829:      	jmp	0x7085f <f.2+0x180af>
   6a82e:      	movq	%rcx, 0x10(%rsp)
   6a833:      	leaq	-0xe(%r12), %rsi
   6a838:      	movq	$0x0, 0x48(%rsp)
   6a841:      	movq	$0x3, 0x30(%rsp)
   6a84a:      	xorl	%edi, %edi
   6a84c:      	callq	0x70870 <f.3>
   6a851:      	subq	$0x8, %rsp
   6a855:      	cmpb	$0x0, 0xb1f4(%rip)      # 0x75a50 <g.4>
   6a85c:      	je	0x7085f <f.2+0x180af>
   6a862:      	movq	%rax, 0x18(%rsp)
   6a867:      	cmpq	$0x0, 0xb1d9(%rip)      # 0x75a48 <g.3>
   6a86f:      	je	0x7085f <f.2+0x180af>
   6a875:      	leaq	-0xf(%r12), %rsi
   6a87a:      	movq	$0x0, 0x48(%rsp)
   6a883:      	movq	$0x3, 0x30(%rsp)
   6a88c:      	xorl	%edi, %edi
   6a88e:      	callq	0x70870 <f.3>
   6a893:      	subq	$0x8, %rsp
   6a897:      	cmpb	$0x0, 0xb1b2(%rip)      # 0x75a50 <g.4>
   6a89e:      	je	0x7085f <f.2+0x180af>
   6a8a4:      	cmpq	$0x0, 0xb19c(%rip)      # 0x75a48 <g.3>
   6a8ac:      	movq	0x10(%rsp), %rcx
   6a8b1:      	je	0x7085f <f.2+0x180af>
   6a8b7:      	movq	%rax, %rbp
   6a8ba:      	addq	0x18(%rsp), %rbp
   6a8bf:      	cmpq	$0xf, %r12
   6a8c3:      	ja	0x6a8cc <f.2+0x1211c>
   6a8c5:      	leaq	-0xe(%r12,%rbp), %rax
   6a8ca:      	jmp	0x6a94a <f.2+0x1219a>
   6a8cc:      	movq	$0x0, 0x48(%rsp)
   6a8d5:      	movq	$0x3, 0x30(%rsp)
   6a8de:      	xorl	%edi, %edi
   6a8e0:      	leaq	-0xf(%r12), %rsi
   6a8e5:      	callq	0x70870 <f.3>
   6a8ea:      	subq	$0x8, %rsp
   6a8ee:      	cmpb	$0x0, 0xb15b(%rip)      # 0x75a50 <g.4>
   6a8f5:      	je	0x7085f <f.2+0x180af>
   6a8fb:      	movq	%rax, 0x18(%rsp)
   6a900:      	cmpq	$0x0, 0xb140(%rip)      # 0x75a48 <g.3>
   6a908:      	je	0x7085f <f.2+0x180af>
   6a90e:      	leaq	-0x10(%r12), %rsi
   6a913:      	movq	$0x0, 0x48(%rsp)
   6a91c:      	movq	$0x3, 0x30(%rsp)
   6a925:      	xorl	%edi, %edi
   6a927:      	callq	0x70870 <f.3>
   6a92c:      	subq	$0x8, %rsp
   6a930:      	cmpb	$0x0, 0xb119(%rip)      # 0x75a50 <g.4>
   6a937:      	je	0x7085f <f.2+0x180af>
   6a93d:      	addq	0x18(%rsp), %rax
   6a942:      	addq	%rbp, %rax
   6a945:      	movq	0x10(%rsp), %rcx
   6a94a:      	cmpq	$0x0, 0xb0f6(%rip)      # 0x75a48 <g.3>
   6a952:      	je	0x7085f <f.2+0x180af>
   6a958:      	cmpq	$0xf, %r12
   6a95c:      	je	0x6a96e <f.2+0x121be>
   6a95e:      	cmpq	$0xe, %r12
   6a962:      	jne	0x6a986 <f.2+0x121d6>
   6a964:      	leaq	-0xd(%r12,%rax), %rdx
   6a969:      	jmp	0x6aab9 <f.2+0x12309>
   6a96e:      	movl	$0x1, %esi
   6a973:      	cmpq	$0x0, 0xb0cd(%rip)      # 0x75a48 <g.3>
   6a97b:      	jne	0x6aa23 <f.2+0x12273>
   6a981:      	jmp	0x7085f <f.2+0x180af>
   6a986:      	movq	%rax, 0x18(%rsp)
   6a98b:      	movq	%rcx, 0x10(%rsp)
   6a990:      	leaq	-0xf(%r12), %rsi
   6a995:      	movq	$0x0, 0x48(%rsp)
   6a99e:      	movq	$0x3, 0x30(%rsp)
   6a9a7:      	xorl	%edi, %edi
   6a9a9:      	callq	0x70870 <f.3>
   6a9ae:      	subq	$0x8, %rsp
   6a9b2:      	cmpb	$0x0, 0xb097(%rip)      # 0x75a50 <g.4>
   6a9b9:      	je	0x7085f <f.2+0x180af>
   6a9bf:      	cmpq	$0x0, 0xb081(%rip)      # 0x75a48 <g.3>
   6a9c7:      	je	0x7085f <f.2+0x180af>
   6a9cd:      	movq	%rax, %rbp
   6a9d0:      	leaq	-0x10(%r12), %rsi
   6a9d5:      	movq	$0x0, 0x48(%rsp)
   6a9de:      	movq	$0x3, 0x30(%rsp)
   6a9e7:      	xorl	%edi, %edi
   6a9e9:      	callq	0x70870 <f.3>
   6a9ee:      	subq	$0x8, %rsp
   6a9f2:      	cmpb	$0x0, 0xb057(%rip)      # 0x75a50 <g.4>
   6a9f9:      	je	0x7085f <f.2+0x180af>
   6a9ff:      	movq	%rax, %rsi
   6aa02:      	cmpq	$0x0, 0xb03e(%rip)      # 0x75a48 <g.3>
   6aa0a:      	movq	0x10(%rsp), %rcx
   6aa0f:      	movq	0x18(%rsp), %rax
   6aa14:      	je	0x7085f <f.2+0x180af>
   6aa1a:      	addq	%rbp, %rsi
   6aa1d:      	cmpq	$0x10, %r12
   6aa21:      	ja	0x6aa2a <f.2+0x1227a>
   6aa23:      	leaq	-0xf(%r12), %rdx
   6aa28:      	jmp	0x6aaa6 <f.2+0x122f6>
   6aa2a:      	movq	%rsi, 0x50(%rsp)
   6aa2f:      	movq	$0x0, 0x48(%rsp)
   6aa38:      	movq	$0x3, 0x30(%rsp)
   6aa41:      	xorl	%edi, %edi
   6aa43:      	leaq	-0x10(%r12), %rsi
   6aa48:      	callq	0x70870 <f.3>
   6aa4d:      	subq	$0x8, %rsp
   6aa51:      	cmpb	$0x0, 0xaff8(%rip)      # 0x75a50 <g.4>
   6aa58:      	je	0x7085f <f.2+0x180af>
   6aa5e:      	cmpq	$0x0, 0xafe2(%rip)      # 0x75a48 <g.3>
   6aa66:      	je	0x7085f <f.2+0x180af>
   6aa6c:      	movq	%rax, %rbp
   6aa6f:      	leaq	-0x11(%r12), %rsi
   6aa74:      	movq	$0x0, 0x48(%rsp)
   6aa7d:      	movq	$0x3, 0x30(%rsp)
   6aa86:      	xorl	%edi, %edi
   6aa88:      	callq	0x70870 <f.3>
   6aa8d:      	subq	$0x8, %rsp
   6aa91:      	movq	%rax, %rdx
   6aa94:      	addq	%rbp, %rdx
   6aa97:      	movq	0x10(%rsp), %rcx
   6aa9c:      	movq	0x18(%rsp), %rax
   6aaa1:      	movq	0x50(%rsp), %rsi
   6aaa6:      	cmpb	$0x0, 0xafa3(%rip)      # 0x75a50 <g.4>
   6aaad:      	je	0x7085f <f.2+0x180af>
   6aab3:      	addq	%rsi, %rdx
   6aab6:      	addq	%rax, %rdx
   6aab9:      	cmpq	$0x0, 0xaf87(%rip)      # 0x75a48 <g.3>
   6aac1:      	je	0x7085f <f.2+0x180af>
   6aac7:      	cmpq	$0xd, %r12
   6aacb:      	ja	0x6aad7 <f.2+0x12327>
   6aacd:      	leaq	-0xc(%r12), %rbp
   6aad2:      	jmp	0x6b0b0 <f.2+0x12900>
   6aad7:      	cmpq	$0xe, %r12
   6aadb:      	jne	0x6aaf5 <f.2+0x12345>
   6aadd:      	movl	$0x1, %ebp
   6aae2:      	cmpq	$0x0, 0xaf5e(%rip)      # 0x75a48 <g.3>
   6aaea:      	jne	0x6ac58 <f.2+0x124a8>
   6aaf0:      	jmp	0x7085f <f.2+0x180af>
   6aaf5:      	cmpq	$0x10, %r12
   6aaf9:      	jb	0x6ac2c <f.2+0x1247c>
   6aaff:      	movq	%rdx, 0x18(%rsp)
   6ab04:      	movq	%rcx, 0x10(%rsp)
   6ab09:      	leaq	-0xf(%r12), %rsi
   6ab0e:      	movq	$0x0, 0x48(%rsp)
   6ab17:      	movq	$0x3, 0x30(%rsp)
   6ab20:      	xorl	%edi, %edi
   6ab22:      	callq	0x70870 <f.3>
   6ab27:      	subq	$0x8, %rsp
   6ab2b:      	cmpb	$0x0, 0xaf1e(%rip)      # 0x75a50 <g.4>
   6ab32:      	je	0x7085f <f.2+0x180af>
   6ab38:      	cmpq	$0x0, 0xaf08(%rip)      # 0x75a48 <g.3>
   6ab40:      	je	0x7085f <f.2+0x180af>
   6ab46:      	movq	%rax, %rbp
   6ab49:      	leaq	-0x10(%r12), %rsi
   6ab4e:      	movq	$0x0, 0x48(%rsp)
   6ab57:      	movq	$0x3, 0x30(%rsp)
   6ab60:      	xorl	%edi, %edi
   6ab62:      	callq	0x70870 <f.3>
   6ab67:      	subq	$0x8, %rsp
   6ab6b:      	cmpb	$0x0, 0xaede(%rip)      # 0x75a50 <g.4>
   6ab72:      	je	0x7085f <f.2+0x180af>
   6ab78:      	cmpq	$0x0, 0xaec8(%rip)      # 0x75a48 <g.3>
   6ab80:      	movq	0x10(%rsp), %rcx
   6ab85:      	movq	0x18(%rsp), %rdx
   6ab8a:      	je	0x7085f <f.2+0x180af>
   6ab90:      	addq	%rbp, %rax
   6ab93:      	cmpq	$0x10, %r12
   6ab97:      	je	0x6ac3f <f.2+0x1248f>
   6ab9d:      	movq	%rax, 0x50(%rsp)
   6aba2:      	movq	$0x0, 0x48(%rsp)
   6abab:      	movq	$0x3, 0x30(%rsp)
   6abb4:      	xorl	%edi, %edi
   6abb6:      	leaq	-0x10(%r12), %rsi
   6abbb:      	callq	0x70870 <f.3>
   6abc0:      	subq	$0x8, %rsp
   6abc4:      	cmpb	$0x0, 0xae85(%rip)      # 0x75a50 <g.4>
   6abcb:      	je	0x7085f <f.2+0x180af>
   6abd1:      	movq	%rax, 0x58(%rsp)
   6abd6:      	cmpq	$0x0, 0xae6a(%rip)      # 0x75a48 <g.3>
   6abde:      	je	0x7085f <f.2+0x180af>
   6abe4:      	leaq	-0x11(%r12), %rsi
   6abe9:      	movq	$0x0, 0x48(%rsp)
   6abf2:      	movq	$0x3, 0x30(%rsp)
   6abfb:      	xorl	%edi, %edi
   6abfd:      	callq	0x70870 <f.3>
   6ac02:      	subq	$0x8, %rsp
   6ac06:      	cmpb	$0x0, 0xae43(%rip)      # 0x75a50 <g.4>
   6ac0d:      	je	0x7085f <f.2+0x180af>
   6ac13:      	movq	%rax, %rbp
   6ac16:      	addq	0x58(%rsp), %rbp
   6ac1b:      	addq	0x50(%rsp), %rbp
   6ac20:      	movq	0x10(%rsp), %rcx
   6ac25:      	movq	0x18(%rsp), %rdx
   6ac2a:      	jmp	0x6ac44 <f.2+0x12494>
   6ac2c:      	movl	$0x1, %eax
   6ac31:      	cmpq	$0x0, 0xae0f(%rip)      # 0x75a48 <g.3>
   6ac39:      	je	0x7085f <f.2+0x180af>
   6ac3f:      	leaq	-0xf(%r12,%rax), %rbp
   6ac44:      	cmpq	$0x0, 0xadfc(%rip)      # 0x75a48 <g.3>
   6ac4c:      	je	0x7085f <f.2+0x180af>
   6ac52:      	cmpq	$0xf, %r12
   6ac56:      	ja	0x6ac62 <f.2+0x124b2>
   6ac58:      	leaq	-0xe(%r12), %rsi
   6ac5d:      	jmp	0x6b0ad <f.2+0x128fd>
   6ac62:      	cmpq	$0x10, %r12
   6ac66:      	jne	0x6ac80 <f.2+0x124d0>
   6ac68:      	movl	$0x1, %esi
   6ac6d:      	cmpq	$0x0, 0xadd3(%rip)      # 0x75a48 <g.3>
   6ac75:      	jne	0x6ad25 <f.2+0x12575>
   6ac7b:      	jmp	0x7085f <f.2+0x180af>
   6ac80:      	movq	%rdx, 0x18(%rsp)
   6ac85:      	movq	%rcx, 0x10(%rsp)
   6ac8a:      	leaq	-0x10(%r12), %rsi
   6ac8f:      	movq	$0x0, 0x48(%rsp)
   6ac98:      	movq	$0x3, 0x30(%rsp)
   6aca1:      	xorl	%edi, %edi
   6aca3:      	callq	0x70870 <f.3>
   6aca8:      	subq	$0x8, %rsp
   6acac:      	cmpb	$0x0, 0xad9d(%rip)      # 0x75a50 <g.4>
   6acb3:      	je	0x7085f <f.2+0x180af>
   6acb9:      	movq	%rax, 0x50(%rsp)
   6acbe:      	cmpq	$0x0, 0xad82(%rip)      # 0x75a48 <g.3>
   6acc6:      	je	0x7085f <f.2+0x180af>
   6accc:      	leaq	-0x11(%r12), %rsi
   6acd1:      	movq	$0x0, 0x48(%rsp)
   6acda:      	movq	$0x3, 0x30(%rsp)
   6ace3:      	xorl	%edi, %edi
   6ace5:      	callq	0x70870 <f.3>
   6acea:      	subq	$0x8, %rsp
   6acee:      	cmpb	$0x0, 0xad5b(%rip)      # 0x75a50 <g.4>
   6acf5:      	je	0x7085f <f.2+0x180af>
   6acfb:      	cmpq	$0x0, 0xad45(%rip)      # 0x75a48 <g.3>
   6ad03:      	movq	0x10(%rsp), %rcx
   6ad08:      	movq	0x18(%rsp), %rdx
   6ad0d:      	je	0x7085f <f.2+0x180af>
   6ad13:      	movq	%rax, %rsi
   6ad16:      	addq	0x50(%rsp), %rsi
   6ad1b:      	cmpq	$0x11, %r12
   6ad1f:      	ja	0x6b02d <f.2+0x1287d>
   6ad25:      	leaq	-0x10(%r12), %rax
   6ad2a:      	jmp	0x6b0aa <f.2+0x128fa>
   6ad2f:      	movq	%rdx, 0x50(%rsp)
   6ad34:      	movq	$0x0, 0x48(%rsp)
   6ad3d:      	movq	$0x3, 0x30(%rsp)
   6ad46:      	xorl	%edi, %edi
   6ad48:      	leaq	-0x10(%r12), %rsi
   6ad4d:      	callq	0x70870 <f.3>
   6ad52:      	subq	$0x8, %rsp
   6ad56:      	cmpb	$0x0, 0xacf3(%rip)      # 0x75a50 <g.4>
   6ad5d:      	je	0x7085f <f.2+0x180af>
   6ad63:      	movq	%rax, 0x58(%rsp)
   6ad68:      	cmpq	$0x0, 0xacd8(%rip)      # 0x75a48 <g.3>
   6ad70:      	je	0x7085f <f.2+0x180af>
   6ad76:      	leaq	-0x11(%r12), %rsi
   6ad7b:      	movq	$0x0, 0x48(%rsp)
   6ad84:      	movq	$0x3, 0x30(%rsp)
   6ad8d:      	xorl	%edi, %edi
   6ad8f:      	callq	0x70870 <f.3>
   6ad94:      	subq	$0x8, %rsp
   6ad98:      	movq	%rax, %r14
   6ad9b:      	addq	0x58(%rsp), %r14
   6ada0:      	movq	0x10(%rsp), %rcx
   6ada5:      	movq	0x18(%rsp), %rax
   6adaa:      	movq	0x50(%rsp), %rdx
   6adaf:      	cmpb	$0x0, 0xac9a(%rip)      # 0x75a50 <g.4>
   6adb6:      	je	0x7085f <f.2+0x180af>
   6adbc:      	addq	%rdx, %r14
   6adbf:      	addq	%rax, %r14
   6adc2:      	cmpq	$0x0, 0xac7e(%rip)      # 0x75a48 <g.3>
   6adca:      	je	0x7085f <f.2+0x180af>
   6add0:      	cmpq	$0xd, %r12
   6add4:      	ja	0x6ade0 <f.2+0x12630>
   6add6:      	leaq	-0xc(%r12), %rdx
   6addb:      	jmp	0x6bcf0 <f.2+0x13540>
   6ade0:      	cmpq	$0xe, %r12
   6ade4:      	jne	0x6adfe <f.2+0x1264e>
   6ade6:      	movl	$0x1, %edx
   6adeb:      	cmpq	$0x0, 0xac55(%rip)      # 0x75a48 <g.3>
   6adf3:      	jne	0x6af56 <f.2+0x127a6>
   6adf9:      	jmp	0x7085f <f.2+0x180af>
   6adfe:      	cmpq	$0x10, %r12
   6ae02:      	jb	0x6af2a <f.2+0x1277a>
   6ae08:      	movq	%rcx, 0x10(%rsp)
   6ae0d:      	leaq	-0xf(%r12), %rsi
   6ae12:      	movq	$0x0, 0x48(%rsp)
   6ae1b:      	movq	$0x3, 0x30(%rsp)
   6ae24:      	xorl	%edi, %edi
   6ae26:      	callq	0x70870 <f.3>
   6ae2b:      	subq	$0x8, %rsp
   6ae2f:      	cmpb	$0x0, 0xac1a(%rip)      # 0x75a50 <g.4>
   6ae36:      	je	0x7085f <f.2+0x180af>
   6ae3c:      	movq	%rax, 0x18(%rsp)
   6ae41:      	cmpq	$0x0, 0xabff(%rip)      # 0x75a48 <g.3>
   6ae49:      	je	0x7085f <f.2+0x180af>
   6ae4f:      	leaq	-0x10(%r12), %rsi
   6ae54:      	movq	$0x0, 0x48(%rsp)
   6ae5d:      	movq	$0x3, 0x30(%rsp)
   6ae66:      	xorl	%edi, %edi
   6ae68:      	callq	0x70870 <f.3>
   6ae6d:      	subq	$0x8, %rsp
   6ae71:      	cmpb	$0x0, 0xabd8(%rip)      # 0x75a50 <g.4>
   6ae78:      	je	0x7085f <f.2+0x180af>
   6ae7e:      	cmpq	$0x0, 0xabc2(%rip)      # 0x75a48 <g.3>
   6ae86:      	movq	0x10(%rsp), %rcx
   6ae8b:      	je	0x7085f <f.2+0x180af>
   6ae91:      	addq	0x18(%rsp), %rax
   6ae96:      	cmpq	$0x10, %r12
   6ae9a:      	je	0x6af3d <f.2+0x1278d>
   6aea0:      	movq	%rax, 0x18(%rsp)
   6aea5:      	movq	$0x0, 0x48(%rsp)
   6aeae:      	movq	$0x3, 0x30(%rsp)
   6aeb7:      	xorl	%edi, %edi
   6aeb9:      	leaq	-0x10(%r12), %rsi
   6aebe:      	callq	0x70870 <f.3>
   6aec3:      	subq	$0x8, %rsp
   6aec7:      	cmpb	$0x0, 0xab82(%rip)      # 0x75a50 <g.4>
   6aece:      	je	0x7085f <f.2+0x180af>
   6aed4:      	movq	%rax, 0x50(%rsp)
   6aed9:      	cmpq	$0x0, 0xab67(%rip)      # 0x75a48 <g.3>
   6aee1:      	je	0x7085f <f.2+0x180af>
   6aee7:      	leaq	-0x11(%r12), %rsi
   6aeec:      	movq	$0x0, 0x48(%rsp)
   6aef5:      	movq	$0x3, 0x30(%rsp)
   6aefe:      	xorl	%edi, %edi
   6af00:      	callq	0x70870 <f.3>
   6af05:      	subq	$0x8, %rsp
   6af09:      	cmpb	$0x0, 0xab40(%rip)      # 0x75a50 <g.4>
   6af10:      	je	0x7085f <f.2+0x180af>
   6af16:      	movq	%rax, %rdx
   6af19:      	addq	0x50(%rsp), %rdx
   6af1e:      	addq	0x18(%rsp), %rdx
   6af23:      	movq	0x10(%rsp), %rcx
   6af28:      	jmp	0x6af42 <f.2+0x12792>
   6af2a:      	movl	$0x1, %eax
   6af2f:      	cmpq	$0x0, 0xab11(%rip)      # 0x75a48 <g.3>
   6af37:      	je	0x7085f <f.2+0x180af>
   6af3d:      	leaq	-0xf(%r12,%rax), %rdx
   6af42:      	cmpq	$0x0, 0xaafe(%rip)      # 0x75a48 <g.3>
   6af4a:      	je	0x7085f <f.2+0x180af>
   6af50:      	cmpq	$0xf, %r12
   6af54:      	ja	0x6af60 <f.2+0x127b0>
   6af56:      	leaq	-0xe(%r12), %rsi
   6af5b:      	jmp	0x6bced <f.2+0x1353d>
   6af60:      	cmpq	$0x10, %r12
   6af64:      	jne	0x6af7e <f.2+0x127ce>
   6af66:      	movl	$0x1, %esi
   6af6b:      	cmpq	$0x0, 0xaad5(%rip)      # 0x75a48 <g.3>
   6af73:      	jne	0x6b023 <f.2+0x12873>
   6af79:      	jmp	0x7085f <f.2+0x180af>
   6af7e:      	movq	%rdx, 0x18(%rsp)
   6af83:      	movq	%rcx, 0x10(%rsp)
   6af88:      	leaq	-0x10(%r12), %rsi
   6af8d:      	movq	$0x0, 0x48(%rsp)
   6af96:      	movq	$0x3, 0x30(%rsp)
   6af9f:      	xorl	%edi, %edi
   6afa1:      	callq	0x70870 <f.3>
   6afa6:      	subq	$0x8, %rsp
   6afaa:      	cmpb	$0x0, 0xaa9f(%rip)      # 0x75a50 <g.4>
   6afb1:      	je	0x7085f <f.2+0x180af>
   6afb7:      	movq	%rax, 0x50(%rsp)
   6afbc:      	cmpq	$0x0, 0xaa84(%rip)      # 0x75a48 <g.3>
   6afc4:      	je	0x7085f <f.2+0x180af>
   6afca:      	leaq	-0x11(%r12), %rsi
   6afcf:      	movq	$0x0, 0x48(%rsp)
   6afd8:      	movq	$0x3, 0x30(%rsp)
   6afe1:      	xorl	%edi, %edi
   6afe3:      	callq	0x70870 <f.3>
   6afe8:      	subq	$0x8, %rsp
   6afec:      	cmpb	$0x0, 0xaa5d(%rip)      # 0x75a50 <g.4>
   6aff3:      	je	0x7085f <f.2+0x180af>
   6aff9:      	cmpq	$0x0, 0xaa47(%rip)      # 0x75a48 <g.3>
   6b001:      	movq	0x10(%rsp), %rcx
   6b006:      	movq	0x18(%rsp), %rdx
   6b00b:      	je	0x7085f <f.2+0x180af>
   6b011:      	movq	%rax, %rsi
   6b014:      	addq	0x50(%rsp), %rsi
   6b019:      	cmpq	$0x11, %r12
   6b01d:      	ja	0x6bc6d <f.2+0x134bd>
   6b023:      	leaq	-0x10(%r12), %rax
   6b028:      	jmp	0x6bcea <f.2+0x1353a>
   6b02d:      	movq	%rsi, 0x50(%rsp)
   6b032:      	movq	$0x0, 0x48(%rsp)
   6b03b:      	movq	$0x3, 0x30(%rsp)
   6b044:      	xorl	%edi, %edi
   6b046:      	leaq	-0x11(%r12), %rsi
   6b04b:      	callq	0x70870 <f.3>
   6b050:      	subq	$0x8, %rsp
   6b054:      	cmpb	$0x0, 0xa9f5(%rip)      # 0x75a50 <g.4>
   6b05b:      	je	0x7085f <f.2+0x180af>
   6b061:      	movq	%rax, 0x58(%rsp)
   6b066:      	cmpq	$0x0, 0xa9da(%rip)      # 0x75a48 <g.3>
   6b06e:      	je	0x7085f <f.2+0x180af>
   6b074:      	leaq	-0x12(%r12), %rsi
   6b079:      	movq	$0x0, 0x48(%rsp)
   6b082:      	movq	$0x3, 0x30(%rsp)
   6b08b:      	xorl	%edi, %edi
   6b08d:      	callq	0x70870 <f.3>
   6b092:      	subq	$0x8, %rsp
   6b096:      	addq	0x58(%rsp), %rax
   6b09b:      	movq	0x10(%rsp), %rcx
   6b0a0:      	movq	0x18(%rsp), %rdx
   6b0a5:      	movq	0x50(%rsp), %rsi
   6b0aa:      	addq	%rax, %rsi
   6b0ad:      	addq	%rsi, %rbp
   6b0b0:      	cmpb	$0x0, 0xa999(%rip)      # 0x75a50 <g.4>
   6b0b7:      	je	0x7085f <f.2+0x180af>
   6b0bd:      	addq	%rdx, %rbp
   6b0c0:      	addq	%rcx, %rbp
   6b0c3:      	cmpq	$0x0, 0xa97d(%rip)      # 0x75a48 <g.3>
   6b0cb:      	je	0x7085f <f.2+0x180af>
   6b0d1:      	cmpq	$0xa, %r12
   6b0d5:      	ja	0x6b0f1 <f.2+0x12941>
   6b0d7:      	leaq	-0x9(%r12), %rcx
   6b0dc:      	addq	%rcx, %rbp
   6b0df:      	cmpb	$0x0, 0xa96a(%rip)      # 0x75a50 <g.4>
   6b0e6:      	jne	0x68d53 <f.2+0x105a3>
   6b0ec:      	jmp	0x7085f <f.2+0x180af>
   6b0f1:      	cmpq	$0xb, %r12
   6b0f5:      	jne	0x6b10f <f.2+0x1295f>
   6b0f7:      	movl	$0x1, %ecx
   6b0fc:      	cmpq	$0x0, 0xa944(%rip)      # 0x75a48 <g.3>
   6b104:      	jne	0x6b6ec <f.2+0x12f3c>
   6b10a:      	jmp	0x7085f <f.2+0x180af>
   6b10f:      	cmpq	$0xd, %r12
   6b113:      	jb	0x6b12f <f.2+0x1297f>
   6b115:      	jne	0x6b147 <f.2+0x12997>
   6b117:      	movl	$0x1, %eax
   6b11c:      	cmpq	$0x0, 0xa924(%rip)      # 0x75a48 <g.3>
   6b124:      	jne	0x6b28d <f.2+0x12add>
   6b12a:      	jmp	0x7085f <f.2+0x180af>
   6b12f:      	movl	$0x1, %edx
   6b134:      	cmpq	$0x0, 0xa90c(%rip)      # 0x75a48 <g.3>
   6b13c:      	jne	0x6b3fb <f.2+0x12c4b>
   6b142:      	jmp	0x7085f <f.2+0x180af>
   6b147:      	cmpq	$0xf, %r12
   6b14b:      	jb	0x6b261 <f.2+0x12ab1>
   6b151:      	leaq	-0xe(%r12), %rsi
   6b156:      	movq	$0x0, 0x48(%rsp)
   6b15f:      	movq	$0x3, 0x30(%rsp)
   6b168:      	xorl	%edi, %edi
   6b16a:      	callq	0x70870 <f.3>
   6b16f:      	subq	$0x8, %rsp
   6b173:      	cmpb	$0x0, 0xa8d6(%rip)      # 0x75a50 <g.4>
   6b17a:      	je	0x7085f <f.2+0x180af>
   6b180:      	movq	%rax, 0x10(%rsp)
   6b185:      	cmpq	$0x0, 0xa8bb(%rip)      # 0x75a48 <g.3>
   6b18d:      	je	0x7085f <f.2+0x180af>
   6b193:      	leaq	-0xf(%r12), %rsi
   6b198:      	movq	$0x0, 0x48(%rsp)
   6b1a1:      	movq	$0x3, 0x30(%rsp)
   6b1aa:      	xorl	%edi, %edi
   6b1ac:      	callq	0x70870 <f.3>
   6b1b1:      	subq	$0x8, %rsp
   6b1b5:      	cmpb	$0x0, 0xa894(%rip)      # 0x75a50 <g.4>
   6b1bc:      	je	0x7085f <f.2+0x180af>
   6b1c2:      	cmpq	$0x0, 0xa87e(%rip)      # 0x75a48 <g.3>
   6b1ca:      	je	0x7085f <f.2+0x180af>
   6b1d0:      	addq	0x10(%rsp), %rax
   6b1d5:      	cmpq	$0xf, %r12
   6b1d9:      	je	0x6b274 <f.2+0x12ac4>
   6b1df:      	movq	%rax, 0x10(%rsp)
   6b1e4:      	movq	$0x0, 0x48(%rsp)
   6b1ed:      	movq	$0x3, 0x30(%rsp)
   6b1f6:      	xorl	%edi, %edi
   6b1f8:      	leaq	-0xf(%r12), %rsi
   6b1fd:      	callq	0x70870 <f.3>
   6b202:      	subq	$0x8, %rsp
   6b206:      	cmpb	$0x0, 0xa843(%rip)      # 0x75a50 <g.4>
   6b20d:      	je	0x7085f <f.2+0x180af>
   6b213:      	movq	%rax, 0x18(%rsp)
   6b218:      	cmpq	$0x0, 0xa828(%rip)      # 0x75a48 <g.3>
   6b220:      	je	0x7085f <f.2+0x180af>
   6b226:      	leaq	-0x10(%r12), %rsi
   6b22b:      	movq	$0x0, 0x48(%rsp)
   6b234:      	movq	$0x3, 0x30(%rsp)
   6b23d:      	xorl	%edi, %edi
   6b23f:      	callq	0x70870 <f.3>
   6b244:      	subq	$0x8, %rsp
   6b248:      	cmpb	$0x0, 0xa801(%rip)      # 0x75a50 <g.4>
   6b24f:      	je	0x7085f <f.2+0x180af>
   6b255:      	addq	0x18(%rsp), %rax
   6b25a:      	addq	0x10(%rsp), %rax
   6b25f:      	jmp	0x6b279 <f.2+0x12ac9>
   6b261:      	movl	$0x1, %eax
   6b266:      	cmpq	$0x0, 0xa7da(%rip)      # 0x75a48 <g.3>
   6b26e:      	je	0x7085f <f.2+0x180af>
   6b274:      	leaq	-0xe(%r12,%rax), %rax
   6b279:      	cmpq	$0x0, 0xa7c7(%rip)      # 0x75a48 <g.3>
   6b281:      	je	0x7085f <f.2+0x180af>
   6b287:      	cmpq	$0xe, %r12
   6b28b:      	ja	0x6b297 <f.2+0x12ae7>
   6b28d:      	leaq	-0xd(%r12,%rax), %rdx
   6b292:      	jmp	0x6b3e1 <f.2+0x12c31>
   6b297:      	cmpq	$0xf, %r12
   6b29b:      	jne	0x6b2b5 <f.2+0x12b05>
   6b29d:      	movl	$0x1, %ecx
   6b2a2:      	cmpq	$0x0, 0xa79e(%rip)      # 0x75a48 <g.3>
   6b2aa:      	jne	0x6b34c <f.2+0x12b9c>
   6b2b0:      	jmp	0x7085f <f.2+0x180af>
   6b2b5:      	movq	%rax, 0x10(%rsp)
   6b2ba:      	leaq	-0xf(%r12), %rsi
   6b2bf:      	movq	$0x0, 0x48(%rsp)
   6b2c8:      	movq	$0x3, 0x30(%rsp)
   6b2d1:      	xorl	%edi, %edi
   6b2d3:      	callq	0x70870 <f.3>
   6b2d8:      	subq	$0x8, %rsp
   6b2dc:      	cmpb	$0x0, 0xa76d(%rip)      # 0x75a50 <g.4>
   6b2e3:      	je	0x7085f <f.2+0x180af>
   6b2e9:      	movq	%rax, 0x18(%rsp)
   6b2ee:      	cmpq	$0x0, 0xa752(%rip)      # 0x75a48 <g.3>
   6b2f6:      	je	0x7085f <f.2+0x180af>
   6b2fc:      	leaq	-0x10(%r12), %rsi
   6b301:      	movq	$0x0, 0x48(%rsp)
   6b30a:      	movq	$0x3, 0x30(%rsp)
   6b313:      	xorl	%edi, %edi
   6b315:      	callq	0x70870 <f.3>
   6b31a:      	subq	$0x8, %rsp
   6b31e:      	cmpb	$0x0, 0xa72b(%rip)      # 0x75a50 <g.4>
   6b325:      	je	0x7085f <f.2+0x180af>
   6b32b:      	movq	%rax, %rcx
   6b32e:      	cmpq	$0x0, 0xa712(%rip)      # 0x75a48 <g.3>
   6b336:      	movq	0x10(%rsp), %rax
   6b33b:      	je	0x7085f <f.2+0x180af>
   6b341:      	addq	0x18(%rsp), %rcx
   6b346:      	cmpq	$0x10, %r12
   6b34a:      	ja	0x6b353 <f.2+0x12ba3>
   6b34c:      	leaq	-0xf(%r12), %rdx
   6b351:      	jmp	0x6b3ce <f.2+0x12c1e>
   6b353:      	movq	%rcx, 0x18(%rsp)
   6b358:      	movq	$0x0, 0x48(%rsp)
   6b361:      	movq	$0x3, 0x30(%rsp)
   6b36a:      	xorl	%edi, %edi
   6b36c:      	leaq	-0x10(%r12), %rsi
   6b371:      	callq	0x70870 <f.3>
   6b376:      	subq	$0x8, %rsp
   6b37a:      	cmpb	$0x0, 0xa6cf(%rip)      # 0x75a50 <g.4>
   6b381:      	je	0x7085f <f.2+0x180af>
   6b387:      	movq	%rax, 0x50(%rsp)
   6b38c:      	cmpq	$0x0, 0xa6b4(%rip)      # 0x75a48 <g.3>
   6b394:      	je	0x7085f <f.2+0x180af>
   6b39a:      	leaq	-0x11(%r12), %rsi
   6b39f:      	movq	$0x0, 0x48(%rsp)
   6b3a8:      	movq	$0x3, 0x30(%rsp)
   6b3b1:      	xorl	%edi, %edi
   6b3b3:      	callq	0x70870 <f.3>
   6b3b8:      	subq	$0x8, %rsp
   6b3bc:      	movq	%rax, %rdx
   6b3bf:      	addq	0x50(%rsp), %rdx
   6b3c4:      	movq	0x10(%rsp), %rax
   6b3c9:      	movq	0x18(%rsp), %rcx
   6b3ce:      	cmpb	$0x0, 0xa67b(%rip)      # 0x75a50 <g.4>
   6b3d5:      	je	0x7085f <f.2+0x180af>
   6b3db:      	addq	%rcx, %rdx
   6b3de:      	addq	%rax, %rdx
   6b3e1:      	cmpq	$0x0, 0xa65f(%rip)      # 0x75a48 <g.3>
   6b3e9:      	je	0x7085f <f.2+0x180af>
   6b3ef:      	cmpq	$0xe, %r12
   6b3f3:      	je	0x6b405 <f.2+0x12c55>
   6b3f5:      	cmpq	$0xd, %r12
   6b3f9:      	jne	0x6b41d <f.2+0x12c6d>
   6b3fb:      	leaq	-0xc(%r12,%rdx), %rcx
   6b400:      	jmp	0x6b6d8 <f.2+0x12f28>
   6b405:      	movl	$0x1, %esi
   6b40a:      	cmpq	$0x0, 0xa636(%rip)      # 0x75a48 <g.3>
   6b412:      	jne	0x6b575 <f.2+0x12dc5>
   6b418:      	jmp	0x7085f <f.2+0x180af>
   6b41d:      	cmpq	$0x10, %r12
   6b421:      	jb	0x6b549 <f.2+0x12d99>
   6b427:      	movq	%rdx, 0x18(%rsp)
   6b42c:      	leaq	-0xf(%r12), %rsi
   6b431:      	movq	$0x0, 0x48(%rsp)
   6b43a:      	movq	$0x3, 0x30(%rsp)
   6b443:      	xorl	%edi, %edi
   6b445:      	callq	0x70870 <f.3>
   6b44a:      	subq	$0x8, %rsp
   6b44e:      	cmpb	$0x0, 0xa5fb(%rip)      # 0x75a50 <g.4>
   6b455:      	je	0x7085f <f.2+0x180af>
   6b45b:      	movq	%rax, 0x10(%rsp)
   6b460:      	cmpq	$0x0, 0xa5e0(%rip)      # 0x75a48 <g.3>
   6b468:      	je	0x7085f <f.2+0x180af>
   6b46e:      	leaq	-0x10(%r12), %rsi
   6b473:      	movq	$0x0, 0x48(%rsp)
   6b47c:      	movq	$0x3, 0x30(%rsp)
   6b485:      	xorl	%edi, %edi
   6b487:      	callq	0x70870 <f.3>
   6b48c:      	subq	$0x8, %rsp
   6b490:      	cmpb	$0x0, 0xa5b9(%rip)      # 0x75a50 <g.4>
   6b497:      	je	0x7085f <f.2+0x180af>
   6b49d:      	cmpq	$0x0, 0xa5a3(%rip)      # 0x75a48 <g.3>
   6b4a5:      	movq	0x18(%rsp), %rdx
   6b4aa:      	je	0x7085f <f.2+0x180af>
   6b4b0:      	addq	0x10(%rsp), %rax
   6b4b5:      	cmpq	$0x10, %r12
   6b4b9:      	je	0x6b55c <f.2+0x12dac>
   6b4bf:      	movq	%rax, 0x10(%rsp)
   6b4c4:      	movq	$0x0, 0x48(%rsp)
   6b4cd:      	movq	$0x3, 0x30(%rsp)
   6b4d6:      	xorl	%edi, %edi
   6b4d8:      	leaq	-0x10(%r12), %rsi
   6b4dd:      	callq	0x70870 <f.3>
   6b4e2:      	subq	$0x8, %rsp
   6b4e6:      	cmpb	$0x0, 0xa563(%rip)      # 0x75a50 <g.4>
   6b4ed:      	je	0x7085f <f.2+0x180af>
   6b4f3:      	movq	%rax, 0x50(%rsp)
   6b4f8:      	cmpq	$0x0, 0xa548(%rip)      # 0x75a48 <g.3>
   6b500:      	je	0x7085f <f.2+0x180af>
   6b506:      	leaq	-0x11(%r12), %rsi
   6b50b:      	movq	$0x0, 0x48(%rsp)
   6b514:      	movq	$0x3, 0x30(%rsp)
   6b51d:      	xorl	%edi, %edi
   6b51f:      	callq	0x70870 <f.3>
   6b524:      	subq	$0x8, %rsp
   6b528:      	cmpb	$0x0, 0xa521(%rip)      # 0x75a50 <g.4>
   6b52f:      	je	0x7085f <f.2+0x180af>
   6b535:      	movq	%rax, %rsi
   6b538:      	addq	0x50(%rsp), %rsi
   6b53d:      	addq	0x10(%rsp), %rsi
   6b542:      	movq	0x18(%rsp), %rdx
   6b547:      	jmp	0x6b561 <f.2+0x12db1>
   6b549:      	movl	$0x1, %eax
   6b54e:      	cmpq	$0x0, 0xa4f2(%rip)      # 0x75a48 <g.3>
   6b556:      	je	0x7085f <f.2+0x180af>
   6b55c:      	leaq	-0xf(%r12,%rax), %rsi
   6b561:      	cmpq	$0x0, 0xa4df(%rip)      # 0x75a48 <g.3>
   6b569:      	je	0x7085f <f.2+0x180af>
   6b56f:      	cmpq	$0xf, %r12
   6b573:      	ja	0x6b57f <f.2+0x12dcf>
   6b575:      	leaq	-0xe(%r12), %rcx
   6b57a:      	jmp	0x6b6c5 <f.2+0x12f15>
   6b57f:      	cmpq	$0x10, %r12
   6b583:      	jne	0x6b59d <f.2+0x12ded>
   6b585:      	movl	$0x1, %ecx
   6b58a:      	cmpq	$0x0, 0xa4b6(%rip)      # 0x75a48 <g.3>
   6b592:      	jne	0x6b63e <f.2+0x12e8e>
   6b598:      	jmp	0x7085f <f.2+0x180af>
   6b59d:      	movq	%rsi, 0x50(%rsp)
   6b5a2:      	movq	%rdx, 0x18(%rsp)
   6b5a7:      	leaq	-0x10(%r12), %rsi
   6b5ac:      	movq	$0x0, 0x48(%rsp)
   6b5b5:      	movq	$0x3, 0x30(%rsp)
   6b5be:      	xorl	%edi, %edi
   6b5c0:      	callq	0x70870 <f.3>
   6b5c5:      	subq	$0x8, %rsp
   6b5c9:      	cmpb	$0x0, 0xa480(%rip)      # 0x75a50 <g.4>
   6b5d0:      	je	0x7085f <f.2+0x180af>
   6b5d6:      	movq	%rax, 0x10(%rsp)
   6b5db:      	cmpq	$0x0, 0xa465(%rip)      # 0x75a48 <g.3>
   6b5e3:      	je	0x7085f <f.2+0x180af>
   6b5e9:      	leaq	-0x11(%r12), %rsi
   6b5ee:      	movq	$0x0, 0x48(%rsp)
   6b5f7:      	movq	$0x3, 0x30(%rsp)
   6b600:      	xorl	%edi, %edi
   6b602:      	callq	0x70870 <f.3>
   6b607:      	subq	$0x8, %rsp
   6b60b:      	cmpb	$0x0, 0xa43e(%rip)      # 0x75a50 <g.4>
   6b612:      	je	0x7085f <f.2+0x180af>
   6b618:      	cmpq	$0x0, 0xa428(%rip)      # 0x75a48 <g.3>
   6b620:      	movq	0x18(%rsp), %rdx
   6b625:      	movq	0x50(%rsp), %rsi
   6b62a:      	je	0x7085f <f.2+0x180af>
   6b630:      	movq	%rax, %rcx
   6b633:      	addq	0x10(%rsp), %rcx
   6b638:      	cmpq	$0x11, %r12
   6b63c:      	ja	0x6b645 <f.2+0x12e95>
   6b63e:      	leaq	-0x10(%r12), %rax
   6b643:      	jmp	0x6b6c2 <f.2+0x12f12>
   6b645:      	movq	%rcx, 0x10(%rsp)
   6b64a:      	movq	$0x0, 0x48(%rsp)
   6b653:      	movq	$0x3, 0x30(%rsp)
   6b65c:      	xorl	%edi, %edi
   6b65e:      	leaq	-0x11(%r12), %rsi
   6b663:      	callq	0x70870 <f.3>
   6b668:      	subq	$0x8, %rsp
   6b66c:      	cmpb	$0x0, 0xa3dd(%rip)      # 0x75a50 <g.4>
   6b673:      	je	0x7085f <f.2+0x180af>
   6b679:      	movq	%rax, 0x58(%rsp)
   6b67e:      	cmpq	$0x0, 0xa3c2(%rip)      # 0x75a48 <g.3>
   6b686:      	je	0x7085f <f.2+0x180af>
   6b68c:      	leaq	-0x12(%r12), %rsi
   6b691:      	movq	$0x0, 0x48(%rsp)
   6b69a:      	movq	$0x3, 0x30(%rsp)
   6b6a3:      	xorl	%edi, %edi
   6b6a5:      	callq	0x70870 <f.3>
   6b6aa:      	subq	$0x8, %rsp
   6b6ae:      	addq	0x58(%rsp), %rax
   6b6b3:      	movq	0x10(%rsp), %rcx
   6b6b8:      	movq	0x18(%rsp), %rdx
   6b6bd:      	movq	0x50(%rsp), %rsi
   6b6c2:      	addq	%rax, %rcx
   6b6c5:      	cmpb	$0x0, 0xa384(%rip)      # 0x75a50 <g.4>
   6b6cc:      	je	0x7085f <f.2+0x180af>
   6b6d2:      	addq	%rsi, %rcx
   6b6d5:      	addq	%rdx, %rcx
   6b6d8:      	cmpq	$0x0, 0xa368(%rip)      # 0x75a48 <g.3>
   6b6e0:      	je	0x7085f <f.2+0x180af>
   6b6e6:      	cmpq	$0xc, %r12
   6b6ea:      	ja	0x6b6f6 <f.2+0x12f46>
   6b6ec:      	leaq	-0xb(%r12), %rdx
   6b6f1:      	jmp	0x6d54a <f.2+0x14d9a>
   6b6f6:      	cmpq	$0xd, %r12
   6b6fa:      	jne	0x6b714 <f.2+0x12f64>
   6b6fc:      	movl	$0x1, %edx
   6b701:      	cmpq	$0x0, 0xa33f(%rip)      # 0x75a48 <g.3>
   6b709:      	jne	0x6b9fd <f.2+0x1324d>
   6b70f:      	jmp	0x7085f <f.2+0x180af>
   6b714:      	cmpq	$0xf, %r12
   6b718:      	jb	0x6b734 <f.2+0x12f84>
   6b71a:      	jne	0x6b74c <f.2+0x12f9c>
   6b71c:      	movl	$0x1, %eax
   6b721:      	cmpq	$0x0, 0xa31f(%rip)      # 0x75a48 <g.3>
   6b729:      	jne	0x6b7e0 <f.2+0x13030>
   6b72f:      	jmp	0x7085f <f.2+0x180af>
   6b734:      	movl	$0x1, %eax
   6b739:      	cmpq	$0x0, 0xa307(%rip)      # 0x75a48 <g.3>
   6b741:      	jne	0x6b889 <f.2+0x130d9>
   6b747:      	jmp	0x7085f <f.2+0x180af>
   6b74c:      	movq	%rcx, 0x10(%rsp)
   6b751:      	leaq	-0xf(%r12), %rsi
   6b756:      	movq	$0x0, 0x48(%rsp)
   6b75f:      	movq	$0x3, 0x30(%rsp)
   6b768:      	xorl	%edi, %edi
   6b76a:      	callq	0x70870 <f.3>
   6b76f:      	subq	$0x8, %rsp
   6b773:      	cmpb	$0x0, 0xa2d6(%rip)      # 0x75a50 <g.4>
   6b77a:      	je	0x7085f <f.2+0x180af>
   6b780:      	movq	%rax, 0x18(%rsp)
   6b785:      	cmpq	$0x0, 0xa2bb(%rip)      # 0x75a48 <g.3>
   6b78d:      	je	0x7085f <f.2+0x180af>
   6b793:      	leaq	-0x10(%r12), %rsi
   6b798:      	movq	$0x0, 0x48(%rsp)
   6b7a1:      	movq	$0x3, 0x30(%rsp)
   6b7aa:      	xorl	%edi, %edi
   6b7ac:      	callq	0x70870 <f.3>
   6b7b1:      	subq	$0x8, %rsp
   6b7b5:      	cmpb	$0x0, 0xa294(%rip)      # 0x75a50 <g.4>
   6b7bc:      	je	0x7085f <f.2+0x180af>
   6b7c2:      	cmpq	$0x0, 0xa27e(%rip)      # 0x75a48 <g.3>
   6b7ca:      	movq	0x10(%rsp), %rcx
   6b7cf:      	je	0x7085f <f.2+0x180af>
   6b7d5:      	addq	0x18(%rsp), %rax
   6b7da:      	cmpq	$0x10, %r12
   6b7de:      	ja	0x6b7ea <f.2+0x1303a>
   6b7e0:      	leaq	-0xf(%r12,%rax), %rax
   6b7e5:      	jmp	0x6b86f <f.2+0x130bf>
   6b7ea:      	movq	%rax, 0x18(%rsp)
   6b7ef:      	movq	$0x0, 0x48(%rsp)
   6b7f8:      	movq	$0x3, 0x30(%rsp)
   6b801:      	xorl	%edi, %edi
   6b803:      	leaq	-0x10(%r12), %rsi
   6b808:      	callq	0x70870 <f.3>
   6b80d:      	subq	$0x8, %rsp
   6b811:      	cmpb	$0x0, 0xa238(%rip)      # 0x75a50 <g.4>
   6b818:      	je	0x7085f <f.2+0x180af>
   6b81e:      	movq	%rax, 0x50(%rsp)
   6b823:      	cmpq	$0x0, 0xa21d(%rip)      # 0x75a48 <g.3>
   6b82b:      	je	0x7085f <f.2+0x180af>
   6b831:      	leaq	-0x11(%r12), %rsi
   6b836:      	movq	$0x0, 0x48(%rsp)
   6b83f:      	movq	$0x3, 0x30(%rsp)
   6b848:      	xorl	%edi, %edi
   6b84a:      	callq	0x70870 <f.3>
   6b84f:      	subq	$0x8, %rsp
   6b853:      	cmpb	$0x0, 0xa1f6(%rip)      # 0x75a50 <g.4>
   6b85a:      	je	0x7085f <f.2+0x180af>
   6b860:      	addq	0x50(%rsp), %rax
   6b865:      	addq	0x18(%rsp), %rax
   6b86a:      	movq	0x10(%rsp), %rcx
   6b86f:      	cmpq	$0x0, 0xa1d1(%rip)      # 0x75a48 <g.3>
   6b877:      	je	0x7085f <f.2+0x180af>
   6b87d:      	cmpq	$0x10, %r12
   6b881:      	je	0x6b893 <f.2+0x130e3>
   6b883:      	cmpq	$0xf, %r12
   6b887:      	jne	0x6b8ab <f.2+0x130fb>
   6b889:      	leaq	-0xe(%r12,%rax), %rdx
   6b88e:      	jmp	0x6b9e9 <f.2+0x13239>
   6b893:      	movl	$0x1, %esi
   6b898:      	cmpq	$0x0, 0xa1a8(%rip)      # 0x75a48 <g.3>
   6b8a0:      	jne	0x6b94c <f.2+0x1319c>
   6b8a6:      	jmp	0x7085f <f.2+0x180af>
   6b8ab:      	movq	%rax, 0x18(%rsp)
   6b8b0:      	movq	%rcx, 0x10(%rsp)
   6b8b5:      	leaq	-0x10(%r12), %rsi
   6b8ba:      	movq	$0x0, 0x48(%rsp)
   6b8c3:      	movq	$0x3, 0x30(%rsp)
   6b8cc:      	xorl	%edi, %edi
   6b8ce:      	callq	0x70870 <f.3>
   6b8d3:      	subq	$0x8, %rsp
   6b8d7:      	cmpb	$0x0, 0xa172(%rip)      # 0x75a50 <g.4>
   6b8de:      	je	0x7085f <f.2+0x180af>
   6b8e4:      	movq	%rax, 0x50(%rsp)
   6b8e9:      	cmpq	$0x0, 0xa157(%rip)      # 0x75a48 <g.3>
   6b8f1:      	je	0x7085f <f.2+0x180af>
   6b8f7:      	leaq	-0x11(%r12), %rsi
   6b8fc:      	movq	$0x0, 0x48(%rsp)
   6b905:      	movq	$0x3, 0x30(%rsp)
   6b90e:      	xorl	%edi, %edi
   6b910:      	callq	0x70870 <f.3>
   6b915:      	subq	$0x8, %rsp
   6b919:      	cmpb	$0x0, 0xa130(%rip)      # 0x75a50 <g.4>
   6b920:      	je	0x7085f <f.2+0x180af>
   6b926:      	movq	%rax, %rsi
   6b929:      	cmpq	$0x0, 0xa117(%rip)      # 0x75a48 <g.3>
   6b931:      	movq	0x10(%rsp), %rcx
   6b936:      	movq	0x18(%rsp), %rax
   6b93b:      	je	0x7085f <f.2+0x180af>
   6b941:      	addq	0x50(%rsp), %rsi
   6b946:      	cmpq	$0x11, %r12
   6b94a:      	ja	0x6b956 <f.2+0x131a6>
   6b94c:      	leaq	-0x10(%r12), %rdx
   6b951:      	jmp	0x6b9d6 <f.2+0x13226>
   6b956:      	movq	%rsi, 0x50(%rsp)
   6b95b:      	movq	$0x0, 0x48(%rsp)
   6b964:      	movq	$0x3, 0x30(%rsp)
   6b96d:      	xorl	%edi, %edi
   6b96f:      	leaq	-0x11(%r12), %rsi
   6b974:      	callq	0x70870 <f.3>
   6b979:      	subq	$0x8, %rsp
   6b97d:      	cmpb	$0x0, 0xa0cc(%rip)      # 0x75a50 <g.4>
   6b984:      	je	0x7085f <f.2+0x180af>
   6b98a:      	movq	%rax, 0x58(%rsp)
   6b98f:      	cmpq	$0x0, 0xa0b1(%rip)      # 0x75a48 <g.3>
   6b997:      	je	0x7085f <f.2+0x180af>
   6b99d:      	leaq	-0x12(%r12), %rsi
   6b9a2:      	movq	$0x0, 0x48(%rsp)
   6b9ab:      	movq	$0x3, 0x30(%rsp)
   6b9b4:      	xorl	%edi, %edi
   6b9b6:      	callq	0x70870 <f.3>
   6b9bb:      	subq	$0x8, %rsp
   6b9bf:      	movq	%rax, %rdx
   6b9c2:      	addq	0x58(%rsp), %rdx
   6b9c7:      	movq	0x10(%rsp), %rcx
   6b9cc:      	movq	0x18(%rsp), %rax
   6b9d1:      	movq	0x50(%rsp), %rsi
   6b9d6:      	cmpb	$0x0, 0xa073(%rip)      # 0x75a50 <g.4>
   6b9dd:      	je	0x7085f <f.2+0x180af>
   6b9e3:      	addq	%rsi, %rdx
   6b9e6:      	addq	%rax, %rdx
   6b9e9:      	cmpq	$0x0, 0xa057(%rip)      # 0x75a48 <g.3>
   6b9f1:      	je	0x7085f <f.2+0x180af>
   6b9f7:      	cmpq	$0xe, %r12
   6b9fb:      	ja	0x6ba07 <f.2+0x13257>
   6b9fd:      	leaq	-0xd(%r12), %rsi
   6ba02:      	jmp	0x6d547 <f.2+0x14d97>
   6ba07:      	cmpq	$0xf, %r12
   6ba0b:      	jne	0x6ba25 <f.2+0x13275>
   6ba0d:      	movl	$0x1, %esi
   6ba12:      	cmpq	$0x0, 0xa02e(%rip)      # 0x75a48 <g.3>
   6ba1a:      	jne	0x6bb8c <f.2+0x133dc>
   6ba20:      	jmp	0x7085f <f.2+0x180af>
   6ba25:      	cmpq	$0x11, %r12
   6ba29:      	jb	0x6bb60 <f.2+0x133b0>
   6ba2f:      	movq	%rdx, 0x18(%rsp)
   6ba34:      	movq	%rcx, 0x10(%rsp)
   6ba39:      	leaq	-0x10(%r12), %rsi
   6ba3e:      	movq	$0x0, 0x48(%rsp)
   6ba47:      	movq	$0x3, 0x30(%rsp)
   6ba50:      	xorl	%edi, %edi
   6ba52:      	callq	0x70870 <f.3>
   6ba57:      	subq	$0x8, %rsp
   6ba5b:      	cmpb	$0x0, 0x9fee(%rip)      # 0x75a50 <g.4>
   6ba62:      	je	0x7085f <f.2+0x180af>
   6ba68:      	movq	%rax, 0x50(%rsp)
   6ba6d:      	cmpq	$0x0, 0x9fd3(%rip)      # 0x75a48 <g.3>
   6ba75:      	je	0x7085f <f.2+0x180af>
   6ba7b:      	leaq	-0x11(%r12), %rsi
   6ba80:      	movq	$0x0, 0x48(%rsp)
   6ba89:      	movq	$0x3, 0x30(%rsp)
   6ba92:      	xorl	%edi, %edi
   6ba94:      	callq	0x70870 <f.3>
   6ba99:      	subq	$0x8, %rsp
   6ba9d:      	cmpb	$0x0, 0x9fac(%rip)      # 0x75a50 <g.4>
   6baa4:      	je	0x7085f <f.2+0x180af>
   6baaa:      	cmpq	$0x0, 0x9f96(%rip)      # 0x75a48 <g.3>
   6bab2:      	movq	0x10(%rsp), %rcx
   6bab7:      	movq	0x18(%rsp), %rdx
   6babc:      	je	0x7085f <f.2+0x180af>
   6bac2:      	addq	0x50(%rsp), %rax
   6bac7:      	cmpq	$0x11, %r12
   6bacb:      	je	0x6bb73 <f.2+0x133c3>
   6bad1:      	movq	%rax, 0x50(%rsp)
   6bad6:      	movq	$0x0, 0x48(%rsp)
   6badf:      	movq	$0x3, 0x30(%rsp)
   6bae8:      	xorl	%edi, %edi
   6baea:      	leaq	-0x11(%r12), %rsi
   6baef:      	callq	0x70870 <f.3>
   6baf4:      	subq	$0x8, %rsp
   6baf8:      	cmpb	$0x0, 0x9f51(%rip)      # 0x75a50 <g.4>
   6baff:      	je	0x7085f <f.2+0x180af>
   6bb05:      	movq	%rax, 0x58(%rsp)
   6bb0a:      	cmpq	$0x0, 0x9f36(%rip)      # 0x75a48 <g.3>
   6bb12:      	je	0x7085f <f.2+0x180af>
   6bb18:      	leaq	-0x12(%r12), %rsi
   6bb1d:      	movq	$0x0, 0x48(%rsp)
   6bb26:      	movq	$0x3, 0x30(%rsp)
   6bb2f:      	xorl	%edi, %edi
   6bb31:      	callq	0x70870 <f.3>
   6bb36:      	subq	$0x8, %rsp
   6bb3a:      	cmpb	$0x0, 0x9f0f(%rip)      # 0x75a50 <g.4>
   6bb41:      	je	0x7085f <f.2+0x180af>
   6bb47:      	movq	%rax, %rsi
   6bb4a:      	addq	0x58(%rsp), %rsi
   6bb4f:      	addq	0x50(%rsp), %rsi
   6bb54:      	movq	0x10(%rsp), %rcx
   6bb59:      	movq	0x18(%rsp), %rdx
   6bb5e:      	jmp	0x6bb78 <f.2+0x133c8>
   6bb60:      	movl	$0x1, %eax
   6bb65:      	cmpq	$0x0, 0x9edb(%rip)      # 0x75a48 <g.3>
   6bb6d:      	je	0x7085f <f.2+0x180af>
   6bb73:      	leaq	-0x10(%r12,%rax), %rsi
   6bb78:      	cmpq	$0x0, 0x9ec8(%rip)      # 0x75a48 <g.3>
   6bb80:      	je	0x7085f <f.2+0x180af>
   6bb86:      	cmpq	$0x10, %r12
   6bb8a:      	ja	0x6bb96 <f.2+0x133e6>
   6bb8c:      	leaq	-0xf(%r12), %rdi
   6bb91:      	jmp	0x6d544 <f.2+0x14d94>
   6bb96:      	cmpq	$0x11, %r12
   6bb9a:      	jne	0x6bbb4 <f.2+0x13404>
   6bb9c:      	movl	$0x1, %edi
   6bba1:      	cmpq	$0x0, 0x9e9f(%rip)      # 0x75a48 <g.3>
   6bba9:      	jne	0x6bc63 <f.2+0x134b3>
   6bbaf:      	jmp	0x7085f <f.2+0x180af>
   6bbb4:      	movq	%rsi, 0x50(%rsp)
   6bbb9:      	movq	%rdx, 0x18(%rsp)
   6bbbe:      	movq	%rcx, 0x10(%rsp)
   6bbc3:      	leaq	-0x11(%r12), %rsi
   6bbc8:      	movq	$0x0, 0x48(%rsp)
   6bbd1:      	movq	$0x3, 0x30(%rsp)
   6bbda:      	xorl	%edi, %edi
   6bbdc:      	callq	0x70870 <f.3>
   6bbe1:      	subq	$0x8, %rsp
   6bbe5:      	cmpb	$0x0, 0x9e64(%rip)      # 0x75a50 <g.4>
   6bbec:      	je	0x7085f <f.2+0x180af>
   6bbf2:      	movq	%rax, 0x58(%rsp)
   6bbf7:      	cmpq	$0x0, 0x9e49(%rip)      # 0x75a48 <g.3>
   6bbff:      	je	0x7085f <f.2+0x180af>
   6bc05:      	leaq	-0x12(%r12), %rsi
   6bc0a:      	movq	$0x0, 0x48(%rsp)
   6bc13:      	movq	$0x3, 0x30(%rsp)
   6bc1c:      	xorl	%edi, %edi
   6bc1e:      	callq	0x70870 <f.3>
   6bc23:      	subq	$0x8, %rsp
   6bc27:      	cmpb	$0x0, 0x9e22(%rip)      # 0x75a50 <g.4>
   6bc2e:      	je	0x7085f <f.2+0x180af>
   6bc34:      	cmpq	$0x0, 0x9e0c(%rip)      # 0x75a48 <g.3>
   6bc3c:      	movq	0x10(%rsp), %rcx
   6bc41:      	movq	0x18(%rsp), %rdx
   6bc46:      	movq	0x50(%rsp), %rsi
   6bc4b:      	je	0x7085f <f.2+0x180af>
   6bc51:      	movq	%rax, %rdi
   6bc54:      	addq	0x58(%rsp), %rdi
   6bc59:      	cmpq	$0x12, %r12
   6bc5d:      	ja	0x6d4bf <f.2+0x14d0f>
   6bc63:      	leaq	-0x11(%r12), %rax
   6bc68:      	jmp	0x6d541 <f.2+0x14d91>
   6bc6d:      	movq	%rsi, 0x50(%rsp)
   6bc72:      	movq	$0x0, 0x48(%rsp)
   6bc7b:      	movq	$0x3, 0x30(%rsp)
   6bc84:      	xorl	%edi, %edi
   6bc86:      	leaq	-0x11(%r12), %rsi
   6bc8b:      	callq	0x70870 <f.3>
   6bc90:      	subq	$0x8, %rsp
   6bc94:      	movq	%rax, 0x58(%rsp)
   6bc99:      	cmpb	$0x0, 0x9db0(%rip)      # 0x75a50 <g.4>
   6bca0:      	je	0x7085f <f.2+0x180af>
   6bca6:      	cmpq	$0x0, 0x9d9a(%rip)      # 0x75a48 <g.3>
   6bcae:      	je	0x7085f <f.2+0x180af>
   6bcb4:      	leaq	-0x12(%r12), %rsi
   6bcb9:      	movq	$0x0, 0x48(%rsp)
   6bcc2:      	movq	$0x3, 0x30(%rsp)
   6bccb:      	xorl	%edi, %edi
   6bccd:      	callq	0x70870 <f.3>
   6bcd2:      	subq	$0x8, %rsp
   6bcd6:      	addq	0x58(%rsp), %rax
   6bcdb:      	movq	0x10(%rsp), %rcx
   6bce0:      	movq	0x18(%rsp), %rdx
   6bce5:      	movq	0x50(%rsp), %rsi
   6bcea:      	addq	%rax, %rsi
   6bced:      	addq	%rsi, %rdx
   6bcf0:      	addq	%rdx, %r14
   6bcf3:      	cmpb	$0x0, 0x9d56(%rip)      # 0x75a50 <g.4>
   6bcfa:      	je	0x7085f <f.2+0x180af>
   6bd00:      	addq	%rcx, %r14
   6bd03:      	addq	%r15, %r14
   6bd06:      	cmpq	$0x0, 0x9d3a(%rip)      # 0x75a48 <g.3>
   6bd0e:      	leaq	0x68(%rsp), %r15
   6bd13:      	je	0x7085f <f.2+0x180af>
   6bd19:      	cmpq	$0x9, %r12
   6bd1d:      	je	0x6bd3d <f.2+0x1358d>
   6bd1f:      	cmpq	$0x8, %r12
   6bd23:      	jne	0x6bd56 <f.2+0x135a6>
   6bd25:      	leaq	-0x7(%r12,%r14), %rcx
   6bd2a:      	cmpq	$0x0, 0x9d16(%rip)      # 0x75a48 <g.3>
   6bd32:      	jne	0x6d616 <f.2+0x14e66>
   6bd38:      	jmp	0x7085f <f.2+0x180af>
   6bd3d:      	movl	$0x1, %r15d
   6bd43:      	cmpq	$0x0, 0x9cfd(%rip)      # 0x75a48 <g.3>
   6bd4b:      	jne	0x6c92c <f.2+0x1417c>
   6bd51:      	jmp	0x7085f <f.2+0x180af>
   6bd56:      	cmpq	$0xb, %r12
   6bd5a:      	jb	0x6bd77 <f.2+0x135c7>
   6bd5c:      	jne	0x6bd8f <f.2+0x135df>
   6bd5e:      	movl	$0x1, %r15d
   6bd64:      	cmpq	$0x0, 0x9cdc(%rip)      # 0x75a48 <g.3>
   6bd6c:      	jne	0x6c04d <f.2+0x1389d>
   6bd72:      	jmp	0x7085f <f.2+0x180af>
   6bd77:      	movl	$0x1, %ecx
   6bd7c:      	cmpq	$0x0, 0x9cc4(%rip)      # 0x75a48 <g.3>
   6bd84:      	jne	0x6c32c <f.2+0x13b7c>
   6bd8a:      	jmp	0x7085f <f.2+0x180af>
   6bd8f:      	cmpq	$0xd, %r12
   6bd93:      	jb	0x6bdb0 <f.2+0x13600>
   6bd95:      	jne	0x6bdc8 <f.2+0x13618>
   6bd97:      	movl	$0x1, %r15d
   6bd9d:      	cmpq	$0x0, 0x9ca3(%rip)      # 0x75a48 <g.3>
   6bda5:      	jne	0x6be55 <f.2+0x136a5>
   6bdab:      	jmp	0x7085f <f.2+0x180af>
   6bdb0:      	movl	$0x1, %eax
   6bdb5:      	cmpq	$0x0, 0x9c8b(%rip)      # 0x75a48 <g.3>
   6bdbd:      	jne	0x6beef <f.2+0x1373f>
   6bdc3:      	jmp	0x7085f <f.2+0x180af>
   6bdc8:      	leaq	-0xd(%r12), %rsi
   6bdcd:      	movq	$0x0, 0x48(%rsp)
   6bdd6:      	movq	$0x3, 0x30(%rsp)
   6bddf:      	xorl	%edi, %edi
   6bde1:      	callq	0x70870 <f.3>
   6bde6:      	subq	$0x8, %rsp
   6bdea:      	cmpb	$0x0, 0x9c5f(%rip)      # 0x75a50 <g.4>
   6bdf1:      	je	0x7085f <f.2+0x180af>
   6bdf7:      	movq	%rax, 0x10(%rsp)
   6bdfc:      	cmpq	$0x0, 0x9c44(%rip)      # 0x75a48 <g.3>
   6be04:      	je	0x7085f <f.2+0x180af>
   6be0a:      	leaq	-0xe(%r12), %rsi
   6be0f:      	movq	$0x0, 0x48(%rsp)
   6be18:      	movq	$0x3, 0x30(%rsp)
   6be21:      	xorl	%edi, %edi
   6be23:      	callq	0x70870 <f.3>
   6be28:      	subq	$0x8, %rsp
   6be2c:      	cmpb	$0x0, 0x9c1d(%rip)      # 0x75a50 <g.4>
   6be33:      	je	0x7085f <f.2+0x180af>
   6be39:      	cmpq	$0x0, 0x9c07(%rip)      # 0x75a48 <g.3>
   6be41:      	je	0x7085f <f.2+0x180af>
   6be47:      	movq	%rax, %r15
   6be4a:      	addq	0x10(%rsp), %r15
   6be4f:      	cmpq	$0xe, %r12
   6be53:      	ja	0x6be5c <f.2+0x136ac>
   6be55:      	leaq	-0xd(%r12,%r15), %rax
   6be5a:      	jmp	0x6bed5 <f.2+0x13725>
   6be5c:      	movq	$0x0, 0x48(%rsp)
   6be65:      	movq	$0x3, 0x30(%rsp)
   6be6e:      	xorl	%edi, %edi
   6be70:      	leaq	-0xe(%r12), %rsi
   6be75:      	callq	0x70870 <f.3>
   6be7a:      	subq	$0x8, %rsp
   6be7e:      	cmpb	$0x0, 0x9bcb(%rip)      # 0x75a50 <g.4>
   6be85:      	je	0x7085f <f.2+0x180af>
   6be8b:      	movq	%rax, 0x10(%rsp)
   6be90:      	cmpq	$0x0, 0x9bb0(%rip)      # 0x75a48 <g.3>
   6be98:      	je	0x7085f <f.2+0x180af>
   6be9e:      	leaq	-0xf(%r12), %rsi
   6bea3:      	movq	$0x0, 0x48(%rsp)
   6beac:      	movq	$0x3, 0x30(%rsp)
   6beb5:      	xorl	%edi, %edi
   6beb7:      	callq	0x70870 <f.3>
   6bebc:      	subq	$0x8, %rsp
   6bec0:      	cmpb	$0x0, 0x9b89(%rip)      # 0x75a50 <g.4>
   6bec7:      	je	0x7085f <f.2+0x180af>
   6becd:      	addq	0x10(%rsp), %rax
   6bed2:      	addq	%r15, %rax
   6bed5:      	cmpq	$0x0, 0x9b6b(%rip)      # 0x75a48 <g.3>
   6bedd:      	je	0x7085f <f.2+0x180af>
   6bee3:      	cmpq	$0xe, %r12
   6bee7:      	je	0x6bef9 <f.2+0x13749>
   6bee9:      	cmpq	$0xd, %r12
   6beed:      	jne	0x6bf11 <f.2+0x13761>
   6beef:      	leaq	-0xc(%r12,%rax), %r15
   6bef4:      	jmp	0x6c039 <f.2+0x13889>
   6bef9:      	movl	$0x1, %ecx
   6befe:      	cmpq	$0x0, 0x9b42(%rip)      # 0x75a48 <g.3>
   6bf06:      	jne	0x6bfa4 <f.2+0x137f4>
   6bf0c:      	jmp	0x7085f <f.2+0x180af>
   6bf11:      	movq	%rax, 0x10(%rsp)
   6bf16:      	leaq	-0xe(%r12), %rsi
   6bf1b:      	movq	$0x0, 0x48(%rsp)
   6bf24:      	movq	$0x3, 0x30(%rsp)
   6bf2d:      	xorl	%edi, %edi
   6bf2f:      	callq	0x70870 <f.3>
   6bf34:      	subq	$0x8, %rsp
   6bf38:      	cmpb	$0x0, 0x9b11(%rip)      # 0x75a50 <g.4>
   6bf3f:      	je	0x7085f <f.2+0x180af>
   6bf45:      	cmpq	$0x0, 0x9afb(%rip)      # 0x75a48 <g.3>
   6bf4d:      	je	0x7085f <f.2+0x180af>
   6bf53:      	movq	%rax, %r15
   6bf56:      	leaq	-0xf(%r12), %rsi
   6bf5b:      	movq	$0x0, 0x48(%rsp)
   6bf64:      	movq	$0x3, 0x30(%rsp)
   6bf6d:      	xorl	%edi, %edi
   6bf6f:      	callq	0x70870 <f.3>
   6bf74:      	subq	$0x8, %rsp
   6bf78:      	cmpb	$0x0, 0x9ad1(%rip)      # 0x75a50 <g.4>
   6bf7f:      	je	0x7085f <f.2+0x180af>
   6bf85:      	movq	%rax, %rcx
   6bf88:      	cmpq	$0x0, 0x9ab8(%rip)      # 0x75a48 <g.3>
   6bf90:      	movq	0x10(%rsp), %rax
   6bf95:      	je	0x7085f <f.2+0x180af>
   6bf9b:      	addq	%r15, %rcx
   6bf9e:      	cmpq	$0xf, %r12
   6bfa2:      	ja	0x6bfab <f.2+0x137fb>
   6bfa4:      	leaq	-0xe(%r12), %r15
   6bfa9:      	jmp	0x6c026 <f.2+0x13876>
   6bfab:      	movq	%rcx, 0x18(%rsp)
   6bfb0:      	movq	$0x0, 0x48(%rsp)
   6bfb9:      	movq	$0x3, 0x30(%rsp)
   6bfc2:      	xorl	%edi, %edi
   6bfc4:      	leaq	-0xf(%r12), %rsi
   6bfc9:      	callq	0x70870 <f.3>
   6bfce:      	subq	$0x8, %rsp
   6bfd2:      	cmpb	$0x0, 0x9a77(%rip)      # 0x75a50 <g.4>
   6bfd9:      	je	0x7085f <f.2+0x180af>
   6bfdf:      	movq	%rax, 0x50(%rsp)
   6bfe4:      	cmpq	$0x0, 0x9a5c(%rip)      # 0x75a48 <g.3>
   6bfec:      	je	0x7085f <f.2+0x180af>
   6bff2:      	leaq	-0x10(%r12), %rsi
   6bff7:      	movq	$0x0, 0x48(%rsp)
   6c000:      	movq	$0x3, 0x30(%rsp)
   6c009:      	xorl	%edi, %edi
   6c00b:      	callq	0x70870 <f.3>
   6c010:      	subq	$0x8, %rsp
   6c014:      	movq	%rax, %r15
   6c017:      	addq	0x50(%rsp), %r15
   6c01c:      	movq	0x10(%rsp), %rax
   6c021:      	movq	0x18(%rsp), %rcx
   6c026:      	cmpb	$0x0, 0x9a23(%rip)      # 0x75a50 <g.4>
   6c02d:      	je	0x7085f <f.2+0x180af>
   6c033:      	addq	%rcx, %r15
   6c036:      	addq	%rax, %r15
   6c039:      	cmpq	$0x0, 0x9a07(%rip)      # 0x75a48 <g.3>
   6c041:      	je	0x7085f <f.2+0x180af>
   6c047:      	cmpq	$0xc, %r12
   6c04b:      	ja	0x6c057 <f.2+0x138a7>
   6c04d:      	leaq	-0xb(%r12,%r15), %rcx
   6c052:      	jmp	0x6c312 <f.2+0x13b62>
   6c057:      	cmpq	$0xd, %r12
   6c05b:      	jne	0x6c075 <f.2+0x138c5>
   6c05d:      	movl	$0x1, %edx
   6c062:      	cmpq	$0x0, 0x99de(%rip)      # 0x75a48 <g.3>
   6c06a:      	jne	0x6c1be <f.2+0x13a0e>
   6c070:      	jmp	0x7085f <f.2+0x180af>
   6c075:      	cmpq	$0xf, %r12
   6c079:      	jb	0x6c192 <f.2+0x139e2>
   6c07f:      	leaq	-0xe(%r12), %rsi
   6c084:      	movq	$0x0, 0x48(%rsp)
   6c08d:      	movq	$0x3, 0x30(%rsp)
   6c096:      	xorl	%edi, %edi
   6c098:      	callq	0x70870 <f.3>
   6c09d:      	subq	$0x8, %rsp
   6c0a1:      	cmpb	$0x0, 0x99a8(%rip)      # 0x75a50 <g.4>
   6c0a8:      	je	0x7085f <f.2+0x180af>
   6c0ae:      	movq	%rax, 0x10(%rsp)
   6c0b3:      	cmpq	$0x0, 0x998d(%rip)      # 0x75a48 <g.3>
   6c0bb:      	je	0x7085f <f.2+0x180af>
   6c0c1:      	leaq	-0xf(%r12), %rsi
   6c0c6:      	movq	$0x0, 0x48(%rsp)
   6c0cf:      	movq	$0x3, 0x30(%rsp)
   6c0d8:      	xorl	%edi, %edi
   6c0da:      	callq	0x70870 <f.3>
   6c0df:      	subq	$0x8, %rsp
   6c0e3:      	cmpb	$0x0, 0x9966(%rip)      # 0x75a50 <g.4>
   6c0ea:      	je	0x7085f <f.2+0x180af>
   6c0f0:      	cmpq	$0x0, 0x9950(%rip)      # 0x75a48 <g.3>
   6c0f8:      	je	0x7085f <f.2+0x180af>
   6c0fe:      	addq	0x10(%rsp), %rax
   6c103:      	cmpq	$0xf, %r12
   6c107:      	je	0x6c1a5 <f.2+0x139f5>
   6c10d:      	movq	%rax, 0x10(%rsp)
   6c112:      	movq	$0x0, 0x48(%rsp)
   6c11b:      	movq	$0x3, 0x30(%rsp)
   6c124:      	xorl	%edi, %edi
   6c126:      	leaq	-0xf(%r12), %rsi
   6c12b:      	callq	0x70870 <f.3>
   6c130:      	subq	$0x8, %rsp
   6c134:      	cmpb	$0x0, 0x9915(%rip)      # 0x75a50 <g.4>
   6c13b:      	je	0x7085f <f.2+0x180af>
   6c141:      	movq	%rax, 0x18(%rsp)
   6c146:      	cmpq	$0x0, 0x98fa(%rip)      # 0x75a48 <g.3>
   6c14e:      	je	0x7085f <f.2+0x180af>
   6c154:      	leaq	-0x10(%r12), %rsi
   6c159:      	movq	$0x0, 0x48(%rsp)
   6c162:      	movq	$0x3, 0x30(%rsp)
   6c16b:      	xorl	%edi, %edi
   6c16d:      	callq	0x70870 <f.3>
   6c172:      	subq	$0x8, %rsp
   6c176:      	cmpb	$0x0, 0x98d3(%rip)      # 0x75a50 <g.4>
   6c17d:      	je	0x7085f <f.2+0x180af>
   6c183:      	movq	%rax, %rdx
   6c186:      	addq	0x18(%rsp), %rdx
   6c18b:      	addq	0x10(%rsp), %rdx
   6c190:      	jmp	0x6c1aa <f.2+0x139fa>
   6c192:      	movl	$0x1, %eax
   6c197:      	cmpq	$0x0, 0x98a9(%rip)      # 0x75a48 <g.3>
   6c19f:      	je	0x7085f <f.2+0x180af>
   6c1a5:      	leaq	-0xe(%r12,%rax), %rdx
   6c1aa:      	cmpq	$0x0, 0x9896(%rip)      # 0x75a48 <g.3>
   6c1b2:      	je	0x7085f <f.2+0x180af>
   6c1b8:      	cmpq	$0xe, %r12
   6c1bc:      	ja	0x6c1c8 <f.2+0x13a18>
   6c1be:      	leaq	-0xd(%r12), %rcx
   6c1c3:      	jmp	0x6c2ff <f.2+0x13b4f>
   6c1c8:      	cmpq	$0xf, %r12
   6c1cc:      	jne	0x6c1e6 <f.2+0x13a36>
   6c1ce:      	movl	$0x1, %ecx
   6c1d3:      	cmpq	$0x0, 0x986d(%rip)      # 0x75a48 <g.3>
   6c1db:      	jne	0x6c27d <f.2+0x13acd>
   6c1e1:      	jmp	0x7085f <f.2+0x180af>
   6c1e6:      	movq	%rdx, 0x18(%rsp)
   6c1eb:      	leaq	-0xf(%r12), %rsi
   6c1f0:      	movq	$0x0, 0x48(%rsp)
   6c1f9:      	movq	$0x3, 0x30(%rsp)
   6c202:      	xorl	%edi, %edi
   6c204:      	callq	0x70870 <f.3>
   6c209:      	subq	$0x8, %rsp
   6c20d:      	cmpb	$0x0, 0x983c(%rip)      # 0x75a50 <g.4>
   6c214:      	je	0x7085f <f.2+0x180af>
   6c21a:      	movq	%rax, 0x10(%rsp)
   6c21f:      	cmpq	$0x0, 0x9821(%rip)      # 0x75a48 <g.3>
   6c227:      	je	0x7085f <f.2+0x180af>
   6c22d:      	leaq	-0x10(%r12), %rsi
   6c232:      	movq	$0x0, 0x48(%rsp)
   6c23b:      	movq	$0x3, 0x30(%rsp)
   6c244:      	xorl	%edi, %edi
   6c246:      	callq	0x70870 <f.3>
   6c24b:      	subq	$0x8, %rsp
   6c24f:      	cmpb	$0x0, 0x97fa(%rip)      # 0x75a50 <g.4>
   6c256:      	je	0x7085f <f.2+0x180af>
   6c25c:      	cmpq	$0x0, 0x97e4(%rip)      # 0x75a48 <g.3>
   6c264:      	movq	0x18(%rsp), %rdx
   6c269:      	je	0x7085f <f.2+0x180af>
   6c26f:      	movq	%rax, %rcx
   6c272:      	addq	0x10(%rsp), %rcx
   6c277:      	cmpq	$0x10, %r12
   6c27b:      	ja	0x6c284 <f.2+0x13ad4>
   6c27d:      	leaq	-0xf(%r12), %rax
   6c282:      	jmp	0x6c2fc <f.2+0x13b4c>
   6c284:      	movq	%rcx, 0x10(%rsp)
   6c289:      	movq	$0x0, 0x48(%rsp)
   6c292:      	movq	$0x3, 0x30(%rsp)
   6c29b:      	xorl	%edi, %edi
   6c29d:      	leaq	-0x10(%r12), %rsi
   6c2a2:      	callq	0x70870 <f.3>
   6c2a7:      	subq	$0x8, %rsp
   6c2ab:      	cmpb	$0x0, 0x979e(%rip)      # 0x75a50 <g.4>
   6c2b2:      	je	0x7085f <f.2+0x180af>
   6c2b8:      	movq	%rax, 0x50(%rsp)
   6c2bd:      	cmpq	$0x0, 0x9783(%rip)      # 0x75a48 <g.3>
   6c2c5:      	je	0x7085f <f.2+0x180af>
   6c2cb:      	leaq	-0x11(%r12), %rsi
   6c2d0:      	movq	$0x0, 0x48(%rsp)
   6c2d9:      	movq	$0x3, 0x30(%rsp)
   6c2e2:      	xorl	%edi, %edi
   6c2e4:      	callq	0x70870 <f.3>
   6c2e9:      	subq	$0x8, %rsp
   6c2ed:      	addq	0x50(%rsp), %rax
   6c2f2:      	movq	0x10(%rsp), %rcx
   6c2f7:      	movq	0x18(%rsp), %rdx
   6c2fc:      	addq	%rax, %rcx
   6c2ff:      	cmpb	$0x0, 0x974a(%rip)      # 0x75a50 <g.4>
   6c306:      	je	0x7085f <f.2+0x180af>
   6c30c:      	addq	%rdx, %rcx
   6c30f:      	addq	%r15, %rcx
   6c312:      	cmpq	$0x0, 0x972e(%rip)      # 0x75a48 <g.3>
   6c31a:      	je	0x7085f <f.2+0x180af>
   6c320:      	cmpq	$0xc, %r12
   6c324:      	je	0x6c336 <f.2+0x13b86>
   6c326:      	cmpq	$0xb, %r12
   6c32a:      	jne	0x6c34e <f.2+0x13b9e>
   6c32c:      	leaq	-0xa(%r12,%rcx), %r15
   6c331:      	jmp	0x6c918 <f.2+0x14168>
   6c336:      	movl	$0x1, %edx
   6c33b:      	cmpq	$0x0, 0x9705(%rip)      # 0x75a48 <g.3>
   6c343:      	jne	0x6c626 <f.2+0x13e76>
   6c349:      	jmp	0x7085f <f.2+0x180af>
   6c34e:      	cmpq	$0xe, %r12
   6c352:      	jb	0x6c36f <f.2+0x13bbf>
   6c354:      	jne	0x6c387 <f.2+0x13bd7>
   6c356:      	movl	$0x1, %r15d
   6c35c:      	cmpq	$0x0, 0x96e4(%rip)      # 0x75a48 <g.3>
   6c364:      	jne	0x6c41e <f.2+0x13c6e>
   6c36a:      	jmp	0x7085f <f.2+0x180af>
   6c36f:      	movl	$0x1, %eax
   6c374:      	cmpq	$0x0, 0x96cc(%rip)      # 0x75a48 <g.3>
   6c37c:      	jne	0x6c4bd <f.2+0x13d0d>
   6c382:      	jmp	0x7085f <f.2+0x180af>
   6c387:      	movq	%rcx, 0x10(%rsp)
   6c38c:      	leaq	-0xe(%r12), %rsi
   6c391:      	movq	$0x0, 0x48(%rsp)
   6c39a:      	movq	$0x3, 0x30(%rsp)
   6c3a3:      	xorl	%edi, %edi
   6c3a5:      	callq	0x70870 <f.3>
   6c3aa:      	subq	$0x8, %rsp
   6c3ae:      	cmpb	$0x0, 0x969b(%rip)      # 0x75a50 <g.4>
   6c3b5:      	je	0x7085f <f.2+0x180af>
   6c3bb:      	movq	%rax, 0x18(%rsp)
   6c3c0:      	cmpq	$0x0, 0x9680(%rip)      # 0x75a48 <g.3>
   6c3c8:      	je	0x7085f <f.2+0x180af>
   6c3ce:      	leaq	-0xf(%r12), %rsi
   6c3d3:      	movq	$0x0, 0x48(%rsp)
   6c3dc:      	movq	$0x3, 0x30(%rsp)
   6c3e5:      	xorl	%edi, %edi
   6c3e7:      	callq	0x70870 <f.3>
   6c3ec:      	subq	$0x8, %rsp
   6c3f0:      	cmpb	$0x0, 0x9659(%rip)      # 0x75a50 <g.4>
   6c3f7:      	je	0x7085f <f.2+0x180af>
   6c3fd:      	cmpq	$0x0, 0x9643(%rip)      # 0x75a48 <g.3>
   6c405:      	movq	0x10(%rsp), %rcx
   6c40a:      	je	0x7085f <f.2+0x180af>
   6c410:      	movq	%rax, %r15
   6c413:      	addq	0x18(%rsp), %r15
   6c418:      	cmpq	$0xf, %r12
   6c41c:      	ja	0x6c425 <f.2+0x13c75>
   6c41e:      	leaq	-0xe(%r12,%r15), %rax
   6c423:      	jmp	0x6c4a3 <f.2+0x13cf3>
   6c425:      	movq	$0x0, 0x48(%rsp)
   6c42e:      	movq	$0x3, 0x30(%rsp)
   6c437:      	xorl	%edi, %edi
   6c439:      	leaq	-0xf(%r12), %rsi
   6c43e:      	callq	0x70870 <f.3>
   6c443:      	subq	$0x8, %rsp
   6c447:      	cmpb	$0x0, 0x9602(%rip)      # 0x75a50 <g.4>
   6c44e:      	je	0x7085f <f.2+0x180af>
   6c454:      	movq	%rax, 0x18(%rsp)
   6c459:      	cmpq	$0x0, 0x95e7(%rip)      # 0x75a48 <g.3>
   6c461:      	je	0x7085f <f.2+0x180af>
   6c467:      	leaq	-0x10(%r12), %rsi
   6c46c:      	movq	$0x0, 0x48(%rsp)
   6c475:      	movq	$0x3, 0x30(%rsp)
   6c47e:      	xorl	%edi, %edi
   6c480:      	callq	0x70870 <f.3>
   6c485:      	subq	$0x8, %rsp
   6c489:      	cmpb	$0x0, 0x95c0(%rip)      # 0x75a50 <g.4>
   6c490:      	je	0x7085f <f.2+0x180af>
   6c496:      	addq	0x18(%rsp), %rax
   6c49b:      	addq	%r15, %rax
   6c49e:      	movq	0x10(%rsp), %rcx
   6c4a3:      	cmpq	$0x0, 0x959d(%rip)      # 0x75a48 <g.3>
   6c4ab:      	je	0x7085f <f.2+0x180af>
   6c4b1:      	cmpq	$0xf, %r12
   6c4b5:      	je	0x6c4c7 <f.2+0x13d17>
   6c4b7:      	cmpq	$0xe, %r12
   6c4bb:      	jne	0x6c4df <f.2+0x13d2f>
   6c4bd:      	leaq	-0xd(%r12,%rax), %rdx
   6c4c2:      	jmp	0x6c612 <f.2+0x13e62>
   6c4c7:      	movl	$0x1, %esi
   6c4cc:      	cmpq	$0x0, 0x9574(%rip)      # 0x75a48 <g.3>
   6c4d4:      	jne	0x6c57c <f.2+0x13dcc>
   6c4da:      	jmp	0x7085f <f.2+0x180af>
   6c4df:      	movq	%rax, 0x18(%rsp)
   6c4e4:      	movq	%rcx, 0x10(%rsp)
   6c4e9:      	leaq	-0xf(%r12), %rsi
   6c4ee:      	movq	$0x0, 0x48(%rsp)
   6c4f7:      	movq	$0x3, 0x30(%rsp)
   6c500:      	xorl	%edi, %edi
   6c502:      	callq	0x70870 <f.3>
   6c507:      	subq	$0x8, %rsp
   6c50b:      	cmpb	$0x0, 0x953e(%rip)      # 0x75a50 <g.4>
   6c512:      	je	0x7085f <f.2+0x180af>
   6c518:      	cmpq	$0x0, 0x9528(%rip)      # 0x75a48 <g.3>
   6c520:      	je	0x7085f <f.2+0x180af>
   6c526:      	movq	%rax, %r15
   6c529:      	leaq	-0x10(%r12), %rsi
   6c52e:      	movq	$0x0, 0x48(%rsp)
   6c537:      	movq	$0x3, 0x30(%rsp)
   6c540:      	xorl	%edi, %edi
   6c542:      	callq	0x70870 <f.3>
   6c547:      	subq	$0x8, %rsp
   6c54b:      	cmpb	$0x0, 0x94fe(%rip)      # 0x75a50 <g.4>
   6c552:      	je	0x7085f <f.2+0x180af>
   6c558:      	movq	%rax, %rsi
   6c55b:      	cmpq	$0x0, 0x94e5(%rip)      # 0x75a48 <g.3>
   6c563:      	movq	0x10(%rsp), %rcx
   6c568:      	movq	0x18(%rsp), %rax
   6c56d:      	je	0x7085f <f.2+0x180af>
   6c573:      	addq	%r15, %rsi
   6c576:      	cmpq	$0x10, %r12
   6c57a:      	ja	0x6c583 <f.2+0x13dd3>
   6c57c:      	leaq	-0xf(%r12), %rdx
   6c581:      	jmp	0x6c5ff <f.2+0x13e4f>
   6c583:      	movq	%rsi, 0x50(%rsp)
   6c588:      	movq	$0x0, 0x48(%rsp)
   6c591:      	movq	$0x3, 0x30(%rsp)
   6c59a:      	xorl	%edi, %edi
   6c59c:      	leaq	-0x10(%r12), %rsi
   6c5a1:      	callq	0x70870 <f.3>
   6c5a6:      	subq	$0x8, %rsp
   6c5aa:      	cmpb	$0x0, 0x949f(%rip)      # 0x75a50 <g.4>
   6c5b1:      	je	0x7085f <f.2+0x180af>
   6c5b7:      	cmpq	$0x0, 0x9489(%rip)      # 0x75a48 <g.3>
   6c5bf:      	je	0x7085f <f.2+0x180af>
   6c5c5:      	movq	%rax, %r15
   6c5c8:      	leaq	-0x11(%r12), %rsi
   6c5cd:      	movq	$0x0, 0x48(%rsp)
   6c5d6:      	movq	$0x3, 0x30(%rsp)
   6c5df:      	xorl	%edi, %edi
   6c5e1:      	callq	0x70870 <f.3>
   6c5e6:      	subq	$0x8, %rsp
   6c5ea:      	movq	%rax, %rdx
   6c5ed:      	addq	%r15, %rdx
   6c5f0:      	movq	0x10(%rsp), %rcx
   6c5f5:      	movq	0x18(%rsp), %rax
   6c5fa:      	movq	0x50(%rsp), %rsi
   6c5ff:      	cmpb	$0x0, 0x944a(%rip)      # 0x75a50 <g.4>
   6c606:      	je	0x7085f <f.2+0x180af>
   6c60c:      	addq	%rsi, %rdx
   6c60f:      	addq	%rax, %rdx
   6c612:      	cmpq	$0x0, 0x942e(%rip)      # 0x75a48 <g.3>
   6c61a:      	je	0x7085f <f.2+0x180af>
   6c620:      	cmpq	$0xd, %r12
   6c624:      	ja	0x6c630 <f.2+0x13e80>
   6c626:      	leaq	-0xc(%r12), %r15
   6c62b:      	jmp	0x6c905 <f.2+0x14155>
   6c630:      	cmpq	$0xe, %r12
   6c634:      	jne	0x6c64f <f.2+0x13e9f>
   6c636:      	movl	$0x1, %r15d
   6c63c:      	cmpq	$0x0, 0x9404(%rip)      # 0x75a48 <g.3>
   6c644:      	jne	0x6c7b2 <f.2+0x14002>
   6c64a:      	jmp	0x7085f <f.2+0x180af>
   6c64f:      	cmpq	$0x10, %r12
   6c653:      	jb	0x6c786 <f.2+0x13fd6>
   6c659:      	movq	%rdx, 0x18(%rsp)
   6c65e:      	movq	%rcx, 0x10(%rsp)
   6c663:      	leaq	-0xf(%r12), %rsi
   6c668:      	movq	$0x0, 0x48(%rsp)
   6c671:      	movq	$0x3, 0x30(%rsp)
   6c67a:      	xorl	%edi, %edi
   6c67c:      	callq	0x70870 <f.3>
   6c681:      	subq	$0x8, %rsp
   6c685:      	cmpb	$0x0, 0x93c4(%rip)      # 0x75a50 <g.4>
   6c68c:      	je	0x7085f <f.2+0x180af>
   6c692:      	cmpq	$0x0, 0x93ae(%rip)      # 0x75a48 <g.3>
   6c69a:      	je	0x7085f <f.2+0x180af>
   6c6a0:      	movq	%rax, %r15
   6c6a3:      	leaq	-0x10(%r12), %rsi
   6c6a8:      	movq	$0x0, 0x48(%rsp)
   6c6b1:      	movq	$0x3, 0x30(%rsp)
   6c6ba:      	xorl	%edi, %edi
   6c6bc:      	callq	0x70870 <f.3>
   6c6c1:      	subq	$0x8, %rsp
   6c6c5:      	cmpb	$0x0, 0x9384(%rip)      # 0x75a50 <g.4>
   6c6cc:      	je	0x7085f <f.2+0x180af>
   6c6d2:      	cmpq	$0x0, 0x936e(%rip)      # 0x75a48 <g.3>
   6c6da:      	movq	0x10(%rsp), %rcx
   6c6df:      	movq	0x18(%rsp), %rdx
   6c6e4:      	je	0x7085f <f.2+0x180af>
   6c6ea:      	addq	%r15, %rax
   6c6ed:      	cmpq	$0x10, %r12
   6c6f1:      	je	0x6c799 <f.2+0x13fe9>
   6c6f7:      	movq	%rax, 0x50(%rsp)
   6c6fc:      	movq	$0x0, 0x48(%rsp)
   6c705:      	movq	$0x3, 0x30(%rsp)
   6c70e:      	xorl	%edi, %edi
   6c710:      	leaq	-0x10(%r12), %rsi
   6c715:      	callq	0x70870 <f.3>
   6c71a:      	subq	$0x8, %rsp
   6c71e:      	cmpb	$0x0, 0x932b(%rip)      # 0x75a50 <g.4>
   6c725:      	je	0x7085f <f.2+0x180af>
   6c72b:      	movq	%rax, 0x58(%rsp)
   6c730:      	cmpq	$0x0, 0x9310(%rip)      # 0x75a48 <g.3>
   6c738:      	je	0x7085f <f.2+0x180af>
   6c73e:      	leaq	-0x11(%r12), %rsi
   6c743:      	movq	$0x0, 0x48(%rsp)
   6c74c:      	movq	$0x3, 0x30(%rsp)
   6c755:      	xorl	%edi, %edi
   6c757:      	callq	0x70870 <f.3>
   6c75c:      	subq	$0x8, %rsp
   6c760:      	cmpb	$0x0, 0x92e9(%rip)      # 0x75a50 <g.4>
   6c767:      	je	0x7085f <f.2+0x180af>
   6c76d:      	movq	%rax, %r15
   6c770:      	addq	0x58(%rsp), %r15
   6c775:      	addq	0x50(%rsp), %r15
   6c77a:      	movq	0x10(%rsp), %rcx
   6c77f:      	movq	0x18(%rsp), %rdx
   6c784:      	jmp	0x6c79e <f.2+0x13fee>
   6c786:      	movl	$0x1, %eax
   6c78b:      	cmpq	$0x0, 0x92b5(%rip)      # 0x75a48 <g.3>
   6c793:      	je	0x7085f <f.2+0x180af>
   6c799:      	leaq	-0xf(%r12,%rax), %r15
   6c79e:      	cmpq	$0x0, 0x92a2(%rip)      # 0x75a48 <g.3>
   6c7a6:      	je	0x7085f <f.2+0x180af>
   6c7ac:      	cmpq	$0xf, %r12
   6c7b0:      	ja	0x6c7bc <f.2+0x1400c>
   6c7b2:      	leaq	-0xe(%r12), %rsi
   6c7b7:      	jmp	0x6c902 <f.2+0x14152>
   6c7bc:      	cmpq	$0x10, %r12
   6c7c0:      	jne	0x6c7da <f.2+0x1402a>
   6c7c2:      	movl	$0x1, %esi
   6c7c7:      	cmpq	$0x0, 0x9279(%rip)      # 0x75a48 <g.3>
   6c7cf:      	jne	0x6c87b <f.2+0x140cb>
   6c7d5:      	jmp	0x7085f <f.2+0x180af>
   6c7da:      	movq	%rdx, 0x18(%rsp)
   6c7df:      	movq	%rcx, 0x10(%rsp)
   6c7e4:      	leaq	-0x10(%r12), %rsi
   6c7e9:      	movq	$0x0, 0x48(%rsp)
   6c7f2:      	movq	$0x3, 0x30(%rsp)
   6c7fb:      	xorl	%edi, %edi
   6c7fd:      	callq	0x70870 <f.3>
   6c802:      	subq	$0x8, %rsp
   6c806:      	cmpb	$0x0, 0x9243(%rip)      # 0x75a50 <g.4>
   6c80d:      	je	0x7085f <f.2+0x180af>
   6c813:      	movq	%rax, 0x50(%rsp)
   6c818:      	cmpq	$0x0, 0x9228(%rip)      # 0x75a48 <g.3>
   6c820:      	je	0x7085f <f.2+0x180af>
   6c826:      	leaq	-0x11(%r12), %rsi
   6c82b:      	movq	$0x0, 0x48(%rsp)
   6c834:      	movq	$0x3, 0x30(%rsp)
   6c83d:      	xorl	%edi, %edi
   6c83f:      	callq	0x70870 <f.3>
   6c844:      	subq	$0x8, %rsp
   6c848:      	cmpb	$0x0, 0x9201(%rip)      # 0x75a50 <g.4>
   6c84f:      	je	0x7085f <f.2+0x180af>
   6c855:      	cmpq	$0x0, 0x91eb(%rip)      # 0x75a48 <g.3>
   6c85d:      	movq	0x10(%rsp), %rcx
   6c862:      	movq	0x18(%rsp), %rdx
   6c867:      	je	0x7085f <f.2+0x180af>
   6c86d:      	movq	%rax, %rsi
   6c870:      	addq	0x50(%rsp), %rsi
   6c875:      	cmpq	$0x11, %r12
   6c879:      	ja	0x6c882 <f.2+0x140d2>
   6c87b:      	leaq	-0x10(%r12), %rax
   6c880:      	jmp	0x6c8ff <f.2+0x1414f>
   6c882:      	movq	%rsi, 0x50(%rsp)
   6c887:      	movq	$0x0, 0x48(%rsp)
   6c890:      	movq	$0x3, 0x30(%rsp)
   6c899:      	xorl	%edi, %edi
   6c89b:      	leaq	-0x11(%r12), %rsi
   6c8a0:      	callq	0x70870 <f.3>
   6c8a5:      	subq	$0x8, %rsp
   6c8a9:      	cmpb	$0x0, 0x91a0(%rip)      # 0x75a50 <g.4>
   6c8b0:      	je	0x7085f <f.2+0x180af>
   6c8b6:      	movq	%rax, 0x58(%rsp)
   6c8bb:      	cmpq	$0x0, 0x9185(%rip)      # 0x75a48 <g.3>
   6c8c3:      	je	0x7085f <f.2+0x180af>
   6c8c9:      	leaq	-0x12(%r12), %rsi
   6c8ce:      	movq	$0x0, 0x48(%rsp)
   6c8d7:      	movq	$0x3, 0x30(%rsp)
   6c8e0:      	xorl	%edi, %edi
   6c8e2:      	callq	0x70870 <f.3>
   6c8e7:      	subq	$0x8, %rsp
   6c8eb:      	addq	0x58(%rsp), %rax
   6c8f0:      	movq	0x10(%rsp), %rcx
   6c8f5:      	movq	0x18(%rsp), %rdx
   6c8fa:      	movq	0x50(%rsp), %rsi
   6c8ff:      	addq	%rax, %rsi
   6c902:      	addq	%rsi, %r15
   6c905:      	cmpb	$0x0, 0x9144(%rip)      # 0x75a50 <g.4>
   6c90c:      	je	0x7085f <f.2+0x180af>
   6c912:      	addq	%rdx, %r15
   6c915:      	addq	%rcx, %r15
   6c918:      	cmpq	$0x0, 0x9128(%rip)      # 0x75a48 <g.3>
   6c920:      	je	0x7085f <f.2+0x180af>
   6c926:      	cmpq	$0xa, %r12
   6c92a:      	ja	0x6c943 <f.2+0x14193>
   6c92c:      	leaq	-0x9(%r12), %rcx
   6c931:      	cmpb	$0x0, 0x9118(%rip)      # 0x75a50 <g.4>
   6c938:      	jne	0x6d5fd <f.2+0x14e4d>
   6c93e:      	jmp	0x7085f <f.2+0x180af>
   6c943:      	cmpq	$0xb, %r12
   6c947:      	jne	0x6c961 <f.2+0x141b1>
   6c949:      	movl	$0x1, %ecx
   6c94e:      	cmpq	$0x0, 0x90f2(%rip)      # 0x75a48 <g.3>
   6c956:      	jne	0x6cf3e <f.2+0x1478e>
   6c95c:      	jmp	0x7085f <f.2+0x180af>
   6c961:      	cmpq	$0xd, %r12
   6c965:      	jb	0x6c981 <f.2+0x141d1>
   6c967:      	jne	0x6c999 <f.2+0x141e9>
   6c969:      	movl	$0x1, %eax
   6c96e:      	cmpq	$0x0, 0x90d2(%rip)      # 0x75a48 <g.3>
   6c976:      	jne	0x6cadf <f.2+0x1432f>
   6c97c:      	jmp	0x7085f <f.2+0x180af>
   6c981:      	movl	$0x1, %edx
   6c986:      	cmpq	$0x0, 0x90ba(%rip)      # 0x75a48 <g.3>
   6c98e:      	jne	0x6cc4d <f.2+0x1449d>
   6c994:      	jmp	0x7085f <f.2+0x180af>
   6c999:      	cmpq	$0xf, %r12
   6c99d:      	jb	0x6cab3 <f.2+0x14303>
   6c9a3:      	leaq	-0xe(%r12), %rsi
   6c9a8:      	movq	$0x0, 0x48(%rsp)
   6c9b1:      	movq	$0x3, 0x30(%rsp)
   6c9ba:      	xorl	%edi, %edi
   6c9bc:      	callq	0x70870 <f.3>
   6c9c1:      	subq	$0x8, %rsp
   6c9c5:      	cmpb	$0x0, 0x9084(%rip)      # 0x75a50 <g.4>
   6c9cc:      	je	0x7085f <f.2+0x180af>
   6c9d2:      	movq	%rax, 0x10(%rsp)
   6c9d7:      	cmpq	$0x0, 0x9069(%rip)      # 0x75a48 <g.3>
   6c9df:      	je	0x7085f <f.2+0x180af>
   6c9e5:      	leaq	-0xf(%r12), %rsi
   6c9ea:      	movq	$0x0, 0x48(%rsp)
   6c9f3:      	movq	$0x3, 0x30(%rsp)
   6c9fc:      	xorl	%edi, %edi
   6c9fe:      	callq	0x70870 <f.3>
   6ca03:      	subq	$0x8, %rsp
   6ca07:      	cmpb	$0x0, 0x9042(%rip)      # 0x75a50 <g.4>
   6ca0e:      	je	0x7085f <f.2+0x180af>
   6ca14:      	cmpq	$0x0, 0x902c(%rip)      # 0x75a48 <g.3>
   6ca1c:      	je	0x7085f <f.2+0x180af>
   6ca22:      	addq	0x10(%rsp), %rax
   6ca27:      	cmpq	$0xf, %r12
   6ca2b:      	je	0x6cac6 <f.2+0x14316>
   6ca31:      	movq	%rax, 0x10(%rsp)
   6ca36:      	movq	$0x0, 0x48(%rsp)
   6ca3f:      	movq	$0x3, 0x30(%rsp)
   6ca48:      	xorl	%edi, %edi
   6ca4a:      	leaq	-0xf(%r12), %rsi
   6ca4f:      	callq	0x70870 <f.3>
   6ca54:      	subq	$0x8, %rsp
   6ca58:      	cmpb	$0x0, 0x8ff1(%rip)      # 0x75a50 <g.4>
   6ca5f:      	je	0x7085f <f.2+0x180af>
   6ca65:      	movq	%rax, 0x18(%rsp)
   6ca6a:      	cmpq	$0x0, 0x8fd6(%rip)      # 0x75a48 <g.3>
   6ca72:      	je	0x7085f <f.2+0x180af>
   6ca78:      	leaq	-0x10(%r12), %rsi
   6ca7d:      	movq	$0x0, 0x48(%rsp)
   6ca86:      	movq	$0x3, 0x30(%rsp)
   6ca8f:      	xorl	%edi, %edi
   6ca91:      	callq	0x70870 <f.3>
   6ca96:      	subq	$0x8, %rsp
   6ca9a:      	cmpb	$0x0, 0x8faf(%rip)      # 0x75a50 <g.4>
   6caa1:      	je	0x7085f <f.2+0x180af>
   6caa7:      	addq	0x18(%rsp), %rax
   6caac:      	addq	0x10(%rsp), %rax
   6cab1:      	jmp	0x6cacb <f.2+0x1431b>
   6cab3:      	movl	$0x1, %eax
   6cab8:      	cmpq	$0x0, 0x8f88(%rip)      # 0x75a48 <g.3>
   6cac0:      	je	0x7085f <f.2+0x180af>
   6cac6:      	leaq	-0xe(%r12,%rax), %rax
   6cacb:      	cmpq	$0x0, 0x8f75(%rip)      # 0x75a48 <g.3>
   6cad3:      	je	0x7085f <f.2+0x180af>
   6cad9:      	cmpq	$0xe, %r12
   6cadd:      	ja	0x6cae9 <f.2+0x14339>
   6cadf:      	leaq	-0xd(%r12,%rax), %rdx
   6cae4:      	jmp	0x6cc33 <f.2+0x14483>
   6cae9:      	cmpq	$0xf, %r12
   6caed:      	jne	0x6cb07 <f.2+0x14357>
   6caef:      	movl	$0x1, %ecx
   6caf4:      	cmpq	$0x0, 0x8f4c(%rip)      # 0x75a48 <g.3>
   6cafc:      	jne	0x6cb9e <f.2+0x143ee>
   6cb02:      	jmp	0x7085f <f.2+0x180af>
   6cb07:      	movq	%rax, 0x10(%rsp)
   6cb0c:      	leaq	-0xf(%r12), %rsi
   6cb11:      	movq	$0x0, 0x48(%rsp)
   6cb1a:      	movq	$0x3, 0x30(%rsp)
   6cb23:      	xorl	%edi, %edi
   6cb25:      	callq	0x70870 <f.3>
   6cb2a:      	subq	$0x8, %rsp
   6cb2e:      	cmpb	$0x0, 0x8f1b(%rip)      # 0x75a50 <g.4>
   6cb35:      	je	0x7085f <f.2+0x180af>
   6cb3b:      	movq	%rax, 0x18(%rsp)
   6cb40:      	cmpq	$0x0, 0x8f00(%rip)      # 0x75a48 <g.3>
   6cb48:      	je	0x7085f <f.2+0x180af>
   6cb4e:      	leaq	-0x10(%r12), %rsi
   6cb53:      	movq	$0x0, 0x48(%rsp)
   6cb5c:      	movq	$0x3, 0x30(%rsp)
   6cb65:      	xorl	%edi, %edi
   6cb67:      	callq	0x70870 <f.3>
   6cb6c:      	subq	$0x8, %rsp
   6cb70:      	cmpb	$0x0, 0x8ed9(%rip)      # 0x75a50 <g.4>
   6cb77:      	je	0x7085f <f.2+0x180af>
   6cb7d:      	movq	%rax, %rcx
   6cb80:      	cmpq	$0x0, 0x8ec0(%rip)      # 0x75a48 <g.3>
   6cb88:      	movq	0x10(%rsp), %rax
   6cb8d:      	je	0x7085f <f.2+0x180af>
   6cb93:      	addq	0x18(%rsp), %rcx
   6cb98:      	cmpq	$0x10, %r12
   6cb9c:      	ja	0x6cba5 <f.2+0x143f5>
   6cb9e:      	leaq	-0xf(%r12), %rdx
   6cba3:      	jmp	0x6cc20 <f.2+0x14470>
   6cba5:      	movq	%rcx, 0x18(%rsp)
   6cbaa:      	movq	$0x0, 0x48(%rsp)
   6cbb3:      	movq	$0x3, 0x30(%rsp)
   6cbbc:      	xorl	%edi, %edi
   6cbbe:      	leaq	-0x10(%r12), %rsi
   6cbc3:      	callq	0x70870 <f.3>
   6cbc8:      	subq	$0x8, %rsp
   6cbcc:      	cmpb	$0x0, 0x8e7d(%rip)      # 0x75a50 <g.4>
   6cbd3:      	je	0x7085f <f.2+0x180af>
   6cbd9:      	movq	%rax, 0x50(%rsp)
   6cbde:      	cmpq	$0x0, 0x8e62(%rip)      # 0x75a48 <g.3>
   6cbe6:      	je	0x7085f <f.2+0x180af>
   6cbec:      	leaq	-0x11(%r12), %rsi
   6cbf1:      	movq	$0x0, 0x48(%rsp)
   6cbfa:      	movq	$0x3, 0x30(%rsp)
   6cc03:      	xorl	%edi, %edi
   6cc05:      	callq	0x70870 <f.3>
   6cc0a:      	subq	$0x8, %rsp
   6cc0e:      	movq	%rax, %rdx
   6cc11:      	addq	0x50(%rsp), %rdx
   6cc16:      	movq	0x10(%rsp), %rax
   6cc1b:      	movq	0x18(%rsp), %rcx
   6cc20:      	cmpb	$0x0, 0x8e29(%rip)      # 0x75a50 <g.4>
   6cc27:      	je	0x7085f <f.2+0x180af>
   6cc2d:      	addq	%rcx, %rdx
   6cc30:      	addq	%rax, %rdx
   6cc33:      	cmpq	$0x0, 0x8e0d(%rip)      # 0x75a48 <g.3>
   6cc3b:      	je	0x7085f <f.2+0x180af>
   6cc41:      	cmpq	$0xe, %r12
   6cc45:      	je	0x6cc57 <f.2+0x144a7>
   6cc47:      	cmpq	$0xd, %r12
   6cc4b:      	jne	0x6cc6f <f.2+0x144bf>
   6cc4d:      	leaq	-0xc(%r12,%rdx), %rcx
   6cc52:      	jmp	0x6cf2a <f.2+0x1477a>
   6cc57:      	movl	$0x1, %esi
   6cc5c:      	cmpq	$0x0, 0x8de4(%rip)      # 0x75a48 <g.3>
   6cc64:      	jne	0x6cdc7 <f.2+0x14617>
   6cc6a:      	jmp	0x7085f <f.2+0x180af>
   6cc6f:      	cmpq	$0x10, %r12
   6cc73:      	jb	0x6cd9b <f.2+0x145eb>
   6cc79:      	movq	%rdx, 0x18(%rsp)
   6cc7e:      	leaq	-0xf(%r12), %rsi
   6cc83:      	movq	$0x0, 0x48(%rsp)
   6cc8c:      	movq	$0x3, 0x30(%rsp)
   6cc95:      	xorl	%edi, %edi
   6cc97:      	callq	0x70870 <f.3>
   6cc9c:      	subq	$0x8, %rsp
   6cca0:      	cmpb	$0x0, 0x8da9(%rip)      # 0x75a50 <g.4>
   6cca7:      	je	0x7085f <f.2+0x180af>
   6ccad:      	movq	%rax, 0x10(%rsp)
   6ccb2:      	cmpq	$0x0, 0x8d8e(%rip)      # 0x75a48 <g.3>
   6ccba:      	je	0x7085f <f.2+0x180af>
   6ccc0:      	leaq	-0x10(%r12), %rsi
   6ccc5:      	movq	$0x0, 0x48(%rsp)
   6ccce:      	movq	$0x3, 0x30(%rsp)
   6ccd7:      	xorl	%edi, %edi
   6ccd9:      	callq	0x70870 <f.3>
   6ccde:      	subq	$0x8, %rsp
   6cce2:      	cmpb	$0x0, 0x8d67(%rip)      # 0x75a50 <g.4>
   6cce9:      	je	0x7085f <f.2+0x180af>
   6ccef:      	cmpq	$0x0, 0x8d51(%rip)      # 0x75a48 <g.3>
   6ccf7:      	movq	0x18(%rsp), %rdx
   6ccfc:      	je	0x7085f <f.2+0x180af>
   6cd02:      	addq	0x10(%rsp), %rax
   6cd07:      	cmpq	$0x10, %r12
   6cd0b:      	je	0x6cdae <f.2+0x145fe>
   6cd11:      	movq	%rax, 0x10(%rsp)
   6cd16:      	movq	$0x0, 0x48(%rsp)
   6cd1f:      	movq	$0x3, 0x30(%rsp)
   6cd28:      	xorl	%edi, %edi
   6cd2a:      	leaq	-0x10(%r12), %rsi
   6cd2f:      	callq	0x70870 <f.3>
   6cd34:      	subq	$0x8, %rsp
   6cd38:      	cmpb	$0x0, 0x8d11(%rip)      # 0x75a50 <g.4>
   6cd3f:      	je	0x7085f <f.2+0x180af>
   6cd45:      	movq	%rax, 0x50(%rsp)
   6cd4a:      	cmpq	$0x0, 0x8cf6(%rip)      # 0x75a48 <g.3>
   6cd52:      	je	0x7085f <f.2+0x180af>
   6cd58:      	leaq	-0x11(%r12), %rsi
   6cd5d:      	movq	$0x0, 0x48(%rsp)
   6cd66:      	movq	$0x3, 0x30(%rsp)
   6cd6f:      	xorl	%edi, %edi
   6cd71:      	callq	0x70870 <f.3>
   6cd76:      	subq	$0x8, %rsp
   6cd7a:      	cmpb	$0x0, 0x8ccf(%rip)      # 0x75a50 <g.4>
   6cd81:      	je	0x7085f <f.2+0x180af>
   6cd87:      	movq	%rax, %rsi
   6cd8a:      	addq	0x50(%rsp), %rsi
   6cd8f:      	addq	0x10(%rsp), %rsi
   6cd94:      	movq	0x18(%rsp), %rdx
   6cd99:      	jmp	0x6cdb3 <f.2+0x14603>
   6cd9b:      	movl	$0x1, %eax
   6cda0:      	cmpq	$0x0, 0x8ca0(%rip)      # 0x75a48 <g.3>
   6cda8:      	je	0x7085f <f.2+0x180af>
   6cdae:      	leaq	-0xf(%r12,%rax), %rsi
   6cdb3:      	cmpq	$0x0, 0x8c8d(%rip)      # 0x75a48 <g.3>
   6cdbb:      	je	0x7085f <f.2+0x180af>
   6cdc1:      	cmpq	$0xf, %r12
   6cdc5:      	ja	0x6cdd1 <f.2+0x14621>
   6cdc7:      	leaq	-0xe(%r12), %rcx
   6cdcc:      	jmp	0x6cf17 <f.2+0x14767>
   6cdd1:      	cmpq	$0x10, %r12
   6cdd5:      	jne	0x6cdef <f.2+0x1463f>
   6cdd7:      	movl	$0x1, %ecx
   6cddc:      	cmpq	$0x0, 0x8c64(%rip)      # 0x75a48 <g.3>
   6cde4:      	jne	0x6ce90 <f.2+0x146e0>
   6cdea:      	jmp	0x7085f <f.2+0x180af>
   6cdef:      	movq	%rsi, 0x50(%rsp)
   6cdf4:      	movq	%rdx, 0x18(%rsp)
   6cdf9:      	leaq	-0x10(%r12), %rsi
   6cdfe:      	movq	$0x0, 0x48(%rsp)
   6ce07:      	movq	$0x3, 0x30(%rsp)
   6ce10:      	xorl	%edi, %edi
   6ce12:      	callq	0x70870 <f.3>
   6ce17:      	subq	$0x8, %rsp
   6ce1b:      	cmpb	$0x0, 0x8c2e(%rip)      # 0x75a50 <g.4>
   6ce22:      	je	0x7085f <f.2+0x180af>
   6ce28:      	movq	%rax, 0x10(%rsp)
   6ce2d:      	cmpq	$0x0, 0x8c13(%rip)      # 0x75a48 <g.3>
   6ce35:      	je	0x7085f <f.2+0x180af>
   6ce3b:      	leaq	-0x11(%r12), %rsi
   6ce40:      	movq	$0x0, 0x48(%rsp)
   6ce49:      	movq	$0x3, 0x30(%rsp)
   6ce52:      	xorl	%edi, %edi
   6ce54:      	callq	0x70870 <f.3>
   6ce59:      	subq	$0x8, %rsp
   6ce5d:      	cmpb	$0x0, 0x8bec(%rip)      # 0x75a50 <g.4>
   6ce64:      	je	0x7085f <f.2+0x180af>
   6ce6a:      	cmpq	$0x0, 0x8bd6(%rip)      # 0x75a48 <g.3>
   6ce72:      	movq	0x18(%rsp), %rdx
   6ce77:      	movq	0x50(%rsp), %rsi
   6ce7c:      	je	0x7085f <f.2+0x180af>
   6ce82:      	movq	%rax, %rcx
   6ce85:      	addq	0x10(%rsp), %rcx
   6ce8a:      	cmpq	$0x11, %r12
   6ce8e:      	ja	0x6ce97 <f.2+0x146e7>
   6ce90:      	leaq	-0x10(%r12), %rax
   6ce95:      	jmp	0x6cf14 <f.2+0x14764>
   6ce97:      	movq	%rcx, 0x10(%rsp)
   6ce9c:      	movq	$0x0, 0x48(%rsp)
   6cea5:      	movq	$0x3, 0x30(%rsp)
   6ceae:      	xorl	%edi, %edi
   6ceb0:      	leaq	-0x11(%r12), %rsi
   6ceb5:      	callq	0x70870 <f.3>
   6ceba:      	subq	$0x8, %rsp
   6cebe:      	cmpb	$0x0, 0x8b8b(%rip)      # 0x75a50 <g.4>
   6cec5:      	je	0x7085f <f.2+0x180af>
   6cecb:      	movq	%rax, 0x58(%rsp)
   6ced0:      	cmpq	$0x0, 0x8b70(%rip)      # 0x75a48 <g.3>
   6ced8:      	je	0x7085f <f.2+0x180af>
   6cede:      	leaq	-0x12(%r12), %rsi
   6cee3:      	movq	$0x0, 0x48(%rsp)
   6ceec:      	movq	$0x3, 0x30(%rsp)
   6cef5:      	xorl	%edi, %edi
   6cef7:      	callq	0x70870 <f.3>
   6cefc:      	subq	$0x8, %rsp
   6cf00:      	addq	0x58(%rsp), %rax
   6cf05:      	movq	0x10(%rsp), %rcx
   6cf0a:      	movq	0x18(%rsp), %rdx
   6cf0f:      	movq	0x50(%rsp), %rsi
   6cf14:      	addq	%rax, %rcx
   6cf17:      	cmpb	$0x0, 0x8b32(%rip)      # 0x75a50 <g.4>
   6cf1e:      	je	0x7085f <f.2+0x180af>
   6cf24:      	addq	%rsi, %rcx
   6cf27:      	addq	%rdx, %rcx
   6cf2a:      	cmpq	$0x0, 0x8b16(%rip)      # 0x75a48 <g.3>
   6cf32:      	je	0x7085f <f.2+0x180af>
   6cf38:      	cmpq	$0xc, %r12
   6cf3c:      	ja	0x6cf48 <f.2+0x14798>
   6cf3e:      	leaq	-0xb(%r12), %rdx
   6cf43:      	jmp	0x6d5ed <f.2+0x14e3d>
   6cf48:      	cmpq	$0xd, %r12
   6cf4c:      	jne	0x6cf66 <f.2+0x147b6>
   6cf4e:      	movl	$0x1, %edx
   6cf53:      	cmpq	$0x0, 0x8aed(%rip)      # 0x75a48 <g.3>
   6cf5b:      	jne	0x6d24f <f.2+0x14a9f>
   6cf61:      	jmp	0x7085f <f.2+0x180af>
   6cf66:      	cmpq	$0xf, %r12
   6cf6a:      	jb	0x6cf86 <f.2+0x147d6>
   6cf6c:      	jne	0x6cf9e <f.2+0x147ee>
   6cf6e:      	movl	$0x1, %eax
   6cf73:      	cmpq	$0x0, 0x8acd(%rip)      # 0x75a48 <g.3>
   6cf7b:      	jne	0x6d032 <f.2+0x14882>
   6cf81:      	jmp	0x7085f <f.2+0x180af>
   6cf86:      	movl	$0x1, %eax
   6cf8b:      	cmpq	$0x0, 0x8ab5(%rip)      # 0x75a48 <g.3>
   6cf93:      	jne	0x6d0db <f.2+0x1492b>
   6cf99:      	jmp	0x7085f <f.2+0x180af>
   6cf9e:      	movq	%rcx, 0x10(%rsp)
   6cfa3:      	leaq	-0xf(%r12), %rsi
   6cfa8:      	movq	$0x0, 0x48(%rsp)
   6cfb1:      	movq	$0x3, 0x30(%rsp)
   6cfba:      	xorl	%edi, %edi
   6cfbc:      	callq	0x70870 <f.3>
   6cfc1:      	subq	$0x8, %rsp
   6cfc5:      	cmpb	$0x0, 0x8a84(%rip)      # 0x75a50 <g.4>
   6cfcc:      	je	0x7085f <f.2+0x180af>
   6cfd2:      	movq	%rax, 0x18(%rsp)
   6cfd7:      	cmpq	$0x0, 0x8a69(%rip)      # 0x75a48 <g.3>
   6cfdf:      	je	0x7085f <f.2+0x180af>
   6cfe5:      	leaq	-0x10(%r12), %rsi
   6cfea:      	movq	$0x0, 0x48(%rsp)
   6cff3:      	movq	$0x3, 0x30(%rsp)
   6cffc:      	xorl	%edi, %edi
   6cffe:      	callq	0x70870 <f.3>
   6d003:      	subq	$0x8, %rsp
   6d007:      	cmpb	$0x0, 0x8a42(%rip)      # 0x75a50 <g.4>
   6d00e:      	je	0x7085f <f.2+0x180af>
   6d014:      	cmpq	$0x0, 0x8a2c(%rip)      # 0x75a48 <g.3>
   6d01c:      	movq	0x10(%rsp), %rcx
   6d021:      	je	0x7085f <f.2+0x180af>
   6d027:      	addq	0x18(%rsp), %rax
   6d02c:      	cmpq	$0x10, %r12
   6d030:      	ja	0x6d03c <f.2+0x1488c>
   6d032:      	leaq	-0xf(%r12,%rax), %rax
   6d037:      	jmp	0x6d0c1 <f.2+0x14911>
   6d03c:      	movq	%rax, 0x18(%rsp)
   6d041:      	movq	$0x0, 0x48(%rsp)
   6d04a:      	movq	$0x3, 0x30(%rsp)
   6d053:      	xorl	%edi, %edi
   6d055:      	leaq	-0x10(%r12), %rsi
   6d05a:      	callq	0x70870 <f.3>
   6d05f:      	subq	$0x8, %rsp
   6d063:      	cmpb	$0x0, 0x89e6(%rip)      # 0x75a50 <g.4>
   6d06a:      	je	0x7085f <f.2+0x180af>
   6d070:      	movq	%rax, 0x50(%rsp)
   6d075:      	cmpq	$0x0, 0x89cb(%rip)      # 0x75a48 <g.3>
   6d07d:      	je	0x7085f <f.2+0x180af>
   6d083:      	leaq	-0x11(%r12), %rsi
   6d088:      	movq	$0x0, 0x48(%rsp)
   6d091:      	movq	$0x3, 0x30(%rsp)
   6d09a:      	xorl	%edi, %edi
   6d09c:      	callq	0x70870 <f.3>
   6d0a1:      	subq	$0x8, %rsp
   6d0a5:      	cmpb	$0x0, 0x89a4(%rip)      # 0x75a50 <g.4>
   6d0ac:      	je	0x7085f <f.2+0x180af>
   6d0b2:      	addq	0x50(%rsp), %rax
   6d0b7:      	addq	0x18(%rsp), %rax
   6d0bc:      	movq	0x10(%rsp), %rcx
   6d0c1:      	cmpq	$0x0, 0x897f(%rip)      # 0x75a48 <g.3>
   6d0c9:      	je	0x7085f <f.2+0x180af>
   6d0cf:      	cmpq	$0x10, %r12
   6d0d3:      	je	0x6d0e5 <f.2+0x14935>
   6d0d5:      	cmpq	$0xf, %r12
   6d0d9:      	jne	0x6d0fd <f.2+0x1494d>
   6d0db:      	leaq	-0xe(%r12,%rax), %rdx
   6d0e0:      	jmp	0x6d23b <f.2+0x14a8b>
   6d0e5:      	movl	$0x1, %esi
   6d0ea:      	cmpq	$0x0, 0x8956(%rip)      # 0x75a48 <g.3>
   6d0f2:      	jne	0x6d19e <f.2+0x149ee>
   6d0f8:      	jmp	0x7085f <f.2+0x180af>
   6d0fd:      	movq	%rax, 0x18(%rsp)
   6d102:      	movq	%rcx, 0x10(%rsp)
   6d107:      	leaq	-0x10(%r12), %rsi
   6d10c:      	movq	$0x0, 0x48(%rsp)
   6d115:      	movq	$0x3, 0x30(%rsp)
   6d11e:      	xorl	%edi, %edi
   6d120:      	callq	0x70870 <f.3>
   6d125:      	subq	$0x8, %rsp
   6d129:      	cmpb	$0x0, 0x8920(%rip)      # 0x75a50 <g.4>
   6d130:      	je	0x7085f <f.2+0x180af>
   6d136:      	movq	%rax, 0x50(%rsp)
   6d13b:      	cmpq	$0x0, 0x8905(%rip)      # 0x75a48 <g.3>
   6d143:      	je	0x7085f <f.2+0x180af>
   6d149:      	leaq	-0x11(%r12), %rsi
   6d14e:      	movq	$0x0, 0x48(%rsp)
   6d157:      	movq	$0x3, 0x30(%rsp)
   6d160:      	xorl	%edi, %edi
   6d162:      	callq	0x70870 <f.3>
   6d167:      	subq	$0x8, %rsp
   6d16b:      	cmpb	$0x0, 0x88de(%rip)      # 0x75a50 <g.4>
   6d172:      	je	0x7085f <f.2+0x180af>
   6d178:      	movq	%rax, %rsi
   6d17b:      	cmpq	$0x0, 0x88c5(%rip)      # 0x75a48 <g.3>
   6d183:      	movq	0x10(%rsp), %rcx
   6d188:      	movq	0x18(%rsp), %rax
   6d18d:      	je	0x7085f <f.2+0x180af>
   6d193:      	addq	0x50(%rsp), %rsi
   6d198:      	cmpq	$0x11, %r12
   6d19c:      	ja	0x6d1a8 <f.2+0x149f8>
   6d19e:      	leaq	-0x10(%r12), %rdx
   6d1a3:      	jmp	0x6d228 <f.2+0x14a78>
   6d1a8:      	movq	%rsi, 0x50(%rsp)
   6d1ad:      	movq	$0x0, 0x48(%rsp)
   6d1b6:      	movq	$0x3, 0x30(%rsp)
   6d1bf:      	xorl	%edi, %edi
   6d1c1:      	leaq	-0x11(%r12), %rsi
   6d1c6:      	callq	0x70870 <f.3>
   6d1cb:      	subq	$0x8, %rsp
   6d1cf:      	cmpb	$0x0, 0x887a(%rip)      # 0x75a50 <g.4>
   6d1d6:      	je	0x7085f <f.2+0x180af>
   6d1dc:      	movq	%rax, 0x58(%rsp)
   6d1e1:      	cmpq	$0x0, 0x885f(%rip)      # 0x75a48 <g.3>
   6d1e9:      	je	0x7085f <f.2+0x180af>
   6d1ef:      	leaq	-0x12(%r12), %rsi
   6d1f4:      	movq	$0x0, 0x48(%rsp)
   6d1fd:      	movq	$0x3, 0x30(%rsp)
   6d206:      	xorl	%edi, %edi
   6d208:      	callq	0x70870 <f.3>
   6d20d:      	subq	$0x8, %rsp
   6d211:      	movq	%rax, %rdx
   6d214:      	addq	0x58(%rsp), %rdx
   6d219:      	movq	0x10(%rsp), %rcx
   6d21e:      	movq	0x18(%rsp), %rax
   6d223:      	movq	0x50(%rsp), %rsi
   6d228:      	cmpb	$0x0, 0x8821(%rip)      # 0x75a50 <g.4>
   6d22f:      	je	0x7085f <f.2+0x180af>
   6d235:      	addq	%rsi, %rdx
   6d238:      	addq	%rax, %rdx
   6d23b:      	cmpq	$0x0, 0x8805(%rip)      # 0x75a48 <g.3>
   6d243:      	je	0x7085f <f.2+0x180af>
   6d249:      	cmpq	$0xe, %r12
   6d24d:      	ja	0x6d259 <f.2+0x14aa9>
   6d24f:      	leaq	-0xd(%r12), %rsi
   6d254:      	jmp	0x6d5ea <f.2+0x14e3a>
   6d259:      	cmpq	$0xf, %r12
   6d25d:      	jne	0x6d277 <f.2+0x14ac7>
   6d25f:      	movl	$0x1, %esi
   6d264:      	cmpq	$0x0, 0x87dc(%rip)      # 0x75a48 <g.3>
   6d26c:      	jne	0x6d3de <f.2+0x14c2e>
   6d272:      	jmp	0x7085f <f.2+0x180af>
   6d277:      	cmpq	$0x11, %r12
   6d27b:      	jb	0x6d3b2 <f.2+0x14c02>
   6d281:      	movq	%rdx, 0x18(%rsp)
   6d286:      	movq	%rcx, 0x10(%rsp)
   6d28b:      	leaq	-0x10(%r12), %rsi
   6d290:      	movq	$0x0, 0x48(%rsp)
   6d299:      	movq	$0x3, 0x30(%rsp)
   6d2a2:      	xorl	%edi, %edi
   6d2a4:      	callq	0x70870 <f.3>
   6d2a9:      	subq	$0x8, %rsp
   6d2ad:      	cmpb	$0x0, 0x879c(%rip)      # 0x75a50 <g.4>
   6d2b4:      	je	0x7085f <f.2+0x180af>
   6d2ba:      	movq	%rax, 0x50(%rsp)
   6d2bf:      	cmpq	$0x0, 0x8781(%rip)      # 0x75a48 <g.3>
   6d2c7:      	je	0x7085f <f.2+0x180af>
   6d2cd:      	leaq	-0x11(%r12), %rsi
   6d2d2:      	movq	$0x0, 0x48(%rsp)
   6d2db:      	movq	$0x3, 0x30(%rsp)
   6d2e4:      	xorl	%edi, %edi
   6d2e6:      	callq	0x70870 <f.3>
   6d2eb:      	subq	$0x8, %rsp
   6d2ef:      	cmpb	$0x0, 0x875a(%rip)      # 0x75a50 <g.4>
   6d2f6:      	je	0x7085f <f.2+0x180af>
   6d2fc:      	cmpq	$0x0, 0x8744(%rip)      # 0x75a48 <g.3>
   6d304:      	movq	0x10(%rsp), %rcx
   6d309:      	movq	0x18(%rsp), %rdx
   6d30e:      	je	0x7085f <f.2+0x180af>
   6d314:      	addq	0x50(%rsp), %rax
   6d319:      	cmpq	$0x11, %r12
   6d31d:      	je	0x6d3c5 <f.2+0x14c15>
   6d323:      	movq	%rax, 0x50(%rsp)
   6d328:      	movq	$0x0, 0x48(%rsp)
   6d331:      	movq	$0x3, 0x30(%rsp)
   6d33a:      	xorl	%edi, %edi
   6d33c:      	leaq	-0x11(%r12), %rsi
   6d341:      	callq	0x70870 <f.3>
   6d346:      	subq	$0x8, %rsp
   6d34a:      	cmpb	$0x0, 0x86ff(%rip)      # 0x75a50 <g.4>
   6d351:      	je	0x7085f <f.2+0x180af>
   6d357:      	movq	%rax, 0x58(%rsp)
   6d35c:      	cmpq	$0x0, 0x86e4(%rip)      # 0x75a48 <g.3>
   6d364:      	je	0x7085f <f.2+0x180af>
   6d36a:      	leaq	-0x12(%r12), %rsi
   6d36f:      	movq	$0x0, 0x48(%rsp)
   6d378:      	movq	$0x3, 0x30(%rsp)
   6d381:      	xorl	%edi, %edi
   6d383:      	callq	0x70870 <f.3>
   6d388:      	subq	$0x8, %rsp
   6d38c:      	cmpb	$0x0, 0x86bd(%rip)      # 0x75a50 <g.4>
   6d393:      	je	0x7085f <f.2+0x180af>
   6d399:      	movq	%rax, %rsi
   6d39c:      	addq	0x58(%rsp), %rsi
   6d3a1:      	addq	0x50(%rsp), %rsi
   6d3a6:      	movq	0x10(%rsp), %rcx
   6d3ab:      	movq	0x18(%rsp), %rdx
   6d3b0:      	jmp	0x6d3ca <f.2+0x14c1a>
   6d3b2:      	movl	$0x1, %eax
   6d3b7:      	cmpq	$0x0, 0x8689(%rip)      # 0x75a48 <g.3>
   6d3bf:      	je	0x7085f <f.2+0x180af>
   6d3c5:      	leaq	-0x10(%r12,%rax), %rsi
   6d3ca:      	cmpq	$0x0, 0x8676(%rip)      # 0x75a48 <g.3>
   6d3d2:      	je	0x7085f <f.2+0x180af>
   6d3d8:      	cmpq	$0x10, %r12
   6d3dc:      	ja	0x6d3e8 <f.2+0x14c38>
   6d3de:      	leaq	-0xf(%r12), %rdi
   6d3e3:      	jmp	0x6d5e7 <f.2+0x14e37>
   6d3e8:      	cmpq	$0x11, %r12
   6d3ec:      	jne	0x6d406 <f.2+0x14c56>
   6d3ee:      	movl	$0x1, %edi
   6d3f3:      	cmpq	$0x0, 0x864d(%rip)      # 0x75a48 <g.3>
   6d3fb:      	jne	0x6d4b5 <f.2+0x14d05>
   6d401:      	jmp	0x7085f <f.2+0x180af>
   6d406:      	movq	%rsi, 0x50(%rsp)
   6d40b:      	movq	%rdx, 0x18(%rsp)
   6d410:      	movq	%rcx, 0x10(%rsp)
   6d415:      	leaq	-0x11(%r12), %rsi
   6d41a:      	movq	$0x0, 0x48(%rsp)
   6d423:      	movq	$0x3, 0x30(%rsp)
   6d42c:      	xorl	%edi, %edi
   6d42e:      	callq	0x70870 <f.3>
   6d433:      	subq	$0x8, %rsp
   6d437:      	cmpb	$0x0, 0x8612(%rip)      # 0x75a50 <g.4>
   6d43e:      	je	0x7085f <f.2+0x180af>
   6d444:      	movq	%rax, 0x58(%rsp)
   6d449:      	cmpq	$0x0, 0x85f7(%rip)      # 0x75a48 <g.3>
   6d451:      	je	0x7085f <f.2+0x180af>
   6d457:      	leaq	-0x12(%r12), %rsi
   6d45c:      	movq	$0x0, 0x48(%rsp)
   6d465:      	movq	$0x3, 0x30(%rsp)
   6d46e:      	xorl	%edi, %edi
   6d470:      	callq	0x70870 <f.3>
   6d475:      	subq	$0x8, %rsp
   6d479:      	cmpb	$0x0, 0x85d0(%rip)      # 0x75a50 <g.4>
   6d480:      	je	0x7085f <f.2+0x180af>
   6d486:      	cmpq	$0x0, 0x85ba(%rip)      # 0x75a48 <g.3>
   6d48e:      	movq	0x10(%rsp), %rcx
   6d493:      	movq	0x18(%rsp), %rdx
   6d498:      	movq	0x50(%rsp), %rsi
   6d49d:      	je	0x7085f <f.2+0x180af>
   6d4a3:      	movq	%rax, %rdi
   6d4a6:      	addq	0x58(%rsp), %rdi
   6d4ab:      	cmpq	$0x12, %r12
   6d4af:      	ja	0x6d562 <f.2+0x14db2>
   6d4b5:      	leaq	-0x11(%r12), %rax
   6d4ba:      	jmp	0x6d5e4 <f.2+0x14e34>
   6d4bf:      	movq	%rdi, 0x58(%rsp)
   6d4c4:      	movq	$0x0, 0x48(%rsp)
   6d4cd:      	movq	$0x3, 0x30(%rsp)
   6d4d6:      	xorl	%edi, %edi
   6d4d8:      	leaq	-0x12(%r12), %rsi
   6d4dd:      	callq	0x70870 <f.3>
   6d4e2:      	subq	$0x8, %rsp
   6d4e6:      	movq	%rax, 0x60(%rsp)
   6d4eb:      	cmpb	$0x0, 0x855e(%rip)      # 0x75a50 <g.4>
   6d4f2:      	je	0x7085f <f.2+0x180af>
   6d4f8:      	cmpq	$0x0, 0x8548(%rip)      # 0x75a48 <g.3>
   6d500:      	je	0x7085f <f.2+0x180af>
   6d506:      	leaq	-0x13(%r12), %rsi
   6d50b:      	movq	$0x0, 0x48(%rsp)
   6d514:      	movq	$0x3, 0x30(%rsp)
   6d51d:      	xorl	%edi, %edi
   6d51f:      	callq	0x70870 <f.3>
   6d524:      	subq	$0x8, %rsp
   6d528:      	addq	0x60(%rsp), %rax
   6d52d:      	movq	0x10(%rsp), %rcx
   6d532:      	movq	0x18(%rsp), %rdx
   6d537:      	movq	0x50(%rsp), %rsi
   6d53c:      	movq	0x58(%rsp), %rdi
   6d541:      	addq	%rax, %rdi
   6d544:      	addq	%rdi, %rsi
   6d547:      	addq	%rsi, %rdx
   6d54a:      	addq	%rdx, %rcx
   6d54d:      	addq	%rcx, %rbp
   6d550:      	cmpb	$0x0, 0x84f9(%rip)      # 0x75a50 <g.4>
   6d557:      	jne	0x68d53 <f.2+0x105a3>
   6d55d:      	jmp	0x7085f <f.2+0x180af>
   6d562:      	movq	%rdi, 0x58(%rsp)
   6d567:      	movq	$0x0, 0x48(%rsp)
   6d570:      	movq	$0x3, 0x30(%rsp)
   6d579:      	xorl	%edi, %edi
   6d57b:      	leaq	-0x12(%r12), %rsi
   6d580:      	callq	0x70870 <f.3>
   6d585:      	subq	$0x8, %rsp
   6d589:      	movq	%rax, 0x60(%rsp)
   6d58e:      	cmpb	$0x0, 0x84bb(%rip)      # 0x75a50 <g.4>
   6d595:      	je	0x7085f <f.2+0x180af>
   6d59b:      	cmpq	$0x0, 0x84a5(%rip)      # 0x75a48 <g.3>
   6d5a3:      	je	0x7085f <f.2+0x180af>
   6d5a9:      	leaq	-0x13(%r12), %rsi
   6d5ae:      	movq	$0x0, 0x48(%rsp)
   6d5b7:      	movq	$0x3, 0x30(%rsp)
   6d5c0:      	xorl	%edi, %edi
   6d5c2:      	callq	0x70870 <f.3>
   6d5c7:      	subq	$0x8, %rsp
   6d5cb:      	addq	0x60(%rsp), %rax
   6d5d0:      	movq	0x10(%rsp), %rcx
   6d5d5:      	movq	0x18(%rsp), %rdx
   6d5da:      	movq	0x50(%rsp), %rsi
   6d5df:      	movq	0x58(%rsp), %rdi
   6d5e4:      	addq	%rax, %rdi
   6d5e7:      	addq	%rdi, %rsi
   6d5ea:      	addq	%rsi, %rdx
   6d5ed:      	addq	%rdx, %rcx
   6d5f0:      	cmpb	$0x0, 0x8459(%rip)      # 0x75a50 <g.4>
   6d5f7:      	je	0x7085f <f.2+0x180af>
   6d5fd:      	addq	%r15, %rcx
   6d600:      	addq	%r14, %rcx
   6d603:      	leaq	0x68(%rsp), %r15
   6d608:      	cmpq	$0x0, 0x8438(%rip)      # 0x75a48 <g.3>
   6d610:      	je	0x7085f <f.2+0x180af>
   6d616:      	cmpq	$0x7, %r12
   6d61a:      	ja	0x6d625 <f.2+0x14e75>
   6d61c:      	addq	$-0x6, %r12
   6d620:      	jmp	0x707e4 <f.2+0x18034>
   6d625:      	cmpq	$0x8, %r12
   6d629:      	jne	0x6d644 <f.2+0x14e94>
   6d62b:      	movl	$0x1, %r14d
   6d631:      	cmpq	$0x0, 0x840f(%rip)      # 0x75a48 <g.3>
   6d639:      	jne	0x6eeda <f.2+0x1672a>
   6d63f:      	jmp	0x7085f <f.2+0x180af>
   6d644:      	cmpq	$0xa, %r12
   6d648:      	jb	0x6d665 <f.2+0x14eb5>
   6d64a:      	jne	0x6d67e <f.2+0x14ece>
   6d64c:      	movl	$0x1, %r14d
   6d652:      	cmpq	$0x0, 0x83ee(%rip)      # 0x75a48 <g.3>
   6d65a:      	jne	0x6dc55 <f.2+0x154a5>
   6d660:      	jmp	0x7085f <f.2+0x180af>
   6d665:      	movl	$0x1, %r15d
   6d66b:      	cmpq	$0x0, 0x83d5(%rip)      # 0x75a48 <g.3>
   6d673:      	jne	0x6e261 <f.2+0x15ab1>
   6d679:      	jmp	0x7085f <f.2+0x180af>
   6d67e:      	cmpq	$0xc, %r12
   6d682:      	jb	0x6d69f <f.2+0x14eef>
   6d684:      	jne	0x6d6b8 <f.2+0x14f08>
   6d686:      	movl	$0x1, %r14d
   6d68c:      	cmpq	$0x0, 0x83b4(%rip)      # 0x75a48 <g.3>
   6d694:      	jne	0x6d809 <f.2+0x15059>
   6d69a:      	jmp	0x7085f <f.2+0x180af>
   6d69f:      	movl	$0x1, %r15d
   6d6a5:      	cmpq	$0x0, 0x839b(%rip)      # 0x75a48 <g.3>
   6d6ad:      	jne	0x6d970 <f.2+0x151c0>
   6d6b3:      	jmp	0x7085f <f.2+0x180af>
   6d6b8:      	cmpq	$0xe, %r12
   6d6bc:      	jb	0x6d7dc <f.2+0x1502c>
   6d6c2:      	movq	%rcx, 0x10(%rsp)
   6d6c7:      	leaq	-0xd(%r12), %rsi
   6d6cc:      	movq	$0x0, 0x48(%rsp)
   6d6d5:      	movq	$0x3, 0x30(%rsp)
   6d6de:      	xorl	%edi, %edi
   6d6e0:      	callq	0x70870 <f.3>
   6d6e5:      	subq	$0x8, %rsp
   6d6e9:      	cmpb	$0x0, 0x8360(%rip)      # 0x75a50 <g.4>
   6d6f0:      	je	0x7085f <f.2+0x180af>
   6d6f6:      	cmpq	$0x0, 0x834a(%rip)      # 0x75a48 <g.3>
   6d6fe:      	je	0x7085f <f.2+0x180af>
   6d704:      	movq	%rax, %r14
   6d707:      	leaq	-0xe(%r12), %rsi
   6d70c:      	movq	$0x0, 0x48(%rsp)
   6d715:      	movq	$0x3, 0x30(%rsp)
   6d71e:      	xorl	%edi, %edi
   6d720:      	callq	0x70870 <f.3>
   6d725:      	subq	$0x8, %rsp
   6d729:      	cmpb	$0x0, 0x8320(%rip)      # 0x75a50 <g.4>
   6d730:      	je	0x7085f <f.2+0x180af>
   6d736:      	cmpq	$0x0, 0x830a(%rip)      # 0x75a48 <g.3>
   6d73e:      	movq	0x10(%rsp), %rcx
   6d743:      	je	0x7085f <f.2+0x180af>
   6d749:      	movq	%rax, %r15
   6d74c:      	addq	%r14, %r15
   6d74f:      	cmpq	$0xe, %r12
   6d753:      	je	0x6d7f0 <f.2+0x15040>
   6d759:      	movq	$0x0, 0x48(%rsp)
   6d762:      	movq	$0x3, 0x30(%rsp)
   6d76b:      	xorl	%edi, %edi
   6d76d:      	leaq	-0xe(%r12), %rsi
   6d772:      	callq	0x70870 <f.3>
   6d777:      	subq	$0x8, %rsp
   6d77b:      	cmpb	$0x0, 0x82ce(%rip)      # 0x75a50 <g.4>
   6d782:      	je	0x7085f <f.2+0x180af>
   6d788:      	movq	%rax, 0x18(%rsp)
   6d78d:      	cmpq	$0x0, 0x82b3(%rip)      # 0x75a48 <g.3>
   6d795:      	je	0x7085f <f.2+0x180af>
   6d79b:      	leaq	-0xf(%r12), %rsi
   6d7a0:      	movq	$0x0, 0x48(%rsp)
   6d7a9:      	movq	$0x3, 0x30(%rsp)
   6d7b2:      	xorl	%edi, %edi
   6d7b4:      	callq	0x70870 <f.3>
   6d7b9:      	subq	$0x8, %rsp
   6d7bd:      	cmpb	$0x0, 0x828c(%rip)      # 0x75a50 <g.4>
   6d7c4:      	je	0x7085f <f.2+0x180af>
   6d7ca:      	movq	%rax, %r14
   6d7cd:      	addq	0x18(%rsp), %r14
   6d7d2:      	addq	%r15, %r14
   6d7d5:      	movq	0x10(%rsp), %rcx
   6d7da:      	jmp	0x6d7f5 <f.2+0x15045>
   6d7dc:      	movl	$0x1, %r15d
   6d7e2:      	cmpq	$0x0, 0x825e(%rip)      # 0x75a48 <g.3>
   6d7ea:      	je	0x7085f <f.2+0x180af>
   6d7f0:      	leaq	-0xd(%r12,%r15), %r14
   6d7f5:      	cmpq	$0x0, 0x824b(%rip)      # 0x75a48 <g.3>
   6d7fd:      	je	0x7085f <f.2+0x180af>
   6d803:      	cmpq	$0xd, %r12
   6d807:      	ja	0x6d813 <f.2+0x15063>
   6d809:      	leaq	-0xc(%r12,%r14), %r15
   6d80e:      	jmp	0x6d956 <f.2+0x151a6>
   6d813:      	cmpq	$0xe, %r12
   6d817:      	jne	0x6d831 <f.2+0x15081>
   6d819:      	movl	$0x1, %eax
   6d81e:      	cmpq	$0x0, 0x8222(%rip)      # 0x75a48 <g.3>
   6d826:      	jne	0x6d8c1 <f.2+0x15111>
   6d82c:      	jmp	0x7085f <f.2+0x180af>
   6d831:      	movq	%rcx, 0x10(%rsp)
   6d836:      	leaq	-0xe(%r12), %rsi
   6d83b:      	movq	$0x0, 0x48(%rsp)
   6d844:      	movq	$0x3, 0x30(%rsp)
   6d84d:      	xorl	%edi, %edi
   6d84f:      	callq	0x70870 <f.3>
   6d854:      	subq	$0x8, %rsp
   6d858:      	cmpb	$0x0, 0x81f1(%rip)      # 0x75a50 <g.4>
   6d85f:      	je	0x7085f <f.2+0x180af>
   6d865:      	cmpq	$0x0, 0x81db(%rip)      # 0x75a48 <g.3>
   6d86d:      	je	0x7085f <f.2+0x180af>
   6d873:      	movq	%rax, %r15
   6d876:      	leaq	-0xf(%r12), %rsi
   6d87b:      	movq	$0x0, 0x48(%rsp)
   6d884:      	movq	$0x3, 0x30(%rsp)
   6d88d:      	xorl	%edi, %edi
   6d88f:      	callq	0x70870 <f.3>
   6d894:      	subq	$0x8, %rsp
   6d898:      	cmpb	$0x0, 0x81b1(%rip)      # 0x75a50 <g.4>
   6d89f:      	je	0x7085f <f.2+0x180af>
   6d8a5:      	cmpq	$0x0, 0x819b(%rip)      # 0x75a48 <g.3>
   6d8ad:      	movq	0x10(%rsp), %rcx
   6d8b2:      	je	0x7085f <f.2+0x180af>
   6d8b8:      	addq	%r15, %rax
   6d8bb:      	cmpq	$0xf, %r12
   6d8bf:      	ja	0x6d8c8 <f.2+0x15118>
   6d8c1:      	leaq	-0xe(%r12), %r15
   6d8c6:      	jmp	0x6d943 <f.2+0x15193>
   6d8c8:      	movq	%rax, 0x18(%rsp)
   6d8cd:      	movq	$0x0, 0x48(%rsp)
   6d8d6:      	movq	$0x3, 0x30(%rsp)
   6d8df:      	xorl	%edi, %edi
   6d8e1:      	leaq	-0xf(%r12), %rsi
   6d8e6:      	callq	0x70870 <f.3>
   6d8eb:      	subq	$0x8, %rsp
   6d8ef:      	cmpb	$0x0, 0x815a(%rip)      # 0x75a50 <g.4>
   6d8f6:      	je	0x7085f <f.2+0x180af>
   6d8fc:      	movq	%rax, 0x50(%rsp)
   6d901:      	cmpq	$0x0, 0x813f(%rip)      # 0x75a48 <g.3>
   6d909:      	je	0x7085f <f.2+0x180af>
   6d90f:      	leaq	-0x10(%r12), %rsi
   6d914:      	movq	$0x0, 0x48(%rsp)
   6d91d:      	movq	$0x3, 0x30(%rsp)
   6d926:      	xorl	%edi, %edi
   6d928:      	callq	0x70870 <f.3>
   6d92d:      	subq	$0x8, %rsp
   6d931:      	movq	%rax, %r15
   6d934:      	addq	0x50(%rsp), %r15
   6d939:      	movq	0x10(%rsp), %rcx
   6d93e:      	movq	0x18(%rsp), %rax
   6d943:      	cmpb	$0x0, 0x8106(%rip)      # 0x75a50 <g.4>
   6d94a:      	je	0x7085f <f.2+0x180af>
   6d950:      	addq	%rax, %r15
   6d953:      	addq	%r14, %r15
   6d956:      	cmpq	$0x0, 0x80ea(%rip)      # 0x75a48 <g.3>
   6d95e:      	je	0x7085f <f.2+0x180af>
   6d964:      	cmpq	$0xd, %r12
   6d968:      	je	0x6d97a <f.2+0x151ca>
   6d96a:      	cmpq	$0xc, %r12
   6d96e:      	jne	0x6d992 <f.2+0x151e2>
   6d970:      	leaq	-0xb(%r12,%r15), %r14
   6d975:      	jmp	0x6dc41 <f.2+0x15491>
   6d97a:      	movl	$0x1, %edx
   6d97f:      	cmpq	$0x0, 0x80c1(%rip)      # 0x75a48 <g.3>
   6d987:      	jne	0x6dae7 <f.2+0x15337>
   6d98d:      	jmp	0x7085f <f.2+0x180af>
   6d992:      	cmpq	$0xf, %r12
   6d996:      	jb	0x6daba <f.2+0x1530a>
   6d99c:      	movq	%rcx, 0x10(%rsp)
   6d9a1:      	leaq	-0xe(%r12), %rsi
   6d9a6:      	movq	$0x0, 0x48(%rsp)
   6d9af:      	movq	$0x3, 0x30(%rsp)
   6d9b8:      	xorl	%edi, %edi
   6d9ba:      	callq	0x70870 <f.3>
   6d9bf:      	subq	$0x8, %rsp
   6d9c3:      	cmpb	$0x0, 0x8086(%rip)      # 0x75a50 <g.4>
   6d9ca:      	je	0x7085f <f.2+0x180af>
   6d9d0:      	movq	%rax, 0x18(%rsp)
   6d9d5:      	cmpq	$0x0, 0x806b(%rip)      # 0x75a48 <g.3>
   6d9dd:      	je	0x7085f <f.2+0x180af>
   6d9e3:      	leaq	-0xf(%r12), %rsi
   6d9e8:      	movq	$0x0, 0x48(%rsp)
   6d9f1:      	movq	$0x3, 0x30(%rsp)
   6d9fa:      	xorl	%edi, %edi
   6d9fc:      	callq	0x70870 <f.3>
   6da01:      	subq	$0x8, %rsp
   6da05:      	cmpb	$0x0, 0x8044(%rip)      # 0x75a50 <g.4>
   6da0c:      	je	0x7085f <f.2+0x180af>
   6da12:      	cmpq	$0x0, 0x802e(%rip)      # 0x75a48 <g.3>
   6da1a:      	movq	0x10(%rsp), %rcx
   6da1f:      	je	0x7085f <f.2+0x180af>
   6da25:      	movq	%rax, %r14
   6da28:      	addq	0x18(%rsp), %r14
   6da2d:      	cmpq	$0xf, %r12
   6da31:      	je	0x6dace <f.2+0x1531e>
   6da37:      	movq	$0x0, 0x48(%rsp)
   6da40:      	movq	$0x3, 0x30(%rsp)
   6da49:      	xorl	%edi, %edi
   6da4b:      	leaq	-0xf(%r12), %rsi
   6da50:      	callq	0x70870 <f.3>
   6da55:      	subq	$0x8, %rsp
   6da59:      	cmpb	$0x0, 0x7ff0(%rip)      # 0x75a50 <g.4>
   6da60:      	je	0x7085f <f.2+0x180af>
   6da66:      	movq	%rax, 0x18(%rsp)
   6da6b:      	cmpq	$0x0, 0x7fd5(%rip)      # 0x75a48 <g.3>
   6da73:      	je	0x7085f <f.2+0x180af>
   6da79:      	leaq	-0x10(%r12), %rsi
   6da7e:      	movq	$0x0, 0x48(%rsp)
   6da87:      	movq	$0x3, 0x30(%rsp)
   6da90:      	xorl	%edi, %edi
   6da92:      	callq	0x70870 <f.3>
   6da97:      	subq	$0x8, %rsp
   6da9b:      	cmpb	$0x0, 0x7fae(%rip)      # 0x75a50 <g.4>
   6daa2:      	je	0x7085f <f.2+0x180af>
   6daa8:      	movq	%rax, %rdx
   6daab:      	addq	0x18(%rsp), %rdx
   6dab0:      	addq	%r14, %rdx
   6dab3:      	movq	0x10(%rsp), %rcx
   6dab8:      	jmp	0x6dad3 <f.2+0x15323>
   6daba:      	movl	$0x1, %r14d
   6dac0:      	cmpq	$0x0, 0x7f80(%rip)      # 0x75a48 <g.3>
   6dac8:      	je	0x7085f <f.2+0x180af>
   6dace:      	leaq	-0xe(%r12,%r14), %rdx
   6dad3:      	cmpq	$0x0, 0x7f6d(%rip)      # 0x75a48 <g.3>
   6dadb:      	je	0x7085f <f.2+0x180af>
   6dae1:      	cmpq	$0xe, %r12
   6dae5:      	ja	0x6daf1 <f.2+0x15341>
   6dae7:      	leaq	-0xd(%r12), %r14
   6daec:      	jmp	0x6dc2e <f.2+0x1547e>
   6daf1:      	cmpq	$0xf, %r12
   6daf5:      	jne	0x6db10 <f.2+0x15360>
   6daf7:      	movl	$0x1, %r14d
   6dafd:      	cmpq	$0x0, 0x7f43(%rip)      # 0x75a48 <g.3>
   6db05:      	jne	0x6dbb1 <f.2+0x15401>
   6db0b:      	jmp	0x7085f <f.2+0x180af>
   6db10:      	movq	%rdx, 0x18(%rsp)
   6db15:      	movq	%rcx, 0x10(%rsp)
   6db1a:      	leaq	-0xf(%r12), %rsi
   6db1f:      	movq	$0x0, 0x48(%rsp)
   6db28:      	movq	$0x3, 0x30(%rsp)
   6db31:      	xorl	%edi, %edi
   6db33:      	callq	0x70870 <f.3>
   6db38:      	subq	$0x8, %rsp
   6db3c:      	cmpb	$0x0, 0x7f0d(%rip)      # 0x75a50 <g.4>
   6db43:      	je	0x7085f <f.2+0x180af>
   6db49:      	movq	%rax, 0x50(%rsp)
   6db4e:      	cmpq	$0x0, 0x7ef2(%rip)      # 0x75a48 <g.3>
   6db56:      	je	0x7085f <f.2+0x180af>
   6db5c:      	leaq	-0x10(%r12), %rsi
   6db61:      	movq	$0x0, 0x48(%rsp)
   6db6a:      	movq	$0x3, 0x30(%rsp)
   6db73:      	xorl	%edi, %edi
   6db75:      	callq	0x70870 <f.3>
   6db7a:      	subq	$0x8, %rsp
   6db7e:      	cmpb	$0x0, 0x7ecb(%rip)      # 0x75a50 <g.4>
   6db85:      	je	0x7085f <f.2+0x180af>
   6db8b:      	cmpq	$0x0, 0x7eb5(%rip)      # 0x75a48 <g.3>
   6db93:      	movq	0x10(%rsp), %rcx
   6db98:      	movq	0x18(%rsp), %rdx
   6db9d:      	je	0x7085f <f.2+0x180af>
   6dba3:      	movq	%rax, %r14
   6dba6:      	addq	0x50(%rsp), %r14
   6dbab:      	cmpq	$0x10, %r12
   6dbaf:      	ja	0x6dbb8 <f.2+0x15408>
   6dbb1:      	leaq	-0xf(%r12), %rax
   6dbb6:      	jmp	0x6dc2b <f.2+0x1547b>
   6dbb8:      	movq	$0x0, 0x48(%rsp)
   6dbc1:      	movq	$0x3, 0x30(%rsp)
   6dbca:      	xorl	%edi, %edi
   6dbcc:      	leaq	-0x10(%r12), %rsi
   6dbd1:      	callq	0x70870 <f.3>
   6dbd6:      	subq	$0x8, %rsp
   6dbda:      	cmpb	$0x0, 0x7e6f(%rip)      # 0x75a50 <g.4>
   6dbe1:      	je	0x7085f <f.2+0x180af>
   6dbe7:      	movq	%rax, 0x50(%rsp)
   6dbec:      	cmpq	$0x0, 0x7e54(%rip)      # 0x75a48 <g.3>
   6dbf4:      	je	0x7085f <f.2+0x180af>
   6dbfa:      	leaq	-0x11(%r12), %rsi
   6dbff:      	movq	$0x0, 0x48(%rsp)
   6dc08:      	movq	$0x3, 0x30(%rsp)
   6dc11:      	xorl	%edi, %edi
   6dc13:      	callq	0x70870 <f.3>
   6dc18:      	subq	$0x8, %rsp
   6dc1c:      	addq	0x50(%rsp), %rax
   6dc21:      	movq	0x10(%rsp), %rcx
   6dc26:      	movq	0x18(%rsp), %rdx
   6dc2b:      	addq	%rax, %r14
   6dc2e:      	cmpb	$0x0, 0x7e1b(%rip)      # 0x75a50 <g.4>
   6dc35:      	je	0x7085f <f.2+0x180af>
   6dc3b:      	addq	%rdx, %r14
   6dc3e:      	addq	%r15, %r14
   6dc41:      	cmpq	$0x0, 0x7dff(%rip)      # 0x75a48 <g.3>
   6dc49:      	je	0x7085f <f.2+0x180af>
   6dc4f:      	cmpq	$0xb, %r12
   6dc53:      	ja	0x6dc5f <f.2+0x154af>
   6dc55:      	leaq	-0xa(%r12,%r14), %r15
   6dc5a:      	jmp	0x6e247 <f.2+0x15a97>
   6dc5f:      	cmpq	$0xc, %r12
   6dc63:      	jne	0x6dc7d <f.2+0x154cd>
   6dc65:      	movl	$0x1, %edx
   6dc6a:      	cmpq	$0x0, 0x7dd6(%rip)      # 0x75a48 <g.3>
   6dc72:      	jne	0x6df55 <f.2+0x157a5>
   6dc78:      	jmp	0x7085f <f.2+0x180af>
   6dc7d:      	cmpq	$0xe, %r12
   6dc81:      	jb	0x6dc9e <f.2+0x154ee>
   6dc83:      	jne	0x6dcb6 <f.2+0x15506>
   6dc85:      	movl	$0x1, %r15d
   6dc8b:      	cmpq	$0x0, 0x7db5(%rip)      # 0x75a48 <g.3>
   6dc93:      	jne	0x6dd4d <f.2+0x1559d>
   6dc99:      	jmp	0x7085f <f.2+0x180af>
   6dc9e:      	movl	$0x1, %eax
   6dca3:      	cmpq	$0x0, 0x7d9d(%rip)      # 0x75a48 <g.3>
   6dcab:      	jne	0x6ddec <f.2+0x1563c>
   6dcb1:      	jmp	0x7085f <f.2+0x180af>
   6dcb6:      	movq	%rcx, 0x10(%rsp)
   6dcbb:      	leaq	-0xe(%r12), %rsi
   6dcc0:      	movq	$0x0, 0x48(%rsp)
   6dcc9:      	movq	$0x3, 0x30(%rsp)
   6dcd2:      	xorl	%edi, %edi
   6dcd4:      	callq	0x70870 <f.3>
   6dcd9:      	subq	$0x8, %rsp
   6dcdd:      	cmpb	$0x0, 0x7d6c(%rip)      # 0x75a50 <g.4>
   6dce4:      	je	0x7085f <f.2+0x180af>
   6dcea:      	movq	%rax, 0x18(%rsp)
   6dcef:      	cmpq	$0x0, 0x7d51(%rip)      # 0x75a48 <g.3>
   6dcf7:      	je	0x7085f <f.2+0x180af>
   6dcfd:      	leaq	-0xf(%r12), %rsi
   6dd02:      	movq	$0x0, 0x48(%rsp)
   6dd0b:      	movq	$0x3, 0x30(%rsp)
   6dd14:      	xorl	%edi, %edi
   6dd16:      	callq	0x70870 <f.3>
   6dd1b:      	subq	$0x8, %rsp
   6dd1f:      	cmpb	$0x0, 0x7d2a(%rip)      # 0x75a50 <g.4>
   6dd26:      	je	0x7085f <f.2+0x180af>
   6dd2c:      	cmpq	$0x0, 0x7d14(%rip)      # 0x75a48 <g.3>
   6dd34:      	movq	0x10(%rsp), %rcx
   6dd39:      	je	0x7085f <f.2+0x180af>
   6dd3f:      	movq	%rax, %r15
   6dd42:      	addq	0x18(%rsp), %r15
   6dd47:      	cmpq	$0xf, %r12
   6dd4b:      	ja	0x6dd54 <f.2+0x155a4>
   6dd4d:      	leaq	-0xe(%r12,%r15), %rax
   6dd52:      	jmp	0x6ddd2 <f.2+0x15622>
   6dd54:      	movq	$0x0, 0x48(%rsp)
   6dd5d:      	movq	$0x3, 0x30(%rsp)
   6dd66:      	xorl	%edi, %edi
   6dd68:      	leaq	-0xf(%r12), %rsi
   6dd6d:      	callq	0x70870 <f.3>
   6dd72:      	subq	$0x8, %rsp
   6dd76:      	cmpb	$0x0, 0x7cd3(%rip)      # 0x75a50 <g.4>
   6dd7d:      	je	0x7085f <f.2+0x180af>
   6dd83:      	movq	%rax, 0x18(%rsp)
   6dd88:      	cmpq	$0x0, 0x7cb8(%rip)      # 0x75a48 <g.3>
   6dd90:      	je	0x7085f <f.2+0x180af>
   6dd96:      	leaq	-0x10(%r12), %rsi
   6dd9b:      	movq	$0x0, 0x48(%rsp)
   6dda4:      	movq	$0x3, 0x30(%rsp)
   6ddad:      	xorl	%edi, %edi
   6ddaf:      	callq	0x70870 <f.3>
   6ddb4:      	subq	$0x8, %rsp
   6ddb8:      	cmpb	$0x0, 0x7c91(%rip)      # 0x75a50 <g.4>
   6ddbf:      	je	0x7085f <f.2+0x180af>
   6ddc5:      	addq	0x18(%rsp), %rax
   6ddca:      	addq	%r15, %rax
   6ddcd:      	movq	0x10(%rsp), %rcx
   6ddd2:      	cmpq	$0x0, 0x7c6e(%rip)      # 0x75a48 <g.3>
   6ddda:      	je	0x7085f <f.2+0x180af>
   6dde0:      	cmpq	$0xf, %r12
   6dde4:      	je	0x6ddf6 <f.2+0x15646>
   6dde6:      	cmpq	$0xe, %r12
   6ddea:      	jne	0x6de0e <f.2+0x1565e>
   6ddec:      	leaq	-0xd(%r12,%rax), %rdx
   6ddf1:      	jmp	0x6df41 <f.2+0x15791>
   6ddf6:      	movl	$0x1, %esi
   6ddfb:      	cmpq	$0x0, 0x7c45(%rip)      # 0x75a48 <g.3>
   6de03:      	jne	0x6deab <f.2+0x156fb>
   6de09:      	jmp	0x7085f <f.2+0x180af>
   6de0e:      	movq	%rax, 0x18(%rsp)
   6de13:      	movq	%rcx, 0x10(%rsp)
   6de18:      	leaq	-0xf(%r12), %rsi
   6de1d:      	movq	$0x0, 0x48(%rsp)
   6de26:      	movq	$0x3, 0x30(%rsp)
   6de2f:      	xorl	%edi, %edi
   6de31:      	callq	0x70870 <f.3>
   6de36:      	subq	$0x8, %rsp
   6de3a:      	cmpb	$0x0, 0x7c0f(%rip)      # 0x75a50 <g.4>
   6de41:      	je	0x7085f <f.2+0x180af>
   6de47:      	cmpq	$0x0, 0x7bf9(%rip)      # 0x75a48 <g.3>
   6de4f:      	je	0x7085f <f.2+0x180af>
   6de55:      	movq	%rax, %r15
   6de58:      	leaq	-0x10(%r12), %rsi
   6de5d:      	movq	$0x0, 0x48(%rsp)
   6de66:      	movq	$0x3, 0x30(%rsp)
   6de6f:      	xorl	%edi, %edi
   6de71:      	callq	0x70870 <f.3>
   6de76:      	subq	$0x8, %rsp
   6de7a:      	cmpb	$0x0, 0x7bcf(%rip)      # 0x75a50 <g.4>
   6de81:      	je	0x7085f <f.2+0x180af>
   6de87:      	movq	%rax, %rsi
   6de8a:      	cmpq	$0x0, 0x7bb6(%rip)      # 0x75a48 <g.3>
   6de92:      	movq	0x10(%rsp), %rcx
   6de97:      	movq	0x18(%rsp), %rax
   6de9c:      	je	0x7085f <f.2+0x180af>
   6dea2:      	addq	%r15, %rsi
   6dea5:      	cmpq	$0x10, %r12
   6dea9:      	ja	0x6deb2 <f.2+0x15702>
   6deab:      	leaq	-0xf(%r12), %rdx
   6deb0:      	jmp	0x6df2e <f.2+0x1577e>
   6deb2:      	movq	%rsi, 0x50(%rsp)
   6deb7:      	movq	$0x0, 0x48(%rsp)
   6dec0:      	movq	$0x3, 0x30(%rsp)
   6dec9:      	xorl	%edi, %edi
   6decb:      	leaq	-0x10(%r12), %rsi
   6ded0:      	callq	0x70870 <f.3>
   6ded5:      	subq	$0x8, %rsp
   6ded9:      	cmpb	$0x0, 0x7b70(%rip)      # 0x75a50 <g.4>
   6dee0:      	je	0x7085f <f.2+0x180af>
   6dee6:      	cmpq	$0x0, 0x7b5a(%rip)      # 0x75a48 <g.3>
   6deee:      	je	0x7085f <f.2+0x180af>
   6def4:      	movq	%rax, %r15
   6def7:      	leaq	-0x11(%r12), %rsi
   6defc:      	movq	$0x0, 0x48(%rsp)
   6df05:      	movq	$0x3, 0x30(%rsp)
   6df0e:      	xorl	%edi, %edi
   6df10:      	callq	0x70870 <f.3>
   6df15:      	subq	$0x8, %rsp
   6df19:      	movq	%rax, %rdx
   6df1c:      	addq	%r15, %rdx
   6df1f:      	movq	0x10(%rsp), %rcx
   6df24:      	movq	0x18(%rsp), %rax
   6df29:      	movq	0x50(%rsp), %rsi
   6df2e:      	cmpb	$0x0, 0x7b1b(%rip)      # 0x75a50 <g.4>
   6df35:      	je	0x7085f <f.2+0x180af>
   6df3b:      	addq	%rsi, %rdx
   6df3e:      	addq	%rax, %rdx
   6df41:      	cmpq	$0x0, 0x7aff(%rip)      # 0x75a48 <g.3>
   6df49:      	je	0x7085f <f.2+0x180af>
   6df4f:      	cmpq	$0xd, %r12
   6df53:      	ja	0x6df5f <f.2+0x157af>
   6df55:      	leaq	-0xc(%r12), %r15
   6df5a:      	jmp	0x6e234 <f.2+0x15a84>
   6df5f:      	cmpq	$0xe, %r12
   6df63:      	jne	0x6df7e <f.2+0x157ce>
   6df65:      	movl	$0x1, %r15d
   6df6b:      	cmpq	$0x0, 0x7ad5(%rip)      # 0x75a48 <g.3>
   6df73:      	jne	0x6e0e1 <f.2+0x15931>
   6df79:      	jmp	0x7085f <f.2+0x180af>
   6df7e:      	cmpq	$0x10, %r12
   6df82:      	jb	0x6e0b5 <f.2+0x15905>
   6df88:      	movq	%rdx, 0x18(%rsp)
   6df8d:      	movq	%rcx, 0x10(%rsp)
   6df92:      	leaq	-0xf(%r12), %rsi
   6df97:      	movq	$0x0, 0x48(%rsp)
   6dfa0:      	movq	$0x3, 0x30(%rsp)
   6dfa9:      	xorl	%edi, %edi
   6dfab:      	callq	0x70870 <f.3>
   6dfb0:      	subq	$0x8, %rsp
   6dfb4:      	cmpb	$0x0, 0x7a95(%rip)      # 0x75a50 <g.4>
   6dfbb:      	je	0x7085f <f.2+0x180af>
   6dfc1:      	cmpq	$0x0, 0x7a7f(%rip)      # 0x75a48 <g.3>
   6dfc9:      	je	0x7085f <f.2+0x180af>
   6dfcf:      	movq	%rax, %r15
   6dfd2:      	leaq	-0x10(%r12), %rsi
   6dfd7:      	movq	$0x0, 0x48(%rsp)
   6dfe0:      	movq	$0x3, 0x30(%rsp)
   6dfe9:      	xorl	%edi, %edi
   6dfeb:      	callq	0x70870 <f.3>
   6dff0:      	subq	$0x8, %rsp
   6dff4:      	cmpb	$0x0, 0x7a55(%rip)      # 0x75a50 <g.4>
   6dffb:      	je	0x7085f <f.2+0x180af>
   6e001:      	cmpq	$0x0, 0x7a3f(%rip)      # 0x75a48 <g.3>
   6e009:      	movq	0x10(%rsp), %rcx
   6e00e:      	movq	0x18(%rsp), %rdx
   6e013:      	je	0x7085f <f.2+0x180af>
   6e019:      	addq	%r15, %rax
   6e01c:      	cmpq	$0x10, %r12
   6e020:      	je	0x6e0c8 <f.2+0x15918>
   6e026:      	movq	%rax, 0x50(%rsp)
   6e02b:      	movq	$0x0, 0x48(%rsp)
   6e034:      	movq	$0x3, 0x30(%rsp)
   6e03d:      	xorl	%edi, %edi
   6e03f:      	leaq	-0x10(%r12), %rsi
   6e044:      	callq	0x70870 <f.3>
   6e049:      	subq	$0x8, %rsp
   6e04d:      	cmpb	$0x0, 0x79fc(%rip)      # 0x75a50 <g.4>
   6e054:      	je	0x7085f <f.2+0x180af>
   6e05a:      	movq	%rax, 0x58(%rsp)
   6e05f:      	cmpq	$0x0, 0x79e1(%rip)      # 0x75a48 <g.3>
   6e067:      	je	0x7085f <f.2+0x180af>
   6e06d:      	leaq	-0x11(%r12), %rsi
   6e072:      	movq	$0x0, 0x48(%rsp)
   6e07b:      	movq	$0x3, 0x30(%rsp)
   6e084:      	xorl	%edi, %edi
   6e086:      	callq	0x70870 <f.3>
   6e08b:      	subq	$0x8, %rsp
   6e08f:      	cmpb	$0x0, 0x79ba(%rip)      # 0x75a50 <g.4>
   6e096:      	je	0x7085f <f.2+0x180af>
   6e09c:      	movq	%rax, %r15
   6e09f:      	addq	0x58(%rsp), %r15
   6e0a4:      	addq	0x50(%rsp), %r15
   6e0a9:      	movq	0x10(%rsp), %rcx
   6e0ae:      	movq	0x18(%rsp), %rdx
   6e0b3:      	jmp	0x6e0cd <f.2+0x1591d>
   6e0b5:      	movl	$0x1, %eax
   6e0ba:      	cmpq	$0x0, 0x7986(%rip)      # 0x75a48 <g.3>
   6e0c2:      	je	0x7085f <f.2+0x180af>
   6e0c8:      	leaq	-0xf(%r12,%rax), %r15
   6e0cd:      	cmpq	$0x0, 0x7973(%rip)      # 0x75a48 <g.3>
   6e0d5:      	je	0x7085f <f.2+0x180af>
   6e0db:      	cmpq	$0xf, %r12
   6e0df:      	ja	0x6e0eb <f.2+0x1593b>
   6e0e1:      	leaq	-0xe(%r12), %rsi
   6e0e6:      	jmp	0x6e231 <f.2+0x15a81>
   6e0eb:      	cmpq	$0x10, %r12
   6e0ef:      	jne	0x6e109 <f.2+0x15959>
   6e0f1:      	movl	$0x1, %esi
   6e0f6:      	cmpq	$0x0, 0x794a(%rip)      # 0x75a48 <g.3>
   6e0fe:      	jne	0x6e1aa <f.2+0x159fa>
   6e104:      	jmp	0x7085f <f.2+0x180af>
   6e109:      	movq	%rdx, 0x18(%rsp)
   6e10e:      	movq	%rcx, 0x10(%rsp)
   6e113:      	leaq	-0x10(%r12), %rsi
   6e118:      	movq	$0x0, 0x48(%rsp)
   6e121:      	movq	$0x3, 0x30(%rsp)
   6e12a:      	xorl	%edi, %edi
   6e12c:      	callq	0x70870 <f.3>
   6e131:      	subq	$0x8, %rsp
   6e135:      	cmpb	$0x0, 0x7914(%rip)      # 0x75a50 <g.4>
   6e13c:      	je	0x7085f <f.2+0x180af>
   6e142:      	movq	%rax, 0x50(%rsp)
   6e147:      	cmpq	$0x0, 0x78f9(%rip)      # 0x75a48 <g.3>
   6e14f:      	je	0x7085f <f.2+0x180af>
   6e155:      	leaq	-0x11(%r12), %rsi
   6e15a:      	movq	$0x0, 0x48(%rsp)
   6e163:      	movq	$0x3, 0x30(%rsp)
   6e16c:      	xorl	%edi, %edi
   6e16e:      	callq	0x70870 <f.3>
   6e173:      	subq	$0x8, %rsp
   6e177:      	cmpb	$0x0, 0x78d2(%rip)      # 0x75a50 <g.4>
   6e17e:      	je	0x7085f <f.2+0x180af>
   6e184:      	cmpq	$0x0, 0x78bc(%rip)      # 0x75a48 <g.3>
   6e18c:      	movq	0x10(%rsp), %rcx
   6e191:      	movq	0x18(%rsp), %rdx
   6e196:      	je	0x7085f <f.2+0x180af>
   6e19c:      	movq	%rax, %rsi
   6e19f:      	addq	0x50(%rsp), %rsi
   6e1a4:      	cmpq	$0x11, %r12
   6e1a8:      	ja	0x6e1b1 <f.2+0x15a01>
   6e1aa:      	leaq	-0x10(%r12), %rax
   6e1af:      	jmp	0x6e22e <f.2+0x15a7e>
   6e1b1:      	movq	%rsi, 0x50(%rsp)
   6e1b6:      	movq	$0x0, 0x48(%rsp)
   6e1bf:      	movq	$0x3, 0x30(%rsp)
   6e1c8:      	xorl	%edi, %edi
   6e1ca:      	leaq	-0x11(%r12), %rsi
   6e1cf:      	callq	0x70870 <f.3>
   6e1d4:      	subq	$0x8, %rsp
   6e1d8:      	movq	%rax, 0x58(%rsp)
   6e1dd:      	cmpb	$0x0, 0x786c(%rip)      # 0x75a50 <g.4>
   6e1e4:      	je	0x7085f <f.2+0x180af>
   6e1ea:      	cmpq	$0x0, 0x7856(%rip)      # 0x75a48 <g.3>
   6e1f2:      	je	0x7085f <f.2+0x180af>
   6e1f8:      	leaq	-0x12(%r12), %rsi
   6e1fd:      	movq	$0x0, 0x48(%rsp)
   6e206:      	movq	$0x3, 0x30(%rsp)
   6e20f:      	xorl	%edi, %edi
   6e211:      	callq	0x70870 <f.3>
   6e216:      	subq	$0x8, %rsp
   6e21a:      	addq	0x58(%rsp), %rax
   6e21f:      	movq	0x10(%rsp), %rcx
   6e224:      	movq	0x18(%rsp), %rdx
   6e229:      	movq	0x50(%rsp), %rsi
   6e22e:      	addq	%rax, %rsi
   6e231:      	addq	%rsi, %r15
   6e234:      	cmpb	$0x0, 0x7815(%rip)      # 0x75a50 <g.4>
   6e23b:      	je	0x7085f <f.2+0x180af>
   6e241:      	addq	%rdx, %r15
   6e244:      	addq	%r14, %r15
   6e247:      	cmpq	$0x0, 0x77f9(%rip)      # 0x75a48 <g.3>
   6e24f:      	je	0x7085f <f.2+0x180af>
   6e255:      	cmpq	$0xb, %r12
   6e259:      	je	0x6e27e <f.2+0x15ace>
   6e25b:      	cmpq	$0xa, %r12
   6e25f:      	jne	0x6e296 <f.2+0x15ae6>
   6e261:      	leaq	-0x9(%r12,%r15), %r14
   6e266:      	cmpq	$0x0, 0x77da(%rip)      # 0x75a48 <g.3>
   6e26e:      	leaq	0x68(%rsp), %r15
   6e273:      	jne	0x6eed4 <f.2+0x16724>
   6e279:      	jmp	0x7085f <f.2+0x180af>
   6e27e:      	movl	$0x1, %edx
   6e283:      	cmpq	$0x0, 0x77bd(%rip)      # 0x75a48 <g.3>
   6e28b:      	jne	0x6e88e <f.2+0x160de>
   6e291:      	jmp	0x7085f <f.2+0x180af>
   6e296:      	cmpq	$0xd, %r12
   6e29a:      	jb	0x6e2b6 <f.2+0x15b06>
   6e29c:      	jne	0x6e2cf <f.2+0x15b1f>
   6e29e:      	movl	$0x1, %eax
   6e2a3:      	cmpq	$0x0, 0x779d(%rip)      # 0x75a48 <g.3>
   6e2ab:      	jne	0x6e421 <f.2+0x15c71>
   6e2b1:      	jmp	0x7085f <f.2+0x180af>
   6e2b6:      	movl	$0x1, %r14d
   6e2bc:      	cmpq	$0x0, 0x7784(%rip)      # 0x75a48 <g.3>
   6e2c4:      	jne	0x6e59d <f.2+0x15ded>
   6e2ca:      	jmp	0x7085f <f.2+0x180af>
   6e2cf:      	cmpq	$0xf, %r12
   6e2d3:      	jb	0x6e3f4 <f.2+0x15c44>
   6e2d9:      	movq	%rcx, 0x10(%rsp)
   6e2de:      	leaq	-0xe(%r12), %rsi
   6e2e3:      	movq	$0x0, 0x48(%rsp)
   6e2ec:      	movq	$0x3, 0x30(%rsp)
   6e2f5:      	xorl	%edi, %edi
   6e2f7:      	callq	0x70870 <f.3>
   6e2fc:      	subq	$0x8, %rsp
   6e300:      	cmpb	$0x0, 0x7749(%rip)      # 0x75a50 <g.4>
   6e307:      	je	0x7085f <f.2+0x180af>
   6e30d:      	movq	%rax, 0x18(%rsp)
   6e312:      	cmpq	$0x0, 0x772e(%rip)      # 0x75a48 <g.3>
   6e31a:      	je	0x7085f <f.2+0x180af>
   6e320:      	leaq	-0xf(%r12), %rsi
   6e325:      	movq	$0x0, 0x48(%rsp)
   6e32e:      	movq	$0x3, 0x30(%rsp)
   6e337:      	xorl	%edi, %edi
   6e339:      	callq	0x70870 <f.3>
   6e33e:      	subq	$0x8, %rsp
   6e342:      	cmpb	$0x0, 0x7707(%rip)      # 0x75a50 <g.4>
   6e349:      	je	0x7085f <f.2+0x180af>
   6e34f:      	cmpq	$0x0, 0x76f1(%rip)      # 0x75a48 <g.3>
   6e357:      	movq	0x10(%rsp), %rcx
   6e35c:      	je	0x7085f <f.2+0x180af>
   6e362:      	movq	%rax, %r14
   6e365:      	addq	0x18(%rsp), %r14
   6e36a:      	cmpq	$0xf, %r12
   6e36e:      	je	0x6e408 <f.2+0x15c58>
   6e374:      	movq	$0x0, 0x48(%rsp)
   6e37d:      	movq	$0x3, 0x30(%rsp)
   6e386:      	xorl	%edi, %edi
   6e388:      	leaq	-0xf(%r12), %rsi
   6e38d:      	callq	0x70870 <f.3>
   6e392:      	subq	$0x8, %rsp
   6e396:      	cmpb	$0x0, 0x76b3(%rip)      # 0x75a50 <g.4>
   6e39d:      	je	0x7085f <f.2+0x180af>
   6e3a3:      	movq	%rax, 0x18(%rsp)
   6e3a8:      	cmpq	$0x0, 0x7698(%rip)      # 0x75a48 <g.3>
   6e3b0:      	je	0x7085f <f.2+0x180af>
   6e3b6:      	leaq	-0x10(%r12), %rsi
   6e3bb:      	movq	$0x0, 0x48(%rsp)
   6e3c4:      	movq	$0x3, 0x30(%rsp)
   6e3cd:      	xorl	%edi, %edi
   6e3cf:      	callq	0x70870 <f.3>
   6e3d4:      	subq	$0x8, %rsp
   6e3d8:      	cmpb	$0x0, 0x7671(%rip)      # 0x75a50 <g.4>
   6e3df:      	je	0x7085f <f.2+0x180af>
   6e3e5:      	addq	0x18(%rsp), %rax
   6e3ea:      	addq	%r14, %rax
   6e3ed:      	movq	0x10(%rsp), %rcx
   6e3f2:      	jmp	0x6e40d <f.2+0x15c5d>
   6e3f4:      	movl	$0x1, %r14d
   6e3fa:      	cmpq	$0x0, 0x7646(%rip)      # 0x75a48 <g.3>
   6e402:      	je	0x7085f <f.2+0x180af>
   6e408:      	leaq	-0xe(%r12,%r14), %rax
   6e40d:      	cmpq	$0x0, 0x7633(%rip)      # 0x75a48 <g.3>
   6e415:      	je	0x7085f <f.2+0x180af>
   6e41b:      	cmpq	$0xe, %r12
   6e41f:      	ja	0x6e42b <f.2+0x15c7b>
   6e421:      	leaq	-0xd(%r12,%rax), %r14
   6e426:      	jmp	0x6e583 <f.2+0x15dd3>
   6e42b:      	cmpq	$0xf, %r12
   6e42f:      	jne	0x6e449 <f.2+0x15c99>
   6e431:      	movl	$0x1, %edx
   6e436:      	cmpq	$0x0, 0x760a(%rip)      # 0x75a48 <g.3>
   6e43e:      	jne	0x6e4e6 <f.2+0x15d36>
   6e444:      	jmp	0x7085f <f.2+0x180af>
   6e449:      	movq	%rax, 0x18(%rsp)
   6e44e:      	movq	%rcx, 0x10(%rsp)
   6e453:      	leaq	-0xf(%r12), %rsi
   6e458:      	movq	$0x0, 0x48(%rsp)
   6e461:      	movq	$0x3, 0x30(%rsp)
   6e46a:      	xorl	%edi, %edi
   6e46c:      	callq	0x70870 <f.3>
   6e471:      	subq	$0x8, %rsp
   6e475:      	cmpb	$0x0, 0x75d4(%rip)      # 0x75a50 <g.4>
   6e47c:      	je	0x7085f <f.2+0x180af>
   6e482:      	cmpq	$0x0, 0x75be(%rip)      # 0x75a48 <g.3>
   6e48a:      	je	0x7085f <f.2+0x180af>
   6e490:      	movq	%rax, %r14
   6e493:      	leaq	-0x10(%r12), %rsi
   6e498:      	movq	$0x0, 0x48(%rsp)
   6e4a1:      	movq	$0x3, 0x30(%rsp)
   6e4aa:      	xorl	%edi, %edi
   6e4ac:      	callq	0x70870 <f.3>
   6e4b1:      	subq	$0x8, %rsp
   6e4b5:      	cmpb	$0x0, 0x7594(%rip)      # 0x75a50 <g.4>
   6e4bc:      	je	0x7085f <f.2+0x180af>
   6e4c2:      	movq	%rax, %rdx
   6e4c5:      	cmpq	$0x0, 0x757b(%rip)      # 0x75a48 <g.3>
   6e4cd:      	movq	0x10(%rsp), %rcx
   6e4d2:      	movq	0x18(%rsp), %rax
   6e4d7:      	je	0x7085f <f.2+0x180af>
   6e4dd:      	addq	%r14, %rdx
   6e4e0:      	cmpq	$0x10, %r12
   6e4e4:      	ja	0x6e4f0 <f.2+0x15d40>
   6e4e6:      	leaq	-0xf(%r12), %r14
   6e4eb:      	jmp	0x6e570 <f.2+0x15dc0>
   6e4f0:      	movq	%rdx, 0x50(%rsp)
   6e4f5:      	movq	$0x0, 0x48(%rsp)
   6e4fe:      	movq	$0x3, 0x30(%rsp)
   6e507:      	xorl	%edi, %edi
   6e509:      	leaq	-0x10(%r12), %rsi
   6e50e:      	callq	0x70870 <f.3>
   6e513:      	subq	$0x8, %rsp
   6e517:      	cmpb	$0x0, 0x7532(%rip)      # 0x75a50 <g.4>
   6e51e:      	je	0x7085f <f.2+0x180af>
   6e524:      	movq	%rax, 0x58(%rsp)
   6e529:      	cmpq	$0x0, 0x7517(%rip)      # 0x75a48 <g.3>
   6e531:      	je	0x7085f <f.2+0x180af>
   6e537:      	leaq	-0x11(%r12), %rsi
   6e53c:      	movq	$0x0, 0x48(%rsp)
   6e545:      	movq	$0x3, 0x30(%rsp)
   6e54e:      	xorl	%edi, %edi
   6e550:      	callq	0x70870 <f.3>
   6e555:      	subq	$0x8, %rsp
   6e559:      	movq	%rax, %r14
   6e55c:      	addq	0x58(%rsp), %r14
   6e561:      	movq	0x10(%rsp), %rcx
   6e566:      	movq	0x18(%rsp), %rax
   6e56b:      	movq	0x50(%rsp), %rdx
   6e570:      	cmpb	$0x0, 0x74d9(%rip)      # 0x75a50 <g.4>
   6e577:      	je	0x7085f <f.2+0x180af>
   6e57d:      	addq	%rdx, %r14
   6e580:      	addq	%rax, %r14
   6e583:      	cmpq	$0x0, 0x74bd(%rip)      # 0x75a48 <g.3>
   6e58b:      	je	0x7085f <f.2+0x180af>
   6e591:      	cmpq	$0xe, %r12
   6e595:      	je	0x6e5a7 <f.2+0x15df7>
   6e597:      	cmpq	$0xd, %r12
   6e59b:      	jne	0x6e5bf <f.2+0x15e0f>
   6e59d:      	leaq	-0xc(%r12,%r14), %rdx
   6e5a2:      	jmp	0x6e87a <f.2+0x160ca>
   6e5a7:      	movl	$0x1, %esi
   6e5ac:      	cmpq	$0x0, 0x7494(%rip)      # 0x75a48 <g.3>
   6e5b4:      	jne	0x6e717 <f.2+0x15f67>
   6e5ba:      	jmp	0x7085f <f.2+0x180af>
   6e5bf:      	cmpq	$0x10, %r12
   6e5c3:      	jb	0x6e6eb <f.2+0x15f3b>
   6e5c9:      	movq	%rcx, 0x10(%rsp)
   6e5ce:      	leaq	-0xf(%r12), %rsi
   6e5d3:      	movq	$0x0, 0x48(%rsp)
   6e5dc:      	movq	$0x3, 0x30(%rsp)
   6e5e5:      	xorl	%edi, %edi
   6e5e7:      	callq	0x70870 <f.3>
   6e5ec:      	subq	$0x8, %rsp
   6e5f0:      	cmpb	$0x0, 0x7459(%rip)      # 0x75a50 <g.4>
   6e5f7:      	je	0x7085f <f.2+0x180af>
   6e5fd:      	movq	%rax, 0x18(%rsp)
   6e602:      	cmpq	$0x0, 0x743e(%rip)      # 0x75a48 <g.3>
   6e60a:      	je	0x7085f <f.2+0x180af>
   6e610:      	leaq	-0x10(%r12), %rsi
   6e615:      	movq	$0x0, 0x48(%rsp)
   6e61e:      	movq	$0x3, 0x30(%rsp)
   6e627:      	xorl	%edi, %edi
   6e629:      	callq	0x70870 <f.3>
   6e62e:      	subq	$0x8, %rsp
   6e632:      	cmpb	$0x0, 0x7417(%rip)      # 0x75a50 <g.4>
   6e639:      	je	0x7085f <f.2+0x180af>
   6e63f:      	cmpq	$0x0, 0x7401(%rip)      # 0x75a48 <g.3>
   6e647:      	movq	0x10(%rsp), %rcx
   6e64c:      	je	0x7085f <f.2+0x180af>
   6e652:      	addq	0x18(%rsp), %rax
   6e657:      	cmpq	$0x10, %r12
   6e65b:      	je	0x6e6fe <f.2+0x15f4e>
   6e661:      	movq	%rax, 0x18(%rsp)
   6e666:      	movq	$0x0, 0x48(%rsp)
   6e66f:      	movq	$0x3, 0x30(%rsp)
   6e678:      	xorl	%edi, %edi
   6e67a:      	leaq	-0x10(%r12), %rsi
   6e67f:      	callq	0x70870 <f.3>
   6e684:      	subq	$0x8, %rsp
   6e688:      	cmpb	$0x0, 0x73c1(%rip)      # 0x75a50 <g.4>
   6e68f:      	je	0x7085f <f.2+0x180af>
   6e695:      	movq	%rax, 0x50(%rsp)
   6e69a:      	cmpq	$0x0, 0x73a6(%rip)      # 0x75a48 <g.3>
   6e6a2:      	je	0x7085f <f.2+0x180af>
   6e6a8:      	leaq	-0x11(%r12), %rsi
   6e6ad:      	movq	$0x0, 0x48(%rsp)
   6e6b6:      	movq	$0x3, 0x30(%rsp)
   6e6bf:      	xorl	%edi, %edi
   6e6c1:      	callq	0x70870 <f.3>
   6e6c6:      	subq	$0x8, %rsp
   6e6ca:      	cmpb	$0x0, 0x737f(%rip)      # 0x75a50 <g.4>
   6e6d1:      	je	0x7085f <f.2+0x180af>
   6e6d7:      	movq	%rax, %rsi
   6e6da:      	addq	0x50(%rsp), %rsi
   6e6df:      	addq	0x18(%rsp), %rsi
   6e6e4:      	movq	0x10(%rsp), %rcx
   6e6e9:      	jmp	0x6e703 <f.2+0x15f53>
   6e6eb:      	movl	$0x1, %eax
   6e6f0:      	cmpq	$0x0, 0x7350(%rip)      # 0x75a48 <g.3>
   6e6f8:      	je	0x7085f <f.2+0x180af>
   6e6fe:      	leaq	-0xf(%r12,%rax), %rsi
   6e703:      	cmpq	$0x0, 0x733d(%rip)      # 0x75a48 <g.3>
   6e70b:      	je	0x7085f <f.2+0x180af>
   6e711:      	cmpq	$0xf, %r12
   6e715:      	ja	0x6e721 <f.2+0x15f71>
   6e717:      	leaq	-0xe(%r12), %rdx
   6e71c:      	jmp	0x6e867 <f.2+0x160b7>
   6e721:      	cmpq	$0x10, %r12
   6e725:      	jne	0x6e73f <f.2+0x15f8f>
   6e727:      	movl	$0x1, %edx
   6e72c:      	cmpq	$0x0, 0x7314(%rip)      # 0x75a48 <g.3>
   6e734:      	jne	0x6e7e0 <f.2+0x16030>
   6e73a:      	jmp	0x7085f <f.2+0x180af>
   6e73f:      	movq	%rsi, 0x50(%rsp)
   6e744:      	movq	%rcx, 0x10(%rsp)
   6e749:      	leaq	-0x10(%r12), %rsi
   6e74e:      	movq	$0x0, 0x48(%rsp)
   6e757:      	movq	$0x3, 0x30(%rsp)
   6e760:      	xorl	%edi, %edi
   6e762:      	callq	0x70870 <f.3>
   6e767:      	subq	$0x8, %rsp
   6e76b:      	cmpb	$0x0, 0x72de(%rip)      # 0x75a50 <g.4>
   6e772:      	je	0x7085f <f.2+0x180af>
   6e778:      	movq	%rax, 0x18(%rsp)
   6e77d:      	cmpq	$0x0, 0x72c3(%rip)      # 0x75a48 <g.3>
   6e785:      	je	0x7085f <f.2+0x180af>
   6e78b:      	leaq	-0x11(%r12), %rsi
   6e790:      	movq	$0x0, 0x48(%rsp)
   6e799:      	movq	$0x3, 0x30(%rsp)
   6e7a2:      	xorl	%edi, %edi
   6e7a4:      	callq	0x70870 <f.3>
   6e7a9:      	subq	$0x8, %rsp
   6e7ad:      	cmpb	$0x0, 0x729c(%rip)      # 0x75a50 <g.4>
   6e7b4:      	je	0x7085f <f.2+0x180af>
   6e7ba:      	cmpq	$0x0, 0x7286(%rip)      # 0x75a48 <g.3>
   6e7c2:      	movq	0x10(%rsp), %rcx
   6e7c7:      	movq	0x50(%rsp), %rsi
   6e7cc:      	je	0x7085f <f.2+0x180af>
   6e7d2:      	movq	%rax, %rdx
   6e7d5:      	addq	0x18(%rsp), %rdx
   6e7da:      	cmpq	$0x11, %r12
   6e7de:      	ja	0x6e7e7 <f.2+0x16037>
   6e7e0:      	leaq	-0x10(%r12), %rax
   6e7e5:      	jmp	0x6e864 <f.2+0x160b4>
   6e7e7:      	movq	%rdx, 0x18(%rsp)
   6e7ec:      	movq	$0x0, 0x48(%rsp)
   6e7f5:      	movq	$0x3, 0x30(%rsp)
   6e7fe:      	xorl	%edi, %edi
   6e800:      	leaq	-0x11(%r12), %rsi
   6e805:      	callq	0x70870 <f.3>
   6e80a:      	subq	$0x8, %rsp
   6e80e:      	cmpb	$0x0, 0x723b(%rip)      # 0x75a50 <g.4>
   6e815:      	je	0x7085f <f.2+0x180af>
   6e81b:      	movq	%rax, 0x58(%rsp)
   6e820:      	cmpq	$0x0, 0x7220(%rip)      # 0x75a48 <g.3>
   6e828:      	je	0x7085f <f.2+0x180af>
   6e82e:      	leaq	-0x12(%r12), %rsi
   6e833:      	movq	$0x0, 0x48(%rsp)
   6e83c:      	movq	$0x3, 0x30(%rsp)
   6e845:      	xorl	%edi, %edi
   6e847:      	callq	0x70870 <f.3>
   6e84c:      	subq	$0x8, %rsp
   6e850:      	addq	0x58(%rsp), %rax
   6e855:      	movq	0x10(%rsp), %rcx
   6e85a:      	movq	0x18(%rsp), %rdx
   6e85f:      	movq	0x50(%rsp), %rsi
   6e864:      	addq	%rax, %rdx
   6e867:      	cmpb	$0x0, 0x71e2(%rip)      # 0x75a50 <g.4>
   6e86e:      	je	0x7085f <f.2+0x180af>
   6e874:      	addq	%rsi, %rdx
   6e877:      	addq	%r14, %rdx
   6e87a:      	cmpq	$0x0, 0x71c6(%rip)      # 0x75a48 <g.3>
   6e882:      	je	0x7085f <f.2+0x180af>
   6e888:      	cmpq	$0xc, %r12
   6e88c:      	ja	0x6e898 <f.2+0x160e8>
   6e88e:      	leaq	-0xb(%r12), %r14
   6e893:      	jmp	0x6eeae <f.2+0x166fe>
   6e898:      	cmpq	$0xd, %r12
   6e89c:      	jne	0x6e8b7 <f.2+0x16107>
   6e89e:      	movl	$0x1, %r14d
   6e8a4:      	cmpq	$0x0, 0x719c(%rip)      # 0x75a48 <g.3>
   6e8ac:      	jne	0x6ebb7 <f.2+0x16407>
   6e8b2:      	jmp	0x7085f <f.2+0x180af>
   6e8b7:      	cmpq	$0xf, %r12
   6e8bb:      	jb	0x6e8d8 <f.2+0x16128>
   6e8bd:      	jne	0x6e8f0 <f.2+0x16140>
   6e8bf:      	movl	$0x1, %r14d
   6e8c5:      	cmpq	$0x0, 0x717b(%rip)      # 0x75a48 <g.3>
   6e8cd:      	jne	0x6e991 <f.2+0x161e1>
   6e8d3:      	jmp	0x7085f <f.2+0x180af>
   6e8d8:      	movl	$0x1, %eax
   6e8dd:      	cmpq	$0x0, 0x7163(%rip)      # 0x75a48 <g.3>
   6e8e5:      	jne	0x6ea38 <f.2+0x16288>
   6e8eb:      	jmp	0x7085f <f.2+0x180af>
   6e8f0:      	movq	%rdx, 0x18(%rsp)
   6e8f5:      	movq	%rcx, 0x10(%rsp)
   6e8fa:      	leaq	-0xf(%r12), %rsi
   6e8ff:      	movq	$0x0, 0x48(%rsp)
   6e908:      	movq	$0x3, 0x30(%rsp)
   6e911:      	xorl	%edi, %edi
   6e913:      	callq	0x70870 <f.3>
   6e918:      	subq	$0x8, %rsp
   6e91c:      	cmpb	$0x0, 0x712d(%rip)      # 0x75a50 <g.4>
   6e923:      	je	0x7085f <f.2+0x180af>
   6e929:      	movq	%rax, 0x50(%rsp)
   6e92e:      	cmpq	$0x0, 0x7112(%rip)      # 0x75a48 <g.3>
   6e936:      	je	0x7085f <f.2+0x180af>
   6e93c:      	leaq	-0x10(%r12), %rsi
   6e941:      	movq	$0x0, 0x48(%rsp)
   6e94a:      	movq	$0x3, 0x30(%rsp)
   6e953:      	xorl	%edi, %edi
   6e955:      	callq	0x70870 <f.3>
   6e95a:      	subq	$0x8, %rsp
   6e95e:      	cmpb	$0x0, 0x70eb(%rip)      # 0x75a50 <g.4>
   6e965:      	je	0x7085f <f.2+0x180af>
   6e96b:      	cmpq	$0x0, 0x70d5(%rip)      # 0x75a48 <g.3>
   6e973:      	movq	0x10(%rsp), %rcx
   6e978:      	movq	0x18(%rsp), %rdx
   6e97d:      	je	0x7085f <f.2+0x180af>
   6e983:      	movq	%rax, %r14
   6e986:      	addq	0x50(%rsp), %r14
   6e98b:      	cmpq	$0x10, %r12
   6e98f:      	ja	0x6e99b <f.2+0x161eb>
   6e991:      	leaq	-0xf(%r12,%r14), %rax
   6e996:      	jmp	0x6ea1e <f.2+0x1626e>
   6e99b:      	movq	$0x0, 0x48(%rsp)
   6e9a4:      	movq	$0x3, 0x30(%rsp)
   6e9ad:      	xorl	%edi, %edi
   6e9af:      	leaq	-0x10(%r12), %rsi
   6e9b4:      	callq	0x70870 <f.3>
   6e9b9:      	subq	$0x8, %rsp
   6e9bd:      	cmpb	$0x0, 0x708c(%rip)      # 0x75a50 <g.4>
   6e9c4:      	je	0x7085f <f.2+0x180af>
   6e9ca:      	movq	%rax, 0x50(%rsp)
   6e9cf:      	cmpq	$0x0, 0x7071(%rip)      # 0x75a48 <g.3>
   6e9d7:      	je	0x7085f <f.2+0x180af>
   6e9dd:      	leaq	-0x11(%r12), %rsi
   6e9e2:      	movq	$0x0, 0x48(%rsp)
   6e9eb:      	movq	$0x3, 0x30(%rsp)
   6e9f4:      	xorl	%edi, %edi
   6e9f6:      	callq	0x70870 <f.3>
   6e9fb:      	subq	$0x8, %rsp
   6e9ff:      	cmpb	$0x0, 0x704a(%rip)      # 0x75a50 <g.4>
   6ea06:      	je	0x7085f <f.2+0x180af>
   6ea0c:      	addq	0x50(%rsp), %rax
   6ea11:      	addq	%r14, %rax
   6ea14:      	movq	0x10(%rsp), %rcx
   6ea19:      	movq	0x18(%rsp), %rdx
   6ea1e:      	cmpq	$0x0, 0x7022(%rip)      # 0x75a48 <g.3>
   6ea26:      	je	0x7085f <f.2+0x180af>
   6ea2c:      	cmpq	$0x10, %r12
   6ea30:      	je	0x6ea42 <f.2+0x16292>
   6ea32:      	cmpq	$0xf, %r12
   6ea36:      	jne	0x6ea5a <f.2+0x162aa>
   6ea38:      	leaq	-0xe(%r12,%rax), %r14
   6ea3d:      	jmp	0x6eba3 <f.2+0x163f3>
   6ea42:      	movl	$0x1, %esi
   6ea47:      	cmpq	$0x0, 0x6ff9(%rip)      # 0x75a48 <g.3>
   6ea4f:      	jne	0x6eb01 <f.2+0x16351>
   6ea55:      	jmp	0x7085f <f.2+0x180af>
   6ea5a:      	movq	%rax, 0x50(%rsp)
   6ea5f:      	movq	%rdx, 0x18(%rsp)
   6ea64:      	movq	%rcx, 0x10(%rsp)
   6ea69:      	leaq	-0x10(%r12), %rsi
   6ea6e:      	movq	$0x0, 0x48(%rsp)
   6ea77:      	movq	$0x3, 0x30(%rsp)
   6ea80:      	xorl	%edi, %edi
   6ea82:      	callq	0x70870 <f.3>
   6ea87:      	subq	$0x8, %rsp
   6ea8b:      	cmpb	$0x0, 0x6fbe(%rip)      # 0x75a50 <g.4>
   6ea92:      	je	0x7085f <f.2+0x180af>
   6ea98:      	cmpq	$0x0, 0x6fa8(%rip)      # 0x75a48 <g.3>
   6eaa0:      	je	0x7085f <f.2+0x180af>
   6eaa6:      	movq	%rax, %r14
   6eaa9:      	leaq	-0x11(%r12), %rsi
   6eaae:      	movq	$0x0, 0x48(%rsp)
   6eab7:      	movq	$0x3, 0x30(%rsp)
   6eac0:      	xorl	%edi, %edi
   6eac2:      	callq	0x70870 <f.3>
   6eac7:      	subq	$0x8, %rsp
   6eacb:      	cmpb	$0x0, 0x6f7e(%rip)      # 0x75a50 <g.4>
   6ead2:      	je	0x7085f <f.2+0x180af>
   6ead8:      	movq	%rax, %rsi
   6eadb:      	cmpq	$0x0, 0x6f65(%rip)      # 0x75a48 <g.3>
   6eae3:      	movq	0x10(%rsp), %rcx
   6eae8:      	movq	0x18(%rsp), %rdx
   6eaed:      	movq	0x50(%rsp), %rax
   6eaf2:      	je	0x7085f <f.2+0x180af>
   6eaf8:      	addq	%r14, %rsi
   6eafb:      	cmpq	$0x11, %r12
   6eaff:      	ja	0x6eb0b <f.2+0x1635b>
   6eb01:      	leaq	-0x10(%r12), %r14
   6eb06:      	jmp	0x6eb90 <f.2+0x163e0>
   6eb0b:      	movq	%rsi, 0x58(%rsp)
   6eb10:      	movq	$0x0, 0x48(%rsp)
   6eb19:      	movq	$0x3, 0x30(%rsp)
   6eb22:      	xorl	%edi, %edi
   6eb24:      	leaq	-0x11(%r12), %rsi
   6eb29:      	callq	0x70870 <f.3>
   6eb2e:      	subq	$0x8, %rsp
   6eb32:      	cmpb	$0x0, 0x6f17(%rip)      # 0x75a50 <g.4>
   6eb39:      	je	0x7085f <f.2+0x180af>
   6eb3f:      	movq	%rax, 0x60(%rsp)
   6eb44:      	cmpq	$0x0, 0x6efc(%rip)      # 0x75a48 <g.3>
   6eb4c:      	je	0x7085f <f.2+0x180af>
   6eb52:      	leaq	-0x12(%r12), %rsi
   6eb57:      	movq	$0x0, 0x48(%rsp)
   6eb60:      	movq	$0x3, 0x30(%rsp)
   6eb69:      	xorl	%edi, %edi
   6eb6b:      	callq	0x70870 <f.3>
   6eb70:      	subq	$0x8, %rsp
   6eb74:      	movq	%rax, %r14
   6eb77:      	addq	0x60(%rsp), %r14
   6eb7c:      	movq	0x10(%rsp), %rcx
   6eb81:      	movq	0x18(%rsp), %rdx
   6eb86:      	movq	0x50(%rsp), %rax
   6eb8b:      	movq	0x58(%rsp), %rsi
   6eb90:      	cmpb	$0x0, 0x6eb9(%rip)      # 0x75a50 <g.4>
   6eb97:      	je	0x7085f <f.2+0x180af>
   6eb9d:      	addq	%rsi, %r14
   6eba0:      	addq	%rax, %r14
   6eba3:      	cmpq	$0x0, 0x6e9d(%rip)      # 0x75a48 <g.3>
   6ebab:      	je	0x7085f <f.2+0x180af>
   6ebb1:      	cmpq	$0xe, %r12
   6ebb5:      	ja	0x6ebc1 <f.2+0x16411>
   6ebb7:      	leaq	-0xd(%r12), %rsi
   6ebbc:      	jmp	0x6eeab <f.2+0x166fb>
   6ebc1:      	cmpq	$0xf, %r12
   6ebc5:      	jne	0x6ebdf <f.2+0x1642f>
   6ebc7:      	movl	$0x1, %esi
   6ebcc:      	cmpq	$0x0, 0x6e74(%rip)      # 0x75a48 <g.3>
   6ebd4:      	jne	0x6ed46 <f.2+0x16596>
   6ebda:      	jmp	0x7085f <f.2+0x180af>
   6ebdf:      	cmpq	$0x11, %r12
   6ebe3:      	jb	0x6ed1a <f.2+0x1656a>
   6ebe9:      	movq	%rdx, 0x18(%rsp)
   6ebee:      	movq	%rcx, 0x10(%rsp)
   6ebf3:      	leaq	-0x10(%r12), %rsi
   6ebf8:      	movq	$0x0, 0x48(%rsp)
   6ec01:      	movq	$0x3, 0x30(%rsp)
   6ec0a:      	xorl	%edi, %edi
   6ec0c:      	callq	0x70870 <f.3>
   6ec11:      	subq	$0x8, %rsp
   6ec15:      	cmpb	$0x0, 0x6e34(%rip)      # 0x75a50 <g.4>
   6ec1c:      	je	0x7085f <f.2+0x180af>
   6ec22:      	movq	%rax, 0x50(%rsp)
   6ec27:      	cmpq	$0x0, 0x6e19(%rip)      # 0x75a48 <g.3>
   6ec2f:      	je	0x7085f <f.2+0x180af>
   6ec35:      	leaq	-0x11(%r12), %rsi
   6ec3a:      	movq	$0x0, 0x48(%rsp)
   6ec43:      	movq	$0x3, 0x30(%rsp)
   6ec4c:      	xorl	%edi, %edi
   6ec4e:      	callq	0x70870 <f.3>
   6ec53:      	subq	$0x8, %rsp
   6ec57:      	cmpb	$0x0, 0x6df2(%rip)      # 0x75a50 <g.4>
   6ec5e:      	je	0x7085f <f.2+0x180af>
   6ec64:      	cmpq	$0x0, 0x6ddc(%rip)      # 0x75a48 <g.3>
   6ec6c:      	movq	0x10(%rsp), %rcx
   6ec71:      	movq	0x18(%rsp), %rdx
   6ec76:      	je	0x7085f <f.2+0x180af>
   6ec7c:      	addq	0x50(%rsp), %rax
   6ec81:      	cmpq	$0x11, %r12
   6ec85:      	je	0x6ed2d <f.2+0x1657d>
   6ec8b:      	movq	%rax, 0x50(%rsp)
   6ec90:      	movq	$0x0, 0x48(%rsp)
   6ec99:      	movq	$0x3, 0x30(%rsp)
   6eca2:      	xorl	%edi, %edi
   6eca4:      	leaq	-0x11(%r12), %rsi
   6eca9:      	callq	0x70870 <f.3>
   6ecae:      	subq	$0x8, %rsp
   6ecb2:      	cmpb	$0x0, 0x6d97(%rip)      # 0x75a50 <g.4>
   6ecb9:      	je	0x7085f <f.2+0x180af>
   6ecbf:      	movq	%rax, 0x58(%rsp)
   6ecc4:      	cmpq	$0x0, 0x6d7c(%rip)      # 0x75a48 <g.3>
   6eccc:      	je	0x7085f <f.2+0x180af>
   6ecd2:      	leaq	-0x12(%r12), %rsi
   6ecd7:      	movq	$0x0, 0x48(%rsp)
   6ece0:      	movq	$0x3, 0x30(%rsp)
   6ece9:      	xorl	%edi, %edi
   6eceb:      	callq	0x70870 <f.3>
   6ecf0:      	subq	$0x8, %rsp
   6ecf4:      	cmpb	$0x0, 0x6d55(%rip)      # 0x75a50 <g.4>
   6ecfb:      	je	0x7085f <f.2+0x180af>
   6ed01:      	movq	%rax, %rsi
   6ed04:      	addq	0x58(%rsp), %rsi
   6ed09:      	addq	0x50(%rsp), %rsi
   6ed0e:      	movq	0x10(%rsp), %rcx
   6ed13:      	movq	0x18(%rsp), %rdx
   6ed18:      	jmp	0x6ed32 <f.2+0x16582>
   6ed1a:      	movl	$0x1, %eax
   6ed1f:      	cmpq	$0x0, 0x6d21(%rip)      # 0x75a48 <g.3>
   6ed27:      	je	0x7085f <f.2+0x180af>
   6ed2d:      	leaq	-0x10(%r12,%rax), %rsi
   6ed32:      	cmpq	$0x0, 0x6d0e(%rip)      # 0x75a48 <g.3>
   6ed3a:      	je	0x7085f <f.2+0x180af>
   6ed40:      	cmpq	$0x10, %r12
   6ed44:      	ja	0x6ed50 <f.2+0x165a0>
   6ed46:      	leaq	-0xf(%r12), %rdi
   6ed4b:      	jmp	0x6eea8 <f.2+0x166f8>
   6ed50:      	cmpq	$0x11, %r12
   6ed54:      	jne	0x6ed6e <f.2+0x165be>
   6ed56:      	movl	$0x1, %edi
   6ed5b:      	cmpq	$0x0, 0x6ce5(%rip)      # 0x75a48 <g.3>
   6ed63:      	jne	0x6ee19 <f.2+0x16669>
   6ed69:      	jmp	0x7085f <f.2+0x180af>
   6ed6e:      	movq	%rsi, 0x50(%rsp)
   6ed73:      	movq	%rdx, 0x18(%rsp)
   6ed78:      	movq	%rcx, 0x10(%rsp)
   6ed7d:      	leaq	-0x11(%r12), %rsi
   6ed82:      	movq	$0x0, 0x48(%rsp)
   6ed8b:      	movq	$0x3, 0x30(%rsp)
   6ed94:      	xorl	%edi, %edi
   6ed96:      	callq	0x70870 <f.3>
   6ed9b:      	subq	$0x8, %rsp
   6ed9f:      	cmpb	$0x0, 0x6caa(%rip)      # 0x75a50 <g.4>
   6eda6:      	je	0x7085f <f.2+0x180af>
   6edac:      	movq	%rax, 0x58(%rsp)
   6edb1:      	cmpq	$0x0, 0x6c8f(%rip)      # 0x75a48 <g.3>
   6edb9:      	je	0x7085f <f.2+0x180af>
   6edbf:      	leaq	-0x12(%r12), %rsi
   6edc4:      	movq	$0x0, 0x48(%rsp)
   6edcd:      	movq	$0x3, 0x30(%rsp)
   6edd6:      	xorl	%edi, %edi
   6edd8:      	callq	0x70870 <f.3>
   6eddd:      	subq	$0x8, %rsp
   6ede1:      	cmpb	$0x0, 0x6c68(%rip)      # 0x75a50 <g.4>
   6ede8:      	je	0x7085f <f.2+0x180af>
   6edee:      	cmpq	$0x0, 0x6c52(%rip)      # 0x75a48 <g.3>
   6edf6:      	movq	0x10(%rsp), %rcx
   6edfb:      	movq	0x18(%rsp), %rdx
   6ee00:      	movq	0x50(%rsp), %rsi
   6ee05:      	je	0x7085f <f.2+0x180af>
   6ee0b:      	movq	%rax, %rdi
   6ee0e:      	addq	0x58(%rsp), %rdi
   6ee13:      	cmpq	$0x12, %r12
   6ee17:      	ja	0x6ee23 <f.2+0x16673>
   6ee19:      	leaq	-0x11(%r12), %rax
   6ee1e:      	jmp	0x6eea5 <f.2+0x166f5>
   6ee23:      	movq	%rdi, 0x58(%rsp)
   6ee28:      	movq	$0x0, 0x48(%rsp)
   6ee31:      	movq	$0x3, 0x30(%rsp)
   6ee3a:      	xorl	%edi, %edi
   6ee3c:      	leaq	-0x12(%r12), %rsi
   6ee41:      	callq	0x70870 <f.3>
   6ee46:      	subq	$0x8, %rsp
   6ee4a:      	movq	%rax, 0x60(%rsp)
   6ee4f:      	cmpb	$0x0, 0x6bfa(%rip)      # 0x75a50 <g.4>
   6ee56:      	je	0x7085f <f.2+0x180af>
   6ee5c:      	cmpq	$0x0, 0x6be4(%rip)      # 0x75a48 <g.3>
   6ee64:      	je	0x7085f <f.2+0x180af>
   6ee6a:      	leaq	-0x13(%r12), %rsi
   6ee6f:      	movq	$0x0, 0x48(%rsp)
   6ee78:      	movq	$0x3, 0x30(%rsp)
   6ee81:      	xorl	%edi, %edi
   6ee83:      	callq	0x70870 <f.3>
   6ee88:      	subq	$0x8, %rsp
   6ee8c:      	addq	0x60(%rsp), %rax
   6ee91:      	movq	0x10(%rsp), %rcx
   6ee96:      	movq	0x18(%rsp), %rdx
   6ee9b:      	movq	0x50(%rsp), %rsi
   6eea0:      	movq	0x58(%rsp), %rdi
   6eea5:      	addq	%rax, %rdi
   6eea8:      	addq	%rdi, %rsi
   6eeab:      	addq	%rsi, %r14
   6eeae:      	cmpb	$0x0, 0x6b9b(%rip)      # 0x75a50 <g.4>
   6eeb5:      	je	0x7085f <f.2+0x180af>
   6eebb:      	addq	%rdx, %r14
   6eebe:      	addq	%r15, %r14
   6eec1:      	cmpq	$0x0, 0x6b7f(%rip)      # 0x75a48 <g.3>
   6eec9:      	leaq	0x68(%rsp), %r15
   6eece:      	je	0x7085f <f.2+0x180af>
   6eed4:      	cmpq	$0x9, %r12
   6eed8:      	ja	0x6eee3 <f.2+0x16733>
   6eeda:      	addq	$-0x8, %r12
   6eede:      	jmp	0x707e1 <f.2+0x18031>
   6eee3:      	cmpq	$0xa, %r12
   6eee7:      	jne	0x6ef02 <f.2+0x16752>
   6eee9:      	movl	$0x1, %r15d
   6eeef:      	cmpq	$0x0, 0x6b51(%rip)      # 0x75a48 <g.3>
   6eef7:      	jne	0x6fb58 <f.2+0x173a8>
   6eefd:      	jmp	0x7085f <f.2+0x180af>
   6ef02:      	cmpq	$0xc, %r12
   6ef06:      	jb	0x6ef23 <f.2+0x16773>
   6ef08:      	jne	0x6ef3b <f.2+0x1678b>
   6ef0a:      	movl	$0x1, %r15d
   6ef10:      	cmpq	$0x0, 0x6b30(%rip)      # 0x75a48 <g.3>
   6ef18:      	jne	0x6f21a <f.2+0x16a6a>
   6ef1e:      	jmp	0x7085f <f.2+0x180af>
   6ef23:      	movl	$0x1, %edx
   6ef28:      	cmpq	$0x0, 0x6b18(%rip)      # 0x75a48 <g.3>
   6ef30:      	jne	0x6f517 <f.2+0x16d67>
   6ef36:      	jmp	0x7085f <f.2+0x180af>
   6ef3b:      	cmpq	$0xe, %r12
   6ef3f:      	jb	0x6ef5c <f.2+0x167ac>
   6ef41:      	jne	0x6ef74 <f.2+0x167c4>
   6ef43:      	movl	$0x1, %r15d
   6ef49:      	cmpq	$0x0, 0x6af7(%rip)      # 0x75a48 <g.3>
   6ef51:      	jne	0x6f00b <f.2+0x1685b>
   6ef57:      	jmp	0x7085f <f.2+0x180af>
   6ef5c:      	movl	$0x1, %eax
   6ef61:      	cmpq	$0x0, 0x6adf(%rip)      # 0x75a48 <g.3>
   6ef69:      	jne	0x6f0aa <f.2+0x168fa>
   6ef6f:      	jmp	0x7085f <f.2+0x180af>
   6ef74:      	movq	%rcx, 0x10(%rsp)
   6ef79:      	leaq	-0xe(%r12), %rsi
   6ef7e:      	movq	$0x0, 0x48(%rsp)
   6ef87:      	movq	$0x3, 0x30(%rsp)
   6ef90:      	xorl	%edi, %edi
   6ef92:      	callq	0x70870 <f.3>
   6ef97:      	subq	$0x8, %rsp
   6ef9b:      	cmpb	$0x0, 0x6aae(%rip)      # 0x75a50 <g.4>
   6efa2:      	je	0x7085f <f.2+0x180af>
   6efa8:      	movq	%rax, 0x18(%rsp)
   6efad:      	cmpq	$0x0, 0x6a93(%rip)      # 0x75a48 <g.3>
   6efb5:      	je	0x7085f <f.2+0x180af>
   6efbb:      	leaq	-0xf(%r12), %rsi
   6efc0:      	movq	$0x0, 0x48(%rsp)
   6efc9:      	movq	$0x3, 0x30(%rsp)
   6efd2:      	xorl	%edi, %edi
   6efd4:      	callq	0x70870 <f.3>
   6efd9:      	subq	$0x8, %rsp
   6efdd:      	cmpb	$0x0, 0x6a6c(%rip)      # 0x75a50 <g.4>
   6efe4:      	je	0x7085f <f.2+0x180af>
   6efea:      	cmpq	$0x0, 0x6a56(%rip)      # 0x75a48 <g.3>
   6eff2:      	movq	0x10(%rsp), %rcx
   6eff7:      	je	0x7085f <f.2+0x180af>
   6effd:      	movq	%rax, %r15
   6f000:      	addq	0x18(%rsp), %r15
   6f005:      	cmpq	$0xf, %r12
   6f009:      	ja	0x6f012 <f.2+0x16862>
   6f00b:      	leaq	-0xe(%r12,%r15), %rax
   6f010:      	jmp	0x6f090 <f.2+0x168e0>
   6f012:      	movq	$0x0, 0x48(%rsp)
   6f01b:      	movq	$0x3, 0x30(%rsp)
   6f024:      	xorl	%edi, %edi
   6f026:      	leaq	-0xf(%r12), %rsi
   6f02b:      	callq	0x70870 <f.3>
   6f030:      	subq	$0x8, %rsp
   6f034:      	cmpb	$0x0, 0x6a15(%rip)      # 0x75a50 <g.4>
   6f03b:      	je	0x7085f <f.2+0x180af>
   6f041:      	movq	%rax, 0x18(%rsp)
   6f046:      	cmpq	$0x0, 0x69fa(%rip)      # 0x75a48 <g.3>
   6f04e:      	je	0x7085f <f.2+0x180af>
   6f054:      	leaq	-0x10(%r12), %rsi
   6f059:      	movq	$0x0, 0x48(%rsp)
   6f062:      	movq	$0x3, 0x30(%rsp)
   6f06b:      	xorl	%edi, %edi
   6f06d:      	callq	0x70870 <f.3>
   6f072:      	subq	$0x8, %rsp
   6f076:      	cmpb	$0x0, 0x69d3(%rip)      # 0x75a50 <g.4>
   6f07d:      	je	0x7085f <f.2+0x180af>
   6f083:      	addq	0x18(%rsp), %rax
   6f088:      	addq	%r15, %rax
   6f08b:      	movq	0x10(%rsp), %rcx
   6f090:      	cmpq	$0x0, 0x69b0(%rip)      # 0x75a48 <g.3>
   6f098:      	je	0x7085f <f.2+0x180af>
   6f09e:      	cmpq	$0xf, %r12
   6f0a2:      	je	0x6f0b4 <f.2+0x16904>
   6f0a4:      	cmpq	$0xe, %r12
   6f0a8:      	jne	0x6f0cc <f.2+0x1691c>
   6f0aa:      	leaq	-0xd(%r12,%rax), %r15
   6f0af:      	jmp	0x6f206 <f.2+0x16a56>
   6f0b4:      	movl	$0x1, %edx
   6f0b9:      	cmpq	$0x0, 0x6987(%rip)      # 0x75a48 <g.3>
   6f0c1:      	jne	0x6f169 <f.2+0x169b9>
   6f0c7:      	jmp	0x7085f <f.2+0x180af>
   6f0cc:      	movq	%rax, 0x18(%rsp)
   6f0d1:      	movq	%rcx, 0x10(%rsp)
   6f0d6:      	leaq	-0xf(%r12), %rsi
   6f0db:      	movq	$0x0, 0x48(%rsp)
   6f0e4:      	movq	$0x3, 0x30(%rsp)
   6f0ed:      	xorl	%edi, %edi
   6f0ef:      	callq	0x70870 <f.3>
   6f0f4:      	subq	$0x8, %rsp
   6f0f8:      	cmpb	$0x0, 0x6951(%rip)      # 0x75a50 <g.4>
   6f0ff:      	je	0x7085f <f.2+0x180af>
   6f105:      	cmpq	$0x0, 0x693b(%rip)      # 0x75a48 <g.3>
   6f10d:      	je	0x7085f <f.2+0x180af>
   6f113:      	movq	%rax, %r15
   6f116:      	leaq	-0x10(%r12), %rsi
   6f11b:      	movq	$0x0, 0x48(%rsp)
   6f124:      	movq	$0x3, 0x30(%rsp)
   6f12d:      	xorl	%edi, %edi
   6f12f:      	callq	0x70870 <f.3>
   6f134:      	subq	$0x8, %rsp
   6f138:      	cmpb	$0x0, 0x6911(%rip)      # 0x75a50 <g.4>
   6f13f:      	je	0x7085f <f.2+0x180af>
   6f145:      	movq	%rax, %rdx
   6f148:      	cmpq	$0x0, 0x68f8(%rip)      # 0x75a48 <g.3>
   6f150:      	movq	0x10(%rsp), %rcx
   6f155:      	movq	0x18(%rsp), %rax
   6f15a:      	je	0x7085f <f.2+0x180af>
   6f160:      	addq	%r15, %rdx
   6f163:      	cmpq	$0x10, %r12
   6f167:      	ja	0x6f173 <f.2+0x169c3>
   6f169:      	leaq	-0xf(%r12), %r15
   6f16e:      	jmp	0x6f1f3 <f.2+0x16a43>
   6f173:      	movq	%rdx, 0x50(%rsp)
   6f178:      	movq	$0x0, 0x48(%rsp)
   6f181:      	movq	$0x3, 0x30(%rsp)
   6f18a:      	xorl	%edi, %edi
   6f18c:      	leaq	-0x10(%r12), %rsi
   6f191:      	callq	0x70870 <f.3>
   6f196:      	subq	$0x8, %rsp
   6f19a:      	cmpb	$0x0, 0x68af(%rip)      # 0x75a50 <g.4>
   6f1a1:      	je	0x7085f <f.2+0x180af>
   6f1a7:      	movq	%rax, 0x58(%rsp)
   6f1ac:      	cmpq	$0x0, 0x6894(%rip)      # 0x75a48 <g.3>
   6f1b4:      	je	0x7085f <f.2+0x180af>
   6f1ba:      	leaq	-0x11(%r12), %rsi
   6f1bf:      	movq	$0x0, 0x48(%rsp)
   6f1c8:      	movq	$0x3, 0x30(%rsp)
   6f1d1:      	xorl	%edi, %edi
   6f1d3:      	callq	0x70870 <f.3>
   6f1d8:      	subq	$0x8, %rsp
   6f1dc:      	movq	%rax, %r15
   6f1df:      	addq	0x58(%rsp), %r15
   6f1e4:      	movq	0x10(%rsp), %rcx
   6f1e9:      	movq	0x18(%rsp), %rax
   6f1ee:      	movq	0x50(%rsp), %rdx
   6f1f3:      	cmpb	$0x0, 0x6856(%rip)      # 0x75a50 <g.4>
   6f1fa:      	je	0x7085f <f.2+0x180af>
   6f200:      	addq	%rdx, %r15
   6f203:      	addq	%rax, %r15
   6f206:      	cmpq	$0x0, 0x683a(%rip)      # 0x75a48 <g.3>
   6f20e:      	je	0x7085f <f.2+0x180af>
   6f214:      	cmpq	$0xd, %r12
   6f218:      	ja	0x6f224 <f.2+0x16a74>
   6f21a:      	leaq	-0xc(%r12,%r15), %rdx
   6f21f:      	jmp	0x6f4fd <f.2+0x16d4d>
   6f224:      	cmpq	$0xe, %r12
   6f228:      	jne	0x6f242 <f.2+0x16a92>
   6f22a:      	movl	$0x1, %esi
   6f22f:      	cmpq	$0x0, 0x6811(%rip)      # 0x75a48 <g.3>
   6f237:      	jne	0x6f39a <f.2+0x16bea>
   6f23d:      	jmp	0x7085f <f.2+0x180af>
   6f242:      	cmpq	$0x10, %r12
   6f246:      	jb	0x6f36e <f.2+0x16bbe>
   6f24c:      	movq	%rcx, 0x10(%rsp)
   6f251:      	leaq	-0xf(%r12), %rsi
   6f256:      	movq	$0x0, 0x48(%rsp)
   6f25f:      	movq	$0x3, 0x30(%rsp)
   6f268:      	xorl	%edi, %edi
   6f26a:      	callq	0x70870 <f.3>
   6f26f:      	subq	$0x8, %rsp
   6f273:      	cmpb	$0x0, 0x67d6(%rip)      # 0x75a50 <g.4>
   6f27a:      	je	0x7085f <f.2+0x180af>
   6f280:      	movq	%rax, 0x18(%rsp)
   6f285:      	cmpq	$0x0, 0x67bb(%rip)      # 0x75a48 <g.3>
   6f28d:      	je	0x7085f <f.2+0x180af>
   6f293:      	leaq	-0x10(%r12), %rsi
   6f298:      	movq	$0x0, 0x48(%rsp)
   6f2a1:      	movq	$0x3, 0x30(%rsp)
   6f2aa:      	xorl	%edi, %edi
   6f2ac:      	callq	0x70870 <f.3>
   6f2b1:      	subq	$0x8, %rsp
   6f2b5:      	cmpb	$0x0, 0x6794(%rip)      # 0x75a50 <g.4>
   6f2bc:      	je	0x7085f <f.2+0x180af>
   6f2c2:      	cmpq	$0x0, 0x677e(%rip)      # 0x75a48 <g.3>
   6f2ca:      	movq	0x10(%rsp), %rcx
   6f2cf:      	je	0x7085f <f.2+0x180af>
   6f2d5:      	addq	0x18(%rsp), %rax
   6f2da:      	cmpq	$0x10, %r12
   6f2de:      	je	0x6f381 <f.2+0x16bd1>
   6f2e4:      	movq	%rax, 0x18(%rsp)
   6f2e9:      	movq	$0x0, 0x48(%rsp)
   6f2f2:      	movq	$0x3, 0x30(%rsp)
   6f2fb:      	xorl	%edi, %edi
   6f2fd:      	leaq	-0x10(%r12), %rsi
   6f302:      	callq	0x70870 <f.3>
   6f307:      	subq	$0x8, %rsp
   6f30b:      	cmpb	$0x0, 0x673e(%rip)      # 0x75a50 <g.4>
   6f312:      	je	0x7085f <f.2+0x180af>
   6f318:      	movq	%rax, 0x50(%rsp)
   6f31d:      	cmpq	$0x0, 0x6723(%rip)      # 0x75a48 <g.3>
   6f325:      	je	0x7085f <f.2+0x180af>
   6f32b:      	leaq	-0x11(%r12), %rsi
   6f330:      	movq	$0x0, 0x48(%rsp)
   6f339:      	movq	$0x3, 0x30(%rsp)
   6f342:      	xorl	%edi, %edi
   6f344:      	callq	0x70870 <f.3>
   6f349:      	subq	$0x8, %rsp
   6f34d:      	cmpb	$0x0, 0x66fc(%rip)      # 0x75a50 <g.4>
   6f354:      	je	0x7085f <f.2+0x180af>
   6f35a:      	movq	%rax, %rsi
   6f35d:      	addq	0x50(%rsp), %rsi
   6f362:      	addq	0x18(%rsp), %rsi
   6f367:      	movq	0x10(%rsp), %rcx
   6f36c:      	jmp	0x6f386 <f.2+0x16bd6>
   6f36e:      	movl	$0x1, %eax
   6f373:      	cmpq	$0x0, 0x66cd(%rip)      # 0x75a48 <g.3>
   6f37b:      	je	0x7085f <f.2+0x180af>
   6f381:      	leaq	-0xf(%r12,%rax), %rsi
   6f386:      	cmpq	$0x0, 0x66ba(%rip)      # 0x75a48 <g.3>
   6f38e:      	je	0x7085f <f.2+0x180af>
   6f394:      	cmpq	$0xf, %r12
   6f398:      	ja	0x6f3a4 <f.2+0x16bf4>
   6f39a:      	leaq	-0xe(%r12), %rdx
   6f39f:      	jmp	0x6f4ea <f.2+0x16d3a>
   6f3a4:      	cmpq	$0x10, %r12
   6f3a8:      	jne	0x6f3c2 <f.2+0x16c12>
   6f3aa:      	movl	$0x1, %edx
   6f3af:      	cmpq	$0x0, 0x6691(%rip)      # 0x75a48 <g.3>
   6f3b7:      	jne	0x6f463 <f.2+0x16cb3>
   6f3bd:      	jmp	0x7085f <f.2+0x180af>
   6f3c2:      	movq	%rsi, 0x50(%rsp)
   6f3c7:      	movq	%rcx, 0x10(%rsp)
   6f3cc:      	leaq	-0x10(%r12), %rsi
   6f3d1:      	movq	$0x0, 0x48(%rsp)
   6f3da:      	movq	$0x3, 0x30(%rsp)
   6f3e3:      	xorl	%edi, %edi
   6f3e5:      	callq	0x70870 <f.3>
   6f3ea:      	subq	$0x8, %rsp
   6f3ee:      	cmpb	$0x0, 0x665b(%rip)      # 0x75a50 <g.4>
   6f3f5:      	je	0x7085f <f.2+0x180af>
   6f3fb:      	movq	%rax, 0x18(%rsp)
   6f400:      	cmpq	$0x0, 0x6640(%rip)      # 0x75a48 <g.3>
   6f408:      	je	0x7085f <f.2+0x180af>
   6f40e:      	leaq	-0x11(%r12), %rsi
   6f413:      	movq	$0x0, 0x48(%rsp)
   6f41c:      	movq	$0x3, 0x30(%rsp)
   6f425:      	xorl	%edi, %edi
   6f427:      	callq	0x70870 <f.3>
   6f42c:      	subq	$0x8, %rsp
   6f430:      	cmpb	$0x0, 0x6619(%rip)      # 0x75a50 <g.4>
   6f437:      	je	0x7085f <f.2+0x180af>
   6f43d:      	cmpq	$0x0, 0x6603(%rip)      # 0x75a48 <g.3>
   6f445:      	movq	0x10(%rsp), %rcx
   6f44a:      	movq	0x50(%rsp), %rsi
   6f44f:      	je	0x7085f <f.2+0x180af>
   6f455:      	movq	%rax, %rdx
   6f458:      	addq	0x18(%rsp), %rdx
   6f45d:      	cmpq	$0x11, %r12
   6f461:      	ja	0x6f46a <f.2+0x16cba>
   6f463:      	leaq	-0x10(%r12), %rax
   6f468:      	jmp	0x6f4e7 <f.2+0x16d37>
   6f46a:      	movq	%rdx, 0x18(%rsp)
   6f46f:      	movq	$0x0, 0x48(%rsp)
   6f478:      	movq	$0x3, 0x30(%rsp)
   6f481:      	xorl	%edi, %edi
   6f483:      	leaq	-0x11(%r12), %rsi
   6f488:      	callq	0x70870 <f.3>
   6f48d:      	subq	$0x8, %rsp
   6f491:      	movq	%rax, 0x58(%rsp)
   6f496:      	cmpb	$0x0, 0x65b3(%rip)      # 0x75a50 <g.4>
   6f49d:      	je	0x7085f <f.2+0x180af>
   6f4a3:      	cmpq	$0x0, 0x659d(%rip)      # 0x75a48 <g.3>
   6f4ab:      	je	0x7085f <f.2+0x180af>
   6f4b1:      	leaq	-0x12(%r12), %rsi
   6f4b6:      	movq	$0x0, 0x48(%rsp)
   6f4bf:      	movq	$0x3, 0x30(%rsp)
   6f4c8:      	xorl	%edi, %edi
   6f4ca:      	callq	0x70870 <f.3>
   6f4cf:      	subq	$0x8, %rsp
   6f4d3:      	addq	0x58(%rsp), %rax
   6f4d8:      	movq	0x10(%rsp), %rcx
   6f4dd:      	movq	0x18(%rsp), %rdx
   6f4e2:      	movq	0x50(%rsp), %rsi
   6f4e7:      	addq	%rax, %rdx
   6f4ea:      	cmpb	$0x0, 0x655f(%rip)      # 0x75a50 <g.4>
   6f4f1:      	je	0x7085f <f.2+0x180af>
   6f4f7:      	addq	%rsi, %rdx
   6f4fa:      	addq	%r15, %rdx
   6f4fd:      	cmpq	$0x0, 0x6543(%rip)      # 0x75a48 <g.3>
   6f505:      	je	0x7085f <f.2+0x180af>
   6f50b:      	cmpq	$0xd, %r12
   6f50f:      	je	0x6f521 <f.2+0x16d71>
   6f511:      	cmpq	$0xc, %r12
   6f515:      	jne	0x6f53a <f.2+0x16d8a>
   6f517:      	leaq	-0xb(%r12), %r15
   6f51c:      	jmp	0x6fb34 <f.2+0x17384>
   6f521:      	movl	$0x1, %r15d
   6f527:      	cmpq	$0x0, 0x6519(%rip)      # 0x75a48 <g.3>
   6f52f:      	jne	0x6f83a <f.2+0x1708a>
   6f535:      	jmp	0x7085f <f.2+0x180af>
   6f53a:      	cmpq	$0xf, %r12
   6f53e:      	jb	0x6f55b <f.2+0x16dab>
   6f540:      	jne	0x6f573 <f.2+0x16dc3>
   6f542:      	movl	$0x1, %r15d
   6f548:      	cmpq	$0x0, 0x64f8(%rip)      # 0x75a48 <g.3>
   6f550:      	jne	0x6f614 <f.2+0x16e64>
   6f556:      	jmp	0x7085f <f.2+0x180af>
   6f55b:      	movl	$0x1, %eax
   6f560:      	cmpq	$0x0, 0x64e0(%rip)      # 0x75a48 <g.3>
   6f568:      	jne	0x6f6bb <f.2+0x16f0b>
   6f56e:      	jmp	0x7085f <f.2+0x180af>
   6f573:      	movq	%rdx, 0x18(%rsp)
   6f578:      	movq	%rcx, 0x10(%rsp)
   6f57d:      	leaq	-0xf(%r12), %rsi
   6f582:      	movq	$0x0, 0x48(%rsp)
   6f58b:      	movq	$0x3, 0x30(%rsp)
   6f594:      	xorl	%edi, %edi
   6f596:      	callq	0x70870 <f.3>
   6f59b:      	subq	$0x8, %rsp
   6f59f:      	cmpb	$0x0, 0x64aa(%rip)      # 0x75a50 <g.4>
   6f5a6:      	je	0x7085f <f.2+0x180af>
   6f5ac:      	movq	%rax, 0x50(%rsp)
   6f5b1:      	cmpq	$0x0, 0x648f(%rip)      # 0x75a48 <g.3>
   6f5b9:      	je	0x7085f <f.2+0x180af>
   6f5bf:      	leaq	-0x10(%r12), %rsi
   6f5c4:      	movq	$0x0, 0x48(%rsp)
   6f5cd:      	movq	$0x3, 0x30(%rsp)
   6f5d6:      	xorl	%edi, %edi
   6f5d8:      	callq	0x70870 <f.3>
   6f5dd:      	subq	$0x8, %rsp
   6f5e1:      	cmpb	$0x0, 0x6468(%rip)      # 0x75a50 <g.4>
   6f5e8:      	je	0x7085f <f.2+0x180af>
   6f5ee:      	cmpq	$0x0, 0x6452(%rip)      # 0x75a48 <g.3>
   6f5f6:      	movq	0x10(%rsp), %rcx
   6f5fb:      	movq	0x18(%rsp), %rdx
   6f600:      	je	0x7085f <f.2+0x180af>
   6f606:      	movq	%rax, %r15
   6f609:      	addq	0x50(%rsp), %r15
   6f60e:      	cmpq	$0x10, %r12
   6f612:      	ja	0x6f61e <f.2+0x16e6e>
   6f614:      	leaq	-0xf(%r12,%r15), %rax
   6f619:      	jmp	0x6f6a1 <f.2+0x16ef1>
   6f61e:      	movq	$0x0, 0x48(%rsp)
   6f627:      	movq	$0x3, 0x30(%rsp)
   6f630:      	xorl	%edi, %edi
   6f632:      	leaq	-0x10(%r12), %rsi
   6f637:      	callq	0x70870 <f.3>
   6f63c:      	subq	$0x8, %rsp
   6f640:      	cmpb	$0x0, 0x6409(%rip)      # 0x75a50 <g.4>
   6f647:      	je	0x7085f <f.2+0x180af>
   6f64d:      	movq	%rax, 0x50(%rsp)
   6f652:      	cmpq	$0x0, 0x63ee(%rip)      # 0x75a48 <g.3>
   6f65a:      	je	0x7085f <f.2+0x180af>
   6f660:      	leaq	-0x11(%r12), %rsi
   6f665:      	movq	$0x0, 0x48(%rsp)
   6f66e:      	movq	$0x3, 0x30(%rsp)
   6f677:      	xorl	%edi, %edi
   6f679:      	callq	0x70870 <f.3>
   6f67e:      	subq	$0x8, %rsp
   6f682:      	cmpb	$0x0, 0x63c7(%rip)      # 0x75a50 <g.4>
   6f689:      	je	0x7085f <f.2+0x180af>
   6f68f:      	addq	0x50(%rsp), %rax
   6f694:      	addq	%r15, %rax
   6f697:      	movq	0x10(%rsp), %rcx
   6f69c:      	movq	0x18(%rsp), %rdx
   6f6a1:      	cmpq	$0x0, 0x639f(%rip)      # 0x75a48 <g.3>
   6f6a9:      	je	0x7085f <f.2+0x180af>
   6f6af:      	cmpq	$0x10, %r12
   6f6b3:      	je	0x6f6c5 <f.2+0x16f15>
   6f6b5:      	cmpq	$0xf, %r12
   6f6b9:      	jne	0x6f6dd <f.2+0x16f2d>
   6f6bb:      	leaq	-0xe(%r12,%rax), %r15
   6f6c0:      	jmp	0x6f826 <f.2+0x17076>
   6f6c5:      	movl	$0x1, %esi
   6f6ca:      	cmpq	$0x0, 0x6376(%rip)      # 0x75a48 <g.3>
   6f6d2:      	jne	0x6f784 <f.2+0x16fd4>
   6f6d8:      	jmp	0x7085f <f.2+0x180af>
   6f6dd:      	movq	%rax, 0x50(%rsp)
   6f6e2:      	movq	%rdx, 0x18(%rsp)
   6f6e7:      	movq	%rcx, 0x10(%rsp)
   6f6ec:      	leaq	-0x10(%r12), %rsi
   6f6f1:      	movq	$0x0, 0x48(%rsp)
   6f6fa:      	movq	$0x3, 0x30(%rsp)
   6f703:      	xorl	%edi, %edi
   6f705:      	callq	0x70870 <f.3>
   6f70a:      	subq	$0x8, %rsp
   6f70e:      	cmpb	$0x0, 0x633b(%rip)      # 0x75a50 <g.4>
   6f715:      	je	0x7085f <f.2+0x180af>
   6f71b:      	cmpq	$0x0, 0x6325(%rip)      # 0x75a48 <g.3>
   6f723:      	je	0x7085f <f.2+0x180af>
   6f729:      	movq	%rax, %r15
   6f72c:      	leaq	-0x11(%r12), %rsi
   6f731:      	movq	$0x0, 0x48(%rsp)
   6f73a:      	movq	$0x3, 0x30(%rsp)
   6f743:      	xorl	%edi, %edi
   6f745:      	callq	0x70870 <f.3>
   6f74a:      	subq	$0x8, %rsp
   6f74e:      	cmpb	$0x0, 0x62fb(%rip)      # 0x75a50 <g.4>
   6f755:      	je	0x7085f <f.2+0x180af>
   6f75b:      	movq	%rax, %rsi
   6f75e:      	cmpq	$0x0, 0x62e2(%rip)      # 0x75a48 <g.3>
   6f766:      	movq	0x10(%rsp), %rcx
   6f76b:      	movq	0x18(%rsp), %rdx
   6f770:      	movq	0x50(%rsp), %rax
   6f775:      	je	0x7085f <f.2+0x180af>
   6f77b:      	addq	%r15, %rsi
   6f77e:      	cmpq	$0x11, %r12
   6f782:      	ja	0x6f78e <f.2+0x16fde>
   6f784:      	leaq	-0x10(%r12), %r15
   6f789:      	jmp	0x6f813 <f.2+0x17063>
   6f78e:      	movq	%rsi, 0x58(%rsp)
   6f793:      	movq	$0x0, 0x48(%rsp)
   6f79c:      	movq	$0x3, 0x30(%rsp)
   6f7a5:      	xorl	%edi, %edi
   6f7a7:      	leaq	-0x11(%r12), %rsi
   6f7ac:      	callq	0x70870 <f.3>
   6f7b1:      	subq	$0x8, %rsp
   6f7b5:      	cmpb	$0x0, 0x6294(%rip)      # 0x75a50 <g.4>
   6f7bc:      	je	0x7085f <f.2+0x180af>
   6f7c2:      	movq	%rax, 0x60(%rsp)
   6f7c7:      	cmpq	$0x0, 0x6279(%rip)      # 0x75a48 <g.3>
   6f7cf:      	je	0x7085f <f.2+0x180af>
   6f7d5:      	leaq	-0x12(%r12), %rsi
   6f7da:      	movq	$0x0, 0x48(%rsp)
   6f7e3:      	movq	$0x3, 0x30(%rsp)
   6f7ec:      	xorl	%edi, %edi
   6f7ee:      	callq	0x70870 <f.3>
   6f7f3:      	subq	$0x8, %rsp
   6f7f7:      	movq	%rax, %r15
   6f7fa:      	addq	0x60(%rsp), %r15
   6f7ff:      	movq	0x10(%rsp), %rcx
   6f804:      	movq	0x18(%rsp), %rdx
   6f809:      	movq	0x50(%rsp), %rax
   6f80e:      	movq	0x58(%rsp), %rsi
   6f813:      	cmpb	$0x0, 0x6236(%rip)      # 0x75a50 <g.4>
   6f81a:      	je	0x7085f <f.2+0x180af>
   6f820:      	addq	%rsi, %r15
   6f823:      	addq	%rax, %r15
   6f826:      	cmpq	$0x0, 0x621a(%rip)      # 0x75a48 <g.3>
   6f82e:      	je	0x7085f <f.2+0x180af>
   6f834:      	cmpq	$0xe, %r12
   6f838:      	ja	0x6f844 <f.2+0x17094>
   6f83a:      	leaq	-0xd(%r12), %rsi
   6f83f:      	jmp	0x6fb31 <f.2+0x17381>
   6f844:      	cmpq	$0xf, %r12
   6f848:      	jne	0x6f862 <f.2+0x170b2>
   6f84a:      	movl	$0x1, %esi
   6f84f:      	cmpq	$0x0, 0x61f1(%rip)      # 0x75a48 <g.3>
   6f857:      	jne	0x6f9cc <f.2+0x1721c>
   6f85d:      	jmp	0x7085f <f.2+0x180af>
   6f862:      	cmpq	$0x11, %r12
   6f866:      	jb	0x6f990 <f.2+0x171e0>
   6f86c:      	movq	%rdx, 0x18(%rsp)
   6f871:      	movq	%rcx, 0x10(%rsp)
   6f876:      	leaq	-0x10(%r12), %rsi
   6f87b:      	movq	$0x0, 0x48(%rsp)
   6f884:      	movq	$0x3, 0x30(%rsp)
   6f88d:      	xorl	%edi, %edi
   6f88f:      	callq	0x70870 <f.3>
   6f894:      	subq	$0x8, %rsp
   6f898:      	cmpb	$0x0, 0x61b1(%rip)      # 0x75a50 <g.4>
   6f89f:      	je	0x7085f <f.2+0x180af>
   6f8a5:      	movq	%rax, 0x50(%rsp)
   6f8aa:      	cmpq	$0x0, 0x6196(%rip)      # 0x75a48 <g.3>
   6f8b2:      	je	0x7085f <f.2+0x180af>
   6f8b8:      	leaq	-0x11(%r12), %rsi
   6f8bd:      	movq	$0x0, 0x48(%rsp)
   6f8c6:      	movq	$0x3, 0x30(%rsp)
   6f8cf:      	xorl	%edi, %edi
   6f8d1:      	callq	0x70870 <f.3>
   6f8d6:      	subq	$0x8, %rsp
   6f8da:      	cmpb	$0x0, 0x616f(%rip)      # 0x75a50 <g.4>
   6f8e1:      	je	0x7085f <f.2+0x180af>
   6f8e7:      	cmpq	$0x0, 0x6159(%rip)      # 0x75a48 <g.3>
   6f8ef:      	movq	0x10(%rsp), %rcx
   6f8f4:      	movq	0x18(%rsp), %rdx
   6f8f9:      	je	0x7085f <f.2+0x180af>
   6f8ff:      	addq	0x50(%rsp), %rax
   6f904:      	cmpq	$0x11, %r12
   6f908:      	je	0x6f9a3 <f.2+0x171f3>
   6f90e:      	movq	%rax, 0x50(%rsp)
   6f913:      	movq	$0x0, 0x48(%rsp)
   6f91c:      	movq	$0x3, 0x30(%rsp)
   6f925:      	xorl	%edi, %edi
   6f927:      	leaq	-0x11(%r12), %rsi
   6f92c:      	callq	0x70870 <f.3>
   6f931:      	subq	$0x8, %rsp
   6f935:      	cmpb	$0x0, 0x6114(%rip)      # 0x75a50 <g.4>
   6f93c:      	je	0x7085f <f.2+0x180af>
   6f942:      	movq	%rax, 0x58(%rsp)
   6f947:      	cmpq	$0x0, 0x60f9(%rip)      # 0x75a48 <g.3>
   6f94f:      	je	0x7085f <f.2+0x180af>
   6f955:      	leaq	-0x12(%r12), %rsi
   6f95a:      	movq	$0x0, 0x48(%rsp)
   6f963:      	movq	$0x3, 0x30(%rsp)
   6f96c:      	xorl	%edi, %edi
   6f96e:      	callq	0x70870 <f.3>
   6f973:      	subq	$0x8, %rsp
   6f977:      	movq	%rax, %rsi
   6f97a:      	addq	0x58(%rsp), %rsi
   6f97f:      	movq	0x10(%rsp), %rcx
   6f984:      	movq	0x18(%rsp), %rdx
   6f989:      	movq	0x50(%rsp), %rax
   6f98e:      	jmp	0x6f9a8 <f.2+0x171f8>
   6f990:      	movl	$0x1, %eax
   6f995:      	cmpq	$0x0, 0x60ab(%rip)      # 0x75a48 <g.3>
   6f99d:      	je	0x7085f <f.2+0x180af>
   6f9a3:      	leaq	-0x10(%r12), %rsi
   6f9a8:      	cmpb	$0x0, 0x60a1(%rip)      # 0x75a50 <g.4>
   6f9af:      	je	0x7085f <f.2+0x180af>
   6f9b5:      	cmpq	$0x0, 0x608b(%rip)      # 0x75a48 <g.3>
   6f9bd:      	je	0x7085f <f.2+0x180af>
   6f9c3:      	addq	%rax, %rsi
   6f9c6:      	cmpq	$0x10, %r12
   6f9ca:      	ja	0x6f9d6 <f.2+0x17226>
   6f9cc:      	leaq	-0xf(%r12), %rdi
   6f9d1:      	jmp	0x6fb2e <f.2+0x1737e>
   6f9d6:      	cmpq	$0x11, %r12
   6f9da:      	jne	0x6f9f4 <f.2+0x17244>
   6f9dc:      	movl	$0x1, %edi
   6f9e1:      	cmpq	$0x0, 0x605f(%rip)      # 0x75a48 <g.3>
   6f9e9:      	jne	0x6fa9f <f.2+0x172ef>
   6f9ef:      	jmp	0x7085f <f.2+0x180af>
   6f9f4:      	movq	%rsi, 0x50(%rsp)
   6f9f9:      	movq	%rdx, 0x18(%rsp)
   6f9fe:      	movq	%rcx, 0x10(%rsp)
   6fa03:      	leaq	-0x11(%r12), %rsi
   6fa08:      	movq	$0x0, 0x48(%rsp)
   6fa11:      	movq	$0x3, 0x30(%rsp)
   6fa1a:      	xorl	%edi, %edi
   6fa1c:      	callq	0x70870 <f.3>
   6fa21:      	subq	$0x8, %rsp
   6fa25:      	cmpb	$0x0, 0x6024(%rip)      # 0x75a50 <g.4>
   6fa2c:      	je	0x7085f <f.2+0x180af>
   6fa32:      	movq	%rax, 0x58(%rsp)
   6fa37:      	cmpq	$0x0, 0x6009(%rip)      # 0x75a48 <g.3>
   6fa3f:      	je	0x7085f <f.2+0x180af>
   6fa45:      	leaq	-0x12(%r12), %rsi
   6fa4a:      	movq	$0x0, 0x48(%rsp)
   6fa53:      	movq	$0x3, 0x30(%rsp)
   6fa5c:      	xorl	%edi, %edi
   6fa5e:      	callq	0x70870 <f.3>
   6fa63:      	subq	$0x8, %rsp
   6fa67:      	cmpb	$0x0, 0x5fe2(%rip)      # 0x75a50 <g.4>
   6fa6e:      	je	0x7085f <f.2+0x180af>
   6fa74:      	cmpq	$0x0, 0x5fcc(%rip)      # 0x75a48 <g.3>
   6fa7c:      	movq	0x10(%rsp), %rcx
   6fa81:      	movq	0x18(%rsp), %rdx
   6fa86:      	movq	0x50(%rsp), %rsi
   6fa8b:      	je	0x7085f <f.2+0x180af>
   6fa91:      	movq	%rax, %rdi
   6fa94:      	addq	0x58(%rsp), %rdi
   6fa99:      	cmpq	$0x12, %r12
   6fa9d:      	ja	0x6faa9 <f.2+0x172f9>
   6fa9f:      	leaq	-0x11(%r12), %rax
   6faa4:      	jmp	0x6fb2b <f.2+0x1737b>
   6faa9:      	movq	%rdi, 0x58(%rsp)
   6faae:      	movq	$0x0, 0x48(%rsp)
   6fab7:      	movq	$0x3, 0x30(%rsp)
   6fac0:      	xorl	%edi, %edi
   6fac2:      	leaq	-0x12(%r12), %rsi
   6fac7:      	callq	0x70870 <f.3>
   6facc:      	subq	$0x8, %rsp
   6fad0:      	movq	%rax, 0x60(%rsp)
   6fad5:      	cmpb	$0x0, 0x5f74(%rip)      # 0x75a50 <g.4>
   6fadc:      	je	0x7085f <f.2+0x180af>
   6fae2:      	cmpq	$0x0, 0x5f5e(%rip)      # 0x75a48 <g.3>
   6faea:      	je	0x7085f <f.2+0x180af>
   6faf0:      	leaq	-0x13(%r12), %rsi
   6faf5:      	movq	$0x0, 0x48(%rsp)
   6fafe:      	movq	$0x3, 0x30(%rsp)
   6fb07:      	xorl	%edi, %edi
   6fb09:      	callq	0x70870 <f.3>
   6fb0e:      	subq	$0x8, %rsp
   6fb12:      	addq	0x60(%rsp), %rax
   6fb17:      	movq	0x10(%rsp), %rcx
   6fb1c:      	movq	0x18(%rsp), %rdx
   6fb21:      	movq	0x50(%rsp), %rsi
   6fb26:      	movq	0x58(%rsp), %rdi
   6fb2b:      	addq	%rax, %rdi
   6fb2e:      	addq	%rdi, %rsi
   6fb31:      	addq	%rsi, %r15
   6fb34:      	cmpb	$0x0, 0x5f15(%rip)      # 0x75a50 <g.4>
   6fb3b:      	je	0x7085f <f.2+0x180af>
   6fb41:      	cmpq	$0x0, 0x5eff(%rip)      # 0x75a48 <g.3>
   6fb49:      	je	0x7085f <f.2+0x180af>
   6fb4f:      	addq	%rdx, %r15
   6fb52:      	cmpq	$0xb, %r12
   6fb56:      	ja	0x6fb61 <f.2+0x173b1>
   6fb58:      	addq	$-0xa, %r12
   6fb5c:      	jmp	0x707d9 <f.2+0x18029>
   6fb61:      	cmpq	$0xc, %r12
   6fb65:      	jne	0x6fb7f <f.2+0x173cf>
   6fb67:      	movl	$0x1, %edx
   6fb6c:      	cmpq	$0x0, 0x5ed4(%rip)      # 0x75a48 <g.3>
   6fb74:      	jne	0x701a1 <f.2+0x179f1>
   6fb7a:      	jmp	0x7085f <f.2+0x180af>
   6fb7f:      	cmpq	$0xe, %r12
   6fb83:      	jb	0x6fb9f <f.2+0x173ef>
   6fb85:      	jne	0x6fbb7 <f.2+0x17407>
   6fb87:      	movl	$0x1, %edx
   6fb8c:      	cmpq	$0x0, 0x5eb4(%rip)      # 0x75a48 <g.3>
   6fb94:      	jne	0x6fd12 <f.2+0x17562>
   6fb9a:      	jmp	0x7085f <f.2+0x180af>
   6fb9f:      	movl	$0x1, %esi
   6fba4:      	cmpq	$0x0, 0x5e9c(%rip)      # 0x75a48 <g.3>
   6fbac:      	jne	0x6fe8c <f.2+0x176dc>
   6fbb2:      	jmp	0x7085f <f.2+0x180af>
   6fbb7:      	cmpq	$0x10, %r12
   6fbbb:      	jb	0x6fcd6 <f.2+0x17526>
   6fbc1:      	movq	%rcx, 0x10(%rsp)
   6fbc6:      	leaq	-0xf(%r12), %rsi
   6fbcb:      	movq	$0x0, 0x48(%rsp)
   6fbd4:      	movq	$0x3, 0x30(%rsp)
   6fbdd:      	xorl	%edi, %edi
   6fbdf:      	callq	0x70870 <f.3>
   6fbe4:      	subq	$0x8, %rsp
   6fbe8:      	cmpb	$0x0, 0x5e61(%rip)      # 0x75a50 <g.4>
   6fbef:      	je	0x7085f <f.2+0x180af>
   6fbf5:      	movq	%rax, 0x18(%rsp)
   6fbfa:      	cmpq	$0x0, 0x5e46(%rip)      # 0x75a48 <g.3>
   6fc02:      	je	0x7085f <f.2+0x180af>
   6fc08:      	leaq	-0x10(%r12), %rsi
   6fc0d:      	movq	$0x0, 0x48(%rsp)
   6fc16:      	movq	$0x3, 0x30(%rsp)
   6fc1f:      	xorl	%edi, %edi
   6fc21:      	callq	0x70870 <f.3>
   6fc26:      	subq	$0x8, %rsp
   6fc2a:      	cmpb	$0x0, 0x5e1f(%rip)      # 0x75a50 <g.4>
   6fc31:      	je	0x7085f <f.2+0x180af>
   6fc37:      	cmpq	$0x0, 0x5e09(%rip)      # 0x75a48 <g.3>
   6fc3f:      	movq	0x10(%rsp), %rcx
   6fc44:      	je	0x7085f <f.2+0x180af>
   6fc4a:      	addq	0x18(%rsp), %rax
   6fc4f:      	cmpq	$0x10, %r12
   6fc53:      	je	0x6fce9 <f.2+0x17539>
   6fc59:      	movq	%rax, 0x18(%rsp)
   6fc5e:      	movq	$0x0, 0x48(%rsp)
   6fc67:      	movq	$0x3, 0x30(%rsp)
   6fc70:      	xorl	%edi, %edi
   6fc72:      	leaq	-0x10(%r12), %rsi
   6fc77:      	callq	0x70870 <f.3>
   6fc7c:      	subq	$0x8, %rsp
   6fc80:      	cmpb	$0x0, 0x5dc9(%rip)      # 0x75a50 <g.4>
   6fc87:      	je	0x7085f <f.2+0x180af>
   6fc8d:      	movq	%rax, 0x50(%rsp)
   6fc92:      	cmpq	$0x0, 0x5dae(%rip)      # 0x75a48 <g.3>
   6fc9a:      	je	0x7085f <f.2+0x180af>
   6fca0:      	leaq	-0x11(%r12), %rsi
   6fca5:      	movq	$0x0, 0x48(%rsp)
   6fcae:      	movq	$0x3, 0x30(%rsp)
   6fcb7:      	xorl	%edi, %edi
   6fcb9:      	callq	0x70870 <f.3>
   6fcbe:      	subq	$0x8, %rsp
   6fcc2:      	movq	%rax, %rdx
   6fcc5:      	addq	0x50(%rsp), %rdx
   6fcca:      	movq	0x10(%rsp), %rcx
   6fccf:      	movq	0x18(%rsp), %rax
   6fcd4:      	jmp	0x6fcee <f.2+0x1753e>
   6fcd6:      	movl	$0x1, %eax
   6fcdb:      	cmpq	$0x0, 0x5d65(%rip)      # 0x75a48 <g.3>
   6fce3:      	je	0x7085f <f.2+0x180af>
   6fce9:      	leaq	-0xf(%r12), %rdx
   6fcee:      	cmpb	$0x0, 0x5d5b(%rip)      # 0x75a50 <g.4>
   6fcf5:      	je	0x7085f <f.2+0x180af>
   6fcfb:      	cmpq	$0x0, 0x5d45(%rip)      # 0x75a48 <g.3>
   6fd03:      	je	0x7085f <f.2+0x180af>
   6fd09:      	addq	%rax, %rdx
   6fd0c:      	cmpq	$0xf, %r12
   6fd10:      	ja	0x6fd1c <f.2+0x1756c>
   6fd12:      	leaq	-0xe(%r12), %rsi
   6fd17:      	jmp	0x6fe62 <f.2+0x176b2>
   6fd1c:      	cmpq	$0x10, %r12
   6fd20:      	jne	0x6fd3a <f.2+0x1758a>
   6fd22:      	movl	$0x1, %esi
   6fd27:      	cmpq	$0x0, 0x5d19(%rip)      # 0x75a48 <g.3>
   6fd2f:      	jne	0x6fddb <f.2+0x1762b>
   6fd35:      	jmp	0x7085f <f.2+0x180af>
   6fd3a:      	movq	%rdx, 0x18(%rsp)
   6fd3f:      	movq	%rcx, 0x10(%rsp)
   6fd44:      	leaq	-0x10(%r12), %rsi
   6fd49:      	movq	$0x0, 0x48(%rsp)
   6fd52:      	movq	$0x3, 0x30(%rsp)
   6fd5b:      	xorl	%edi, %edi
   6fd5d:      	callq	0x70870 <f.3>
   6fd62:      	subq	$0x8, %rsp
   6fd66:      	cmpb	$0x0, 0x5ce3(%rip)      # 0x75a50 <g.4>
   6fd6d:      	je	0x7085f <f.2+0x180af>
   6fd73:      	movq	%rax, 0x50(%rsp)
   6fd78:      	cmpq	$0x0, 0x5cc8(%rip)      # 0x75a48 <g.3>
   6fd80:      	je	0x7085f <f.2+0x180af>
   6fd86:      	leaq	-0x11(%r12), %rsi
   6fd8b:      	movq	$0x0, 0x48(%rsp)
   6fd94:      	movq	$0x3, 0x30(%rsp)
   6fd9d:      	xorl	%edi, %edi
   6fd9f:      	callq	0x70870 <f.3>
   6fda4:      	subq	$0x8, %rsp
   6fda8:      	cmpb	$0x0, 0x5ca1(%rip)      # 0x75a50 <g.4>
   6fdaf:      	je	0x7085f <f.2+0x180af>
   6fdb5:      	cmpq	$0x0, 0x5c8b(%rip)      # 0x75a48 <g.3>
   6fdbd:      	movq	0x10(%rsp), %rcx
   6fdc2:      	movq	0x18(%rsp), %rdx
   6fdc7:      	je	0x7085f <f.2+0x180af>
   6fdcd:      	movq	%rax, %rsi
   6fdd0:      	addq	0x50(%rsp), %rsi
   6fdd5:      	cmpq	$0x11, %r12
   6fdd9:      	ja	0x6fde2 <f.2+0x17632>
   6fddb:      	leaq	-0x10(%r12), %rax
   6fde0:      	jmp	0x6fe5f <f.2+0x176af>
   6fde2:      	movq	%rsi, 0x50(%rsp)
   6fde7:      	movq	$0x0, 0x48(%rsp)
   6fdf0:      	movq	$0x3, 0x30(%rsp)
   6fdf9:      	xorl	%edi, %edi
   6fdfb:      	leaq	-0x11(%r12), %rsi
   6fe00:      	callq	0x70870 <f.3>
   6fe05:      	subq	$0x8, %rsp
   6fe09:      	movq	%rax, 0x58(%rsp)
   6fe0e:      	cmpb	$0x0, 0x5c3b(%rip)      # 0x75a50 <g.4>
   6fe15:      	je	0x7085f <f.2+0x180af>
   6fe1b:      	cmpq	$0x0, 0x5c25(%rip)      # 0x75a48 <g.3>
   6fe23:      	je	0x7085f <f.2+0x180af>
   6fe29:      	leaq	-0x12(%r12), %rsi
   6fe2e:      	movq	$0x0, 0x48(%rsp)
   6fe37:      	movq	$0x3, 0x30(%rsp)
   6fe40:      	xorl	%edi, %edi
   6fe42:      	callq	0x70870 <f.3>
   6fe47:      	subq	$0x8, %rsp
   6fe4b:      	addq	0x58(%rsp), %rax
   6fe50:      	movq	0x10(%rsp), %rcx
   6fe55:      	movq	0x50(%rsp), %rsi
   6fe5a:      	movq	0x18(%rsp), %rdx
   6fe5f:      	addq	%rax, %rsi
   6fe62:      	cmpb	$0x0, 0x5be7(%rip)      # 0x75a50 <g.4>
   6fe69:      	je	0x7085f <f.2+0x180af>
   6fe6f:      	cmpq	$0x0, 0x5bd1(%rip)      # 0x75a48 <g.3>
   6fe77:      	je	0x7085f <f.2+0x180af>
   6fe7d:      	addq	%rdx, %rsi
   6fe80:      	cmpq	$0xf, %r12
   6fe84:      	je	0x6fe96 <f.2+0x176e6>
   6fe86:      	cmpq	$0xe, %r12
   6fe8a:      	jne	0x6feae <f.2+0x176fe>
   6fe8c:      	leaq	-0xd(%r12), %rdx
   6fe91:      	jmp	0x7017d <f.2+0x179cd>
   6fe96:      	movl	$0x1, %edx
   6fe9b:      	cmpq	$0x0, 0x5ba5(%rip)      # 0x75a48 <g.3>
   6fea3:      	jne	0x70018 <f.2+0x17868>
   6fea9:      	jmp	0x7085f <f.2+0x180af>
   6feae:      	cmpq	$0x11, %r12
   6feb2:      	jb	0x6ffdc <f.2+0x1782c>
   6feb8:      	movq	%rsi, 0x50(%rsp)
   6febd:      	movq	%rcx, 0x10(%rsp)
   6fec2:      	leaq	-0x10(%r12), %rsi
   6fec7:      	movq	$0x0, 0x48(%rsp)
   6fed0:      	movq	$0x3, 0x30(%rsp)
   6fed9:      	xorl	%edi, %edi
   6fedb:      	callq	0x70870 <f.3>
   6fee0:      	subq	$0x8, %rsp
   6fee4:      	cmpb	$0x0, 0x5b65(%rip)      # 0x75a50 <g.4>
   6feeb:      	je	0x7085f <f.2+0x180af>
   6fef1:      	movq	%rax, 0x18(%rsp)
   6fef6:      	cmpq	$0x0, 0x5b4a(%rip)      # 0x75a48 <g.3>
   6fefe:      	je	0x7085f <f.2+0x180af>
   6ff04:      	leaq	-0x11(%r12), %rsi
   6ff09:      	movq	$0x0, 0x48(%rsp)
   6ff12:      	movq	$0x3, 0x30(%rsp)
   6ff1b:      	xorl	%edi, %edi
   6ff1d:      	callq	0x70870 <f.3>
   6ff22:      	subq	$0x8, %rsp
   6ff26:      	cmpb	$0x0, 0x5b23(%rip)      # 0x75a50 <g.4>
   6ff2d:      	je	0x7085f <f.2+0x180af>
   6ff33:      	cmpq	$0x0, 0x5b0d(%rip)      # 0x75a48 <g.3>
   6ff3b:      	movq	0x10(%rsp), %rcx
   6ff40:      	movq	0x50(%rsp), %rsi
   6ff45:      	je	0x7085f <f.2+0x180af>
   6ff4b:      	addq	0x18(%rsp), %rax
   6ff50:      	cmpq	$0x11, %r12
   6ff54:      	je	0x6ffef <f.2+0x1783f>
   6ff5a:      	movq	%rax, 0x18(%rsp)
   6ff5f:      	movq	$0x0, 0x48(%rsp)
   6ff68:      	movq	$0x3, 0x30(%rsp)
   6ff71:      	xorl	%edi, %edi
   6ff73:      	leaq	-0x11(%r12), %rsi
   6ff78:      	callq	0x70870 <f.3>
   6ff7d:      	subq	$0x8, %rsp
   6ff81:      	cmpb	$0x0, 0x5ac8(%rip)      # 0x75a50 <g.4>
   6ff88:      	je	0x7085f <f.2+0x180af>
   6ff8e:      	movq	%rax, 0x58(%rsp)
   6ff93:      	cmpq	$0x0, 0x5aad(%rip)      # 0x75a48 <g.3>
   6ff9b:      	je	0x7085f <f.2+0x180af>
   6ffa1:      	leaq	-0x12(%r12), %rsi
   6ffa6:      	movq	$0x0, 0x48(%rsp)
   6ffaf:      	movq	$0x3, 0x30(%rsp)
   6ffb8:      	xorl	%edi, %edi
   6ffba:      	callq	0x70870 <f.3>
   6ffbf:      	subq	$0x8, %rsp
   6ffc3:      	movq	%rax, %rdx
   6ffc6:      	addq	0x58(%rsp), %rdx
   6ffcb:      	movq	0x10(%rsp), %rcx
   6ffd0:      	movq	0x50(%rsp), %rsi
   6ffd5:      	movq	0x18(%rsp), %rax
   6ffda:      	jmp	0x6fff4 <f.2+0x17844>
   6ffdc:      	movl	$0x1, %eax
   6ffe1:      	cmpq	$0x0, 0x5a5f(%rip)      # 0x75a48 <g.3>
   6ffe9:      	je	0x7085f <f.2+0x180af>
   6ffef:      	leaq	-0x10(%r12), %rdx
   6fff4:      	cmpb	$0x0, 0x5a55(%rip)      # 0x75a50 <g.4>
   6fffb:      	je	0x7085f <f.2+0x180af>
   70001:      	cmpq	$0x0, 0x5a3f(%rip)      # 0x75a48 <g.3>
   70009:      	je	0x7085f <f.2+0x180af>
   7000f:      	addq	%rax, %rdx
   70012:      	cmpq	$0x10, %r12
   70016:      	ja	0x70022 <f.2+0x17872>
   70018:      	leaq	-0xf(%r12), %rdi
   7001d:      	jmp	0x7017a <f.2+0x179ca>
   70022:      	cmpq	$0x11, %r12
   70026:      	jne	0x70040 <f.2+0x17890>
   70028:      	movl	$0x1, %edi
   7002d:      	cmpq	$0x0, 0x5a13(%rip)      # 0x75a48 <g.3>
   70035:      	jne	0x700eb <f.2+0x1793b>
   7003b:      	jmp	0x7085f <f.2+0x180af>
   70040:      	movq	%rsi, 0x50(%rsp)
   70045:      	movq	%rdx, 0x18(%rsp)
   7004a:      	movq	%rcx, 0x10(%rsp)
   7004f:      	leaq	-0x11(%r12), %rsi
   70054:      	movq	$0x0, 0x48(%rsp)
   7005d:      	movq	$0x3, 0x30(%rsp)
   70066:      	xorl	%edi, %edi
   70068:      	callq	0x70870 <f.3>
   7006d:      	subq	$0x8, %rsp
   70071:      	cmpb	$0x0, 0x59d8(%rip)      # 0x75a50 <g.4>
   70078:      	je	0x7085f <f.2+0x180af>
   7007e:      	movq	%rax, 0x58(%rsp)
   70083:      	cmpq	$0x0, 0x59bd(%rip)      # 0x75a48 <g.3>
   7008b:      	je	0x7085f <f.2+0x180af>
   70091:      	leaq	-0x12(%r12), %rsi
   70096:      	movq	$0x0, 0x48(%rsp)
   7009f:      	movq	$0x3, 0x30(%rsp)
   700a8:      	xorl	%edi, %edi
   700aa:      	callq	0x70870 <f.3>
   700af:      	subq	$0x8, %rsp
   700b3:      	cmpb	$0x0, 0x5996(%rip)      # 0x75a50 <g.4>
   700ba:      	je	0x7085f <f.2+0x180af>
   700c0:      	cmpq	$0x0, 0x5980(%rip)      # 0x75a48 <g.3>
   700c8:      	movq	0x10(%rsp), %rcx
   700cd:      	movq	0x18(%rsp), %rdx
   700d2:      	movq	0x50(%rsp), %rsi
   700d7:      	je	0x7085f <f.2+0x180af>
   700dd:      	movq	%rax, %rdi
   700e0:      	addq	0x58(%rsp), %rdi
   700e5:      	cmpq	$0x12, %r12
   700e9:      	ja	0x700f5 <f.2+0x17945>
   700eb:      	leaq	-0x11(%r12), %rax
   700f0:      	jmp	0x70177 <f.2+0x179c7>
   700f5:      	movq	%rdi, 0x58(%rsp)
   700fa:      	movq	$0x0, 0x48(%rsp)
   70103:      	movq	$0x3, 0x30(%rsp)
   7010c:      	xorl	%edi, %edi
   7010e:      	leaq	-0x12(%r12), %rsi
   70113:      	callq	0x70870 <f.3>
   70118:      	subq	$0x8, %rsp
   7011c:      	movq	%rax, 0x60(%rsp)
   70121:      	cmpb	$0x0, 0x5928(%rip)      # 0x75a50 <g.4>
   70128:      	je	0x7085f <f.2+0x180af>
   7012e:      	cmpq	$0x0, 0x5912(%rip)      # 0x75a48 <g.3>
   70136:      	je	0x7085f <f.2+0x180af>
   7013c:      	leaq	-0x13(%r12), %rsi
   70141:      	movq	$0x0, 0x48(%rsp)
   7014a:      	movq	$0x3, 0x30(%rsp)
   70153:      	xorl	%edi, %edi
   70155:      	callq	0x70870 <f.3>
   7015a:      	subq	$0x8, %rsp
   7015e:      	addq	0x60(%rsp), %rax
   70163:      	movq	0x10(%rsp), %rcx
   70168:      	movq	0x18(%rsp), %rdx
   7016d:      	movq	0x50(%rsp), %rsi
   70172:      	movq	0x58(%rsp), %rdi
   70177:      	addq	%rax, %rdi
   7017a:      	addq	%rdi, %rdx
   7017d:      	cmpb	$0x0, 0x58cc(%rip)      # 0x75a50 <g.4>
   70184:      	je	0x7085f <f.2+0x180af>
   7018a:      	cmpq	$0x0, 0x58b6(%rip)      # 0x75a48 <g.3>
   70192:      	je	0x7085f <f.2+0x180af>
   70198:      	addq	%rsi, %rdx
   7019b:      	cmpq	$0xd, %r12
   7019f:      	ja	0x701aa <f.2+0x179fa>
   701a1:      	addq	$-0xc, %r12
   701a5:      	jmp	0x707d6 <f.2+0x18026>
   701aa:      	cmpq	$0xe, %r12
   701ae:      	jne	0x701c8 <f.2+0x17a18>
   701b0:      	movl	$0x1, %esi
   701b5:      	cmpq	$0x0, 0x588b(%rip)      # 0x75a48 <g.3>
   701bd:      	jne	0x704d2 <f.2+0x17d22>
   701c3:      	jmp	0x7085f <f.2+0x180af>
   701c8:      	cmpq	$0x10, %r12
   701cc:      	jb	0x701e8 <f.2+0x17a38>
   701ce:      	jne	0x70200 <f.2+0x17a50>
   701d0:      	movl	$0x1, %eax
   701d5:      	cmpq	$0x0, 0x586b(%rip)      # 0x75a48 <g.3>
   701dd:      	jne	0x7029e <f.2+0x17aee>
   701e3:      	jmp	0x7085f <f.2+0x180af>
   701e8:      	movl	$0x1, %edi
   701ed:      	cmpq	$0x0, 0x5853(%rip)      # 0x75a48 <g.3>
   701f5:      	jne	0x70352 <f.2+0x17ba2>
   701fb:      	jmp	0x7085f <f.2+0x180af>
   70200:      	movq	%rdx, 0x18(%rsp)
   70205:      	movq	%rcx, 0x10(%rsp)
   7020a:      	leaq	-0x10(%r12), %rsi
   7020f:      	movq	$0x0, 0x48(%rsp)
   70218:      	movq	$0x3, 0x30(%rsp)
   70221:      	xorl	%edi, %edi
   70223:      	callq	0x70870 <f.3>
   70228:      	subq	$0x8, %rsp
   7022c:      	cmpb	$0x0, 0x581d(%rip)      # 0x75a50 <g.4>
   70233:      	je	0x7085f <f.2+0x180af>
   70239:      	movq	%rax, 0x50(%rsp)
   7023e:      	cmpq	$0x0, 0x5802(%rip)      # 0x75a48 <g.3>
   70246:      	je	0x7085f <f.2+0x180af>
   7024c:      	leaq	-0x11(%r12), %rsi
   70251:      	movq	$0x0, 0x48(%rsp)
   7025a:      	movq	$0x3, 0x30(%rsp)
   70263:      	xorl	%edi, %edi
   70265:      	callq	0x70870 <f.3>
   7026a:      	subq	$0x8, %rsp
   7026e:      	cmpb	$0x0, 0x57db(%rip)      # 0x75a50 <g.4>
   70275:      	je	0x7085f <f.2+0x180af>
   7027b:      	cmpq	$0x0, 0x57c5(%rip)      # 0x75a48 <g.3>
   70283:      	movq	0x10(%rsp), %rcx
   70288:      	movq	0x18(%rsp), %rdx
   7028d:      	je	0x7085f <f.2+0x180af>
   70293:      	addq	0x50(%rsp), %rax
   70298:      	cmpq	$0x11, %r12
   7029c:      	ja	0x702a8 <f.2+0x17af8>
   7029e:      	leaq	-0x10(%r12), %rdi
   702a3:      	jmp	0x70328 <f.2+0x17b78>
   702a8:      	movq	%rax, 0x50(%rsp)
   702ad:      	movq	$0x0, 0x48(%rsp)
   702b6:      	movq	$0x3, 0x30(%rsp)
   702bf:      	xorl	%edi, %edi
   702c1:      	leaq	-0x11(%r12), %rsi
   702c6:      	callq	0x70870 <f.3>
   702cb:      	subq	$0x8, %rsp
   702cf:      	movq	%rax, 0x58(%rsp)
   702d4:      	cmpb	$0x0, 0x5775(%rip)      # 0x75a50 <g.4>
   702db:      	je	0x7085f <f.2+0x180af>
   702e1:      	cmpq	$0x0, 0x575f(%rip)      # 0x75a48 <g.3>
   702e9:      	je	0x7085f <f.2+0x180af>
   702ef:      	leaq	-0x12(%r12), %rsi
   702f4:      	movq	$0x0, 0x48(%rsp)
   702fd:      	movq	$0x3, 0x30(%rsp)
   70306:      	xorl	%edi, %edi
   70308:      	callq	0x70870 <f.3>
   7030d:      	subq	$0x8, %rsp
   70311:      	movq	%rax, %rdi
   70314:      	addq	0x58(%rsp), %rdi
   70319:      	movq	0x10(%rsp), %rcx
   7031e:      	movq	0x18(%rsp), %rdx
   70323:      	movq	0x50(%rsp), %rax
   70328:      	cmpb	$0x0, 0x5721(%rip)      # 0x75a50 <g.4>
   7032f:      	je	0x7085f <f.2+0x180af>
   70335:      	cmpq	$0x0, 0x570b(%rip)      # 0x75a48 <g.3>
   7033d:      	je	0x7085f <f.2+0x180af>
   70343:      	addq	%rax, %rdi
   70346:      	cmpq	$0x11, %r12
   7034a:      	je	0x7035c <f.2+0x17bac>
   7034c:      	cmpq	$0x10, %r12
   70350:      	jne	0x70374 <f.2+0x17bc4>
   70352:      	leaq	-0xf(%r12), %rsi
   70357:      	jmp	0x704ae <f.2+0x17cfe>
   7035c:      	movl	$0x1, %esi
   70361:      	cmpq	$0x0, 0x56df(%rip)      # 0x75a48 <g.3>
   70369:      	jne	0x7041f <f.2+0x17c6f>
   7036f:      	jmp	0x7085f <f.2+0x180af>
   70374:      	movq	%rdi, 0x58(%rsp)
   70379:      	movq	%rdx, 0x18(%rsp)
   7037e:      	movq	%rcx, 0x10(%rsp)
   70383:      	leaq	-0x11(%r12), %rsi
   70388:      	movq	$0x0, 0x48(%rsp)
   70391:      	movq	$0x3, 0x30(%rsp)
   7039a:      	xorl	%edi, %edi
   7039c:      	callq	0x70870 <f.3>
   703a1:      	subq	$0x8, %rsp
   703a5:      	cmpb	$0x0, 0x56a4(%rip)      # 0x75a50 <g.4>
   703ac:      	je	0x7085f <f.2+0x180af>
   703b2:      	movq	%rax, 0x50(%rsp)
   703b7:      	cmpq	$0x0, 0x5689(%rip)      # 0x75a48 <g.3>
   703bf:      	je	0x7085f <f.2+0x180af>
   703c5:      	leaq	-0x12(%r12), %rsi
   703ca:      	movq	$0x0, 0x48(%rsp)
   703d3:      	movq	$0x3, 0x30(%rsp)
   703dc:      	xorl	%edi, %edi
   703de:      	callq	0x70870 <f.3>
   703e3:      	subq	$0x8, %rsp
   703e7:      	cmpb	$0x0, 0x5662(%rip)      # 0x75a50 <g.4>
   703ee:      	je	0x7085f <f.2+0x180af>
   703f4:      	cmpq	$0x0, 0x564c(%rip)      # 0x75a48 <g.3>
   703fc:      	movq	0x10(%rsp), %rcx
   70401:      	movq	0x18(%rsp), %rdx
   70406:      	movq	0x58(%rsp), %rdi
   7040b:      	je	0x7085f <f.2+0x180af>
   70411:      	movq	%rax, %rsi
   70414:      	addq	0x50(%rsp), %rsi
   70419:      	cmpq	$0x12, %r12
   7041d:      	ja	0x70429 <f.2+0x17c79>
   7041f:      	leaq	-0x11(%r12), %rax
   70424:      	jmp	0x704ab <f.2+0x17cfb>
   70429:      	movq	%rsi, 0x50(%rsp)
   7042e:      	movq	$0x0, 0x48(%rsp)
   70437:      	movq	$0x3, 0x30(%rsp)
   70440:      	xorl	%edi, %edi
   70442:      	leaq	-0x12(%r12), %rsi
   70447:      	callq	0x70870 <f.3>
   7044c:      	subq	$0x8, %rsp
   70450:      	movq	%rax, 0x60(%rsp)
   70455:      	cmpb	$0x0, 0x55f4(%rip)      # 0x75a50 <g.4>
   7045c:      	je	0x7085f <f.2+0x180af>
   70462:      	cmpq	$0x0, 0x55de(%rip)      # 0x75a48 <g.3>
   7046a:      	je	0x7085f <f.2+0x180af>
   70470:      	leaq	-0x13(%r12), %rsi
   70475:      	movq	$0x0, 0x48(%rsp)
   7047e:      	movq	$0x3, 0x30(%rsp)
   70487:      	xorl	%edi, %edi
   70489:      	callq	0x70870 <f.3>
   7048e:      	subq	$0x8, %rsp
   70492:      	addq	0x60(%rsp), %rax
   70497:      	movq	0x10(%rsp), %rcx
   7049c:      	movq	0x18(%rsp), %rdx
   704a1:      	movq	0x50(%rsp), %rsi
   704a6:      	movq	0x58(%rsp), %rdi
   704ab:      	addq	%rax, %rsi
   704ae:      	cmpb	$0x0, 0x559b(%rip)      # 0x75a50 <g.4>
   704b5:      	je	0x7085f <f.2+0x180af>
   704bb:      	cmpq	$0x0, 0x5585(%rip)      # 0x75a48 <g.3>
   704c3:      	je	0x7085f <f.2+0x180af>
   704c9:      	addq	%rdi, %rsi
   704cc:      	cmpq	$0xf, %r12
   704d0:      	ja	0x704db <f.2+0x17d2b>
   704d2:      	addq	$-0xe, %r12
   704d6:      	jmp	0x707d3 <f.2+0x18023>
   704db:      	cmpq	$0x10, %r12
   704df:      	jne	0x704f9 <f.2+0x17d49>
   704e1:      	movl	$0x1, %eax
   704e6:      	cmpq	$0x0, 0x555a(%rip)      # 0x75a48 <g.3>
   704ee:      	jne	0x70672 <f.2+0x17ec2>
   704f4:      	jmp	0x7085f <f.2+0x180af>
   704f9:      	cmpq	$0x12, %r12
   704fd:      	movq	%rcx, 0x10(%rsp)
   70502:      	movq	%rdx, 0x18(%rsp)
   70507:      	movq	%rsi, 0x50(%rsp)
   7050c:      	jb	0x705b7 <f.2+0x17e07>
   70512:      	leaq	-0x11(%r12), %rsi
   70517:      	movq	$0x0, 0x48(%rsp)
   70520:      	movq	$0x3, 0x30(%rsp)
   70529:      	xorl	%edi, %edi
   7052b:      	callq	0x70870 <f.3>
   70530:      	subq	$0x8, %rsp
   70534:      	movq	%rax, 0x58(%rsp)
   70539:      	cmpb	$0x0, 0x5510(%rip)      # 0x75a50 <g.4>
   70540:      	je	0x7085f <f.2+0x180af>
   70546:      	cmpq	$0x0, 0x54fa(%rip)      # 0x75a48 <g.3>
   7054e:      	je	0x7085f <f.2+0x180af>
   70554:      	leaq	-0x12(%r12), %rsi
   70559:      	movq	$0x0, 0x48(%rsp)
   70562:      	movq	$0x3, 0x30(%rsp)
   7056b:      	xorl	%edi, %edi
   7056d:      	callq	0x70870 <f.3>
   70572:      	subq	$0x8, %rsp
   70576:      	cmpb	$0x0, 0x54d3(%rip)      # 0x75a50 <g.4>
   7057d:      	je	0x7085f <f.2+0x180af>
   70583:      	cmpq	$0x0, 0x54bd(%rip)      # 0x75a48 <g.3>
   7058b:      	je	0x7085f <f.2+0x180af>
   70591:      	addq	0x58(%rsp), %rax
   70596:      	movq	%rax, 0x58(%rsp)
   7059b:      	cmpq	$0x12, %r12
   7059f:      	jne	0x705d1 <f.2+0x17e21>
   705a1:      	movq	0x10(%rsp), %rcx
   705a6:      	movq	0x18(%rsp), %rdx
   705ab:      	movq	0x50(%rsp), %rsi
   705b0:      	movq	0x58(%rsp), %rdi
   705b5:      	jmp	0x705ca <f.2+0x17e1a>
   705b7:      	movl	$0x1, %edi
   705bc:      	cmpq	$0x0, 0x5484(%rip)      # 0x75a48 <g.3>
   705c4:      	je	0x7085f <f.2+0x180af>
   705ca:      	leaq	-0x11(%r12), %rax
   705cf:      	jmp	0x7064e <f.2+0x17e9e>
   705d1:      	movq	$0x0, 0x48(%rsp)
   705da:      	movq	$0x3, 0x30(%rsp)
   705e3:      	xorl	%edi, %edi
   705e5:      	leaq	-0x12(%r12), %rsi
   705ea:      	callq	0x70870 <f.3>
   705ef:      	subq	$0x8, %rsp
   705f3:      	movq	%rax, 0x60(%rsp)
   705f8:      	cmpb	$0x0, 0x5451(%rip)      # 0x75a50 <g.4>
   705ff:      	je	0x7085f <f.2+0x180af>
   70605:      	cmpq	$0x0, 0x543b(%rip)      # 0x75a48 <g.3>
   7060d:      	je	0x7085f <f.2+0x180af>
   70613:      	leaq	-0x13(%r12), %rsi
   70618:      	movq	$0x0, 0x48(%rsp)
   70621:      	movq	$0x3, 0x30(%rsp)
   7062a:      	xorl	%edi, %edi
   7062c:      	callq	0x70870 <f.3>
   70631:      	subq	$0x8, %rsp
   70635:      	addq	0x60(%rsp), %rax
   7063a:      	movq	0x10(%rsp), %rcx
   7063f:      	movq	0x18(%rsp), %rdx
   70644:      	movq	0x50(%rsp), %rsi
   70649:      	movq	0x58(%rsp), %rdi
   7064e:      	cmpb	$0x0, 0x53fb(%rip)      # 0x75a50 <g.4>
   70655:      	je	0x7085f <f.2+0x180af>
   7065b:      	cmpq	$0x0, 0x53e5(%rip)      # 0x75a48 <g.3>
   70663:      	je	0x7085f <f.2+0x180af>
   70669:      	addq	%rdi, %rax
   7066c:      	cmpq	$0x11, %r12
   70670:      	ja	0x7067b <f.2+0x17ecb>
   70672:      	addq	$-0x10, %r12
   70676:      	jmp	0x707d0 <f.2+0x18020>
   7067b:      	movq	%rax, 0x60(%rsp)
   70680:      	cmpq	$0x12, %r12
   70684:      	jne	0x706a3 <f.2+0x17ef3>
   70686:      	movl	$0x1, %eax
   7068b:      	movq	%rax, 0x58(%rsp)
   70690:      	cmpq	$0x0, 0x53b0(%rip)      # 0x75a48 <g.3>
   70698:      	jne	0x7073d <f.2+0x17f8d>
   7069e:      	jmp	0x7085f <f.2+0x180af>
   706a3:      	leaq	-0x12(%r12), %rsi
   706a8:      	movq	$0x0, 0x48(%rsp)
   706b1:      	movq	$0x3, 0x30(%rsp)
   706ba:      	xorl	%edi, %edi
   706bc:      	callq	0x70870 <f.3>
   706c1:      	subq	$0x8, %rsp
   706c5:      	movq	%rax, 0x80(%rsp)
   706cd:      	cmpb	$0x0, 0x537c(%rip)      # 0x75a50 <g.4>
   706d4:      	je	0x7085f <f.2+0x180af>
   706da:      	cmpq	$0x0, 0x5366(%rip)      # 0x75a48 <g.3>
   706e2:      	je	0x7085f <f.2+0x180af>
   706e8:      	leaq	-0x13(%r12), %rsi
   706ed:      	movq	$0x0, 0x48(%rsp)
   706f6:      	movq	$0x3, 0x30(%rsp)
   706ff:      	xorl	%edi, %edi
   70701:      	callq	0x70870 <f.3>
   70706:      	subq	$0x8, %rsp
   7070a:      	movq	%rax, 0x58(%rsp)
   7070f:      	cmpb	$0x0, 0x533a(%rip)      # 0x75a50 <g.4>
   70716:      	je	0x7085f <f.2+0x180af>
   7071c:      	cmpq	$0x0, 0x5324(%rip)      # 0x75a48 <g.3>
   70724:      	je	0x7085f <f.2+0x180af>
   7072a:      	movq	0x80(%rsp), %rax
   70732:      	addq	%rax, 0x58(%rsp)
   70737:      	cmpq	$0x13, %r12
   7073b:      	ja	0x70743 <f.2+0x17f93>
   7073d:      	addq	$-0x12, %r12
   70741:      	jmp	0x707b7 <f.2+0x18007>
   70743:      	movq	$0x0, 0x48(%rsp)
   7074c:      	movq	$0x3, 0x30(%rsp)
   70755:      	xorl	%edi, %edi
   70757:      	leaq	-0x13(%r12), %rsi
   7075c:      	callq	0x70870 <f.3>
   70761:      	subq	$0x8, %rsp
   70765:      	movq	%rax, 0x80(%rsp)
   7076d:      	cmpb	$0x0, 0x52dc(%rip)      # 0x75a50 <g.4>
   70774:      	je	0x7085f <f.2+0x180af>
   7077a:      	cmpq	$0x0, 0x52c6(%rip)      # 0x75a48 <g.3>
   70782:      	je	0x7085f <f.2+0x180af>
   70788:      	addq	$-0x14, %r12
   7078c:      	movq	$0x0, 0x48(%rsp)
   70795:      	movq	$0x3, 0x30(%rsp)
   7079e:      	xorl	%edi, %edi
   707a0:      	movq	%r12, %rsi
   707a3:      	callq	0x70870 <f.3>
   707a8:      	subq	$0x8, %rsp
   707ac:      	movq	%rax, %r12
   707af:      	addq	0x80(%rsp), %r12
   707b7:      	addq	0x58(%rsp), %r12
   707bc:      	movq	0x10(%rsp), %rcx
   707c1:      	movq	0x18(%rsp), %rdx
   707c6:      	movq	0x50(%rsp), %rsi
   707cb:      	movq	0x60(%rsp), %rax
   707d0:      	addq	%rax, %r12
   707d3:      	addq	%rsi, %r12
   707d6:      	addq	%rdx, %r12
   707d9:      	addq	%r15, %r12
   707dc:      	leaq	0x68(%rsp), %r15
   707e1:      	addq	%r14, %r12
   707e4:      	addq	%rcx, %r12
   707e7:      	addq	%rbp, %r12
   707ea:      	addq	%r13, %r12
   707ed:      	movq	0x40(%rsp), %r14
   707f2:      	testq	%r14, %r14
   707f5:      	je	0x7085f <f.2+0x180af>
   707f7:      	movq	0x10(%r14), %rax
   707fb:      	testq	%rax, %rax
   707fe:      	je	0x7085f <f.2+0x180af>
   70800:      	cmpl	$0x0, 0x8(%rax)
   70804:      	je	0x7085f <f.2+0x180af>
   70806:      	cmpq	$0x0, 0x10(%rax)
   7080b:      	je	0x7085f <f.2+0x180af>
   7080d:      	incq	%rbx
   70810:      	leaq	0x20(%rsp), %r13
   70815:      	movq	%r13, %rdi
   70818:      	callq	0x298b0 <native_roots_leave>
   7081d:      	movl	$0x3, %esi
   70822:      	movq	%r13, %rdi
   70825:      	callq	0x29860 <native_roots_enter>
   7082a:      	movq	%r14, 0x38(%rsp)
   7082f:      	movq	%r14, 0x40(%rsp)
   70834:      	cmpq	%rbx, 0x8(%r14)
   70838:      	jg	0x58810 <f.2+0x60>
   7083e:      	leaq	0x20(%rsp), %rdi
   70843:      	callq	0x298b0 <native_roots_leave>
   70848:      	movq	%r12, %rax
   7084b:      	addq	$0x88, %rsp
   70852:      	popq	%rbx
   70853:      	popq	%r12
   70855:      	popq	%r13
   70857:      	popq	%r14
   70859:      	popq	%r15
   7085b:      	popq	%rbp
   7085c:      	retq	$0x8
   7085f:      	callq	0x258f0 <native_trap>
   70864:      	int3
   70865:      	int3
   70866:      	int3
   70867:      	int3
   70868:      	int3
   70869:      	int3
   7086a:      	int3
   7086b:      	int3
   7086c:      	int3
   7086d:      	int3
   7086e:      	int3
   7086f:      	int3

0000000000070870 <f.3>:
   70870:      	pushq	%r14
   70872:      	pushq	%rbx
   70873:      	subq	$0x38, %rsp
   70877:      	movq	%rsi, %rbx
   7087a:      	movq	%rdi, %r14
   7087d:      	leaq	0x10(%rsp), %rdi
   70882:      	movl	$0x2, %esi
   70887:      	callq	0x29860 <native_roots_enter>
   7088c:      	movq	%r14, 0x28(%rsp)
   70891:      	cmpq	$0x2, %rbx
   70895:      	jl	0x70907 <f.3+0x97>
   70897:      	cmpb	$0x0, 0x51b2(%rip)      # 0x75a50 <g.4>
   7089e:      	je	0x7091e <f.3+0xae>
   708a0:      	cmpq	$0x0, 0x51a0(%rip)      # 0x75a48 <g.3>
   708a8:      	je	0x7091e <f.3+0xae>
   708aa:      	leaq	-0x1(%rbx), %rsi
   708ae:      	movq	%r14, 0x30(%rsp)
   708b3:      	movq	$0x2, 0x20(%rsp)
   708bc:      	movq	%r14, %rdi
   708bf:      	callq	0x70870 <f.3>
   708c4:      	subq	$0x8, %rsp
   708c8:      	cmpb	$0x0, 0x5181(%rip)      # 0x75a50 <g.4>
   708cf:      	je	0x7091e <f.3+0xae>
   708d1:      	cmpq	$0x0, 0x516f(%rip)      # 0x75a48 <g.3>
   708d9:      	je	0x7091e <f.3+0xae>
   708db:      	movq	%rax, %r14
   708de:      	movq	0x28(%rsp), %rdi
   708e3:      	addq	$-0x2, %rbx
   708e7:      	movq	%rdi, 0x30(%rsp)
   708ec:      	movq	$0x2, 0x20(%rsp)
   708f5:      	movq	%rbx, %rsi
   708f8:      	callq	0x70870 <f.3>
   708fd:      	subq	$0x8, %rsp
   70901:      	movq	%rax, %rbx
   70904:      	addq	%r14, %rbx
   70907:      	leaq	0x10(%rsp), %rdi
   7090c:      	callq	0x298b0 <native_roots_leave>
   70911:      	movq	%rbx, %rax
   70914:      	addq	$0x38, %rsp
   70918:      	popq	%rbx
   70919:      	popq	%r14
   7091b:      	retq	$0x8
   7091e:      	callq	0x258f0 <native_trap>
   70923:      	int3
   70924:      	int3
   70925:      	int3
   70926:      	int3
   70927:      	int3
   70928:      	int3
   70929:      	int3
   7092a:      	int3
   7092b:      	int3
   7092c:      	int3
   7092d:      	int3
   7092e:      	int3
   7092f:      	int3

0000000000070930 <f.4>:
   70930:      	pushq	%r15
   70932:      	pushq	%r14
   70934:      	pushq	%rbx
   70935:      	subq	$0x40, %rsp
   70939:      	movq	%rdx, %rbx
   7093c:      	movq	%rdi, %r14
   7093f:      	leaq	0x8(%rsp), %r15
   70944:      	movl	$0x1, %esi
   70949:      	movq	%r15, %rdi
   7094c:      	callq	0x29860 <native_roots_enter>
   70951:      	movq	%r14, 0x20(%rsp)
   70956:      	movq	$0x1, 0x18(%rsp)
   7095f:      	leaq	0x28(%rsp), %r14
   70964:      	movq	%r14, %rdi
   70967:      	xorl	%esi, %esi
   70969:      	callq	0x29860 <native_roots_enter>
   7096e:      	movq	$0x0, 0x38(%rsp)
   70977:      	movq	%rbx, %rdi
   7097a:      	callq	0x13700 <hide_i64>
   7097f:      	movq	%rax, %rbx
   70982:      	movq	%r14, %rdi
   70985:      	callq	0x298b0 <native_roots_leave>
   7098a:      	movq	%r15, %rdi
   7098d:      	callq	0x298b0 <native_roots_leave>
   70992:      	movq	%rbx, %rax
   70995:      	addq	$0x40, %rsp
   70999:      	popq	%rbx
   7099a:      	popq	%r14
   7099c:      	popq	%r15
   7099e:      	retq	$0x8
   709a1:      	int3
   709a2:      	int3
   709a3:      	int3
   709a4:      	int3
   709a5:      	int3
   709a6:      	int3
   709a7:      	int3
   709a8:      	int3
   709a9:      	int3
   709aa:      	int3
   709ab:      	int3
   709ac:      	int3
   709ad:      	int3
   709ae:      	int3
   709af:      	int3
