000000000004ad00 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79>:
   4ad00:      	pushq	%rbp
   4ad01:      	pushq	%r15
   4ad03:      	pushq	%r14
   4ad05:      	pushq	%r13
   4ad07:      	pushq	%r12
   4ad09:      	pushq	%rbx
   4ad0a:      	subq	$0x3c8, %rsp            # imm = 0x3C8
   4ad11:      	cmpq	$0x0, 0x28aa7(%rip)     # 0x737c0 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ad19:      	jne	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4ad1f:      	movl	$0xd8, %edi
   4ad24:      	callq	*0x26f9e(%rip)          # 0x71cc8 <writev+0x71cc8>
   4ad2a:      	testq	%rax, %rax
   4ad2d:      	je	0x4bd4c <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x104c>
   4ad33:      	movq	%rax, %r14
   4ad36:      	movq	$0x0, (%rax)
   4ad3d:      	movq	$0x4, 0x8(%rax)
   4ad45:      	movq	$0x0, 0x10(%rax)
   4ad4d:      	movl	$0x4, %ebx
   4ad52:      	movl	$0x4, %edi
   4ad57:      	callq	*0x26f6b(%rip)          # 0x71cc8 <writev+0x71cc8>
   4ad5d:      	testq	%rax, %rax
   4ad60:      	je	0x4bd44 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1044>
   4ad66:      	movl	$0x2, (%rax)
   4ad6c:      	movq	$0x1, 0x18(%r14)
   4ad74:      	movq	%rax, 0x20(%r14)
   4ad78:      	movq	$0x1, 0x28(%r14)
   4ad80:      	movl	$0x4, %ebx
   4ad85:      	movl	$0x4, %edi
   4ad8a:      	callq	*0x26f38(%rip)          # 0x71cc8 <writev+0x71cc8>
   4ad90:      	testq	%rax, %rax
   4ad93:      	je	0x4bd44 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1044>
   4ad99:      	movl	$0x2, (%rax)
   4ad9f:      	movq	$0x1, 0x30(%r14)
   4ada7:      	movq	%rax, 0x38(%r14)
   4adab:      	movq	$0x1, 0x40(%r14)
   4adb3:      	movq	$0x0, 0x48(%r14)
   4adbb:      	movq	$0x4, 0x50(%r14)
   4adc3:      	xorps	%xmm0, %xmm0
   4adc6:      	movups	%xmm0, 0x58(%r14)
   4adcb:      	movq	$0x4, 0x68(%r14)
   4add3:      	movq	$0x0, 0x70(%r14)
   4addb:      	movl	$0x8, %ebx
   4ade0:      	movl	$0x8, %edi
   4ade5:      	callq	*0x26edd(%rip)          # 0x71cc8 <writev+0x71cc8>
   4adeb:      	testq	%rax, %rax
   4adee:      	je	0x4bd44 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1044>
   4adf4:      	movabsq	$0x200000001, %rcx      # imm = 0x200000001
   4adfe:      	movq	%rcx, (%rax)
   4ae01:      	movq	$0x2, 0x78(%r14)
   4ae09:      	movq	%rax, 0x80(%r14)
   4ae10:      	movq	$0x2, 0x88(%r14)
   4ae1b:      	movq	$0x0, 0x90(%r14)
   4ae26:      	movq	$0x4, 0x98(%r14)
   4ae31:      	xorps	%xmm0, %xmm0
   4ae34:      	movups	%xmm0, 0xa0(%r14)
   4ae3c:      	movq	$0x4, 0xb0(%r14)
   4ae47:      	movups	%xmm0, 0xb8(%r14)
   4ae4f:      	movq	$0x4, 0xc8(%r14)
   4ae5a:      	movq	$0x0, 0xd0(%r14)
   4ae65:      	movl	$0x18, %edi
   4ae6a:      	callq	*0x26e58(%rip)          # 0x71cc8 <writev+0x71cc8>
   4ae70:      	testq	%rax, %rax
   4ae73:      	je	0x4bd56 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1056>
   4ae79:      	movq	%rax, %r15
   4ae7c:      	movq	0x26b7d(%rip), %rax     # 0x71a00 <native_gc_globals+0x10>
   4ae83:      	movq	%rax, 0x10(%r15)
   4ae87:      	movapd	0x26b61(%rip), %xmm0    # 0x719f0 <native_gc_globals>
   4ae8f:      	movupd	%xmm0, (%r15)
   4ae94:      	movl	$0x1, %edi
   4ae99:      	movl	$0x48, %esi
   4ae9e:      	callq	*0x26d7c(%rip)          # 0x71c20 <writev+0x71c20>
   4aea4:      	testq	%rax, %rax
   4aea7:      	je	0x4bd60 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1060>
   4aead:      	movq	%rax, %rbp
   4aeb0:      	movabsq	$0x3fffffffffff8000, %r13 # imm = 0x3FFFFFFFFFFF8000
   4aeba:      	leaq	-0x42616(%rip), %rsi    # 0x88ab <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4aec1:      	leaq	0x80(%rsp), %rdi
   4aec9:      	movl	$0x13, %edx
   4aece:      	callq	0x54040 <std::env::_var_os>
   4aed3:      	movq	0x80(%rsp), %rax
   4aedb:      	negq	%rax
   4aede:      	jo	0x4af22 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x222>
   4aee0:      	jae	0x4aef0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1f0>
   4aee2:      	movq	0x88(%rsp), %rdi
   4aeea:      	callq	*0x26d38(%rip)          # 0x71c28 <writev+0x71c28>
   4aef0:      	leaq	-0x4264c(%rip), %rdi    # 0x88ab <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4aef7:      	movl	$0x13, %esi
   4aefc:      	xorl	%edx, %edx
   4aefe:      	callq	0x54230 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4af03:      	movq	%rax, %rdx
   4af06:      	addq	$-0x8000, %rax          # imm = 0x8000
   4af0c:      	cmpq	%r13, %rax
   4af0f:      	jae	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4af15:      	andq	%r13, %rdx
   4af18:      	movq	%rdx, %rbx
   4af1b:      	movq	%rdx, 0x18(%rsp)
   4af20:      	jmp	0x4af33 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x233>
   4af22:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4af27:      	movq	$0x0, 0x18(%rsp)
   4af30:      	movq	%r13, %rbx
   4af33:      	leaq	-0x4267c(%rip), %rdi    # 0x88be <core::num::flt2dec::strategy::dragon::POW5TO256+0x60a>
   4af3a:      	movl	$0x16, %esi
   4af3f:      	callq	0x54230 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4af44:      	movq	%rax, %r12
   4af47:      	addq	$-0x8000, %rax          # imm = 0x8000
   4af4d:      	cmpq	%r13, %rax
   4af50:      	jae	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4af56:      	movq	%rbp, 0x38(%rsp)
   4af5b:      	andq	%r13, %r12
   4af5e:      	cmpq	%rbx, %r12
   4af61:      	ja	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4af67:      	leaq	-0x4269a(%rip), %rdi    # 0x88d4 <core::num::flt2dec::strategy::dragon::POW5TO256+0x620>
   4af6e:      	movl	$0x12, %esi
   4af73:      	movl	$0x800000, %edx         # imm = 0x800000
   4af78:      	callq	0x54230 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4af7d:      	movq	%rax, %r13
   4af80:      	leaq	-0x426a1(%rip), %rsi    # 0x88e6 <core::num::flt2dec::strategy::dragon::POW5TO256+0x632>
   4af87:      	leaq	0x80(%rsp), %rdi
   4af8f:      	movl	$0xe, %edx
   4af94:      	callq	0x54040 <std::env::_var_os>
   4af99:      	movq	0x80(%rsp), %rax
   4afa1:      	movq	%rax, %rcx
   4afa4:      	negq	%rcx
   4afa7:      	setno	%bpl
   4afab:      	testq	%rax, %rax
   4afae:      	jle	0x4afbe <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x2be>
   4afb0:      	movq	0x88(%rsp), %rdi
   4afb8:      	callq	*0x26c6a(%rip)          # 0x71c28 <writev+0x71c28>
   4afbe:      	movq	$0x0, 0x80(%rsp)
   4afca:      	movq	$0x8, 0x88(%rsp)
   4afd6:      	xorpd	%xmm0, %xmm0
   4afda:      	movupd	%xmm0, 0x90(%rsp)
   4afe3:      	movupd	%xmm0, 0x138(%rsp)
   4afec:      	movupd	%xmm0, 0x148(%rsp)
   4aff5:      	movupd	%xmm0, 0x158(%rsp)
   4affe:      	movq	%r12, 0x110(%rsp)
   4b006:      	movq	%rbx, 0x118(%rsp)
   4b00e:      	movq	0x18(%rsp), %rax
   4b013:      	movq	%rax, 0x120(%rsp)
   4b01b:      	movq	%r13, 0x128(%rsp)
   4b023:      	movb	%bpl, 0x130(%rsp)
   4b02b:      	movq	%r13, 0x168(%rsp)
   4b033:      	movq	$0x8, 0xa0(%rsp)
   4b03f:      	movupd	%xmm0, 0xa8(%rsp)
   4b048:      	movq	$0x8, 0xb8(%rsp)
   4b054:      	movq	$0x0, 0xc0(%rsp)
   4b060:      	movq	$0x9, 0xc8(%rsp)
   4b06c:      	movq	%r14, 0xd0(%rsp)
   4b074:      	movq	$0x9, 0xd8(%rsp)
   4b080:      	movq	$0x3, 0xe0(%rsp)
   4b08c:      	movq	%r15, 0xe8(%rsp)
   4b094:      	movq	$0x3, 0xf0(%rsp)
   4b0a0:      	movq	$0x0, 0xf8(%rsp)
   4b0ac:      	movq	$0x8, 0x100(%rsp)
   4b0b8:      	movq	$0x0, 0x108(%rsp)
   4b0c4:      	movupd	%xmm0, 0x1c0(%rsp)
   4b0cd:      	movupd	%xmm0, 0x1b0(%rsp)
   4b0d6:      	movupd	%xmm0, 0x1a0(%rsp)
   4b0df:      	movupd	%xmm0, 0x190(%rsp)
   4b0e8:      	movupd	%xmm0, 0x180(%rsp)
   4b0f1:      	movupd	%xmm0, 0x170(%rsp)
   4b0fa:      	movq	$0x0, 0x1d0(%rsp)
   4b106:      	leaq	0x80(%rsp), %rdi
   4b10e:      	movq	%r12, %rsi
   4b111:      	callq	0x54480 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4b116:      	movq	0x80(%rsp), %rbp
   4b11e:      	movq	0x88(%rsp), %rcx
   4b126:      	movq	%rcx, 0x28(%rsp)
   4b12b:      	movq	0x90(%rsp), %r15
   4b133:      	movq	0x98(%rsp), %rcx
   4b13b:      	movq	%rcx, 0x68(%rsp)
   4b140:      	movq	0xa0(%rsp), %rcx
   4b148:      	movq	%rcx, 0x40(%rsp)
   4b14d:      	movq	0xb0(%rsp), %rcx
   4b155:      	movq	%rcx, 0x70(%rsp)
   4b15a:      	movq	0xb8(%rsp), %rcx
   4b162:      	movq	%rcx, 0x48(%rsp)
   4b167:      	movq	0xc8(%rsp), %rcx
   4b16f:      	movq	%rcx, 0x78(%rsp)
   4b174:      	movq	0xd0(%rsp), %rcx
   4b17c:      	movq	%rcx, 0x30(%rsp)
   4b181:      	movq	0xd8(%rsp), %rcx
   4b189:      	movq	%rcx, 0x58(%rsp)
   4b18e:      	movq	0xe0(%rsp), %rcx
   4b196:      	movq	%rcx, 0x18(%rsp)
   4b19b:      	movq	0xe8(%rsp), %r13
   4b1a3:      	movq	0xf8(%rsp), %r14
   4b1ab:      	movq	0x100(%rsp), %r12
   4b1b3:      	testb	%al, %al
   4b1b5:      	movq	%r13, 0x50(%rsp)
   4b1ba:      	movq	%rbp, 0x60(%rsp)
   4b1bf:      	je	0x4bd6a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x106a>
   4b1c5:      	movabsq	$-0x8000000000000000, %rbx # imm = 0x8000000000000000
   4b1cf:      	leaq	0x108(%rsp), %rsi
   4b1d7:      	movq	0xf0(%rsp), %rax
   4b1df:      	movq	%rax, 0x210(%rsp)
   4b1e7:      	movq	0xa8(%rsp), %rax
   4b1ef:      	movq	%rax, 0x200(%rsp)
   4b1f7:      	movq	0xc0(%rsp), %rax
   4b1ff:      	movq	%rax, 0x208(%rsp)
   4b207:      	leaq	0x228(%rsp), %rdi
   4b20f:      	movl	$0xd0, %edx
   4b214:      	callq	*0x26ba6(%rip)          # 0x71dc0 <writev+0x71dc0>
   4b21a:      	cmpq	%rbx, %rbp
   4b21d:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b223:      	leaq	0x2f8(%rsp), %rdi
   4b22b:      	leaq	0x228(%rsp), %rsi
   4b233:      	movl	$0xd0, %edx
   4b238:      	callq	*0x26b82(%rip)          # 0x71dc0 <writev+0x71dc0>
   4b23e:      	movupd	-0x4273b(%rip), %xmm0   # 0x8b0b <core::num::flt2dec::strategy::dragon::POW5TO256+0x857>
   4b246:      	movapd	%xmm0, 0x80(%rsp)
   4b24f:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4b259:      	movq	%rax, 0x90(%rsp)
   4b261:      	movb	$0x0, 0x98(%rsp)
   4b269:      	movb	$0x1, %al
   4b26b:      	testb	%al, %al
   4b26d:      	je	0x4b27b <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x57b>
   4b26f:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4b279:      	jmp	0x4b297 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x597>
   4b27b:      	xorl	%eax, %eax
   4b27d:      	nopl	(%rax)
   4b280:      	cmpb	$0x0, 0x80(%rsp,%rax)
   4b288:      	je	0x4b303 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x603>
   4b28a:      	incq	%rax
   4b28d:      	jne	0x4b280 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x580>
   4b28f:      	movq	0x80(%rsp), %rax
   4b297:      	movq	0x88(%rsp), %rcx
   4b29f:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4b2a9:      	movq	%rdx, %rsi
   4b2ac:      	subq	%rax, %rsi
   4b2af:      	orq	%rax, %rsi
   4b2b2:      	subq	%rcx, %rdx
   4b2b5:      	orq	%rcx, %rdx
   4b2b8:      	andq	%rsi, %rdx
   4b2bb:      	notq	%rdx
   4b2be:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4b2c8:      	xorl	%ecx, %ecx
   4b2ca:      	testq	%rax, %rdx
   4b2cd:      	sete	%cl
   4b2d0:      	shll	$0x4, %ecx
   4b2d3:      	leaq	(%rsp,%rcx), %rdx
   4b2d7:      	addq	$0x80, %rdx
   4b2de:      	movq	%rcx, %rsi
   4b2e1:      	xorq	$0x19, %rsi
   4b2e5:      	xorl	%eax, %eax
   4b2e7:      	nopw	(%rax,%rax)
   4b2f0:      	cmpb	$0x0, (%rdx,%rax)
   4b2f4:      	je	0x4b300 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x600>
   4b2f6:      	incq	%rax
   4b2f9:      	cmpq	%rax, %rsi
   4b2fc:      	jne	0x4b2f0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x5f0>
   4b2fe:      	jmp	0x4b347 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x647>
   4b300:      	addq	%rcx, %rax
   4b303:      	cmpq	$0x18, %rax
   4b307:      	jne	0x4b347 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x647>
   4b309:      	movq	%r12, 0x10(%rsp)
   4b30e:      	leaq	0x228(%rsp), %rdi
   4b316:      	leaq	0x80(%rsp), %rsi
   4b31e:      	callq	0x45f30 <std::sys::env::unix::getenv::{closure#0}>
   4b323:      	movq	0x228(%rsp), %r12
   4b32b:      	leaq	0x1(%rbx), %rax
   4b32f:      	cmpq	%rax, %r12
   4b332:      	jne	0x4b97a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc7a>
   4b338:      	movq	0x230(%rsp), %rax
   4b340:      	movq	0x10(%rsp), %r12
   4b345:      	jmp	0x4b35a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x65a>
   4b347:      	leaq	0x1(%rbx), %rax
   4b34b:      	movq	%rax, 0x228(%rsp)
   4b353:      	leaq	0x25b56(%rip), %rax     # 0x70eb0 <writev+0x70eb0>
   4b35a:      	movl	%eax, %ecx
   4b35c:      	andl	$0x3, %ecx
   4b35f:      	leal	-0x2(%rcx), %edx
   4b362:      	cmpl	$0x2, %edx
   4b365:      	jb	0x4b3a5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a5>
   4b367:      	testq	%rcx, %rcx
   4b36a:      	je	0x4b3a5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a5>
   4b36c:      	leaq	-0x1(%rax), %rcx
   4b370:      	movq	%rcx, 0x10(%rsp)
   4b375:      	movq	-0x1(%rax), %r13
   4b379:      	movq	0x7(%rax), %rbx
   4b37d:      	movq	(%rbx), %rax
   4b380:      	testq	%rax, %rax
   4b383:      	je	0x4b38a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x68a>
   4b385:      	movq	%r13, %rdi
   4b388:      	callq	*%rax
   4b38a:      	cmpq	$0x0, 0x8(%rbx)
   4b38f:      	je	0x4b39a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x69a>
   4b391:      	movq	%r13, %rdi
   4b394:      	callq	*0x2688e(%rip)          # 0x71c28 <writev+0x71c28>
   4b39a:      	movq	0x10(%rsp), %rdi
   4b39f:      	callq	*0x26883(%rip)          # 0x71c28 <writev+0x71c28>
   4b3a5:      	xorl	%r13d, %r13d
   4b3a8:      	movl	$0x180, %edi            # imm = 0x180
   4b3ad:      	callq	*0x26915(%rip)          # 0x71cc8 <writev+0x71cc8>
   4b3b3:      	testq	%rax, %rax
   4b3b6:      	je	0x4bae3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xde3>
   4b3bc:      	movq	%rax, %rbx
   4b3bf:      	movq	0x60(%rsp), %rcx
   4b3c4:      	movq	%rcx, (%rax)
   4b3c7:      	movq	0x28(%rsp), %rcx
   4b3cc:      	movq	%rcx, 0x8(%rax)
   4b3d0:      	movq	%r15, 0x10(%rax)
   4b3d4:      	movq	0x68(%rsp), %rcx
   4b3d9:      	movq	%rcx, 0x18(%rax)
   4b3dd:      	movq	0x40(%rsp), %rcx
   4b3e2:      	movq	%rcx, 0x20(%rax)
   4b3e6:      	movq	0x200(%rsp), %rcx
   4b3ee:      	movq	%rcx, 0x28(%rax)
   4b3f2:      	movq	0x70(%rsp), %rcx
   4b3f7:      	movq	%rcx, 0x30(%rax)
   4b3fb:      	movq	0x48(%rsp), %rcx
   4b400:      	movq	%rcx, 0x38(%rax)
   4b404:      	movq	0x208(%rsp), %rcx
   4b40c:      	movq	%rcx, 0x40(%rax)
   4b410:      	movq	0x78(%rsp), %rcx
   4b415:      	movq	%rcx, 0x48(%rax)
   4b419:      	movq	0x30(%rsp), %rcx
   4b41e:      	movq	%rcx, 0x50(%rax)
   4b422:      	movq	0x58(%rsp), %rcx
   4b427:      	movq	%rcx, 0x58(%rax)
   4b42b:      	movq	0x18(%rsp), %rcx
   4b430:      	movq	%rcx, 0x60(%rax)
   4b434:      	movq	0x50(%rsp), %rcx
   4b439:      	movq	%rcx, 0x68(%rax)
   4b43d:      	movq	0x210(%rsp), %rcx
   4b445:      	movq	%rcx, 0x70(%rax)
   4b449:      	movq	%r14, 0x78(%rax)
   4b44d:      	movq	%r12, 0x80(%rax)
   4b454:      	addq	$0x88, %rax
   4b45a:      	leaq	0x2f8(%rsp), %rsi
   4b462:      	movl	$0xd0, %edx
   4b467:      	movq	%rax, %rdi
   4b46a:      	callq	*0x26950(%rip)          # 0x71dc0 <writev+0x71dc0>
   4b470:      	movq	$0x9, 0x158(%rbx)
   4b47b:      	movq	0x38(%rsp), %rax
   4b480:      	movq	%rax, 0x160(%rbx)
   4b487:      	movq	$0x9, 0x168(%rbx)
   4b492:      	movq	$0x0, 0x170(%rbx)
   4b49d:      	movq	%r13, 0x178(%rbx)
   4b4a4:      	movq	%rbx, 0x28315(%rip)     # 0x737c0 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b4ab:      	leaq	0x91be(%rip), %rdi      # 0x54670 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4b4b2:      	callq	0x11da0 <atexit>
   4b4b7:      	movq	$0x2, 0x88(%rsp)
   4b4c3:      	movq	$0x0, 0x90(%rsp)
   4b4cf:      	movq	0x282f2(%rip), %rax     # 0x737c8 <native_roots.0>
   4b4d6:      	movq	%rax, 0x80(%rsp)
   4b4de:      	movq	0x282c3(%rip), %rax     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b4e5:      	incq	%rax
   4b4e8:      	movq	%rax, 0x282b9(%rip)     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b4ef:      	movq	0x282ba(%rip), %rcx     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b4f6:      	cmpq	%rcx, %rax
   4b4f9:      	cmovbeq	%rcx, %rax
   4b4fd:      	leaq	0x80(%rsp), %r14
   4b505:      	movq	%r14, 0x282bc(%rip)     # 0x737c8 <native_roots.0>
   4b50c:      	movq	%rax, 0x2829d(%rip)     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b513:      	cmpl	$0x0, 0x2837a(%rip)     # 0x73894 <g.0>
   4b51a:      	jne	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b520:      	movl	$0x1, 0x2836a(%rip)     # 0x73894 <g.0>
   4b52a:      	movq	$0x0, 0x98(%rsp)
   4b536:      	leaq	0x2649b(%rip), %rbx     # 0x719d8 <ref.4>
   4b53d:      	movq	%rbx, 0xa0(%rsp)
   4b545:      	movq	$0x2, 0x90(%rsp)
   4b551:      	movl	$0x18, %edi
   4b556:      	callq	0x55540 <native_alloc>
   4b55b:      	movq	$0x1a, (%rax)
   4b562:      	movq	%rbx, 0x8(%rax)
   4b566:      	movq	$0x0, 0x10(%rax)
   4b56e:      	movq	%rax, 0x28323(%rip)     # 0x73898 <g.1>
   4b575:      	movb	$0x1, 0x28324(%rip)     # 0x738a0 <g.2>
   4b57c:      	movq	$0x0, 0x90(%rsp)
   4b588:      	movl	$0x8, %edi
   4b58d:      	callq	0x55540 <native_alloc>
   4b592:      	movq	$0x16, (%rax)
   4b599:      	movq	%rax, 0x28308(%rip)     # 0x738a8 <g.3>
   4b5a0:      	movb	$0x1, 0x28309(%rip)     # 0x738b0 <g.4>
   4b5a7:      	movq	$0x0, 0x90(%rsp)
   4b5b3:      	movq	$0x28, 0x228(%rsp)
   4b5bf:      	leaq	0x228(%rsp), %rax
   4b5c7:      	movq	0x228(%rsp), %rax
   4b5cf:      	movq	%rax, 0x282e2(%rip)     # 0x738b8 <g.5>
   4b5d6:      	movb	$0x1, 0x282e3(%rip)     # 0x738c0 <g.6>
   4b5dd:      	movq	$0x0, 0x90(%rsp)
   4b5e9:      	movl	$0x8, %edi
   4b5ee:      	callq	0x55540 <native_alloc>
   4b5f3:      	movq	$0x16, (%rax)
   4b5fa:      	movq	%rax, 0x282c7(%rip)     # 0x738c8 <g.7>
   4b601:      	movl	$0x2, 0x28289(%rip)     # 0x73894 <g.0>
   4b60b:      	cmpq	$0x0, 0x88(%rsp)
   4b614:      	je	0x4b62c <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x92c>
   4b616:      	movq	0x80(%rsp), %rax
   4b61e:      	movq	%rax, 0x281a3(%rip)     # 0x737c8 <native_roots.0>
   4b625:      	decq	0x2817c(%rip)           # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b62c:      	callq	0x4c030 <<std::sys::pal::unix::time::Timespec>::now>
   4b631:      	movq	%rax, %rbx
   4b634:      	movq	$0x5, 0x88(%rsp)
   4b640:      	movq	$0x0, 0x90(%rsp)
   4b64c:      	movq	0x28175(%rip), %rax     # 0x737c8 <native_roots.0>
   4b653:      	movq	%rax, 0x80(%rsp)
   4b65b:      	movq	%r14, 0x28166(%rip)     # 0x737c8 <native_roots.0>
   4b662:      	movq	0x2813f(%rip), %rax     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b669:      	incq	%rax
   4b66c:      	movq	%rax, 0x28135(%rip)     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b673:      	movq	0x28136(%rip), %rcx     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b67a:      	cmpq	%rcx, %rax
   4b67d:      	cmovbeq	%rcx, %rax
   4b681:      	movq	%rax, 0x28128(%rip)     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b688:      	xorpd	%xmm0, %xmm0
   4b68c:      	movupd	%xmm0, 0x98(%rsp)
   4b695:      	cmpl	$0x2, 0x281f8(%rip)     # 0x73894 <g.0>
   4b69c:      	jne	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b6a2:      	cmpq	$0x0, 0x2821e(%rip)     # 0x738c8 <g.7>
   4b6aa:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b6b0:      	movl	%edx, %ebp
   4b6b2:      	movq	$0x2, 0x90(%rsp)
   4b6be:      	movl	$0x18, %edi
   4b6c3:      	callq	0x55540 <native_alloc>
   4b6c8:      	movq	%rax, %r14
   4b6cb:      	movq	$0xa, (%rax)
   4b6d2:      	movl	$0x0, 0x8(%rax)
   4b6d9:      	movq	$0x0, 0x10(%rax)
   4b6e1:      	movq	%rax, 0x98(%rsp)
   4b6e9:      	movq	%rax, 0xa8(%rsp)
   4b6f1:      	leaq	0x262d0(%rip), %r12     # 0x719c8 <ref.2>
   4b6f8:      	movq	%r12, 0xb0(%rsp)
   4b700:      	movq	%rax, 0xb8(%rsp)
   4b708:      	movq	$0x5, 0x90(%rsp)
   4b714:      	movl	$0x18, %edi
   4b719:      	callq	0x55540 <native_alloc>
   4b71e:      	movq	%rax, %r15
   4b721:      	movq	$0xe, (%rax)
   4b728:      	movq	$0x5, 0x8(%rax)
   4b730:      	movq	%r14, 0x10(%rax)
   4b734:      	movq	%rax, 0xa8(%rsp)
   4b73c:      	movq	%r12, 0xb0(%rsp)
   4b744:      	movq	%r14, 0xb8(%rsp)
   4b74c:      	movq	$0x5, 0x90(%rsp)
   4b758:      	movl	$0x18, %edi
   4b75d:      	callq	0x55540 <native_alloc>
   4b762:      	movq	$0x1a, (%rax)
   4b769:      	movq	%r12, 0x8(%rax)
   4b76d:      	movq	%r15, 0x10(%rax)
   4b771:      	movq	%rax, 0x10(%r14)
   4b775:      	movq	0x98(%rsp), %rax
   4b77d:      	testq	%rax, %rax
   4b780:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b786:      	movl	$0x1, 0x8(%rax)
   4b78d:      	movq	0x98(%rsp), %rax
   4b795:      	testq	%rax, %rax
   4b798:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b79e:      	cmpl	$0x0, 0x8(%rax)
   4b7a2:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b7a8:      	movq	0x10(%rax), %rax
   4b7ac:      	testq	%rax, %rax
   4b7af:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b7b5:      	movq	%rax, 0xa0(%rsp)
   4b7bd:      	movq	0x8(%rax), %rcx
   4b7c1:      	testq	%rcx, %rcx
   4b7c4:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4b7ca:      	movq	0x10(%rax), %rdi
   4b7ce:      	movq	0x8(%rcx), %rax
   4b7d2:      	cmpq	$0x0, 0x88(%rsp)
   4b7db:      	je	0x4b7f3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xaf3>
   4b7dd:      	movq	0x80(%rsp), %rcx
   4b7e5:      	movq	%rcx, 0x27fdc(%rip)     # 0x737c8 <native_roots.0>
   4b7ec:      	decq	0x27fb5(%rip)           # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b7f3:      	xorl	%esi, %esi
   4b7f5:      	xorl	%edx, %edx
   4b7f7:      	callq	*%rax
   4b7f9:      	subq	$0x8, %rsp
   4b7fd:      	movq	%rax, %r14
   4b800:      	movq	%rax, 0x218(%rsp)
   4b808:      	callq	0x4c030 <<std::sys::pal::unix::time::Timespec>::now>
   4b80d:      	movq	%rax, 0x2f8(%rsp)
   4b815:      	movl	%edx, 0x300(%rsp)
   4b81c:      	movq	%rbx, 0x228(%rsp)
   4b824:      	movl	%ebp, 0x230(%rsp)
   4b82b:      	leaq	0x80(%rsp), %rdi
   4b833:      	leaq	0x2f8(%rsp), %rbx
   4b83b:      	leaq	0x228(%rsp), %rdx
   4b843:      	movq	%rbx, %rsi
   4b846:      	callq	0x4c100 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4b84b:      	cmpb	$0x0, 0x80(%rsp)
   4b853:      	xorpd	%xmm0, %xmm0
   4b857:      	jne	0x4b895 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xb95>
   4b859:      	movsd	0x88(%rsp), %xmm1
   4b862:      	unpcklps	-0x47d09(%rip), %xmm1   # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x3b60 <writev+0x3b60>
   4b869:      	subpd	-0x47d71(%rip), %xmm1   # 0x3b00 <writev+0x3b00>
   4b871:      	movapd	%xmm1, %xmm2
   4b875:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   4b879:      	xorps	%xmm0, %xmm0
   4b87c:      	cvtsi2sdl	0x90(%rsp), %xmm0
   4b885:      	addsd	%xmm1, %xmm2
   4b889:      	divsd	-0x461b9(%rip), %xmm0   # 0x56d8 <writev+0x56d8>
   4b891:      	addsd	%xmm2, %xmm0
   4b895:      	movsd	%xmm0, 0x220(%rsp)
   4b89e:      	cmpq	$0x6197ecb, %r14        # imm = 0x6197ECB
   4b8a5:      	jne	0x4b94a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc4a>
   4b8ab:      	leaq	0x218(%rsp), %rax
   4b8b3:      	movq	%rax, 0x228(%rsp)
   4b8bb:      	leaq	0x121e(%rip), %rax      # 0x4cae0 <<i64 as core::fmt::Display>::fmt>
   4b8c2:      	movq	%rax, 0x230(%rsp)
   4b8ca:      	leaq	0x220(%rsp), %rax
   4b8d2:      	movq	%rax, 0x238(%rsp)
   4b8da:      	leaq	0x131f(%rip), %rax      # 0x4cc00 <<f64 as core::fmt::Display>::fmt>
   4b8e1:      	movq	%rax, 0x240(%rsp)
   4b8e9:      	leaq	-0x422e9(%rip), %rax    # 0x9607 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1353>
   4b8f0:      	movq	%rax, 0x2f8(%rsp)
   4b8f8:      	movq	$0x6, 0x300(%rsp)
   4b904:      	movl	0x2752e(%rip), %eax     # 0x72e38 <std::io::stdio::STDOUT+0x38>
   4b90a:      	testl	%eax, %eax
   4b90c:      	jne	0x4baed <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xded>
   4b912:      	movq	%fs:-0x8, %r14
   4b91b:      	testq	%r14, %r14
   4b91e:      	je	0x4bb04 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xe04>
   4b924:      	movq	0x274d5(%rip), %rax     # 0x72e00 <std::io::stdio::STDOUT>
   4b92b:      	cmpq	%rax, %r14
   4b92e:      	jne	0x4bb42 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xe42>
   4b934:      	movl	0x274d2(%rip), %ebp     # 0x72e0c <std::io::stdio::STDOUT+0xc>
   4b93a:      	cmpl	$-0x1, %ebp
   4b93d:      	je	0x4bca9 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xfa9>
   4b943:      	incl	%ebp
   4b945:      	jmp	0x4bb5e <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xe5e>
   4b94a:      	leaq	0x80(%rsp), %rdi
   4b952:      	callq	0x4c1d0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4b957:      	cmpq	$0x0, 0x80(%rsp)
   4b960:      	jle	0x4b970 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc70>
   4b962:      	movq	0x88(%rsp), %rdi
   4b96a:      	callq	*0x262b8(%rip)          # 0x71c28 <writev+0x71c28>
   4b970:      	movl	$0x1, %eax
   4b975:      	jmp	0x4bc92 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf92>
   4b97a:      	cmpq	%rbx, %r12
   4b97d:      	jne	0x4b98c <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc8c>
   4b97f:      	xorl	%r13d, %r13d
   4b982:      	movq	0x10(%rsp), %r12
   4b987:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4b98c:      	movq	0x230(%rsp), %rbx
   4b994:      	movq	0x238(%rsp), %rbp
   4b99c:      	leaq	0x80(%rsp), %rdi
   4b9a4:      	movq	%rbx, %rsi
   4b9a7:      	movq	%rbp, %rdx
   4b9aa:      	callq	0x19a10 <core::str::converts::from_utf8>
   4b9af:      	cmpb	$0x0, 0x80(%rsp)
   4b9b7:      	je	0x4b9cf <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xccf>
   4b9b9:      	xorl	%r13d, %r13d
   4b9bc:      	testq	%r12, %r12
   4b9bf:      	movq	0x10(%rsp), %r12
   4b9c4:      	jg	0x4bac3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdc3>
   4b9ca:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4b9cf:      	testq	%rbp, %rbp
   4b9d2:      	je	0x4b9f4 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xcf4>
   4b9d4:      	cmpq	$0x1, %rbp
   4b9d8:      	jne	0x4ba0a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xd0a>
   4b9da:      	movzbl	(%rbx), %eax
   4b9dd:      	xorl	%r13d, %r13d
   4b9e0:      	cmpl	$0x2b, %eax
   4b9e3:      	je	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4b9e9:      	cmpl	$0x2d, %eax
   4b9ec:      	je	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4b9f2:      	jmp	0x4ba0d <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xd0d>
   4b9f4:      	movq	%rbp, %r13
   4b9f7:      	testq	%r12, %r12
   4b9fa:      	movq	0x10(%rsp), %r12
   4b9ff:      	jne	0x4bac3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdc3>
   4ba05:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4ba0a:      	movzbl	(%rbx), %eax
   4ba0d:      	xorl	%ecx, %ecx
   4ba0f:      	cmpb	$0x2b, %al
   4ba11:      	sete	%cl
   4ba14:      	movq	%rcx, %rax
   4ba17:      	negq	%rax
   4ba1a:      	movq	%rbp, %rdx
   4ba1d:      	subq	%rcx, %rdx
   4ba20:      	addq	%rbx, %rcx
   4ba23:      	cmpq	$0x11, %rdx
   4ba27:      	jae	0x4ba63 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xd63>
   4ba29:      	testq	%rdx, %rdx
   4ba2c:      	je	0x4baa0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xda0>
   4ba2e:      	addq	%rax, %rbp
   4ba31:      	negq	%rbp
   4ba34:      	xorl	%eax, %eax
   4ba36:      	xorl	%r13d, %r13d
   4ba39:      	movzbl	(%rcx,%rax), %edx
   4ba3d:      	addl	$-0x30, %edx
   4ba40:      	cmpl	$0x9, %edx
   4ba43:      	ja	0x4bab2 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb2>
   4ba45:      	leaq	(,%r13,4), %rsi
   4ba4d:      	addq	%r13, %rsi
   4ba50:      	movl	%edx, %edx
   4ba52:      	leaq	(%rdx,%rsi,2), %r13
   4ba56:      	incq	%rax
   4ba59:      	movq	%rbp, %rdx
   4ba5c:      	addq	%rax, %rdx
   4ba5f:      	jne	0x4ba39 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xd39>
   4ba61:      	jmp	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4ba63:      	addq	%rax, %rbp
   4ba66:      	negq	%rbp
   4ba69:      	xorl	%r13d, %r13d
   4ba6c:      	movl	$0xa, %esi
   4ba71:      	xorl	%edi, %edi
   4ba73:      	xorl	%eax, %eax
   4ba75:      	movq	%rbp, %rdx
   4ba78:      	addq	%rdi, %rdx
   4ba7b:      	je	0x4bad1 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdd1>
   4ba7d:      	mulq	%rsi
   4ba80:      	jo	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4ba82:      	movzbl	(%rcx,%rdi), %r8d
   4ba87:      	addl	$-0x30, %r8d
   4ba8b:      	addq	%r8, %rax
   4ba8e:      	setb	%dl
   4ba91:      	cmpl	$0x9, %r8d
   4ba95:      	ja	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4ba97:      	incq	%rdi
   4ba9a:      	testb	%dl, %dl
   4ba9c:      	je	0x4ba75 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xd75>
   4ba9e:      	jmp	0x4bab5 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdb5>
   4baa0:      	xorl	%r13d, %r13d
   4baa3:      	testq	%r12, %r12
   4baa6:      	movq	0x10(%rsp), %r12
   4baab:      	jne	0x4bac3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdc3>
   4baad:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4bab2:      	xorl	%r13d, %r13d
   4bab5:      	testq	%r12, %r12
   4bab8:      	movq	0x10(%rsp), %r12
   4babd:      	je	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4bac3:      	movq	%rbx, %rdi
   4bac6:      	callq	*0x2615c(%rip)          # 0x71c28 <writev+0x71c28>
   4bacc:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4bad1:      	movq	%rax, %r13
   4bad4:      	testq	%r12, %r12
   4bad7:      	movq	0x10(%rsp), %r12
   4badc:      	jne	0x4bac3 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xdc3>
   4bade:      	jmp	0x4b3a8 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x6a8>
   4bae3:      	movl	$0x180, %edi            # imm = 0x180
   4bae8:      	callq	0x12fb0 <alloc::alloc::handle_alloc_error>
   4baed:      	callq	0x4cc32 <<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::get_or_init<std::io::stdio::stdout::{closure#0}>::{closure#0}, !>>
   4baf2:      	movq	%fs:-0x8, %r14
   4bafb:      	testq	%r14, %r14
   4bafe:      	jne	0x4b924 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc24>
   4bb04:      	movq	0x27d4d(%rip), %rax     # 0x73858 <<std::thread::id::ThreadId>::new::COUNTER>
   4bb0b:      	nopl	(%rax,%rax)
   4bb10:      	cmpq	$-0x1, %rax
   4bb14:      	je	0x4bca4 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xfa4>
   4bb1a:      	leaq	0x1(%rax), %r14
   4bb1e:      	lock
   4bb1f:      	cmpxchgq	%r14, 0x27d31(%rip)     # 0x73858 <<std::thread::id::ThreadId>::new::COUNTER>
   4bb27:      	jne	0x4bb10 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xe10>
   4bb29:      	movq	%r14, %fs:-0x8
   4bb32:      	movq	0x272c7(%rip), %rax     # 0x72e00 <std::io::stdio::STDOUT>
   4bb39:      	cmpq	%rax, %r14
   4bb3c:      	je	0x4b934 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xc34>
   4bb42:      	movl	$0x1, %ebp
   4bb47:      	xorl	%eax, %eax
   4bb49:      	lock
   4bb4a:      	cmpxchgl	%ebp, 0x272b7(%rip)     # 0x72e08 <std::io::stdio::STDOUT+0x8>
   4bb51:      	jne	0x4bcc1 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xfc1>
   4bb57:      	movq	%r14, 0x272a2(%rip)     # 0x72e00 <std::io::stdio::STDOUT>
   4bb5e:      	movl	%ebp, 0x272a8(%rip)     # 0x72e0c <std::io::stdio::STDOUT+0xc>
   4bb64:      	leaq	0x27295(%rip), %rax     # 0x72e00 <std::io::stdio::STDOUT>
   4bb6b:      	movq	%rax, 0x20(%rsp)
   4bb70:      	leaq	0x20(%rsp), %r12
   4bb75:      	movq	%r12, 0x80(%rsp)
   4bb7d:      	leaq	0x88(%rsp), %r14
   4bb85:      	movq	$0x0, 0x88(%rsp)
   4bb91:      	leaq	0x25270(%rip), %rsi     # 0x70e08 <writev+0x70e08>
   4bb98:      	leaq	-0x46437(%rip), %rdx    # 0x5768 <writev+0x5768>
   4bb9f:      	leaq	0x80(%rsp), %rdi
   4bba7:      	leaq	0x228(%rsp), %rcx
   4bbaf:      	callq	0x12ab0 <core::fmt::write>
   4bbb4:      	movq	0x88(%rsp), %rcx
   4bbbc:      	testb	%al, %al
   4bbbe:      	je	0x4bbe0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xee0>
   4bbc0:      	movq	%rcx, %r15
   4bbc3:      	testq	%rcx, %rcx
   4bbc6:      	jne	0x4bc30 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf30>
   4bbc8:      	leaq	-0x42fa3(%rip), %rdi    # 0x8c2c <core::num::flt2dec::strategy::dragon::POW5TO256+0x978>
   4bbcf:      	leaq	0x251ea(%rip), %rdx     # 0x70dc0 <writev+0x70dc0>
   4bbd6:      	movl	$0xad, %esi
   4bbdb:      	callq	0x12fe0 <core::panicking::panic_fmt>
   4bbe0:      	testq	%rcx, %rcx
   4bbe3:      	je	0x4bc2d <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf2d>
   4bbe5:      	movl	%ecx, %eax
   4bbe7:      	andl	$0x3, %eax
   4bbea:      	xorl	%r15d, %r15d
   4bbed:      	leal	-0x2(%rax), %edx
   4bbf0:      	cmpl	$0x2, %edx
   4bbf3:      	jb	0x4bc30 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf30>
   4bbf5:      	testq	%rax, %rax
   4bbf8:      	je	0x4bc30 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf30>
   4bbfa:      	leaq	-0x1(%rcx), %r14
   4bbfe:      	movq	-0x1(%rcx), %r15
   4bc02:      	movq	0x7(%rcx), %r13
   4bc06:      	movq	(%r13), %rax
   4bc0a:      	testq	%rax, %rax
   4bc0d:      	je	0x4bc14 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf14>
   4bc0f:      	movq	%r15, %rdi
   4bc12:      	callq	*%rax
   4bc14:      	cmpq	$0x0, 0x8(%r13)
   4bc19:      	je	0x4bc24 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf24>
   4bc1b:      	movq	%r15, %rdi
   4bc1e:      	callq	*0x26004(%rip)          # 0x71c28 <writev+0x71c28>
   4bc24:      	movq	%r14, %rdi
   4bc27:      	callq	*0x25ffb(%rip)          # 0x71c28 <writev+0x71c28>
   4bc2d:      	xorl	%r15d, %r15d
   4bc30:      	movq	0x20(%rsp), %rsi
   4bc35:      	decl	0xc(%rsi)
   4bc38:      	jne	0x4bc4f <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf4f>
   4bc3a:      	movq	$0x0, (%rsi)
   4bc41:      	xorl	%eax, %eax
   4bc43:      	xchgl	%eax, 0x8(%rsi)
   4bc46:      	cmpl	$0x2, %eax
   4bc49:      	je	0x4bcd2 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xfd2>
   4bc4f:      	testq	%r15, %r15
   4bc52:      	jne	0x4bcf6 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xff6>
   4bc58:      	leaq	0x80(%rsp), %rdi
   4bc60:      	callq	0x4c1d0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4bc65:      	movq	0x80(%rsp), %rbx
   4bc6d:      	testq	%rbx, %rbx
   4bc70:      	jle	0x4bc80 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf80>
   4bc72:      	movq	0x88(%rsp), %rdi
   4bc7a:      	callq	*0x25fa8(%rip)          # 0x71c28 <writev+0x71c28>
   4bc80:      	xorl	%eax, %eax
   4bc82:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bc8c:      	cmpq	%rcx, %rbx
   4bc8f:      	setne	%al
   4bc92:      	addq	$0x3c8, %rsp            # imm = 0x3C8
   4bc99:      	popq	%rbx
   4bc9a:      	popq	%r12
   4bc9c:      	popq	%r13
   4bc9e:      	popq	%r14
   4bca0:      	popq	%r15
   4bca2:      	popq	%rbp
   4bca3:      	retq
   4bca4:      	callq	0x47650 <<std::thread::id::ThreadId>::new::exhausted>
   4bca9:      	leaq	-0x4288c(%rip), %rdi    # 0x9424 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1170>
   4bcb0:      	leaq	0x255c1(%rip), %rdx     # 0x71278 <writev+0x71278>
   4bcb7:      	movl	$0x26, %esi
   4bcbc:      	callq	0x4cc90 <core::option::expect_failed>
   4bcc1:      	leaq	0x27140(%rip), %rdi     # 0x72e08 <std::io::stdio::STDOUT+0x8>
   4bcc8:      	callq	0x462e0 <<std::sys::sync::mutex::futex::Mutex>::lock_contended>
   4bccd:      	jmp	0x4bb57 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xe57>
   4bcd2:      	addq	$0x8, %rsi
   4bcd6:      	movl	$0xca, %edi
   4bcdb:      	movl	$0x81, %edx
   4bce0:      	movl	$0x1, %ecx
   4bce5:      	xorl	%eax, %eax
   4bce7:      	callq	*0x25f43(%rip)          # 0x71c30 <writev+0x71c30>
   4bced:      	testq	%r15, %r15
   4bcf0:      	je	0x4bc58 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0xf58>
   4bcf6:      	movq	%r15, 0x20(%rsp)
   4bcfb:      	movq	%rbx, 0x80(%rsp)
   4bd03:      	leaq	-0x3347a(%rip), %rax    # 0x18890 <<&str as core::fmt::Display>::fmt>
   4bd0a:      	movq	%rax, 0x88(%rsp)
   4bd12:      	movq	%r12, 0x90(%rsp)
   4bd1a:      	leaq	0x154f(%rip), %rax      # 0x4d270 <<std::io::error::Error as core::fmt::Display>::fmt>
   4bd21:      	movq	%rax, 0x98(%rsp)
   4bd29:      	leaq	-0x4587d(%rip), %rdi    # 0x64b3 <writev+0x64b3>
   4bd30:      	leaq	0x25161(%rip), %rdx     # 0x70e98 <writev+0x70e98>
   4bd37:      	leaq	0x80(%rsp), %rsi
   4bd3f:      	callq	0x12fe0 <core::panicking::panic_fmt>
   4bd44:      	movq	%rbx, %rdi
   4bd47:      	callq	0x12fb0 <alloc::alloc::handle_alloc_error>
   4bd4c:      	movl	$0xd8, %edi
   4bd51:      	callq	0x12fb0 <alloc::alloc::handle_alloc_error>
   4bd56:      	movl	$0x18, %edi
   4bd5b:      	callq	0x12fb0 <alloc::alloc::handle_alloc_error>
   4bd60:      	movl	$0x48, %edi
   4bd65:      	callq	0x12fb0 <alloc::alloc::handle_alloc_error>
   4bd6a:      	movq	%r14, 0x38(%rsp)
   4bd6f:      	movq	%r12, 0x10(%rsp)
   4bd74:      	testq	%r15, %r15
   4bd77:      	jne	0x4bdac <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x10ac>
   4bd79:      	cmpq	$0x0, 0x60(%rsp)
   4bd7f:      	jne	0x4bdf7 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x10f7>
   4bd81:      	cmpq	$0x0, 0x68(%rsp)
   4bd87:      	jne	0x4be0e <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x110e>
   4bd8d:      	cmpq	$0x0, 0x70(%rsp)
   4bd93:      	jne	0x4be25 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1125>
   4bd99:      	movq	0x58(%rsp), %r15
   4bd9e:      	testq	%r15, %r15
   4bda1:      	je	0x4be3a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x113a>
   4bda7:      	jmp	0x4be57 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1157>
   4bdac:      	movq	0x28(%rsp), %rax
   4bdb1:      	leaq	0x18(%rax), %rbx
   4bdb5:      	movq	0x25e24(%rip), %r12     # 0x71be0 <writev+0x71be0>
   4bdbc:      	movq	0x25e65(%rip), %r13     # 0x71c28 <writev+0x71c28>
   4bdc3:      	jmp	0x4bdd9 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x10d9>
   4bdc5:      	nopw	%cs:(%rax,%rax)
   4bdd0:      	addq	$0x38, %rbx
   4bdd4:      	decq	%r15
   4bdd7:      	je	0x4bd79 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1079>
   4bdd9:      	movq	-0x8(%rbx), %rsi
   4bddd:      	movq	(%rbx), %rdi
   4bde0:      	shlq	$0xf, %rsi
   4bde4:      	callq	*%r12
   4bde7:      	cmpq	$0x0, -0x18(%rbx)
   4bdec:      	je	0x4bdd0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x10d0>
   4bdee:      	movq	-0x10(%rbx), %rdi
   4bdf2:      	callq	*%r13
   4bdf5:      	jmp	0x4bdd0 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x10d0>
   4bdf7:      	movq	0x28(%rsp), %rdi
   4bdfc:      	callq	*0x25e26(%rip)          # 0x71c28 <writev+0x71c28>
   4be02:      	cmpq	$0x0, 0x68(%rsp)
   4be08:      	je	0x4bd8d <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x108d>
   4be0e:      	movq	0x40(%rsp), %rdi
   4be13:      	callq	*0x25e0f(%rip)          # 0x71c28 <writev+0x71c28>
   4be19:      	cmpq	$0x0, 0x70(%rsp)
   4be1f:      	je	0x4bd99 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1099>
   4be25:      	movq	0x48(%rsp), %rdi
   4be2a:      	callq	*0x25df8(%rip)          # 0x71c28 <writev+0x71c28>
   4be30:      	movq	0x58(%rsp), %r15
   4be35:      	testq	%r15, %r15
   4be38:      	jne	0x4be57 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1157>
   4be3a:      	cmpq	$0x0, 0x78(%rsp)
   4be40:      	jne	0x4be88 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1188>
   4be42:      	cmpq	$0x0, 0x18(%rsp)
   4be48:      	jne	0x4be9b <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x119b>
   4be4a:      	cmpq	$0x0, 0x38(%rsp)
   4be50:      	jne	0x4beae <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x11ae>
   4be52:      	callq	0x54020 <native_trap>
   4be57:      	movq	0x30(%rsp), %rax
   4be5c:      	leaq	0x8(%rax), %rbx
   4be60:      	movq	0x25dc1(%rip), %r14     # 0x71c28 <writev+0x71c28>
   4be67:      	jmp	0x4be79 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1179>
   4be69:      	nopl	(%rax)
   4be70:      	addq	$0x18, %rbx
   4be74:      	decq	%r15
   4be77:      	je	0x4be3a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x113a>
   4be79:      	cmpq	$0x0, -0x8(%rbx)
   4be7e:      	jle	0x4be70 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1170>
   4be80:      	movq	(%rbx), %rdi
   4be83:      	callq	*%r14
   4be86:      	jmp	0x4be70 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1170>
   4be88:      	movq	0x30(%rsp), %rdi
   4be8d:      	callq	*0x25d95(%rip)          # 0x71c28 <writev+0x71c28>
   4be93:      	cmpq	$0x0, 0x18(%rsp)
   4be99:      	je	0x4be4a <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x114a>
   4be9b:      	movq	0x50(%rsp), %rdi
   4bea0:      	callq	*0x25d82(%rip)          # 0x71c28 <writev+0x71c28>
   4bea6:      	cmpq	$0x0, 0x38(%rsp)
   4beac:      	je	0x4be52 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1152>
   4beae:      	movq	0x10(%rsp), %rdi
   4beb3:      	callq	*0x25d6f(%rip)          # 0x71c28 <writev+0x71c28>
   4beb9:      	callq	0x54020 <native_trap>
   4bebe:      	movq	%rax, %rbp
   4bec1:      	cmpq	$0x0, 0x8(%r13)
   4bec6:      	je	0x4bed1 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x11d1>
   4bec8:      	movq	%r15, %rdi
   4becb:      	callq	*0x25d57(%rip)          # 0x71c28 <writev+0x71c28>
   4bed1:      	movq	%r14, %rdi
   4bed4:      	callq	*0x25d4e(%rip)          # 0x71c28 <writev+0x71c28>
   4beda:      	movq	0x20(%rsp), %rdi
   4bedf:      	callq	0x4d230 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4bee4:      	movq	%rbp, %rdi
   4bee7:      	callq	0x6eb90 <_Unwind_Resume@plt>
   4beec:      	movq	%rax, %rbp
   4beef:      	cmpq	$0x0, 0x8(%rbx)
   4bef4:      	je	0x4beff <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x11ff>
   4bef6:      	movq	%r13, %rdi
   4bef9:      	callq	*0x25d29(%rip)          # 0x71c28 <writev+0x71c28>
   4beff:      	movq	0x10(%rsp), %rdi
   4bf04:      	callq	*0x25d1e(%rip)          # 0x71c28 <writev+0x71c28>
   4bf0a:      	movq	%rbp, %rdi
   4bf0d:      	callq	0x6eb90 <_Unwind_Resume@plt>
   4bf12:      	movq	%rax, %rbp
   4bf15:      	cmpq	$0x0, 0x88(%rsp)
   4bf1e:      	je	0x4bf28 <wasm_native_e19353084526422f5373ddd10155676499010ab83fa0a097d5069c9dc3d1a61d::run::h2848d4bee2a3dd79+0x1228>
   4bf20:      	movq	%r14, %rdi
   4bf23:      	callq	0x20a10 <core::ptr::drop_in_place::<std::io::error::Error>>
   4bf28:      	movq	0x20(%rsp), %rdi
   4bf2d:      	callq	0x4d230 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4bf32:      	movq	%rbp, %rdi
   4bf35:      	callq	0x6eb90 <_Unwind_Resume@plt>
   4bf3a:      	callq	0x13a2c <core::panicking::panic_in_cleanup>
   4bf3f:      	movq	%rax, %rbp
   4bf42:      	leaq	0x20(%rsp), %rdi
   4bf47:      	callq	0x20a10 <core::ptr::drop_in_place::<std::io::error::Error>>
   4bf4c:      	movq	%rbp, %rdi
   4bf4f:      	callq	0x6eb90 <_Unwind_Resume@plt>
   4bf54:      	callq	0x13a2c <core::panicking::panic_in_cleanup>
   4bf59:      	int3
   4bf5a:      	int3
   4bf5b:      	int3
   4bf5c:      	int3
   4bf5d:      	int3
   4bf5e:      	int3
   4bf5f:      	int3
