0000000000059e10 <f.5>:
   59e10:      	pushq	%rbp
   59e11:      	pushq	%r15
   59e13:      	pushq	%r14
   59e15:      	pushq	%r13
   59e17:      	pushq	%r12
   59e19:      	pushq	%rbx
   59e1a:      	subq	$0x78, %rsp
   59e1e:      	movq	%rsi, %r13
   59e21:      	movq	%rdi, %r12
   59e24:      	leaq	0x8(%rsp), %rdi
   59e29:      	movl	$0x7, %esi
   59e2e:      	callq	0x2ac30 <native_roots_enter>
   59e33:      	movq	%r12, 0x20(%rsp)
   59e38:      	movq	$0x0, 0x28(%rsp)
   59e41:      	movq	$0x0, 0x30(%rsp)
   59e4a:      	movq	$0x0, 0x38(%rsp)
   59e53:      	movl	$0x76, %esi
   59e58:      	movq	%r12, %rdi
   59e5b:      	xorl	%edx, %edx
   59e5d:      	xorl	%ecx, %ecx
   59e5f:      	callq	0x2ab40 <native_ref_test>
   59e64:      	testl	%eax, %eax
   59e66:      	je	0x5a294 <f.5+0x484>
   59e6c:      	decq	%r13
   59e6f:      	leaq	0x6062(%rip), %rbx      # 0x5fed8 <ref.19>
   59e76:      	nopw	%cs:(%rax,%rax)
   59e80:      	testq	%r12, %r12
   59e83:      	je	0x5a294 <f.5+0x484>
   59e89:      	incq	%r13
   59e8c:      	cmpq	0x8(%r12), %r13
   59e91:      	je	0x5a299 <f.5+0x489>
   59e97:      	movq	0x20(%rsp), %rdi
   59e9c:      	movl	$0x76, %esi
   59ea1:      	xorl	%edx, %edx
   59ea3:      	xorl	%ecx, %ecx
   59ea5:      	callq	0x2ab40 <native_ref_test>
   59eaa:      	testl	%eax, %eax
   59eac:      	je	0x5a294 <f.5+0x484>
   59eb2:      	cmpb	$0x0, 0x837f(%rip)      # 0x62238 <g.29>
   59eb9:      	je	0x5a294 <f.5+0x484>
   59ebf:      	cmpb	$0x0, 0x8332(%rip)      # 0x621f8 <g.21>
   59ec6:      	je	0x5a294 <f.5+0x484>
   59ecc:      	cmpq	$0x0, 0x831c(%rip)      # 0x621f0 <g.20>
   59ed4:      	je	0x5a294 <f.5+0x484>
   59eda:      	movq	0x834f(%rip), %r14      # 0x62230 <g.28>
   59ee1:      	movq	$0x4, 0x18(%rsp)
   59eea:      	leaq	0x60(%rsp), %r15
   59eef:      	movq	%r15, %rdi
   59ef2:      	xorl	%esi, %esi
   59ef4:      	callq	0x2ac30 <native_roots_enter>
   59ef9:      	movq	$0x0, 0x70(%rsp)
   59f02:      	movq	%r14, %rdi
   59f05:      	callq	0x144b0 <hide_i64>
   59f0a:      	movq	%rax, %r12
   59f0d:      	movq	%r15, %rdi
   59f10:      	callq	0x2ac80 <native_roots_leave>
   59f15:      	cmpb	$0x0, 0x830c(%rip)      # 0x62228 <g.27>
   59f1c:      	je	0x5a294 <f.5+0x484>
   59f22:      	cmpq	$0x0, 0x82f6(%rip)      # 0x62220 <g.26>
   59f2a:      	je	0x5a294 <f.5+0x484>
   59f30:      	cmpb	$0x0, 0x8291(%rip)      # 0x621c8 <g.15>
   59f37:      	je	0x5a294 <f.5+0x484>
   59f3d:      	cmpq	$0x0, 0x827b(%rip)      # 0x621c0 <g.14>
   59f45:      	je	0x5a294 <f.5+0x484>
   59f4b:      	movq	%rbx, %r14
   59f4e:      	movq	%r13, 0x58(%rsp)
   59f53:      	movq	$0x4, 0x18(%rsp)
   59f5c:      	movl	$0x18, %edi
   59f61:      	callq	0x28860 <native_alloc>
   59f66:      	testq	%rax, %rax
   59f69:      	je	0x5a294 <f.5+0x484>
   59f6f:      	movq	%rax, %r13
   59f72:      	movq	$0x7a, (%rax)
   59f79:      	movl	$0x0, 0x8(%rax)
   59f80:      	movq	$0x0, 0x10(%rax)
   59f88:      	movq	%rax, 0x28(%rsp)
   59f8d:      	movq	%rax, 0x40(%rsp)
   59f92:      	movq	%r14, 0x48(%rsp)
   59f97:      	movq	%rax, 0x50(%rsp)
   59f9c:      	movq	$0x7, 0x18(%rsp)
   59fa5:      	movl	$0x10, %edi
   59faa:      	callq	0x28860 <native_alloc>
   59faf:      	testq	%rax, %rax
   59fb2:      	je	0x5a294 <f.5+0x484>
   59fb8:      	movq	%rax, %rbp
   59fbb:      	movq	$0x72, (%rax)
   59fc2:      	movq	%r13, 0x8(%rax)
   59fc6:      	movq	%rax, 0x40(%rsp)
   59fcb:      	movq	%r14, 0x48(%rsp)
   59fd0:      	movq	%r13, 0x50(%rsp)
   59fd5:      	movq	$0x7, 0x18(%rsp)
   59fde:      	movl	$0x18, %edi
   59fe3:      	callq	0x28860 <native_alloc>
   59fe8:      	testq	%rax, %rax
   59feb:      	je	0x5a294 <f.5+0x484>
   59ff1:      	movq	$0x92, (%rax)
   59ff8:      	movq	%r14, 0x8(%rax)
   59ffc:      	movq	%rbp, 0x10(%rax)
   5a000:      	movq	%rax, 0x10(%r13)
   5a004:      	movq	0x28(%rsp), %rax
   5a009:      	testq	%rax, %rax
   5a00c:      	je	0x5a294 <f.5+0x484>
   5a012:      	movl	$0x1, 0x8(%rax)
   5a019:      	movq	0x28(%rsp), %rax
   5a01e:      	testq	%rax, %rax
   5a021:      	je	0x5a294 <f.5+0x484>
   5a027:      	cmpl	$0x0, 0x8(%rax)
   5a02b:      	je	0x5a294 <f.5+0x484>
   5a031:      	movq	0x10(%rax), %rax
   5a035:      	testq	%rax, %rax
   5a038:      	je	0x5a294 <f.5+0x484>
   5a03e:      	movq	%rax, 0x30(%rsp)
   5a043:      	movq	0x8(%rax), %rcx
   5a047:      	testq	%rcx, %rcx
   5a04a:      	je	0x5a294 <f.5+0x484>
   5a050:      	leaq	-0x1(%r12), %rsi
   5a055:      	movq	0x10(%rax), %rdi
   5a059:      	movq	0x8(%rcx), %rax
   5a05d:      	movq	%rdi, 0x40(%rsp)
   5a062:      	movq	$0x5, 0x18(%rsp)
   5a06b:      	movl	$0x1, %edx
   5a070:      	callq	*%rax
   5a072:      	subq	$0x8, %rsp
   5a076:      	movq	%rax, %r13
   5a079:      	movq	$0x4, 0x18(%rsp)
   5a082:      	movl	$0x10, %edi
   5a087:      	callq	0x28860 <native_alloc>
   5a08c:      	testq	%rax, %rax
   5a08f:      	je	0x5a294 <f.5+0x484>
   5a095:      	movq	%rax, %r14
   5a098:      	movq	$0x96, (%rax)
   5a09f:      	movq	$0x0, 0x8(%rax)
   5a0a7:      	movq	%rax, 0x40(%rsp)
   5a0ac:      	movq	$0x5, 0x18(%rsp)
   5a0b5:      	movl	$0x10, %edi
   5a0ba:      	callq	0x28860 <native_alloc>
   5a0bf:      	testq	%rax, %rax
   5a0c2:      	je	0x5a294 <f.5+0x484>
   5a0c8:      	movq	%rax, %rbp
   5a0cb:      	movq	$0x6a, (%rax)
   5a0d2:      	movq	%r14, 0x8(%rax)
   5a0d6:      	movq	%rax, 0x40(%rsp)
   5a0db:      	movq	$0x5, 0x18(%rsp)
   5a0e4:      	movl	$0x18, %edi
   5a0e9:      	callq	0x28860 <native_alloc>
   5a0ee:      	testq	%rax, %rax
   5a0f1:      	je	0x5a294 <f.5+0x484>
   5a0f7:      	movq	%rax, %r14
   5a0fa:      	movq	$0x66, (%rax)
   5a101:      	movq	%r12, 0x8(%rax)
   5a105:      	movq	%rbp, 0x10(%rax)
   5a109:      	movq	%rax, 0x40(%rsp)
   5a10e:      	movq	$0x5, 0x18(%rsp)
   5a117:      	movl	$0x10, %edi
   5a11c:      	callq	0x28860 <native_alloc>
   5a121:      	testq	%rax, %rax
   5a124:      	je	0x5a294 <f.5+0x484>
   5a12a:      	movq	%rax, %r15
   5a12d:      	movq	$0x96, (%rax)
   5a134:      	movq	%r14, 0x8(%rax)
   5a138:      	movq	%rax, 0x40(%rsp)
   5a13d:      	movq	$0x5, 0x18(%rsp)
   5a146:      	movl	$0x10, %edi
   5a14b:      	callq	0x28860 <native_alloc>
   5a150:      	testq	%rax, %rax
   5a153:      	je	0x5a294 <f.5+0x484>
   5a159:      	movq	%rax, %rbp
   5a15c:      	movq	$0x6a, (%rax)
   5a163:      	movq	%r15, 0x8(%rax)
   5a167:      	movq	%rax, 0x40(%rsp)
   5a16c:      	movq	$0x5, 0x18(%rsp)
   5a175:      	movl	$0x28, %edi
   5a17a:      	callq	0x28860 <native_alloc>
   5a17f:      	testq	%rax, %rax
   5a182:      	je	0x5a294 <f.5+0x484>
   5a188:      	movq	%r12, %rcx
   5a18b:      	addq	$-0x2, %rcx
   5a18f:      	leaq	-0x4(,%r13,4), %rdx
   5a197:      	movq	$0x62, (%rax)
   5a19e:      	movq	%r12, 0x8(%rax)
   5a1a2:      	movq	%rcx, 0x10(%rax)
   5a1a6:      	movq	%rdx, 0x18(%rax)
   5a1aa:      	movq	%rbp, 0x20(%rax)
   5a1ae:      	movq	%rax, 0x40(%rsp)
   5a1b3:      	movq	$0x5, 0x18(%rsp)
   5a1bc:      	movq	%rax, %rdi
   5a1bf:      	callq	0x5a620 <f.8>
   5a1c4:      	subq	$0x8, %rsp
   5a1c8:      	movq	0x20(%rsp), %r14
   5a1cd:      	movl	$0x76, %esi
   5a1d2:      	movq	%r14, %rdi
   5a1d5:      	xorl	%edx, %edx
   5a1d7:      	xorl	%ecx, %ecx
   5a1d9:      	callq	0x2ab40 <native_ref_test>
   5a1de:      	testl	%eax, %eax
   5a1e0:      	je	0x5a294 <f.5+0x484>
   5a1e6:      	testq	%r14, %r14
   5a1e9:      	movq	0x58(%rsp), %r13
   5a1ee:      	je	0x5a294 <f.5+0x484>
   5a1f4:      	movq	0x10(%r14), %rax
   5a1f8:      	testq	%rax, %rax
   5a1fb:      	je	0x5a294 <f.5+0x484>
   5a201:      	cmpl	$0x0, 0x8(%rax)
   5a205:      	je	0x5a294 <f.5+0x484>
   5a20b:      	movq	0x20(%rsp), %r12
   5a210:      	movl	$0x76, %esi
   5a215:      	movq	%r12, %rdi
   5a218:      	xorl	%edx, %edx
   5a21a:      	xorl	%ecx, %ecx
   5a21c:      	callq	0x2ab40 <native_ref_test>
   5a221:      	testl	%eax, %eax
   5a223:      	je	0x5a294 <f.5+0x484>
   5a225:      	movq	%r12, 0x38(%rsp)
   5a22a:      	testq	%r12, %r12
   5a22d:      	je	0x5a294 <f.5+0x484>
   5a22f:      	movq	0x10(%r12), %rax
   5a234:      	testq	%rax, %rax
   5a237:      	je	0x5a294 <f.5+0x484>
   5a239:      	cmpq	$0x0, 0x10(%rax)
   5a23e:      	je	0x5a294 <f.5+0x484>
   5a240:      	leaq	0x8(%rsp), %r14
   5a245:      	movq	%r14, %rdi
   5a248:      	callq	0x2ac80 <native_roots_leave>
   5a24d:      	movl	$0x7, %esi
   5a252:      	movq	%r14, %rdi
   5a255:      	callq	0x2ac30 <native_roots_enter>
   5a25a:      	movq	%r12, 0x20(%rsp)
   5a25f:      	leaq	0x28(%rsp), %rax
   5a264:      	movq	$0x0, 0x10(%rax)
   5a26c:      	movq	$0x0, 0x8(%rax)
   5a274:      	movq	$0x0, (%rax)
   5a27b:      	movl	$0x76, %esi
   5a280:      	movq	%r12, %rdi
   5a283:      	xorl	%edx, %edx
   5a285:      	xorl	%ecx, %ecx
   5a287:      	callq	0x2ab40 <native_ref_test>
   5a28c:      	testl	%eax, %eax
   5a28e:      	jne	0x59e80 <f.5+0x70>
   5a294:      	callq	0x268c0 <native_trap>
   5a299:      	leaq	0x8(%rsp), %rdi
   5a29e:      	callq	0x2ac80 <native_roots_leave>
   5a2a3:      	xorl	%eax, %eax
   5a2a5:      	addq	$0x78, %rsp
   5a2a9:      	popq	%rbx
   5a2aa:      	popq	%r12
   5a2ac:      	popq	%r13
   5a2ae:      	popq	%r14
   5a2b0:      	popq	%r15
   5a2b2:      	popq	%rbp
   5a2b3:      	retq	$0x8
   5a2b6:      	int3
   5a2b7:      	int3
   5a2b8:      	int3
   5a2b9:      	int3
   5a2ba:      	int3
   5a2bb:      	int3
   5a2bc:      	int3
   5a2bd:      	int3
   5a2be:      	int3
   5a2bf:      	int3

000000000005a2c0 <f.6>:
   5a2c0:      	pushq	%r15
   5a2c2:      	pushq	%r14
   5a2c4:      	pushq	%rbx
   5a2c5:      	subq	$0x40, %rsp
   5a2c9:      	movq	%rdx, %rbx
   5a2cc:      	movq	%rdi, %r14
   5a2cf:      	leaq	0x8(%rsp), %r15
   5a2d4:      	movl	$0x1, %esi
   5a2d9:      	movq	%r15, %rdi
   5a2dc:      	callq	0x2ac30 <native_roots_enter>
   5a2e1:      	movq	%r14, 0x20(%rsp)
   5a2e6:      	movq	$0x1, 0x18(%rsp)
   5a2ef:      	leaq	0x28(%rsp), %r14
   5a2f4:      	movq	%r14, %rdi
   5a2f7:      	xorl	%esi, %esi
   5a2f9:      	callq	0x2ac30 <native_roots_enter>
   5a2fe:      	movq	$0x0, 0x38(%rsp)
   5a307:      	movq	%rbx, %rdi
   5a30a:      	callq	0x144b0 <hide_i64>
   5a30f:      	movq	%rax, %rbx
   5a312:      	movq	%r14, %rdi
   5a315:      	callq	0x2ac80 <native_roots_leave>
   5a31a:      	movq	%r15, %rdi
   5a31d:      	callq	0x2ac80 <native_roots_leave>
   5a322:      	movq	%rbx, %rax
   5a325:      	addq	$0x40, %rsp
   5a329:      	popq	%rbx
   5a32a:      	popq	%r14
   5a32c:      	popq	%r15
   5a32e:      	retq	$0x8
   5a331:      	int3
   5a332:      	int3
   5a333:      	int3
   5a334:      	int3
   5a335:      	int3
   5a336:      	int3
   5a337:      	int3
   5a338:      	int3
   5a339:      	int3
   5a33a:      	int3
   5a33b:      	int3
   5a33c:      	int3
   5a33d:      	int3
   5a33e:      	int3
   5a33f:      	int3

000000000005a340 <f.7>:
   5a340:      	pushq	%r15
   5a342:      	pushq	%r14
   5a344:      	pushq	%r13
   5a346:      	pushq	%r12
   5a348:      	pushq	%rbx
   5a349:      	subq	$0x50, %rsp
   5a34d:      	movq	%rsi, %rbx
   5a350:      	movq	%rdi, %r14
   5a353:      	leaq	0x8(%rsp), %rdi
   5a358:      	movl	$0x6, %esi
   5a35d:      	callq	0x2ac30 <native_roots_enter>
   5a362:      	movq	%r14, 0x20(%rsp)
   5a367:      	movq	$0x0, 0x28(%rsp)
   5a370:      	movq	$0x0, 0x30(%rsp)
   5a379:      	cmpb	$0x0, 0x7e48(%rip)      # 0x621c8 <g.15>
   5a380:      	je	0x5a61a <f.7+0x2da>
   5a386:      	cmpq	$0x0, 0x7e32(%rip)      # 0x621c0 <g.14>
   5a38e:      	je	0x5a61a <f.7+0x2da>
   5a394:      	movq	$0x3, 0x18(%rsp)
   5a39d:      	movl	$0x18, %edi
   5a3a2:      	callq	0x28860 <native_alloc>
   5a3a7:      	testq	%rax, %rax
   5a3aa:      	je	0x5a61a <f.7+0x2da>
   5a3b0:      	movq	%rax, %r14
   5a3b3:      	movq	$0x7a, (%rax)
   5a3ba:      	movl	$0x0, 0x8(%rax)
   5a3c1:      	movq	$0x0, 0x10(%rax)
   5a3c9:      	movq	%rax, 0x28(%rsp)
   5a3ce:      	movq	%rax, 0x38(%rsp)
   5a3d3:      	leaq	0x5afe(%rip), %r12      # 0x5fed8 <ref.19>
   5a3da:      	movq	%r12, 0x40(%rsp)
   5a3df:      	movq	%rax, 0x48(%rsp)
   5a3e4:      	movq	$0x6, 0x18(%rsp)
   5a3ed:      	movl	$0x10, %edi
   5a3f2:      	callq	0x28860 <native_alloc>
   5a3f7:      	testq	%rax, %rax
   5a3fa:      	je	0x5a61a <f.7+0x2da>
   5a400:      	movq	%rax, %r15
   5a403:      	movq	$0x72, (%rax)
   5a40a:      	movq	%r14, 0x8(%rax)
   5a40e:      	movq	%rax, 0x38(%rsp)
   5a413:      	movq	%r12, 0x40(%rsp)
   5a418:      	movq	%r14, 0x48(%rsp)
   5a41d:      	movq	$0x6, 0x18(%rsp)
   5a426:      	movl	$0x18, %edi
   5a42b:      	callq	0x28860 <native_alloc>
   5a430:      	testq	%rax, %rax
   5a433:      	je	0x5a61a <f.7+0x2da>
   5a439:      	movq	$0x92, (%rax)
   5a440:      	movq	%r12, 0x8(%rax)
   5a444:      	movq	%r15, 0x10(%rax)
   5a448:      	movq	%rax, 0x10(%r14)
   5a44c:      	movq	0x28(%rsp), %rax
   5a451:      	testq	%rax, %rax
   5a454:      	je	0x5a61a <f.7+0x2da>
   5a45a:      	movl	$0x1, 0x8(%rax)
   5a461:      	movq	0x28(%rsp), %rax
   5a466:      	testq	%rax, %rax
   5a469:      	je	0x5a61a <f.7+0x2da>
   5a46f:      	cmpl	$0x0, 0x8(%rax)
   5a473:      	je	0x5a61a <f.7+0x2da>
   5a479:      	movq	0x10(%rax), %rax
   5a47d:      	testq	%rax, %rax
   5a480:      	je	0x5a61a <f.7+0x2da>
   5a486:      	movq	%rax, 0x30(%rsp)
   5a48b:      	movq	0x8(%rax), %rcx
   5a48f:      	testq	%rcx, %rcx
   5a492:      	je	0x5a61a <f.7+0x2da>
   5a498:      	leaq	-0x1(%rbx), %rsi
   5a49c:      	movq	0x10(%rax), %rdi
   5a4a0:      	movq	0x8(%rcx), %rax
   5a4a4:      	movq	%rdi, 0x38(%rsp)
   5a4a9:      	movq	$0x4, 0x18(%rsp)
   5a4b2:      	movl	$0x1, %edx
   5a4b7:      	callq	*%rax
   5a4b9:      	subq	$0x8, %rsp
   5a4bd:      	movq	%rax, %r14
   5a4c0:      	movq	$0x3, 0x18(%rsp)
   5a4c9:      	movl	$0x10, %edi
   5a4ce:      	callq	0x28860 <native_alloc>
   5a4d3:      	testq	%rax, %rax
   5a4d6:      	je	0x5a61a <f.7+0x2da>
   5a4dc:      	movq	%rax, %r12
   5a4df:      	movq	$0x96, (%rax)
   5a4e6:      	movq	$0x0, 0x8(%rax)
   5a4ee:      	movq	%rax, 0x38(%rsp)
   5a4f3:      	movq	$0x4, 0x18(%rsp)
   5a4fc:      	movl	$0x10, %edi
   5a501:      	callq	0x28860 <native_alloc>
   5a506:      	testq	%rax, %rax
   5a509:      	je	0x5a61a <f.7+0x2da>
   5a50f:      	movq	%rax, %r15
   5a512:      	movq	$0x6a, (%rax)
   5a519:      	movq	%r12, 0x8(%rax)
   5a51d:      	movq	%rax, 0x38(%rsp)
   5a522:      	movq	$0x4, 0x18(%rsp)
   5a52b:      	movl	$0x18, %edi
   5a530:      	callq	0x28860 <native_alloc>
   5a535:      	testq	%rax, %rax
   5a538:      	je	0x5a61a <f.7+0x2da>
   5a53e:      	movq	%rax, %r12
   5a541:      	movq	$0x66, (%rax)
   5a548:      	movq	%rbx, 0x8(%rax)
   5a54c:      	movq	%r15, 0x10(%rax)
   5a550:      	movq	%rax, 0x38(%rsp)
   5a555:      	movq	$0x4, 0x18(%rsp)
   5a55e:      	movl	$0x10, %edi
   5a563:      	callq	0x28860 <native_alloc>
   5a568:      	testq	%rax, %rax
   5a56b:      	je	0x5a61a <f.7+0x2da>
   5a571:      	movq	%rax, %r13
   5a574:      	movq	$0x96, (%rax)
   5a57b:      	movq	%r12, 0x8(%rax)
   5a57f:      	movq	%rax, 0x38(%rsp)
   5a584:      	movq	$0x4, 0x18(%rsp)
   5a58d:      	movl	$0x10, %edi
   5a592:      	callq	0x28860 <native_alloc>
   5a597:      	testq	%rax, %rax
   5a59a:      	je	0x5a61a <f.7+0x2da>
   5a59c:      	movq	%rax, %r15
   5a59f:      	movq	$0x6a, (%rax)
   5a5a6:      	movq	%r13, 0x8(%rax)
   5a5aa:      	movq	%rax, 0x38(%rsp)
   5a5af:      	movq	$0x4, 0x18(%rsp)
   5a5b8:      	movl	$0x28, %edi
   5a5bd:      	callq	0x28860 <native_alloc>
   5a5c2:      	testq	%rax, %rax
   5a5c5:      	je	0x5a61a <f.7+0x2da>
   5a5c7:      	movq	%rax, %r12
   5a5ca:      	leaq	-0x4(,%r14,4), %rax
   5a5d2:      	movq	$0x62, (%r12)
   5a5da:      	movq	%rbx, 0x8(%r12)
   5a5df:      	addq	$-0x2, %rbx
   5a5e3:      	movq	%rbx, 0x10(%r12)
   5a5e8:      	movq	%rax, 0x18(%r12)
   5a5ed:      	movq	%r15, 0x20(%r12)
   5a5f2:      	leaq	0x8(%rsp), %rdi
   5a5f7:      	callq	0x2ac80 <native_roots_leave>
   5a5fc:      	movq	%r12, %rdi
   5a5ff:      	callq	0x5a620 <f.8>
   5a604:      	subq	$0x8, %rsp
   5a608:      	xorl	%eax, %eax
   5a60a:      	addq	$0x50, %rsp
   5a60e:      	popq	%rbx
   5a60f:      	popq	%r12
   5a611:      	popq	%r13
   5a613:      	popq	%r14
   5a615:      	popq	%r15
   5a617:      	retq	$0x8
   5a61a:      	callq	0x268c0 <native_trap>
   5a61f:      	int3

000000000005a620 <f.8>:
   5a620:      	pushq	%rbp
   5a621:      	pushq	%r15
   5a623:      	pushq	%r14
   5a625:      	pushq	%r13
   5a627:      	pushq	%r12
   5a629:      	pushq	%rbx
   5a62a:      	subq	$0xb8, %rsp
   5a631:      	movq	%rdi, %rbx
   5a634:      	leaq	0x20(%rsp), %rdi
   5a639:      	movl	$0xf, %esi
   5a63e:      	callq	0x2ac30 <native_roots_enter>
   5a643:      	movq	%rbx, 0x38(%rsp)
   5a648:      	movq	$0x0, 0x40(%rsp)
   5a651:      	movq	$0x0, 0x48(%rsp)
   5a65a:      	movq	$0x0, 0x50(%rsp)
   5a663:      	movq	$0x0, 0x58(%rsp)
   5a66c:      	movq	$0x0, 0x60(%rsp)
   5a675:      	movq	$0x0, 0x68(%rsp)
   5a67e:      	movq	$0x0, 0x70(%rsp)
   5a687:      	movq	$0x8, 0x30(%rsp)
   5a690:      	movl	$0x18, %edi
   5a695:      	callq	0x28860 <native_alloc>
   5a69a:      	testq	%rax, %rax
   5a69d:      	je	0x5b343 <f.8+0xd23>
   5a6a3:      	movq	%rax, %rbx
   5a6a6:      	movq	$0x56, (%rax)
   5a6ad:      	movl	$0x0, 0x8(%rax)
   5a6b4:      	movq	$0x0, 0x10(%rax)
   5a6bc:      	movq	%rax, 0x48(%rsp)
   5a6c1:      	movq	%rax, 0x78(%rsp)
   5a6c6:      	movq	%rax, 0x80(%rsp)
   5a6ce:      	movq	$0xa, 0x30(%rsp)
   5a6d7:      	movl	$0x10, %edi
   5a6dc:      	callq	0x28860 <native_alloc>
   5a6e1:      	testq	%rax, %rax
   5a6e4:      	je	0x5b343 <f.8+0xd23>
   5a6ea:      	movq	%rax, %r14
   5a6ed:      	movq	$0x4a, (%rax)
   5a6f4:      	movq	%rbx, 0x8(%rax)
   5a6f8:      	movq	%rax, 0x78(%rsp)
   5a6fd:      	movq	%rbx, 0x80(%rsp)
   5a705:      	movq	$0xa, 0x30(%rsp)
   5a70e:      	movl	$0x10, %edi
   5a713:      	callq	0x28860 <native_alloc>
   5a718:      	testq	%rax, %rax
   5a71b:      	je	0x5b343 <f.8+0xd23>
   5a721:      	movq	$0x42, (%rax)
   5a728:      	movq	%r14, 0x8(%rax)
   5a72c:      	movq	%rax, 0x10(%rbx)
   5a730:      	movq	0x48(%rsp), %rax
   5a735:      	testq	%rax, %rax
   5a738:      	je	0x5b343 <f.8+0xd23>
   5a73e:      	movl	$0x1, 0x8(%rax)
   5a745:      	movq	$0x8, 0x30(%rsp)
   5a74e:      	movl	$0x18, %edi
   5a753:      	callq	0x28860 <native_alloc>
   5a758:      	testq	%rax, %rax
   5a75b:      	je	0x5b343 <f.8+0xd23>
   5a761:      	movq	%rax, %rbx
   5a764:      	movq	$0x52, (%rax)
   5a76b:      	movl	$0x0, 0x8(%rax)
   5a772:      	movq	$0x0, 0x10(%rax)
   5a77a:      	movq	%rax, 0x50(%rsp)
   5a77f:      	movq	%rax, 0x78(%rsp)
   5a784:      	movq	%rax, 0x80(%rsp)
   5a78c:      	movq	$0xa, 0x30(%rsp)
   5a795:      	movl	$0x10, %edi
   5a79a:      	callq	0x28860 <native_alloc>
   5a79f:      	testq	%rax, %rax
   5a7a2:      	je	0x5b343 <f.8+0xd23>
   5a7a8:      	movq	%rax, %r14
   5a7ab:      	movq	$0x3e, (%rax)
   5a7b2:      	movq	%rbx, 0x8(%rax)
   5a7b6:      	movq	%rax, 0x78(%rsp)
   5a7bb:      	movq	%rbx, 0x80(%rsp)
   5a7c3:      	movq	$0xa, 0x30(%rsp)
   5a7cc:      	movl	$0x10, %edi
   5a7d1:      	callq	0x28860 <native_alloc>
   5a7d6:      	testq	%rax, %rax
   5a7d9:      	je	0x5b343 <f.8+0xd23>
   5a7df:      	movq	$0x3a, (%rax)
   5a7e6:      	movq	%r14, 0x8(%rax)
   5a7ea:      	movq	%rax, 0x10(%rbx)
   5a7ee:      	movq	0x50(%rsp), %rax
   5a7f3:      	testq	%rax, %rax
   5a7f6:      	je	0x5b343 <f.8+0xd23>
   5a7fc:      	movl	$0x1, 0x8(%rax)
   5a803:      	movq	$0x8, 0x30(%rsp)
   5a80c:      	leaq	0x8(%rsp), %rbx
   5a811:      	movq	%rbx, %rdi
   5a814:      	xorl	%esi, %esi
   5a816:      	callq	0x2ac30 <native_roots_enter>
   5a81b:      	movq	$0x0, 0x18(%rsp)
   5a824:      	movl	$0x3, %edi
   5a829:      	callq	0x145b0 <print_text>
   5a82e:      	movq	%rbx, %rdi
   5a831:      	callq	0x2ac80 <native_roots_leave>
   5a836:      	movq	$0x8, 0x30(%rsp)
   5a83f:      	leaq	0x8(%rsp), %rbx
   5a844:      	movq	%rbx, %rdi
   5a847:      	xorl	%esi, %esi
   5a849:      	callq	0x2ac30 <native_roots_enter>
   5a84e:      	movq	$0x0, 0x18(%rsp)
   5a857:      	xorl	%edi, %edi
   5a859:      	callq	0x145b0 <print_text>
   5a85e:      	movq	%rbx, %rdi
   5a861:      	callq	0x2ac80 <native_roots_leave>
   5a866:      	movq	0x38(%rsp), %rax
   5a86b:      	testq	%rax, %rax
   5a86e:      	je	0x5b343 <f.8+0xd23>
   5a874:      	movq	0x8(%rax), %rbx
   5a878:      	movq	$0x8, 0x30(%rsp)
   5a881:      	leaq	0x8(%rsp), %r14
   5a886:      	movq	%r14, %rdi
   5a889:      	xorl	%esi, %esi
   5a88b:      	callq	0x2ac30 <native_roots_enter>
   5a890:      	movq	$0x0, 0x18(%rsp)
   5a899:      	xorl	%edi, %edi
   5a89b:      	movq	%rbx, %rsi
   5a89e:      	callq	0x14530 <print_size>
   5a8a3:      	movq	%r14, %rdi
   5a8a6:      	callq	0x2ac80 <native_roots_leave>
   5a8ab:      	movq	$0x8, 0x30(%rsp)
   5a8b4:      	leaq	0x8(%rsp), %r14
   5a8b9:      	movq	%r14, %rdi
   5a8bc:      	xorl	%esi, %esi
   5a8be:      	callq	0x2ac30 <native_roots_enter>
   5a8c3:      	movq	$0x0, 0x18(%rsp)
   5a8cc:      	xorl	%edi, %edi
   5a8ce:      	callq	0x145b0 <print_text>
   5a8d3:      	movq	%r14, %rdi
   5a8d6:      	callq	0x2ac80 <native_roots_leave>
   5a8db:      	cmpb	$0x0, 0x7936(%rip)      # 0x62218 <g.25>
   5a8e2:      	je	0x5b343 <f.8+0xd23>
   5a8e8:      	cmpq	$0x0, 0x7920(%rip)      # 0x62210 <g.24>
   5a8f0:      	je	0x5b343 <f.8+0xd23>
   5a8f6:      	movq	$0x8, 0x30(%rsp)
   5a8ff:      	leaq	0x8(%rsp), %r14
   5a904:      	movq	%r14, %rdi
   5a907:      	xorl	%esi, %esi
   5a909:      	callq	0x2ac30 <native_roots_enter>
   5a90e:      	movq	$0x0, 0x18(%rsp)
   5a917:      	movl	$0x1, %edi
   5a91c:      	callq	0x145b0 <print_text>
   5a921:      	movq	%r14, %rdi
   5a924:      	callq	0x2ac80 <native_roots_leave>
   5a929:      	movq	$0x8, 0x30(%rsp)
   5a932:      	leaq	0x8(%rsp), %r14
   5a937:      	movq	%r14, %rdi
   5a93a:      	xorl	%esi, %esi
   5a93c:      	callq	0x2ac30 <native_roots_enter>
   5a941:      	movq	$0x0, 0x18(%rsp)
   5a94a:      	movl	$0x2, %edi
   5a94f:      	callq	0x145b0 <print_text>
   5a954:      	movq	%r14, %rdi
   5a957:      	callq	0x2ac80 <native_roots_leave>
   5a95c:      	movq	$0x8, 0x30(%rsp)
   5a965:      	leaq	0x8(%rsp), %r14
   5a96a:      	movq	%r14, %rdi
   5a96d:      	xorl	%esi, %esi
   5a96f:      	callq	0x2ac30 <native_roots_enter>
   5a974:      	movq	$0x0, 0x18(%rsp)
   5a97d:      	xorl	%edi, %edi
   5a97f:      	callq	0x145b0 <print_text>
   5a984:      	movq	%r14, %rdi
   5a987:      	callq	0x2ac80 <native_roots_leave>
   5a98c:      	cmpb	$0x0, 0x7875(%rip)      # 0x62208 <g.23>
   5a993:      	je	0x5b343 <f.8+0xd23>
   5a999:      	cmpq	$0x0, 0x785f(%rip)      # 0x62200 <g.22>
   5a9a1:      	je	0x5b343 <f.8+0xd23>
   5a9a7:      	movq	$0x8, 0x30(%rsp)
   5a9b0:      	leaq	0x8(%rsp), %r14
   5a9b5:      	movq	%r14, %rdi
   5a9b8:      	xorl	%esi, %esi
   5a9ba:      	callq	0x2ac30 <native_roots_enter>
   5a9bf:      	movq	$0x0, 0x18(%rsp)
   5a9c8:      	movl	$0x6, %edi
   5a9cd:      	callq	0x145b0 <print_text>
   5a9d2:      	movq	%r14, %rdi
   5a9d5:      	callq	0x2ac80 <native_roots_leave>
   5a9da:      	movq	$0x8, 0x30(%rsp)
   5a9e3:      	leaq	0x8(%rsp), %r14
   5a9e8:      	movq	%r14, %rdi
   5a9eb:      	xorl	%esi, %esi
   5a9ed:      	callq	0x2ac30 <native_roots_enter>
   5a9f2:      	movq	$0x0, 0x18(%rsp)
   5a9fb:      	xorl	%edi, %edi
   5a9fd:      	callq	0x145b0 <print_text>
   5aa02:      	movq	%r14, %rdi
   5aa05:      	callq	0x2ac80 <native_roots_leave>
   5aa0a:      	movq	0x50(%rsp), %rax
   5aa0f:      	testq	%rax, %rax
   5aa12:      	je	0x5b343 <f.8+0xd23>
   5aa18:      	cmpl	$0x0, 0x8(%rax)
   5aa1c:      	je	0x5b343 <f.8+0xd23>
   5aa22:      	movq	0x10(%rax), %rax
   5aa26:      	testq	%rax, %rax
   5aa29:      	je	0x5b343 <f.8+0xd23>
   5aa2f:      	movq	0x8(%rax), %rdi
   5aa33:      	movq	%rdi, 0x78(%rsp)
   5aa38:      	movq	$0x9, 0x30(%rsp)
   5aa41:      	movq	%rbx, %rsi
   5aa44:      	callq	0x5c9b0 <f.18>
   5aa49:      	subq	$0x8, %rsp
   5aa4d:      	movq	0x38(%rsp), %rax
   5aa52:      	testq	%rax, %rax
   5aa55:      	je	0x5b343 <f.8+0xd23>
   5aa5b:      	movq	0x10(%rax), %r13
   5aa5f:      	movq	$0x8, 0x30(%rsp)
   5aa68:      	leaq	0x8(%rsp), %r14
   5aa6d:      	movq	%r14, %rdi
   5aa70:      	xorl	%esi, %esi
   5aa72:      	callq	0x2ac30 <native_roots_enter>
   5aa77:      	movq	$0x0, 0x18(%rsp)
   5aa80:      	movl	$0x1, %edi
   5aa85:      	movq	%r13, %rsi
   5aa88:      	callq	0x14530 <print_size>
   5aa8d:      	movq	%r14, %rdi
   5aa90:      	callq	0x2ac80 <native_roots_leave>
   5aa95:      	movq	$0x8, 0x30(%rsp)
   5aa9e:      	leaq	0x8(%rsp), %r14
   5aaa3:      	movq	%r14, %rdi
   5aaa6:      	xorl	%esi, %esi
   5aaa8:      	callq	0x2ac30 <native_roots_enter>
   5aaad:      	movq	$0x0, 0x18(%rsp)
   5aab6:      	xorl	%edi, %edi
   5aab8:      	callq	0x145b0 <print_text>
   5aabd:      	movq	%r14, %rdi
   5aac0:      	callq	0x2ac80 <native_roots_leave>
   5aac5:      	cmpb	$0x0, 0x76ac(%rip)      # 0x62178 <g.5>
   5aacc:      	je	0x5b343 <f.8+0xd23>
   5aad2:      	cmpq	$0x0, 0x7696(%rip)      # 0x62170 <g.4>
   5aada:      	je	0x5b343 <f.8+0xd23>
   5aae0:      	movq	0x48(%rsp), %rax
   5aae5:      	testq	%rax, %rax
   5aae8:      	je	0x5b343 <f.8+0xd23>
   5aaee:      	cmpl	$0x0, 0x8(%rax)
   5aaf2:      	je	0x5b343 <f.8+0xd23>
   5aaf8:      	movq	0x10(%rax), %rax
   5aafc:      	testq	%rax, %rax
   5aaff:      	je	0x5b343 <f.8+0xd23>
   5ab05:      	movq	0x8(%rax), %rax
   5ab09:      	movq	%rax, 0x68(%rsp)
   5ab0e:      	leaq	-0x4f4a5(%rip), %r15    # 0xb670 <object.1.0>
   5ab15:      	movq	%r15, 0x78(%rsp)
   5ab1a:      	movq	$0x9, 0x30(%rsp)
   5ab23:      	movl	$0x10, %edi
   5ab28:      	callq	0x28860 <native_alloc>
   5ab2d:      	testq	%rax, %rax
   5ab30:      	je	0x5b343 <f.8+0xd23>
   5ab36:      	movq	%rax, %r14
   5ab39:      	movq	$0x36, (%rax)
   5ab40:      	movq	%r15, 0x8(%rax)
   5ab44:      	movq	%r15, 0x78(%rsp)
   5ab49:      	movq	%rax, 0x80(%rsp)
   5ab51:      	movq	$0xa, 0x30(%rsp)
   5ab5a:      	movl	$0x10, %edi
   5ab5f:      	callq	0x28860 <native_alloc>
   5ab64:      	testq	%rax, %rax
   5ab67:      	je	0x5b343 <f.8+0xd23>
   5ab6d:      	movq	%rax, %r12
   5ab70:      	movq	$0x36, (%rax)
   5ab77:      	movq	%r15, 0x8(%rax)
   5ab7b:      	movq	%rax, 0x78(%rsp)
   5ab80:      	movq	%r14, 0x80(%rsp)
   5ab88:      	movq	$0xa, 0x30(%rsp)
   5ab91:      	movl	$0x18, %edi
   5ab96:      	callq	0x28860 <native_alloc>
   5ab9b:      	testq	%rax, %rax
   5ab9e:      	je	0x5b343 <f.8+0xd23>
   5aba4:      	movq	%rax, %r15
   5aba7:      	movq	$0x46, (%rax)
   5abae:      	movq	%r14, 0x8(%rax)
   5abb2:      	movq	%r12, 0x10(%rax)
   5abb6:      	movq	%rax, 0x70(%rsp)
   5abbb:      	testq	%r13, %r13
   5abbe:      	jle	0x5ac28 <f.8+0x608>
   5abc0:      	movq	0x68(%rsp), %rax
   5abc5:      	testq	%rax, %rax
   5abc8:      	je	0x5b343 <f.8+0xd23>
   5abce:      	movq	0x8(%rax), %rbx
   5abd2:      	movq	%r15, 0x78(%rsp)
   5abd7:      	movq	%rbx, 0x80(%rsp)
   5abdf:      	movq	$0xa, 0x30(%rsp)
   5abe8:      	movl	$0x18, %edi
   5abed:      	callq	0x28860 <native_alloc>
   5abf2:      	testq	%rax, %rax
   5abf5:      	je	0x5b343 <f.8+0xd23>
   5abfb:      	movq	$0x32, (%rax)
   5ac02:      	movq	%rbx, 0x8(%rax)
   5ac06:      	movq	%r15, 0x10(%rax)
   5ac0a:      	leaq	-0x1(%r13), %rsi
   5ac0e:      	movq	%rax, 0x78(%rsp)
   5ac13:      	movq	$0x9, 0x30(%rsp)
   5ac1c:      	movq	%rax, %rdi
   5ac1f:      	callq	0x5c450 <f.17>
   5ac24:      	subq	$0x8, %rsp
   5ac28:      	movq	0x38(%rsp), %rax
   5ac2d:      	testq	%rax, %rax
   5ac30:      	je	0x5b343 <f.8+0xd23>
   5ac36:      	movq	0x18(%rax), %r14
   5ac3a:      	movq	$0x8, 0x30(%rsp)
   5ac43:      	leaq	0x8(%rsp), %r15
   5ac48:      	movq	%r15, %rdi
   5ac4b:      	xorl	%esi, %esi
   5ac4d:      	callq	0x2ac30 <native_roots_enter>
   5ac52:      	movq	$0x0, 0x18(%rsp)
   5ac5b:      	movl	$0x2, %edi
   5ac60:      	movq	%r14, %rsi
   5ac63:      	callq	0x14530 <print_size>
   5ac68:      	movq	%r15, %rdi
   5ac6b:      	callq	0x2ac80 <native_roots_leave>
   5ac70:      	movq	$0x8, 0x30(%rsp)
   5ac79:      	leaq	0x8(%rsp), %r15
   5ac7e:      	movq	%r15, %rdi
   5ac81:      	xorl	%esi, %esi
   5ac83:      	callq	0x2ac30 <native_roots_enter>
   5ac88:      	movq	$0x0, 0x18(%rsp)
   5ac91:      	xorl	%edi, %edi
   5ac93:      	callq	0x145b0 <print_text>
   5ac98:      	movq	%r15, %rdi
   5ac9b:      	callq	0x2ac80 <native_roots_leave>
   5aca0:      	movq	%r14, %rax
   5aca3:      	shrq	$0x20, %rax
   5aca7:      	jne	0x5b343 <f.8+0xd23>
   5acad:      	movq	%r13, 0xb0(%rsp)
   5acb5:      	movq	$0x8, 0x30(%rsp)
   5acbe:      	movl	$0x18, %edi
   5acc3:      	callq	0x28860 <native_alloc>
   5acc8:      	testq	%rax, %rax
   5accb:      	je	0x5b343 <f.8+0xd23>
   5acd1:      	movq	%rax, %r15
   5acd4:      	movq	$0x5e, (%rax)
   5acdb:      	movl	$0x0, 0x8(%rax)
   5ace2:      	movq	$0x0, 0x10(%rax)
   5acea:      	movq	%rax, 0x40(%rsp)
   5acef:      	leaq	0x51d2(%rip), %rbp      # 0x5fec8 <ref.16>
   5acf6:      	movq	%rbp, 0x78(%rsp)
   5acfb:      	movq	%rax, 0x80(%rsp)
   5ad03:      	movq	$0xa, 0x30(%rsp)
   5ad0c:      	movl	$0x4f, %edi
   5ad11:      	movl	%r14d, %esi
   5ad14:      	xorl	%edx, %edx
   5ad16:      	movl	$0x8, %ecx
   5ad1b:      	callq	0x2a830 <native_array_new>
   5ad20:      	movq	%rax, %r13
   5ad23:      	movq	%rax, 0x60(%rsp)
   5ad28:      	movq	0x40(%rsp), %rbx
   5ad2d:      	movq	%rbx, 0x78(%rsp)
   5ad32:      	movq	%rax, 0x80(%rsp)
   5ad3a:      	movq	%rbp, 0x88(%rsp)
   5ad42:      	movq	%r15, 0x90(%rsp)
   5ad4a:      	movq	$0xc, 0x30(%rsp)
   5ad53:      	movl	$0x20, %edi
   5ad58:      	callq	0x28860 <native_alloc>
   5ad5d:      	testq	%rax, %rax
   5ad60:      	je	0x5b343 <f.8+0xd23>
   5ad66:      	movq	%rax, %r12
   5ad69:      	movq	$0x2e, (%rax)
   5ad70:      	movq	%r14, 0x8(%rax)
   5ad74:      	movq	%r13, 0x10(%rax)
   5ad78:      	movq	%rbx, 0x18(%rax)
   5ad7c:      	movq	%rax, 0x78(%rsp)
   5ad81:      	movq	%rbp, 0x80(%rsp)
   5ad89:      	movq	%r15, 0x88(%rsp)
   5ad91:      	movq	$0xb, 0x30(%rsp)
   5ad9a:      	movl	$0x18, %edi
   5ad9f:      	callq	0x28860 <native_alloc>
   5ada4:      	testq	%rax, %rax
   5ada7:      	je	0x5b343 <f.8+0xd23>
   5adad:      	movq	$0x82, (%rax)
   5adb4:      	movq	%rbp, 0x8(%rax)
   5adb8:      	movq	%r12, 0x10(%rax)
   5adbc:      	movq	%rax, 0x10(%r15)
   5adc0:      	movq	0x40(%rsp), %rax
   5adc5:      	testq	%rax, %rax
   5adc8:      	je	0x5b343 <f.8+0xd23>
   5adce:      	movl	$0x1, 0x8(%rax)
   5add5:      	movq	0x40(%rsp), %rax
   5adda:      	testq	%rax, %rax
   5addd:      	je	0x5b343 <f.8+0xd23>
   5ade3:      	cmpl	$0x0, 0x8(%rax)
   5ade7:      	je	0x5b343 <f.8+0xd23>
   5aded:      	movq	0x10(%rax), %rax
   5adf1:      	testq	%rax, %rax
   5adf4:      	je	0x5b343 <f.8+0xd23>
   5adfa:      	movq	%rax, 0x58(%rsp)
   5adff:      	movq	0x8(%rax), %rcx
   5ae03:      	testq	%rcx, %rcx
   5ae06:      	je	0x5b343 <f.8+0xd23>
   5ae0c:      	movq	0x10(%rax), %rdi
   5ae10:      	movq	0x8(%rcx), %rax
   5ae14:      	movq	%rdi, 0x78(%rsp)
   5ae19:      	movq	$0x9, 0x30(%rsp)
   5ae22:      	xorl	%esi, %esi
   5ae24:      	callq	*%rax
   5ae26:      	subq	$0x8, %rsp
   5ae2a:      	cmpb	$0x0, 0x73e7(%rip)      # 0x62218 <g.25>
   5ae31:      	je	0x5b343 <f.8+0xd23>
   5ae37:      	cmpq	$0x0, 0x73d1(%rip)      # 0x62210 <g.24>
   5ae3f:      	je	0x5b343 <f.8+0xd23>
   5ae45:      	movq	$0x8, 0x30(%rsp)
   5ae4e:      	leaq	0x8(%rsp), %r14
   5ae53:      	movq	%r14, %rdi
   5ae56:      	xorl	%esi, %esi
   5ae58:      	callq	0x2ac30 <native_roots_enter>
   5ae5d:      	movq	$0x0, 0x18(%rsp)
   5ae66:      	movl	$0x1, %edi
   5ae6b:      	callq	0x145b0 <print_text>
   5ae70:      	movq	%r14, %rdi
   5ae73:      	callq	0x2ac80 <native_roots_leave>
   5ae78:      	movq	$0x8, 0x30(%rsp)
   5ae81:      	leaq	0x8(%rsp), %r14
   5ae86:      	movq	%r14, %rdi
   5ae89:      	xorl	%esi, %esi
   5ae8b:      	callq	0x2ac30 <native_roots_enter>
   5ae90:      	movq	$0x0, 0x18(%rsp)
   5ae99:      	movl	$0x2, %edi
   5ae9e:      	callq	0x145b0 <print_text>
   5aea3:      	movq	%r14, %rdi
   5aea6:      	callq	0x2ac80 <native_roots_leave>
   5aeab:      	movq	$0x8, 0x30(%rsp)
   5aeb4:      	leaq	0x8(%rsp), %r14
   5aeb9:      	movq	%r14, %rdi
   5aebc:      	xorl	%esi, %esi
   5aebe:      	callq	0x2ac30 <native_roots_enter>
   5aec3:      	movq	$0x0, 0x18(%rsp)
   5aecc:      	xorl	%edi, %edi
   5aece:      	callq	0x145b0 <print_text>
   5aed3:      	movq	%r14, %rdi
   5aed6:      	callq	0x2ac80 <native_roots_leave>
   5aedb:      	movq	$0x8, 0x30(%rsp)
   5aee4:      	movl	$0x18, %edi
   5aee9:      	callq	0x28860 <native_alloc>
   5aeee:      	testq	%rax, %rax
   5aef1:      	je	0x5b343 <f.8+0xd23>
   5aef7:      	movq	%rax, %r14
   5aefa:      	movq	$0x5e, (%rax)
   5af01:      	movl	$0x0, 0x8(%rax)
   5af08:      	movq	$0x0, 0x10(%rax)
   5af10:      	movq	%rax, 0x40(%rsp)
   5af15:      	movq	0x38(%rsp), %rax
   5af1a:      	testq	%rax, %rax
   5af1d:      	je	0x5b343 <f.8+0xd23>
   5af23:      	movq	0x50(%rsp), %r12
   5af28:      	movq	0x48(%rsp), %rbx
   5af2d:      	movq	0x20(%rax), %r13
   5af31:      	movq	%r13, 0x78(%rsp)
   5af36:      	movq	%rbx, 0x80(%rsp)
   5af3e:      	movq	%r12, 0x88(%rsp)
   5af46:      	leaq	0x4f4b(%rip), %rbp      # 0x5fe98 <ref.11>
   5af4d:      	movq	%rbp, 0x90(%rsp)
   5af55:      	movq	%r14, 0x98(%rsp)
   5af5d:      	leaq	0x4f24(%rip), %rax      # 0x5fe88 <ref.10>
   5af64:      	movq	%rax, 0xa0(%rsp)
   5af6c:      	movq	%r14, 0xa8(%rsp)
   5af74:      	movq	$0xf, 0x30(%rsp)
   5af7d:      	movl	$0x20, %edi
   5af82:      	callq	0x28860 <native_alloc>
   5af87:      	testq	%rax, %rax
   5af8a:      	je	0x5b343 <f.8+0xd23>
   5af90:      	movq	%rax, %r15
   5af93:      	movq	$0x2a, (%rax)
   5af9a:      	movq	%r12, 0x8(%rax)
   5af9e:      	movq	%rbx, 0x10(%rax)
   5afa2:      	movq	%r13, 0x18(%rax)
   5afa6:      	movq	%rax, 0x78(%rsp)
   5afab:      	movq	%rbp, 0x80(%rsp)
   5afb3:      	movq	%r14, 0x88(%rsp)
   5afbb:      	leaq	0x4ec6(%rip), %rbx      # 0x5fe88 <ref.10>
   5afc2:      	movq	%rbx, 0x90(%rsp)
   5afca:      	movq	%r14, 0x98(%rsp)
   5afd2:      	movq	$0xd, 0x30(%rsp)
   5afdb:      	movl	$0x18, %edi
   5afe0:      	callq	0x28860 <native_alloc>
   5afe5:      	testq	%rax, %rax
   5afe8:      	je	0x5b343 <f.8+0xd23>
   5afee:      	movq	%rax, %r12
   5aff1:      	movq	$0x82, (%rax)
   5aff8:      	movq	%rbp, 0x8(%rax)
   5affc:      	movq	%r15, 0x10(%rax)
   5b000:      	movq	%rax, 0x78(%rsp)
   5b005:      	movq	%r14, 0x80(%rsp)
   5b00d:      	movq	%rbx, 0x88(%rsp)
   5b015:      	movq	%r14, 0x90(%rsp)
   5b01d:      	movq	$0xc, 0x30(%rsp)
   5b026:      	movl	$0x18, %edi
   5b02b:      	callq	0x28860 <native_alloc>
   5b030:      	testq	%rax, %rax
   5b033:      	je	0x5b343 <f.8+0xd23>
   5b039:      	movq	%rax, %r15
   5b03c:      	movq	$0x5e, (%rax)
   5b043:      	movl	$0x1, 0x8(%rax)
   5b04a:      	movq	%r12, 0x10(%rax)
   5b04e:      	movq	%rax, 0x78(%rsp)
   5b053:      	movq	%r14, 0x80(%rsp)
   5b05b:      	movq	%rbx, 0x88(%rsp)
   5b063:      	movq	%r14, 0x90(%rsp)
   5b06b:      	movq	$0xc, 0x30(%rsp)
   5b074:      	movl	$0x20, %edi
   5b079:      	callq	0x28860 <native_alloc>
   5b07e:      	movq	%rax, %r12
   5b081:      	testq	%rax, %rax
   5b084:      	movq	0xb0(%rsp), %rax
   5b08c:      	je	0x5b343 <f.8+0xd23>
   5b092:      	movq	$0x26, (%r12)
   5b09a:      	movq	%rax, 0x8(%r12)
   5b09f:      	movq	%r14, 0x10(%r12)
   5b0a4:      	movq	%r15, 0x18(%r12)
   5b0a9:      	movq	%r12, 0x78(%rsp)
   5b0ae:      	movq	%rbx, 0x80(%rsp)
   5b0b6:      	movq	%r14, 0x88(%rsp)
   5b0be:      	movq	$0xb, 0x30(%rsp)
   5b0c7:      	movl	$0x18, %edi
   5b0cc:      	callq	0x28860 <native_alloc>
   5b0d1:      	testq	%rax, %rax
   5b0d4:      	je	0x5b343 <f.8+0xd23>
   5b0da:      	movq	$0x82, (%rax)
   5b0e1:      	movq	%rbx, 0x8(%rax)
   5b0e5:      	movq	%r12, 0x10(%rax)
   5b0e9:      	movq	%rax, 0x10(%r14)
   5b0ed:      	movq	0x40(%rsp), %rax
   5b0f2:      	testq	%rax, %rax
   5b0f5:      	je	0x5b343 <f.8+0xd23>
   5b0fb:      	movl	$0x1, 0x8(%rax)
   5b102:      	movq	0x40(%rsp), %rax
   5b107:      	testq	%rax, %rax
   5b10a:      	je	0x5b343 <f.8+0xd23>
   5b110:      	cmpl	$0x0, 0x8(%rax)
   5b114:      	je	0x5b343 <f.8+0xd23>
   5b11a:      	movq	0x10(%rax), %rax
   5b11e:      	testq	%rax, %rax
   5b121:      	je	0x5b343 <f.8+0xd23>
   5b127:      	movq	%rax, 0x58(%rsp)
   5b12c:      	movq	0x8(%rax), %rcx
   5b130:      	testq	%rcx, %rcx
   5b133:      	je	0x5b343 <f.8+0xd23>
   5b139:      	movq	0x10(%rax), %rdi
   5b13d:      	movq	0x8(%rcx), %rax
   5b141:      	movq	%rdi, 0x78(%rsp)
   5b146:      	movq	$0x9, 0x30(%rsp)
   5b14f:      	movl	$0x4, %esi
   5b154:      	callq	*%rax
   5b156:      	subq	$0x8, %rsp
   5b15a:      	cmpb	$0x0, 0x7007(%rip)      # 0x62168 <g.3>
   5b161:      	je	0x5b343 <f.8+0xd23>
   5b167:      	cmpq	$0x0, 0x6ff1(%rip)      # 0x62160 <g.2>
   5b16f:      	je	0x5b343 <f.8+0xd23>
   5b175:      	cmpb	$0x0, 0x705c(%rip)      # 0x621d8 <g.17>
   5b17c:      	je	0x5b343 <f.8+0xd23>
   5b182:      	cmpq	$0x0, 0x7046(%rip)      # 0x621d0 <g.16>
   5b18a:      	je	0x5b343 <f.8+0xd23>
   5b190:      	movq	0x60(%rsp), %rax
   5b195:      	testq	%rax, %rax
   5b198:      	je	0x5b343 <f.8+0xd23>
   5b19e:      	testb	$0x1, %al
   5b1a0:      	jne	0x5b343 <f.8+0xd23>
   5b1a6:      	movq	0x8(%rax), %rdx
   5b1aa:      	movl	%edx, %esi
   5b1ac:      	shrl	%esi
   5b1ae:      	cmpq	$0x3e9, %rsi            # imm = 0x3E9
   5b1b5:      	movl	$0x3e9, %ecx            # imm = 0x3E9
   5b1ba:      	cmovbq	%rsi, %rcx
   5b1be:      	leaq	-0x1(%rcx), %rsi
   5b1c2:      	movq	%rsi, %rdi
   5b1c5:      	shrq	$0x20, %rdi
   5b1c9:      	jne	0x5b343 <f.8+0xd23>
   5b1cf:      	cmpq	%rdx, %rsi
   5b1d2:      	jae	0x5b343 <f.8+0xd23>
   5b1d8:      	cmpb	$0x0, 0x7009(%rip)      # 0x621e8 <g.19>
   5b1df:      	je	0x5b343 <f.8+0xd23>
   5b1e5:      	cmpq	$0x0, 0x6ff3(%rip)      # 0x621e0 <g.18>
   5b1ed:      	je	0x5b343 <f.8+0xd23>
   5b1f3:      	movsd	0x8(%rax,%rcx,8), %xmm0
   5b1f9:      	cvtsi2sd	%ecx, %xmm1
   5b1fd:      	movsd	-0x569f5(%rip), %xmm2   # 0x4810 <writev+0x4810>
   5b205:      	divsd	%xmm1, %xmm2
   5b209:      	ucomisd	%xmm2, %xmm0
   5b20d:      	jne	0x5b211 <f.8+0xbf1>
   5b20f:      	jnp	0x5b274 <f.8+0xc54>
   5b211:      	movq	$0x8, 0x30(%rsp)
   5b21a:      	leaq	0x8(%rsp), %rbx
   5b21f:      	movq	%rbx, %rdi
   5b222:      	xorl	%esi, %esi
   5b224:      	callq	0x2ac30 <native_roots_enter>
   5b229:      	movq	$0x0, 0x18(%rsp)
   5b232:      	movl	$0x7, %edi
   5b237:      	callq	0x145b0 <print_text>
   5b23c:      	movq	%rbx, %rdi
   5b23f:      	callq	0x2ac80 <native_roots_leave>
   5b244:      	movq	$0x8, 0x30(%rsp)
   5b24d:      	leaq	0x8(%rsp), %rbx
   5b252:      	movq	%rbx, %rdi
   5b255:      	xorl	%esi, %esi
   5b257:      	callq	0x2ac30 <native_roots_enter>
   5b25c:      	movq	$0x0, 0x18(%rsp)
   5b265:      	xorl	%edi, %edi
   5b267:      	callq	0x145b0 <print_text>
   5b26c:      	movq	%rbx, %rdi
   5b26f:      	callq	0x2ac80 <native_roots_leave>
   5b274:      	cmpb	$0x0, 0x6f9d(%rip)      # 0x62218 <g.25>
   5b27b:      	je	0x5b343 <f.8+0xd23>
   5b281:      	cmpq	$0x0, 0x6f87(%rip)      # 0x62210 <g.24>
   5b289:      	je	0x5b343 <f.8+0xd23>
   5b28f:      	movq	$0x8, 0x30(%rsp)
   5b298:      	leaq	0x8(%rsp), %rbx
   5b29d:      	movq	%rbx, %rdi
   5b2a0:      	xorl	%esi, %esi
   5b2a2:      	callq	0x2ac30 <native_roots_enter>
   5b2a7:      	movq	$0x0, 0x18(%rsp)
   5b2b0:      	movl	$0x1, %edi
   5b2b5:      	callq	0x145b0 <print_text>
   5b2ba:      	movq	%rbx, %rdi
   5b2bd:      	callq	0x2ac80 <native_roots_leave>
   5b2c2:      	movq	$0x8, 0x30(%rsp)
   5b2cb:      	leaq	0x8(%rsp), %rbx
   5b2d0:      	movq	%rbx, %rdi
   5b2d3:      	xorl	%esi, %esi
   5b2d5:      	callq	0x2ac30 <native_roots_enter>
   5b2da:      	movq	$0x0, 0x18(%rsp)
   5b2e3:      	movl	$0x2, %edi
   5b2e8:      	callq	0x145b0 <print_text>
   5b2ed:      	movq	%rbx, %rdi
   5b2f0:      	callq	0x2ac80 <native_roots_leave>
   5b2f5:      	movq	$0x8, 0x30(%rsp)
   5b2fe:      	leaq	0x8(%rsp), %rbx
   5b303:      	movq	%rbx, %rdi
   5b306:      	xorl	%esi, %esi
   5b308:      	callq	0x2ac30 <native_roots_enter>
   5b30d:      	movq	$0x0, 0x18(%rsp)
   5b316:      	xorl	%edi, %edi
   5b318:      	callq	0x145b0 <print_text>
   5b31d:      	movq	%rbx, %rdi
   5b320:      	callq	0x2ac80 <native_roots_leave>
   5b325:      	leaq	0x20(%rsp), %rdi
   5b32a:      	callq	0x2ac80 <native_roots_leave>
   5b32f:      	addq	$0xb8, %rsp
   5b336:      	popq	%rbx
   5b337:      	popq	%r12
   5b339:      	popq	%r13
   5b33b:      	popq	%r14
   5b33d:      	popq	%r15
   5b33f:      	popq	%rbp
   5b340:      	retq	$0x8
   5b343:      	callq	0x268c0 <native_trap>
   5b348:      	int3
   5b349:      	int3
   5b34a:      	int3
   5b34b:      	int3
   5b34c:      	int3
   5b34d:      	int3
   5b34e:      	int3
   5b34f:      	int3

000000000005b350 <f.9>:
   5b350:      	pushq	%r15
   5b352:      	pushq	%r14
   5b354:      	pushq	%r12
   5b356:      	pushq	%rbx
   5b357:      	subq	$0x28, %rsp
   5b35b:      	movq	%rdx, %rbx
   5b35e:      	movq	%rsi, %r14
   5b361:      	movq	%rdi, %r15
   5b364:      	leaq	0x8(%rsp), %r12
   5b369:      	movq	%r12, %rdi
   5b36c:      	xorl	%esi, %esi
   5b36e:      	callq	0x2ac30 <native_roots_enter>
   5b373:      	movq	%r15, 0x20(%rsp)
   5b378:      	cmpq	%rbx, %r14
   5b37b:      	cmovlq	%r14, %rbx
   5b37f:      	movq	%r12, %rdi
   5b382:      	callq	0x2ac80 <native_roots_leave>
   5b387:      	movq	%rbx, %rax
   5b38a:      	addq	$0x28, %rsp
   5b38e:      	popq	%rbx
   5b38f:      	popq	%r12
   5b391:      	popq	%r14
   5b393:      	popq	%r15
   5b395:      	retq	$0x8
   5b398:      	int3
   5b399:      	int3
   5b39a:      	int3
   5b39b:      	int3
   5b39c:      	int3
   5b39d:      	int3
   5b39e:      	int3
   5b39f:      	int3

000000000005b3a0 <f.10>:
   5b3a0:      	pushq	%rbp
   5b3a1:      	pushq	%r15
   5b3a3:      	pushq	%r14
   5b3a5:      	pushq	%r13
   5b3a7:      	pushq	%r12
   5b3a9:      	pushq	%rbx
   5b3aa:      	subq	$0x48, %rsp
   5b3ae:      	movq	%rsi, %rbx
   5b3b1:      	movq	%rdi, %r15
   5b3b4:      	leaq	0x8(%rsp), %rdi
   5b3b9:      	movl	$0x5, %esi
   5b3be:      	callq	0x2ac30 <native_roots_enter>
   5b3c3:      	movq	%r15, 0x20(%rsp)
   5b3c8:      	movq	$0x0, 0x28(%rsp)
   5b3d1:      	movq	$0x0, 0x30(%rsp)
   5b3da:      	movl	$0x26, %esi
   5b3df:      	movq	%r15, %rdi
   5b3e2:      	xorl	%edx, %edx
   5b3e4:      	xorl	%ecx, %ecx
   5b3e6:      	callq	0x2ab40 <native_ref_test>
   5b3eb:      	testl	%eax, %eax
   5b3ed:      	je	0x5b5d1 <f.10+0x231>
   5b3f3:      	leaq	0x28(%rsp), %r12
   5b3f8:      	leaq	0x8(%rsp), %r14
   5b3fd:      	nopl	(%rax)
   5b400:      	testq	%r15, %r15
   5b403:      	je	0x5b5d1 <f.10+0x231>
   5b409:      	cmpq	%rbx, 0x8(%r15)
   5b40d:      	jl	0x5b5d6 <f.10+0x236>
   5b413:      	movq	0x20(%rsp), %r15
   5b418:      	movl	$0x26, %esi
   5b41d:      	movq	%r15, %rdi
   5b420:      	xorl	%edx, %edx
   5b422:      	xorl	%ecx, %ecx
   5b424:      	callq	0x2ab40 <native_ref_test>
   5b429:      	testl	%eax, %eax
   5b42b:      	je	0x5b5d1 <f.10+0x231>
   5b431:      	testq	%r15, %r15
   5b434:      	je	0x5b5d1 <f.10+0x231>
   5b43a:      	movq	0x18(%r15), %rax
   5b43e:      	testq	%rax, %rax
   5b441:      	je	0x5b5d1 <f.10+0x231>
   5b447:      	cmpl	$0x0, 0x8(%rax)
   5b44b:      	je	0x5b5d1 <f.10+0x231>
   5b451:      	movq	0x20(%rsp), %r15
   5b456:      	movl	$0x26, %esi
   5b45b:      	movq	%r15, %rdi
   5b45e:      	xorl	%edx, %edx
   5b460:      	xorl	%ecx, %ecx
   5b462:      	callq	0x2ab40 <native_ref_test>
   5b467:      	testl	%eax, %eax
   5b469:      	je	0x5b5d1 <f.10+0x231>
   5b46f:      	movq	%r15, 0x28(%rsp)
   5b474:      	testq	%r15, %r15
   5b477:      	je	0x5b5d1 <f.10+0x231>
   5b47d:      	movq	0x18(%r15), %rax
   5b481:      	testq	%rax, %rax
   5b484:      	je	0x5b5d1 <f.10+0x231>
   5b48a:      	movq	0x10(%rax), %rax
   5b48e:      	testq	%rax, %rax
   5b491:      	je	0x5b5d1 <f.10+0x231>
   5b497:      	movq	0x10(%rax), %r15
   5b49b:      	movl	$0x2a, %esi
   5b4a0:      	movq	%r15, %rdi
   5b4a3:      	xorl	%edx, %edx
   5b4a5:      	xorl	%ecx, %ecx
   5b4a7:      	callq	0x2ab40 <native_ref_test>
   5b4ac:      	testl	%eax, %eax
   5b4ae:      	je	0x5b5d1 <f.10+0x231>
   5b4b4:      	movq	%r15, 0x30(%rsp)
   5b4b9:      	testq	%r15, %r15
   5b4bc:      	je	0x5b5d1 <f.10+0x231>
   5b4c2:      	movq	0x18(%r15), %rax
   5b4c6:      	testq	%rax, %rax
   5b4c9:      	je	0x5b5d1 <f.10+0x231>
   5b4cf:      	movq	0x8(%rax), %rax
   5b4d3:      	testq	%rax, %rax
   5b4d6:      	je	0x5b5d1 <f.10+0x231>
   5b4dc:      	movq	0x8(%rax), %rdi
   5b4e0:      	movq	%rdi, 0x38(%rsp)
   5b4e5:      	movq	$0x4, 0x18(%rsp)
   5b4ee:      	movq	%rbx, %rsi
   5b4f1:      	callq	0x5bf60 <f.15>
   5b4f6:      	subq	$0x8, %rsp
   5b4fa:      	movq	%rax, %r15
   5b4fd:      	movq	0x30(%rsp), %rax
   5b502:      	testq	%rax, %rax
   5b505:      	je	0x5b5d1 <f.10+0x231>
   5b50b:      	movq	0x8(%rax), %r13
   5b50f:      	movq	0x10(%rax), %rbp
   5b513:      	movq	%rbp, 0x38(%rsp)
   5b518:      	movq	%r13, 0x40(%rsp)
   5b51d:      	movq	$0x5, 0x18(%rsp)
   5b526:      	movl	$0x20, %edi
   5b52b:      	callq	0x28860 <native_alloc>
   5b530:      	testq	%rax, %rax
   5b533:      	je	0x5b5d1 <f.10+0x231>
   5b539:      	movq	$0x22, (%rax)
   5b540:      	movq	%r13, 0x8(%rax)
   5b544:      	movq	%rbp, 0x10(%rax)
   5b548:      	movq	%rbx, 0x18(%rax)
   5b54c:      	movq	%rax, 0x38(%rsp)
   5b551:      	movq	$0x4, 0x18(%rsp)
   5b55a:      	movq	%rax, %rdi
   5b55d:      	movq	%r15, %rsi
   5b560:      	callq	0x5b710 <f.12>
   5b565:      	subq	$0x8, %rsp
   5b569:      	movq	0x28(%rsp), %r15
   5b56e:      	testq	%r15, %r15
   5b571:      	je	0x5b5d1 <f.10+0x231>
   5b573:      	movq	0x10(%r15), %rax
   5b577:      	testq	%rax, %rax
   5b57a:      	je	0x5b5d1 <f.10+0x231>
   5b57c:      	cmpl	$0x0, 0x8(%rax)
   5b580:      	je	0x5b5d1 <f.10+0x231>
   5b582:      	cmpq	$0x0, 0x10(%rax)
   5b587:      	je	0x5b5d1 <f.10+0x231>
   5b589:      	addq	$0x2, %rbx
   5b58d:      	movq	%r14, %rdi
   5b590:      	callq	0x2ac80 <native_roots_leave>
   5b595:      	movl	$0x5, %esi
   5b59a:      	movq	%r14, %rdi
   5b59d:      	callq	0x2ac30 <native_roots_enter>
   5b5a2:      	movq	%r15, 0x20(%rsp)
   5b5a7:      	movq	$0x0, 0x8(%r12)
   5b5b0:      	movq	$0x0, (%r12)
   5b5b8:      	movl	$0x26, %esi
   5b5bd:      	movq	%r15, %rdi
   5b5c0:      	xorl	%edx, %edx
   5b5c2:      	xorl	%ecx, %ecx
   5b5c4:      	callq	0x2ab40 <native_ref_test>
   5b5c9:      	testl	%eax, %eax
   5b5cb:      	jne	0x5b400 <f.10+0x60>
   5b5d1:      	callq	0x268c0 <native_trap>
   5b5d6:      	leaq	0x8(%rsp), %rdi
   5b5db:      	callq	0x2ac80 <native_roots_leave>
   5b5e0:      	xorl	%eax, %eax
   5b5e2:      	addq	$0x48, %rsp
   5b5e6:      	popq	%rbx
   5b5e7:      	popq	%r12
   5b5e9:      	popq	%r13
   5b5eb:      	popq	%r14
   5b5ed:      	popq	%r15
   5b5ef:      	popq	%rbp
   5b5f0:      	retq	$0x8
   5b5f3:      	int3
   5b5f4:      	int3
   5b5f5:      	int3
   5b5f6:      	int3
   5b5f7:      	int3
   5b5f8:      	int3
   5b5f9:      	int3
   5b5fa:      	int3
   5b5fb:      	int3
   5b5fc:      	int3
   5b5fd:      	int3
   5b5fe:      	int3
   5b5ff:      	int3

000000000005b600 <f.11>:
   5b600:      	pushq	%r15
   5b602:      	pushq	%r14
   5b604:      	pushq	%r13
   5b606:      	pushq	%r12
   5b608:      	pushq	%rbx
   5b609:      	subq	$0x40, %rsp
   5b60d:      	movq	%rsi, %rbx
   5b610:      	movq	%rdi, %r14
   5b613:      	leaq	0x8(%rsp), %rdi
   5b618:      	movl	$0x4, %esi
   5b61d:      	callq	0x2ac30 <native_roots_enter>
   5b622:      	movq	%r14, 0x20(%rsp)
   5b627:      	movq	$0x0, 0x28(%rsp)
   5b630:      	movl	$0x2a, %esi
   5b635:      	movq	%r14, %rdi
   5b638:      	xorl	%edx, %edx
   5b63a:      	xorl	%ecx, %ecx
   5b63c:      	callq	0x2ab40 <native_ref_test>
   5b641:      	testl	%eax, %eax
   5b643:      	je	0x5b6fe <f.11+0xfe>
   5b649:      	movq	%r14, 0x28(%rsp)
   5b64e:      	testq	%r14, %r14
   5b651:      	je	0x5b6fe <f.11+0xfe>
   5b657:      	movq	0x18(%r14), %rax
   5b65b:      	testq	%rax, %rax
   5b65e:      	je	0x5b6fe <f.11+0xfe>
   5b664:      	movq	0x8(%rax), %rax
   5b668:      	testq	%rax, %rax
   5b66b:      	je	0x5b6fe <f.11+0xfe>
   5b671:      	movq	0x8(%rax), %rdi
   5b675:      	movq	%rdi, 0x30(%rsp)
   5b67a:      	movq	$0x3, 0x18(%rsp)
   5b683:      	movq	%rbx, %rsi
   5b686:      	callq	0x5bf60 <f.15>
   5b68b:      	subq	$0x8, %rsp
   5b68f:      	movq	%rax, %r14
   5b692:      	movq	0x28(%rsp), %rax
   5b697:      	testq	%rax, %rax
   5b69a:      	je	0x5b6fe <f.11+0xfe>
   5b69c:      	movq	0x8(%rax), %r12
   5b6a0:      	movq	0x10(%rax), %r13
   5b6a4:      	movq	%r13, 0x30(%rsp)
   5b6a9:      	movq	%r12, 0x38(%rsp)
   5b6ae:      	movq	$0x4, 0x18(%rsp)
   5b6b7:      	movl	$0x20, %edi
   5b6bc:      	callq	0x28860 <native_alloc>
   5b6c1:      	testq	%rax, %rax
   5b6c4:      	je	0x5b6fe <f.11+0xfe>
   5b6c6:      	movq	%rax, %r15
   5b6c9:      	movq	$0x22, (%rax)
   5b6d0:      	movq	%r12, 0x8(%rax)
   5b6d4:      	movq	%r13, 0x10(%rax)
   5b6d8:      	movq	%rbx, 0x18(%rax)
   5b6dc:      	leaq	0x8(%rsp), %rdi
   5b6e1:      	callq	0x2ac80 <native_roots_leave>
   5b6e6:      	movq	%r15, %rdi
   5b6e9:      	movq	%r14, %rsi
   5b6ec:      	addq	$0x40, %rsp
   5b6f0:      	popq	%rbx
   5b6f1:      	popq	%r12
   5b6f3:      	popq	%r13
   5b6f5:      	popq	%r14
   5b6f7:      	popq	%r15
   5b6f9:      	jmp	0x5b710 <f.12>
   5b6fe:      	callq	0x268c0 <native_trap>
   5b703:      	int3
   5b704:      	int3
   5b705:      	int3
   5b706:      	int3
   5b707:      	int3
   5b708:      	int3
   5b709:      	int3
   5b70a:      	int3
   5b70b:      	int3
   5b70c:      	int3
   5b70d:      	int3
   5b70e:      	int3
   5b70f:      	int3

000000000005b710 <f.12>:
   5b710:      	pushq	%rbp
   5b711:      	pushq	%r15
   5b713:      	pushq	%r14
   5b715:      	pushq	%r13
   5b717:      	pushq	%r12
   5b719:      	pushq	%rbx
   5b71a:      	subq	$0x88, %rsp
   5b721:      	movq	%rsi, %rbx
   5b724:      	movq	%rdi, %r14
   5b727:      	leaq	0x8(%rsp), %rdi
   5b72c:      	movl	$0x7, %esi
   5b731:      	callq	0x2ac30 <native_roots_enter>
   5b736:      	movq	%r14, 0x20(%rsp)
   5b73b:      	testq	%r14, %r14
   5b73e:      	movq	$0x0, 0x28(%rsp)
   5b747:      	movq	$0x0, 0x30(%rsp)
   5b750:      	je	0x5bb49 <f.12+0x439>
   5b756:      	movq	0x18(%r14), %r14
   5b75a:      	movq	$0x3, 0x18(%rsp)
   5b763:      	leaq	0x58(%rsp), %r15
   5b768:      	movq	%r15, %rdi
   5b76b:      	xorl	%esi, %esi
   5b76d:      	callq	0x2ac30 <native_roots_enter>
   5b772:      	movq	$0x0, 0x68(%rsp)
   5b77b:      	movq	%rbx, %rdi
   5b77e:      	movq	%r14, %rsi
   5b781:      	callq	0x144e0 <print_construction>
   5b786:      	movq	%r15, %rdi
   5b789:      	callq	0x2ac80 <native_roots_leave>
   5b78e:      	movq	$0x3, 0x18(%rsp)
   5b797:      	leaq	0x58(%rsp), %r14
   5b79c:      	movq	%r14, %rdi
   5b79f:      	xorl	%esi, %esi
   5b7a1:      	callq	0x2ac30 <native_roots_enter>
   5b7a6:      	movq	$0x0, 0x68(%rsp)
   5b7af:      	xorl	%edi, %edi
   5b7b1:      	callq	0x145b0 <print_text>
   5b7b6:      	movq	%r14, %rdi
   5b7b9:      	callq	0x2ac80 <native_roots_leave>
   5b7be:      	cmpb	$0x0, 0x6a43(%rip)      # 0x62208 <g.23>
   5b7c5:      	je	0x5bb49 <f.12+0x439>
   5b7cb:      	cmpq	$0x0, 0x6a2d(%rip)      # 0x62200 <g.22>
   5b7d3:      	je	0x5bb49 <f.12+0x439>
   5b7d9:      	movq	$0x3, 0x18(%rsp)
   5b7e2:      	leaq	0x58(%rsp), %r14
   5b7e7:      	movq	%r14, %rdi
   5b7ea:      	xorl	%esi, %esi
   5b7ec:      	callq	0x2ac30 <native_roots_enter>
   5b7f1:      	movq	$0x0, 0x68(%rsp)
   5b7fa:      	movl	$0x4, %edi
   5b7ff:      	callq	0x145b0 <print_text>
   5b804:      	movq	%r14, %rdi
   5b807:      	callq	0x2ac80 <native_roots_leave>
   5b80c:      	movq	$0x3, 0x18(%rsp)
   5b815:      	leaq	0x58(%rsp), %r14
   5b81a:      	movq	%r14, %rdi
   5b81d:      	xorl	%esi, %esi
   5b81f:      	callq	0x2ac30 <native_roots_enter>
   5b824:      	movq	$0x0, 0x68(%rsp)
   5b82d:      	xorl	%edi, %edi
   5b82f:      	callq	0x145b0 <print_text>
   5b834:      	movq	%r14, %rdi
   5b837:      	callq	0x2ac80 <native_roots_leave>
   5b83c:      	movq	$0x3, 0x18(%rsp)
   5b845:      	movl	$0x18, %edi
   5b84a:      	callq	0x28860 <native_alloc>
   5b84f:      	testq	%rax, %rax
   5b852:      	je	0x5bb49 <f.12+0x439>
   5b858:      	movq	%rax, %r14
   5b85b:      	movq	$0x5e, (%rax)
   5b862:      	movl	$0x0, 0x8(%rax)
   5b869:      	movq	$0x0, 0x10(%rax)
   5b871:      	movq	%rax, 0x28(%rsp)
   5b876:      	movq	0x20(%rsp), %rax
   5b87b:      	testq	%rax, %rax
   5b87e:      	je	0x5bb49 <f.12+0x439>
   5b884:      	movups	0x10(%rax), %xmm0
   5b888:      	movaps	%xmm0, 0x70(%rsp)
   5b88d:      	movq	0x10(%rax), %rax
   5b891:      	movq	%r14, 0x38(%rsp)
   5b896:      	movq	%rax, 0x40(%rsp)
   5b89b:      	leaq	0x4616(%rip), %r12      # 0x5feb8 <ref.14>
   5b8a2:      	movq	%r12, 0x48(%rsp)
   5b8a7:      	movq	%r14, 0x50(%rsp)
   5b8ac:      	movq	$0x7, 0x18(%rsp)
   5b8b5:      	movl	$0x28, %edi
   5b8ba:      	callq	0x28860 <native_alloc>
   5b8bf:      	testq	%rax, %rax
   5b8c2:      	je	0x5bb49 <f.12+0x439>
   5b8c8:      	movq	%rax, %r15
   5b8cb:      	movq	$0x1a, (%rax)
   5b8d2:      	movaps	0x70(%rsp), %xmm0
   5b8d7:      	movups	%xmm0, 0x8(%rax)
   5b8db:      	movq	%rbx, 0x18(%rax)
   5b8df:      	movq	%r14, 0x20(%rax)
   5b8e3:      	movq	%rax, 0x38(%rsp)
   5b8e8:      	movq	%r12, 0x40(%rsp)
   5b8ed:      	movq	%r14, 0x48(%rsp)
   5b8f2:      	movq	$0x6, 0x18(%rsp)
   5b8fb:      	movl	$0x18, %edi
   5b900:      	callq	0x28860 <native_alloc>
   5b905:      	testq	%rax, %rax
   5b908:      	je	0x5bb49 <f.12+0x439>
   5b90e:      	movq	$0x82, (%rax)
   5b915:      	movq	%r12, 0x8(%rax)
   5b919:      	movq	%r15, 0x10(%rax)
   5b91d:      	movq	%rax, 0x10(%r14)
   5b921:      	movq	0x28(%rsp), %rax
   5b926:      	testq	%rax, %rax
   5b929:      	je	0x5bb49 <f.12+0x439>
   5b92f:      	movl	$0x1, 0x8(%rax)
   5b936:      	movq	0x28(%rsp), %rax
   5b93b:      	testq	%rax, %rax
   5b93e:      	je	0x5bb49 <f.12+0x439>
   5b944:      	cmpl	$0x0, 0x8(%rax)
   5b948:      	je	0x5bb49 <f.12+0x439>
   5b94e:      	movq	0x10(%rax), %rax
   5b952:      	testq	%rax, %rax
   5b955:      	je	0x5bb49 <f.12+0x439>
   5b95b:      	movq	%rax, 0x30(%rsp)
   5b960:      	movq	0x8(%rax), %rcx
   5b964:      	testq	%rcx, %rcx
   5b967:      	je	0x5bb49 <f.12+0x439>
   5b96d:      	movq	0x10(%rax), %rdi
   5b971:      	movq	0x8(%rcx), %rax
   5b975:      	movq	%rdi, 0x38(%rsp)
   5b97a:      	movq	$0x4, 0x18(%rsp)
   5b983:      	xorl	%esi, %esi
   5b985:      	callq	*%rax
   5b987:      	subq	$0x8, %rsp
   5b98b:      	cmpb	$0x0, 0x6876(%rip)      # 0x62208 <g.23>
   5b992:      	je	0x5bb49 <f.12+0x439>
   5b998:      	cmpq	$0x0, 0x6860(%rip)      # 0x62200 <g.22>
   5b9a0:      	je	0x5bb49 <f.12+0x439>
   5b9a6:      	movq	$0x3, 0x18(%rsp)
   5b9af:      	leaq	0x58(%rsp), %r14
   5b9b4:      	movq	%r14, %rdi
   5b9b7:      	xorl	%esi, %esi
   5b9b9:      	callq	0x2ac30 <native_roots_enter>
   5b9be:      	movq	$0x0, 0x68(%rsp)
   5b9c7:      	movl	$0x5, %edi
   5b9cc:      	callq	0x145b0 <print_text>
   5b9d1:      	movq	%r14, %rdi
   5b9d4:      	callq	0x2ac80 <native_roots_leave>
   5b9d9:      	movq	$0x3, 0x18(%rsp)
   5b9e2:      	leaq	0x58(%rsp), %r14
   5b9e7:      	movq	%r14, %rdi
   5b9ea:      	xorl	%esi, %esi
   5b9ec:      	callq	0x2ac30 <native_roots_enter>
   5b9f1:      	movq	$0x0, 0x68(%rsp)
   5b9fa:      	xorl	%edi, %edi
   5b9fc:      	callq	0x145b0 <print_text>
   5ba01:      	movq	%r14, %rdi
   5ba04:      	callq	0x2ac80 <native_roots_leave>
   5ba09:      	movq	$0x3, 0x18(%rsp)
   5ba12:      	movl	$0x18, %edi
   5ba17:      	callq	0x28860 <native_alloc>
   5ba1c:      	testq	%rax, %rax
   5ba1f:      	je	0x5bb49 <f.12+0x439>
   5ba25:      	movq	%rax, %r14
   5ba28:      	movq	$0x5e, (%rax)
   5ba2f:      	movl	$0x0, 0x8(%rax)
   5ba36:      	movq	$0x0, 0x10(%rax)
   5ba3e:      	movq	%rax, 0x28(%rsp)
   5ba43:      	movq	0x20(%rsp), %rax
   5ba48:      	testq	%rax, %rax
   5ba4b:      	je	0x5bb49 <f.12+0x439>
   5ba51:      	movq	0x8(%rax), %r13
   5ba55:      	movq	0x18(%rax), %rbp
   5ba59:      	movq	%r14, 0x38(%rsp)
   5ba5e:      	movq	%r13, 0x40(%rsp)
   5ba63:      	leaq	0x443e(%rip), %r12      # 0x5fea8 <ref.13>
   5ba6a:      	movq	%r12, 0x48(%rsp)
   5ba6f:      	movq	%r14, 0x50(%rsp)
   5ba74:      	movq	$0x7, 0x18(%rsp)
   5ba7d:      	movl	$0x28, %edi
   5ba82:      	callq	0x28860 <native_alloc>
   5ba87:      	testq	%rax, %rax
   5ba8a:      	je	0x5bb49 <f.12+0x439>
   5ba90:      	movq	%rax, %r15
   5ba93:      	movq	$0x16, (%rax)
   5ba9a:      	movq	%r13, 0x8(%rax)
   5ba9e:      	movq	%rbp, 0x10(%rax)
   5baa2:      	movq	%rbx, 0x18(%rax)
   5baa6:      	movq	%r14, 0x20(%rax)
   5baaa:      	movq	%rax, 0x38(%rsp)
   5baaf:      	movq	%r12, 0x40(%rsp)
   5bab4:      	movq	%r14, 0x48(%rsp)
   5bab9:      	movq	$0x6, 0x18(%rsp)
   5bac2:      	movl	$0x18, %edi
   5bac7:      	callq	0x28860 <native_alloc>
   5bacc:      	testq	%rax, %rax
   5bacf:      	je	0x5bb49 <f.12+0x439>
   5bad1:      	movq	$0x82, (%rax)
   5bad8:      	movq	%r12, 0x8(%rax)
   5badc:      	movq	%r15, 0x10(%rax)
   5bae0:      	movq	%rax, 0x10(%r14)
   5bae4:      	movq	0x28(%rsp), %rax
   5bae9:      	testq	%rax, %rax
   5baec:      	je	0x5bb49 <f.12+0x439>
   5baee:      	movl	$0x1, 0x8(%rax)
   5baf5:      	movq	0x28(%rsp), %rax
   5bafa:      	testq	%rax, %rax
   5bafd:      	je	0x5bb49 <f.12+0x439>
   5baff:      	cmpl	$0x0, 0x8(%rax)
   5bb03:      	je	0x5bb49 <f.12+0x439>
   5bb05:      	movq	0x10(%rax), %rax
   5bb09:      	testq	%rax, %rax
   5bb0c:      	je	0x5bb49 <f.12+0x439>
   5bb0e:      	movq	%rax, 0x30(%rsp)
   5bb13:      	movq	0x8(%rax), %rcx
   5bb17:      	testq	%rcx, %rcx
   5bb1a:      	je	0x5bb49 <f.12+0x439>
   5bb1c:      	movq	0x10(%rax), %rbx
   5bb20:      	movq	0x8(%rcx), %r14
   5bb24:      	leaq	0x8(%rsp), %rdi
   5bb29:      	callq	0x2ac80 <native_roots_leave>
   5bb2e:      	movq	%rbx, %rdi
   5bb31:      	xorl	%esi, %esi
   5bb33:      	movq	%r14, %rax
   5bb36:      	addq	$0x88, %rsp
   5bb3d:      	popq	%rbx
   5bb3e:      	popq	%r12
   5bb40:      	popq	%r13
   5bb42:      	popq	%r14
   5bb44:      	popq	%r15
   5bb46:      	popq	%rbp
   5bb47:      	jmpq	*%rax
   5bb49:      	callq	0x268c0 <native_trap>
   5bb4e:      	int3
   5bb4f:      	int3

000000000005bb50 <f.13>:
   5bb50:      	pushq	%r15
   5bb52:      	pushq	%r14
   5bb54:      	pushq	%rbx
   5bb55:      	subq	$0x40, %rsp
   5bb59:      	movq	%rsi, %rbx
   5bb5c:      	movq	%rdi, %r15
   5bb5f:      	leaq	0x10(%rsp), %rdi
   5bb64:      	movl	$0x3, %esi
   5bb69:      	callq	0x2ac30 <native_roots_enter>
   5bb6e:      	movq	%r15, 0x28(%rsp)
   5bb73:      	movq	$0x0, 0x30(%rsp)
   5bb7c:      	movl	$0x16, %esi
   5bb81:      	movq	%r15, %rdi
   5bb84:      	xorl	%edx, %edx
   5bb86:      	xorl	%ecx, %ecx
   5bb88:      	callq	0x2ab40 <native_ref_test>
   5bb8d:      	testl	%eax, %eax
   5bb8f:      	je	0x5bc7d <f.13+0x12d>
   5bb95:      	decq	%rbx
   5bb98:      	leaq	0x10(%rsp), %r14
   5bb9d:      	nopl	(%rax)
   5bba0:      	testq	%r15, %r15
   5bba3:      	je	0x5bc7d <f.13+0x12d>
   5bba9:      	incq	%rbx
   5bbac:      	cmpq	%rbx, 0x18(%r15)
   5bbb0:      	jle	0x5bc82 <f.13+0x132>
   5bbb6:      	movq	0x28(%rsp), %r15
   5bbbb:      	movl	$0x16, %esi
   5bbc0:      	movq	%r15, %rdi
   5bbc3:      	xorl	%edx, %edx
   5bbc5:      	xorl	%ecx, %ecx
   5bbc7:      	callq	0x2ab40 <native_ref_test>
   5bbcc:      	testl	%eax, %eax
   5bbce:      	je	0x5bc7d <f.13+0x12d>
   5bbd4:      	movq	%r15, 0x30(%rsp)
   5bbd9:      	testq	%r15, %r15
   5bbdc:      	je	0x5bc7d <f.13+0x12d>
   5bbe2:      	movq	0x8(%r15), %rax
   5bbe6:      	testq	%rax, %rax
   5bbe9:      	je	0x5bc7d <f.13+0x12d>
   5bbef:      	cmpl	$0x0, 0x8(%rax)
   5bbf3:      	je	0x5bc7d <f.13+0x12d>
   5bbf9:      	movq	0x10(%rax), %rax
   5bbfd:      	testq	%rax, %rax
   5bc00:      	je	0x5bc7d <f.13+0x12d>
   5bc02:      	movq	0x10(%r15), %rsi
   5bc06:      	movq	0x8(%rax), %rdi
   5bc0a:      	movq	%rdi, 0x38(%rsp)
   5bc0f:      	movq	$0x3, 0x20(%rsp)
   5bc18:      	callq	0x5c9b0 <f.18>
   5bc1d:      	subq	$0x8, %rsp
   5bc21:      	movq	0x30(%rsp), %r15
   5bc26:      	testq	%r15, %r15
   5bc29:      	je	0x5bc7d <f.13+0x12d>
   5bc2b:      	movq	0x20(%r15), %rax
   5bc2f:      	testq	%rax, %rax
   5bc32:      	je	0x5bc7d <f.13+0x12d>
   5bc34:      	cmpl	$0x0, 0x8(%rax)
   5bc38:      	je	0x5bc7d <f.13+0x12d>
   5bc3a:      	cmpq	$0x0, 0x10(%rax)
   5bc3f:      	je	0x5bc7d <f.13+0x12d>
   5bc41:      	movq	%r14, %rdi
   5bc44:      	callq	0x2ac80 <native_roots_leave>
   5bc49:      	movl	$0x3, %esi
   5bc4e:      	movq	%r14, %rdi
   5bc51:      	callq	0x2ac30 <native_roots_enter>
   5bc56:      	movq	%r15, 0x28(%rsp)
   5bc5b:      	movq	$0x0, 0x30(%rsp)
   5bc64:      	movl	$0x16, %esi
   5bc69:      	movq	%r15, %rdi
   5bc6c:      	xorl	%edx, %edx
   5bc6e:      	xorl	%ecx, %ecx
   5bc70:      	callq	0x2ab40 <native_ref_test>
   5bc75:      	testl	%eax, %eax
   5bc77:      	jne	0x5bba0 <f.13+0x50>
   5bc7d:      	callq	0x268c0 <native_trap>
   5bc82:      	leaq	0x10(%rsp), %rdi
   5bc87:      	callq	0x2ac80 <native_roots_leave>
   5bc8c:      	xorl	%eax, %eax
   5bc8e:      	addq	$0x40, %rsp
   5bc92:      	popq	%rbx
   5bc93:      	popq	%r14
   5bc95:      	popq	%r15
   5bc97:      	retq	$0x8
   5bc9a:      	int3
   5bc9b:      	int3
   5bc9c:      	int3
   5bc9d:      	int3
   5bc9e:      	int3
   5bc9f:      	int3

000000000005bca0 <f.14>:
   5bca0:      	pushq	%rbp
   5bca1:      	pushq	%r15
   5bca3:      	pushq	%r14
   5bca5:      	pushq	%r13
   5bca7:      	pushq	%r12
   5bca9:      	pushq	%rbx
   5bcaa:      	subq	$0x58, %rsp
   5bcae:      	movq	%rsi, %rbx
   5bcb1:      	movq	%rdi, %r15
   5bcb4:      	leaq	0x10(%rsp), %rdi
   5bcb9:      	movl	$0x6, %esi
   5bcbe:      	callq	0x2ac30 <native_roots_enter>
   5bcc3:      	movq	%r15, 0x28(%rsp)
   5bcc8:      	movq	$0x0, 0x30(%rsp)
   5bcd1:      	movq	$0x0, 0x38(%rsp)
   5bcda:      	movq	$0x0, 0x40(%rsp)
   5bce3:      	movl	$0x1a, %esi
   5bce8:      	movq	%r15, %rdi
   5bceb:      	xorl	%edx, %edx
   5bced:      	xorl	%ecx, %ecx
   5bcef:      	callq	0x2ab40 <native_ref_test>
   5bcf4:      	testl	%eax, %eax
   5bcf6:      	je	0x5bf34 <f.14+0x294>
   5bcfc:      	decq	%rbx
   5bcff:      	leaq	-0x50696(%rip), %r14    # 0xb670 <object.1.0>
   5bd06:      	nopw	%cs:(%rax,%rax)
   5bd10:      	testq	%r15, %r15
   5bd13:      	je	0x5bf34 <f.14+0x294>
   5bd19:      	incq	%rbx
   5bd1c:      	cmpq	%rbx, 0x18(%r15)
   5bd20:      	jle	0x5bf39 <f.14+0x299>
   5bd26:      	movq	0x28(%rsp), %r15
   5bd2b:      	movl	$0x1a, %esi
   5bd30:      	movq	%r15, %rdi
   5bd33:      	xorl	%edx, %edx
   5bd35:      	xorl	%ecx, %ecx
   5bd37:      	callq	0x2ab40 <native_ref_test>
   5bd3c:      	testl	%eax, %eax
   5bd3e:      	je	0x5bf34 <f.14+0x294>
   5bd44:      	movq	%r15, 0x30(%rsp)
   5bd49:      	testq	%r15, %r15
   5bd4c:      	je	0x5bf34 <f.14+0x294>
   5bd52:      	cmpb	$0x0, 0x641f(%rip)      # 0x62178 <g.5>
   5bd59:      	je	0x5bf34 <f.14+0x294>
   5bd5f:      	cmpq	$0x0, 0x6409(%rip)      # 0x62170 <g.4>
   5bd67:      	je	0x5bf34 <f.14+0x294>
   5bd6d:      	movq	0x8(%r15), %rax
   5bd71:      	testq	%rax, %rax
   5bd74:      	je	0x5bf34 <f.14+0x294>
   5bd7a:      	cmpl	$0x0, 0x8(%rax)
   5bd7e:      	je	0x5bf34 <f.14+0x294>
   5bd84:      	movq	0x10(%r15), %r12
   5bd88:      	movq	%r14, 0x48(%rsp)
   5bd8d:      	movq	$0x5, 0x20(%rsp)
   5bd96:      	movl	$0x10, %edi
   5bd9b:      	callq	0x28860 <native_alloc>
   5bda0:      	testq	%rax, %rax
   5bda3:      	je	0x5bf34 <f.14+0x294>
   5bda9:      	movq	%rax, %r15
   5bdac:      	movq	$0x36, (%rax)
   5bdb3:      	movq	%r14, 0x8(%rax)
   5bdb7:      	movq	%r14, 0x48(%rsp)
   5bdbc:      	movq	%rax, 0x50(%rsp)
   5bdc1:      	movq	$0x6, 0x20(%rsp)
   5bdca:      	movl	$0x10, %edi
   5bdcf:      	callq	0x28860 <native_alloc>
   5bdd4:      	testq	%rax, %rax
   5bdd7:      	je	0x5bf34 <f.14+0x294>
   5bddd:      	movq	%rax, %rbp
   5bde0:      	movq	$0x36, (%rax)
   5bde7:      	movq	%r14, 0x8(%rax)
   5bdeb:      	movq	%rax, 0x48(%rsp)
   5bdf0:      	movq	%r15, 0x50(%rsp)
   5bdf5:      	movq	$0x6, 0x20(%rsp)
   5bdfe:      	movl	$0x18, %edi
   5be03:      	callq	0x28860 <native_alloc>
   5be08:      	testq	%rax, %rax
   5be0b:      	je	0x5bf34 <f.14+0x294>
   5be11:      	movq	%rax, %r13
   5be14:      	movq	$0x46, (%rax)
   5be1b:      	movq	%r15, 0x8(%rax)
   5be1f:      	movq	%rbp, 0x10(%rax)
   5be23:      	movq	%rax, 0x38(%rsp)
   5be28:      	movq	0x30(%rsp), %r15
   5be2d:      	testq	%r15, %r15
   5be30:      	je	0x5bf34 <f.14+0x294>
   5be36:      	movq	0x8(%r15), %rax
   5be3a:      	testq	%rax, %rax
   5be3d:      	je	0x5bf34 <f.14+0x294>
   5be43:      	movq	0x10(%rax), %rax
   5be47:      	testq	%rax, %rax
   5be4a:      	je	0x5bf34 <f.14+0x294>
   5be50:      	movq	0x8(%rax), %rax
   5be54:      	movq	%rax, 0x40(%rsp)
   5be59:      	testq	%r12, %r12
   5be5c:      	jle	0x5beca <f.14+0x22a>
   5be5e:      	testq	%rax, %rax
   5be61:      	je	0x5bf34 <f.14+0x294>
   5be67:      	movq	0x8(%rax), %r15
   5be6b:      	movq	%r13, 0x48(%rsp)
   5be70:      	movq	%r15, 0x50(%rsp)
   5be75:      	movq	$0x6, 0x20(%rsp)
   5be7e:      	movl	$0x18, %edi
   5be83:      	callq	0x28860 <native_alloc>
   5be88:      	testq	%rax, %rax
   5be8b:      	je	0x5bf34 <f.14+0x294>
   5be91:      	movq	$0x32, (%rax)
   5be98:      	movq	%r15, 0x8(%rax)
   5be9c:      	movq	%r13, 0x10(%rax)
   5bea0:      	decq	%r12
   5bea3:      	movq	%rax, 0x48(%rsp)
   5bea8:      	movq	$0x5, 0x20(%rsp)
   5beb1:      	movq	%rax, %rdi
   5beb4:      	movq	%r12, %rsi
   5beb7:      	callq	0x5c450 <f.17>
   5bebc:      	subq	$0x8, %rsp
   5bec0:      	movq	0x30(%rsp), %r15
   5bec5:      	testq	%r15, %r15
   5bec8:      	je	0x5bf34 <f.14+0x294>
   5beca:      	movq	0x20(%r15), %rax
   5bece:      	testq	%rax, %rax
   5bed1:      	je	0x5bf34 <f.14+0x294>
   5bed3:      	cmpl	$0x0, 0x8(%rax)
   5bed7:      	je	0x5bf34 <f.14+0x294>
   5bed9:      	cmpq	$0x0, 0x10(%rax)
   5bede:      	je	0x5bf34 <f.14+0x294>
   5bee0:      	leaq	0x10(%rsp), %r12
   5bee5:      	movq	%r12, %rdi
   5bee8:      	callq	0x2ac80 <native_roots_leave>
   5beed:      	movl	$0x6, %esi
   5bef2:      	movq	%r12, %rdi
   5bef5:      	callq	0x2ac30 <native_roots_enter>
   5befa:      	movq	%r15, 0x28(%rsp)
   5beff:      	leaq	0x30(%rsp), %rax
   5bf04:      	movq	$0x0, 0x10(%rax)
   5bf0c:      	movq	$0x0, 0x8(%rax)
   5bf14:      	movq	$0x0, (%rax)
   5bf1b:      	movl	$0x1a, %esi
   5bf20:      	movq	%r15, %rdi
   5bf23:      	xorl	%edx, %edx
   5bf25:      	xorl	%ecx, %ecx
   5bf27:      	callq	0x2ab40 <native_ref_test>
   5bf2c:      	testl	%eax, %eax
   5bf2e:      	jne	0x5bd10 <f.14+0x70>
   5bf34:      	callq	0x268c0 <native_trap>
   5bf39:      	leaq	0x10(%rsp), %rdi
   5bf3e:      	callq	0x2ac80 <native_roots_leave>
   5bf43:      	xorl	%eax, %eax
   5bf45:      	addq	$0x58, %rsp
   5bf49:      	popq	%rbx
   5bf4a:      	popq	%r12
   5bf4c:      	popq	%r13
   5bf4e:      	popq	%r14
   5bf50:      	popq	%r15
   5bf52:      	popq	%rbp
   5bf53:      	retq	$0x8
   5bf56:      	int3
   5bf57:      	int3
   5bf58:      	int3
   5bf59:      	int3
   5bf5a:      	int3
   5bf5b:      	int3
   5bf5c:      	int3
   5bf5d:      	int3
   5bf5e:      	int3
   5bf5f:      	int3

000000000005bf60 <f.15>:
   5bf60:      	pushq	%r15
   5bf62:      	pushq	%r14
   5bf64:      	pushq	%r13
   5bf66:      	pushq	%r12
   5bf68:      	pushq	%rbx
   5bf69:      	subq	$0x50, %rsp
   5bf6d:      	movq	%rsi, %rbx
   5bf70:      	movq	%rdi, %r14
   5bf73:      	leaq	0x8(%rsp), %rdi
   5bf78:      	movl	$0x6, %esi
   5bf7d:      	callq	0x2ac30 <native_roots_enter>
   5bf82:      	movq	%r14, 0x20(%rsp)
   5bf87:      	testq	%r14, %r14
   5bf8a:      	movq	$0x0, 0x28(%rsp)
   5bf93:      	movq	$0x0, 0x30(%rsp)
   5bf9c:      	je	0x5c25b <f.15+0x2fb>
   5bfa2:      	cmpb	$0x0, 0x621f(%rip)      # 0x621c8 <g.15>
   5bfa9:      	je	0x5c25b <f.15+0x2fb>
   5bfaf:      	cmpq	$0x0, 0x6209(%rip)      # 0x621c0 <g.14>
   5bfb7:      	je	0x5c25b <f.15+0x2fb>
   5bfbd:      	movq	0x8(%r14), %r14
   5bfc1:      	movq	$0x3, 0x18(%rsp)
   5bfca:      	movl	$0x18, %edi
   5bfcf:      	callq	0x28860 <native_alloc>
   5bfd4:      	testq	%rax, %rax
   5bfd7:      	je	0x5c25b <f.15+0x2fb>
   5bfdd:      	movq	%rax, %r15
   5bfe0:      	movq	$0x7a, (%rax)
   5bfe7:      	movl	$0x0, 0x8(%rax)
   5bfee:      	movq	$0x0, 0x10(%rax)
   5bff6:      	movq	%rax, 0x28(%rsp)
   5bffb:      	movq	%rax, 0x38(%rsp)
   5c000:      	leaq	0x3ed1(%rip), %r13      # 0x5fed8 <ref.19>
   5c007:      	movq	%r13, 0x40(%rsp)
   5c00c:      	movq	%rax, 0x48(%rsp)
   5c011:      	movq	$0x6, 0x18(%rsp)
   5c01a:      	movl	$0x10, %edi
   5c01f:      	callq	0x28860 <native_alloc>
   5c024:      	testq	%rax, %rax
   5c027:      	je	0x5c25b <f.15+0x2fb>
   5c02d:      	movq	%rax, %r12
   5c030:      	movq	$0x72, (%rax)
   5c037:      	movq	%r15, 0x8(%rax)
   5c03b:      	movq	%rax, 0x38(%rsp)
   5c040:      	movq	%r13, 0x40(%rsp)
   5c045:      	movq	%r15, 0x48(%rsp)
   5c04a:      	movq	$0x6, 0x18(%rsp)
   5c053:      	movl	$0x18, %edi
   5c058:      	callq	0x28860 <native_alloc>
   5c05d:      	testq	%rax, %rax
   5c060:      	je	0x5c25b <f.15+0x2fb>
   5c066:      	movq	$0x92, (%rax)
   5c06d:      	movq	%r13, 0x8(%rax)
   5c071:      	movq	%r12, 0x10(%rax)
   5c075:      	movq	%rax, 0x10(%r15)
   5c079:      	movq	0x28(%rsp), %rax
   5c07e:      	testq	%rax, %rax
   5c081:      	je	0x5c25b <f.15+0x2fb>
   5c087:      	movl	$0x1, 0x8(%rax)
   5c08e:      	movq	0x28(%rsp), %rax
   5c093:      	testq	%rax, %rax
   5c096:      	je	0x5c25b <f.15+0x2fb>
   5c09c:      	cmpl	$0x0, 0x8(%rax)
   5c0a0:      	je	0x5c25b <f.15+0x2fb>
   5c0a6:      	movq	0x10(%rax), %rax
   5c0aa:      	testq	%rax, %rax
   5c0ad:      	je	0x5c25b <f.15+0x2fb>
   5c0b3:      	movq	%rax, 0x30(%rsp)
   5c0b8:      	movq	0x8(%rax), %rcx
   5c0bc:      	testq	%rcx, %rcx
   5c0bf:      	je	0x5c25b <f.15+0x2fb>
   5c0c5:      	incq	%r14
   5c0c8:      	movq	0x10(%rax), %rdi
   5c0cc:      	movq	0x8(%rcx), %rax
   5c0d0:      	movq	%rdi, 0x38(%rsp)
   5c0d5:      	movq	$0x4, 0x18(%rsp)
   5c0de:      	movl	$0x1, %edx
   5c0e3:      	movq	%r14, %rsi
   5c0e6:      	callq	*%rax
   5c0e8:      	subq	$0x8, %rsp
   5c0ec:      	cmpq	$0x0, 0x20(%rsp)
   5c0f2:      	je	0x5c25b <f.15+0x2fb>
   5c0f8:      	cmpb	$0x0, 0x60c9(%rip)      # 0x621c8 <g.15>
   5c0ff:      	je	0x5c25b <f.15+0x2fb>
   5c105:      	cmpq	$0x0, 0x60b3(%rip)      # 0x621c0 <g.14>
   5c10d:      	je	0x5c25b <f.15+0x2fb>
   5c113:      	movq	%rax, %r14
   5c116:      	movq	$0x3, 0x18(%rsp)
   5c11f:      	movl	$0x18, %edi
   5c124:      	callq	0x28860 <native_alloc>
   5c129:      	testq	%rax, %rax
   5c12c:      	je	0x5c25b <f.15+0x2fb>
   5c132:      	movq	%rax, %r15
   5c135:      	movq	$0x7a, (%rax)
   5c13c:      	movl	$0x0, 0x8(%rax)
   5c143:      	movq	$0x0, 0x10(%rax)
   5c14b:      	movq	%rax, 0x28(%rsp)
   5c150:      	movq	%rax, 0x38(%rsp)
   5c155:      	movq	%r13, 0x40(%rsp)
   5c15a:      	movq	%rax, 0x48(%rsp)
   5c15f:      	movq	$0x6, 0x18(%rsp)
   5c168:      	movl	$0x10, %edi
   5c16d:      	callq	0x28860 <native_alloc>
   5c172:      	testq	%rax, %rax
   5c175:      	je	0x5c25b <f.15+0x2fb>
   5c17b:      	movq	%rax, %r12
   5c17e:      	movq	$0x72, (%rax)
   5c185:      	movq	%r15, 0x8(%rax)
   5c189:      	movq	%rax, 0x38(%rsp)
   5c18e:      	movq	%r13, 0x40(%rsp)
   5c193:      	movq	%r15, 0x48(%rsp)
   5c198:      	movq	$0x6, 0x18(%rsp)
   5c1a1:      	movl	$0x18, %edi
   5c1a6:      	callq	0x28860 <native_alloc>
   5c1ab:      	testq	%rax, %rax
   5c1ae:      	je	0x5c25b <f.15+0x2fb>
   5c1b4:      	movq	$0x92, (%rax)
   5c1bb:      	movq	%r13, 0x8(%rax)
   5c1bf:      	movq	%r12, 0x10(%rax)
   5c1c3:      	movq	%rax, 0x10(%r15)
   5c1c7:      	movq	0x28(%rsp), %rax
   5c1cc:      	testq	%rax, %rax
   5c1cf:      	je	0x5c25b <f.15+0x2fb>
   5c1d5:      	movl	$0x1, 0x8(%rax)
   5c1dc:      	movq	0x28(%rsp), %rax
   5c1e1:      	testq	%rax, %rax
   5c1e4:      	je	0x5c25b <f.15+0x2fb>
   5c1e6:      	cmpl	$0x0, 0x8(%rax)
   5c1ea:      	je	0x5c25b <f.15+0x2fb>
   5c1ec:      	movq	0x10(%rax), %rax
   5c1f0:      	testq	%rax, %rax
   5c1f3:      	je	0x5c25b <f.15+0x2fb>
   5c1f5:      	movq	%rax, 0x30(%rsp)
   5c1fa:      	movq	0x8(%rax), %rcx
   5c1fe:      	testq	%rcx, %rcx
   5c201:      	je	0x5c25b <f.15+0x2fb>
   5c203:      	movq	0x10(%rax), %rdi
   5c207:      	incq	%rbx
   5c20a:      	leaq	-0x2(%r14,%r14), %r14
   5c20f:      	movq	0x8(%rcx), %rax
   5c213:      	movq	%rdi, 0x38(%rsp)
   5c218:      	movq	$0x4, 0x18(%rsp)
   5c221:      	movl	$0x1, %edx
   5c226:      	movq	%rbx, %rsi
   5c229:      	callq	*%rax
   5c22b:      	subq	$0x8, %rsp
   5c22f:      	leaq	-0x1(%rax), %rsi
   5c233:      	movq	%r14, %rdi
   5c236:      	callq	0x2ab00 <native_i64_div_s>
   5c23b:      	movq	%rax, %rbx
   5c23e:      	leaq	0x8(%rsp), %rdi
   5c243:      	callq	0x2ac80 <native_roots_leave>
   5c248:      	movq	%rbx, %rax
   5c24b:      	addq	$0x50, %rsp
   5c24f:      	popq	%rbx
   5c250:      	popq	%r12
   5c252:      	popq	%r13
   5c254:      	popq	%r14
   5c256:      	popq	%r15
   5c258:      	retq	$0x8
   5c25b:      	callq	0x268c0 <native_trap>

000000000005c260 <f.16>:
   5c260:      	pushq	%r15
   5c262:      	pushq	%r14
   5c264:      	pushq	%r13
   5c266:      	pushq	%r12
   5c268:      	pushq	%rbx
   5c269:      	subq	$0x30, %rsp
   5c26d:      	movq	%rsi, %r14
   5c270:      	movq	%rdi, %r15
   5c273:      	movq	%rsp, %rdi
   5c276:      	xorl	%esi, %esi
   5c278:      	callq	0x2ac30 <native_roots_enter>
   5c27d:      	movq	%r15, 0x18(%rsp)
   5c282:      	movq	$0x0, 0x20(%rsp)
   5c28b:      	movq	$0x0, 0x28(%rsp)
   5c294:      	movl	$0x2e, %esi
   5c299:      	movq	%r15, %rdi
   5c29c:      	xorl	%edx, %edx
   5c29e:      	xorl	%ecx, %ecx
   5c2a0:      	callq	0x2ab40 <native_ref_test>
   5c2a5:      	testl	%eax, %eax
   5c2a7:      	je	0x5c423 <f.16+0x1c3>
   5c2ad:      	leaq	0x20(%rsp), %r12
   5c2b2:      	movq	%rsp, %rbx
   5c2b5:      	nopw	%cs:(%rax,%rax)
   5c2bf:      	nop
   5c2c0:      	testq	%r15, %r15
   5c2c3:      	je	0x5c423 <f.16+0x1c3>
   5c2c9:      	movq	0x8(%r15), %rdi
   5c2cd:      	movl	$0x2, %esi
   5c2d2:      	callq	0x2ab00 <native_i64_div_s>
   5c2d7:      	cmpq	%r14, %rax
   5c2da:      	jle	0x5c428 <f.16+0x1c8>
   5c2e0:      	movq	0x18(%rsp), %r15
   5c2e5:      	movl	$0x2e, %esi
   5c2ea:      	movq	%r15, %rdi
   5c2ed:      	xorl	%edx, %edx
   5c2ef:      	xorl	%ecx, %ecx
   5c2f1:      	callq	0x2ab40 <native_ref_test>
   5c2f6:      	testl	%eax, %eax
   5c2f8:      	je	0x5c423 <f.16+0x1c3>
   5c2fe:      	testq	%r15, %r15
   5c301:      	je	0x5c423 <f.16+0x1c3>
   5c307:      	cmpb	$0x0, 0x5eda(%rip)      # 0x621e8 <g.19>
   5c30e:      	je	0x5c423 <f.16+0x1c3>
   5c314:      	cmpq	$0x0, 0x5ec4(%rip)      # 0x621e0 <g.18>
   5c31c:      	je	0x5c423 <f.16+0x1c3>
   5c322:      	movq	%r14, %rax
   5c325:      	shrq	$0x20, %rax
   5c329:      	jne	0x5c423 <f.16+0x1c3>
   5c32f:      	movq	0x10(%r15), %rax
   5c333:      	testq	%rax, %rax
   5c336:      	je	0x5c423 <f.16+0x1c3>
   5c33c:      	testb	$0x1, %al
   5c33e:      	jne	0x5c423 <f.16+0x1c3>
   5c344:      	leaq	0x1(%r14), %rcx
   5c348:      	leaq	-0x1(%rcx), %r13
   5c34c:      	cmpq	0x8(%rax), %r13
   5c350:      	jae	0x5c423 <f.16+0x1c3>
   5c356:      	cvtsi2sd	%rcx, %xmm0
   5c35b:      	movsd	-0x57b53(%rip), %xmm1   # 0x4810 <writev+0x4810>
   5c363:      	divsd	%xmm0, %xmm1
   5c367:      	movsd	%xmm1, 0x10(%rax,%r14,8)
   5c36e:      	movq	0x18(%rsp), %r14
   5c373:      	movl	$0x2e, %esi
   5c378:      	movq	%r14, %rdi
   5c37b:      	xorl	%edx, %edx
   5c37d:      	xorl	%ecx, %ecx
   5c37f:      	callq	0x2ab40 <native_ref_test>
   5c384:      	testl	%eax, %eax
   5c386:      	je	0x5c423 <f.16+0x1c3>
   5c38c:      	testq	%r14, %r14
   5c38f:      	je	0x5c423 <f.16+0x1c3>
   5c395:      	movq	0x18(%r14), %rax
   5c399:      	testq	%rax, %rax
   5c39c:      	je	0x5c423 <f.16+0x1c3>
   5c3a2:      	cmpl	$0x0, 0x8(%rax)
   5c3a6:      	je	0x5c423 <f.16+0x1c3>
   5c3a8:      	movq	0x18(%rsp), %r15
   5c3ad:      	movl	$0x2e, %esi
   5c3b2:      	movq	%r15, %rdi
   5c3b5:      	xorl	%edx, %edx
   5c3b7:      	xorl	%ecx, %ecx
   5c3b9:      	callq	0x2ab40 <native_ref_test>
   5c3be:      	testl	%eax, %eax
   5c3c0:      	je	0x5c423 <f.16+0x1c3>
   5c3c2:      	movq	%r15, 0x28(%rsp)
   5c3c7:      	testq	%r15, %r15
   5c3ca:      	je	0x5c423 <f.16+0x1c3>
   5c3cc:      	movq	0x18(%r15), %rax
   5c3d0:      	testq	%rax, %rax
   5c3d3:      	je	0x5c423 <f.16+0x1c3>
   5c3d5:      	cmpq	$0x0, 0x10(%rax)
   5c3da:      	je	0x5c423 <f.16+0x1c3>
   5c3dc:      	movq	%rbx, %rdi
   5c3df:      	callq	0x2ac80 <native_roots_leave>
   5c3e4:      	movq	%rbx, %rdi
   5c3e7:      	xorl	%esi, %esi
   5c3e9:      	callq	0x2ac30 <native_roots_enter>
   5c3ee:      	movq	%r15, 0x18(%rsp)
   5c3f3:      	movq	$0x0, 0x8(%r12)
   5c3fc:      	movq	$0x0, (%r12)
   5c404:      	movl	$0x2e, %esi
   5c409:      	movq	%r15, %rdi
   5c40c:      	xorl	%edx, %edx
   5c40e:      	xorl	%ecx, %ecx
   5c410:      	callq	0x2ab40 <native_ref_test>
   5c415:      	incq	%r13
   5c418:      	testl	%eax, %eax
   5c41a:      	movq	%r13, %r14
   5c41d:      	jne	0x5c2c0 <f.16+0x60>
   5c423:      	callq	0x268c0 <native_trap>
   5c428:      	movq	%rsp, %rdi
   5c42b:      	callq	0x2ac80 <native_roots_leave>
   5c430:      	xorl	%eax, %eax
   5c432:      	addq	$0x30, %rsp
   5c436:      	popq	%rbx
   5c437:      	popq	%r12
   5c439:      	popq	%r13
   5c43b:      	popq	%r14
   5c43d:      	popq	%r15
   5c43f:      	retq	$0x8
   5c442:      	int3
   5c443:      	int3
   5c444:      	int3
   5c445:      	int3
   5c446:      	int3
   5c447:      	int3
   5c448:      	int3
   5c449:      	int3
   5c44a:      	int3
   5c44b:      	int3
   5c44c:      	int3
   5c44d:      	int3
   5c44e:      	int3
   5c44f:      	int3

000000000005c450 <f.17>:
   5c450:      	pushq	%rbp
   5c451:      	pushq	%r15
   5c453:      	pushq	%r14
   5c455:      	pushq	%r13
   5c457:      	pushq	%r12
   5c459:      	pushq	%rbx
   5c45a:      	subq	$0x58, %rsp
   5c45e:      	movq	%rsi, %rbx
   5c461:      	movq	%rdi, %r15
   5c464:      	leaq	0x10(%rsp), %rdi
   5c469:      	movl	$0x6, %esi
   5c46e:      	callq	0x2ac30 <native_roots_enter>
   5c473:      	movq	%r15, 0x28(%rsp)
   5c478:      	movq	$0x0, 0x30(%rsp)
   5c481:      	movq	$0x0, 0x38(%rsp)
   5c48a:      	cmpb	$0x1, 0x5ce7(%rip)      # 0x62178 <g.5>
   5c491:      	jne	0x5c98b <f.17+0x53b>
   5c497:      	leaq	-0x50e2e(%rip), %rbp    # 0xb670 <object.1.0>
   5c49e:      	leaq	0x10(%rsp), %r14
   5c4a3:      	nopw	%cs:(%rax,%rax)
   5c4ad:      	nopl	(%rax)
   5c4b0:      	cmpq	$0x0, 0x5cb8(%rip)      # 0x62170 <g.4>
   5c4b8:      	je	0x5c98b <f.17+0x53b>
   5c4be:      	cmpb	$0x0, 0x5ce3(%rip)      # 0x621a8 <g.11>
   5c4c5:      	je	0x5c98b <f.17+0x53b>
   5c4cb:      	cmpq	$0x0, 0x5ccd(%rip)      # 0x621a0 <g.10>
   5c4d3:      	je	0x5c98b <f.17+0x53b>
   5c4d9:      	testq	%r15, %r15
   5c4dc:      	je	0x5c98b <f.17+0x53b>
   5c4e2:      	movq	0x10(%r15), %rdi
   5c4e6:      	movq	%rdi, 0x30(%rsp)
   5c4eb:      	movl	$0xaa, %esi
   5c4f0:      	xorl	%edx, %edx
   5c4f2:      	xorl	%ecx, %ecx
   5c4f4:      	callq	0x2ab40 <native_ref_test>
   5c4f9:      	testl	%eax, %eax
   5c4fb:      	jne	0x5c98b <f.17+0x53b>
   5c501:      	movq	0x30(%rsp), %r15
   5c506:      	movl	$0x46, %esi
   5c50b:      	movq	%r15, %rdi
   5c50e:      	xorl	%edx, %edx
   5c510:      	xorl	%ecx, %ecx
   5c512:      	callq	0x2ab40 <native_ref_test>
   5c517:      	testl	%eax, %eax
   5c519:      	je	0x5c98b <f.17+0x53b>
   5c51f:      	testq	%r15, %r15
   5c522:      	je	0x5c98b <f.17+0x53b>
   5c528:      	movq	0x8(%r15), %r13
   5c52c:      	movq	%rbp, 0x40(%rsp)
   5c531:      	movq	%r13, 0x48(%rsp)
   5c536:      	movq	$0x5, 0x20(%rsp)
   5c53f:      	movl	$0x10, %edi
   5c544:      	callq	0x28860 <native_alloc>
   5c549:      	testq	%rax, %rax
   5c54c:      	je	0x5c98b <f.17+0x53b>
   5c552:      	movq	%rax, %r15
   5c555:      	movq	$0x36, (%rax)
   5c55c:      	movq	%rbp, 0x8(%rax)
   5c560:      	movq	%rbp, 0x40(%rsp)
   5c565:      	movq	%rax, 0x48(%rsp)
   5c56a:      	movq	%r13, 0x50(%rsp)
   5c56f:      	movq	$0x6, 0x20(%rsp)
   5c578:      	movl	$0x10, %edi
   5c57d:      	callq	0x28860 <native_alloc>
   5c582:      	testq	%rax, %rax
   5c585:      	je	0x5c98b <f.17+0x53b>
   5c58b:      	movq	%rax, %r12
   5c58e:      	movq	$0x36, (%rax)
   5c595:      	movq	%rbp, 0x8(%rax)
   5c599:      	movq	%rax, 0x40(%rsp)
   5c59e:      	movq	%r15, 0x48(%rsp)
   5c5a3:      	movq	%r13, 0x50(%rsp)
   5c5a8:      	movq	$0x6, 0x20(%rsp)
   5c5b1:      	movl	$0x18, %edi
   5c5b6:      	callq	0x28860 <native_alloc>
   5c5bb:      	testq	%rax, %rax
   5c5be:      	je	0x5c98b <f.17+0x53b>
   5c5c4:      	movq	$0x46, (%rax)
   5c5cb:      	movq	%r15, 0x8(%rax)
   5c5cf:      	movq	%r12, 0x10(%rax)
   5c5d3:      	testq	%r13, %r13
   5c5d6:      	je	0x5c98b <f.17+0x53b>
   5c5dc:      	movq	%rax, 0x8(%r13)
   5c5e0:      	cmpb	$0x0, 0x5b91(%rip)      # 0x62178 <g.5>
   5c5e7:      	je	0x5c98b <f.17+0x53b>
   5c5ed:      	cmpq	$0x0, 0x5b7b(%rip)      # 0x62170 <g.4>
   5c5f5:      	je	0x5c98b <f.17+0x53b>
   5c5fb:      	cmpb	$0x0, 0x5bb6(%rip)      # 0x621b8 <g.13>
   5c602:      	je	0x5c98b <f.17+0x53b>
   5c608:      	cmpq	$0x0, 0x5ba0(%rip)      # 0x621b0 <g.12>
   5c610:      	je	0x5c98b <f.17+0x53b>
   5c616:      	movq	0x28(%rsp), %rax
   5c61b:      	testq	%rax, %rax
   5c61e:      	je	0x5c98b <f.17+0x53b>
   5c624:      	movq	0x10(%rax), %rdi
   5c628:      	movq	%rdi, 0x30(%rsp)
   5c62d:      	movl	$0xaa, %esi
   5c632:      	xorl	%edx, %edx
   5c634:      	xorl	%ecx, %ecx
   5c636:      	callq	0x2ab40 <native_ref_test>
   5c63b:      	testl	%eax, %eax
   5c63d:      	jne	0x5c98b <f.17+0x53b>
   5c643:      	movq	0x30(%rsp), %r15
   5c648:      	movl	$0x46, %esi
   5c64d:      	movq	%r15, %rdi
   5c650:      	xorl	%edx, %edx
   5c652:      	xorl	%ecx, %ecx
   5c654:      	callq	0x2ab40 <native_ref_test>
   5c659:      	testl	%eax, %eax
   5c65b:      	je	0x5c98b <f.17+0x53b>
   5c661:      	testq	%r15, %r15
   5c664:      	je	0x5c98b <f.17+0x53b>
   5c66a:      	movq	0x10(%r15), %r13
   5c66e:      	movq	%rbp, 0x40(%rsp)
   5c673:      	movq	%r13, 0x48(%rsp)
   5c678:      	movq	$0x5, 0x20(%rsp)
   5c681:      	movl	$0x10, %edi
   5c686:      	callq	0x28860 <native_alloc>
   5c68b:      	testq	%rax, %rax
   5c68e:      	je	0x5c98b <f.17+0x53b>
   5c694:      	movq	%rax, %r15
   5c697:      	movq	$0x36, (%rax)
   5c69e:      	movq	%rbp, 0x8(%rax)
   5c6a2:      	movq	%rbp, 0x40(%rsp)
   5c6a7:      	movq	%rax, 0x48(%rsp)
   5c6ac:      	movq	%r13, 0x50(%rsp)
   5c6b1:      	movq	$0x6, 0x20(%rsp)
   5c6ba:      	movl	$0x10, %edi
   5c6bf:      	callq	0x28860 <native_alloc>
   5c6c4:      	testq	%rax, %rax
   5c6c7:      	je	0x5c98b <f.17+0x53b>
   5c6cd:      	movq	%rax, %r12
   5c6d0:      	movq	$0x36, (%rax)
   5c6d7:      	movq	%rbp, 0x8(%rax)
   5c6db:      	movq	%rax, 0x40(%rsp)
   5c6e0:      	movq	%r15, 0x48(%rsp)
   5c6e5:      	movq	%r13, 0x50(%rsp)
   5c6ea:      	movq	$0x6, 0x20(%rsp)
   5c6f3:      	movl	$0x18, %edi
   5c6f8:      	callq	0x28860 <native_alloc>
   5c6fd:      	testq	%rax, %rax
   5c700:      	je	0x5c98b <f.17+0x53b>
   5c706:      	movq	$0x46, (%rax)
   5c70d:      	movq	%r15, 0x8(%rax)
   5c711:      	movq	%r12, 0x10(%rax)
   5c715:      	testq	%r13, %r13
   5c718:      	je	0x5c98b <f.17+0x53b>
   5c71e:      	movq	%rax, 0x8(%r13)
   5c722:      	cmpb	$0x0, 0x5a5f(%rip)      # 0x62188 <g.7>
   5c729:      	je	0x5c98b <f.17+0x53b>
   5c72f:      	cmpq	$0x0, 0x5a49(%rip)      # 0x62180 <g.6>
   5c737:      	je	0x5c98b <f.17+0x53b>
   5c73d:      	movq	0x28(%rsp), %rax
   5c742:      	testq	%rax, %rax
   5c745:      	je	0x5c98b <f.17+0x53b>
   5c74b:      	movq	0x10(%rax), %rdi
   5c74f:      	movq	%rdi, 0x30(%rsp)
   5c754:      	movl	$0xaa, %esi
   5c759:      	xorl	%edx, %edx
   5c75b:      	xorl	%ecx, %ecx
   5c75d:      	callq	0x2ab40 <native_ref_test>
   5c762:      	testl	%eax, %eax
   5c764:      	jne	0x5c98b <f.17+0x53b>
   5c76a:      	movq	0x30(%rsp), %r15
   5c76f:      	movl	$0x46, %esi
   5c774:      	movq	%r15, %rdi
   5c777:      	xorl	%edx, %edx
   5c779:      	xorl	%ecx, %ecx
   5c77b:      	callq	0x2ab40 <native_ref_test>
   5c780:      	testl	%eax, %eax
   5c782:      	je	0x5c98b <f.17+0x53b>
   5c788:      	testq	%r15, %r15
   5c78b:      	je	0x5c98b <f.17+0x53b>
   5c791:      	movq	0x8(%r15), %rax
   5c795:      	testq	%rax, %rax
   5c798:      	je	0x5c98b <f.17+0x53b>
   5c79e:      	movq	0x8(%rax), %r15
   5c7a2:      	movq	%r15, 0x30(%rsp)
   5c7a7:      	movq	0x28(%rsp), %rax
   5c7ac:      	testq	%rax, %rax
   5c7af:      	je	0x5c98b <f.17+0x53b>
   5c7b5:      	movq	0x8(%rax), %rax
   5c7b9:      	testq	%rax, %rax
   5c7bc:      	je	0x5c98b <f.17+0x53b>
   5c7c2:      	cmpl	$0x0, 0x8(%rax)
   5c7c6:      	je	0x5c98b <f.17+0x53b>
   5c7cc:      	movq	0x10(%rax), %rax
   5c7d0:      	testq	%rax, %rax
   5c7d3:      	je	0x5c98b <f.17+0x53b>
   5c7d9:      	movq	0x8(%rax), %rax
   5c7dd:      	movq	%rax, 0x38(%rsp)
   5c7e2:      	testq	%rbx, %rbx
   5c7e5:      	jle	0x5c847 <f.17+0x3f7>
   5c7e7:      	testq	%rax, %rax
   5c7ea:      	je	0x5c98b <f.17+0x53b>
   5c7f0:      	movq	0x8(%rax), %r12
   5c7f4:      	movq	%r15, 0x40(%rsp)
   5c7f9:      	movq	%r12, 0x48(%rsp)
   5c7fe:      	movq	$0x5, 0x20(%rsp)
   5c807:      	movl	$0x18, %edi
   5c80c:      	callq	0x28860 <native_alloc>
   5c811:      	testq	%rax, %rax
   5c814:      	je	0x5c98b <f.17+0x53b>
   5c81a:      	movq	$0x32, (%rax)
   5c821:      	movq	%r12, 0x8(%rax)
   5c825:      	movq	%r15, 0x10(%rax)
   5c829:      	leaq	-0x1(%rbx), %rsi
   5c82d:      	movq	%rax, 0x40(%rsp)
   5c832:      	movq	$0x4, 0x20(%rsp)
   5c83b:      	movq	%rax, %rdi
   5c83e:      	callq	0x5c450 <f.17>
   5c843:      	subq	$0x8, %rsp
   5c847:      	cmpb	$0x0, 0x594a(%rip)      # 0x62198 <g.9>
   5c84e:      	je	0x5c98b <f.17+0x53b>
   5c854:      	cmpq	$0x0, 0x5934(%rip)      # 0x62190 <g.8>
   5c85c:      	je	0x5c98b <f.17+0x53b>
   5c862:      	movq	0x28(%rsp), %rax
   5c867:      	testq	%rax, %rax
   5c86a:      	je	0x5c98b <f.17+0x53b>
   5c870:      	movq	0x10(%rax), %rdi
   5c874:      	movq	%rdi, 0x30(%rsp)
   5c879:      	movl	$0xaa, %esi
   5c87e:      	xorl	%edx, %edx
   5c880:      	xorl	%ecx, %ecx
   5c882:      	callq	0x2ab40 <native_ref_test>
   5c887:      	testl	%eax, %eax
   5c889:      	jne	0x5c98b <f.17+0x53b>
   5c88f:      	movq	0x30(%rsp), %r15
   5c894:      	movl	$0x46, %esi
   5c899:      	movq	%r15, %rdi
   5c89c:      	xorl	%edx, %edx
   5c89e:      	xorl	%ecx, %ecx
   5c8a0:      	callq	0x2ab40 <native_ref_test>
   5c8a5:      	testl	%eax, %eax
   5c8a7:      	je	0x5c98b <f.17+0x53b>
   5c8ad:      	testq	%r15, %r15
   5c8b0:      	je	0x5c98b <f.17+0x53b>
   5c8b6:      	movq	0x10(%r15), %rax
   5c8ba:      	testq	%rax, %rax
   5c8bd:      	je	0x5c98b <f.17+0x53b>
   5c8c3:      	movq	0x8(%rax), %r12
   5c8c7:      	movq	%r12, 0x30(%rsp)
   5c8cc:      	movq	0x28(%rsp), %rax
   5c8d1:      	testq	%rax, %rax
   5c8d4:      	je	0x5c98b <f.17+0x53b>
   5c8da:      	movq	0x8(%rax), %rax
   5c8de:      	testq	%rax, %rax
   5c8e1:      	je	0x5c98b <f.17+0x53b>
   5c8e7:      	cmpl	$0x0, 0x8(%rax)
   5c8eb:      	je	0x5c98b <f.17+0x53b>
   5c8f1:      	movq	0x10(%rax), %rax
   5c8f5:      	testq	%rax, %rax
   5c8f8:      	je	0x5c98b <f.17+0x53b>
   5c8fe:      	testq	%rbx, %rbx
   5c901:      	movq	0x8(%rax), %rax
   5c905:      	movq	%rax, 0x38(%rsp)
   5c90a:      	jle	0x5c990 <f.17+0x540>
   5c910:      	testq	%rax, %rax
   5c913:      	je	0x5c98b <f.17+0x53b>
   5c915:      	movq	0x8(%rax), %r13
   5c919:      	movq	%r12, 0x40(%rsp)
   5c91e:      	movq	%r13, 0x48(%rsp)
   5c923:      	movq	$0x5, 0x20(%rsp)
   5c92c:      	movl	$0x18, %edi
   5c931:      	callq	0x28860 <native_alloc>
   5c936:      	testq	%rax, %rax
   5c939:      	je	0x5c98b <f.17+0x53b>
   5c93b:      	movq	%rax, %r15
   5c93e:      	movq	$0x32, (%rax)
   5c945:      	movq	%r13, 0x8(%rax)
   5c949:      	movq	%r12, 0x10(%rax)
   5c94d:      	decq	%rbx
   5c950:      	movq	%r14, %rdi
   5c953:      	callq	0x2ac80 <native_roots_leave>
   5c958:      	movl	$0x6, %esi
   5c95d:      	movq	%r14, %rdi
   5c960:      	callq	0x2ac30 <native_roots_enter>
   5c965:      	movq	%r15, 0x28(%rsp)
   5c96a:      	leaq	0x30(%rsp), %rax
   5c96f:      	movq	$0x0, 0x8(%rax)
   5c977:      	movq	$0x0, (%rax)
   5c97e:      	cmpb	$0x0, 0x57f3(%rip)      # 0x62178 <g.5>
   5c985:      	jne	0x5c4b0 <f.17+0x60>
   5c98b:      	callq	0x268c0 <native_trap>
   5c990:      	leaq	0x10(%rsp), %rdi
   5c995:      	callq	0x2ac80 <native_roots_leave>
   5c99a:      	addq	$0x58, %rsp
   5c99e:      	popq	%rbx
   5c99f:      	popq	%r12
   5c9a1:      	popq	%r13
   5c9a3:      	popq	%r14
   5c9a5:      	popq	%r15
   5c9a7:      	popq	%rbp
   5c9a8:      	retq	$0x8
   5c9ab:      	int3
   5c9ac:      	int3
   5c9ad:      	int3
   5c9ae:      	int3
   5c9af:      	int3

000000000005c9b0 <f.18>:
   5c9b0:      	pushq	%r15
   5c9b2:      	pushq	%r14
   5c9b4:      	pushq	%rbx
   5c9b5:      	subq	$0x60, %rsp
   5c9b9:      	movq	%rsi, %rbx
   5c9bc:      	movq	%rdi, %r14
   5c9bf:      	leaq	0x10(%rsp), %rdi
   5c9c4:      	movl	$0x7, %esi
   5c9c9:      	callq	0x2ac30 <native_roots_enter>
   5c9ce:      	movq	%r14, 0x28(%rsp)
   5c9d3:      	testq	%rbx, %rbx
   5c9d6:      	movq	$0x0, 0x30(%rsp)
   5c9df:      	movq	$0x0, 0x38(%rsp)
   5c9e8:      	movq	$0x0, 0x40(%rsp)
   5c9f1:      	movq	$0x0, 0x48(%rsp)
   5c9fa:      	jle	0x5cb08 <f.18+0x158>
   5ca00:      	testq	%r14, %r14
   5ca03:      	je	0x5cbd6 <f.18+0x226>
   5ca09:      	movq	0x8(%r14), %rax
   5ca0d:      	testq	%rax, %rax
   5ca10:      	je	0x5cbd6 <f.18+0x226>
   5ca16:      	cmpl	$0x0, 0x8(%rax)
   5ca1a:      	je	0x5cbd6 <f.18+0x226>
   5ca20:      	movq	%rax, 0x30(%rsp)
   5ca25:      	cmpq	$0x0, 0x10(%rax)
   5ca2a:      	je	0x5cbd6 <f.18+0x226>
   5ca30:      	decq	%rbx
   5ca33:      	movq	%r14, 0x50(%rsp)
   5ca38:      	movq	$0x6, 0x20(%rsp)
   5ca41:      	movq	%r14, %rdi
   5ca44:      	movq	%rbx, %rsi
   5ca47:      	callq	0x5c9b0 <f.18>
   5ca4c:      	subq	$0x8, %rsp
   5ca50:      	movq	%rax, 0x48(%rsp)
   5ca55:      	movq	0x30(%rsp), %rax
   5ca5a:      	testq	%rax, %rax
   5ca5d:      	je	0x5cbd6 <f.18+0x226>
   5ca63:      	cmpl	$0x0, 0x8(%rax)
   5ca67:      	je	0x5cbd6 <f.18+0x226>
   5ca6d:      	movq	0x28(%rsp), %rdi
   5ca72:      	testq	%rdi, %rdi
   5ca75:      	je	0x5cbd6 <f.18+0x226>
   5ca7b:      	movq	0x8(%rdi), %rax
   5ca7f:      	testq	%rax, %rax
   5ca82:      	je	0x5cbd6 <f.18+0x226>
   5ca88:      	cmpq	$0x0, 0x10(%rax)
   5ca8d:      	je	0x5cbd6 <f.18+0x226>
   5ca93:      	movq	%rdi, 0x50(%rsp)
   5ca98:      	movq	$0x6, 0x20(%rsp)
   5caa1:      	movq	%rbx, %rsi
   5caa4:      	callq	0x5c9b0 <f.18>
   5caa9:      	subq	$0x8, %rsp
   5caad:      	movq	%rax, 0x40(%rsp)
   5cab2:      	cmpb	$0x0, 0x56bf(%rip)      # 0x62178 <g.5>
   5cab9:      	je	0x5cbd6 <f.18+0x226>
   5cabf:      	cmpq	$0x0, 0x56a9(%rip)      # 0x62170 <g.4>
   5cac7:      	je	0x5cbd6 <f.18+0x226>
   5cacd:      	movq	0x48(%rsp), %r14
   5cad2:      	movq	%r14, 0x50(%rsp)
   5cad7:      	movq	$0x6, 0x20(%rsp)
   5cae0:      	movl	$0x10, %edi
   5cae5:      	callq	0x28860 <native_alloc>
   5caea:      	testq	%rax, %rax
   5caed:      	je	0x5cbd6 <f.18+0x226>
   5caf3:      	movq	%rax, %rbx
   5caf6:      	movq	$0x36, (%rax)
   5cafd:      	movq	%r14, 0x8(%rax)
   5cb01:      	movq	0x40(%rsp), %r15
   5cb06:      	jmp	0x5cb59 <f.18+0x1a9>
   5cb08:      	cmpb	$0x0, 0x5669(%rip)      # 0x62178 <g.5>
   5cb0f:      	je	0x5cbd6 <f.18+0x226>
   5cb15:      	cmpq	$0x0, 0x5653(%rip)      # 0x62170 <g.4>
   5cb1d:      	je	0x5cbd6 <f.18+0x226>
   5cb23:      	leaq	-0x514ba(%rip), %r15    # 0xb670 <object.1.0>
   5cb2a:      	movq	%r15, 0x50(%rsp)
   5cb2f:      	movq	$0x6, 0x20(%rsp)
   5cb38:      	movl	$0x10, %edi
   5cb3d:      	callq	0x28860 <native_alloc>
   5cb42:      	testq	%rax, %rax
   5cb45:      	je	0x5cbd6 <f.18+0x226>
   5cb4b:      	movq	%rax, %rbx
   5cb4e:      	movq	$0x36, (%rax)
   5cb55:      	movq	%r15, 0x8(%rax)
   5cb59:      	movq	%r15, 0x50(%rsp)
   5cb5e:      	movq	%rbx, 0x58(%rsp)
   5cb63:      	movq	$0x7, 0x20(%rsp)
   5cb6c:      	movl	$0x10, %edi
   5cb71:      	callq	0x28860 <native_alloc>
   5cb76:      	testq	%rax, %rax
   5cb79:      	je	0x5cbd6 <f.18+0x226>
   5cb7b:      	movq	%rax, %r14
   5cb7e:      	movq	$0x36, (%rax)
   5cb85:      	movq	%r15, 0x8(%rax)
   5cb89:      	movq	%rax, 0x50(%rsp)
   5cb8e:      	movq	%rbx, 0x58(%rsp)
   5cb93:      	movq	$0x7, 0x20(%rsp)
   5cb9c:      	movl	$0x18, %edi
   5cba1:      	callq	0x28860 <native_alloc>
   5cba6:      	testq	%rax, %rax
   5cba9:      	je	0x5cbd6 <f.18+0x226>
   5cbab:      	movq	$0x46, (%rax)
   5cbb2:      	movq	%rbx, 0x8(%rax)
   5cbb6:      	movq	%r14, 0x10(%rax)
   5cbba:      	leaq	0x10(%rsp), %rdi
   5cbbf:      	movq	%rax, %rbx
   5cbc2:      	callq	0x2ac80 <native_roots_leave>
   5cbc7:      	movq	%rbx, %rax
   5cbca:      	addq	$0x60, %rsp
   5cbce:      	popq	%rbx
   5cbcf:      	popq	%r14
   5cbd1:      	popq	%r15
   5cbd3:      	retq	$0x8
   5cbd6:      	callq	0x268c0 <native_trap>
   5cbdb:      	int3
   5cbdc:      	int3
   5cbdd:      	int3
   5cbde:      	int3
   5cbdf:      	int3

000000000005cbe0 <f.19>:
   5cbe0:      	pushq	%r15
   5cbe2:      	pushq	%r14
   5cbe4:      	pushq	%r12
   5cbe6:      	pushq	%rbx
   5cbe7:      	subq	$0x28, %rsp
   5cbeb:      	movq	%rdx, %rbx
   5cbee:      	movq	%rsi, %r14
   5cbf1:      	movq	%rdi, %r15
   5cbf4:      	movq	%rsp, %rdi
   5cbf7:      	xorl	%esi, %esi
   5cbf9:      	callq	0x2ac30 <native_roots_enter>
   5cbfe:      	movq	%r15, 0x18(%rsp)
   5cc03:      	movq	$0x0, 0x20(%rsp)
   5cc0c:      	testq	%r14, %r14
   5cc0f:      	je	0x5cc6c <f.19+0x8c>
   5cc11:      	testq	%r15, %r15
   5cc14:      	je	0x5cc85 <f.19+0xa5>
   5cc16:      	movq	%rsp, %r12
   5cc19:      	nopl	(%rax)
   5cc20:      	movq	0x8(%r15), %rax
   5cc24:      	testq	%rax, %rax
   5cc27:      	je	0x5cc85 <f.19+0xa5>
   5cc29:      	cmpl	$0x0, 0x8(%rax)
   5cc2d:      	je	0x5cc85 <f.19+0xa5>
   5cc2f:      	movq	%r15, 0x20(%rsp)
   5cc34:      	movq	0x8(%r15), %rax
   5cc38:      	testq	%rax, %rax
   5cc3b:      	je	0x5cc85 <f.19+0xa5>
   5cc3d:      	cmpq	$0x0, 0x10(%rax)
   5cc42:      	je	0x5cc85 <f.19+0xa5>
   5cc44:      	addq	%rbx, %rbx
   5cc47:      	movq	%r12, %rdi
   5cc4a:      	callq	0x2ac80 <native_roots_leave>
   5cc4f:      	movq	%r12, %rdi
   5cc52:      	xorl	%esi, %esi
   5cc54:      	callq	0x2ac30 <native_roots_enter>
   5cc59:      	decq	%r14
   5cc5c:      	movq	%r15, 0x18(%rsp)
   5cc61:      	movq	$0x0, 0x20(%rsp)
   5cc6a:      	jne	0x5cc20 <f.19+0x40>
   5cc6c:      	movq	%rsp, %rdi
   5cc6f:      	callq	0x2ac80 <native_roots_leave>
   5cc74:      	movq	%rbx, %rax
   5cc77:      	addq	$0x28, %rsp
   5cc7b:      	popq	%rbx
   5cc7c:      	popq	%r12
   5cc7e:      	popq	%r14
   5cc80:      	popq	%r15
   5cc82:      	retq	$0x8
   5cc85:      	callq	0x268c0 <native_trap>
   5cc8a:      	int3
   5cc8b:      	int3
   5cc8c:      	int3
   5cc8d:      	int3
   5cc8e:      	int3
   5cc8f:      	int3
