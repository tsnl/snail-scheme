0000000000013360 <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8>:
   13360:      	pushq	%rbp
   13361:      	pushq	%r14
   13363:      	pushq	%rbx
   13364:      	subq	$0x50, %rsp
   13368:      	callq	*0x4a05a(%rip)          # 0x5d3c8 <writev+0x5d3c8>
   1336e:      	callq	*0x4a05c(%rip)          # 0x5d3d0 <writev+0x5d3d0>
   13374:      	callq	*0x4a05e(%rip)          # 0x5d3d8 <writev+0x5d3d8>
   1337a:      	callq	0x53220 <<std::sys::pal::unix::time::Timespec>::now>
   1337f:      	movq	%rax, %r14
   13382:      	movl	%edx, %ebp
   13384:      	movl	$0x1, %edi
   13389:      	callq	*0x4a051(%rip)          # 0x5d3e0 <writev+0x5d3e0>
   1338f:      	movq	%rax, %rbx
   13392:      	movq	%rax, 0x28(%rsp)
   13397:      	callq	0x53220 <<std::sys::pal::unix::time::Timespec>::now>
   1339c:      	movq	%rax, 0x40(%rsp)
   133a1:      	movl	%edx, 0x48(%rsp)
   133a5:      	movq	%r14, 0x30(%rsp)
   133aa:      	movl	%ebp, 0x38(%rsp)
   133ae:      	leaq	0x8(%rsp), %rdi
   133b3:      	leaq	0x40(%rsp), %rsi
   133b8:      	leaq	0x30(%rsp), %r14
   133bd:      	movq	%r14, %rdx
   133c0:      	callq	0x53150 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   133c5:      	cmpb	$0x0, 0x8(%rsp)
   133ca:      	xorpd	%xmm0, %xmm0
   133ce:      	jne	0x13406 <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8+0xa6>
   133d0:      	movsd	0x10(%rsp), %xmm1
   133d6:      	unpcklps	-0xf33d(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x40a0 <writev+0x40a0>
   133dd:      	subpd	-0xf395(%rip), %xmm1    # 0x4050 <writev+0x4050>
   133e5:      	movapd	%xmm1, %xmm2
   133e9:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   133ed:      	xorps	%xmm0, %xmm0
   133f0:      	cvtsi2sdl	0x18(%rsp), %xmm0
   133f6:      	addsd	%xmm1, %xmm2
   133fa:      	divsd	-0xf122(%rip), %xmm0    # 0x42e0 <writev+0x42e0>
   13402:      	addsd	%xmm2, %xmm0
   13406:      	movsd	%xmm0, 0x30(%rsp)
   1340c:      	cmpq	$0xf4240, %rbx          # imm = 0xF4240
   13413:      	jne	0x13476 <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8+0x116>
   13415:      	leaq	0x28(%rsp), %rax
   1341a:      	movq	%rax, 0x8(%rsp)
   1341f:      	leaq	0x6a5a(%rip), %rax      # 0x19e80 <<i64 as core::fmt::Display>::fmt>
   13426:      	movq	%rax, 0x10(%rsp)
   1342b:      	movq	%r14, 0x18(%rsp)
   13430:      	leaq	0x8929(%rip), %rax      # 0x1bd60 <<f64 as core::fmt::Display>::fmt>
   13437:      	movq	%rax, 0x20(%rsp)
   1343c:      	leaq	-0xd687(%rip), %rdi     # 0x5dbc <writev+0x5dbc>
   13443:      	leaq	0x8(%rsp), %rsi
   13448:      	callq	0x580a0 <std::io::stdio::_print>
   1344d:      	leaq	0x8(%rsp), %rdi
   13452:      	callq	0x267a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13457:      	movq	0x8(%rsp), %rbx
   1345c:      	testq	%rbx, %rbx
   1345f:      	jle	0x1346c <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8+0x10c>
   13461:      	movq	0x10(%rsp), %rdi
   13466:      	callq	*0x49f7c(%rip)          # 0x5d3e8 <writev+0x5d3e8>
   1346c:      	xorl	%eax, %eax
   1346e:      	negq	%rbx
   13471:      	setno	%al
   13474:      	jmp	0x13498 <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8+0x138>
   13476:      	leaq	0x8(%rsp), %rdi
   1347b:      	callq	0x267a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13480:      	cmpq	$0x0, 0x8(%rsp)
   13486:      	jle	0x13493 <wasm_native_046894ab588b09dfdf4e88119ed0e7903ee6d2b19fe473d7bb1cb249b21d7e1c::run::h7a5328a4525680b8+0x133>
   13488:      	movq	0x10(%rsp), %rdi
   1348d:      	callq	*0x49f55(%rip)          # 0x5d3e8 <writev+0x5d3e8>
   13493:      	movl	$0x1, %eax
   13498:      	addq	$0x50, %rsp
   1349c:      	popq	%rbx
   1349d:      	popq	%r14
   1349f:      	popq	%rbp
   134a0:      	retq
   134a1:      	int3
   134a2:      	int3
   134a3:      	int3
   134a4:      	int3
   134a5:      	int3
   134a6:      	int3
   134a7:      	int3
   134a8:      	int3
   134a9:      	int3
   134aa:      	int3
   134ab:      	int3
   134ac:      	int3
   134ad:      	int3
   134ae:      	int3
   134af:      	int3
