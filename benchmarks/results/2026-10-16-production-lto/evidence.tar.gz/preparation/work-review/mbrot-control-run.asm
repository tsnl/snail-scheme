0000000000013370 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f>:
   13370:      	pushq	%rbp
   13371:      	pushq	%r14
   13373:      	pushq	%rbx
   13374:      	subq	$0x50, %rsp
   13378:      	callq	*0x49de2(%rip)          # 0x5d160 <writev+0x5d160>
   1337e:      	callq	*0x49de4(%rip)          # 0x5d168 <writev+0x5d168>
   13384:      	callq	*0x49de6(%rip)          # 0x5d170 <writev+0x5d170>
   1338a:      	callq	0x53220 <<std::sys::pal::unix::time::Timespec>::now>
   1338f:      	movq	%rax, %r14
   13392:      	movl	%edx, %ebp
   13394:      	movl	$0x3e8, %edi            # imm = 0x3E8
   13399:      	callq	*0x49dd9(%rip)          # 0x5d178 <writev+0x5d178>
   1339f:      	movq	%rax, %rbx
   133a2:      	movq	%rax, 0x28(%rsp)
   133a7:      	callq	0x53220 <<std::sys::pal::unix::time::Timespec>::now>
   133ac:      	movq	%rax, 0x40(%rsp)
   133b1:      	movl	%edx, 0x48(%rsp)
   133b5:      	movq	%r14, 0x30(%rsp)
   133ba:      	movl	%ebp, 0x38(%rsp)
   133be:      	leaq	0x8(%rsp), %rdi
   133c3:      	leaq	0x40(%rsp), %rsi
   133c8:      	leaq	0x30(%rsp), %r14
   133cd:      	movq	%r14, %rdx
   133d0:      	callq	0x53150 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   133d5:      	cmpb	$0x0, 0x8(%rsp)
   133da:      	xorpd	%xmm0, %xmm0
   133de:      	jne	0x13416 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f+0xa6>
   133e0:      	movsd	0x10(%rsp), %xmm1
   133e6:      	unpcklps	-0xf31d(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x40d0 <writev+0x40d0>
   133ed:      	subpd	-0xf375(%rip), %xmm1    # 0x4080 <writev+0x4080>
   133f5:      	movapd	%xmm1, %xmm2
   133f9:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   133fd:      	xorps	%xmm0, %xmm0
   13400:      	cvtsi2sdl	0x18(%rsp), %xmm0
   13406:      	addsd	%xmm1, %xmm2
   1340a:      	divsd	-0xf112(%rip), %xmm0    # 0x4300 <writev+0x4300>
   13412:      	addsd	%xmm2, %xmm0
   13416:      	movsd	%xmm0, 0x30(%rsp)
   1341c:      	cmpq	$0x5, %rbx
   13420:      	jne	0x13483 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f+0x113>
   13422:      	leaq	0x28(%rsp), %rax
   13427:      	movq	%rax, 0x8(%rsp)
   1342c:      	leaq	0x6a4d(%rip), %rax      # 0x19e80 <<i64 as core::fmt::Display>::fmt>
   13433:      	movq	%rax, 0x10(%rsp)
   13438:      	movq	%r14, 0x18(%rsp)
   1343d:      	leaq	0x891c(%rip), %rax      # 0x1bd60 <<f64 as core::fmt::Display>::fmt>
   13444:      	movq	%rax, 0x20(%rsp)
   13449:      	leaq	-0xd654(%rip), %rdi     # 0x5dfc <writev+0x5dfc>
   13450:      	leaq	0x8(%rsp), %rsi
   13455:      	callq	0x580a0 <std::io::stdio::_print>
   1345a:      	leaq	0x8(%rsp), %rdi
   1345f:      	callq	0x267a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13464:      	movq	0x8(%rsp), %rbx
   13469:      	testq	%rbx, %rbx
   1346c:      	jle	0x13479 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f+0x109>
   1346e:      	movq	0x10(%rsp), %rdi
   13473:      	callq	*0x49d07(%rip)          # 0x5d180 <writev+0x5d180>
   13479:      	xorl	%eax, %eax
   1347b:      	negq	%rbx
   1347e:      	setno	%al
   13481:      	jmp	0x134a5 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f+0x135>
   13483:      	leaq	0x8(%rsp), %rdi
   13488:      	callq	0x267a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   1348d:      	cmpq	$0x0, 0x8(%rsp)
   13493:      	jle	0x134a0 <wasm_native_79d5fb134e730b28e88a7c0cd80d449234a7c21f1a4457820667bcace1dfcadd::run::h4847ab6dfc03214f+0x130>
   13495:      	movq	0x10(%rsp), %rdi
   1349a:      	callq	*0x49ce0(%rip)          # 0x5d180 <writev+0x5d180>
   134a0:      	movl	$0x1, %eax
   134a5:      	addq	$0x50, %rsp
   134a9:      	popq	%rbx
   134aa:      	popq	%r14
   134ac:      	popq	%rbp
   134ad:      	retq
   134ae:      	int3
   134af:      	int3
