00000000000571c0 <f.2>:
   571c0:      	pushq	%rbp
   571c1:      	pushq	%r15
   571c3:      	pushq	%r14
   571c5:      	pushq	%r13
   571c7:      	pushq	%r12
   571c9:      	pushq	%rbx
   571ca:      	subq	$0x88, %rsp
   571d1:      	movq	%rdx, %r14
   571d4:      	movq	%rsi, %rbx
   571d7:      	movq	$0x3, 0x30(%rsp)
   571e0:      	movq	$0x0, 0x38(%rsp)
   571e9:      	movq	0x1c5d8(%rip), %rcx     # 0x737c8 <native_roots.0>
   571f0:      	movq	%rcx, 0x28(%rsp)
   571f5:      	leaq	0x28(%rsp), %r8
   571fa:      	movq	%r8, 0x1c5c7(%rip)      # 0x737c8 <native_roots.0>
   57201:      	movq	0x1c5a0(%rip), %rax     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57208:      	leaq	0x1(%rax), %rdx
   5720c:      	movq	%rdx, 0x1c595(%rip)     # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57213:      	movq	0x1c596(%rip), %rsi     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5721a:      	cmpq	%rsi, %rdx
   5721d:      	cmovaq	%rdx, %rsi
   57221:      	movq	%rsi, 0x1c588(%rip)     # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   57228:      	movq	%rdi, 0x40(%rsp)
   5722d:      	movq	$0x0, 0x48(%rsp)
   57236:      	testq	%rdi, %rdi
   57239:      	je	0x6e9c5 <f.2+0x17805>
   5723f:      	movq	%rdi, 0x48(%rsp)
   57244:      	cmpq	%rbx, 0x8(%rdi)
   57248:      	jle	0x6e9a0 <f.2+0x177e0>
   5724e:      	leaq	0x20(%rsp), %rdi
   57253:      	leaq	0x1c56e(%rip), %r9      # 0x737c8 <native_roots.0>
   5725a:      	nopw	(%rax,%rax)
   57260:      	cmpb	$0x0, 0x1c659(%rip)     # 0x738c0 <g.6>
   57267:      	je	0x6e9c5 <f.2+0x17805>
   5726d:      	cmpb	$0x0, 0x1c62c(%rip)     # 0x738a0 <g.2>
   57274:      	je	0x6e9c5 <f.2+0x17805>
   5727a:      	cmpq	$0x0, 0x1c616(%rip)     # 0x73898 <g.1>
   57282:      	je	0x6e9c5 <f.2+0x17805>
   57288:      	movq	0x1c629(%rip), %rax     # 0x738b8 <g.5>
   5728f:      	movq	$0x2, 0x38(%rsp)
   57298:      	movq	%rax, 0x20(%rsp)
   5729d:      	cmpb	$0x0, 0x1c60c(%rip)     # 0x738b0 <g.4>
   572a4:      	je	0x6e9c5 <f.2+0x17805>
   572aa:      	cmpq	$0x0, 0x1c5f6(%rip)     # 0x738a8 <g.3>
   572b2:      	je	0x6e9c5 <f.2+0x17805>
   572b8:      	movq	0x20(%rsp), %r14
   572bd:      	cmpq	$0x2, %r14
   572c1:      	jl	0x6e900 <f.2+0x17740>
   572c7:      	movl	$0x1, %r15d
   572cd:      	je	0x5736e <f.2+0x1ae>
   572d3:      	movl	$0x1, %r12d
   572d9:      	cmpq	$0x4, %r14
   572dd:      	jb	0x57346 <f.2+0x186>
   572df:      	movl	$0x1, %eax
   572e4:      	je	0x5732a <f.2+0x16a>
   572e6:      	cmpq	$0x5, %r14
   572ea:      	jbe	0x57326 <f.2+0x166>
   572ec:      	cmpq	$0x6, %r14
   572f0:      	je	0x574e9 <f.2+0x329>
   572f6:      	cmpq	$0x7, %r14
   572fa:      	jbe	0x574e5 <f.2+0x325>
   57300:      	cmpq	$0x8, %r14
   57304:      	je	0x576f1 <f.2+0x531>
   5730a:      	cmpq	$0x9, %r14
   5730e:      	jbe	0x576ed <f.2+0x52d>
   57314:      	cmpq	$0xa, %r14
   57318:      	jne	0x57af6 <f.2+0x936>
   5731e:      	xorl	%r12d, %r12d
   57321:      	jmp	0x58048 <f.2+0xe88>
   57326:      	leaq	-0x4(%r14), %rax
   5732a:      	leaq	(%r14,%rax), %r12
   5732e:      	addq	$-0x4, %r12
   57332:      	cmpq	$0x5, %r14
   57336:      	je	0x66ccf <f.2+0xfb0f>
   5733c:      	cmpq	$0x4, %r14
   57340:      	jne	0x5746e <f.2+0x2ae>
   57346:      	leaq	-0x3(%r14), %r15
   5734a:      	cmpb	$0x0, 0x1c55f(%rip)     # 0x738b0 <g.4>
   57351:      	je	0x6e9c5 <f.2+0x17805>
   57357:      	cmpq	$0x0, 0x1c549(%rip)     # 0x738a8 <g.3>
   5735f:      	je	0x6e9c5 <f.2+0x17805>
   57365:      	addq	%r12, %r15
   57368:      	cmpq	$0x3, %r14
   5736c:      	ja	0x57377 <f.2+0x1b7>
   5736e:      	addq	$-0x2, %r14
   57372:      	jmp	0x6e8fd <f.2+0x1773d>
   57377:      	movl	$0x1, %r12d
   5737d:      	cmpq	$0x4, %r14
   57381:      	je	0x574bc <f.2+0x2fc>
   57387:      	cmpq	$0x5, %r14
   5738b:      	jbe	0x574b8 <f.2+0x2f8>
   57391:      	movl	$0x1, %eax
   57396:      	cmpq	$0x6, %r14
   5739a:      	je	0x57549 <f.2+0x389>
   573a0:      	cmpq	$0x7, %r14
   573a4:      	jbe	0x57545 <f.2+0x385>
   573aa:      	cmpq	$0x8, %r14
   573ae:      	je	0x57733 <f.2+0x573>
   573b4:      	cmpq	$0x9, %r14
   573b8:      	jbe	0x5772f <f.2+0x56f>
   573be:      	cmpq	$0xa, %r14
   573c2:      	je	0x57f7f <f.2+0xdbf>
   573c8:      	movq	%r14, %r12
   573cb:      	subq	$0xb, %r12
   573cf:      	jbe	0x57f7c <f.2+0xdbc>
   573d5:      	movq	$0x0, 0x50(%rsp)
   573de:      	movq	$0x3, 0x38(%rsp)
   573e7:      	xorl	%edi, %edi
   573e9:      	movq	%r12, %rsi
   573ec:      	callq	0x6e9d0 <f.3>
   573f1:      	subq	$0x8, %rsp
   573f5:      	cmpb	$0x0, 0x1c4b4(%rip)     # 0x738b0 <g.4>
   573fc:      	je	0x6e9c5 <f.2+0x17805>
   57402:      	cmpq	$0x0, 0x1c49e(%rip)     # 0x738a8 <g.3>
   5740a:      	je	0x6e9c5 <f.2+0x17805>
   57410:      	movq	%rax, %r13
   57413:      	leaq	-0xc(%r14), %rbp
   57417:      	movq	$0x0, 0x50(%rsp)
   57420:      	movq	$0x3, 0x38(%rsp)
   57429:      	xorl	%edi, %edi
   5742b:      	movq	%rbp, %rsi
   5742e:      	callq	0x6e9d0 <f.3>
   57433:      	subq	$0x8, %rsp
   57437:      	cmpb	$0x0, 0x1c472(%rip)     # 0x738b0 <g.4>
   5743e:      	je	0x6e9c5 <f.2+0x17805>
   57444:      	cmpq	$0x0, 0x1c45c(%rip)     # 0x738a8 <g.3>
   5744c:      	je	0x6e9c5 <f.2+0x17805>
   57452:      	addq	%r13, %rax
   57455:      	cmpq	$0xc, %r14
   57459:      	jne	0x58d6d <f.2+0x1bad>
   5745f:      	addq	%rax, %r12
   57462:      	movl	$0x1, %ebp
   57467:      	xorl	%eax, %eax
   57469:      	jmp	0x5b4b1 <f.2+0x42f1>
   5746e:      	cmpq	$0x6, %r14
   57472:      	jbe	0x574c8 <f.2+0x308>
   57474:      	movl	$0x1, %eax
   57479:      	cmpq	$0x7, %r14
   5747d:      	je	0x57661 <f.2+0x4a1>
   57483:      	cmpq	$0x8, %r14
   57487:      	jbe	0x5765d <f.2+0x49d>
   5748d:      	cmpq	$0x9, %r14
   57491:      	je	0x57955 <f.2+0x795>
   57497:      	cmpq	$0xa, %r14
   5749b:      	jbe	0x57951 <f.2+0x791>
   574a1:      	cmpq	$0xb, %r14
   574a5:      	jne	0x57e45 <f.2+0xc85>
   574ab:      	movl	$0x1, %r15d
   574b1:      	xorl	%ebp, %ebp
   574b3:      	jmp	0x586c3 <f.2+0x1503>
   574b8:      	leaq	-0x4(%r14), %r12
   574bc:      	addq	$-0x4, %r14
   574c0:      	movq	%r14, %r13
   574c3:      	jmp	0x6e8f7 <f.2+0x17737>
   574c8:      	leaq	-0x5(%r14), %r15
   574cc:      	leaq	-0x5(%r14), %r13
   574d0:      	addq	%r13, %r15
   574d3:      	cmpb	$0x0, 0x1c3d6(%rip)     # 0x738b0 <g.4>
   574da:      	jne	0x57357 <f.2+0x197>
   574e0:      	jmp	0x6e9c5 <f.2+0x17805>
   574e5:      	leaq	-0x6(%r14), %rax
   574e9:      	leaq	(%r14,%rax), %r12
   574ed:      	addq	$-0x6, %r12
   574f1:      	cmpq	$0x6, %r14
   574f5:      	je	0x580d8 <f.2+0xf18>
   574fb:      	movl	$0x1, %r13d
   57501:      	cmpq	$0x7, %r14
   57505:      	je	0x57647 <f.2+0x487>
   5750b:      	cmpq	$0x8, %r14
   5750f:      	jbe	0x57643 <f.2+0x483>
   57515:      	movl	$0x1, %eax
   5751a:      	cmpq	$0x9, %r14
   5751e:      	je	0x57824 <f.2+0x664>
   57524:      	cmpq	$0xa, %r14
   57528:      	jbe	0x57820 <f.2+0x660>
   5752e:      	cmpq	$0xb, %r14
   57532:      	jne	0x57c31 <f.2+0xa71>
   57538:      	movl	$0x1, %r15d
   5753e:      	xorl	%ebp, %ebp
   57540:      	jmp	0x584d5 <f.2+0x1315>
   57545:      	leaq	-0x6(%r14), %rax
   57549:      	leaq	(%r14,%rax), %rcx
   5754d:      	addq	$-0x6, %rcx
   57551:      	cmpq	$0x6, %r14
   57555:      	je	0x6872d <f.2+0x1156d>
   5755b:      	movl	$0x1, %ebp
   57560:      	cmpq	$0x7, %r14
   57564:      	je	0x576bd <f.2+0x4fd>
   5756a:      	cmpq	$0x8, %r14
   5756e:      	jbe	0x576b9 <f.2+0x4f9>
   57574:      	movl	$0x1, %eax
   57579:      	cmpq	$0x9, %r14
   5757d:      	je	0x57a08 <f.2+0x848>
   57583:      	cmpq	$0xa, %r14
   57587:      	jbe	0x57a04 <f.2+0x844>
   5758d:      	cmpq	$0xb, %r14
   57591:      	je	0x585f8 <f.2+0x1438>
   57597:      	movq	%r14, %rbp
   5759a:      	subq	$0xc, %rbp
   5759e:      	jbe	0x585f5 <f.2+0x1435>
   575a4:      	movq	%rcx, 0x10(%rsp)
   575a9:      	movq	$0x0, 0x50(%rsp)
   575b2:      	movq	$0x3, 0x38(%rsp)
   575bb:      	xorl	%edi, %edi
   575bd:      	movq	%rbp, %rsi
   575c0:      	callq	0x6e9d0 <f.3>
   575c5:      	subq	$0x8, %rsp
   575c9:      	cmpb	$0x0, 0x1c2e0(%rip)     # 0x738b0 <g.4>
   575d0:      	je	0x6e9c5 <f.2+0x17805>
   575d6:      	cmpq	$0x0, 0x1c2ca(%rip)     # 0x738a8 <g.3>
   575de:      	je	0x6e9c5 <f.2+0x17805>
   575e4:      	movq	%rax, %r12
   575e7:      	leaq	-0xd(%r14), %r13
   575eb:      	movq	$0x0, 0x50(%rsp)
   575f4:      	movq	$0x3, 0x38(%rsp)
   575fd:      	xorl	%edi, %edi
   575ff:      	movq	%r13, %rsi
   57602:      	callq	0x6e9d0 <f.3>
   57607:      	subq	$0x8, %rsp
   5760b:      	cmpb	$0x0, 0x1c29e(%rip)     # 0x738b0 <g.4>
   57612:      	je	0x6e9c5 <f.2+0x17805>
   57618:      	cmpq	$0x0, 0x1c288(%rip)     # 0x738a8 <g.3>
   57620:      	je	0x6e9c5 <f.2+0x17805>
   57626:      	addq	%r12, %rax
   57629:      	cmpq	$0xd, %r14
   5762d:      	jne	0x59ddb <f.2+0x2c1b>
   57633:      	addq	%rax, %rbp
   57636:      	movl	$0x1, %r13d
   5763c:      	xorl	%eax, %eax
   5763e:      	jmp	0x5c491 <f.2+0x52d1>
   57643:      	leaq	-0x7(%r14), %r13
   57647:      	leaq	-0x7(%r14), %r15
   5764b:      	cmpb	$0x0, 0x1c25e(%rip)     # 0x738b0 <g.4>
   57652:      	jne	0x5fcd5 <f.2+0x8b15>
   57658:      	jmp	0x6e9c5 <f.2+0x17805>
   5765d:      	leaq	-0x7(%r14), %rax
   57661:      	addq	%r14, %rax
   57664:      	addq	$-0x7, %rax
   57668:      	cmpq	$0x7, %r14
   5766c:      	je	0x62a47 <f.2+0xb887>
   57672:      	movl	$0x1, %ebp
   57677:      	cmpq	$0x8, %r14
   5767b:      	je	0x576d7 <f.2+0x517>
   5767d:      	cmpq	$0x9, %r14
   57681:      	jbe	0x576d3 <f.2+0x513>
   57683:      	movl	$0x1, %ecx
   57688:      	cmpq	$0xa, %r14
   5768c:      	je	0x57bd5 <f.2+0xa15>
   57692:      	cmpq	$0xb, %r14
   57696:      	jbe	0x57bd1 <f.2+0xa11>
   5769c:      	cmpq	$0xc, %r14
   576a0:      	movq	%rax, 0x10(%rsp)
   576a5:      	jne	0x582d3 <f.2+0x1113>
   576ab:      	movl	$0x1, %r13d
   576b1:      	xorl	%r15d, %r15d
   576b4:      	jmp	0x59532 <f.2+0x2372>
   576b9:      	leaq	-0x7(%r14), %rbp
   576bd:      	leaq	-0x7(%r14), %r12
   576c1:      	cmpb	$0x0, 0x1c1e8(%rip)     # 0x738b0 <g.4>
   576c8:      	jne	0x687f5 <f.2+0x11635>
   576ce:      	jmp	0x6e9c5 <f.2+0x17805>
   576d3:      	leaq	-0x8(%r14), %rbp
   576d7:      	leaq	-0x8(%r14), %r15
   576db:      	cmpb	$0x0, 0x1c1ce(%rip)     # 0x738b0 <g.4>
   576e2:      	jne	0x63e87 <f.2+0xccc7>
   576e8:      	jmp	0x6e9c5 <f.2+0x17805>
   576ed:      	leaq	-0x8(%r14), %rax
   576f1:      	leaq	(%r14,%rax), %r12
   576f5:      	addq	$-0x8, %r12
   576f9:      	cmpq	$0x8, %r14
   576fd:      	je	0x580a8 <f.2+0xee8>
   57703:      	movl	$0x1, %r13d
   57709:      	cmpq	$0x9, %r14
   5770d:      	je	0x57870 <f.2+0x6b0>
   57713:      	cmpq	$0xa, %r14
   57717:      	jbe	0x5786c <f.2+0x6ac>
   5771d:      	cmpq	$0xb, %r14
   57721:      	jne	0x57cd5 <f.2+0xb15>
   57727:      	xorl	%r15d, %r15d
   5772a:      	jmp	0x57e06 <f.2+0xc46>
   5772f:      	leaq	-0x8(%r14), %rax
   57733:      	leaq	(%r14,%rax), %r13
   57737:      	addq	$-0x8, %r13
   5773b:      	cmpq	$0x8, %r14
   5773f:      	je	0x5bbcb <f.2+0x4a0b>
   57745:      	movl	$0x1, %ebp
   5774a:      	cmpq	$0x9, %r14
   5774e:      	je	0x579a1 <f.2+0x7e1>
   57754:      	cmpq	$0xa, %r14
   57758:      	jbe	0x5799d <f.2+0x7dd>
   5775e:      	cmpq	$0xb, %r14
   57762:      	je	0x585bd <f.2+0x13fd>
   57768:      	movq	%r14, %rbp
   5776b:      	subq	$0xc, %rbp
   5776f:      	jbe	0x585ba <f.2+0x13fa>
   57775:      	movq	$0x0, 0x50(%rsp)
   5777e:      	movq	$0x3, 0x38(%rsp)
   57787:      	xorl	%edi, %edi
   57789:      	movq	%rbp, %rsi
   5778c:      	callq	0x6e9d0 <f.3>
   57791:      	subq	$0x8, %rsp
   57795:      	cmpb	$0x0, 0x1c114(%rip)     # 0x738b0 <g.4>
   5779c:      	je	0x6e9c5 <f.2+0x17805>
   577a2:      	cmpq	$0x0, 0x1c0fe(%rip)     # 0x738a8 <g.3>
   577aa:      	je	0x6e9c5 <f.2+0x17805>
   577b0:      	movq	%rax, %r12
   577b3:      	leaq	-0xd(%r14), %rsi
   577b7:      	movq	$0x0, 0x50(%rsp)
   577c0:      	movq	$0x3, 0x38(%rsp)
   577c9:      	xorl	%edi, %edi
   577cb:      	callq	0x6e9d0 <f.3>
   577d0:      	subq	$0x8, %rsp
   577d4:      	cmpb	$0x0, 0x1c0d5(%rip)     # 0x738b0 <g.4>
   577db:      	je	0x6e9c5 <f.2+0x17805>
   577e1:      	cmpq	$0x0, 0x1c0bf(%rip)     # 0x738a8 <g.3>
   577e9:      	je	0x6e9c5 <f.2+0x17805>
   577ef:      	addq	%r12, %rax
   577f2:      	cmpq	$0xd, %r14
   577f6:      	leaq	-0xd(%r14), %rsi
   577fa:      	jne	0x59c06 <f.2+0x2a46>
   57800:      	addq	%rax, %rbp
   57803:      	movl	$0x1, %ecx
   57808:      	xorl	%eax, %eax
   5780a:      	leaq	0x28(%rsp), %r8
   5780f:      	leaq	0x20(%rsp), %rdi
   57814:      	leaq	0x1bfad(%rip), %r9      # 0x737c8 <native_roots.0>
   5781b:      	jmp	0x5c3eb <f.2+0x522b>
   57820:      	leaq	-0x9(%r14), %rax
   57824:      	leaq	(%r14,%rax), %r15
   57828:      	addq	$-0x9, %r15
   5782c:      	cmpq	$0x9, %r14
   57830:      	je	0x5c6dc <f.2+0x551c>
   57836:      	movl	$0x1, %ebp
   5783b:      	cmpq	$0xa, %r14
   5783f:      	je	0x57ba1 <f.2+0x9e1>
   57845:      	cmpq	$0xb, %r14
   57849:      	jbe	0x57b9d <f.2+0x9dd>
   5784f:      	cmpq	$0xc, %r14
   57853:      	movq	%r15, 0x10(%rsp)
   57858:      	jne	0x5818b <f.2+0xfcb>
   5785e:      	movl	$0x1, %r15d
   57864:      	xorl	%r13d, %r13d
   57867:      	jmp	0x59107 <f.2+0x1f47>
   5786c:      	leaq	-0x9(%r14), %r13
   57870:      	leaq	-0x9(%r14), %r15
   57874:      	cmpq	$0x0, 0x1c02c(%rip)     # 0x738a8 <g.3>
   5787c:      	je	0x6e9c5 <f.2+0x17805>
   57882:      	addq	%r13, %r15
   57885:      	addq	%r12, %r15
   57888:      	cmpq	$0x9, %r14
   5788c:      	jbe	0x57948 <f.2+0x788>
   57892:      	movl	$0x1, %r13d
   57898:      	cmpq	$0xa, %r14
   5789c:      	je	0x57eec <f.2+0xd2c>
   578a2:      	movq	%r14, %r13
   578a5:      	subq	$0xb, %r13
   578a9:      	jbe	0x57ee9 <f.2+0xd29>
   578af:      	movq	$0x0, 0x50(%rsp)
   578b8:      	movq	$0x3, 0x38(%rsp)
   578c1:      	xorl	%edi, %edi
   578c3:      	movq	%r13, %rsi
   578c6:      	callq	0x6e9d0 <f.3>
   578cb:      	subq	$0x8, %rsp
   578cf:      	cmpb	$0x0, 0x1bfda(%rip)     # 0x738b0 <g.4>
   578d6:      	je	0x6e9c5 <f.2+0x17805>
   578dc:      	cmpq	$0x0, 0x1bfc4(%rip)     # 0x738a8 <g.3>
   578e4:      	je	0x6e9c5 <f.2+0x17805>
   578ea:      	movq	%rax, %r12
   578ed:      	leaq	-0xc(%r14), %rbp
   578f1:      	movq	$0x0, 0x50(%rsp)
   578fa:      	movq	$0x3, 0x38(%rsp)
   57903:      	xorl	%edi, %edi
   57905:      	movq	%rbp, %rsi
   57908:      	callq	0x6e9d0 <f.3>
   5790d:      	subq	$0x8, %rsp
   57911:      	cmpb	$0x0, 0x1bf98(%rip)     # 0x738b0 <g.4>
   57918:      	je	0x6e9c5 <f.2+0x17805>
   5791e:      	cmpq	$0x0, 0x1bf82(%rip)     # 0x738a8 <g.3>
   57926:      	je	0x6e9c5 <f.2+0x17805>
   5792c:      	addq	%r12, %rax
   5792f:      	cmpq	$0xc, %r14
   57933:      	jne	0x589a7 <f.2+0x17e7>
   57939:      	addq	%rax, %r13
   5793c:      	movl	$0x1, %ebp
   57941:      	xorl	%eax, %eax
   57943:      	jmp	0x5a552 <f.2+0x3392>
   57948:      	leaq	-0x8(%r14), %r13
   5794c:      	jmp	0x580b6 <f.2+0xef6>
   57951:      	leaq	-0x9(%r14), %rax
   57955:      	leaq	(%r14,%rax), %r13
   57959:      	addq	$-0x9, %r13
   5795d:      	cmpq	$0x9, %r14
   57961:      	je	0x5c844 <f.2+0x5684>
   57967:      	movl	$0x1, %ebp
   5796c:      	cmpq	$0xa, %r14
   57970:      	je	0x57bbb <f.2+0x9fb>
   57976:      	cmpq	$0xb, %r14
   5797a:      	jbe	0x57bb7 <f.2+0x9f7>
   57980:      	cmpq	$0xc, %r14
   57984:      	movq	%r13, 0x10(%rsp)
   57989:      	jne	0x5822f <f.2+0x106f>
   5798f:      	movl	$0x1, %r13d
   57995:      	xorl	%r15d, %r15d
   57998:      	jmp	0x593b7 <f.2+0x21f7>
   5799d:      	leaq	-0x9(%r14), %rbp
   579a1:      	leaq	-0x9(%r14), %r12
   579a5:      	cmpq	$0x0, 0x1befb(%rip)     # 0x738a8 <g.3>
   579ad:      	je	0x6e9c5 <f.2+0x17805>
   579b3:      	addq	%rbp, %r12
   579b6:      	addq	%r13, %r12
   579b9:      	cmpq	$0x9, %r14
   579bd:      	jbe	0x579f7 <f.2+0x837>
   579bf:      	movl	$0x1, %eax
   579c4:      	cmpq	$0xa, %r14
   579c8:      	je	0x57f26 <f.2+0xd66>
   579ce:      	cmpq	$0xb, %r14
   579d2:      	jbe	0x57f22 <f.2+0xd62>
   579d8:      	cmpq	$0xc, %r14
   579dc:      	movq	%r12, 0x18(%rsp)
   579e1:      	jne	0x588fb <f.2+0x173b>
   579e7:      	movl	$0x1, %r13d
   579ed:      	xorl	%ebp, %ebp
   579ef:      	addq	%r13, %rbp
   579f2:      	jmp	0x5a04b <f.2+0x2e8b>
   579f7:      	leaq	-0x8(%r14), %rbp
   579fb:      	leaq	-0x8(%r14), %rcx
   579ff:      	jmp	0x68702 <f.2+0x11542>
   57a04:      	leaq	-0x9(%r14), %rax
   57a08:      	leaq	(%r14,%rax), %r12
   57a0c:      	addq	$-0x9, %r12
   57a10:      	cmpq	$0x9, %r14
   57a14:      	je	0x62c8e <f.2+0xbace>
   57a1a:      	movl	$0x1, %r13d
   57a20:      	cmpq	$0xa, %r14
   57a24:      	je	0x57c1b <f.2+0xa5b>
   57a2a:      	cmpq	$0xb, %r14
   57a2e:      	jbe	0x57c17 <f.2+0xa57>
   57a34:      	cmpq	$0xc, %r14
   57a38:      	je	0x5948e <f.2+0x22ce>
   57a3e:      	movq	%r14, %r13
   57a41:      	subq	$0xd, %r13
   57a45:      	jbe	0x5948b <f.2+0x22cb>
   57a4b:      	movq	%rcx, 0x10(%rsp)
   57a50:      	movq	$0x0, 0x50(%rsp)
   57a59:      	movq	$0x3, 0x38(%rsp)
   57a62:      	xorl	%edi, %edi
   57a64:      	movq	%r13, %rsi
   57a67:      	callq	0x6e9d0 <f.3>
   57a6c:      	subq	$0x8, %rsp
   57a70:      	cmpb	$0x0, 0x1be39(%rip)     # 0x738b0 <g.4>
   57a77:      	je	0x6e9c5 <f.2+0x17805>
   57a7d:      	cmpq	$0x0, 0x1be23(%rip)     # 0x738a8 <g.3>
   57a85:      	je	0x6e9c5 <f.2+0x17805>
   57a8b:      	movq	%rax, %rbp
   57a8e:      	leaq	-0xe(%r14), %rsi
   57a92:      	movq	$0x0, 0x50(%rsp)
   57a9b:      	movq	$0x3, 0x38(%rsp)
   57aa4:      	xorl	%edi, %edi
   57aa6:      	callq	0x6e9d0 <f.3>
   57aab:      	subq	$0x8, %rsp
   57aaf:      	cmpb	$0x0, 0x1bdfa(%rip)     # 0x738b0 <g.4>
   57ab6:      	je	0x6e9c5 <f.2+0x17805>
   57abc:      	cmpq	$0x0, 0x1bde4(%rip)     # 0x738a8 <g.3>
   57ac4:      	leaq	0x28(%rsp), %r8
   57ac9:      	leaq	0x1bcf8(%rip), %r9      # 0x737c8 <native_roots.0>
   57ad0:      	je	0x6e9c5 <f.2+0x17805>
   57ad6:      	addq	%rbp, %rax
   57ad9:      	cmpq	$0xe, %r14
   57add:      	leaq	-0xe(%r14), %rsi
   57ae1:      	jne	0x5b6cd <f.2+0x450d>
   57ae7:      	addq	%rax, %r13
   57aea:      	movl	$0x1, %edx
   57aef:      	xorl	%eax, %eax
   57af1:      	jmp	0x5b7f3 <f.2+0x4633>
   57af6:      	leaq	-0xa(%r14), %r12
   57afa:      	movq	$0x0, 0x50(%rsp)
   57b03:      	movq	$0x3, 0x38(%rsp)
   57b0c:      	xorl	%edi, %edi
   57b0e:      	movq	%r12, %rsi
   57b11:      	callq	0x6e9d0 <f.3>
   57b16:      	subq	$0x8, %rsp
   57b1a:      	cmpb	$0x0, 0x1bd8f(%rip)     # 0x738b0 <g.4>
   57b21:      	je	0x6e9c5 <f.2+0x17805>
   57b27:      	cmpq	$0x0, 0x1bd79(%rip)     # 0x738a8 <g.3>
   57b2f:      	je	0x6e9c5 <f.2+0x17805>
   57b35:      	movq	%rax, %rbp
   57b38:      	leaq	-0xb(%r14), %r13
   57b3c:      	movq	$0x0, 0x50(%rsp)
   57b45:      	movq	$0x3, 0x38(%rsp)
   57b4e:      	xorl	%edi, %edi
   57b50:      	movq	%r13, %rsi
   57b53:      	callq	0x6e9d0 <f.3>
   57b58:      	subq	$0x8, %rsp
   57b5c:      	cmpb	$0x0, 0x1bd4d(%rip)     # 0x738b0 <g.4>
   57b63:      	je	0x6e9c5 <f.2+0x17805>
   57b69:      	cmpq	$0x0, 0x1bd37(%rip)     # 0x738a8 <g.3>
   57b71:      	je	0x6e9c5 <f.2+0x17805>
   57b77:      	movq	%rax, %r15
   57b7a:      	addq	%rbp, %r15
   57b7d:      	cmpq	$0xb, %r14
   57b81:      	ja	0x57fb7 <f.2+0xdf7>
   57b87:      	leaq	0x28(%rsp), %r8
   57b8c:      	leaq	0x20(%rsp), %rdi
   57b91:      	leaq	0x1bc30(%rip), %r9      # 0x737c8 <native_roots.0>
   57b98:      	jmp	0x58048 <f.2+0xe88>
   57b9d:      	leaq	-0xa(%r14), %rbp
   57ba1:      	leaq	-0xa(%r14), %r13
   57ba5:      	cmpb	$0x0, 0x1bd04(%rip)     # 0x738b0 <g.4>
   57bac:      	jne	0x5cba1 <f.2+0x59e1>
   57bb2:      	jmp	0x6e9c5 <f.2+0x17805>
   57bb7:      	leaq	-0xa(%r14), %rbp
   57bbb:      	leaq	-0xa(%r14), %r15
   57bbf:      	cmpb	$0x0, 0x1bcea(%rip)     # 0x738b0 <g.4>
   57bc6:      	jne	0x5d6ac <f.2+0x64ec>
   57bcc:      	jmp	0x6e9c5 <f.2+0x17805>
   57bd1:      	leaq	-0xa(%r14), %rcx
   57bd5:      	leaq	(%r14,%rcx), %r15
   57bd9:      	addq	$-0xa, %r15
   57bdd:      	cmpq	$0xa, %r14
   57be1:      	je	0x5e1e8 <f.2+0x7028>
   57be7:      	movl	$0x1, %r13d
   57bed:      	cmpq	$0xb, %r14
   57bf1:      	je	0x57f73 <f.2+0xdb3>
   57bf7:      	cmpq	$0xc, %r14
   57bfb:      	jbe	0x57f6f <f.2+0xdaf>
   57c01:      	cmpq	$0xd, %r14
   57c05:      	movq	%rax, 0x10(%rsp)
   57c0a:      	jne	0x58b8a <f.2+0x19ca>
   57c10:      	xorl	%ecx, %ecx
   57c12:      	jmp	0x5a635 <f.2+0x3475>
   57c17:      	leaq	-0xa(%r14), %r13
   57c1b:      	leaq	-0xa(%r14), %rbp
   57c1f:      	cmpb	$0x0, 0x1bc8a(%rip)     # 0x738b0 <g.4>
   57c26:      	jne	0x66fd3 <f.2+0xfe13>
   57c2c:      	jmp	0x6e9c5 <f.2+0x17805>
   57c31:      	leaq	-0xb(%r14), %rbp
   57c35:      	movq	$0x0, 0x50(%rsp)
   57c3e:      	movq	$0x3, 0x38(%rsp)
   57c47:      	xorl	%edi, %edi
   57c49:      	movq	%rbp, %rsi
   57c4c:      	callq	0x6e9d0 <f.3>
   57c51:      	subq	$0x8, %rsp
   57c55:      	cmpb	$0x0, 0x1bc54(%rip)     # 0x738b0 <g.4>
   57c5c:      	je	0x6e9c5 <f.2+0x17805>
   57c62:      	cmpq	$0x0, 0x1bc3e(%rip)     # 0x738a8 <g.3>
   57c6a:      	je	0x6e9c5 <f.2+0x17805>
   57c70:      	movq	%rax, %r13
   57c73:      	leaq	-0xc(%r14), %rsi
   57c77:      	movq	$0x0, 0x50(%rsp)
   57c80:      	movq	$0x3, 0x38(%rsp)
   57c89:      	xorl	%edi, %edi
   57c8b:      	callq	0x6e9d0 <f.3>
   57c90:      	subq	$0x8, %rsp
   57c94:      	cmpb	$0x0, 0x1bc15(%rip)     # 0x738b0 <g.4>
   57c9b:      	je	0x6e9c5 <f.2+0x17805>
   57ca1:      	cmpq	$0x0, 0x1bbff(%rip)     # 0x738a8 <g.3>
   57ca9:      	leaq	0x28(%rsp), %r8
   57cae:      	leaq	0x1bb13(%rip), %r9      # 0x737c8 <native_roots.0>
   57cb5:      	je	0x6e9c5 <f.2+0x17805>
   57cbb:      	movq	%rax, %r15
   57cbe:      	addq	%r13, %r15
   57cc1:      	cmpq	$0xc, %r14
   57cc5:      	ja	0x58443 <f.2+0x1283>
   57ccb:      	leaq	0x20(%rsp), %rdi
   57cd0:      	jmp	0x584d5 <f.2+0x1315>
   57cd5:      	leaq	-0xb(%r14), %r15
   57cd9:      	movq	$0x0, 0x50(%rsp)
   57ce2:      	movq	$0x3, 0x38(%rsp)
   57ceb:      	xorl	%edi, %edi
   57ced:      	movq	%r15, %rsi
   57cf0:      	callq	0x6e9d0 <f.3>
   57cf5:      	subq	$0x8, %rsp
   57cf9:      	cmpb	$0x0, 0x1bbb0(%rip)     # 0x738b0 <g.4>
   57d00:      	je	0x6e9c5 <f.2+0x17805>
   57d06:      	cmpq	$0x0, 0x1bb9a(%rip)     # 0x738a8 <g.3>
   57d0e:      	je	0x6e9c5 <f.2+0x17805>
   57d14:      	movq	%rax, %rbp
   57d17:      	leaq	-0xc(%r14), %rsi
   57d1b:      	movq	$0x0, 0x50(%rsp)
   57d24:      	movq	$0x3, 0x38(%rsp)
   57d2d:      	xorl	%edi, %edi
   57d2f:      	callq	0x6e9d0 <f.3>
   57d34:      	subq	$0x8, %rsp
   57d38:      	cmpb	$0x0, 0x1bb71(%rip)     # 0x738b0 <g.4>
   57d3f:      	je	0x6e9c5 <f.2+0x17805>
   57d45:      	cmpq	$0x0, 0x1bb5b(%rip)     # 0x738a8 <g.3>
   57d4d:      	leaq	0x28(%rsp), %r8
   57d52:      	leaq	0x20(%rsp), %rdi
   57d57:      	leaq	0x1ba6a(%rip), %r9      # 0x737c8 <native_roots.0>
   57d5e:      	je	0x6e9c5 <f.2+0x17805>
   57d64:      	movq	%rax, %r13
   57d67:      	addq	%rbp, %r13
   57d6a:      	cmpq	$0xc, %r14
   57d6e:      	jbe	0x57e06 <f.2+0xc46>
   57d74:      	movq	$0x0, 0x50(%rsp)
   57d7d:      	movq	$0x3, 0x38(%rsp)
   57d86:      	xorl	%edi, %edi
   57d88:      	leaq	-0xc(%r14), %rsi
   57d8c:      	callq	0x6e9d0 <f.3>
   57d91:      	subq	$0x8, %rsp
   57d95:      	cmpb	$0x0, 0x1bb14(%rip)     # 0x738b0 <g.4>
   57d9c:      	je	0x6e9c5 <f.2+0x17805>
   57da2:      	cmpq	$0x0, 0x1bafe(%rip)     # 0x738a8 <g.3>
   57daa:      	je	0x6e9c5 <f.2+0x17805>
   57db0:      	movq	%rax, %rbp
   57db3:      	leaq	-0xd(%r14), %rsi
   57db7:      	movq	$0x0, 0x50(%rsp)
   57dc0:      	movq	$0x3, 0x38(%rsp)
   57dc9:      	xorl	%edi, %edi
   57dcb:      	callq	0x6e9d0 <f.3>
   57dd0:      	subq	$0x8, %rsp
   57dd4:      	cmpb	$0x0, 0x1bad5(%rip)     # 0x738b0 <g.4>
   57ddb:      	je	0x6e9c5 <f.2+0x17805>
   57de1:      	cmpq	$0x0, 0x1babf(%rip)     # 0x738a8 <g.3>
   57de9:      	leaq	0x28(%rsp), %r8
   57dee:      	leaq	0x20(%rsp), %rdi
   57df3:      	leaq	0x1b9ce(%rip), %r9      # 0x737c8 <native_roots.0>
   57dfa:      	je	0x6e9c5 <f.2+0x17805>
   57e00:      	movq	%rax, %r15
   57e03:      	addq	%rbp, %r15
   57e06:      	addq	%r13, %r15
   57e09:      	cmpq	$0xb, %r14
   57e0d:      	je	0x5837c <f.2+0x11bc>
   57e13:      	cmpq	$0xc, %r14
   57e17:      	jne	0x58396 <f.2+0x11d6>
   57e1d:      	cmpq	$0x0, 0x1ba83(%rip)     # 0x738a8 <g.3>
   57e25:      	je	0x6e9c5 <f.2+0x17805>
   57e2b:      	incq	%r15
   57e2e:      	leaq	-0xc(%r14), %rbp
   57e32:      	movq	%r15, %r13
   57e35:      	incq	%rbp
   57e38:      	leaq	(%r14,%rbp), %r15
   57e3c:      	addq	$-0xb, %r15
   57e40:      	jmp	0x57874 <f.2+0x6b4>
   57e45:      	leaq	-0xb(%r14), %rbp
   57e49:      	movq	$0x0, 0x50(%rsp)
   57e52:      	movq	$0x3, 0x38(%rsp)
   57e5b:      	xorl	%edi, %edi
   57e5d:      	movq	%rbp, %rsi
   57e60:      	callq	0x6e9d0 <f.3>
   57e65:      	subq	$0x8, %rsp
   57e69:      	cmpb	$0x0, 0x1ba40(%rip)     # 0x738b0 <g.4>
   57e70:      	je	0x6e9c5 <f.2+0x17805>
   57e76:      	cmpq	$0x0, 0x1ba2a(%rip)     # 0x738a8 <g.3>
   57e7e:      	je	0x6e9c5 <f.2+0x17805>
   57e84:      	movq	%rax, %r13
   57e87:      	leaq	-0xc(%r14), %rsi
   57e8b:      	movq	$0x0, 0x50(%rsp)
   57e94:      	movq	$0x3, 0x38(%rsp)
   57e9d:      	xorl	%edi, %edi
   57e9f:      	callq	0x6e9d0 <f.3>
   57ea4:      	subq	$0x8, %rsp
   57ea8:      	cmpb	$0x0, 0x1ba01(%rip)     # 0x738b0 <g.4>
   57eaf:      	je	0x6e9c5 <f.2+0x17805>
   57eb5:      	cmpq	$0x0, 0x1b9eb(%rip)     # 0x738a8 <g.3>
   57ebd:      	je	0x6e9c5 <f.2+0x17805>
   57ec3:      	movq	%rax, %r15
   57ec6:      	addq	%r13, %r15
   57ec9:      	cmpq	$0xc, %r14
   57ecd:      	ja	0x58631 <f.2+0x1471>
   57ed3:      	leaq	0x28(%rsp), %r8
   57ed8:      	leaq	0x20(%rsp), %rdi
   57edd:      	leaq	0x1b8e4(%rip), %r9      # 0x737c8 <native_roots.0>
   57ee4:      	jmp	0x586c3 <f.2+0x1503>
   57ee9:      	incq	%r13
   57eec:      	leaq	(%r14,%r13), %r12
   57ef0:      	addq	$-0xa, %r12
   57ef4:      	cmpq	$0xa, %r14
   57ef8:      	je	0x5a584 <f.2+0x33c4>
   57efe:      	movl	$0x1, %ebp
   57f03:      	cmpq	$0xb, %r14
   57f07:      	je	0x57f19 <f.2+0xd59>
   57f09:      	movq	%r14, %rbp
   57f0c:      	subq	$0xc, %rbp
   57f10:      	ja	0x58ace <f.2+0x190e>
   57f16:      	incq	%rbp
   57f19:      	leaq	-0xb(%r14), %r13
   57f1d:      	jmp	0x5b08d <f.2+0x3ecd>
   57f22:      	leaq	-0xa(%r14), %rax
   57f26:      	addq	%r14, %rax
   57f29:      	addq	$-0xa, %rax
   57f2d:      	cmpq	$0xa, %r14
   57f31:      	je	0x62bc5 <f.2+0xba05>
   57f37:      	movl	$0x1, %r13d
   57f3d:      	cmpq	$0xb, %r14
   57f41:      	je	0x5843a <f.2+0x127a>
   57f47:      	cmpq	$0xc, %r14
   57f4b:      	jbe	0x58436 <f.2+0x1276>
   57f51:      	cmpq	$0xd, %r14
   57f55:      	movq	%rax, 0x10(%rsp)
   57f5a:      	movq	%r12, 0x18(%rsp)
   57f5f:      	jne	0x59a04 <f.2+0x2844>
   57f65:      	xorl	%ebp, %ebp
   57f67:      	addq	%r13, %rbp
   57f6a:      	jmp	0x5b8a9 <f.2+0x46e9>
   57f6f:      	leaq	-0xb(%r14), %r13
   57f73:      	leaq	-0xb(%r14), %rbp
   57f77:      	jmp	0x5f154 <f.2+0x7f94>
   57f7c:      	incq	%r12
   57f7f:      	leaq	(%r14,%r12), %r13
   57f83:      	addq	$-0xa, %r13
   57f87:      	cmpq	$0xa, %r14
   57f8b:      	je	0x5b4e3 <f.2+0x4323>
   57f91:      	movl	$0x1, %ebp
   57f96:      	cmpq	$0xb, %r14
   57f9a:      	je	0x58b81 <f.2+0x19c1>
   57fa0:      	movq	%r14, %rbp
   57fa3:      	subq	$0xc, %rbp
   57fa7:      	jbe	0x58b7e <f.2+0x19be>
   57fad:      	movq	%r13, 0x10(%rsp)
   57fb2:      	jmp	0x58e8d <f.2+0x1ccd>
   57fb7:      	movq	$0x0, 0x50(%rsp)
   57fc0:      	movq	$0x3, 0x38(%rsp)
   57fc9:      	xorl	%edi, %edi
   57fcb:      	movq	%r13, %rsi
   57fce:      	callq	0x6e9d0 <f.3>
   57fd3:      	subq	$0x8, %rsp
   57fd7:      	cmpb	$0x0, 0x1b8d2(%rip)     # 0x738b0 <g.4>
   57fde:      	je	0x6e9c5 <f.2+0x17805>
   57fe4:      	cmpq	$0x0, 0x1b8bc(%rip)     # 0x738a8 <g.3>
   57fec:      	je	0x6e9c5 <f.2+0x17805>
   57ff2:      	movq	%rax, %r13
   57ff5:      	leaq	-0xc(%r14), %rsi
   57ff9:      	movq	$0x0, 0x50(%rsp)
   58002:      	movq	$0x3, 0x38(%rsp)
   5800b:      	xorl	%edi, %edi
   5800d:      	callq	0x6e9d0 <f.3>
   58012:      	subq	$0x8, %rsp
   58016:      	cmpb	$0x0, 0x1b893(%rip)     # 0x738b0 <g.4>
   5801d:      	je	0x6e9c5 <f.2+0x17805>
   58023:      	cmpq	$0x0, 0x1b87d(%rip)     # 0x738a8 <g.3>
   5802b:      	leaq	0x28(%rsp), %r8
   58030:      	leaq	0x20(%rsp), %rdi
   58035:      	leaq	0x1b78c(%rip), %r9      # 0x737c8 <native_roots.0>
   5803c:      	je	0x6e9c5 <f.2+0x17805>
   58042:      	movq	%rax, %r12
   58045:      	addq	%r13, %r12
   58048:      	addq	%r15, %r12
   5804b:      	cmpq	$0xa, %r14
   5804f:      	je	0x58078 <f.2+0xeb8>
   58051:      	cmpq	$0xb, %r14
   58055:      	jne	0x580ef <f.2+0xf2f>
   5805b:      	cmpq	$0x0, 0x1b845(%rip)     # 0x738a8 <g.3>
   58063:      	je	0x6e9c5 <f.2+0x17805>
   58069:      	incq	%r12
   5806c:      	leaq	-0xb(%r14), %r15
   58070:      	movq	%r12, %r13
   58073:      	incq	%r15
   58076:      	jmp	0x58086 <f.2+0xec6>
   58078:      	leaq	(%r14,%r12), %r13
   5807c:      	addq	$-0x9, %r13
   58080:      	movl	$0x1, %r15d
   58086:      	leaq	-0xa(%r14), %r12
   5808a:      	cmpq	$0x0, 0x1b816(%rip)     # 0x738a8 <g.3>
   58092:      	je	0x6e9c5 <f.2+0x17805>
   58098:      	addq	%r15, %r12
   5809b:      	addq	%r13, %r12
   5809e:      	cmpq	$0x8, %r14
   580a2:      	jne	0x57703 <f.2+0x543>
   580a8:      	leaq	(%r14,%r12), %r15
   580ac:      	addq	$-0x7, %r15
   580b0:      	movl	$0x1, %r13d
   580b6:      	leaq	-0x8(%r14), %r12
   580ba:      	cmpq	$0x0, 0x1b7e6(%rip)     # 0x738a8 <g.3>
   580c2:      	je	0x6e9c5 <f.2+0x17805>
   580c8:      	addq	%r13, %r12
   580cb:      	addq	%r15, %r12
   580ce:      	cmpq	$0x6, %r14
   580d2:      	jne	0x574fb <f.2+0x33b>
   580d8:      	leaq	(%r14,%r12), %r15
   580dc:      	addq	$-0x5, %r15
   580e0:      	movl	$0x1, %r13d
   580e6:      	leaq	-0x6(%r14), %r12
   580ea:      	jmp	0x66ca4 <f.2+0xfae4>
   580ef:      	leaq	-0xb(%r14), %r15
   580f3:      	movq	$0x0, 0x50(%rsp)
   580fc:      	movq	$0x3, 0x38(%rsp)
   58105:      	xorl	%edi, %edi
   58107:      	movq	%r15, %rsi
   5810a:      	callq	0x6e9d0 <f.3>
   5810f:      	subq	$0x8, %rsp
   58113:      	cmpb	$0x0, 0x1b796(%rip)     # 0x738b0 <g.4>
   5811a:      	je	0x6e9c5 <f.2+0x17805>
   58120:      	cmpq	$0x0, 0x1b780(%rip)     # 0x738a8 <g.3>
   58128:      	je	0x6e9c5 <f.2+0x17805>
   5812e:      	movq	%rax, %r13
   58131:      	leaq	-0xc(%r14), %rsi
   58135:      	movq	$0x0, 0x50(%rsp)
   5813e:      	movq	$0x3, 0x38(%rsp)
   58147:      	xorl	%edi, %edi
   58149:      	callq	0x6e9d0 <f.3>
   5814e:      	subq	$0x8, %rsp
   58152:      	cmpb	$0x0, 0x1b757(%rip)     # 0x738b0 <g.4>
   58159:      	je	0x6e9c5 <f.2+0x17805>
   5815f:      	cmpq	$0x0, 0x1b741(%rip)     # 0x738a8 <g.3>
   58167:      	je	0x6e9c5 <f.2+0x17805>
   5816d:      	movq	%rax, %rbp
   58170:      	addq	%r13, %rbp
   58173:      	cmpq	$0xc, %r14
   58177:      	ja	0x587a8 <f.2+0x15e8>
   5817d:      	addq	%r15, %rbp
   58180:      	addq	%r12, %rbp
   58183:      	movq	%rbp, %r13
   58186:      	jmp	0x5884d <f.2+0x168d>
   5818b:      	leaq	-0xc(%r14), %r13
   5818f:      	movq	$0x0, 0x50(%rsp)
   58198:      	movq	$0x3, 0x38(%rsp)
   581a1:      	xorl	%edi, %edi
   581a3:      	movq	%r13, %rsi
   581a6:      	callq	0x6e9d0 <f.3>
   581ab:      	subq	$0x8, %rsp
   581af:      	cmpb	$0x0, 0x1b6fa(%rip)     # 0x738b0 <g.4>
   581b6:      	je	0x6e9c5 <f.2+0x17805>
   581bc:      	cmpq	$0x0, 0x1b6e4(%rip)     # 0x738a8 <g.3>
   581c4:      	je	0x6e9c5 <f.2+0x17805>
   581ca:      	movq	%rax, %rbp
   581cd:      	leaq	-0xd(%r14), %rsi
   581d1:      	movq	$0x0, 0x50(%rsp)
   581da:      	movq	$0x3, 0x38(%rsp)
   581e3:      	xorl	%edi, %edi
   581e5:      	callq	0x6e9d0 <f.3>
   581ea:      	subq	$0x8, %rsp
   581ee:      	cmpb	$0x0, 0x1b6bb(%rip)     # 0x738b0 <g.4>
   581f5:      	je	0x6e9c5 <f.2+0x17805>
   581fb:      	cmpq	$0x0, 0x1b6a5(%rip)     # 0x738a8 <g.3>
   58203:      	leaq	0x28(%rsp), %r8
   58208:      	leaq	0x1b5b9(%rip), %r9      # 0x737c8 <native_roots.0>
   5820f:      	je	0x6e9c5 <f.2+0x17805>
   58215:      	movq	%rax, %r15
   58218:      	addq	%rbp, %r15
   5821b:      	cmpq	$0xd, %r14
   5821f:      	ja	0x59075 <f.2+0x1eb5>
   58225:      	leaq	0x20(%rsp), %rdi
   5822a:      	jmp	0x59107 <f.2+0x1f47>
   5822f:      	leaq	-0xc(%r14), %r15
   58233:      	movq	$0x0, 0x50(%rsp)
   5823c:      	movq	$0x3, 0x38(%rsp)
   58245:      	xorl	%edi, %edi
   58247:      	movq	%r15, %rsi
   5824a:      	callq	0x6e9d0 <f.3>
   5824f:      	subq	$0x8, %rsp
   58253:      	cmpb	$0x0, 0x1b656(%rip)     # 0x738b0 <g.4>
   5825a:      	je	0x6e9c5 <f.2+0x17805>
   58260:      	cmpq	$0x0, 0x1b640(%rip)     # 0x738a8 <g.3>
   58268:      	je	0x6e9c5 <f.2+0x17805>
   5826e:      	movq	%rax, %rbp
   58271:      	leaq	-0xd(%r14), %rsi
   58275:      	movq	$0x0, 0x50(%rsp)
   5827e:      	movq	$0x3, 0x38(%rsp)
   58287:      	xorl	%edi, %edi
   58289:      	callq	0x6e9d0 <f.3>
   5828e:      	subq	$0x8, %rsp
   58292:      	cmpb	$0x0, 0x1b617(%rip)     # 0x738b0 <g.4>
   58299:      	je	0x6e9c5 <f.2+0x17805>
   5829f:      	cmpq	$0x0, 0x1b601(%rip)     # 0x738a8 <g.3>
   582a7:      	leaq	0x28(%rsp), %r8
   582ac:      	leaq	0x1b515(%rip), %r9      # 0x737c8 <native_roots.0>
   582b3:      	je	0x6e9c5 <f.2+0x17805>
   582b9:      	movq	%rax, %r13
   582bc:      	addq	%rbp, %r13
   582bf:      	cmpq	$0xd, %r14
   582c3:      	ja	0x59325 <f.2+0x2165>
   582c9:      	leaq	0x20(%rsp), %rdi
   582ce:      	jmp	0x593b7 <f.2+0x21f7>
   582d3:      	leaq	-0xc(%r14), %r15
   582d7:      	movq	$0x0, 0x50(%rsp)
   582e0:      	movq	$0x3, 0x38(%rsp)
   582e9:      	xorl	%edi, %edi
   582eb:      	movq	%r15, %rsi
   582ee:      	callq	0x6e9d0 <f.3>
   582f3:      	subq	$0x8, %rsp
   582f7:      	cmpb	$0x0, 0x1b5b2(%rip)     # 0x738b0 <g.4>
   582fe:      	je	0x6e9c5 <f.2+0x17805>
   58304:      	cmpq	$0x0, 0x1b59c(%rip)     # 0x738a8 <g.3>
   5830c:      	je	0x6e9c5 <f.2+0x17805>
   58312:      	movq	%rax, %rbp
   58315:      	leaq	-0xd(%r14), %rsi
   58319:      	movq	$0x0, 0x50(%rsp)
   58322:      	movq	$0x3, 0x38(%rsp)
   5832b:      	xorl	%edi, %edi
   5832d:      	callq	0x6e9d0 <f.3>
   58332:      	subq	$0x8, %rsp
   58336:      	cmpb	$0x0, 0x1b573(%rip)     # 0x738b0 <g.4>
   5833d:      	je	0x6e9c5 <f.2+0x17805>
   58343:      	cmpq	$0x0, 0x1b55d(%rip)     # 0x738a8 <g.3>
   5834b:      	je	0x6e9c5 <f.2+0x17805>
   58351:      	movq	%rax, %r13
   58354:      	addq	%rbp, %r13
   58357:      	cmpq	$0xd, %r14
   5835b:      	ja	0x5949b <f.2+0x22db>
   58361:      	leaq	0x28(%rsp), %r8
   58366:      	leaq	0x20(%rsp), %rdi
   5836b:      	leaq	0x1b456(%rip), %r9      # 0x737c8 <native_roots.0>
   58372:      	movq	0x10(%rsp), %rax
   58377:      	jmp	0x59532 <f.2+0x2372>
   5837c:      	leaq	(%r14,%r15), %r13
   58380:      	addq	$-0xa, %r13
   58384:      	movl	$0x1, %eax
   58389:      	leaq	(%r14,%rax), %r15
   5838d:      	addq	$-0xb, %r15
   58391:      	jmp	0x57874 <f.2+0x6b4>
   58396:      	leaq	-0xc(%r14), %rsi
   5839a:      	movq	$0x0, 0x50(%rsp)
   583a3:      	movq	$0x3, 0x38(%rsp)
   583ac:      	xorl	%edi, %edi
   583ae:      	callq	0x6e9d0 <f.3>
   583b3:      	subq	$0x8, %rsp
   583b7:      	cmpb	$0x0, 0x1b4f2(%rip)     # 0x738b0 <g.4>
   583be:      	je	0x6e9c5 <f.2+0x17805>
   583c4:      	cmpq	$0x0, 0x1b4dc(%rip)     # 0x738a8 <g.3>
   583cc:      	je	0x6e9c5 <f.2+0x17805>
   583d2:      	movq	%rax, %r13
   583d5:      	leaq	-0xd(%r14), %rsi
   583d9:      	movq	$0x0, 0x50(%rsp)
   583e2:      	movq	$0x3, 0x38(%rsp)
   583eb:      	xorl	%edi, %edi
   583ed:      	callq	0x6e9d0 <f.3>
   583f2:      	subq	$0x8, %rsp
   583f6:      	cmpb	$0x0, 0x1b4b3(%rip)     # 0x738b0 <g.4>
   583fd:      	je	0x6e9c5 <f.2+0x17805>
   58403:      	cmpq	$0x0, 0x1b49d(%rip)     # 0x738a8 <g.3>
   5840b:      	je	0x6e9c5 <f.2+0x17805>
   58411:      	movq	%rax, %rbp
   58414:      	addq	%r13, %rbp
   58417:      	cmpq	$0xd, %r14
   5841b:      	ja	0x59766 <f.2+0x25a6>
   58421:      	leaq	-0xc(%r14), %rax
   58425:      	addq	%rax, %rbp
   58428:      	addq	%r15, %rbp
   5842b:      	movq	%rbp, %r13
   5842e:      	movq	%rax, %rbp
   58431:      	jmp	0x5980f <f.2+0x264f>
   58436:      	leaq	-0xb(%r14), %r13
   5843a:      	leaq	-0xb(%r14), %rbp
   5843e:      	jmp	0x632e7 <f.2+0xc127>
   58443:      	movq	$0x0, 0x50(%rsp)
   5844c:      	movq	$0x3, 0x38(%rsp)
   58455:      	xorl	%edi, %edi
   58457:      	leaq	-0xc(%r14), %rsi
   5845b:      	callq	0x6e9d0 <f.3>
   58460:      	subq	$0x8, %rsp
   58464:      	cmpb	$0x0, 0x1b445(%rip)     # 0x738b0 <g.4>
   5846b:      	je	0x6e9c5 <f.2+0x17805>
   58471:      	cmpq	$0x0, 0x1b42f(%rip)     # 0x738a8 <g.3>
   58479:      	je	0x6e9c5 <f.2+0x17805>
   5847f:      	movq	%rax, %r13
   58482:      	leaq	-0xd(%r14), %rsi
   58486:      	movq	$0x0, 0x50(%rsp)
   5848f:      	movq	$0x3, 0x38(%rsp)
   58498:      	xorl	%edi, %edi
   5849a:      	callq	0x6e9d0 <f.3>
   5849f:      	subq	$0x8, %rsp
   584a3:      	cmpb	$0x0, 0x1b406(%rip)     # 0x738b0 <g.4>
   584aa:      	je	0x6e9c5 <f.2+0x17805>
   584b0:      	cmpq	$0x0, 0x1b3f0(%rip)     # 0x738a8 <g.3>
   584b8:      	leaq	0x28(%rsp), %r8
   584bd:      	leaq	0x20(%rsp), %rdi
   584c2:      	leaq	0x1b2ff(%rip), %r9      # 0x737c8 <native_roots.0>
   584c9:      	je	0x6e9c5 <f.2+0x17805>
   584cf:      	movq	%rax, %rbp
   584d2:      	addq	%r13, %rbp
   584d5:      	addq	%r15, %rbp
   584d8:      	cmpq	$0xb, %r14
   584dc:      	je	0x58501 <f.2+0x1341>
   584de:      	cmpq	$0xc, %r14
   584e2:      	jne	0x58518 <f.2+0x1358>
   584e4:      	cmpq	$0x0, 0x1b3bc(%rip)     # 0x738a8 <g.3>
   584ec:      	je	0x6e9c5 <f.2+0x17805>
   584f2:      	incq	%rbp
   584f5:      	leaq	-0xc(%r14), %r13
   584f9:      	movq	%rbp, %rax
   584fc:      	incq	%r13
   584ff:      	jmp	0x5850f <f.2+0x134f>
   58501:      	leaq	(%r14,%rbp), %rax
   58505:      	addq	$-0xa, %rax
   58509:      	movl	$0x1, %r13d
   5850f:      	leaq	-0xb(%r14), %r15
   58513:      	jmp	0x5c6be <f.2+0x54fe>
   58518:      	leaq	-0xc(%r14), %rsi
   5851c:      	movq	$0x0, 0x50(%rsp)
   58525:      	movq	$0x3, 0x38(%rsp)
   5852e:      	xorl	%edi, %edi
   58530:      	callq	0x6e9d0 <f.3>
   58535:      	subq	$0x8, %rsp
   58539:      	cmpb	$0x0, 0x1b370(%rip)     # 0x738b0 <g.4>
   58540:      	je	0x6e9c5 <f.2+0x17805>
   58546:      	cmpq	$0x0, 0x1b35a(%rip)     # 0x738a8 <g.3>
   5854e:      	je	0x6e9c5 <f.2+0x17805>
   58554:      	movq	%rax, %r13
   58557:      	leaq	-0xd(%r14), %rsi
   5855b:      	movq	$0x0, 0x50(%rsp)
   58564:      	movq	$0x3, 0x38(%rsp)
   5856d:      	xorl	%edi, %edi
   5856f:      	movq	%rsi, 0x10(%rsp)
   58574:      	callq	0x6e9d0 <f.3>
   58579:      	subq	$0x8, %rsp
   5857d:      	cmpb	$0x0, 0x1b32c(%rip)     # 0x738b0 <g.4>
   58584:      	je	0x6e9c5 <f.2+0x17805>
   5858a:      	cmpq	$0x0, 0x1b316(%rip)     # 0x738a8 <g.3>
   58592:      	je	0x6e9c5 <f.2+0x17805>
   58598:      	movq	%rax, %r15
   5859b:      	addq	%r13, %r15
   5859e:      	cmpq	$0xd, %r14
   585a2:      	ja	0x5960d <f.2+0x244d>
   585a8:      	leaq	-0xc(%r14), %r13
   585ac:      	addq	%r13, %r15
   585af:      	addq	%rbp, %r15
   585b2:      	movq	%r15, %rax
   585b5:      	jmp	0x596af <f.2+0x24ef>
   585ba:      	incq	%rbp
   585bd:      	leaq	(%r14,%rbp), %r12
   585c1:      	addq	$-0xb, %r12
   585c5:      	cmpq	$0xb, %r14
   585c9:      	je	0x5c40c <f.2+0x524c>
   585cf:      	movl	$0x1, %esi
   585d4:      	cmpq	$0xc, %r14
   585d8:      	je	0x59bf1 <f.2+0x2a31>
   585de:      	movq	%r14, %rsi
   585e1:      	subq	$0xd, %rsi
   585e5:      	jbe	0x59bee <f.2+0x2a2e>
   585eb:      	movq	%r12, 0x10(%rsp)
   585f0:      	jmp	0x59d28 <f.2+0x2b68>
   585f5:      	incq	%rbp
   585f8:      	leaq	(%r14,%rbp), %r12
   585fc:      	addq	$-0xb, %r12
   58600:      	cmpq	$0xb, %r14
   58604:      	je	0x5c4c8 <f.2+0x5308>
   5860a:      	movl	$0x1, %r13d
   58610:      	cmpq	$0xc, %r14
   58614:      	je	0x59bfd <f.2+0x2a3d>
   5861a:      	movq	%r14, %r13
   5861d:      	subq	$0xd, %r13
   58621:      	jbe	0x59bfa <f.2+0x2a3a>
   58627:      	movq	%rcx, 0x10(%rsp)
   5862c:      	jmp	0x59f02 <f.2+0x2d42>
   58631:      	movq	$0x0, 0x50(%rsp)
   5863a:      	movq	$0x3, 0x38(%rsp)
   58643:      	xorl	%edi, %edi
   58645:      	leaq	-0xc(%r14), %rsi
   58649:      	callq	0x6e9d0 <f.3>
   5864e:      	subq	$0x8, %rsp
   58652:      	cmpb	$0x0, 0x1b257(%rip)     # 0x738b0 <g.4>
   58659:      	je	0x6e9c5 <f.2+0x17805>
   5865f:      	cmpq	$0x0, 0x1b241(%rip)     # 0x738a8 <g.3>
   58667:      	je	0x6e9c5 <f.2+0x17805>
   5866d:      	movq	%rax, %r13
   58670:      	leaq	-0xd(%r14), %rsi
   58674:      	movq	$0x0, 0x50(%rsp)
   5867d:      	movq	$0x3, 0x38(%rsp)
   58686:      	xorl	%edi, %edi
   58688:      	callq	0x6e9d0 <f.3>
   5868d:      	subq	$0x8, %rsp
   58691:      	cmpb	$0x0, 0x1b218(%rip)     # 0x738b0 <g.4>
   58698:      	je	0x6e9c5 <f.2+0x17805>
   5869e:      	cmpq	$0x0, 0x1b202(%rip)     # 0x738a8 <g.3>
   586a6:      	leaq	0x28(%rsp), %r8
   586ab:      	leaq	0x20(%rsp), %rdi
   586b0:      	leaq	0x1b111(%rip), %r9      # 0x737c8 <native_roots.0>
   586b7:      	je	0x6e9c5 <f.2+0x17805>
   586bd:      	movq	%rax, %rbp
   586c0:      	addq	%r13, %rbp
   586c3:      	addq	%r15, %rbp
   586c6:      	cmpq	$0xb, %r14
   586ca:      	je	0x586ef <f.2+0x152f>
   586cc:      	cmpq	$0xc, %r14
   586d0:      	jne	0x58706 <f.2+0x1546>
   586d2:      	cmpq	$0x0, 0x1b1ce(%rip)     # 0x738a8 <g.3>
   586da:      	je	0x6e9c5 <f.2+0x17805>
   586e0:      	incq	%rbp
   586e3:      	leaq	-0xc(%r14), %r15
   586e7:      	movq	%rbp, %rax
   586ea:      	incq	%r15
   586ed:      	jmp	0x586fd <f.2+0x153d>
   586ef:      	leaq	(%r14,%rbp), %rax
   586f3:      	addq	$-0xa, %rax
   586f7:      	movl	$0x1, %r15d
   586fd:      	leaq	-0xb(%r14), %r13
   58701:      	jmp	0x5c826 <f.2+0x5666>
   58706:      	leaq	-0xc(%r14), %rsi
   5870a:      	movq	$0x0, 0x50(%rsp)
   58713:      	movq	$0x3, 0x38(%rsp)
   5871c:      	xorl	%edi, %edi
   5871e:      	callq	0x6e9d0 <f.3>
   58723:      	subq	$0x8, %rsp
   58727:      	cmpb	$0x0, 0x1b182(%rip)     # 0x738b0 <g.4>
   5872e:      	je	0x6e9c5 <f.2+0x17805>
   58734:      	cmpq	$0x0, 0x1b16c(%rip)     # 0x738a8 <g.3>
   5873c:      	je	0x6e9c5 <f.2+0x17805>
   58742:      	movq	%rax, %r15
   58745:      	leaq	-0xd(%r14), %rsi
   58749:      	movq	$0x0, 0x50(%rsp)
   58752:      	movq	$0x3, 0x38(%rsp)
   5875b:      	xorl	%edi, %edi
   5875d:      	movq	%rsi, 0x10(%rsp)
   58762:      	callq	0x6e9d0 <f.3>
   58767:      	subq	$0x8, %rsp
   5876b:      	cmpb	$0x0, 0x1b13e(%rip)     # 0x738b0 <g.4>
   58772:      	je	0x6e9c5 <f.2+0x17805>
   58778:      	cmpq	$0x0, 0x1b128(%rip)     # 0x738a8 <g.3>
   58780:      	je	0x6e9c5 <f.2+0x17805>
   58786:      	movq	%rax, %r13
   58789:      	addq	%r15, %r13
   5878c:      	cmpq	$0xd, %r14
   58790:      	ja	0x598b7 <f.2+0x26f7>
   58796:      	leaq	-0xc(%r14), %r15
   5879a:      	addq	%r15, %r13
   5879d:      	addq	%rbp, %r13
   587a0:      	movq	%r13, %rax
   587a3:      	jmp	0x59959 <f.2+0x2799>
   587a8:      	movq	$0x0, 0x50(%rsp)
   587b1:      	movq	$0x3, 0x38(%rsp)
   587ba:      	xorl	%edi, %edi
   587bc:      	leaq	-0xc(%r14), %rsi
   587c0:      	callq	0x6e9d0 <f.3>
   587c5:      	subq	$0x8, %rsp
   587c9:      	cmpb	$0x0, 0x1b0e0(%rip)     # 0x738b0 <g.4>
   587d0:      	je	0x6e9c5 <f.2+0x17805>
   587d6:      	cmpq	$0x0, 0x1b0ca(%rip)     # 0x738a8 <g.3>
   587de:      	je	0x6e9c5 <f.2+0x17805>
   587e4:      	movq	%rax, %r15
   587e7:      	leaq	-0xd(%r14), %rsi
   587eb:      	movq	$0x0, 0x50(%rsp)
   587f4:      	movq	$0x3, 0x38(%rsp)
   587fd:      	xorl	%edi, %edi
   587ff:      	callq	0x6e9d0 <f.3>
   58804:      	subq	$0x8, %rsp
   58808:      	cmpb	$0x0, 0x1b0a1(%rip)     # 0x738b0 <g.4>
   5880f:      	je	0x6e9c5 <f.2+0x17805>
   58815:      	cmpq	$0x0, 0x1b08b(%rip)     # 0x738a8 <g.3>
   5881d:      	leaq	0x28(%rsp), %r8
   58822:      	leaq	0x20(%rsp), %rdi
   58827:      	leaq	0x1af9a(%rip), %r9      # 0x737c8 <native_roots.0>
   5882e:      	je	0x6e9c5 <f.2+0x17805>
   58834:      	movq	%rax, %r13
   58837:      	addq	%r15, %r13
   5883a:      	addq	%rbp, %r13
   5883d:      	addq	%r12, %r13
   58840:      	movq	%r14, %r15
   58843:      	subq	$0xb, %r15
   58847:      	jbe	0x58073 <f.2+0xeb3>
   5884d:      	movq	$0x0, 0x50(%rsp)
   58856:      	movq	$0x3, 0x38(%rsp)
   5885f:      	xorl	%edi, %edi
   58861:      	movq	%r15, %rsi
   58864:      	callq	0x6e9d0 <f.3>
   58869:      	subq	$0x8, %rsp
   5886d:      	cmpb	$0x0, 0x1b03c(%rip)     # 0x738b0 <g.4>
   58874:      	je	0x6e9c5 <f.2+0x17805>
   5887a:      	cmpq	$0x0, 0x1b026(%rip)     # 0x738a8 <g.3>
   58882:      	leaq	-0xc(%r14), %rsi
   58886:      	je	0x6e9c5 <f.2+0x17805>
   5888c:      	movq	%rax, %r12
   5888f:      	movq	$0x0, 0x50(%rsp)
   58898:      	movq	$0x3, 0x38(%rsp)
   588a1:      	xorl	%edi, %edi
   588a3:      	callq	0x6e9d0 <f.3>
   588a8:      	subq	$0x8, %rsp
   588ac:      	cmpb	$0x0, 0x1affd(%rip)     # 0x738b0 <g.4>
   588b3:      	je	0x6e9c5 <f.2+0x17805>
   588b9:      	cmpq	$0x0, 0x1afe7(%rip)     # 0x738a8 <g.3>
   588c1:      	je	0x6e9c5 <f.2+0x17805>
   588c7:      	movq	%rax, %rbp
   588ca:      	addq	%r12, %rbp
   588cd:      	cmpq	$0xc, %r14
   588d1:      	jne	0x58f3c <f.2+0x1d7c>
   588d7:      	addq	%rbp, %r15
   588da:      	movl	$0x1, %r12d
   588e0:      	xorl	%eax, %eax
   588e2:      	leaq	0x28(%rsp), %r8
   588e7:      	leaq	0x20(%rsp), %rdi
   588ec:      	leaq	0x1aed5(%rip), %r9      # 0x737c8 <native_roots.0>
   588f3:      	addq	%rax, %r12
   588f6:      	jmp	0x5808a <f.2+0xeca>
   588fb:      	leaq	-0xc(%r14), %rbp
   588ff:      	movq	$0x0, 0x50(%rsp)
   58908:      	movq	$0x3, 0x38(%rsp)
   58911:      	xorl	%edi, %edi
   58913:      	movq	%rbp, %rsi
   58916:      	callq	0x6e9d0 <f.3>
   5891b:      	subq	$0x8, %rsp
   5891f:      	cmpb	$0x0, 0x1af8a(%rip)     # 0x738b0 <g.4>
   58926:      	je	0x6e9c5 <f.2+0x17805>
   5892c:      	cmpq	$0x0, 0x1af74(%rip)     # 0x738a8 <g.3>
   58934:      	je	0x6e9c5 <f.2+0x17805>
   5893a:      	movq	%rax, %r12
   5893d:      	leaq	-0xd(%r14), %rsi
   58941:      	movq	$0x0, 0x50(%rsp)
   5894a:      	movq	$0x3, 0x38(%rsp)
   58953:      	xorl	%edi, %edi
   58955:      	callq	0x6e9d0 <f.3>
   5895a:      	subq	$0x8, %rsp
   5895e:      	cmpb	$0x0, 0x1af4b(%rip)     # 0x738b0 <g.4>
   58965:      	je	0x6e9c5 <f.2+0x17805>
   5896b:      	cmpq	$0x0, 0x1af35(%rip)     # 0x738a8 <g.3>
   58973:      	je	0x6e9c5 <f.2+0x17805>
   58979:      	movq	%rax, %r13
   5897c:      	addq	%r12, %r13
   5897f:      	cmpq	$0xd, %r14
   58983:      	ja	0x59fb1 <f.2+0x2df1>
   58989:      	leaq	0x28(%rsp), %r8
   5898e:      	leaq	0x20(%rsp), %rdi
   58993:      	leaq	0x1ae2e(%rip), %r9      # 0x737c8 <native_roots.0>
   5899a:      	movq	0x18(%rsp), %r12
   5899f:      	addq	%r13, %rbp
   589a2:      	jmp	0x5a04b <f.2+0x2e8b>
   589a7:      	movq	%rax, 0x10(%rsp)
   589ac:      	movq	$0x0, 0x50(%rsp)
   589b5:      	movq	$0x3, 0x38(%rsp)
   589be:      	xorl	%edi, %edi
   589c0:      	movq	%rbp, %rsi
   589c3:      	callq	0x6e9d0 <f.3>
   589c8:      	subq	$0x8, %rsp
   589cc:      	cmpb	$0x0, 0x1aedd(%rip)     # 0x738b0 <g.4>
   589d3:      	je	0x6e9c5 <f.2+0x17805>
   589d9:      	movq	%rax, 0x18(%rsp)
   589de:      	cmpq	$0x0, 0x1aec2(%rip)     # 0x738a8 <g.3>
   589e6:      	je	0x6e9c5 <f.2+0x17805>
   589ec:      	leaq	-0xd(%r14), %r12
   589f0:      	movq	$0x0, 0x50(%rsp)
   589f9:      	movq	$0x3, 0x38(%rsp)
   58a02:      	xorl	%edi, %edi
   58a04:      	movq	%r12, %rsi
   58a07:      	callq	0x6e9d0 <f.3>
   58a0c:      	subq	$0x8, %rsp
   58a10:      	cmpb	$0x0, 0x1ae99(%rip)     # 0x738b0 <g.4>
   58a17:      	je	0x6e9c5 <f.2+0x17805>
   58a1d:      	cmpq	$0x0, 0x1ae83(%rip)     # 0x738a8 <g.3>
   58a25:      	je	0x6e9c5 <f.2+0x17805>
   58a2b:      	movq	%rax, %r13
   58a2e:      	movq	$0x0, 0x50(%rsp)
   58a37:      	movq	$0x3, 0x38(%rsp)
   58a40:      	xorl	%edi, %edi
   58a42:      	movq	%rbp, %rsi
   58a45:      	callq	0x6e9d0 <f.3>
   58a4a:      	subq	$0x8, %rsp
   58a4e:      	cmpb	$0x0, 0x1ae5b(%rip)     # 0x738b0 <g.4>
   58a55:      	je	0x6e9c5 <f.2+0x17805>
   58a5b:      	movq	%rax, 0x58(%rsp)
   58a60:      	cmpq	$0x0, 0x1ae40(%rip)     # 0x738a8 <g.3>
   58a68:      	je	0x6e9c5 <f.2+0x17805>
   58a6e:      	movq	$0x0, 0x50(%rsp)
   58a77:      	movq	$0x3, 0x38(%rsp)
   58a80:      	xorl	%edi, %edi
   58a82:      	movq	%r12, %rsi
   58a85:      	callq	0x6e9d0 <f.3>
   58a8a:      	subq	$0x8, %rsp
   58a8e:      	cmpb	$0x0, 0x1ae1b(%rip)     # 0x738b0 <g.4>
   58a95:      	je	0x6e9c5 <f.2+0x17805>
   58a9b:      	movq	%rax, %r12
   58a9e:      	cmpq	$0x0, 0x1ae02(%rip)     # 0x738a8 <g.3>
   58aa6:      	movq	0x10(%rsp), %rax
   58aab:      	je	0x6e9c5 <f.2+0x17805>
   58ab1:      	addq	0x18(%rsp), %r13
   58ab6:      	addq	%rax, %r13
   58ab9:      	addq	0x58(%rsp), %r12
   58abe:      	cmpq	$0xd, %r14
   58ac2:      	ja	0x5a4df <f.2+0x331f>
   58ac8:      	addq	%rbp, %r12
   58acb:      	addq	%r13, %r12
   58ace:      	movq	$0x0, 0x50(%rsp)
   58ad7:      	movq	$0x3, 0x38(%rsp)
   58ae0:      	xorl	%edi, %edi
   58ae2:      	movq	%rbp, %rsi
   58ae5:      	callq	0x6e9d0 <f.3>
   58aea:      	subq	$0x8, %rsp
   58aee:      	cmpb	$0x0, 0x1adbb(%rip)     # 0x738b0 <g.4>
   58af5:      	je	0x6e9c5 <f.2+0x17805>
   58afb:      	movq	%r12, 0x10(%rsp)
   58b00:      	cmpq	$0x0, 0x1ada0(%rip)     # 0x738a8 <g.3>
   58b08:      	je	0x6e9c5 <f.2+0x17805>
   58b0e:      	movq	%rax, %r13
   58b11:      	leaq	-0xd(%r14), %rsi
   58b15:      	movq	$0x0, 0x50(%rsp)
   58b1e:      	movq	$0x3, 0x38(%rsp)
   58b27:      	xorl	%edi, %edi
   58b29:      	callq	0x6e9d0 <f.3>
   58b2e:      	subq	$0x8, %rsp
   58b32:      	cmpb	$0x0, 0x1ad77(%rip)     # 0x738b0 <g.4>
   58b39:      	je	0x6e9c5 <f.2+0x17805>
   58b3f:      	cmpq	$0x0, 0x1ad61(%rip)     # 0x738a8 <g.3>
   58b47:      	je	0x6e9c5 <f.2+0x17805>
   58b4d:      	movq	%rax, %r12
   58b50:      	addq	%r13, %r12
   58b53:      	cmpq	$0xd, %r14
   58b57:      	jne	0x58c34 <f.2+0x1a74>
   58b5d:      	addq	%r12, %rbp
   58b60:      	movl	$0x1, %r13d
   58b66:      	xorl	%eax, %eax
   58b68:      	leaq	0x28(%rsp), %r8
   58b6d:      	leaq	0x20(%rsp), %rdi
   58b72:      	leaq	0x1ac4f(%rip), %r9      # 0x737c8 <native_roots.0>
   58b79:      	jmp	0x58d65 <f.2+0x1ba5>
   58b7e:      	incq	%rbp
   58b81:      	leaq	-0xb(%r14), %rcx
   58b85:      	jmp	0x5bb77 <f.2+0x49b7>
   58b8a:      	leaq	-0xd(%r14), %rsi
   58b8e:      	movq	$0x0, 0x50(%rsp)
   58b97:      	movq	$0x3, 0x38(%rsp)
   58ba0:      	xorl	%edi, %edi
   58ba2:      	callq	0x6e9d0 <f.3>
   58ba7:      	subq	$0x8, %rsp
   58bab:      	cmpb	$0x0, 0x1acfe(%rip)     # 0x738b0 <g.4>
   58bb2:      	je	0x6e9c5 <f.2+0x17805>
   58bb8:      	cmpq	$0x0, 0x1ace8(%rip)     # 0x738a8 <g.3>
   58bc0:      	je	0x6e9c5 <f.2+0x17805>
   58bc6:      	movq	%rax, %rbp
   58bc9:      	leaq	-0xe(%r14), %rsi
   58bcd:      	movq	$0x0, 0x50(%rsp)
   58bd6:      	movq	$0x3, 0x38(%rsp)
   58bdf:      	xorl	%edi, %edi
   58be1:      	callq	0x6e9d0 <f.3>
   58be6:      	subq	$0x8, %rsp
   58bea:      	cmpb	$0x0, 0x1acbf(%rip)     # 0x738b0 <g.4>
   58bf1:      	je	0x6e9c5 <f.2+0x17805>
   58bf7:      	cmpq	$0x0, 0x1aca9(%rip)     # 0x738a8 <g.3>
   58bff:      	leaq	0x20(%rsp), %rdi
   58c04:      	je	0x6e9c5 <f.2+0x17805>
   58c0a:      	movq	%rax, %r13
   58c0d:      	addq	%rbp, %r13
   58c10:      	cmpq	$0xe, %r14
   58c14:      	ja	0x5a59e <f.2+0x33de>
   58c1a:      	leaq	0x28(%rsp), %r8
   58c1f:      	leaq	0x1aba2(%rip), %r9      # 0x737c8 <native_roots.0>
   58c26:      	movq	0x10(%rsp), %rax
   58c2b:      	leaq	-0xd(%r14), %rcx
   58c2f:      	jmp	0x5a635 <f.2+0x3475>
   58c34:      	movq	$0x0, 0x50(%rsp)
   58c3d:      	movq	$0x3, 0x38(%rsp)
   58c46:      	xorl	%edi, %edi
   58c48:      	leaq	-0xd(%r14), %rsi
   58c4c:      	callq	0x6e9d0 <f.3>
   58c51:      	subq	$0x8, %rsp
   58c55:      	cmpb	$0x0, 0x1ac54(%rip)     # 0x738b0 <g.4>
   58c5c:      	je	0x6e9c5 <f.2+0x17805>
   58c62:      	movq	%rax, 0x18(%rsp)
   58c67:      	cmpq	$0x0, 0x1ac39(%rip)     # 0x738a8 <g.3>
   58c6f:      	je	0x6e9c5 <f.2+0x17805>
   58c75:      	leaq	-0xe(%r14), %r13
   58c79:      	movq	$0x0, 0x50(%rsp)
   58c82:      	movq	$0x3, 0x38(%rsp)
   58c8b:      	xorl	%edi, %edi
   58c8d:      	movq	%r13, %rsi
   58c90:      	callq	0x6e9d0 <f.3>
   58c95:      	subq	$0x8, %rsp
   58c99:      	cmpb	$0x0, 0x1ac10(%rip)     # 0x738b0 <g.4>
   58ca0:      	je	0x6e9c5 <f.2+0x17805>
   58ca6:      	cmpq	$0x0, 0x1abfa(%rip)     # 0x738a8 <g.3>
   58cae:      	je	0x6e9c5 <f.2+0x17805>
   58cb4:      	movq	%rax, %rbp
   58cb7:      	movq	$0x0, 0x50(%rsp)
   58cc0:      	movq	$0x3, 0x38(%rsp)
   58cc9:      	xorl	%edi, %edi
   58ccb:      	leaq	-0xd(%r14), %rsi
   58ccf:      	callq	0x6e9d0 <f.3>
   58cd4:      	subq	$0x8, %rsp
   58cd8:      	cmpb	$0x0, 0x1abd1(%rip)     # 0x738b0 <g.4>
   58cdf:      	je	0x6e9c5 <f.2+0x17805>
   58ce5:      	movq	%rax, 0x58(%rsp)
   58cea:      	cmpq	$0x0, 0x1abb6(%rip)     # 0x738a8 <g.3>
   58cf2:      	je	0x6e9c5 <f.2+0x17805>
   58cf8:      	movq	$0x0, 0x50(%rsp)
   58d01:      	movq	$0x3, 0x38(%rsp)
   58d0a:      	xorl	%edi, %edi
   58d0c:      	movq	%r13, %rsi
   58d0f:      	callq	0x6e9d0 <f.3>
   58d14:      	subq	$0x8, %rsp
   58d18:      	cmpb	$0x0, 0x1ab91(%rip)     # 0x738b0 <g.4>
   58d1f:      	je	0x6e9c5 <f.2+0x17805>
   58d25:      	movq	%rax, %r13
   58d28:      	cmpq	$0x0, 0x1ab78(%rip)     # 0x738a8 <g.3>
   58d30:      	movq	0x58(%rsp), %rax
   58d35:      	je	0x6e9c5 <f.2+0x17805>
   58d3b:      	addq	0x18(%rsp), %rbp
   58d40:      	addq	%r12, %rbp
   58d43:      	addq	%rax, %r13
   58d46:      	cmpq	$0xf, %r14
   58d4a:      	jae	0x5b004 <f.2+0x3e44>
   58d50:      	leaq	0x28(%rsp), %r8
   58d55:      	leaq	0x20(%rsp), %rdi
   58d5a:      	leaq	0x1aa67(%rip), %r9      # 0x737c8 <native_roots.0>
   58d61:      	leaq	-0xd(%r14), %rax
   58d65:      	addq	%rax, %r13
   58d68:      	jmp	0x5b088 <f.2+0x3ec8>
   58d6d:      	movq	%rax, 0x10(%rsp)
   58d72:      	movq	$0x0, 0x50(%rsp)
   58d7b:      	movq	$0x3, 0x38(%rsp)
   58d84:      	xorl	%edi, %edi
   58d86:      	movq	%rbp, %rsi
   58d89:      	callq	0x6e9d0 <f.3>
   58d8e:      	subq	$0x8, %rsp
   58d92:      	cmpb	$0x0, 0x1ab17(%rip)     # 0x738b0 <g.4>
   58d99:      	je	0x6e9c5 <f.2+0x17805>
   58d9f:      	movq	%rax, 0x18(%rsp)
   58da4:      	cmpq	$0x0, 0x1aafc(%rip)     # 0x738a8 <g.3>
   58dac:      	je	0x6e9c5 <f.2+0x17805>
   58db2:      	leaq	-0xd(%r14), %rsi
   58db6:      	movq	$0x0, 0x50(%rsp)
   58dbf:      	movq	$0x3, 0x38(%rsp)
   58dc8:      	xorl	%edi, %edi
   58dca:      	callq	0x6e9d0 <f.3>
   58dcf:      	subq	$0x8, %rsp
   58dd3:      	cmpb	$0x0, 0x1aad6(%rip)     # 0x738b0 <g.4>
   58dda:      	je	0x6e9c5 <f.2+0x17805>
   58de0:      	cmpq	$0x0, 0x1aac0(%rip)     # 0x738a8 <g.3>
   58de8:      	je	0x6e9c5 <f.2+0x17805>
   58dee:      	movq	%rax, %r12
   58df1:      	movq	$0x0, 0x50(%rsp)
   58dfa:      	movq	$0x3, 0x38(%rsp)
   58e03:      	xorl	%edi, %edi
   58e05:      	movq	%rbp, %rsi
   58e08:      	callq	0x6e9d0 <f.3>
   58e0d:      	subq	$0x8, %rsp
   58e11:      	cmpb	$0x0, 0x1aa98(%rip)     # 0x738b0 <g.4>
   58e18:      	je	0x6e9c5 <f.2+0x17805>
   58e1e:      	cmpq	$0x0, 0x1aa82(%rip)     # 0x738a8 <g.3>
   58e26:      	je	0x6e9c5 <f.2+0x17805>
   58e2c:      	movq	%rax, %r13
   58e2f:      	movq	$0x0, 0x50(%rsp)
   58e38:      	movq	$0x3, 0x38(%rsp)
   58e41:      	xorl	%edi, %edi
   58e43:      	leaq	-0xd(%r14), %rsi
   58e47:      	callq	0x6e9d0 <f.3>
   58e4c:      	subq	$0x8, %rsp
   58e50:      	cmpb	$0x0, 0x1aa59(%rip)     # 0x738b0 <g.4>
   58e57:      	je	0x6e9c5 <f.2+0x17805>
   58e5d:      	cmpq	$0x0, 0x1aa43(%rip)     # 0x738a8 <g.3>
   58e65:      	je	0x6e9c5 <f.2+0x17805>
   58e6b:      	addq	0x18(%rsp), %r12
   58e70:      	addq	0x10(%rsp), %r12
   58e75:      	addq	%r13, %rax
   58e78:      	cmpq	$0xd, %r14
   58e7c:      	ja	0x5b43e <f.2+0x427e>
   58e82:      	addq	%rbp, %rax
   58e85:      	addq	%r12, %rax
   58e88:      	movq	%rax, 0x10(%rsp)
   58e8d:      	movq	$0x0, 0x50(%rsp)
   58e96:      	movq	$0x3, 0x38(%rsp)
   58e9f:      	xorl	%edi, %edi
   58ea1:      	movq	%rbp, %rsi
   58ea4:      	callq	0x6e9d0 <f.3>
   58ea9:      	subq	$0x8, %rsp
   58ead:      	cmpb	$0x0, 0x1a9fc(%rip)     # 0x738b0 <g.4>
   58eb4:      	je	0x6e9c5 <f.2+0x17805>
   58eba:      	cmpq	$0x0, 0x1a9e6(%rip)     # 0x738a8 <g.3>
   58ec2:      	je	0x6e9c5 <f.2+0x17805>
   58ec8:      	movq	%rax, %r13
   58ecb:      	leaq	-0xd(%r14), %rsi
   58ecf:      	movq	$0x0, 0x50(%rsp)
   58ed8:      	movq	$0x3, 0x38(%rsp)
   58ee1:      	xorl	%edi, %edi
   58ee3:      	callq	0x6e9d0 <f.3>
   58ee8:      	subq	$0x8, %rsp
   58eec:      	cmpb	$0x0, 0x1a9bd(%rip)     # 0x738b0 <g.4>
   58ef3:      	je	0x6e9c5 <f.2+0x17805>
   58ef9:      	cmpq	$0x0, 0x1a9a7(%rip)     # 0x738a8 <g.3>
   58f01:      	leaq	0x28(%rsp), %r8
   58f06:      	leaq	0x20(%rsp), %rdi
   58f0b:      	leaq	0x1a8b6(%rip), %r9      # 0x737c8 <native_roots.0>
   58f12:      	je	0x6e9c5 <f.2+0x17805>
   58f18:      	movq	%rax, %r12
   58f1b:      	addq	%r13, %r12
   58f1e:      	cmpq	$0xd, %r14
   58f22:      	jne	0x59ab5 <f.2+0x28f5>
   58f28:      	addq	%r12, %rbp
   58f2b:      	movl	$0x1, %ecx
   58f30:      	xorl	%eax, %eax
   58f32:      	movq	0x10(%rsp), %r13
   58f37:      	jmp	0x59be6 <f.2+0x2a26>
   58f3c:      	movq	$0x0, 0x50(%rsp)
   58f45:      	movq	$0x3, 0x38(%rsp)
   58f4e:      	xorl	%edi, %edi
   58f50:      	leaq	-0xc(%r14), %rsi
   58f54:      	callq	0x6e9d0 <f.3>
   58f59:      	subq	$0x8, %rsp
   58f5d:      	cmpb	$0x0, 0x1a94c(%rip)     # 0x738b0 <g.4>
   58f64:      	je	0x6e9c5 <f.2+0x17805>
   58f6a:      	movq	%rax, 0x10(%rsp)
   58f6f:      	cmpq	$0x0, 0x1a931(%rip)     # 0x738a8 <g.3>
   58f77:      	je	0x6e9c5 <f.2+0x17805>
   58f7d:      	leaq	-0xd(%r14), %r12
   58f81:      	movq	$0x0, 0x50(%rsp)
   58f8a:      	movq	$0x3, 0x38(%rsp)
   58f93:      	xorl	%edi, %edi
   58f95:      	movq	%r12, %rsi
   58f98:      	callq	0x6e9d0 <f.3>
   58f9d:      	subq	$0x8, %rsp
   58fa1:      	cmpb	$0x0, 0x1a908(%rip)     # 0x738b0 <g.4>
   58fa8:      	je	0x6e9c5 <f.2+0x17805>
   58fae:      	cmpq	$0x0, 0x1a8f2(%rip)     # 0x738a8 <g.3>
   58fb6:      	je	0x6e9c5 <f.2+0x17805>
   58fbc:      	movq	%rax, %r15
   58fbf:      	movq	$0x0, 0x50(%rsp)
   58fc8:      	movq	$0x3, 0x38(%rsp)
   58fd1:      	xorl	%edi, %edi
   58fd3:      	leaq	-0xc(%r14), %rsi
   58fd7:      	callq	0x6e9d0 <f.3>
   58fdc:      	subq	$0x8, %rsp
   58fe0:      	cmpb	$0x0, 0x1a8c9(%rip)     # 0x738b0 <g.4>
   58fe7:      	je	0x6e9c5 <f.2+0x17805>
   58fed:      	movq	%rax, 0x18(%rsp)
   58ff2:      	cmpq	$0x0, 0x1a8ae(%rip)     # 0x738a8 <g.3>
   58ffa:      	je	0x6e9c5 <f.2+0x17805>
   59000:      	movq	$0x0, 0x50(%rsp)
   59009:      	movq	$0x3, 0x38(%rsp)
   59012:      	xorl	%edi, %edi
   59014:      	movq	%r12, %rsi
   59017:      	callq	0x6e9d0 <f.3>
   5901c:      	subq	$0x8, %rsp
   59020:      	cmpb	$0x0, 0x1a889(%rip)     # 0x738b0 <g.4>
   59027:      	je	0x6e9c5 <f.2+0x17805>
   5902d:      	movq	%rax, %r12
   59030:      	cmpq	$0x0, 0x1a870(%rip)     # 0x738a8 <g.3>
   59038:      	movq	0x18(%rsp), %rax
   5903d:      	je	0x6e9c5 <f.2+0x17805>
   59043:      	addq	0x10(%rsp), %r15
   59048:      	addq	%rbp, %r15
   5904b:      	addq	%rax, %r12
   5904e:      	cmpq	$0xe, %r14
   59052:      	jae	0x5b4f5 <f.2+0x4335>
   59058:      	leaq	0x28(%rsp), %r8
   5905d:      	leaq	0x20(%rsp), %rdi
   59062:      	leaq	0x1a75f(%rip), %r9      # 0x737c8 <native_roots.0>
   59069:      	leaq	-0xc(%r14), %rax
   5906d:      	addq	%rax, %r12
   59070:      	jmp	0x5808a <f.2+0xeca>
   59075:      	movq	$0x0, 0x50(%rsp)
   5907e:      	movq	$0x3, 0x38(%rsp)
   59087:      	xorl	%edi, %edi
   59089:      	leaq	-0xd(%r14), %rsi
   5908d:      	callq	0x6e9d0 <f.3>
   59092:      	subq	$0x8, %rsp
   59096:      	cmpb	$0x0, 0x1a813(%rip)     # 0x738b0 <g.4>
   5909d:      	je	0x6e9c5 <f.2+0x17805>
   590a3:      	cmpq	$0x0, 0x1a7fd(%rip)     # 0x738a8 <g.3>
   590ab:      	je	0x6e9c5 <f.2+0x17805>
   590b1:      	movq	%rax, %rbp
   590b4:      	leaq	-0xe(%r14), %rsi
   590b8:      	movq	$0x0, 0x50(%rsp)
   590c1:      	movq	$0x3, 0x38(%rsp)
   590ca:      	xorl	%edi, %edi
   590cc:      	callq	0x6e9d0 <f.3>
   590d1:      	subq	$0x8, %rsp
   590d5:      	cmpb	$0x0, 0x1a7d4(%rip)     # 0x738b0 <g.4>
   590dc:      	je	0x6e9c5 <f.2+0x17805>
   590e2:      	cmpq	$0x0, 0x1a7be(%rip)     # 0x738a8 <g.3>
   590ea:      	leaq	0x28(%rsp), %r8
   590ef:      	leaq	0x20(%rsp), %rdi
   590f4:      	leaq	0x1a6cd(%rip), %r9      # 0x737c8 <native_roots.0>
   590fb:      	je	0x6e9c5 <f.2+0x17805>
   59101:      	movq	%rax, %r13
   59104:      	addq	%rbp, %r13
   59107:      	addq	%r15, %r13
   5910a:      	cmpq	$0xc, %r14
   5910e:      	je	0x59123 <f.2+0x1f63>
   59110:      	cmpq	$0xd, %r14
   59114:      	jne	0x5913a <f.2+0x1f7a>
   59116:      	movl	$0x1, %r15d
   5911c:      	xorl	%ebp, %ebp
   5911e:      	jmp	0x59254 <f.2+0x2094>
   59123:      	leaq	(%r14,%r13), %rbp
   59127:      	addq	$-0xb, %rbp
   5912b:      	movl	$0x1, %r13d
   59131:      	leaq	-0xc(%r14), %r15
   59135:      	jmp	0x5cb8c <f.2+0x59cc>
   5913a:      	leaq	-0xd(%r14), %rbp
   5913e:      	movq	$0x0, 0x50(%rsp)
   59147:      	movq	$0x3, 0x38(%rsp)
   59150:      	xorl	%edi, %edi
   59152:      	movq	%rbp, %rsi
   59155:      	callq	0x6e9d0 <f.3>
   5915a:      	subq	$0x8, %rsp
   5915e:      	cmpb	$0x0, 0x1a74b(%rip)     # 0x738b0 <g.4>
   59165:      	je	0x6e9c5 <f.2+0x17805>
   5916b:      	movq	%rax, 0x18(%rsp)
   59170:      	cmpq	$0x0, 0x1a730(%rip)     # 0x738a8 <g.3>
   59178:      	je	0x6e9c5 <f.2+0x17805>
   5917e:      	leaq	-0xe(%r14), %rsi
   59182:      	movq	$0x0, 0x50(%rsp)
   5918b:      	movq	$0x3, 0x38(%rsp)
   59194:      	xorl	%edi, %edi
   59196:      	callq	0x6e9d0 <f.3>
   5919b:      	subq	$0x8, %rsp
   5919f:      	cmpb	$0x0, 0x1a70a(%rip)     # 0x738b0 <g.4>
   591a6:      	je	0x6e9c5 <f.2+0x17805>
   591ac:      	cmpq	$0x0, 0x1a6f4(%rip)     # 0x738a8 <g.3>
   591b4:      	leaq	0x28(%rsp), %r8
   591b9:      	leaq	0x20(%rsp), %rdi
   591be:      	leaq	0x1a603(%rip), %r9      # 0x737c8 <native_roots.0>
   591c5:      	je	0x6e9c5 <f.2+0x17805>
   591cb:      	movq	%rax, %r15
   591ce:      	addq	0x18(%rsp), %r15
   591d3:      	cmpq	$0xf, %r14
   591d7:      	jb	0x59254 <f.2+0x2094>
   591d9:      	movq	$0x0, 0x50(%rsp)
   591e2:      	movq	$0x3, 0x38(%rsp)
   591eb:      	xorl	%edi, %edi
   591ed:      	leaq	-0xe(%r14), %rsi
   591f1:      	callq	0x6e9d0 <f.3>
   591f6:      	subq	$0x8, %rsp
   591fa:      	cmpb	$0x0, 0x1a6af(%rip)     # 0x738b0 <g.4>
   59201:      	je	0x6e9c5 <f.2+0x17805>
   59207:      	movq	%rax, 0x18(%rsp)
   5920c:      	cmpq	$0x0, 0x1a694(%rip)     # 0x738a8 <g.3>
   59214:      	je	0x6e9c5 <f.2+0x17805>
   5921a:      	leaq	-0xf(%r14), %rsi
   5921e:      	movq	$0x0, 0x50(%rsp)
   59227:      	movq	$0x3, 0x38(%rsp)
   59230:      	xorl	%edi, %edi
   59232:      	callq	0x6e9d0 <f.3>
   59237:      	subq	$0x8, %rsp
   5923b:      	movq	%rax, %rbp
   5923e:      	addq	0x18(%rsp), %rbp
   59243:      	leaq	0x28(%rsp), %r8
   59248:      	leaq	0x20(%rsp), %rdi
   5924d:      	leaq	0x1a574(%rip), %r9      # 0x737c8 <native_roots.0>
   59254:      	cmpb	$0x0, 0x1a655(%rip)     # 0x738b0 <g.4>
   5925b:      	je	0x6e9c5 <f.2+0x17805>
   59261:      	cmpq	$0x0, 0x1a63f(%rip)     # 0x738a8 <g.3>
   59269:      	je	0x6e9c5 <f.2+0x17805>
   5926f:      	addq	%r15, %rbp
   59272:      	addq	%r13, %rbp
   59275:      	movq	%r14, %r13
   59278:      	subq	$0xd, %r13
   5927c:      	jbe	0x59319 <f.2+0x2159>
   59282:      	movq	$0x0, 0x50(%rsp)
   5928b:      	movq	$0x3, 0x38(%rsp)
   59294:      	xorl	%edi, %edi
   59296:      	movq	%r13, %rsi
   59299:      	callq	0x6e9d0 <f.3>
   5929e:      	subq	$0x8, %rsp
   592a2:      	cmpb	$0x0, 0x1a607(%rip)     # 0x738b0 <g.4>
   592a9:      	je	0x6e9c5 <f.2+0x17805>
   592af:      	cmpq	$0x0, 0x1a5f1(%rip)     # 0x738a8 <g.3>
   592b7:      	je	0x6e9c5 <f.2+0x17805>
   592bd:      	movq	%rax, %r15
   592c0:      	leaq	-0xe(%r14), %rsi
   592c4:      	movq	$0x0, 0x50(%rsp)
   592cd:      	movq	$0x3, 0x38(%rsp)
   592d6:      	xorl	%edi, %edi
   592d8:      	callq	0x6e9d0 <f.3>
   592dd:      	subq	$0x8, %rsp
   592e1:      	cmpb	$0x0, 0x1a5c8(%rip)     # 0x738b0 <g.4>
   592e8:      	je	0x6e9c5 <f.2+0x17805>
   592ee:      	cmpq	$0x0, 0x1a5b2(%rip)     # 0x738a8 <g.3>
   592f6:      	je	0x6e9c5 <f.2+0x17805>
   592fc:      	addq	%r15, %rax
   592ff:      	cmpq	$0xe, %r14
   59303:      	jne	0x5a9d1 <f.2+0x3811>
   59309:      	addq	%rax, %r13
   5930c:      	movl	$0x1, %r15d
   59312:      	xorl	%eax, %eax
   59314:      	jmp	0x5cb78 <f.2+0x59b8>
   59319:      	incq	%r13
   5931c:      	leaq	-0xc(%r14), %r15
   59320:      	jmp	0x5cb8c <f.2+0x59cc>
   59325:      	movq	$0x0, 0x50(%rsp)
   5932e:      	movq	$0x3, 0x38(%rsp)
   59337:      	xorl	%edi, %edi
   59339:      	leaq	-0xd(%r14), %rsi
   5933d:      	callq	0x6e9d0 <f.3>
   59342:      	subq	$0x8, %rsp
   59346:      	cmpb	$0x0, 0x1a563(%rip)     # 0x738b0 <g.4>
   5934d:      	je	0x6e9c5 <f.2+0x17805>
   59353:      	cmpq	$0x0, 0x1a54d(%rip)     # 0x738a8 <g.3>
   5935b:      	je	0x6e9c5 <f.2+0x17805>
   59361:      	movq	%rax, %rbp
   59364:      	leaq	-0xe(%r14), %rsi
   59368:      	movq	$0x0, 0x50(%rsp)
   59371:      	movq	$0x3, 0x38(%rsp)
   5937a:      	xorl	%edi, %edi
   5937c:      	callq	0x6e9d0 <f.3>
   59381:      	subq	$0x8, %rsp
   59385:      	cmpb	$0x0, 0x1a524(%rip)     # 0x738b0 <g.4>
   5938c:      	je	0x6e9c5 <f.2+0x17805>
   59392:      	cmpq	$0x0, 0x1a50e(%rip)     # 0x738a8 <g.3>
   5939a:      	leaq	0x28(%rsp), %r8
   5939f:      	leaq	0x20(%rsp), %rdi
   593a4:      	leaq	0x1a41d(%rip), %r9      # 0x737c8 <native_roots.0>
   593ab:      	je	0x6e9c5 <f.2+0x17805>
   593b1:      	movq	%rax, %r15
   593b4:      	addq	%rbp, %r15
   593b7:      	addq	%r13, %r15
   593ba:      	cmpq	$0xc, %r14
   593be:      	je	0x593d3 <f.2+0x2213>
   593c0:      	cmpq	$0xd, %r14
   593c4:      	jne	0x593ea <f.2+0x222a>
   593c6:      	movl	$0x1, %r13d
   593cc:      	xorl	%ebp, %ebp
   593ce:      	jmp	0x5a795 <f.2+0x35d5>
   593d3:      	leaq	(%r14,%r15), %rbp
   593d7:      	addq	$-0xb, %rbp
   593db:      	movl	$0x1, %r15d
   593e1:      	leaq	-0xc(%r14), %r13
   593e5:      	jmp	0x5d697 <f.2+0x64d7>
   593ea:      	leaq	-0xd(%r14), %rbp
   593ee:      	movq	$0x0, 0x50(%rsp)
   593f7:      	movq	$0x3, 0x38(%rsp)
   59400:      	xorl	%edi, %edi
   59402:      	movq	%rbp, %rsi
   59405:      	callq	0x6e9d0 <f.3>
   5940a:      	subq	$0x8, %rsp
   5940e:      	cmpb	$0x0, 0x1a49b(%rip)     # 0x738b0 <g.4>
   59415:      	je	0x6e9c5 <f.2+0x17805>
   5941b:      	movq	%rax, 0x18(%rsp)
   59420:      	cmpq	$0x0, 0x1a480(%rip)     # 0x738a8 <g.3>
   59428:      	je	0x6e9c5 <f.2+0x17805>
   5942e:      	leaq	-0xe(%r14), %rsi
   59432:      	movq	$0x0, 0x50(%rsp)
   5943b:      	movq	$0x3, 0x38(%rsp)
   59444:      	xorl	%edi, %edi
   59446:      	callq	0x6e9d0 <f.3>
   5944b:      	subq	$0x8, %rsp
   5944f:      	cmpb	$0x0, 0x1a45a(%rip)     # 0x738b0 <g.4>
   59456:      	je	0x6e9c5 <f.2+0x17805>
   5945c:      	cmpq	$0x0, 0x1a444(%rip)     # 0x738a8 <g.3>
   59464:      	leaq	0x20(%rsp), %rdi
   59469:      	je	0x6e9c5 <f.2+0x17805>
   5946f:      	movq	%rax, %r13
   59472:      	addq	0x18(%rsp), %r13
   59477:      	cmpq	$0xf, %r14
   5947b:      	jae	0x5a71a <f.2+0x355a>
   59481:      	leaq	0x28(%rsp), %r8
   59486:      	jmp	0x5a78e <f.2+0x35ce>
   5948b:      	incq	%r13
   5948e:      	leaq	(%r14,%r13), %rax
   59492:      	addq	$-0xc, %rax
   59496:      	jmp	0x5ee7a <f.2+0x7cba>
   5949b:      	movq	$0x0, 0x50(%rsp)
   594a4:      	movq	$0x3, 0x38(%rsp)
   594ad:      	xorl	%edi, %edi
   594af:      	leaq	-0xd(%r14), %rsi
   594b3:      	callq	0x6e9d0 <f.3>
   594b8:      	subq	$0x8, %rsp
   594bc:      	cmpb	$0x0, 0x1a3ed(%rip)     # 0x738b0 <g.4>
   594c3:      	je	0x6e9c5 <f.2+0x17805>
   594c9:      	cmpq	$0x0, 0x1a3d7(%rip)     # 0x738a8 <g.3>
   594d1:      	je	0x6e9c5 <f.2+0x17805>
   594d7:      	movq	%rax, %rbp
   594da:      	leaq	-0xe(%r14), %rsi
   594de:      	movq	$0x0, 0x50(%rsp)
   594e7:      	movq	$0x3, 0x38(%rsp)
   594f0:      	xorl	%edi, %edi
   594f2:      	callq	0x6e9d0 <f.3>
   594f7:      	subq	$0x8, %rsp
   594fb:      	cmpb	$0x0, 0x1a3ae(%rip)     # 0x738b0 <g.4>
   59502:      	je	0x6e9c5 <f.2+0x17805>
   59508:      	movq	%rax, %r15
   5950b:      	cmpq	$0x0, 0x1a395(%rip)     # 0x738a8 <g.3>
   59513:      	leaq	0x28(%rsp), %r8
   59518:      	leaq	0x20(%rsp), %rdi
   5951d:      	leaq	0x1a2a4(%rip), %r9      # 0x737c8 <native_roots.0>
   59524:      	movq	0x10(%rsp), %rax
   59529:      	je	0x6e9c5 <f.2+0x17805>
   5952f:      	addq	%rbp, %r15
   59532:      	addq	%r13, %r15
   59535:      	cmpq	$0xc, %r14
   59539:      	je	0x5954d <f.2+0x238d>
   5953b:      	cmpq	$0xd, %r14
   5953f:      	jne	0x59563 <f.2+0x23a3>
   59541:      	movl	$0x1, %ebp
   59546:      	xorl	%ecx, %ecx
   59548:      	jmp	0x5a8e2 <f.2+0x3722>
   5954d:      	leaq	(%r14,%r15), %rcx
   59551:      	addq	$-0xb, %rcx
   59555:      	movl	$0x1, %ebp
   5955a:      	leaq	-0xc(%r14), %r15
   5955e:      	jmp	0x5e1bd <f.2+0x6ffd>
   59563:      	leaq	-0xd(%r14), %rsi
   59567:      	movq	$0x0, 0x50(%rsp)
   59570:      	movq	$0x3, 0x38(%rsp)
   59579:      	xorl	%edi, %edi
   5957b:      	callq	0x6e9d0 <f.3>
   59580:      	subq	$0x8, %rsp
   59584:      	cmpb	$0x0, 0x1a325(%rip)     # 0x738b0 <g.4>
   5958b:      	je	0x6e9c5 <f.2+0x17805>
   59591:      	cmpq	$0x0, 0x1a30f(%rip)     # 0x738a8 <g.3>
   59599:      	je	0x6e9c5 <f.2+0x17805>
   5959f:      	movq	%rax, %r13
   595a2:      	leaq	-0xe(%r14), %rsi
   595a6:      	movq	$0x0, 0x50(%rsp)
   595af:      	movq	$0x3, 0x38(%rsp)
   595b8:      	xorl	%edi, %edi
   595ba:      	callq	0x6e9d0 <f.3>
   595bf:      	subq	$0x8, %rsp
   595c3:      	cmpb	$0x0, 0x1a2e6(%rip)     # 0x738b0 <g.4>
   595ca:      	je	0x6e9c5 <f.2+0x17805>
   595d0:      	movq	%rax, %rbp
   595d3:      	cmpq	$0x0, 0x1a2cd(%rip)     # 0x738a8 <g.3>
   595db:      	leaq	0x28(%rsp), %r8
   595e0:      	leaq	0x20(%rsp), %rdi
   595e5:      	leaq	0x1a1dc(%rip), %r9      # 0x737c8 <native_roots.0>
   595ec:      	movq	0x10(%rsp), %rax
   595f1:      	je	0x6e9c5 <f.2+0x17805>
   595f7:      	addq	%r13, %rbp
   595fa:      	cmpq	$0xf, %r14
   595fe:      	jae	0x5a866 <f.2+0x36a6>
   59604:      	leaq	-0xd(%r14), %rcx
   59608:      	jmp	0x5a8e2 <f.2+0x3722>
   5960d:      	movq	$0x0, 0x50(%rsp)
   59616:      	movq	$0x3, 0x38(%rsp)
   5961f:      	xorl	%edi, %edi
   59621:      	leaq	-0xd(%r14), %rsi
   59625:      	callq	0x6e9d0 <f.3>
   5962a:      	subq	$0x8, %rsp
   5962e:      	cmpb	$0x0, 0x1a27b(%rip)     # 0x738b0 <g.4>
   59635:      	je	0x6e9c5 <f.2+0x17805>
   5963b:      	cmpq	$0x0, 0x1a265(%rip)     # 0x738a8 <g.3>
   59643:      	je	0x6e9c5 <f.2+0x17805>
   59649:      	movq	%rax, %r13
   5964c:      	leaq	-0xe(%r14), %rsi
   59650:      	movq	$0x0, 0x50(%rsp)
   59659:      	movq	$0x3, 0x38(%rsp)
   59662:      	xorl	%edi, %edi
   59664:      	callq	0x6e9d0 <f.3>
   59669:      	subq	$0x8, %rsp
   5966d:      	cmpb	$0x0, 0x1a23c(%rip)     # 0x738b0 <g.4>
   59674:      	je	0x6e9c5 <f.2+0x17805>
   5967a:      	cmpq	$0x0, 0x1a226(%rip)     # 0x738a8 <g.3>
   59682:      	leaq	0x28(%rsp), %r8
   59687:      	leaq	0x20(%rsp), %rdi
   5968c:      	leaq	0x1a135(%rip), %r9      # 0x737c8 <native_roots.0>
   59693:      	je	0x6e9c5 <f.2+0x17805>
   59699:      	addq	%r13, %rax
   5969c:      	addq	%r15, %rax
   5969f:      	addq	%rbp, %rax
   596a2:      	movq	%r14, %r13
   596a5:      	subq	$0xc, %r13
   596a9:      	jbe	0x5b802 <f.2+0x4642>
   596af:      	movq	%rax, 0x18(%rsp)
   596b4:      	movq	$0x0, 0x50(%rsp)
   596bd:      	movq	$0x3, 0x38(%rsp)
   596c6:      	xorl	%edi, %edi
   596c8:      	movq	%r13, %rsi
   596cb:      	callq	0x6e9d0 <f.3>
   596d0:      	subq	$0x8, %rsp
   596d4:      	cmpb	$0x0, 0x1a1d5(%rip)     # 0x738b0 <g.4>
   596db:      	je	0x6e9c5 <f.2+0x17805>
   596e1:      	cmpq	$0x0, 0x1a1bf(%rip)     # 0x738a8 <g.3>
   596e9:      	je	0x6e9c5 <f.2+0x17805>
   596ef:      	movq	%rax, %r15
   596f2:      	movq	$0x0, 0x50(%rsp)
   596fb:      	movq	$0x3, 0x38(%rsp)
   59704:      	xorl	%edi, %edi
   59706:      	leaq	-0xd(%r14), %rsi
   5970a:      	callq	0x6e9d0 <f.3>
   5970f:      	subq	$0x8, %rsp
   59713:      	cmpb	$0x0, 0x1a196(%rip)     # 0x738b0 <g.4>
   5971a:      	je	0x6e9c5 <f.2+0x17805>
   59720:      	cmpq	$0x0, 0x1a180(%rip)     # 0x738a8 <g.3>
   59728:      	leaq	0x28(%rsp), %r8
   5972d:      	leaq	0x1a094(%rip), %r9      # 0x737c8 <native_roots.0>
   59734:      	je	0x6e9c5 <f.2+0x17805>
   5973a:      	movq	%rax, %rbp
   5973d:      	addq	%r15, %rbp
   59740:      	cmpq	$0xd, %r14
   59744:      	jne	0x5a137 <f.2+0x2f77>
   5974a:      	addq	%rbp, %r13
   5974d:      	movl	$0x1, %r15d
   59753:      	movq	$0x0, 0x10(%rsp)
   5975c:      	leaq	0x20(%rsp), %rdi
   59761:      	jmp	0x5c6a1 <f.2+0x54e1>
   59766:      	movq	$0x0, 0x50(%rsp)
   5976f:      	movq	$0x3, 0x38(%rsp)
   59778:      	xorl	%edi, %edi
   5977a:      	leaq	-0xd(%r14), %rsi
   5977e:      	callq	0x6e9d0 <f.3>
   59783:      	subq	$0x8, %rsp
   59787:      	cmpb	$0x0, 0x1a122(%rip)     # 0x738b0 <g.4>
   5978e:      	je	0x6e9c5 <f.2+0x17805>
   59794:      	movq	%rax, 0x10(%rsp)
   59799:      	cmpq	$0x0, 0x1a107(%rip)     # 0x738a8 <g.3>
   597a1:      	je	0x6e9c5 <f.2+0x17805>
   597a7:      	leaq	-0xe(%r14), %rsi
   597ab:      	movq	$0x0, 0x50(%rsp)
   597b4:      	movq	$0x3, 0x38(%rsp)
   597bd:      	xorl	%edi, %edi
   597bf:      	callq	0x6e9d0 <f.3>
   597c4:      	subq	$0x8, %rsp
   597c8:      	cmpb	$0x0, 0x1a0e1(%rip)     # 0x738b0 <g.4>
   597cf:      	je	0x6e9c5 <f.2+0x17805>
   597d5:      	cmpq	$0x0, 0x1a0cb(%rip)     # 0x738a8 <g.3>
   597dd:      	leaq	0x28(%rsp), %r8
   597e2:      	leaq	0x20(%rsp), %rdi
   597e7:      	leaq	0x19fda(%rip), %r9      # 0x737c8 <native_roots.0>
   597ee:      	je	0x6e9c5 <f.2+0x17805>
   597f4:      	movq	%rax, %r13
   597f7:      	addq	0x10(%rsp), %r13
   597fc:      	addq	%rbp, %r13
   597ff:      	addq	%r15, %r13
   59802:      	movq	%r14, %rbp
   59805:      	subq	$0xc, %rbp
   59809:      	jbe	0x57e35 <f.2+0xc75>
   5980f:      	movq	$0x0, 0x50(%rsp)
   59818:      	movq	$0x3, 0x38(%rsp)
   59821:      	xorl	%edi, %edi
   59823:      	movq	%rbp, %rsi
   59826:      	callq	0x6e9d0 <f.3>
   5982b:      	subq	$0x8, %rsp
   5982f:      	cmpb	$0x0, 0x1a07a(%rip)     # 0x738b0 <g.4>
   59836:      	je	0x6e9c5 <f.2+0x17805>
   5983c:      	cmpq	$0x0, 0x1a064(%rip)     # 0x738a8 <g.3>
   59844:      	je	0x6e9c5 <f.2+0x17805>
   5984a:      	movq	%rax, %r15
   5984d:      	movq	$0x0, 0x50(%rsp)
   59856:      	movq	$0x3, 0x38(%rsp)
   5985f:      	xorl	%edi, %edi
   59861:      	leaq	-0xd(%r14), %rsi
   59865:      	callq	0x6e9d0 <f.3>
   5986a:      	subq	$0x8, %rsp
   5986e:      	cmpb	$0x0, 0x1a03b(%rip)     # 0x738b0 <g.4>
   59875:      	je	0x6e9c5 <f.2+0x17805>
   5987b:      	cmpq	$0x0, 0x1a025(%rip)     # 0x738a8 <g.3>
   59883:      	leaq	0x28(%rsp), %r8
   59888:      	leaq	0x19f39(%rip), %r9      # 0x737c8 <native_roots.0>
   5988f:      	je	0x6e9c5 <f.2+0x17805>
   59895:      	addq	%r15, %rax
   59898:      	cmpq	$0xd, %r14
   5989c:      	jne	0x5a266 <f.2+0x30a6>
   598a2:      	addq	%rax, %rbp
   598a5:      	movl	$0x1, %r15d
   598ab:      	xorl	%eax, %eax
   598ad:      	leaq	0x20(%rsp), %rdi
   598b2:      	jmp	0x5a3ab <f.2+0x31eb>
   598b7:      	movq	$0x0, 0x50(%rsp)
   598c0:      	movq	$0x3, 0x38(%rsp)
   598c9:      	xorl	%edi, %edi
   598cb:      	leaq	-0xd(%r14), %rsi
   598cf:      	callq	0x6e9d0 <f.3>
   598d4:      	subq	$0x8, %rsp
   598d8:      	cmpb	$0x0, 0x19fd1(%rip)     # 0x738b0 <g.4>
   598df:      	je	0x6e9c5 <f.2+0x17805>
   598e5:      	cmpq	$0x0, 0x19fbb(%rip)     # 0x738a8 <g.3>
   598ed:      	je	0x6e9c5 <f.2+0x17805>
   598f3:      	movq	%rax, %r15
   598f6:      	leaq	-0xe(%r14), %rsi
   598fa:      	movq	$0x0, 0x50(%rsp)
   59903:      	movq	$0x3, 0x38(%rsp)
   5990c:      	xorl	%edi, %edi
   5990e:      	callq	0x6e9d0 <f.3>
   59913:      	subq	$0x8, %rsp
   59917:      	cmpb	$0x0, 0x19f92(%rip)     # 0x738b0 <g.4>
   5991e:      	je	0x6e9c5 <f.2+0x17805>
   59924:      	cmpq	$0x0, 0x19f7c(%rip)     # 0x738a8 <g.3>
   5992c:      	leaq	0x28(%rsp), %r8
   59931:      	leaq	0x20(%rsp), %rdi
   59936:      	leaq	0x19e8b(%rip), %r9      # 0x737c8 <native_roots.0>
   5993d:      	je	0x6e9c5 <f.2+0x17805>
   59943:      	addq	%r15, %rax
   59946:      	addq	%r13, %rax
   59949:      	addq	%rbp, %rax
   5994c:      	movq	%r14, %r15
   5994f:      	subq	$0xc, %r15
   59953:      	jbe	0x586ea <f.2+0x152a>
   59959:      	movq	%rax, 0x18(%rsp)
   5995e:      	movq	$0x0, 0x50(%rsp)
   59967:      	movq	$0x3, 0x38(%rsp)
   59970:      	xorl	%edi, %edi
   59972:      	movq	%r15, %rbp
   59975:      	movq	%r15, %rsi
   59978:      	callq	0x6e9d0 <f.3>
   5997d:      	subq	$0x8, %rsp
   59981:      	cmpb	$0x0, 0x19f28(%rip)     # 0x738b0 <g.4>
   59988:      	je	0x6e9c5 <f.2+0x17805>
   5998e:      	cmpq	$0x0, 0x19f12(%rip)     # 0x738a8 <g.3>
   59996:      	leaq	-0xd(%r14), %rsi
   5999a:      	je	0x6e9c5 <f.2+0x17805>
   599a0:      	movq	%rax, %r15
   599a3:      	movq	$0x0, 0x50(%rsp)
   599ac:      	movq	$0x3, 0x38(%rsp)
   599b5:      	xorl	%edi, %edi
   599b7:      	callq	0x6e9d0 <f.3>
   599bc:      	subq	$0x8, %rsp
   599c0:      	cmpb	$0x0, 0x19ee9(%rip)     # 0x738b0 <g.4>
   599c7:      	je	0x6e9c5 <f.2+0x17805>
   599cd:      	cmpq	$0x0, 0x19ed3(%rip)     # 0x738a8 <g.3>
   599d5:      	je	0x6e9c5 <f.2+0x17805>
   599db:      	movq	%rax, %r13
   599de:      	addq	%r15, %r13
   599e1:      	cmpq	$0xd, %r14
   599e5:      	jne	0x5a3b6 <f.2+0x31f6>
   599eb:      	movq	%rbp, %r15
   599ee:      	addq	%r13, %r15
   599f1:      	movl	$0x1, %ecx
   599f6:      	movq	$0x0, 0x10(%rsp)
   599ff:      	jmp	0x5a4c9 <f.2+0x3309>
   59a04:      	leaq	-0xd(%r14), %rbp
   59a08:      	movq	$0x0, 0x50(%rsp)
   59a11:      	movq	$0x3, 0x38(%rsp)
   59a1a:      	xorl	%edi, %edi
   59a1c:      	movq	%rbp, %rsi
   59a1f:      	callq	0x6e9d0 <f.3>
   59a24:      	subq	$0x8, %rsp
   59a28:      	cmpb	$0x0, 0x19e81(%rip)     # 0x738b0 <g.4>
   59a2f:      	je	0x6e9c5 <f.2+0x17805>
   59a35:      	cmpq	$0x0, 0x19e6b(%rip)     # 0x738a8 <g.3>
   59a3d:      	je	0x6e9c5 <f.2+0x17805>
   59a43:      	movq	%rax, %r12
   59a46:      	leaq	-0xe(%r14), %rsi
   59a4a:      	movq	$0x0, 0x50(%rsp)
   59a53:      	movq	$0x3, 0x38(%rsp)
   59a5c:      	xorl	%edi, %edi
   59a5e:      	callq	0x6e9d0 <f.3>
   59a63:      	subq	$0x8, %rsp
   59a67:      	cmpb	$0x0, 0x19e42(%rip)     # 0x738b0 <g.4>
   59a6e:      	je	0x6e9c5 <f.2+0x17805>
   59a74:      	movq	%rax, %r13
   59a77:      	cmpq	$0x0, 0x19e29(%rip)     # 0x738a8 <g.3>
   59a7f:      	leaq	0x28(%rsp), %r8
   59a84:      	leaq	0x19d3d(%rip), %r9      # 0x737c8 <native_roots.0>
   59a8b:      	movq	0x10(%rsp), %rax
   59a90:      	je	0x6e9c5 <f.2+0x17805>
   59a96:      	addq	%r12, %r13
   59a99:      	cmpq	$0xe, %r14
   59a9d:      	ja	0x5b80a <f.2+0x464a>
   59aa3:      	leaq	0x20(%rsp), %rdi
   59aa8:      	movq	0x18(%rsp), %r12
   59aad:      	addq	%r13, %rbp
   59ab0:      	jmp	0x5b8a9 <f.2+0x46e9>
   59ab5:      	movq	$0x0, 0x50(%rsp)
   59abe:      	movq	$0x3, 0x38(%rsp)
   59ac7:      	xorl	%edi, %edi
   59ac9:      	leaq	-0xd(%r14), %rsi
   59acd:      	callq	0x6e9d0 <f.3>
   59ad2:      	subq	$0x8, %rsp
   59ad6:      	cmpb	$0x0, 0x19dd3(%rip)     # 0x738b0 <g.4>
   59add:      	movq	0x10(%rsp), %r13
   59ae2:      	je	0x6e9c5 <f.2+0x17805>
   59ae8:      	movq	%rax, 0x18(%rsp)
   59aed:      	cmpq	$0x0, 0x19db3(%rip)     # 0x738a8 <g.3>
   59af5:      	je	0x6e9c5 <f.2+0x17805>
   59afb:      	leaq	-0xe(%r14), %rsi
   59aff:      	movq	$0x0, 0x50(%rsp)
   59b08:      	movq	$0x3, 0x38(%rsp)
   59b11:      	xorl	%edi, %edi
   59b13:      	callq	0x6e9d0 <f.3>
   59b18:      	subq	$0x8, %rsp
   59b1c:      	cmpb	$0x0, 0x19d8d(%rip)     # 0x738b0 <g.4>
   59b23:      	je	0x6e9c5 <f.2+0x17805>
   59b29:      	cmpq	$0x0, 0x19d77(%rip)     # 0x738a8 <g.3>
   59b31:      	je	0x6e9c5 <f.2+0x17805>
   59b37:      	movq	%rax, %rbp
   59b3a:      	movq	$0x0, 0x50(%rsp)
   59b43:      	movq	$0x3, 0x38(%rsp)
   59b4c:      	xorl	%edi, %edi
   59b4e:      	leaq	-0xd(%r14), %rsi
   59b52:      	callq	0x6e9d0 <f.3>
   59b57:      	subq	$0x8, %rsp
   59b5b:      	cmpb	$0x0, 0x19d4e(%rip)     # 0x738b0 <g.4>
   59b62:      	je	0x6e9c5 <f.2+0x17805>
   59b68:      	movq	%rax, 0x58(%rsp)
   59b6d:      	cmpq	$0x0, 0x19d33(%rip)     # 0x738a8 <g.3>
   59b75:      	je	0x6e9c5 <f.2+0x17805>
   59b7b:      	movq	$0x0, 0x50(%rsp)
   59b84:      	movq	$0x3, 0x38(%rsp)
   59b8d:      	xorl	%edi, %edi
   59b8f:      	leaq	-0xe(%r14), %rsi
   59b93:      	callq	0x6e9d0 <f.3>
   59b98:      	subq	$0x8, %rsp
   59b9c:      	cmpb	$0x0, 0x19d0d(%rip)     # 0x738b0 <g.4>
   59ba3:      	je	0x6e9c5 <f.2+0x17805>
   59ba9:      	cmpq	$0x0, 0x19cf7(%rip)     # 0x738a8 <g.3>
   59bb1:      	leaq	0x28(%rsp), %r8
   59bb6:      	leaq	0x20(%rsp), %rdi
   59bbb:      	leaq	0x19c06(%rip), %r9      # 0x737c8 <native_roots.0>
   59bc2:      	je	0x6e9c5 <f.2+0x17805>
   59bc8:      	movq	%rax, %rcx
   59bcb:      	addq	0x18(%rsp), %rbp
   59bd0:      	addq	%r12, %rbp
   59bd3:      	addq	0x58(%rsp), %rcx
   59bd8:      	cmpq	$0xf, %r14
   59bdc:      	jae	0x5bae8 <f.2+0x4928>
   59be2:      	leaq	-0xd(%r14), %rax
   59be6:      	addq	%rax, %rcx
   59be9:      	jmp	0x5bb77 <f.2+0x49b7>
   59bee:      	incq	%rsi
   59bf1:      	leaq	-0xc(%r14), %rbp
   59bf5:      	jmp	0x5e292 <f.2+0x70d2>
   59bfa:      	incq	%r13
   59bfd:      	leaq	-0xc(%r14), %rbp
   59c01:      	jmp	0x5e6f9 <f.2+0x7539>
   59c06:      	movq	%rax, 0x10(%rsp)
   59c0b:      	movq	$0x0, 0x50(%rsp)
   59c14:      	movq	$0x3, 0x38(%rsp)
   59c1d:      	xorl	%edi, %edi
   59c1f:      	callq	0x6e9d0 <f.3>
   59c24:      	subq	$0x8, %rsp
   59c28:      	cmpb	$0x0, 0x19c81(%rip)     # 0x738b0 <g.4>
   59c2f:      	je	0x6e9c5 <f.2+0x17805>
   59c35:      	movq	%rax, 0x18(%rsp)
   59c3a:      	cmpq	$0x0, 0x19c66(%rip)     # 0x738a8 <g.3>
   59c42:      	je	0x6e9c5 <f.2+0x17805>
   59c48:      	leaq	-0xe(%r14), %rsi
   59c4c:      	movq	$0x0, 0x50(%rsp)
   59c55:      	movq	$0x3, 0x38(%rsp)
   59c5e:      	xorl	%edi, %edi
   59c60:      	callq	0x6e9d0 <f.3>
   59c65:      	subq	$0x8, %rsp
   59c69:      	cmpb	$0x0, 0x19c40(%rip)     # 0x738b0 <g.4>
   59c70:      	je	0x6e9c5 <f.2+0x17805>
   59c76:      	cmpq	$0x0, 0x19c2a(%rip)     # 0x738a8 <g.3>
   59c7e:      	leaq	-0xd(%r14), %rsi
   59c82:      	je	0x6e9c5 <f.2+0x17805>
   59c88:      	movq	%rax, %rbp
   59c8b:      	movq	$0x0, 0x50(%rsp)
   59c94:      	movq	$0x3, 0x38(%rsp)
   59c9d:      	xorl	%edi, %edi
   59c9f:      	callq	0x6e9d0 <f.3>
   59ca4:      	subq	$0x8, %rsp
   59ca8:      	cmpb	$0x0, 0x19c01(%rip)     # 0x738b0 <g.4>
   59caf:      	je	0x6e9c5 <f.2+0x17805>
   59cb5:      	cmpq	$0x0, 0x19beb(%rip)     # 0x738a8 <g.3>
   59cbd:      	je	0x6e9c5 <f.2+0x17805>
   59cc3:      	movq	%rax, %r12
   59cc6:      	movq	$0x0, 0x50(%rsp)
   59ccf:      	movq	$0x3, 0x38(%rsp)
   59cd8:      	xorl	%edi, %edi
   59cda:      	leaq	-0xe(%r14), %rsi
   59cde:      	callq	0x6e9d0 <f.3>
   59ce3:      	subq	$0x8, %rsp
   59ce7:      	cmpb	$0x0, 0x19bc2(%rip)     # 0x738b0 <g.4>
   59cee:      	je	0x6e9c5 <f.2+0x17805>
   59cf4:      	cmpq	$0x0, 0x19bac(%rip)     # 0x738a8 <g.3>
   59cfc:      	leaq	-0xd(%r14), %rsi
   59d00:      	je	0x6e9c5 <f.2+0x17805>
   59d06:      	addq	0x18(%rsp), %rbp
   59d0b:      	addq	0x10(%rsp), %rbp
   59d10:      	addq	%r12, %rax
   59d13:      	cmpq	$0xe, %r14
   59d17:      	ja	0x5c360 <f.2+0x51a0>
   59d1d:      	addq	%rsi, %rax
   59d20:      	addq	%rbp, %rax
   59d23:      	movq	%rax, 0x10(%rsp)
   59d28:      	movq	$0x0, 0x50(%rsp)
   59d31:      	movq	$0x3, 0x38(%rsp)
   59d3a:      	xorl	%edi, %edi
   59d3c:      	movq	%rsi, %rbp
   59d3f:      	callq	0x6e9d0 <f.3>
   59d44:      	subq	$0x8, %rsp
   59d48:      	cmpb	$0x0, 0x19b61(%rip)     # 0x738b0 <g.4>
   59d4f:      	je	0x6e9c5 <f.2+0x17805>
   59d55:      	cmpq	$0x0, 0x19b4b(%rip)     # 0x738a8 <g.3>
   59d5d:      	je	0x6e9c5 <f.2+0x17805>
   59d63:      	movq	%rax, %r12
   59d66:      	leaq	-0xe(%r14), %rsi
   59d6a:      	movq	$0x0, 0x50(%rsp)
   59d73:      	movq	$0x3, 0x38(%rsp)
   59d7c:      	xorl	%edi, %edi
   59d7e:      	callq	0x6e9d0 <f.3>
   59d83:      	subq	$0x8, %rsp
   59d87:      	cmpb	$0x0, 0x19b22(%rip)     # 0x738b0 <g.4>
   59d8e:      	je	0x6e9c5 <f.2+0x17805>
   59d94:      	cmpq	$0x0, 0x19b0c(%rip)     # 0x738a8 <g.3>
   59d9c:      	leaq	0x20(%rsp), %rdi
   59da1:      	je	0x6e9c5 <f.2+0x17805>
   59da7:      	movq	%rbp, %rsi
   59daa:      	addq	%r12, %rax
   59dad:      	cmpq	$0xe, %r14
   59db1:      	leaq	-0xe(%r14), %rbp
   59db5:      	jne	0x5ad83 <f.2+0x3bc3>
   59dbb:      	addq	%rax, %rsi
   59dbe:      	movl	$0x1, %ebp
   59dc3:      	xorl	%eax, %eax
   59dc5:      	leaq	0x28(%rsp), %r8
   59dca:      	leaq	0x199f7(%rip), %r9      # 0x737c8 <native_roots.0>
   59dd1:      	movq	0x10(%rsp), %r12
   59dd6:      	jmp	0x5aec3 <f.2+0x3d03>
   59ddb:      	movq	%rax, 0x18(%rsp)
   59de0:      	movq	$0x0, 0x50(%rsp)
   59de9:      	movq	$0x3, 0x38(%rsp)
   59df2:      	xorl	%edi, %edi
   59df4:      	movq	%r13, %rsi
   59df7:      	callq	0x6e9d0 <f.3>
   59dfc:      	subq	$0x8, %rsp
   59e00:      	cmpb	$0x0, 0x19aa9(%rip)     # 0x738b0 <g.4>
   59e07:      	je	0x6e9c5 <f.2+0x17805>
   59e0d:      	movq	%rax, 0x58(%rsp)
   59e12:      	cmpq	$0x0, 0x19a8e(%rip)     # 0x738a8 <g.3>
   59e1a:      	je	0x6e9c5 <f.2+0x17805>
   59e20:      	leaq	-0xe(%r14), %r12
   59e24:      	movq	$0x0, 0x50(%rsp)
   59e2d:      	movq	$0x3, 0x38(%rsp)
   59e36:      	xorl	%edi, %edi
   59e38:      	movq	%r12, %rsi
   59e3b:      	callq	0x6e9d0 <f.3>
   59e40:      	subq	$0x8, %rsp
   59e44:      	cmpb	$0x0, 0x19a65(%rip)     # 0x738b0 <g.4>
   59e4b:      	je	0x6e9c5 <f.2+0x17805>
   59e51:      	cmpq	$0x0, 0x19a4f(%rip)     # 0x738a8 <g.3>
   59e59:      	je	0x6e9c5 <f.2+0x17805>
   59e5f:      	movq	%rax, %rbp
   59e62:      	movq	$0x0, 0x50(%rsp)
   59e6b:      	movq	$0x3, 0x38(%rsp)
   59e74:      	xorl	%edi, %edi
   59e76:      	movq	%r13, %rsi
   59e79:      	callq	0x6e9d0 <f.3>
   59e7e:      	subq	$0x8, %rsp
   59e82:      	cmpb	$0x0, 0x19a27(%rip)     # 0x738b0 <g.4>
   59e89:      	je	0x6e9c5 <f.2+0x17805>
   59e8f:      	movq	%rax, 0x60(%rsp)
   59e94:      	cmpq	$0x0, 0x19a0c(%rip)     # 0x738a8 <g.3>
   59e9c:      	je	0x6e9c5 <f.2+0x17805>
   59ea2:      	movq	$0x0, 0x50(%rsp)
   59eab:      	movq	$0x3, 0x38(%rsp)
   59eb4:      	xorl	%edi, %edi
   59eb6:      	movq	%r12, %rsi
   59eb9:      	callq	0x6e9d0 <f.3>
   59ebe:      	subq	$0x8, %rsp
   59ec2:      	cmpb	$0x0, 0x199e7(%rip)     # 0x738b0 <g.4>
   59ec9:      	je	0x6e9c5 <f.2+0x17805>
   59ecf:      	movq	%rax, %r12
   59ed2:      	cmpq	$0x0, 0x199ce(%rip)     # 0x738a8 <g.3>
   59eda:      	movq	0x18(%rsp), %rax
   59edf:      	je	0x6e9c5 <f.2+0x17805>
   59ee5:      	addq	0x58(%rsp), %rbp
   59eea:      	addq	%rax, %rbp
   59eed:      	addq	0x60(%rsp), %r12
   59ef2:      	cmpq	$0xe, %r14
   59ef6:      	ja	0x5c41e <f.2+0x525e>
   59efc:      	addq	%r13, %r12
   59eff:      	addq	%rbp, %r12
   59f02:      	movq	$0x0, 0x50(%rsp)
   59f0b:      	movq	$0x3, 0x38(%rsp)
   59f14:      	xorl	%edi, %edi
   59f16:      	movq	%r13, %rsi
   59f19:      	callq	0x6e9d0 <f.3>
   59f1e:      	subq	$0x8, %rsp
   59f22:      	cmpb	$0x0, 0x19987(%rip)     # 0x738b0 <g.4>
   59f29:      	je	0x6e9c5 <f.2+0x17805>
   59f2f:      	movq	%r12, 0x58(%rsp)
   59f34:      	cmpq	$0x0, 0x1996c(%rip)     # 0x738a8 <g.3>
   59f3c:      	je	0x6e9c5 <f.2+0x17805>
   59f42:      	movq	%rax, %rbp
   59f45:      	leaq	-0xe(%r14), %rsi
   59f49:      	movq	$0x0, 0x50(%rsp)
   59f52:      	movq	$0x3, 0x38(%rsp)
   59f5b:      	xorl	%edi, %edi
   59f5d:      	movq	%rsi, 0x18(%rsp)
   59f62:      	callq	0x6e9d0 <f.3>
   59f67:      	subq	$0x8, %rsp
   59f6b:      	cmpb	$0x0, 0x1993e(%rip)     # 0x738b0 <g.4>
   59f72:      	je	0x6e9c5 <f.2+0x17805>
   59f78:      	cmpq	$0x0, 0x19928(%rip)     # 0x738a8 <g.3>
   59f80:      	movq	0x10(%rsp), %rcx
   59f85:      	je	0x6e9c5 <f.2+0x17805>
   59f8b:      	movq	%rax, %r12
   59f8e:      	addq	%rbp, %r12
   59f91:      	cmpq	$0xe, %r14
   59f95:      	jne	0x5aecb <f.2+0x3d0b>
   59f9b:      	addq	%r12, %r13
   59f9e:      	movl	$0x1, %ebp
   59fa3:      	movq	$0x0, 0x18(%rsp)
   59fac:      	jmp	0x5afee <f.2+0x3e2e>
   59fb1:      	movq	$0x0, 0x50(%rsp)
   59fba:      	movq	$0x3, 0x38(%rsp)
   59fc3:      	xorl	%edi, %edi
   59fc5:      	leaq	-0xd(%r14), %rsi
   59fc9:      	callq	0x6e9d0 <f.3>
   59fce:      	subq	$0x8, %rsp
   59fd2:      	cmpb	$0x0, 0x198d7(%rip)     # 0x738b0 <g.4>
   59fd9:      	je	0x6e9c5 <f.2+0x17805>
   59fdf:      	cmpq	$0x0, 0x198c1(%rip)     # 0x738a8 <g.3>
   59fe7:      	je	0x6e9c5 <f.2+0x17805>
   59fed:      	movq	%rax, %r12
   59ff0:      	leaq	-0xe(%r14), %rsi
   59ff4:      	movq	$0x0, 0x50(%rsp)
   59ffd:      	movq	$0x3, 0x38(%rsp)
   5a006:      	xorl	%edi, %edi
   5a008:      	callq	0x6e9d0 <f.3>
   5a00d:      	subq	$0x8, %rsp
   5a011:      	cmpb	$0x0, 0x19898(%rip)     # 0x738b0 <g.4>
   5a018:      	je	0x6e9c5 <f.2+0x17805>
   5a01e:      	cmpq	$0x0, 0x19882(%rip)     # 0x738a8 <g.3>
   5a026:      	leaq	0x28(%rsp), %r8
   5a02b:      	leaq	0x20(%rsp), %rdi
   5a030:      	leaq	0x19791(%rip), %r9      # 0x737c8 <native_roots.0>
   5a037:      	je	0x6e9c5 <f.2+0x17805>
   5a03d:      	movq	%rax, %rbp
   5a040:      	addq	%r12, %rbp
   5a043:      	addq	%r13, %rbp
   5a046:      	movq	0x18(%rsp), %r12
   5a04b:      	cmpq	$0xc, %r14
   5a04f:      	je	0x5a080 <f.2+0x2ec0>
   5a051:      	cmpq	$0xd, %r14
   5a055:      	jne	0x5a097 <f.2+0x2ed7>
   5a057:      	cmpq	$0x0, 0x19849(%rip)     # 0x738a8 <g.3>
   5a05f:      	je	0x6e9c5 <f.2+0x17805>
   5a065:      	incq	%rbp
   5a068:      	leaq	-0xd(%r14), %r13
   5a06c:      	movq	%rbp, %rdx
   5a06f:      	incq	%r13
   5a072:      	leaq	-0xc(%r14), %rax
   5a076:      	movq	0x18(%rsp), %r12
   5a07b:      	jmp	0x62ba7 <f.2+0xb9e7>
   5a080:      	leaq	(%r14,%rbp), %rdx
   5a084:      	addq	$-0xb, %rdx
   5a088:      	movl	$0x1, %r13d
   5a08e:      	leaq	-0xc(%r14), %rax
   5a092:      	jmp	0x62ba7 <f.2+0xb9e7>
   5a097:      	leaq	-0xd(%r14), %rsi
   5a09b:      	movq	$0x0, 0x50(%rsp)
   5a0a4:      	movq	$0x3, 0x38(%rsp)
   5a0ad:      	xorl	%edi, %edi
   5a0af:      	callq	0x6e9d0 <f.3>
   5a0b4:      	subq	$0x8, %rsp
   5a0b8:      	cmpb	$0x0, 0x197f1(%rip)     # 0x738b0 <g.4>
   5a0bf:      	je	0x6e9c5 <f.2+0x17805>
   5a0c5:      	cmpq	$0x0, 0x197db(%rip)     # 0x738a8 <g.3>
   5a0cd:      	je	0x6e9c5 <f.2+0x17805>
   5a0d3:      	movq	%rax, %r12
   5a0d6:      	leaq	-0xe(%r14), %rsi
   5a0da:      	movq	$0x0, 0x50(%rsp)
   5a0e3:      	movq	$0x3, 0x38(%rsp)
   5a0ec:      	xorl	%edi, %edi
   5a0ee:      	callq	0x6e9d0 <f.3>
   5a0f3:      	subq	$0x8, %rsp
   5a0f7:      	cmpb	$0x0, 0x197b2(%rip)     # 0x738b0 <g.4>
   5a0fe:      	je	0x6e9c5 <f.2+0x17805>
   5a104:      	cmpq	$0x0, 0x1979c(%rip)     # 0x738a8 <g.3>
   5a10c:      	je	0x6e9c5 <f.2+0x17805>
   5a112:      	movq	%rax, %r13
   5a115:      	addq	%r12, %r13
   5a118:      	cmpq	$0xe, %r14
   5a11c:      	ja	0x5b986 <f.2+0x47c6>
   5a122:      	leaq	-0xd(%r14), %rax
   5a126:      	addq	%rax, %r13
   5a129:      	addq	%rbp, %r13
   5a12c:      	movq	%r13, %rdx
   5a12f:      	movq	%rax, %r13
   5a132:      	jmp	0x5ba2b <f.2+0x486b>
   5a137:      	movq	$0x0, 0x50(%rsp)
   5a140:      	movq	$0x3, 0x38(%rsp)
   5a149:      	xorl	%edi, %edi
   5a14b:      	leaq	-0xd(%r14), %r15
   5a14f:      	movq	%r15, %rsi
   5a152:      	callq	0x6e9d0 <f.3>
   5a157:      	subq	$0x8, %rsp
   5a15b:      	cmpb	$0x0, 0x1974e(%rip)     # 0x738b0 <g.4>
   5a162:      	je	0x6e9c5 <f.2+0x17805>
   5a168:      	movq	%rax, 0x58(%rsp)
   5a16d:      	cmpq	$0x0, 0x19733(%rip)     # 0x738a8 <g.3>
   5a175:      	je	0x6e9c5 <f.2+0x17805>
   5a17b:      	leaq	-0xe(%r14), %rsi
   5a17f:      	movq	$0x0, 0x50(%rsp)
   5a188:      	movq	$0x3, 0x38(%rsp)
   5a191:      	xorl	%edi, %edi
   5a193:      	callq	0x6e9d0 <f.3>
   5a198:      	subq	$0x8, %rsp
   5a19c:      	cmpb	$0x0, 0x1970d(%rip)     # 0x738b0 <g.4>
   5a1a3:      	je	0x6e9c5 <f.2+0x17805>
   5a1a9:      	cmpq	$0x0, 0x196f7(%rip)     # 0x738a8 <g.3>
   5a1b1:      	je	0x6e9c5 <f.2+0x17805>
   5a1b7:      	movq	%rax, %r13
   5a1ba:      	movq	$0x0, 0x50(%rsp)
   5a1c3:      	movq	$0x3, 0x38(%rsp)
   5a1cc:      	xorl	%edi, %edi
   5a1ce:      	movq	%r15, %rsi
   5a1d1:      	callq	0x6e9d0 <f.3>
   5a1d6:      	subq	$0x8, %rsp
   5a1da:      	cmpb	$0x0, 0x196cf(%rip)     # 0x738b0 <g.4>
   5a1e1:      	je	0x6e9c5 <f.2+0x17805>
   5a1e7:      	movq	%rax, 0x60(%rsp)
   5a1ec:      	cmpq	$0x0, 0x196b4(%rip)     # 0x738a8 <g.3>
   5a1f4:      	je	0x6e9c5 <f.2+0x17805>
   5a1fa:      	movq	$0x0, 0x50(%rsp)
   5a203:      	movq	$0x3, 0x38(%rsp)
   5a20c:      	xorl	%edi, %edi
   5a20e:      	leaq	-0xe(%r14), %rsi
   5a212:      	callq	0x6e9d0 <f.3>
   5a217:      	subq	$0x8, %rsp
   5a21b:      	cmpb	$0x0, 0x1968e(%rip)     # 0x738b0 <g.4>
   5a222:      	je	0x6e9c5 <f.2+0x17805>
   5a228:      	cmpq	$0x0, 0x19678(%rip)     # 0x738a8 <g.3>
   5a230:      	leaq	0x20(%rsp), %rdi
   5a235:      	je	0x6e9c5 <f.2+0x17805>
   5a23b:      	movq	%rax, %r15
   5a23e:      	addq	0x58(%rsp), %r13
   5a243:      	addq	%rbp, %r13
   5a246:      	addq	0x60(%rsp), %r15
   5a24b:      	cmpq	$0xf, %r14
   5a24f:      	jae	0x5c622 <f.2+0x5462>
   5a255:      	leaq	0x28(%rsp), %r8
   5a25a:      	leaq	0x19567(%rip), %r9      # 0x737c8 <native_roots.0>
   5a261:      	jmp	0x5c6a1 <f.2+0x54e1>
   5a266:      	movq	%rax, 0x18(%rsp)
   5a26b:      	movq	$0x0, 0x50(%rsp)
   5a274:      	movq	$0x3, 0x38(%rsp)
   5a27d:      	xorl	%edi, %edi
   5a27f:      	leaq	-0xd(%r14), %r15
   5a283:      	movq	%r15, %rsi
   5a286:      	callq	0x6e9d0 <f.3>
   5a28b:      	subq	$0x8, %rsp
   5a28f:      	cmpb	$0x0, 0x1961a(%rip)     # 0x738b0 <g.4>
   5a296:      	je	0x6e9c5 <f.2+0x17805>
   5a29c:      	cmpq	$0x0, 0x19604(%rip)     # 0x738a8 <g.3>
   5a2a4:      	je	0x6e9c5 <f.2+0x17805>
   5a2aa:      	movq	%rax, %rbp
   5a2ad:      	leaq	-0xe(%r14), %rsi
   5a2b1:      	movq	$0x0, 0x50(%rsp)
   5a2ba:      	movq	$0x3, 0x38(%rsp)
   5a2c3:      	xorl	%edi, %edi
   5a2c5:      	callq	0x6e9d0 <f.3>
   5a2ca:      	subq	$0x8, %rsp
   5a2ce:      	cmpb	$0x0, 0x195db(%rip)     # 0x738b0 <g.4>
   5a2d5:      	je	0x6e9c5 <f.2+0x17805>
   5a2db:      	movq	%rbp, 0x58(%rsp)
   5a2e0:      	movq	%rax, 0x10(%rsp)
   5a2e5:      	cmpq	$0x0, 0x195bb(%rip)     # 0x738a8 <g.3>
   5a2ed:      	je	0x6e9c5 <f.2+0x17805>
   5a2f3:      	movq	$0x0, 0x50(%rsp)
   5a2fc:      	movq	$0x3, 0x38(%rsp)
   5a305:      	xorl	%edi, %edi
   5a307:      	movq	%r15, %rsi
   5a30a:      	callq	0x6e9d0 <f.3>
   5a30f:      	subq	$0x8, %rsp
   5a313:      	cmpb	$0x0, 0x19596(%rip)     # 0x738b0 <g.4>
   5a31a:      	je	0x6e9c5 <f.2+0x17805>
   5a320:      	cmpq	$0x0, 0x19580(%rip)     # 0x738a8 <g.3>
   5a328:      	je	0x6e9c5 <f.2+0x17805>
   5a32e:      	movq	%rax, %rbp
   5a331:      	movq	$0x0, 0x50(%rsp)
   5a33a:      	movq	$0x3, 0x38(%rsp)
   5a343:      	xorl	%edi, %edi
   5a345:      	leaq	-0xe(%r14), %rsi
   5a349:      	callq	0x6e9d0 <f.3>
   5a34e:      	subq	$0x8, %rsp
   5a352:      	cmpb	$0x0, 0x19557(%rip)     # 0x738b0 <g.4>
   5a359:      	je	0x6e9c5 <f.2+0x17805>
   5a35f:      	cmpq	$0x0, 0x19541(%rip)     # 0x738a8 <g.3>
   5a367:      	je	0x6e9c5 <f.2+0x17805>
   5a36d:      	movq	%rax, %r15
   5a370:      	movq	0x10(%rsp), %rax
   5a375:      	addq	0x58(%rsp), %rax
   5a37a:      	addq	0x18(%rsp), %rax
   5a37f:      	movq	%rax, 0x10(%rsp)
   5a384:      	addq	%rbp, %r15
   5a387:      	cmpq	$0xf, %r14
   5a38b:      	jae	0x5c6f3 <f.2+0x5533>
   5a391:      	leaq	0x28(%rsp), %r8
   5a396:      	leaq	0x20(%rsp), %rdi
   5a39b:      	leaq	0x19426(%rip), %r9      # 0x737c8 <native_roots.0>
   5a3a2:      	movq	0x10(%rsp), %rbp
   5a3a7:      	leaq	-0xd(%r14), %rax
   5a3ab:      	addq	%rax, %r15
   5a3ae:      	addq	%rbp, %r15
   5a3b1:      	jmp	0x57874 <f.2+0x6b4>
   5a3b6:      	movq	$0x0, 0x50(%rsp)
   5a3bf:      	movq	$0x3, 0x38(%rsp)
   5a3c8:      	xorl	%edi, %edi
   5a3ca:      	leaq	-0xd(%r14), %rsi
   5a3ce:      	callq	0x6e9d0 <f.3>
   5a3d3:      	subq	$0x8, %rsp
   5a3d7:      	cmpb	$0x0, 0x194d2(%rip)     # 0x738b0 <g.4>
   5a3de:      	je	0x6e9c5 <f.2+0x17805>
   5a3e4:      	movq	%rax, 0x58(%rsp)
   5a3e9:      	cmpq	$0x0, 0x194b7(%rip)     # 0x738a8 <g.3>
   5a3f1:      	je	0x6e9c5 <f.2+0x17805>
   5a3f7:      	leaq	-0xe(%r14), %rsi
   5a3fb:      	movq	$0x0, 0x50(%rsp)
   5a404:      	movq	$0x3, 0x38(%rsp)
   5a40d:      	xorl	%edi, %edi
   5a40f:      	callq	0x6e9d0 <f.3>
   5a414:      	subq	$0x8, %rsp
   5a418:      	cmpb	$0x0, 0x19491(%rip)     # 0x738b0 <g.4>
   5a41f:      	je	0x6e9c5 <f.2+0x17805>
   5a425:      	cmpq	$0x0, 0x1947b(%rip)     # 0x738a8 <g.3>
   5a42d:      	je	0x6e9c5 <f.2+0x17805>
   5a433:      	movq	%rax, %r15
   5a436:      	movq	$0x0, 0x50(%rsp)
   5a43f:      	movq	$0x3, 0x38(%rsp)
   5a448:      	xorl	%edi, %edi
   5a44a:      	leaq	-0xd(%r14), %rsi
   5a44e:      	callq	0x6e9d0 <f.3>
   5a453:      	subq	$0x8, %rsp
   5a457:      	cmpb	$0x0, 0x19452(%rip)     # 0x738b0 <g.4>
   5a45e:      	je	0x6e9c5 <f.2+0x17805>
   5a464:      	cmpq	$0x0, 0x1943c(%rip)     # 0x738a8 <g.3>
   5a46c:      	je	0x6e9c5 <f.2+0x17805>
   5a472:      	movq	%rax, %rbp
   5a475:      	movq	$0x0, 0x50(%rsp)
   5a47e:      	movq	$0x3, 0x38(%rsp)
   5a487:      	xorl	%edi, %edi
   5a489:      	leaq	-0xe(%r14), %rsi
   5a48d:      	callq	0x6e9d0 <f.3>
   5a492:      	subq	$0x8, %rsp
   5a496:      	cmpb	$0x0, 0x19413(%rip)     # 0x738b0 <g.4>
   5a49d:      	je	0x6e9c5 <f.2+0x17805>
   5a4a3:      	cmpq	$0x0, 0x193fd(%rip)     # 0x738a8 <g.3>
   5a4ab:      	je	0x6e9c5 <f.2+0x17805>
   5a4b1:      	movq	%rax, %rcx
   5a4b4:      	addq	0x58(%rsp), %r15
   5a4b9:      	addq	%r13, %r15
   5a4bc:      	addq	%rbp, %rcx
   5a4bf:      	cmpq	$0xf, %r14
   5a4c3:      	jae	0x5c784 <f.2+0x55c4>
   5a4c9:      	leaq	0x28(%rsp), %r8
   5a4ce:      	leaq	0x20(%rsp), %rdi
   5a4d3:      	leaq	0x192ee(%rip), %r9      # 0x737c8 <native_roots.0>
   5a4da:      	jmp	0x5c809 <f.2+0x5649>
   5a4df:      	movq	%r12, %rbp
   5a4e2:      	movq	$0x0, 0x50(%rsp)
   5a4eb:      	movq	$0x3, 0x38(%rsp)
   5a4f4:      	xorl	%edi, %edi
   5a4f6:      	leaq	-0xd(%r14), %rsi
   5a4fa:      	callq	0x6e9d0 <f.3>
   5a4ff:      	subq	$0x8, %rsp
   5a503:      	cmpb	$0x0, 0x193a6(%rip)     # 0x738b0 <g.4>
   5a50a:      	je	0x6e9c5 <f.2+0x17805>
   5a510:      	cmpq	$0x0, 0x19390(%rip)     # 0x738a8 <g.3>
   5a518:      	je	0x6e9c5 <f.2+0x17805>
   5a51e:      	movq	%rax, %r12
   5a521:      	leaq	-0xe(%r14), %rsi
   5a525:      	movq	$0x0, 0x50(%rsp)
   5a52e:      	movq	$0x3, 0x38(%rsp)
   5a537:      	xorl	%edi, %edi
   5a539:      	callq	0x6e9d0 <f.3>
   5a53e:      	subq	$0x8, %rsp
   5a542:      	cmpb	$0x0, 0x19367(%rip)     # 0x738b0 <g.4>
   5a549:      	je	0x6e9c5 <f.2+0x17805>
   5a54f:      	addq	%r12, %rax
   5a552:      	leaq	0x28(%rsp), %r8
   5a557:      	leaq	0x20(%rsp), %rdi
   5a55c:      	leaq	0x19265(%rip), %r9      # 0x737c8 <native_roots.0>
   5a563:      	cmpq	$0x0, 0x1933d(%rip)     # 0x738a8 <g.3>
   5a56b:      	je	0x6e9c5 <f.2+0x17805>
   5a571:      	addq	%rbp, %rax
   5a574:      	addq	%r13, %rax
   5a577:      	movq	%rax, %r12
   5a57a:      	cmpq	$0xa, %r14
   5a57e:      	jne	0x57efe <f.2+0xd3e>
   5a584:      	leaq	(%r14,%r12), %r13
   5a588:      	addq	$-0x9, %r13
   5a58c:      	movl	$0x1, %eax
   5a591:      	leaq	(%r14,%rax), %r12
   5a595:      	addq	$-0xa, %r12
   5a599:      	jmp	0x580ba <f.2+0xefa>
   5a59e:      	movq	$0x0, 0x50(%rsp)
   5a5a7:      	movq	$0x3, 0x38(%rsp)
   5a5b0:      	xorl	%edi, %edi
   5a5b2:      	leaq	-0xe(%r14), %rsi
   5a5b6:      	callq	0x6e9d0 <f.3>
   5a5bb:      	subq	$0x8, %rsp
   5a5bf:      	cmpb	$0x0, 0x192ea(%rip)     # 0x738b0 <g.4>
   5a5c6:      	je	0x6e9c5 <f.2+0x17805>
   5a5cc:      	cmpq	$0x0, 0x192d4(%rip)     # 0x738a8 <g.3>
   5a5d4:      	je	0x6e9c5 <f.2+0x17805>
   5a5da:      	movq	%rax, %rbp
   5a5dd:      	leaq	-0xf(%r14), %rsi
   5a5e1:      	movq	$0x0, 0x50(%rsp)
   5a5ea:      	movq	$0x3, 0x38(%rsp)
   5a5f3:      	xorl	%edi, %edi
   5a5f5:      	callq	0x6e9d0 <f.3>
   5a5fa:      	subq	$0x8, %rsp
   5a5fe:      	cmpb	$0x0, 0x192ab(%rip)     # 0x738b0 <g.4>
   5a605:      	je	0x6e9c5 <f.2+0x17805>
   5a60b:      	movq	%rax, %rcx
   5a60e:      	cmpq	$0x0, 0x19292(%rip)     # 0x738a8 <g.3>
   5a616:      	leaq	0x28(%rsp), %r8
   5a61b:      	leaq	0x20(%rsp), %rdi
   5a620:      	leaq	0x191a1(%rip), %r9      # 0x737c8 <native_roots.0>
   5a627:      	movq	0x10(%rsp), %rax
   5a62c:      	je	0x6e9c5 <f.2+0x17805>
   5a632:      	addq	%rbp, %rcx
   5a635:      	addq	%r13, %rcx
   5a638:      	cmpq	$0xd, %r14
   5a63c:      	je	0x5a651 <f.2+0x3491>
   5a63e:      	cmpq	$0xe, %r14
   5a642:      	jne	0x5a667 <f.2+0x34a7>
   5a644:      	movl	$0x1, %edx
   5a649:      	xorl	%r13d, %r13d
   5a64c:      	jmp	0x5bffe <f.2+0x4e3e>
   5a651:      	leaq	(%r14,%rcx), %r13
   5a655:      	addq	$-0xc, %r13
   5a659:      	movl	$0x1, %ebp
   5a65e:      	leaq	-0xd(%r14), %rdx
   5a662:      	jmp	0x5f151 <f.2+0x7f91>
   5a667:      	movq	%rcx, 0x18(%rsp)
   5a66c:      	leaq	-0xe(%r14), %r13
   5a670:      	movq	$0x0, 0x50(%rsp)
   5a679:      	movq	$0x3, 0x38(%rsp)
   5a682:      	xorl	%edi, %edi
   5a684:      	movq	%r13, %rsi
   5a687:      	callq	0x6e9d0 <f.3>
   5a68c:      	subq	$0x8, %rsp
   5a690:      	cmpb	$0x0, 0x19219(%rip)     # 0x738b0 <g.4>
   5a697:      	je	0x6e9c5 <f.2+0x17805>
   5a69d:      	cmpq	$0x0, 0x19203(%rip)     # 0x738a8 <g.3>
   5a6a5:      	je	0x6e9c5 <f.2+0x17805>
   5a6ab:      	movq	%rax, %rbp
   5a6ae:      	leaq	-0xf(%r14), %rsi
   5a6b2:      	movq	$0x0, 0x50(%rsp)
   5a6bb:      	movq	$0x3, 0x38(%rsp)
   5a6c4:      	xorl	%edi, %edi
   5a6c6:      	callq	0x6e9d0 <f.3>
   5a6cb:      	subq	$0x8, %rsp
   5a6cf:      	cmpb	$0x0, 0x191da(%rip)     # 0x738b0 <g.4>
   5a6d6:      	je	0x6e9c5 <f.2+0x17805>
   5a6dc:      	movq	%rax, %rdx
   5a6df:      	cmpq	$0x0, 0x191c1(%rip)     # 0x738a8 <g.3>
   5a6e7:      	leaq	0x28(%rsp), %r8
   5a6ec:      	leaq	0x20(%rsp), %rdi
   5a6f1:      	leaq	0x190d0(%rip), %r9      # 0x737c8 <native_roots.0>
   5a6f8:      	movq	0x10(%rsp), %rax
   5a6fd:      	je	0x6e9c5 <f.2+0x17805>
   5a703:      	addq	%rbp, %rdx
   5a706:      	cmpq	$0x10, %r14
   5a70a:      	jae	0x5bf73 <f.2+0x4db3>
   5a710:      	movq	0x18(%rsp), %rcx
   5a715:      	jmp	0x5bffe <f.2+0x4e3e>
   5a71a:      	movq	$0x0, 0x50(%rsp)
   5a723:      	movq	$0x3, 0x38(%rsp)
   5a72c:      	xorl	%edi, %edi
   5a72e:      	leaq	-0xe(%r14), %rsi
   5a732:      	callq	0x6e9d0 <f.3>
   5a737:      	subq	$0x8, %rsp
   5a73b:      	cmpb	$0x0, 0x1916e(%rip)     # 0x738b0 <g.4>
   5a742:      	je	0x6e9c5 <f.2+0x17805>
   5a748:      	movq	%rax, 0x18(%rsp)
   5a74d:      	cmpq	$0x0, 0x19153(%rip)     # 0x738a8 <g.3>
   5a755:      	je	0x6e9c5 <f.2+0x17805>
   5a75b:      	leaq	-0xf(%r14), %rsi
   5a75f:      	movq	$0x0, 0x50(%rsp)
   5a768:      	movq	$0x3, 0x38(%rsp)
   5a771:      	xorl	%edi, %edi
   5a773:      	callq	0x6e9d0 <f.3>
   5a778:      	subq	$0x8, %rsp
   5a77c:      	movq	%rax, %rbp
   5a77f:      	addq	0x18(%rsp), %rbp
   5a784:      	leaq	0x28(%rsp), %r8
   5a789:      	leaq	0x20(%rsp), %rdi
   5a78e:      	leaq	0x19033(%rip), %r9      # 0x737c8 <native_roots.0>
   5a795:      	cmpb	$0x0, 0x19114(%rip)     # 0x738b0 <g.4>
   5a79c:      	je	0x6e9c5 <f.2+0x17805>
   5a7a2:      	cmpq	$0x0, 0x190fe(%rip)     # 0x738a8 <g.3>
   5a7aa:      	je	0x6e9c5 <f.2+0x17805>
   5a7b0:      	addq	%r13, %rbp
   5a7b3:      	addq	%r15, %rbp
   5a7b6:      	movq	%r14, %r15
   5a7b9:      	subq	$0xd, %r15
   5a7bd:      	jbe	0x5a85a <f.2+0x369a>
   5a7c3:      	movq	$0x0, 0x50(%rsp)
   5a7cc:      	movq	$0x3, 0x38(%rsp)
   5a7d5:      	xorl	%edi, %edi
   5a7d7:      	movq	%r15, %rsi
   5a7da:      	callq	0x6e9d0 <f.3>
   5a7df:      	subq	$0x8, %rsp
   5a7e3:      	cmpb	$0x0, 0x190c6(%rip)     # 0x738b0 <g.4>
   5a7ea:      	je	0x6e9c5 <f.2+0x17805>
   5a7f0:      	cmpq	$0x0, 0x190b0(%rip)     # 0x738a8 <g.3>
   5a7f8:      	je	0x6e9c5 <f.2+0x17805>
   5a7fe:      	movq	%rax, %r13
   5a801:      	leaq	-0xe(%r14), %rsi
   5a805:      	movq	$0x0, 0x50(%rsp)
   5a80e:      	movq	$0x3, 0x38(%rsp)
   5a817:      	xorl	%edi, %edi
   5a819:      	callq	0x6e9d0 <f.3>
   5a81e:      	subq	$0x8, %rsp
   5a822:      	cmpb	$0x0, 0x19087(%rip)     # 0x738b0 <g.4>
   5a829:      	je	0x6e9c5 <f.2+0x17805>
   5a82f:      	cmpq	$0x0, 0x19071(%rip)     # 0x738a8 <g.3>
   5a837:      	je	0x6e9c5 <f.2+0x17805>
   5a83d:      	addq	%r13, %rax
   5a840:      	cmpq	$0xe, %r14
   5a844:      	jne	0x5ab0b <f.2+0x394b>
   5a84a:      	addq	%rax, %r15
   5a84d:      	movl	$0x1, %r13d
   5a853:      	xorl	%eax, %eax
   5a855:      	jmp	0x5d683 <f.2+0x64c3>
   5a85a:      	incq	%r15
   5a85d:      	leaq	-0xc(%r14), %r13
   5a861:      	jmp	0x5d697 <f.2+0x64d7>
   5a866:      	movq	$0x0, 0x50(%rsp)
   5a86f:      	movq	$0x3, 0x38(%rsp)
   5a878:      	xorl	%edi, %edi
   5a87a:      	leaq	-0xe(%r14), %rsi
   5a87e:      	callq	0x6e9d0 <f.3>
   5a883:      	subq	$0x8, %rsp
   5a887:      	cmpb	$0x0, 0x19022(%rip)     # 0x738b0 <g.4>
   5a88e:      	je	0x6e9c5 <f.2+0x17805>
   5a894:      	cmpq	$0x0, 0x1900c(%rip)     # 0x738a8 <g.3>
   5a89c:      	je	0x6e9c5 <f.2+0x17805>
   5a8a2:      	movq	%rax, %r13
   5a8a5:      	leaq	-0xf(%r14), %rsi
   5a8a9:      	movq	$0x0, 0x50(%rsp)
   5a8b2:      	movq	$0x3, 0x38(%rsp)
   5a8bb:      	xorl	%edi, %edi
   5a8bd:      	callq	0x6e9d0 <f.3>
   5a8c2:      	subq	$0x8, %rsp
   5a8c6:      	addq	%r13, %rax
   5a8c9:      	movq	%rax, %rcx
   5a8cc:      	leaq	0x28(%rsp), %r8
   5a8d1:      	leaq	0x20(%rsp), %rdi
   5a8d6:      	leaq	0x18eeb(%rip), %r9      # 0x737c8 <native_roots.0>
   5a8dd:      	movq	0x10(%rsp), %rax
   5a8e2:      	cmpb	$0x0, 0x18fc7(%rip)     # 0x738b0 <g.4>
   5a8e9:      	je	0x6e9c5 <f.2+0x17805>
   5a8ef:      	cmpq	$0x0, 0x18fb1(%rip)     # 0x738a8 <g.3>
   5a8f7:      	je	0x6e9c5 <f.2+0x17805>
   5a8fd:      	addq	%rbp, %rcx
   5a900:      	addq	%r15, %rcx
   5a903:      	movq	%r14, %rbp
   5a906:      	subq	$0xd, %rbp
   5a90a:      	jbe	0x5a9c5 <f.2+0x3805>
   5a910:      	movq	%rcx, 0x18(%rsp)
   5a915:      	movq	$0x0, 0x50(%rsp)
   5a91e:      	movq	$0x3, 0x38(%rsp)
   5a927:      	xorl	%edi, %edi
   5a929:      	movq	%rbp, %rsi
   5a92c:      	callq	0x6e9d0 <f.3>
   5a931:      	subq	$0x8, %rsp
   5a935:      	cmpb	$0x0, 0x18f74(%rip)     # 0x738b0 <g.4>
   5a93c:      	je	0x6e9c5 <f.2+0x17805>
   5a942:      	cmpq	$0x0, 0x18f5e(%rip)     # 0x738a8 <g.3>
   5a94a:      	je	0x6e9c5 <f.2+0x17805>
   5a950:      	movq	%rax, %r15
   5a953:      	leaq	-0xe(%r14), %rsi
   5a957:      	movq	$0x0, 0x50(%rsp)
   5a960:      	movq	$0x3, 0x38(%rsp)
   5a969:      	xorl	%edi, %edi
   5a96b:      	callq	0x6e9d0 <f.3>
   5a970:      	subq	$0x8, %rsp
   5a974:      	cmpb	$0x0, 0x18f35(%rip)     # 0x738b0 <g.4>
   5a97b:      	je	0x6e9c5 <f.2+0x17805>
   5a981:      	movq	%rax, %rcx
   5a984:      	cmpq	$0x0, 0x18f1c(%rip)     # 0x738a8 <g.3>
   5a98c:      	leaq	0x20(%rsp), %rdi
   5a991:      	movq	0x10(%rsp), %rax
   5a996:      	je	0x6e9c5 <f.2+0x17805>
   5a99c:      	addq	%r15, %rcx
   5a99f:      	cmpq	$0xe, %r14
   5a9a3:      	jne	0x5ac45 <f.2+0x3a85>
   5a9a9:      	addq	%rcx, %rbp
   5a9ac:      	movl	$0x1, %r15d
   5a9b2:      	xorl	%ecx, %ecx
   5a9b4:      	leaq	0x28(%rsp), %r8
   5a9b9:      	leaq	0x18e08(%rip), %r9      # 0x737c8 <native_roots.0>
   5a9c0:      	jmp	0x5e1b5 <f.2+0x6ff5>
   5a9c5:      	incq	%rbp
   5a9c8:      	leaq	-0xc(%r14), %r15
   5a9cc:      	jmp	0x5e1bd <f.2+0x6ffd>
   5a9d1:      	movq	%rax, 0x18(%rsp)
   5a9d6:      	movq	$0x0, 0x50(%rsp)
   5a9df:      	movq	$0x3, 0x38(%rsp)
   5a9e8:      	xorl	%edi, %edi
   5a9ea:      	leaq	-0xe(%r14), %r15
   5a9ee:      	movq	%r15, %rsi
   5a9f1:      	callq	0x6e9d0 <f.3>
   5a9f6:      	subq	$0x8, %rsp
   5a9fa:      	cmpb	$0x0, 0x18eaf(%rip)     # 0x738b0 <g.4>
   5aa01:      	je	0x6e9c5 <f.2+0x17805>
   5aa07:      	movq	%rax, 0x58(%rsp)
   5aa0c:      	cmpq	$0x0, 0x18e94(%rip)     # 0x738a8 <g.3>
   5aa14:      	je	0x6e9c5 <f.2+0x17805>
   5aa1a:      	leaq	-0xf(%r14), %rsi
   5aa1e:      	movq	$0x0, 0x50(%rsp)
   5aa27:      	movq	$0x3, 0x38(%rsp)
   5aa30:      	xorl	%edi, %edi
   5aa32:      	callq	0x6e9d0 <f.3>
   5aa37:      	subq	$0x8, %rsp
   5aa3b:      	cmpb	$0x0, 0x18e6e(%rip)     # 0x738b0 <g.4>
   5aa42:      	je	0x6e9c5 <f.2+0x17805>
   5aa48:      	cmpq	$0x0, 0x18e58(%rip)     # 0x738a8 <g.3>
   5aa50:      	je	0x6e9c5 <f.2+0x17805>
   5aa56:      	movq	%rax, %r13
   5aa59:      	movq	$0x0, 0x50(%rsp)
   5aa62:      	movq	$0x3, 0x38(%rsp)
   5aa6b:      	xorl	%edi, %edi
   5aa6d:      	movq	%r15, %rsi
   5aa70:      	callq	0x6e9d0 <f.3>
   5aa75:      	subq	$0x8, %rsp
   5aa79:      	cmpb	$0x0, 0x18e30(%rip)     # 0x738b0 <g.4>
   5aa80:      	je	0x6e9c5 <f.2+0x17805>
   5aa86:      	movq	%rax, 0x60(%rsp)
   5aa8b:      	cmpq	$0x0, 0x18e15(%rip)     # 0x738a8 <g.3>
   5aa93:      	je	0x6e9c5 <f.2+0x17805>
   5aa99:      	movq	$0x0, 0x50(%rsp)
   5aaa2:      	movq	$0x3, 0x38(%rsp)
   5aaab:      	xorl	%edi, %edi
   5aaad:      	leaq	-0xf(%r14), %rsi
   5aab1:      	callq	0x6e9d0 <f.3>
   5aab6:      	subq	$0x8, %rsp
   5aaba:      	cmpb	$0x0, 0x18def(%rip)     # 0x738b0 <g.4>
   5aac1:      	je	0x6e9c5 <f.2+0x17805>
   5aac7:      	cmpq	$0x0, 0x18dd9(%rip)     # 0x738a8 <g.3>
   5aacf:      	leaq	0x28(%rsp), %r8
   5aad4:      	leaq	0x18ced(%rip), %r9      # 0x737c8 <native_roots.0>
   5aadb:      	je	0x6e9c5 <f.2+0x17805>
   5aae1:      	movq	%rax, %r15
   5aae4:      	addq	0x58(%rsp), %r13
   5aae9:      	addq	0x18(%rsp), %r13
   5aaee:      	addq	0x60(%rsp), %r15
   5aaf3:      	cmpq	$0x10, %r14
   5aaf7:      	jae	0x5cb11 <f.2+0x5951>
   5aafd:      	leaq	0x20(%rsp), %rdi
   5ab02:      	leaq	-0xe(%r14), %rax
   5ab06:      	jmp	0x5cb89 <f.2+0x59c9>
   5ab0b:      	movq	%rax, 0x18(%rsp)
   5ab10:      	movq	$0x0, 0x50(%rsp)
   5ab19:      	movq	$0x3, 0x38(%rsp)
   5ab22:      	xorl	%edi, %edi
   5ab24:      	leaq	-0xe(%r14), %r13
   5ab28:      	movq	%r13, %rsi
   5ab2b:      	callq	0x6e9d0 <f.3>
   5ab30:      	subq	$0x8, %rsp
   5ab34:      	cmpb	$0x0, 0x18d75(%rip)     # 0x738b0 <g.4>
   5ab3b:      	je	0x6e9c5 <f.2+0x17805>
   5ab41:      	movq	%rax, 0x58(%rsp)
   5ab46:      	cmpq	$0x0, 0x18d5a(%rip)     # 0x738a8 <g.3>
   5ab4e:      	je	0x6e9c5 <f.2+0x17805>
   5ab54:      	leaq	-0xf(%r14), %rsi
   5ab58:      	movq	$0x0, 0x50(%rsp)
   5ab61:      	movq	$0x3, 0x38(%rsp)
   5ab6a:      	xorl	%edi, %edi
   5ab6c:      	callq	0x6e9d0 <f.3>
   5ab71:      	subq	$0x8, %rsp
   5ab75:      	cmpb	$0x0, 0x18d34(%rip)     # 0x738b0 <g.4>
   5ab7c:      	je	0x6e9c5 <f.2+0x17805>
   5ab82:      	cmpq	$0x0, 0x18d1e(%rip)     # 0x738a8 <g.3>
   5ab8a:      	je	0x6e9c5 <f.2+0x17805>
   5ab90:      	movq	%rax, %r15
   5ab93:      	movq	$0x0, 0x50(%rsp)
   5ab9c:      	movq	$0x3, 0x38(%rsp)
   5aba5:      	xorl	%edi, %edi
   5aba7:      	movq	%r13, %rsi
   5abaa:      	callq	0x6e9d0 <f.3>
   5abaf:      	subq	$0x8, %rsp
   5abb3:      	cmpb	$0x0, 0x18cf6(%rip)     # 0x738b0 <g.4>
   5abba:      	je	0x6e9c5 <f.2+0x17805>
   5abc0:      	movq	%rax, 0x60(%rsp)
   5abc5:      	cmpq	$0x0, 0x18cdb(%rip)     # 0x738a8 <g.3>
   5abcd:      	je	0x6e9c5 <f.2+0x17805>
   5abd3:      	movq	$0x0, 0x50(%rsp)
   5abdc:      	movq	$0x3, 0x38(%rsp)
   5abe5:      	xorl	%edi, %edi
   5abe7:      	leaq	-0xf(%r14), %rsi
   5abeb:      	callq	0x6e9d0 <f.3>
   5abf0:      	subq	$0x8, %rsp
   5abf4:      	cmpb	$0x0, 0x18cb5(%rip)     # 0x738b0 <g.4>
   5abfb:      	je	0x6e9c5 <f.2+0x17805>
   5ac01:      	cmpq	$0x0, 0x18c9f(%rip)     # 0x738a8 <g.3>
   5ac09:      	leaq	0x28(%rsp), %r8
   5ac0e:      	leaq	0x18bb3(%rip), %r9      # 0x737c8 <native_roots.0>
   5ac15:      	je	0x6e9c5 <f.2+0x17805>
   5ac1b:      	movq	%rax, %r13
   5ac1e:      	addq	0x58(%rsp), %r15
   5ac23:      	addq	0x18(%rsp), %r15
   5ac28:      	addq	0x60(%rsp), %r13
   5ac2d:      	cmpq	$0x10, %r14
   5ac31:      	jae	0x5d61c <f.2+0x645c>
   5ac37:      	leaq	0x20(%rsp), %rdi
   5ac3c:      	leaq	-0xe(%r14), %rax
   5ac40:      	jmp	0x5d694 <f.2+0x64d4>
   5ac45:      	movq	%rcx, 0x58(%rsp)
   5ac4a:      	movq	$0x0, 0x50(%rsp)
   5ac53:      	movq	$0x3, 0x38(%rsp)
   5ac5c:      	xorl	%edi, %edi
   5ac5e:      	leaq	-0xe(%r14), %rsi
   5ac62:      	callq	0x6e9d0 <f.3>
   5ac67:      	subq	$0x8, %rsp
   5ac6b:      	cmpb	$0x0, 0x18c3e(%rip)     # 0x738b0 <g.4>
   5ac72:      	je	0x6e9c5 <f.2+0x17805>
   5ac78:      	movq	%rax, 0x60(%rsp)
   5ac7d:      	cmpq	$0x0, 0x18c23(%rip)     # 0x738a8 <g.3>
   5ac85:      	je	0x6e9c5 <f.2+0x17805>
   5ac8b:      	leaq	-0xf(%r14), %r15
   5ac8f:      	movq	$0x0, 0x50(%rsp)
   5ac98:      	movq	$0x3, 0x38(%rsp)
   5aca1:      	xorl	%edi, %edi
   5aca3:      	movq	%r15, %rsi
   5aca6:      	callq	0x6e9d0 <f.3>
   5acab:      	subq	$0x8, %rsp
   5acaf:      	cmpb	$0x0, 0x18bfa(%rip)     # 0x738b0 <g.4>
   5acb6:      	je	0x6e9c5 <f.2+0x17805>
   5acbc:      	cmpq	$0x0, 0x18be4(%rip)     # 0x738a8 <g.3>
   5acc4:      	je	0x6e9c5 <f.2+0x17805>
   5acca:      	movq	%rax, %rbp
   5accd:      	movq	$0x0, 0x50(%rsp)
   5acd6:      	movq	$0x3, 0x38(%rsp)
   5acdf:      	xorl	%edi, %edi
   5ace1:      	leaq	-0xe(%r14), %rsi
   5ace5:      	callq	0x6e9d0 <f.3>
   5acea:      	subq	$0x8, %rsp
   5acee:      	cmpb	$0x0, 0x18bbb(%rip)     # 0x738b0 <g.4>
   5acf5:      	je	0x6e9c5 <f.2+0x17805>
   5acfb:      	cmpq	$0x0, 0x18ba5(%rip)     # 0x738a8 <g.3>
   5ad03:      	je	0x6e9c5 <f.2+0x17805>
   5ad09:      	movq	%rax, %r13
   5ad0c:      	movq	$0x0, 0x50(%rsp)
   5ad15:      	movq	$0x3, 0x38(%rsp)
   5ad1e:      	xorl	%edi, %edi
   5ad20:      	movq	%r15, %rsi
   5ad23:      	callq	0x6e9d0 <f.3>
   5ad28:      	subq	$0x8, %rsp
   5ad2c:      	cmpb	$0x0, 0x18b7d(%rip)     # 0x738b0 <g.4>
   5ad33:      	je	0x6e9c5 <f.2+0x17805>
   5ad39:      	movq	%rax, %r15
   5ad3c:      	cmpq	$0x0, 0x18b64(%rip)     # 0x738a8 <g.3>
   5ad44:      	leaq	0x20(%rsp), %rdi
   5ad49:      	movq	0x10(%rsp), %rax
   5ad4e:      	movq	0x58(%rsp), %rcx
   5ad53:      	je	0x6e9c5 <f.2+0x17805>
   5ad59:      	addq	0x60(%rsp), %rbp
   5ad5e:      	addq	%rcx, %rbp
   5ad61:      	addq	%r13, %r15
   5ad64:      	cmpq	$0x10, %r14
   5ad68:      	jae	0x5e139 <f.2+0x6f79>
   5ad6e:      	leaq	0x28(%rsp), %r8
   5ad73:      	leaq	0x18a4e(%rip), %r9      # 0x737c8 <native_roots.0>
   5ad7a:      	leaq	-0xe(%r14), %rcx
   5ad7e:      	jmp	0x5e1b5 <f.2+0x6ff5>
   5ad83:      	movq	%rax, 0x58(%rsp)
   5ad88:      	movq	$0x0, 0x50(%rsp)
   5ad91:      	movq	$0x3, 0x38(%rsp)
   5ad9a:      	xorl	%edi, %edi
   5ad9c:      	movq	%rbp, %rsi
   5ad9f:      	callq	0x6e9d0 <f.3>
   5ada4:      	subq	$0x8, %rsp
   5ada8:      	cmpb	$0x0, 0x18b01(%rip)     # 0x738b0 <g.4>
   5adaf:      	movq	0x10(%rsp), %r12
   5adb4:      	je	0x6e9c5 <f.2+0x17805>
   5adba:      	movq	%rax, 0x60(%rsp)
   5adbf:      	cmpq	$0x0, 0x18ae1(%rip)     # 0x738a8 <g.3>
   5adc7:      	je	0x6e9c5 <f.2+0x17805>
   5adcd:      	leaq	-0xf(%r14), %rsi
   5add1:      	movq	$0x0, 0x50(%rsp)
   5adda:      	movq	$0x3, 0x38(%rsp)
   5ade3:      	xorl	%edi, %edi
   5ade5:      	callq	0x6e9d0 <f.3>
   5adea:      	subq	$0x8, %rsp
   5adee:      	cmpb	$0x0, 0x18abb(%rip)     # 0x738b0 <g.4>
   5adf5:      	je	0x6e9c5 <f.2+0x17805>
   5adfb:      	movq	%rax, 0x18(%rsp)
   5ae00:      	cmpq	$0x0, 0x18aa0(%rip)     # 0x738a8 <g.3>
   5ae08:      	je	0x6e9c5 <f.2+0x17805>
   5ae0e:      	movq	$0x0, 0x50(%rsp)
   5ae17:      	movq	$0x3, 0x38(%rsp)
   5ae20:      	xorl	%edi, %edi
   5ae22:      	movq	%rbp, %rsi
   5ae25:      	callq	0x6e9d0 <f.3>
   5ae2a:      	subq	$0x8, %rsp
   5ae2e:      	cmpb	$0x0, 0x18a7b(%rip)     # 0x738b0 <g.4>
   5ae35:      	je	0x6e9c5 <f.2+0x17805>
   5ae3b:      	movq	%rax, 0x68(%rsp)
   5ae40:      	cmpq	$0x0, 0x18a60(%rip)     # 0x738a8 <g.3>
   5ae48:      	je	0x6e9c5 <f.2+0x17805>
   5ae4e:      	movq	$0x0, 0x50(%rsp)
   5ae57:      	movq	$0x3, 0x38(%rsp)
   5ae60:      	xorl	%edi, %edi
   5ae62:      	leaq	-0xf(%r14), %rsi
   5ae66:      	callq	0x6e9d0 <f.3>
   5ae6b:      	subq	$0x8, %rsp
   5ae6f:      	cmpb	$0x0, 0x18a3a(%rip)     # 0x738b0 <g.4>
   5ae76:      	je	0x6e9c5 <f.2+0x17805>
   5ae7c:      	movq	%rax, %rbp
   5ae7f:      	cmpq	$0x0, 0x18a21(%rip)     # 0x738a8 <g.3>
   5ae87:      	leaq	0x20(%rsp), %rdi
   5ae8c:      	movq	0x18(%rsp), %rsi
   5ae91:      	movq	0x58(%rsp), %rax
   5ae96:      	je	0x6e9c5 <f.2+0x17805>
   5ae9c:      	addq	0x60(%rsp), %rsi
   5aea1:      	addq	%rax, %rsi
   5aea4:      	addq	0x68(%rsp), %rbp
   5aea9:      	cmpq	$0x10, %r14
   5aead:      	jae	0x5e1ff <f.2+0x703f>
   5aeb3:      	leaq	0x28(%rsp), %r8
   5aeb8:      	leaq	0x18909(%rip), %r9      # 0x737c8 <native_roots.0>
   5aebf:      	leaq	-0xe(%r14), %rax
   5aec3:      	addq	%rax, %rbp
   5aec6:      	jmp	0x5e292 <f.2+0x70d2>
   5aecb:      	movq	%rcx, 0x10(%rsp)
   5aed0:      	movq	$0x0, 0x50(%rsp)
   5aed9:      	movq	$0x3, 0x38(%rsp)
   5aee2:      	xorl	%edi, %edi
   5aee4:      	leaq	-0xe(%r14), %rbp
   5aee8:      	movq	%rbp, %rsi
   5aeeb:      	callq	0x6e9d0 <f.3>
   5aef0:      	subq	$0x8, %rsp
   5aef4:      	cmpb	$0x0, 0x189b5(%rip)     # 0x738b0 <g.4>
   5aefb:      	je	0x6e9c5 <f.2+0x17805>
   5af01:      	movq	%rax, 0x60(%rsp)
   5af06:      	cmpq	$0x0, 0x1899a(%rip)     # 0x738a8 <g.3>
   5af0e:      	je	0x6e9c5 <f.2+0x17805>
   5af14:      	leaq	-0xf(%r14), %rsi
   5af18:      	movq	$0x0, 0x50(%rsp)
   5af21:      	movq	$0x3, 0x38(%rsp)
   5af2a:      	xorl	%edi, %edi
   5af2c:      	callq	0x6e9d0 <f.3>
   5af31:      	subq	$0x8, %rsp
   5af35:      	cmpb	$0x0, 0x18974(%rip)     # 0x738b0 <g.4>
   5af3c:      	je	0x6e9c5 <f.2+0x17805>
   5af42:      	cmpq	$0x0, 0x1895e(%rip)     # 0x738a8 <g.3>
   5af4a:      	je	0x6e9c5 <f.2+0x17805>
   5af50:      	movq	%rax, %r13
   5af53:      	movq	$0x0, 0x50(%rsp)
   5af5c:      	movq	$0x3, 0x38(%rsp)
   5af65:      	xorl	%edi, %edi
   5af67:      	movq	%rbp, %rsi
   5af6a:      	callq	0x6e9d0 <f.3>
   5af6f:      	subq	$0x8, %rsp
   5af73:      	cmpb	$0x0, 0x18936(%rip)     # 0x738b0 <g.4>
   5af7a:      	je	0x6e9c5 <f.2+0x17805>
   5af80:      	movq	%rax, 0x68(%rsp)
   5af85:      	cmpq	$0x0, 0x1891b(%rip)     # 0x738a8 <g.3>
   5af8d:      	je	0x6e9c5 <f.2+0x17805>
   5af93:      	movq	$0x0, 0x50(%rsp)
   5af9c:      	movq	$0x3, 0x38(%rsp)
   5afa5:      	xorl	%edi, %edi
   5afa7:      	leaq	-0xf(%r14), %rsi
   5afab:      	callq	0x6e9d0 <f.3>
   5afb0:      	subq	$0x8, %rsp
   5afb4:      	cmpb	$0x0, 0x188f5(%rip)     # 0x738b0 <g.4>
   5afbb:      	je	0x6e9c5 <f.2+0x17805>
   5afc1:      	cmpq	$0x0, 0x188df(%rip)     # 0x738a8 <g.3>
   5afc9:      	movq	0x10(%rsp), %rcx
   5afce:      	je	0x6e9c5 <f.2+0x17805>
   5afd4:      	movq	%rax, %rbp
   5afd7:      	addq	0x60(%rsp), %r13
   5afdc:      	addq	%r12, %r13
   5afdf:      	addq	0x68(%rsp), %rbp
   5afe4:      	cmpq	$0x10, %r14
   5afe8:      	jae	0x5e65e <f.2+0x749e>
   5afee:      	leaq	0x28(%rsp), %r8
   5aff3:      	leaq	0x20(%rsp), %rdi
   5aff8:      	leaq	0x187c9(%rip), %r9      # 0x737c8 <native_roots.0>
   5afff:      	jmp	0x5e6dc <f.2+0x751c>
   5b004:      	movq	$0x0, 0x50(%rsp)
   5b00d:      	movq	$0x3, 0x38(%rsp)
   5b016:      	xorl	%edi, %edi
   5b018:      	leaq	-0xe(%r14), %rsi
   5b01c:      	callq	0x6e9d0 <f.3>
   5b021:      	subq	$0x8, %rsp
   5b025:      	cmpb	$0x0, 0x18884(%rip)     # 0x738b0 <g.4>
   5b02c:      	je	0x6e9c5 <f.2+0x17805>
   5b032:      	cmpq	$0x0, 0x1886e(%rip)     # 0x738a8 <g.3>
   5b03a:      	je	0x6e9c5 <f.2+0x17805>
   5b040:      	movq	%rax, %r12
   5b043:      	leaq	-0xf(%r14), %rsi
   5b047:      	movq	$0x0, 0x50(%rsp)
   5b050:      	movq	$0x3, 0x38(%rsp)
   5b059:      	xorl	%edi, %edi
   5b05b:      	callq	0x6e9d0 <f.3>
   5b060:      	subq	$0x8, %rsp
   5b064:      	cmpb	$0x0, 0x18845(%rip)     # 0x738b0 <g.4>
   5b06b:      	je	0x6e9c5 <f.2+0x17805>
   5b071:      	addq	%r12, %rax
   5b074:      	addq	%rax, %r13
   5b077:      	leaq	0x28(%rsp), %r8
   5b07c:      	leaq	0x20(%rsp), %rdi
   5b081:      	leaq	0x18740(%rip), %r9      # 0x737c8 <native_roots.0>
   5b088:      	movq	0x10(%rsp), %r12
   5b08d:      	cmpq	$0x0, 0x18813(%rip)     # 0x738a8 <g.3>
   5b095:      	je	0x6e9c5 <f.2+0x17805>
   5b09b:      	addq	%rbp, %r13
   5b09e:      	addq	%r12, %r13
   5b0a1:      	cmpq	$0xb, %r14
   5b0a5:      	jbe	0x5b0b9 <f.2+0x3ef9>
   5b0a7:      	cmpq	$0xc, %r14
   5b0ab:      	jne	0x5b0ca <f.2+0x3f0a>
   5b0ad:      	movl	$0x1, %ebp
   5b0b2:      	xorl	%eax, %eax
   5b0b4:      	jmp	0x5b1fa <f.2+0x403a>
   5b0b9:      	leaq	-0xa(%r14), %rax
   5b0bd:      	leaq	(%r14,%rax), %r12
   5b0c1:      	addq	$-0xa, %r12
   5b0c5:      	jmp	0x580ba <f.2+0xefa>
   5b0ca:      	leaq	-0xc(%r14), %rsi
   5b0ce:      	movq	$0x0, 0x50(%rsp)
   5b0d7:      	movq	$0x3, 0x38(%rsp)
   5b0e0:      	xorl	%edi, %edi
   5b0e2:      	callq	0x6e9d0 <f.3>
   5b0e7:      	subq	$0x8, %rsp
   5b0eb:      	cmpb	$0x0, 0x187be(%rip)     # 0x738b0 <g.4>
   5b0f2:      	je	0x6e9c5 <f.2+0x17805>
   5b0f8:      	cmpq	$0x0, 0x187a8(%rip)     # 0x738a8 <g.3>
   5b100:      	je	0x6e9c5 <f.2+0x17805>
   5b106:      	movq	%rax, %r12
   5b109:      	leaq	-0xd(%r14), %rsi
   5b10d:      	movq	$0x0, 0x50(%rsp)
   5b116:      	movq	$0x3, 0x38(%rsp)
   5b11f:      	xorl	%edi, %edi
   5b121:      	callq	0x6e9d0 <f.3>
   5b126:      	subq	$0x8, %rsp
   5b12a:      	cmpb	$0x0, 0x1877f(%rip)     # 0x738b0 <g.4>
   5b131:      	je	0x6e9c5 <f.2+0x17805>
   5b137:      	movq	%rax, %rbp
   5b13a:      	cmpq	$0x0, 0x18766(%rip)     # 0x738a8 <g.3>
   5b142:      	leaq	-0xc(%r14), %rax
   5b146:      	je	0x6e9c5 <f.2+0x17805>
   5b14c:      	addq	%r12, %rbp
   5b14f:      	cmpq	$0xd, %r14
   5b153:      	ja	0x5b16b <f.2+0x3fab>
   5b155:      	leaq	0x28(%rsp), %r8
   5b15a:      	leaq	0x20(%rsp), %rdi
   5b15f:      	leaq	0x18662(%rip), %r9      # 0x737c8 <native_roots.0>
   5b166:      	jmp	0x5b1fa <f.2+0x403a>
   5b16b:      	movq	$0x0, 0x50(%rsp)
   5b174:      	movq	$0x3, 0x38(%rsp)
   5b17d:      	xorl	%edi, %edi
   5b17f:      	leaq	-0xd(%r14), %rsi
   5b183:      	callq	0x6e9d0 <f.3>
   5b188:      	subq	$0x8, %rsp
   5b18c:      	cmpb	$0x0, 0x1871d(%rip)     # 0x738b0 <g.4>
   5b193:      	je	0x6e9c5 <f.2+0x17805>
   5b199:      	cmpq	$0x0, 0x18707(%rip)     # 0x738a8 <g.3>
   5b1a1:      	je	0x6e9c5 <f.2+0x17805>
   5b1a7:      	movq	%rax, %r12
   5b1aa:      	leaq	-0xe(%r14), %rsi
   5b1ae:      	movq	$0x0, 0x50(%rsp)
   5b1b7:      	movq	$0x3, 0x38(%rsp)
   5b1c0:      	xorl	%edi, %edi
   5b1c2:      	callq	0x6e9d0 <f.3>
   5b1c7:      	subq	$0x8, %rsp
   5b1cb:      	cmpb	$0x0, 0x186de(%rip)     # 0x738b0 <g.4>
   5b1d2:      	je	0x6e9c5 <f.2+0x17805>
   5b1d8:      	cmpq	$0x0, 0x186c8(%rip)     # 0x738a8 <g.3>
   5b1e0:      	leaq	0x28(%rsp), %r8
   5b1e5:      	leaq	0x20(%rsp), %rdi
   5b1ea:      	leaq	0x185d7(%rip), %r9      # 0x737c8 <native_roots.0>
   5b1f1:      	je	0x6e9c5 <f.2+0x17805>
   5b1f7:      	addq	%r12, %rax
   5b1fa:      	addq	%rbp, %rax
   5b1fd:      	cmpq	$0xc, %r14
   5b201:      	je	0x5b22a <f.2+0x406a>
   5b203:      	cmpq	$0xd, %r14
   5b207:      	jne	0x5b23f <f.2+0x407f>
   5b209:      	cmpq	$0x0, 0x18697(%rip)     # 0x738a8 <g.3>
   5b211:      	je	0x6e9c5 <f.2+0x17805>
   5b217:      	incq	%rax
   5b21a:      	leaq	-0xd(%r14), %rbp
   5b21e:      	incq	%rbp
   5b221:      	leaq	-0xc(%r14), %r12
   5b225:      	jmp	0x5edbe <f.2+0x7bfe>
   5b22a:      	addq	%r14, %rax
   5b22d:      	addq	$-0xb, %rax
   5b231:      	movl	$0x1, %ebp
   5b236:      	leaq	-0xc(%r14), %r12
   5b23a:      	jmp	0x5edbe <f.2+0x7bfe>
   5b23f:      	movq	%rax, 0x10(%rsp)
   5b244:      	leaq	-0xd(%r14), %rsi
   5b248:      	movq	$0x0, 0x50(%rsp)
   5b251:      	movq	$0x3, 0x38(%rsp)
   5b25a:      	xorl	%edi, %edi
   5b25c:      	callq	0x6e9d0 <f.3>
   5b261:      	subq	$0x8, %rsp
   5b265:      	cmpb	$0x0, 0x18644(%rip)     # 0x738b0 <g.4>
   5b26c:      	je	0x6e9c5 <f.2+0x17805>
   5b272:      	cmpq	$0x0, 0x1862e(%rip)     # 0x738a8 <g.3>
   5b27a:      	je	0x6e9c5 <f.2+0x17805>
   5b280:      	movq	%rax, %r12
   5b283:      	leaq	-0xe(%r14), %rsi
   5b287:      	movq	$0x0, 0x50(%rsp)
   5b290:      	movq	$0x3, 0x38(%rsp)
   5b299:      	xorl	%edi, %edi
   5b29b:      	callq	0x6e9d0 <f.3>
   5b2a0:      	subq	$0x8, %rsp
   5b2a4:      	cmpb	$0x0, 0x18605(%rip)     # 0x738b0 <g.4>
   5b2ab:      	je	0x6e9c5 <f.2+0x17805>
   5b2b1:      	cmpq	$0x0, 0x185ef(%rip)     # 0x738a8 <g.3>
   5b2b9:      	je	0x6e9c5 <f.2+0x17805>
   5b2bf:      	movq	%rax, %rbp
   5b2c2:      	addq	%r12, %rbp
   5b2c5:      	cmpq	$0xe, %r14
   5b2c9:      	ja	0x5b2e2 <f.2+0x4122>
   5b2cb:      	leaq	-0xd(%r14), %rcx
   5b2cf:      	addq	%rcx, %rbp
   5b2d2:      	addq	0x10(%rsp), %rbp
   5b2d7:      	movq	%rbp, %rax
   5b2da:      	movq	%rcx, %rbp
   5b2dd:      	jmp	0x5b389 <f.2+0x41c9>
   5b2e2:      	movq	$0x0, 0x50(%rsp)
   5b2eb:      	movq	$0x3, 0x38(%rsp)
   5b2f4:      	xorl	%edi, %edi
   5b2f6:      	leaq	-0xe(%r14), %rsi
   5b2fa:      	callq	0x6e9d0 <f.3>
   5b2ff:      	subq	$0x8, %rsp
   5b303:      	cmpb	$0x0, 0x185a6(%rip)     # 0x738b0 <g.4>
   5b30a:      	je	0x6e9c5 <f.2+0x17805>
   5b310:      	cmpq	$0x0, 0x18590(%rip)     # 0x738a8 <g.3>
   5b318:      	je	0x6e9c5 <f.2+0x17805>
   5b31e:      	movq	%rax, %r12
   5b321:      	leaq	-0xf(%r14), %rsi
   5b325:      	movq	$0x0, 0x50(%rsp)
   5b32e:      	movq	$0x3, 0x38(%rsp)
   5b337:      	xorl	%edi, %edi
   5b339:      	callq	0x6e9d0 <f.3>
   5b33e:      	subq	$0x8, %rsp
   5b342:      	cmpb	$0x0, 0x18567(%rip)     # 0x738b0 <g.4>
   5b349:      	je	0x6e9c5 <f.2+0x17805>
   5b34f:      	cmpq	$0x0, 0x18551(%rip)     # 0x738a8 <g.3>
   5b357:      	leaq	0x28(%rsp), %r8
   5b35c:      	leaq	0x20(%rsp), %rdi
   5b361:      	leaq	0x18460(%rip), %r9      # 0x737c8 <native_roots.0>
   5b368:      	movq	0x10(%rsp), %rcx
   5b36d:      	je	0x6e9c5 <f.2+0x17805>
   5b373:      	addq	%r12, %rax
   5b376:      	addq	%rbp, %rax
   5b379:      	addq	%rcx, %rax
   5b37c:      	movq	%r14, %rbp
   5b37f:      	subq	$0xd, %rbp
   5b383:      	jbe	0x5b21e <f.2+0x405e>
   5b389:      	movq	%rax, 0x10(%rsp)
   5b38e:      	movq	$0x0, 0x50(%rsp)
   5b397:      	movq	$0x3, 0x38(%rsp)
   5b3a0:      	xorl	%edi, %edi
   5b3a2:      	movq	%rbp, %rsi
   5b3a5:      	callq	0x6e9d0 <f.3>
   5b3aa:      	subq	$0x8, %rsp
   5b3ae:      	cmpb	$0x0, 0x184fb(%rip)     # 0x738b0 <g.4>
   5b3b5:      	je	0x6e9c5 <f.2+0x17805>
   5b3bb:      	cmpq	$0x0, 0x184e5(%rip)     # 0x738a8 <g.3>
   5b3c3:      	je	0x6e9c5 <f.2+0x17805>
   5b3c9:      	movq	%rax, %r12
   5b3cc:      	movq	$0x0, 0x50(%rsp)
   5b3d5:      	movq	$0x3, 0x38(%rsp)
   5b3de:      	xorl	%edi, %edi
   5b3e0:      	leaq	-0xe(%r14), %rsi
   5b3e4:      	callq	0x6e9d0 <f.3>
   5b3e9:      	subq	$0x8, %rsp
   5b3ed:      	cmpb	$0x0, 0x184bc(%rip)     # 0x738b0 <g.4>
   5b3f4:      	je	0x6e9c5 <f.2+0x17805>
   5b3fa:      	movq	%rax, %rcx
   5b3fd:      	cmpq	$0x0, 0x184a3(%rip)     # 0x738a8 <g.3>
   5b405:      	leaq	0x28(%rsp), %r8
   5b40a:      	leaq	0x183b7(%rip), %r9      # 0x737c8 <native_roots.0>
   5b411:      	movq	0x10(%rsp), %rax
   5b416:      	je	0x6e9c5 <f.2+0x17805>
   5b41c:      	addq	%r12, %rcx
   5b41f:      	cmpq	$0xe, %r14
   5b423:      	jne	0x5b57e <f.2+0x43be>
   5b429:      	addq	%rcx, %rbp
   5b42c:      	movl	$0x1, %r12d
   5b432:      	xorl	%ecx, %ecx
   5b434:      	leaq	0x20(%rsp), %rdi
   5b439:      	jmp	0x5edbb <f.2+0x7bfb>
   5b43e:      	movq	%rax, %rbp
   5b441:      	movq	$0x0, 0x50(%rsp)
   5b44a:      	movq	$0x3, 0x38(%rsp)
   5b453:      	xorl	%edi, %edi
   5b455:      	leaq	-0xd(%r14), %rsi
   5b459:      	callq	0x6e9d0 <f.3>
   5b45e:      	subq	$0x8, %rsp
   5b462:      	cmpb	$0x0, 0x18447(%rip)     # 0x738b0 <g.4>
   5b469:      	je	0x6e9c5 <f.2+0x17805>
   5b46f:      	cmpq	$0x0, 0x18431(%rip)     # 0x738a8 <g.3>
   5b477:      	je	0x6e9c5 <f.2+0x17805>
   5b47d:      	movq	%rax, %r13
   5b480:      	leaq	-0xe(%r14), %rsi
   5b484:      	movq	$0x0, 0x50(%rsp)
   5b48d:      	movq	$0x3, 0x38(%rsp)
   5b496:      	xorl	%edi, %edi
   5b498:      	callq	0x6e9d0 <f.3>
   5b49d:      	subq	$0x8, %rsp
   5b4a1:      	cmpb	$0x0, 0x18408(%rip)     # 0x738b0 <g.4>
   5b4a8:      	je	0x6e9c5 <f.2+0x17805>
   5b4ae:      	addq	%r13, %rax
   5b4b1:      	leaq	0x28(%rsp), %r8
   5b4b6:      	leaq	0x20(%rsp), %rdi
   5b4bb:      	leaq	0x18306(%rip), %r9      # 0x737c8 <native_roots.0>
   5b4c2:      	cmpq	$0x0, 0x183de(%rip)     # 0x738a8 <g.3>
   5b4ca:      	je	0x6e9c5 <f.2+0x17805>
   5b4d0:      	addq	%rbp, %rax
   5b4d3:      	addq	%r12, %rax
   5b4d6:      	movq	%rax, %r13
   5b4d9:      	cmpq	$0xa, %r14
   5b4dd:      	jne	0x57f91 <f.2+0xdd1>
   5b4e3:      	leaq	(%r14,%r13), %rcx
   5b4e7:      	addq	$-0x9, %rcx
   5b4eb:      	movl	$0x1, %ebp
   5b4f0:      	jmp	0x5bba9 <f.2+0x49e9>
   5b4f5:      	movq	$0x0, 0x50(%rsp)
   5b4fe:      	movq	$0x3, 0x38(%rsp)
   5b507:      	xorl	%edi, %edi
   5b509:      	leaq	-0xd(%r14), %rsi
   5b50d:      	callq	0x6e9d0 <f.3>
   5b512:      	subq	$0x8, %rsp
   5b516:      	cmpb	$0x0, 0x18393(%rip)     # 0x738b0 <g.4>
   5b51d:      	je	0x6e9c5 <f.2+0x17805>
   5b523:      	cmpq	$0x0, 0x1837d(%rip)     # 0x738a8 <g.3>
   5b52b:      	je	0x6e9c5 <f.2+0x17805>
   5b531:      	movq	%rax, %rbp
   5b534:      	leaq	-0xe(%r14), %rsi
   5b538:      	movq	$0x0, 0x50(%rsp)
   5b541:      	movq	$0x3, 0x38(%rsp)
   5b54a:      	xorl	%edi, %edi
   5b54c:      	callq	0x6e9d0 <f.3>
   5b551:      	subq	$0x8, %rsp
   5b555:      	cmpb	$0x0, 0x18354(%rip)     # 0x738b0 <g.4>
   5b55c:      	je	0x6e9c5 <f.2+0x17805>
   5b562:      	addq	%rbp, %rax
   5b565:      	addq	%rax, %r12
   5b568:      	leaq	0x28(%rsp), %r8
   5b56d:      	leaq	0x20(%rsp), %rdi
   5b572:      	leaq	0x1824f(%rip), %r9      # 0x737c8 <native_roots.0>
   5b579:      	jmp	0x5808a <f.2+0xeca>
   5b57e:      	movq	%rcx, 0x58(%rsp)
   5b583:      	movq	$0x0, 0x50(%rsp)
   5b58c:      	movq	$0x3, 0x38(%rsp)
   5b595:      	xorl	%edi, %edi
   5b597:      	leaq	-0xe(%r14), %r12
   5b59b:      	movq	%r12, %rsi
   5b59e:      	callq	0x6e9d0 <f.3>
   5b5a3:      	subq	$0x8, %rsp
   5b5a7:      	cmpb	$0x0, 0x18302(%rip)     # 0x738b0 <g.4>
   5b5ae:      	je	0x6e9c5 <f.2+0x17805>
   5b5b4:      	cmpq	$0x0, 0x182ec(%rip)     # 0x738a8 <g.3>
   5b5bc:      	je	0x6e9c5 <f.2+0x17805>
   5b5c2:      	movq	%rax, %rbp
   5b5c5:      	leaq	-0xf(%r14), %rsi
   5b5c9:      	movq	$0x0, 0x50(%rsp)
   5b5d2:      	movq	$0x3, 0x38(%rsp)
   5b5db:      	xorl	%edi, %edi
   5b5dd:      	callq	0x6e9d0 <f.3>
   5b5e2:      	subq	$0x8, %rsp
   5b5e6:      	cmpb	$0x0, 0x182c3(%rip)     # 0x738b0 <g.4>
   5b5ed:      	je	0x6e9c5 <f.2+0x17805>
   5b5f3:      	movq	%rbp, 0x60(%rsp)
   5b5f8:      	movq	%rax, 0x18(%rsp)
   5b5fd:      	cmpq	$0x0, 0x182a3(%rip)     # 0x738a8 <g.3>
   5b605:      	je	0x6e9c5 <f.2+0x17805>
   5b60b:      	movq	$0x0, 0x50(%rsp)
   5b614:      	movq	$0x3, 0x38(%rsp)
   5b61d:      	xorl	%edi, %edi
   5b61f:      	movq	%r12, %rsi
   5b622:      	callq	0x6e9d0 <f.3>
   5b627:      	subq	$0x8, %rsp
   5b62b:      	cmpb	$0x0, 0x1827e(%rip)     # 0x738b0 <g.4>
   5b632:      	je	0x6e9c5 <f.2+0x17805>
   5b638:      	cmpq	$0x0, 0x18268(%rip)     # 0x738a8 <g.3>
   5b640:      	je	0x6e9c5 <f.2+0x17805>
   5b646:      	movq	%rax, %rbp
   5b649:      	movq	$0x0, 0x50(%rsp)
   5b652:      	movq	$0x3, 0x38(%rsp)
   5b65b:      	xorl	%edi, %edi
   5b65d:      	leaq	-0xf(%r14), %rsi
   5b661:      	callq	0x6e9d0 <f.3>
   5b666:      	subq	$0x8, %rsp
   5b66a:      	cmpb	$0x0, 0x1823f(%rip)     # 0x738b0 <g.4>
   5b671:      	je	0x6e9c5 <f.2+0x17805>
   5b677:      	movq	%rax, %r12
   5b67a:      	cmpq	$0x0, 0x18226(%rip)     # 0x738a8 <g.3>
   5b682:      	leaq	0x28(%rsp), %r8
   5b687:      	leaq	0x1813a(%rip), %r9      # 0x737c8 <native_roots.0>
   5b68e:      	movq	0x10(%rsp), %rax
   5b693:      	je	0x6e9c5 <f.2+0x17805>
   5b699:      	movq	0x18(%rsp), %rcx
   5b69e:      	addq	0x60(%rsp), %rcx
   5b6a3:      	addq	0x58(%rsp), %rcx
   5b6a8:      	movq	%rcx, 0x18(%rsp)
   5b6ad:      	addq	%rbp, %r12
   5b6b0:      	cmpq	$0x10, %r14
   5b6b4:      	jae	0x5ed3a <f.2+0x7b7a>
   5b6ba:      	leaq	0x20(%rsp), %rdi
   5b6bf:      	movq	0x18(%rsp), %rbp
   5b6c4:      	leaq	-0xe(%r14), %rcx
   5b6c8:      	jmp	0x5edbb <f.2+0x7bfb>
   5b6cd:      	movq	%rax, 0x18(%rsp)
   5b6d2:      	movq	$0x0, 0x50(%rsp)
   5b6db:      	movq	$0x3, 0x38(%rsp)
   5b6e4:      	xorl	%edi, %edi
   5b6e6:      	callq	0x6e9d0 <f.3>
   5b6eb:      	subq	$0x8, %rsp
   5b6ef:      	cmpb	$0x0, 0x181ba(%rip)     # 0x738b0 <g.4>
   5b6f6:      	je	0x6e9c5 <f.2+0x17805>
   5b6fc:      	movq	%rax, 0x58(%rsp)
   5b701:      	cmpq	$0x0, 0x1819f(%rip)     # 0x738a8 <g.3>
   5b709:      	je	0x6e9c5 <f.2+0x17805>
   5b70f:      	leaq	-0xf(%r14), %rsi
   5b713:      	movq	$0x0, 0x50(%rsp)
   5b71c:      	movq	$0x3, 0x38(%rsp)
   5b725:      	xorl	%edi, %edi
   5b727:      	callq	0x6e9d0 <f.3>
   5b72c:      	subq	$0x8, %rsp
   5b730:      	cmpb	$0x0, 0x18179(%rip)     # 0x738b0 <g.4>
   5b737:      	je	0x6e9c5 <f.2+0x17805>
   5b73d:      	cmpq	$0x0, 0x18163(%rip)     # 0x738a8 <g.3>
   5b745:      	leaq	-0xe(%r14), %rsi
   5b749:      	je	0x6e9c5 <f.2+0x17805>
   5b74f:      	movq	%rax, %r13
   5b752:      	movq	$0x0, 0x50(%rsp)
   5b75b:      	movq	$0x3, 0x38(%rsp)
   5b764:      	xorl	%edi, %edi
   5b766:      	callq	0x6e9d0 <f.3>
   5b76b:      	subq	$0x8, %rsp
   5b76f:      	cmpb	$0x0, 0x1813a(%rip)     # 0x738b0 <g.4>
   5b776:      	je	0x6e9c5 <f.2+0x17805>
   5b77c:      	cmpq	$0x0, 0x18124(%rip)     # 0x738a8 <g.3>
   5b784:      	je	0x6e9c5 <f.2+0x17805>
   5b78a:      	movq	%rax, %rbp
   5b78d:      	movq	$0x0, 0x50(%rsp)
   5b796:      	movq	$0x3, 0x38(%rsp)
   5b79f:      	xorl	%edi, %edi
   5b7a1:      	leaq	-0xf(%r14), %rsi
   5b7a5:      	callq	0x6e9d0 <f.3>
   5b7aa:      	subq	$0x8, %rsp
   5b7ae:      	cmpb	$0x0, 0x180fb(%rip)     # 0x738b0 <g.4>
   5b7b5:      	je	0x6e9c5 <f.2+0x17805>
   5b7bb:      	movq	%rax, %rdx
   5b7be:      	cmpq	$0x0, 0x180e2(%rip)     # 0x738a8 <g.3>
   5b7c6:      	leaq	0x28(%rsp), %r8
   5b7cb:      	leaq	0x17ff6(%rip), %r9      # 0x737c8 <native_roots.0>
   5b7d2:      	leaq	-0xe(%r14), %rax
   5b7d6:      	je	0x6e9c5 <f.2+0x17805>
   5b7dc:      	addq	0x58(%rsp), %r13
   5b7e1:      	addq	0x18(%rsp), %r13
   5b7e6:      	addq	%rbp, %rdx
   5b7e9:      	cmpq	$0x10, %r14
   5b7ed:      	jae	0x5edd6 <f.2+0x7c16>
   5b7f3:      	leaq	0x20(%rsp), %rdi
   5b7f8:      	movq	0x10(%rsp), %rcx
   5b7fd:      	jmp	0x5ee59 <f.2+0x7c99>
   5b802:      	incq	%r13
   5b805:      	jmp	0x5850f <f.2+0x134f>
   5b80a:      	movq	$0x0, 0x50(%rsp)
   5b813:      	movq	$0x3, 0x38(%rsp)
   5b81c:      	xorl	%edi, %edi
   5b81e:      	leaq	-0xe(%r14), %rsi
   5b822:      	callq	0x6e9d0 <f.3>
   5b827:      	subq	$0x8, %rsp
   5b82b:      	cmpb	$0x0, 0x1807e(%rip)     # 0x738b0 <g.4>
   5b832:      	je	0x6e9c5 <f.2+0x17805>
   5b838:      	cmpq	$0x0, 0x18068(%rip)     # 0x738a8 <g.3>
   5b840:      	je	0x6e9c5 <f.2+0x17805>
   5b846:      	movq	%rax, %r12
   5b849:      	leaq	-0xf(%r14), %rsi
   5b84d:      	movq	$0x0, 0x50(%rsp)
   5b856:      	movq	$0x3, 0x38(%rsp)
   5b85f:      	xorl	%edi, %edi
   5b861:      	callq	0x6e9d0 <f.3>
   5b866:      	subq	$0x8, %rsp
   5b86a:      	cmpb	$0x0, 0x1803f(%rip)     # 0x738b0 <g.4>
   5b871:      	je	0x6e9c5 <f.2+0x17805>
   5b877:      	movq	%rax, %rbp
   5b87a:      	cmpq	$0x0, 0x18026(%rip)     # 0x738a8 <g.3>
   5b882:      	leaq	0x28(%rsp), %r8
   5b887:      	leaq	0x20(%rsp), %rdi
   5b88c:      	leaq	0x17f35(%rip), %r9      # 0x737c8 <native_roots.0>
   5b893:      	movq	0x10(%rsp), %rax
   5b898:      	je	0x6e9c5 <f.2+0x17805>
   5b89e:      	addq	%r12, %rbp
   5b8a1:      	addq	%r13, %rbp
   5b8a4:      	movq	0x18(%rsp), %r12
   5b8a9:      	cmpq	$0xd, %r14
   5b8ad:      	je	0x5b8c2 <f.2+0x4702>
   5b8af:      	cmpq	$0xe, %r14
   5b8b3:      	jne	0x5b8d8 <f.2+0x4718>
   5b8b5:      	movl	$0x1, %ecx
   5b8ba:      	xorl	%r13d, %r13d
   5b8bd:      	jmp	0x5c8e5 <f.2+0x5725>
   5b8c2:      	leaq	(%r14,%rbp), %r13
   5b8c6:      	addq	$-0xc, %r13
   5b8ca:      	movl	$0x1, %ebp
   5b8cf:      	leaq	-0xd(%r14), %rdx
   5b8d3:      	jmp	0x632e4 <f.2+0xc124>
   5b8d8:      	leaq	-0xe(%r14), %r13
   5b8dc:      	movq	$0x0, 0x50(%rsp)
   5b8e5:      	movq	$0x3, 0x38(%rsp)
   5b8ee:      	xorl	%edi, %edi
   5b8f0:      	movq	%r13, %rsi
   5b8f3:      	callq	0x6e9d0 <f.3>
   5b8f8:      	subq	$0x8, %rsp
   5b8fc:      	cmpb	$0x0, 0x17fad(%rip)     # 0x738b0 <g.4>
   5b903:      	je	0x6e9c5 <f.2+0x17805>
   5b909:      	cmpq	$0x0, 0x17f97(%rip)     # 0x738a8 <g.3>
   5b911:      	je	0x6e9c5 <f.2+0x17805>
   5b917:      	movq	%rax, %r12
   5b91a:      	leaq	-0xf(%r14), %rsi
   5b91e:      	movq	$0x0, 0x50(%rsp)
   5b927:      	movq	$0x3, 0x38(%rsp)
   5b930:      	xorl	%edi, %edi
   5b932:      	callq	0x6e9d0 <f.3>
   5b937:      	subq	$0x8, %rsp
   5b93b:      	cmpb	$0x0, 0x17f6e(%rip)     # 0x738b0 <g.4>
   5b942:      	je	0x6e9c5 <f.2+0x17805>
   5b948:      	movq	%rax, %rcx
   5b94b:      	cmpq	$0x0, 0x17f55(%rip)     # 0x738a8 <g.3>
   5b953:      	leaq	0x28(%rsp), %r8
   5b958:      	leaq	0x20(%rsp), %rdi
   5b95d:      	leaq	0x17e64(%rip), %r9      # 0x737c8 <native_roots.0>
   5b964:      	movq	0x10(%rsp), %rax
   5b969:      	je	0x6e9c5 <f.2+0x17805>
   5b96f:      	addq	%r12, %rcx
   5b972:      	cmpq	$0x10, %r14
   5b976:      	jae	0x5c85a <f.2+0x569a>
   5b97c:      	movq	0x18(%rsp), %r12
   5b981:      	jmp	0x5c8e5 <f.2+0x5725>
   5b986:      	movq	$0x0, 0x50(%rsp)
   5b98f:      	movq	$0x3, 0x38(%rsp)
   5b998:      	xorl	%edi, %edi
   5b99a:      	leaq	-0xe(%r14), %rsi
   5b99e:      	callq	0x6e9d0 <f.3>
   5b9a3:      	subq	$0x8, %rsp
   5b9a7:      	cmpb	$0x0, 0x17f02(%rip)     # 0x738b0 <g.4>
   5b9ae:      	je	0x6e9c5 <f.2+0x17805>
   5b9b4:      	cmpq	$0x0, 0x17eec(%rip)     # 0x738a8 <g.3>
   5b9bc:      	je	0x6e9c5 <f.2+0x17805>
   5b9c2:      	movq	%rax, %r12
   5b9c5:      	leaq	-0xf(%r14), %rsi
   5b9c9:      	movq	$0x0, 0x50(%rsp)
   5b9d2:      	movq	$0x3, 0x38(%rsp)
   5b9db:      	xorl	%edi, %edi
   5b9dd:      	callq	0x6e9d0 <f.3>
   5b9e2:      	subq	$0x8, %rsp
   5b9e6:      	cmpb	$0x0, 0x17ec3(%rip)     # 0x738b0 <g.4>
   5b9ed:      	je	0x6e9c5 <f.2+0x17805>
   5b9f3:      	cmpq	$0x0, 0x17ead(%rip)     # 0x738a8 <g.3>
   5b9fb:      	leaq	0x28(%rsp), %r8
   5ba00:      	leaq	0x20(%rsp), %rdi
   5ba05:      	leaq	0x17dbc(%rip), %r9      # 0x737c8 <native_roots.0>
   5ba0c:      	je	0x6e9c5 <f.2+0x17805>
   5ba12:      	movq	%rax, %rdx
   5ba15:      	addq	%r12, %rdx
   5ba18:      	addq	%r13, %rdx
   5ba1b:      	addq	%rbp, %rdx
   5ba1e:      	movq	%r14, %r13
   5ba21:      	subq	$0xd, %r13
   5ba25:      	jbe	0x5a06f <f.2+0x2eaf>
   5ba2b:      	movq	%rdx, 0x10(%rsp)
   5ba30:      	movq	$0x0, 0x50(%rsp)
   5ba39:      	movq	$0x3, 0x38(%rsp)
   5ba42:      	xorl	%edi, %edi
   5ba44:      	movq	%r13, %rsi
   5ba47:      	callq	0x6e9d0 <f.3>
   5ba4c:      	subq	$0x8, %rsp
   5ba50:      	cmpb	$0x0, 0x17e59(%rip)     # 0x738b0 <g.4>
   5ba57:      	je	0x6e9c5 <f.2+0x17805>
   5ba5d:      	cmpq	$0x0, 0x17e43(%rip)     # 0x738a8 <g.3>
   5ba65:      	leaq	-0xe(%r14), %rsi
   5ba69:      	je	0x6e9c5 <f.2+0x17805>
   5ba6f:      	movq	%rax, %r12
   5ba72:      	movq	$0x0, 0x50(%rsp)
   5ba7b:      	movq	$0x3, 0x38(%rsp)
   5ba84:      	xorl	%edi, %edi
   5ba86:      	callq	0x6e9d0 <f.3>
   5ba8b:      	subq	$0x8, %rsp
   5ba8f:      	cmpb	$0x0, 0x17e1a(%rip)     # 0x738b0 <g.4>
   5ba96:      	je	0x6e9c5 <f.2+0x17805>
   5ba9c:      	cmpq	$0x0, 0x17e04(%rip)     # 0x738a8 <g.3>
   5baa4:      	leaq	0x28(%rsp), %r8
   5baa9:      	leaq	0x20(%rsp), %rdi
   5baae:      	leaq	0x17d13(%rip), %r9      # 0x737c8 <native_roots.0>
   5bab5:      	je	0x6e9c5 <f.2+0x17805>
   5babb:      	movq	%rax, %rbp
   5babe:      	addq	%r12, %rbp
   5bac1:      	cmpq	$0xe, %r14
   5bac5:      	leaq	-0xe(%r14), %rsi
   5bac9:      	jne	0x5c4df <f.2+0x531f>
   5bacf:      	addq	%rbp, %r13
   5bad2:      	movl	$0x1, %esi
   5bad7:      	xorl	%eax, %eax
   5bad9:      	movq	0x18(%rsp), %r12
   5bade:      	movq	0x10(%rsp), %rdx
   5bae3:      	jmp	0x62b97 <f.2+0xb9d7>
   5bae8:      	movq	%rcx, %r13
   5baeb:      	movq	$0x0, 0x50(%rsp)
   5baf4:      	movq	$0x3, 0x38(%rsp)
   5bafd:      	xorl	%edi, %edi
   5baff:      	leaq	-0xe(%r14), %rsi
   5bb03:      	callq	0x6e9d0 <f.3>
   5bb08:      	subq	$0x8, %rsp
   5bb0c:      	cmpb	$0x0, 0x17d9d(%rip)     # 0x738b0 <g.4>
   5bb13:      	je	0x6e9c5 <f.2+0x17805>
   5bb19:      	cmpq	$0x0, 0x17d87(%rip)     # 0x738a8 <g.3>
   5bb21:      	je	0x6e9c5 <f.2+0x17805>
   5bb27:      	movq	%rax, %r12
   5bb2a:      	leaq	-0xf(%r14), %rsi
   5bb2e:      	movq	$0x0, 0x50(%rsp)
   5bb37:      	movq	$0x3, 0x38(%rsp)
   5bb40:      	xorl	%edi, %edi
   5bb42:      	callq	0x6e9d0 <f.3>
   5bb47:      	subq	$0x8, %rsp
   5bb4b:      	cmpb	$0x0, 0x17d5e(%rip)     # 0x738b0 <g.4>
   5bb52:      	je	0x6e9c5 <f.2+0x17805>
   5bb58:      	addq	%r12, %rax
   5bb5b:      	movq	%r13, %rcx
   5bb5e:      	addq	%rax, %rcx
   5bb61:      	leaq	0x28(%rsp), %r8
   5bb66:      	leaq	0x20(%rsp), %rdi
   5bb6b:      	leaq	0x17c56(%rip), %r9      # 0x737c8 <native_roots.0>
   5bb72:      	movq	0x10(%rsp), %r13
   5bb77:      	cmpq	$0x0, 0x17d29(%rip)     # 0x738a8 <g.3>
   5bb7f:      	je	0x6e9c5 <f.2+0x17805>
   5bb85:      	addq	%rbp, %rcx
   5bb88:      	addq	%r13, %rcx
   5bb8b:      	cmpq	$0xb, %r14
   5bb8f:      	jbe	0x5bba5 <f.2+0x49e5>
   5bb91:      	cmpq	$0xc, %r14
   5bb95:      	jne	0x5bbe1 <f.2+0x4a21>
   5bb97:      	movl	$0x1, %r12d
   5bb9d:      	xorl	%r13d, %r13d
   5bba0:      	jmp	0x5bd22 <f.2+0x4b62>
   5bba5:      	leaq	-0xa(%r14), %rbp
   5bba9:      	leaq	-0xa(%r14), %r13
   5bbad:      	cmpq	$0x0, 0x17cf3(%rip)     # 0x738a8 <g.3>
   5bbb5:      	je	0x6e9c5 <f.2+0x17805>
   5bbbb:      	addq	%rbp, %r13
   5bbbe:      	addq	%rcx, %r13
   5bbc1:      	cmpq	$0x8, %r14
   5bbc5:      	jne	0x57745 <f.2+0x585>
   5bbcb:      	leaq	(%r14,%r13), %r12
   5bbcf:      	addq	$-0x7, %r12
   5bbd3:      	movl	$0x1, %ebp
   5bbd8:      	leaq	-0x8(%r14), %rcx
   5bbdc:      	jmp	0x68702 <f.2+0x11542>
   5bbe1:      	movq	%rcx, 0x10(%rsp)
   5bbe6:      	leaq	-0xc(%r14), %r13
   5bbea:      	movq	$0x0, 0x50(%rsp)
   5bbf3:      	movq	$0x3, 0x38(%rsp)
   5bbfc:      	xorl	%edi, %edi
   5bbfe:      	movq	%r13, %rsi
   5bc01:      	callq	0x6e9d0 <f.3>
   5bc06:      	subq	$0x8, %rsp
   5bc0a:      	cmpb	$0x0, 0x17c9f(%rip)     # 0x738b0 <g.4>
   5bc11:      	je	0x6e9c5 <f.2+0x17805>
   5bc17:      	cmpq	$0x0, 0x17c89(%rip)     # 0x738a8 <g.3>
   5bc1f:      	je	0x6e9c5 <f.2+0x17805>
   5bc25:      	movq	%rax, %rbp
   5bc28:      	leaq	-0xd(%r14), %rsi
   5bc2c:      	movq	$0x0, 0x50(%rsp)
   5bc35:      	movq	$0x3, 0x38(%rsp)
   5bc3e:      	xorl	%edi, %edi
   5bc40:      	callq	0x6e9d0 <f.3>
   5bc45:      	subq	$0x8, %rsp
   5bc49:      	cmpb	$0x0, 0x17c60(%rip)     # 0x738b0 <g.4>
   5bc50:      	je	0x6e9c5 <f.2+0x17805>
   5bc56:      	cmpq	$0x0, 0x17c4a(%rip)     # 0x738a8 <g.3>
   5bc5e:      	movq	0x10(%rsp), %rcx
   5bc63:      	je	0x6e9c5 <f.2+0x17805>
   5bc69:      	movq	%rax, %r12
   5bc6c:      	addq	%rbp, %r12
   5bc6f:      	cmpq	$0xd, %r14
   5bc73:      	ja	0x5bc8b <f.2+0x4acb>
   5bc75:      	leaq	0x28(%rsp), %r8
   5bc7a:      	leaq	0x20(%rsp), %rdi
   5bc7f:      	leaq	0x17b42(%rip), %r9      # 0x737c8 <native_roots.0>
   5bc86:      	jmp	0x5bd22 <f.2+0x4b62>
   5bc8b:      	movq	$0x0, 0x50(%rsp)
   5bc94:      	movq	$0x3, 0x38(%rsp)
   5bc9d:      	xorl	%edi, %edi
   5bc9f:      	leaq	-0xd(%r14), %rsi
   5bca3:      	callq	0x6e9d0 <f.3>
   5bca8:      	subq	$0x8, %rsp
   5bcac:      	cmpb	$0x0, 0x17bfd(%rip)     # 0x738b0 <g.4>
   5bcb3:      	je	0x6e9c5 <f.2+0x17805>
   5bcb9:      	cmpq	$0x0, 0x17be7(%rip)     # 0x738a8 <g.3>
   5bcc1:      	je	0x6e9c5 <f.2+0x17805>
   5bcc7:      	movq	%rax, %rbp
   5bcca:      	leaq	-0xe(%r14), %rsi
   5bcce:      	movq	$0x0, 0x50(%rsp)
   5bcd7:      	movq	$0x3, 0x38(%rsp)
   5bce0:      	xorl	%edi, %edi
   5bce2:      	callq	0x6e9d0 <f.3>
   5bce7:      	subq	$0x8, %rsp
   5bceb:      	cmpb	$0x0, 0x17bbe(%rip)     # 0x738b0 <g.4>
   5bcf2:      	je	0x6e9c5 <f.2+0x17805>
   5bcf8:      	cmpq	$0x0, 0x17ba8(%rip)     # 0x738a8 <g.3>
   5bd00:      	leaq	0x28(%rsp), %r8
   5bd05:      	leaq	0x20(%rsp), %rdi
   5bd0a:      	leaq	0x17ab7(%rip), %r9      # 0x737c8 <native_roots.0>
   5bd11:      	movq	0x10(%rsp), %rcx
   5bd16:      	je	0x6e9c5 <f.2+0x17805>
   5bd1c:      	movq	%rax, %r13
   5bd1f:      	addq	%rbp, %r13
   5bd22:      	addq	%r12, %r13
   5bd25:      	cmpq	$0xc, %r14
   5bd29:      	je	0x5bd59 <f.2+0x4b99>
   5bd2b:      	cmpq	$0xd, %r14
   5bd2f:      	jne	0x5bd73 <f.2+0x4bb3>
   5bd31:      	cmpq	$0x0, 0x17b6f(%rip)     # 0x738a8 <g.3>
   5bd39:      	je	0x6e9c5 <f.2+0x17805>
   5bd3f:      	incq	%r13
   5bd42:      	leaq	-0xd(%r14), %rsi
   5bd46:      	movq	%r13, %rbp
   5bd49:      	incq	%rsi
   5bd4c:      	leaq	(%r14,%rsi), %r13
   5bd50:      	addq	$-0xc, %r13
   5bd54:      	jmp	0x5bbad <f.2+0x49ed>
   5bd59:      	leaq	(%r14,%r13), %rbp
   5bd5d:      	addq	$-0xb, %rbp
   5bd61:      	movl	$0x1, %eax
   5bd66:      	leaq	(%r14,%rax), %r13
   5bd6a:      	addq	$-0xc, %r13
   5bd6e:      	jmp	0x5bbad <f.2+0x49ed>
   5bd73:      	movq	%rcx, 0x10(%rsp)
   5bd78:      	leaq	-0xd(%r14), %rsi
   5bd7c:      	movq	$0x0, 0x50(%rsp)
   5bd85:      	movq	$0x3, 0x38(%rsp)
   5bd8e:      	xorl	%edi, %edi
   5bd90:      	callq	0x6e9d0 <f.3>
   5bd95:      	subq	$0x8, %rsp
   5bd99:      	cmpb	$0x0, 0x17b10(%rip)     # 0x738b0 <g.4>
   5bda0:      	je	0x6e9c5 <f.2+0x17805>
   5bda6:      	cmpq	$0x0, 0x17afa(%rip)     # 0x738a8 <g.3>
   5bdae:      	je	0x6e9c5 <f.2+0x17805>
   5bdb4:      	movq	%rax, %rbp
   5bdb7:      	leaq	-0xe(%r14), %rsi
   5bdbb:      	movq	$0x0, 0x50(%rsp)
   5bdc4:      	movq	$0x3, 0x38(%rsp)
   5bdcd:      	xorl	%edi, %edi
   5bdcf:      	callq	0x6e9d0 <f.3>
   5bdd4:      	subq	$0x8, %rsp
   5bdd8:      	cmpb	$0x0, 0x17ad1(%rip)     # 0x738b0 <g.4>
   5bddf:      	je	0x6e9c5 <f.2+0x17805>
   5bde5:      	cmpq	$0x0, 0x17abb(%rip)     # 0x738a8 <g.3>
   5bded:      	leaq	-0xd(%r14), %rsi
   5bdf1:      	je	0x6e9c5 <f.2+0x17805>
   5bdf7:      	movq	%rax, %r12
   5bdfa:      	addq	%rbp, %r12
   5bdfd:      	cmpq	$0xe, %r14
   5be01:      	ja	0x5be11 <f.2+0x4c51>
   5be03:      	addq	%rsi, %r12
   5be06:      	addq	%r13, %r12
   5be09:      	movq	%r12, %rbp
   5be0c:      	jmp	0x5bebf <f.2+0x4cff>
   5be11:      	movq	$0x0, 0x50(%rsp)
   5be1a:      	movq	$0x3, 0x38(%rsp)
   5be23:      	xorl	%edi, %edi
   5be25:      	leaq	-0xe(%r14), %rsi
   5be29:      	callq	0x6e9d0 <f.3>
   5be2e:      	subq	$0x8, %rsp
   5be32:      	cmpb	$0x0, 0x17a77(%rip)     # 0x738b0 <g.4>
   5be39:      	je	0x6e9c5 <f.2+0x17805>
   5be3f:      	movq	%rax, 0x18(%rsp)
   5be44:      	cmpq	$0x0, 0x17a5c(%rip)     # 0x738a8 <g.3>
   5be4c:      	je	0x6e9c5 <f.2+0x17805>
   5be52:      	leaq	-0xf(%r14), %rsi
   5be56:      	movq	$0x0, 0x50(%rsp)
   5be5f:      	movq	$0x3, 0x38(%rsp)
   5be68:      	xorl	%edi, %edi
   5be6a:      	callq	0x6e9d0 <f.3>
   5be6f:      	subq	$0x8, %rsp
   5be73:      	cmpb	$0x0, 0x17a36(%rip)     # 0x738b0 <g.4>
   5be7a:      	je	0x6e9c5 <f.2+0x17805>
   5be80:      	cmpq	$0x0, 0x17a20(%rip)     # 0x738a8 <g.3>
   5be88:      	leaq	0x28(%rsp), %r8
   5be8d:      	leaq	0x20(%rsp), %rdi
   5be92:      	leaq	0x1792f(%rip), %r9      # 0x737c8 <native_roots.0>
   5be99:      	movq	0x10(%rsp), %rcx
   5be9e:      	je	0x6e9c5 <f.2+0x17805>
   5bea4:      	movq	%rax, %rbp
   5bea7:      	addq	0x18(%rsp), %rbp
   5beac:      	addq	%r12, %rbp
   5beaf:      	addq	%r13, %rbp
   5beb2:      	movq	%r14, %rsi
   5beb5:      	subq	$0xd, %rsi
   5beb9:      	jbe	0x5bd49 <f.2+0x4b89>
   5bebf:      	movq	$0x0, 0x50(%rsp)
   5bec8:      	movq	$0x3, 0x38(%rsp)
   5bed1:      	xorl	%edi, %edi
   5bed3:      	movq	%rsi, %r12
   5bed6:      	callq	0x6e9d0 <f.3>
   5bedb:      	subq	$0x8, %rsp
   5bedf:      	cmpb	$0x0, 0x179ca(%rip)     # 0x738b0 <g.4>
   5bee6:      	je	0x6e9c5 <f.2+0x17805>
   5beec:      	cmpq	$0x0, 0x179b4(%rip)     # 0x738a8 <g.3>
   5bef4:      	je	0x6e9c5 <f.2+0x17805>
   5befa:      	movq	%rax, %r13
   5befd:      	movq	$0x0, 0x50(%rsp)
   5bf06:      	movq	$0x3, 0x38(%rsp)
   5bf0f:      	xorl	%edi, %edi
   5bf11:      	leaq	-0xe(%r14), %rsi
   5bf15:      	callq	0x6e9d0 <f.3>
   5bf1a:      	subq	$0x8, %rsp
   5bf1e:      	cmpb	$0x0, 0x1798b(%rip)     # 0x738b0 <g.4>
   5bf25:      	je	0x6e9c5 <f.2+0x17805>
   5bf2b:      	cmpq	$0x0, 0x17975(%rip)     # 0x738a8 <g.3>
   5bf33:      	je	0x6e9c5 <f.2+0x17805>
   5bf39:      	movq	%r12, %rdx
   5bf3c:      	addq	%r13, %rax
   5bf3f:      	cmpq	$0xe, %r14
   5bf43:      	leaq	-0xe(%r14), %r12
   5bf47:      	jne	0x5c217 <f.2+0x5057>
   5bf4d:      	addq	%rax, %rdx
   5bf50:      	movl	$0x1, %r13d
   5bf56:      	xorl	%eax, %eax
   5bf58:      	leaq	0x28(%rsp), %r8
   5bf5d:      	leaq	0x20(%rsp), %rdi
   5bf62:      	leaq	0x1785f(%rip), %r9      # 0x737c8 <native_roots.0>
   5bf69:      	movq	0x10(%rsp), %rcx
   5bf6e:      	jmp	0x5c355 <f.2+0x5195>
   5bf73:      	movq	%rdx, 0x58(%rsp)
   5bf78:      	movq	$0x0, 0x50(%rsp)
   5bf81:      	movq	$0x3, 0x38(%rsp)
   5bf8a:      	xorl	%edi, %edi
   5bf8c:      	leaq	-0xf(%r14), %rsi
   5bf90:      	callq	0x6e9d0 <f.3>
   5bf95:      	subq	$0x8, %rsp
   5bf99:      	cmpb	$0x0, 0x17910(%rip)     # 0x738b0 <g.4>
   5bfa0:      	je	0x6e9c5 <f.2+0x17805>
   5bfa6:      	cmpq	$0x0, 0x178fa(%rip)     # 0x738a8 <g.3>
   5bfae:      	je	0x6e9c5 <f.2+0x17805>
   5bfb4:      	movq	%rax, %rbp
   5bfb7:      	leaq	-0x10(%r14), %rsi
   5bfbb:      	movq	$0x0, 0x50(%rsp)
   5bfc4:      	movq	$0x3, 0x38(%rsp)
   5bfcd:      	xorl	%edi, %edi
   5bfcf:      	callq	0x6e9d0 <f.3>
   5bfd4:      	subq	$0x8, %rsp
   5bfd8:      	movq	%rax, %r13
   5bfdb:      	addq	%rbp, %r13
   5bfde:      	leaq	0x28(%rsp), %r8
   5bfe3:      	leaq	0x20(%rsp), %rdi
   5bfe8:      	leaq	0x177d9(%rip), %r9      # 0x737c8 <native_roots.0>
   5bfef:      	movq	0x10(%rsp), %rax
   5bff4:      	movq	0x18(%rsp), %rcx
   5bff9:      	movq	0x58(%rsp), %rdx
   5bffe:      	cmpb	$0x0, 0x178ab(%rip)     # 0x738b0 <g.4>
   5c005:      	je	0x6e9c5 <f.2+0x17805>
   5c00b:      	cmpq	$0x0, 0x17895(%rip)     # 0x738a8 <g.3>
   5c013:      	je	0x6e9c5 <f.2+0x17805>
   5c019:      	addq	%rdx, %r13
   5c01c:      	addq	%rcx, %r13
   5c01f:      	movq	%r14, %rbp
   5c022:      	subq	$0xe, %rbp
   5c026:      	jbe	0x5c0d2 <f.2+0x4f12>
   5c02c:      	movq	$0x0, 0x50(%rsp)
   5c035:      	movq	$0x3, 0x38(%rsp)
   5c03e:      	xorl	%edi, %edi
   5c040:      	movq	%rbp, %rsi
   5c043:      	callq	0x6e9d0 <f.3>
   5c048:      	subq	$0x8, %rsp
   5c04c:      	cmpb	$0x0, 0x1785d(%rip)     # 0x738b0 <g.4>
   5c053:      	je	0x6e9c5 <f.2+0x17805>
   5c059:      	movq	%rax, 0x18(%rsp)
   5c05e:      	cmpq	$0x0, 0x17842(%rip)     # 0x738a8 <g.3>
   5c066:      	je	0x6e9c5 <f.2+0x17805>
   5c06c:      	leaq	-0xf(%r14), %rsi
   5c070:      	movq	$0x0, 0x50(%rsp)
   5c079:      	movq	$0x3, 0x38(%rsp)
   5c082:      	xorl	%edi, %edi
   5c084:      	callq	0x6e9d0 <f.3>
   5c089:      	subq	$0x8, %rsp
   5c08d:      	cmpb	$0x0, 0x1781c(%rip)     # 0x738b0 <g.4>
   5c094:      	je	0x6e9c5 <f.2+0x17805>
   5c09a:      	cmpq	$0x0, 0x17806(%rip)     # 0x738a8 <g.3>
   5c0a2:      	leaq	0x28(%rsp), %r8
   5c0a7:      	leaq	0x1771a(%rip), %r9      # 0x737c8 <native_roots.0>
   5c0ae:      	je	0x6e9c5 <f.2+0x17805>
   5c0b4:      	addq	0x18(%rsp), %rax
   5c0b9:      	cmpq	$0xf, %r14
   5c0bd:      	leaq	-0xf(%r14), %rsi
   5c0c1:      	jne	0x5c0de <f.2+0x4f1e>
   5c0c3:      	addq	%rax, %rbp
   5c0c6:      	movl	$0x1, %edx
   5c0cb:      	xorl	%ecx, %ecx
   5c0cd:      	jmp	0x5c208 <f.2+0x5048>
   5c0d2:      	incq	%rbp
   5c0d5:      	leaq	-0xd(%r14), %rdx
   5c0d9:      	jmp	0x5f151 <f.2+0x7f91>
   5c0de:      	movq	%rax, 0x18(%rsp)
   5c0e3:      	movq	$0x0, 0x50(%rsp)
   5c0ec:      	movq	$0x3, 0x38(%rsp)
   5c0f5:      	xorl	%edi, %edi
   5c0f7:      	callq	0x6e9d0 <f.3>
   5c0fc:      	subq	$0x8, %rsp
   5c100:      	cmpb	$0x0, 0x177a9(%rip)     # 0x738b0 <g.4>
   5c107:      	je	0x6e9c5 <f.2+0x17805>
   5c10d:      	movq	%rax, 0x58(%rsp)
   5c112:      	cmpq	$0x0, 0x1778e(%rip)     # 0x738a8 <g.3>
   5c11a:      	je	0x6e9c5 <f.2+0x17805>
   5c120:      	leaq	-0x10(%r14), %rsi
   5c124:      	movq	$0x0, 0x50(%rsp)
   5c12d:      	movq	$0x3, 0x38(%rsp)
   5c136:      	xorl	%edi, %edi
   5c138:      	callq	0x6e9d0 <f.3>
   5c13d:      	subq	$0x8, %rsp
   5c141:      	cmpb	$0x0, 0x17768(%rip)     # 0x738b0 <g.4>
   5c148:      	je	0x6e9c5 <f.2+0x17805>
   5c14e:      	cmpq	$0x0, 0x17752(%rip)     # 0x738a8 <g.3>
   5c156:      	leaq	-0xf(%r14), %rsi
   5c15a:      	je	0x6e9c5 <f.2+0x17805>
   5c160:      	movq	%rax, %rbp
   5c163:      	movq	$0x0, 0x50(%rsp)
   5c16c:      	movq	$0x3, 0x38(%rsp)
   5c175:      	xorl	%edi, %edi
   5c177:      	callq	0x6e9d0 <f.3>
   5c17c:      	subq	$0x8, %rsp
   5c180:      	cmpb	$0x0, 0x17729(%rip)     # 0x738b0 <g.4>
   5c187:      	je	0x6e9c5 <f.2+0x17805>
   5c18d:      	movq	%rax, 0x60(%rsp)
   5c192:      	cmpq	$0x0, 0x1770e(%rip)     # 0x738a8 <g.3>
   5c19a:      	je	0x6e9c5 <f.2+0x17805>
   5c1a0:      	movq	$0x0, 0x50(%rsp)
   5c1a9:      	movq	$0x3, 0x38(%rsp)
   5c1b2:      	xorl	%edi, %edi
   5c1b4:      	leaq	-0x10(%r14), %rsi
   5c1b8:      	callq	0x6e9d0 <f.3>
   5c1bd:      	subq	$0x8, %rsp
   5c1c1:      	cmpb	$0x0, 0x176e8(%rip)     # 0x738b0 <g.4>
   5c1c8:      	je	0x6e9c5 <f.2+0x17805>
   5c1ce:      	cmpq	$0x0, 0x176d2(%rip)     # 0x738a8 <g.3>
   5c1d6:      	leaq	0x28(%rsp), %r8
   5c1db:      	leaq	0x175e6(%rip), %r9      # 0x737c8 <native_roots.0>
   5c1e2:      	leaq	-0xf(%r14), %rcx
   5c1e6:      	je	0x6e9c5 <f.2+0x17805>
   5c1ec:      	movq	%rax, %rdx
   5c1ef:      	addq	0x58(%rsp), %rbp
   5c1f4:      	addq	0x18(%rsp), %rbp
   5c1f9:      	addq	0x60(%rsp), %rdx
   5c1fe:      	cmpq	$0x11, %r14
   5c202:      	jae	0x5f0c4 <f.2+0x7f04>
   5c208:      	leaq	0x20(%rsp), %rdi
   5c20d:      	movq	0x10(%rsp), %rax
   5c212:      	jmp	0x5f14e <f.2+0x7f8e>
   5c217:      	movq	%rax, 0x58(%rsp)
   5c21c:      	movq	$0x0, 0x50(%rsp)
   5c225:      	movq	$0x3, 0x38(%rsp)
   5c22e:      	xorl	%edi, %edi
   5c230:      	movq	%r12, %rsi
   5c233:      	callq	0x6e9d0 <f.3>
   5c238:      	subq	$0x8, %rsp
   5c23c:      	cmpb	$0x0, 0x1766d(%rip)     # 0x738b0 <g.4>
   5c243:      	je	0x6e9c5 <f.2+0x17805>
   5c249:      	movq	%rax, 0x60(%rsp)
   5c24e:      	cmpq	$0x0, 0x17652(%rip)     # 0x738a8 <g.3>
   5c256:      	je	0x6e9c5 <f.2+0x17805>
   5c25c:      	leaq	-0xf(%r14), %r13
   5c260:      	movq	$0x0, 0x50(%rsp)
   5c269:      	movq	$0x3, 0x38(%rsp)
   5c272:      	xorl	%edi, %edi
   5c274:      	movq	%r13, %rsi
   5c277:      	callq	0x6e9d0 <f.3>
   5c27c:      	subq	$0x8, %rsp
   5c280:      	cmpb	$0x0, 0x17629(%rip)     # 0x738b0 <g.4>
   5c287:      	je	0x6e9c5 <f.2+0x17805>
   5c28d:      	movq	%rax, 0x18(%rsp)
   5c292:      	cmpq	$0x0, 0x1760e(%rip)     # 0x738a8 <g.3>
   5c29a:      	je	0x6e9c5 <f.2+0x17805>
   5c2a0:      	movq	$0x0, 0x50(%rsp)
   5c2a9:      	movq	$0x3, 0x38(%rsp)
   5c2b2:      	xorl	%edi, %edi
   5c2b4:      	movq	%r12, %rsi
   5c2b7:      	callq	0x6e9d0 <f.3>
   5c2bc:      	subq	$0x8, %rsp
   5c2c0:      	cmpb	$0x0, 0x175e9(%rip)     # 0x738b0 <g.4>
   5c2c7:      	je	0x6e9c5 <f.2+0x17805>
   5c2cd:      	cmpq	$0x0, 0x175d3(%rip)     # 0x738a8 <g.3>
   5c2d5:      	je	0x6e9c5 <f.2+0x17805>
   5c2db:      	movq	%rax, %r12
   5c2de:      	movq	$0x0, 0x50(%rsp)
   5c2e7:      	movq	$0x3, 0x38(%rsp)
   5c2f0:      	xorl	%edi, %edi
   5c2f2:      	movq	%r13, %rsi
   5c2f5:      	callq	0x6e9d0 <f.3>
   5c2fa:      	subq	$0x8, %rsp
   5c2fe:      	cmpb	$0x0, 0x175ab(%rip)     # 0x738b0 <g.4>
   5c305:      	je	0x6e9c5 <f.2+0x17805>
   5c30b:      	movq	%rax, %r13
   5c30e:      	cmpq	$0x0, 0x17592(%rip)     # 0x738a8 <g.3>
   5c316:      	movq	0x18(%rsp), %rdx
   5c31b:      	movq	0x58(%rsp), %rax
   5c320:      	je	0x6e9c5 <f.2+0x17805>
   5c326:      	addq	0x60(%rsp), %rdx
   5c32b:      	addq	%rax, %rdx
   5c32e:      	addq	%r12, %r13
   5c331:      	cmpq	$0x10, %r14
   5c335:      	jae	0x62a71 <f.2+0xb8b1>
   5c33b:      	leaq	0x28(%rsp), %r8
   5c340:      	leaq	0x20(%rsp), %rdi
   5c345:      	leaq	0x1747c(%rip), %r9      # 0x737c8 <native_roots.0>
   5c34c:      	movq	0x10(%rsp), %rcx
   5c351:      	leaq	-0xe(%r14), %rax
   5c355:      	addq	%rax, %r13
   5c358:      	addq	%rdx, %r13
   5c35b:      	jmp	0x5bbad <f.2+0x49ed>
   5c360:      	movq	%rax, 0x10(%rsp)
   5c365:      	movq	$0x0, 0x50(%rsp)
   5c36e:      	movq	$0x3, 0x38(%rsp)
   5c377:      	xorl	%edi, %edi
   5c379:      	leaq	-0xe(%r14), %rsi
   5c37d:      	callq	0x6e9d0 <f.3>
   5c382:      	subq	$0x8, %rsp
   5c386:      	cmpb	$0x0, 0x17523(%rip)     # 0x738b0 <g.4>
   5c38d:      	je	0x6e9c5 <f.2+0x17805>
   5c393:      	cmpq	$0x0, 0x1750d(%rip)     # 0x738a8 <g.3>
   5c39b:      	je	0x6e9c5 <f.2+0x17805>
   5c3a1:      	movq	%rax, %r12
   5c3a4:      	leaq	-0xf(%r14), %rsi
   5c3a8:      	movq	$0x0, 0x50(%rsp)
   5c3b1:      	movq	$0x3, 0x38(%rsp)
   5c3ba:      	xorl	%edi, %edi
   5c3bc:      	callq	0x6e9d0 <f.3>
   5c3c1:      	subq	$0x8, %rsp
   5c3c5:      	cmpb	$0x0, 0x174e4(%rip)     # 0x738b0 <g.4>
   5c3cc:      	je	0x6e9c5 <f.2+0x17805>
   5c3d2:      	addq	%r12, %rax
   5c3d5:      	leaq	0x28(%rsp), %r8
   5c3da:      	leaq	0x20(%rsp), %rdi
   5c3df:      	leaq	0x173e2(%rip), %r9      # 0x737c8 <native_roots.0>
   5c3e6:      	movq	0x10(%rsp), %rcx
   5c3eb:      	cmpq	$0x0, 0x174b5(%rip)     # 0x738a8 <g.3>
   5c3f3:      	je	0x6e9c5 <f.2+0x17805>
   5c3f9:      	addq	%rcx, %rax
   5c3fc:      	addq	%rbp, %rax
   5c3ff:      	movq	%rax, %r12
   5c402:      	cmpq	$0xb, %r14
   5c406:      	jne	0x585cf <f.2+0x140f>
   5c40c:      	leaq	(%r14,%r12), %rbp
   5c410:      	addq	$-0xa, %rbp
   5c414:      	movl	$0x1, %eax
   5c419:      	jmp	0x5e2c3 <f.2+0x7103>
   5c41e:      	movq	%r12, %r13
   5c421:      	movq	$0x0, 0x50(%rsp)
   5c42a:      	movq	$0x3, 0x38(%rsp)
   5c433:      	xorl	%edi, %edi
   5c435:      	leaq	-0xe(%r14), %rsi
   5c439:      	callq	0x6e9d0 <f.3>
   5c43e:      	subq	$0x8, %rsp
   5c442:      	cmpb	$0x0, 0x17467(%rip)     # 0x738b0 <g.4>
   5c449:      	je	0x6e9c5 <f.2+0x17805>
   5c44f:      	cmpq	$0x0, 0x17451(%rip)     # 0x738a8 <g.3>
   5c457:      	je	0x6e9c5 <f.2+0x17805>
   5c45d:      	movq	%rax, %r12
   5c460:      	leaq	-0xf(%r14), %rsi
   5c464:      	movq	$0x0, 0x50(%rsp)
   5c46d:      	movq	$0x3, 0x38(%rsp)
   5c476:      	xorl	%edi, %edi
   5c478:      	callq	0x6e9d0 <f.3>
   5c47d:      	subq	$0x8, %rsp
   5c481:      	cmpb	$0x0, 0x17428(%rip)     # 0x738b0 <g.4>
   5c488:      	je	0x6e9c5 <f.2+0x17805>
   5c48e:      	addq	%r12, %rax
   5c491:      	leaq	0x28(%rsp), %r8
   5c496:      	leaq	0x20(%rsp), %rdi
   5c49b:      	leaq	0x17326(%rip), %r9      # 0x737c8 <native_roots.0>
   5c4a2:      	movq	0x10(%rsp), %rcx
   5c4a7:      	cmpq	$0x0, 0x173f9(%rip)     # 0x738a8 <g.3>
   5c4af:      	je	0x6e9c5 <f.2+0x17805>
   5c4b5:      	addq	%r13, %rax
   5c4b8:      	addq	%rbp, %rax
   5c4bb:      	movq	%rax, %r12
   5c4be:      	cmpq	$0xb, %r14
   5c4c2:      	jne	0x5860a <f.2+0x144a>
   5c4c8:      	leaq	(%r14,%r12), %rbp
   5c4cc:      	addq	$-0xa, %rbp
   5c4d0:      	movl	$0x1, %r13d
   5c4d6:      	leaq	-0xb(%r14), %r12
   5c4da:      	jmp	0x62c63 <f.2+0xbaa3>
   5c4df:      	movq	$0x0, 0x50(%rsp)
   5c4e8:      	movq	$0x3, 0x38(%rsp)
   5c4f1:      	xorl	%edi, %edi
   5c4f3:      	callq	0x6e9d0 <f.3>
   5c4f8:      	subq	$0x8, %rsp
   5c4fc:      	cmpb	$0x0, 0x173ad(%rip)     # 0x738b0 <g.4>
   5c503:      	movq	0x18(%rsp), %r12
   5c508:      	je	0x6e9c5 <f.2+0x17805>
   5c50e:      	cmpq	$0x0, 0x17392(%rip)     # 0x738a8 <g.3>
   5c516:      	je	0x6e9c5 <f.2+0x17805>
   5c51c:      	movq	%rax, %r13
   5c51f:      	leaq	-0xf(%r14), %rsi
   5c523:      	movq	$0x0, 0x50(%rsp)
   5c52c:      	movq	$0x3, 0x38(%rsp)
   5c535:      	xorl	%edi, %edi
   5c537:      	callq	0x6e9d0 <f.3>
   5c53c:      	subq	$0x8, %rsp
   5c540:      	cmpb	$0x0, 0x17369(%rip)     # 0x738b0 <g.4>
   5c547:      	je	0x6e9c5 <f.2+0x17805>
   5c54d:      	movq	%r13, 0x60(%rsp)
   5c552:      	movq	%rax, 0x58(%rsp)
   5c557:      	cmpq	$0x0, 0x17349(%rip)     # 0x738a8 <g.3>
   5c55f:      	leaq	-0xe(%r14), %rsi
   5c563:      	je	0x6e9c5 <f.2+0x17805>
   5c569:      	movq	$0x0, 0x50(%rsp)
   5c572:      	movq	$0x3, 0x38(%rsp)
   5c57b:      	xorl	%edi, %edi
   5c57d:      	callq	0x6e9d0 <f.3>
   5c582:      	subq	$0x8, %rsp
   5c586:      	cmpb	$0x0, 0x17323(%rip)     # 0x738b0 <g.4>
   5c58d:      	je	0x6e9c5 <f.2+0x17805>
   5c593:      	cmpq	$0x0, 0x1730d(%rip)     # 0x738a8 <g.3>
   5c59b:      	je	0x6e9c5 <f.2+0x17805>
   5c5a1:      	movq	%rax, %r13
   5c5a4:      	movq	$0x0, 0x50(%rsp)
   5c5ad:      	movq	$0x3, 0x38(%rsp)
   5c5b6:      	xorl	%edi, %edi
   5c5b8:      	leaq	-0xf(%r14), %rsi
   5c5bc:      	callq	0x6e9d0 <f.3>
   5c5c1:      	subq	$0x8, %rsp
   5c5c5:      	cmpb	$0x0, 0x172e4(%rip)     # 0x738b0 <g.4>
   5c5cc:      	je	0x6e9c5 <f.2+0x17805>
   5c5d2:      	movq	%rax, %rsi
   5c5d5:      	cmpq	$0x0, 0x172cb(%rip)     # 0x738a8 <g.3>
   5c5dd:      	leaq	0x28(%rsp), %r8
   5c5e2:      	leaq	0x20(%rsp), %rdi
   5c5e7:      	leaq	0x171da(%rip), %r9      # 0x737c8 <native_roots.0>
   5c5ee:      	leaq	-0xe(%r14), %rax
   5c5f2:      	movq	0x10(%rsp), %rdx
   5c5f7:      	je	0x6e9c5 <f.2+0x17805>
   5c5fd:      	movq	0x58(%rsp), %rcx
   5c602:      	addq	0x60(%rsp), %rcx
   5c607:      	addq	%rbp, %rcx
   5c60a:      	movq	%rcx, %rbp
   5c60d:      	addq	%r13, %rsi
   5c610:      	cmpq	$0x10, %r14
   5c614:      	jae	0x62b0c <f.2+0xb94c>
   5c61a:      	movq	%rbp, %r13
   5c61d:      	jmp	0x62b97 <f.2+0xb9d7>
   5c622:      	movq	%r13, %rbp
   5c625:      	movq	$0x0, 0x50(%rsp)
   5c62e:      	movq	$0x3, 0x38(%rsp)
   5c637:      	xorl	%edi, %edi
   5c639:      	leaq	-0xe(%r14), %rsi
   5c63d:      	callq	0x6e9d0 <f.3>
   5c642:      	subq	$0x8, %rsp
   5c646:      	cmpb	$0x0, 0x17263(%rip)     # 0x738b0 <g.4>
   5c64d:      	je	0x6e9c5 <f.2+0x17805>
   5c653:      	cmpq	$0x0, 0x1724d(%rip)     # 0x738a8 <g.3>
   5c65b:      	je	0x6e9c5 <f.2+0x17805>
   5c661:      	movq	%rax, %r13
   5c664:      	leaq	-0xf(%r14), %rsi
   5c668:      	movq	$0x0, 0x50(%rsp)
   5c671:      	movq	$0x3, 0x38(%rsp)
   5c67a:      	xorl	%edi, %edi
   5c67c:      	callq	0x6e9d0 <f.3>
   5c681:      	subq	$0x8, %rsp
   5c685:      	addq	%r13, %rax
   5c688:      	movq	%rax, 0x10(%rsp)
   5c68d:      	leaq	0x28(%rsp), %r8
   5c692:      	leaq	0x20(%rsp), %rdi
   5c697:      	leaq	0x1712a(%rip), %r9      # 0x737c8 <native_roots.0>
   5c69e:      	movq	%rbp, %r13
   5c6a1:      	cmpb	$0x0, 0x17208(%rip)     # 0x738b0 <g.4>
   5c6a8:      	je	0x6e9c5 <f.2+0x17805>
   5c6ae:      	movq	0x10(%rsp), %rax
   5c6b3:      	addq	%r15, %rax
   5c6b6:      	movq	%rax, %r15
   5c6b9:      	movq	0x18(%rsp), %rax
   5c6be:      	cmpq	$0x0, 0x171e2(%rip)     # 0x738a8 <g.3>
   5c6c6:      	je	0x6e9c5 <f.2+0x17805>
   5c6cc:      	addq	%r13, %r15
   5c6cf:      	addq	%rax, %r15
   5c6d2:      	cmpq	$0x9, %r14
   5c6d6:      	jne	0x57836 <f.2+0x676>
   5c6dc:      	leaq	(%r14,%r15), %r13
   5c6e0:      	addq	$-0x8, %r13
   5c6e4:      	movl	$0x1, %r15d
   5c6ea:      	leaq	-0x9(%r14), %rbp
   5c6ee:      	jmp	0x5fcc5 <f.2+0x8b05>
   5c6f3:      	movq	$0x0, 0x50(%rsp)
   5c6fc:      	movq	$0x3, 0x38(%rsp)
   5c705:      	xorl	%edi, %edi
   5c707:      	leaq	-0xe(%r14), %rsi
   5c70b:      	callq	0x6e9d0 <f.3>
   5c710:      	subq	$0x8, %rsp
   5c714:      	cmpb	$0x0, 0x17195(%rip)     # 0x738b0 <g.4>
   5c71b:      	je	0x6e9c5 <f.2+0x17805>
   5c721:      	cmpq	$0x0, 0x1717f(%rip)     # 0x738a8 <g.3>
   5c729:      	je	0x6e9c5 <f.2+0x17805>
   5c72f:      	movq	%rax, %rbp
   5c732:      	leaq	-0xf(%r14), %rsi
   5c736:      	movq	$0x0, 0x50(%rsp)
   5c73f:      	movq	$0x3, 0x38(%rsp)
   5c748:      	xorl	%edi, %edi
   5c74a:      	callq	0x6e9d0 <f.3>
   5c74f:      	subq	$0x8, %rsp
   5c753:      	cmpb	$0x0, 0x17156(%rip)     # 0x738b0 <g.4>
   5c75a:      	je	0x6e9c5 <f.2+0x17805>
   5c760:      	addq	%rbp, %rax
   5c763:      	addq	%r15, %rax
   5c766:      	addq	0x10(%rsp), %rax
   5c76b:      	movq	%rax, %r15
   5c76e:      	leaq	0x28(%rsp), %r8
   5c773:      	leaq	0x20(%rsp), %rdi
   5c778:      	leaq	0x17049(%rip), %r9      # 0x737c8 <native_roots.0>
   5c77f:      	jmp	0x57874 <f.2+0x6b4>
   5c784:      	movq	%rcx, %rbp
   5c787:      	movq	%r15, %r13
   5c78a:      	movq	$0x0, 0x50(%rsp)
   5c793:      	movq	$0x3, 0x38(%rsp)
   5c79c:      	xorl	%edi, %edi
   5c79e:      	leaq	-0xe(%r14), %rsi
   5c7a2:      	callq	0x6e9d0 <f.3>
   5c7a7:      	subq	$0x8, %rsp
   5c7ab:      	cmpb	$0x0, 0x170fe(%rip)     # 0x738b0 <g.4>
   5c7b2:      	je	0x6e9c5 <f.2+0x17805>
   5c7b8:      	cmpq	$0x0, 0x170e8(%rip)     # 0x738a8 <g.3>
   5c7c0:      	je	0x6e9c5 <f.2+0x17805>
   5c7c6:      	movq	%rax, %r15
   5c7c9:      	leaq	-0xf(%r14), %rsi
   5c7cd:      	movq	$0x0, 0x50(%rsp)
   5c7d6:      	movq	$0x3, 0x38(%rsp)
   5c7df:      	xorl	%edi, %edi
   5c7e1:      	callq	0x6e9d0 <f.3>
   5c7e6:      	subq	$0x8, %rsp
   5c7ea:      	addq	%r15, %rax
   5c7ed:      	movq	%rax, 0x10(%rsp)
   5c7f2:      	leaq	0x28(%rsp), %r8
   5c7f7:      	leaq	0x20(%rsp), %rdi
   5c7fc:      	leaq	0x16fc5(%rip), %r9      # 0x737c8 <native_roots.0>
   5c803:      	movq	%r13, %r15
   5c806:      	movq	%rbp, %rcx
   5c809:      	cmpb	$0x0, 0x170a0(%rip)     # 0x738b0 <g.4>
   5c810:      	je	0x6e9c5 <f.2+0x17805>
   5c816:      	movq	0x10(%rsp), %rax
   5c81b:      	addq	%rcx, %rax
   5c81e:      	movq	%rax, %r13
   5c821:      	movq	0x18(%rsp), %rax
   5c826:      	cmpq	$0x0, 0x1707a(%rip)     # 0x738a8 <g.3>
   5c82e:      	je	0x6e9c5 <f.2+0x17805>
   5c834:      	addq	%r15, %r13
   5c837:      	addq	%rax, %r13
   5c83a:      	cmpq	$0x9, %r14
   5c83e:      	jne	0x57967 <f.2+0x7a7>
   5c844:      	leaq	(%r14,%r13), %r15
   5c848:      	addq	$-0x8, %r15
   5c84c:      	movl	$0x1, %ebp
   5c851:      	leaq	-0x9(%r14), %rax
   5c855:      	jmp	0x62a1c <f.2+0xb85c>
   5c85a:      	movq	%rcx, 0x58(%rsp)
   5c85f:      	movq	$0x0, 0x50(%rsp)
   5c868:      	movq	$0x3, 0x38(%rsp)
   5c871:      	xorl	%edi, %edi
   5c873:      	leaq	-0xf(%r14), %rsi
   5c877:      	callq	0x6e9d0 <f.3>
   5c87c:      	subq	$0x8, %rsp
   5c880:      	cmpb	$0x0, 0x17029(%rip)     # 0x738b0 <g.4>
   5c887:      	je	0x6e9c5 <f.2+0x17805>
   5c88d:      	cmpq	$0x0, 0x17013(%rip)     # 0x738a8 <g.3>
   5c895:      	je	0x6e9c5 <f.2+0x17805>
   5c89b:      	movq	%rax, %r12
   5c89e:      	leaq	-0x10(%r14), %rsi
   5c8a2:      	movq	$0x0, 0x50(%rsp)
   5c8ab:      	movq	$0x3, 0x38(%rsp)
   5c8b4:      	xorl	%edi, %edi
   5c8b6:      	callq	0x6e9d0 <f.3>
   5c8bb:      	subq	$0x8, %rsp
   5c8bf:      	movq	%rax, %r13
   5c8c2:      	addq	%r12, %r13
   5c8c5:      	leaq	0x28(%rsp), %r8
   5c8ca:      	leaq	0x20(%rsp), %rdi
   5c8cf:      	leaq	0x16ef2(%rip), %r9      # 0x737c8 <native_roots.0>
   5c8d6:      	movq	0x18(%rsp), %r12
   5c8db:      	movq	0x10(%rsp), %rax
   5c8e0:      	movq	0x58(%rsp), %rcx
   5c8e5:      	cmpb	$0x0, 0x16fc4(%rip)     # 0x738b0 <g.4>
   5c8ec:      	je	0x6e9c5 <f.2+0x17805>
   5c8f2:      	cmpq	$0x0, 0x16fae(%rip)     # 0x738a8 <g.3>
   5c8fa:      	je	0x6e9c5 <f.2+0x17805>
   5c900:      	addq	%rcx, %r13
   5c903:      	addq	%rbp, %r13
   5c906:      	movq	%r14, %rbp
   5c909:      	subq	$0xe, %rbp
   5c90d:      	jbe	0x5c9c7 <f.2+0x5807>
   5c913:      	movq	$0x0, 0x50(%rsp)
   5c91c:      	movq	$0x3, 0x38(%rsp)
   5c925:      	xorl	%edi, %edi
   5c927:      	movq	%rbp, %rsi
   5c92a:      	callq	0x6e9d0 <f.3>
   5c92f:      	subq	$0x8, %rsp
   5c933:      	cmpb	$0x0, 0x16f76(%rip)     # 0x738b0 <g.4>
   5c93a:      	je	0x6e9c5 <f.2+0x17805>
   5c940:      	cmpq	$0x0, 0x16f60(%rip)     # 0x738a8 <g.3>
   5c948:      	je	0x6e9c5 <f.2+0x17805>
   5c94e:      	movq	%rax, %r12
   5c951:      	leaq	-0xf(%r14), %rsi
   5c955:      	movq	$0x0, 0x50(%rsp)
   5c95e:      	movq	$0x3, 0x38(%rsp)
   5c967:      	xorl	%edi, %edi
   5c969:      	callq	0x6e9d0 <f.3>
   5c96e:      	subq	$0x8, %rsp
   5c972:      	cmpb	$0x0, 0x16f37(%rip)     # 0x738b0 <g.4>
   5c979:      	je	0x6e9c5 <f.2+0x17805>
   5c97f:      	movq	%rax, %rcx
   5c982:      	cmpq	$0x0, 0x16f1e(%rip)     # 0x738a8 <g.3>
   5c98a:      	movq	0x10(%rsp), %rax
   5c98f:      	je	0x6e9c5 <f.2+0x17805>
   5c995:      	addq	%r12, %rcx
   5c998:      	cmpq	$0xf, %r14
   5c99c:      	leaq	-0xf(%r14), %rsi
   5c9a0:      	jne	0x5c9d3 <f.2+0x5813>
   5c9a2:      	addq	%rcx, %rbp
   5c9a5:      	movl	$0x1, %edx
   5c9aa:      	xorl	%ecx, %ecx
   5c9ac:      	leaq	0x28(%rsp), %r8
   5c9b1:      	leaq	0x20(%rsp), %rdi
   5c9b6:      	leaq	0x16e0b(%rip), %r9      # 0x737c8 <native_roots.0>
   5c9bd:      	movq	0x18(%rsp), %r12
   5c9c2:      	jmp	0x632e1 <f.2+0xc121>
   5c9c7:      	incq	%rbp
   5c9ca:      	leaq	-0xd(%r14), %rdx
   5c9ce:      	jmp	0x632e4 <f.2+0xc124>
   5c9d3:      	movq	%rcx, 0x58(%rsp)
   5c9d8:      	movq	$0x0, 0x50(%rsp)
   5c9e1:      	movq	$0x3, 0x38(%rsp)
   5c9ea:      	xorl	%edi, %edi
   5c9ec:      	callq	0x6e9d0 <f.3>
   5c9f1:      	subq	$0x8, %rsp
   5c9f5:      	cmpb	$0x0, 0x16eb4(%rip)     # 0x738b0 <g.4>
   5c9fc:      	movq	0x18(%rsp), %r12
   5ca01:      	je	0x6e9c5 <f.2+0x17805>
   5ca07:      	movq	%rax, 0x60(%rsp)
   5ca0c:      	cmpq	$0x0, 0x16e94(%rip)     # 0x738a8 <g.3>
   5ca14:      	je	0x6e9c5 <f.2+0x17805>
   5ca1a:      	leaq	-0x10(%r14), %rsi
   5ca1e:      	movq	$0x0, 0x50(%rsp)
   5ca27:      	movq	$0x3, 0x38(%rsp)
   5ca30:      	xorl	%edi, %edi
   5ca32:      	callq	0x6e9d0 <f.3>
   5ca37:      	subq	$0x8, %rsp
   5ca3b:      	cmpb	$0x0, 0x16e6e(%rip)     # 0x738b0 <g.4>
   5ca42:      	je	0x6e9c5 <f.2+0x17805>
   5ca48:      	cmpq	$0x0, 0x16e58(%rip)     # 0x738a8 <g.3>
   5ca50:      	leaq	-0xf(%r14), %rsi
   5ca54:      	je	0x6e9c5 <f.2+0x17805>
   5ca5a:      	movq	%rax, %rbp
   5ca5d:      	movq	$0x0, 0x50(%rsp)
   5ca66:      	movq	$0x3, 0x38(%rsp)
   5ca6f:      	xorl	%edi, %edi
   5ca71:      	callq	0x6e9d0 <f.3>
   5ca76:      	subq	$0x8, %rsp
   5ca7a:      	cmpb	$0x0, 0x16e2f(%rip)     # 0x738b0 <g.4>
   5ca81:      	je	0x6e9c5 <f.2+0x17805>
   5ca87:      	movq	%rax, 0x68(%rsp)
   5ca8c:      	cmpq	$0x0, 0x16e14(%rip)     # 0x738a8 <g.3>
   5ca94:      	je	0x6e9c5 <f.2+0x17805>
   5ca9a:      	movq	$0x0, 0x50(%rsp)
   5caa3:      	movq	$0x3, 0x38(%rsp)
   5caac:      	xorl	%edi, %edi
   5caae:      	leaq	-0x10(%r14), %rsi
   5cab2:      	callq	0x6e9d0 <f.3>
   5cab7:      	subq	$0x8, %rsp
   5cabb:      	cmpb	$0x0, 0x16dee(%rip)     # 0x738b0 <g.4>
   5cac2:      	je	0x6e9c5 <f.2+0x17805>
   5cac8:      	movq	%rax, %rdx
   5cacb:      	cmpq	$0x0, 0x16dd5(%rip)     # 0x738a8 <g.3>
   5cad3:      	movq	0x10(%rsp), %rax
   5cad8:      	leaq	-0xf(%r14), %rcx
   5cadc:      	je	0x6e9c5 <f.2+0x17805>
   5cae2:      	addq	0x60(%rsp), %rbp
   5cae7:      	addq	0x58(%rsp), %rbp
   5caec:      	addq	0x68(%rsp), %rdx
   5caf1:      	cmpq	$0x11, %r14
   5caf5:      	jae	0x63256 <f.2+0xc096>
   5cafb:      	leaq	0x28(%rsp), %r8
   5cb00:      	leaq	0x20(%rsp), %rdi
   5cb05:      	leaq	0x16cbc(%rip), %r9      # 0x737c8 <native_roots.0>
   5cb0c:      	jmp	0x632e1 <f.2+0xc121>
   5cb11:      	movq	$0x0, 0x50(%rsp)
   5cb1a:      	movq	$0x3, 0x38(%rsp)
   5cb23:      	xorl	%edi, %edi
   5cb25:      	leaq	-0xf(%r14), %rsi
   5cb29:      	callq	0x6e9d0 <f.3>
   5cb2e:      	subq	$0x8, %rsp
   5cb32:      	cmpb	$0x0, 0x16d77(%rip)     # 0x738b0 <g.4>
   5cb39:      	je	0x6e9c5 <f.2+0x17805>
   5cb3f:      	movq	%rax, 0x18(%rsp)
   5cb44:      	cmpq	$0x0, 0x16d5c(%rip)     # 0x738a8 <g.3>
   5cb4c:      	je	0x6e9c5 <f.2+0x17805>
   5cb52:      	leaq	-0x10(%r14), %rsi
   5cb56:      	movq	$0x0, 0x50(%rsp)
   5cb5f:      	movq	$0x3, 0x38(%rsp)
   5cb68:      	xorl	%edi, %edi
   5cb6a:      	callq	0x6e9d0 <f.3>
   5cb6f:      	subq	$0x8, %rsp
   5cb73:      	addq	0x18(%rsp), %rax
   5cb78:      	leaq	0x28(%rsp), %r8
   5cb7d:      	leaq	0x20(%rsp), %rdi
   5cb82:      	leaq	0x16c3f(%rip), %r9      # 0x737c8 <native_roots.0>
   5cb89:      	addq	%rax, %r15
   5cb8c:      	addq	%r15, %r13
   5cb8f:      	movq	0x10(%rsp), %r15
   5cb94:      	cmpb	$0x0, 0x16d15(%rip)     # 0x738b0 <g.4>
   5cb9b:      	je	0x6e9c5 <f.2+0x17805>
   5cba1:      	cmpq	$0x0, 0x16cff(%rip)     # 0x738a8 <g.3>
   5cba9:      	je	0x6e9c5 <f.2+0x17805>
   5cbaf:      	addq	%rbp, %r13
   5cbb2:      	addq	%r15, %r13
   5cbb5:      	cmpq	$0xa, %r14
   5cbb9:      	jbe	0x5cc72 <f.2+0x5ab2>
   5cbbf:      	movl	$0x1, %r15d
   5cbc5:      	cmpq	$0xb, %r14
   5cbc9:      	je	0x5cc82 <f.2+0x5ac2>
   5cbcf:      	movq	%r14, %r15
   5cbd2:      	subq	$0xc, %r15
   5cbd6:      	jbe	0x5cc7f <f.2+0x5abf>
   5cbdc:      	movq	$0x0, 0x50(%rsp)
   5cbe5:      	movq	$0x3, 0x38(%rsp)
   5cbee:      	xorl	%edi, %edi
   5cbf0:      	movq	%r15, %rsi
   5cbf3:      	callq	0x6e9d0 <f.3>
   5cbf8:      	subq	$0x8, %rsp
   5cbfc:      	cmpb	$0x0, 0x16cad(%rip)     # 0x738b0 <g.4>
   5cc03:      	je	0x6e9c5 <f.2+0x17805>
   5cc09:      	cmpq	$0x0, 0x16c97(%rip)     # 0x738a8 <g.3>
   5cc11:      	je	0x6e9c5 <f.2+0x17805>
   5cc17:      	movq	%rax, %rbp
   5cc1a:      	leaq	-0xd(%r14), %rsi
   5cc1e:      	movq	$0x0, 0x50(%rsp)
   5cc27:      	movq	$0x3, 0x38(%rsp)
   5cc30:      	xorl	%edi, %edi
   5cc32:      	callq	0x6e9d0 <f.3>
   5cc37:      	subq	$0x8, %rsp
   5cc3b:      	cmpb	$0x0, 0x16c6e(%rip)     # 0x738b0 <g.4>
   5cc42:      	je	0x6e9c5 <f.2+0x17805>
   5cc48:      	cmpq	$0x0, 0x16c58(%rip)     # 0x738a8 <g.3>
   5cc50:      	je	0x6e9c5 <f.2+0x17805>
   5cc56:      	addq	%rbp, %rax
   5cc59:      	cmpq	$0xd, %r14
   5cc5d:      	leaq	-0xd(%r14), %rsi
   5cc61:      	jne	0x5cc8f <f.2+0x5acf>
   5cc63:      	addq	%rax, %r15
   5cc66:      	movl	$0x1, %ecx
   5cc6b:      	xorl	%eax, %eax
   5cc6d:      	jmp	0x5cda5 <f.2+0x5be5>
   5cc72:      	leaq	-0x9(%r14), %r15
   5cc76:      	leaq	-0x9(%r14), %rbp
   5cc7a:      	jmp	0x5fcc5 <f.2+0x8b05>
   5cc7f:      	incq	%r15
   5cc82:      	leaq	(%r14,%r15), %rax
   5cc86:      	addq	$-0xb, %rax
   5cc8a:      	jmp	0x5ce57 <f.2+0x5c97>
   5cc8f:      	movq	%rax, 0x10(%rsp)
   5cc94:      	movq	$0x0, 0x50(%rsp)
   5cc9d:      	movq	$0x3, 0x38(%rsp)
   5cca6:      	xorl	%edi, %edi
   5cca8:      	callq	0x6e9d0 <f.3>
   5ccad:      	subq	$0x8, %rsp
   5ccb1:      	cmpb	$0x0, 0x16bf8(%rip)     # 0x738b0 <g.4>
   5ccb8:      	je	0x6e9c5 <f.2+0x17805>
   5ccbe:      	movq	%rax, 0x18(%rsp)
   5ccc3:      	cmpq	$0x0, 0x16bdd(%rip)     # 0x738a8 <g.3>
   5cccb:      	je	0x6e9c5 <f.2+0x17805>
   5ccd1:      	leaq	-0xe(%r14), %rsi
   5ccd5:      	movq	$0x0, 0x50(%rsp)
   5ccde:      	movq	$0x3, 0x38(%rsp)
   5cce7:      	xorl	%edi, %edi
   5cce9:      	callq	0x6e9d0 <f.3>
   5ccee:      	subq	$0x8, %rsp
   5ccf2:      	cmpb	$0x0, 0x16bb7(%rip)     # 0x738b0 <g.4>
   5ccf9:      	je	0x6e9c5 <f.2+0x17805>
   5ccff:      	cmpq	$0x0, 0x16ba1(%rip)     # 0x738a8 <g.3>
   5cd07:      	leaq	-0xd(%r14), %rsi
   5cd0b:      	je	0x6e9c5 <f.2+0x17805>
   5cd11:      	movq	%rax, %r15
   5cd14:      	movq	$0x0, 0x50(%rsp)
   5cd1d:      	movq	$0x3, 0x38(%rsp)
   5cd26:      	xorl	%edi, %edi
   5cd28:      	callq	0x6e9d0 <f.3>
   5cd2d:      	subq	$0x8, %rsp
   5cd31:      	cmpb	$0x0, 0x16b78(%rip)     # 0x738b0 <g.4>
   5cd38:      	je	0x6e9c5 <f.2+0x17805>
   5cd3e:      	cmpq	$0x0, 0x16b62(%rip)     # 0x738a8 <g.3>
   5cd46:      	je	0x6e9c5 <f.2+0x17805>
   5cd4c:      	movq	%rax, %rbp
   5cd4f:      	movq	$0x0, 0x50(%rsp)
   5cd58:      	movq	$0x3, 0x38(%rsp)
   5cd61:      	xorl	%edi, %edi
   5cd63:      	leaq	-0xe(%r14), %rsi
   5cd67:      	callq	0x6e9d0 <f.3>
   5cd6c:      	subq	$0x8, %rsp
   5cd70:      	cmpb	$0x0, 0x16b39(%rip)     # 0x738b0 <g.4>
   5cd77:      	je	0x6e9c5 <f.2+0x17805>
   5cd7d:      	movq	%rax, %rcx
   5cd80:      	cmpq	$0x0, 0x16b20(%rip)     # 0x738a8 <g.3>
   5cd88:      	leaq	-0xd(%r14), %rax
   5cd8c:      	je	0x6e9c5 <f.2+0x17805>
   5cd92:      	addq	0x18(%rsp), %r15
   5cd97:      	addq	0x10(%rsp), %r15
   5cd9c:      	addq	%rbp, %rcx
   5cd9f:      	cmpq	$0xf, %r14
   5cda3:      	jae	0x5cdb8 <f.2+0x5bf8>
   5cda5:      	leaq	0x28(%rsp), %r8
   5cdaa:      	leaq	0x20(%rsp), %rdi
   5cdaf:      	leaq	0x16a12(%rip), %r9      # 0x737c8 <native_roots.0>
   5cdb6:      	jmp	0x5ce36 <f.2+0x5c76>
   5cdb8:      	movq	%rcx, 0x10(%rsp)
   5cdbd:      	movq	$0x0, 0x50(%rsp)
   5cdc6:      	movq	$0x3, 0x38(%rsp)
   5cdcf:      	xorl	%edi, %edi
   5cdd1:      	leaq	-0xe(%r14), %rsi
   5cdd5:      	callq	0x6e9d0 <f.3>
   5cdda:      	subq	$0x8, %rsp
   5cdde:      	cmpb	$0x0, 0x16acb(%rip)     # 0x738b0 <g.4>
   5cde5:      	je	0x6e9c5 <f.2+0x17805>
   5cdeb:      	cmpq	$0x0, 0x16ab5(%rip)     # 0x738a8 <g.3>
   5cdf3:      	je	0x6e9c5 <f.2+0x17805>
   5cdf9:      	movq	%rax, %rbp
   5cdfc:      	leaq	-0xf(%r14), %rsi
   5ce00:      	movq	$0x0, 0x50(%rsp)
   5ce09:      	movq	$0x3, 0x38(%rsp)
   5ce12:      	xorl	%edi, %edi
   5ce14:      	callq	0x6e9d0 <f.3>
   5ce19:      	subq	$0x8, %rsp
   5ce1d:      	addq	%rbp, %rax
   5ce20:      	leaq	0x28(%rsp), %r8
   5ce25:      	leaq	0x20(%rsp), %rdi
   5ce2a:      	leaq	0x16997(%rip), %r9      # 0x737c8 <native_roots.0>
   5ce31:      	movq	0x10(%rsp), %rcx
   5ce36:      	cmpb	$0x0, 0x16a73(%rip)     # 0x738b0 <g.4>
   5ce3d:      	je	0x6e9c5 <f.2+0x17805>
   5ce43:      	cmpq	$0x0, 0x16a5d(%rip)     # 0x738a8 <g.3>
   5ce4b:      	je	0x6e9c5 <f.2+0x17805>
   5ce51:      	addq	%rcx, %rax
   5ce54:      	addq	%r15, %rax
   5ce57:      	cmpq	$0xb, %r14
   5ce5b:      	je	0x5cf2e <f.2+0x5d6e>
   5ce61:      	movl	$0x1, %ebp
   5ce66:      	cmpq	$0xc, %r14
   5ce6a:      	je	0x5cf47 <f.2+0x5d87>
   5ce70:      	movq	%r14, %rbp
   5ce73:      	subq	$0xd, %rbp
   5ce77:      	jbe	0x5cf44 <f.2+0x5d84>
   5ce7d:      	movq	%rax, 0x10(%rsp)
   5ce82:      	movq	$0x0, 0x50(%rsp)
   5ce8b:      	movq	$0x3, 0x38(%rsp)
   5ce94:      	xorl	%edi, %edi
   5ce96:      	movq	%rbp, %rsi
   5ce99:      	callq	0x6e9d0 <f.3>
   5ce9e:      	subq	$0x8, %rsp
   5cea2:      	cmpb	$0x0, 0x16a07(%rip)     # 0x738b0 <g.4>
   5cea9:      	je	0x6e9c5 <f.2+0x17805>
   5ceaf:      	cmpq	$0x0, 0x169f1(%rip)     # 0x738a8 <g.3>
   5ceb7:      	je	0x6e9c5 <f.2+0x17805>
   5cebd:      	movq	%rax, %r15
   5cec0:      	leaq	-0xe(%r14), %rsi
   5cec4:      	movq	$0x0, 0x50(%rsp)
   5cecd:      	movq	$0x3, 0x38(%rsp)
   5ced6:      	xorl	%edi, %edi
   5ced8:      	callq	0x6e9d0 <f.3>
   5cedd:      	subq	$0x8, %rsp
   5cee1:      	cmpb	$0x0, 0x169c8(%rip)     # 0x738b0 <g.4>
   5cee8:      	je	0x6e9c5 <f.2+0x17805>
   5ceee:      	movq	%rax, %rcx
   5cef1:      	cmpq	$0x0, 0x169af(%rip)     # 0x738a8 <g.3>
   5cef9:      	movq	0x10(%rsp), %rax
   5cefe:      	je	0x6e9c5 <f.2+0x17805>
   5cf04:      	addq	%r15, %rcx
   5cf07:      	cmpq	$0xe, %r14
   5cf0b:      	jne	0x5cf50 <f.2+0x5d90>
   5cf0d:      	addq	%rcx, %rbp
   5cf10:      	movl	$0x1, %r15d
   5cf16:      	xorl	%ecx, %ecx
   5cf18:      	leaq	0x28(%rsp), %r8
   5cf1d:      	leaq	0x20(%rsp), %rdi
   5cf22:      	leaq	0x1689f(%rip), %r9      # 0x737c8 <native_roots.0>
   5cf29:      	jmp	0x5d10e <f.2+0x5f4e>
   5cf2e:      	leaq	(%r14,%rax), %r15
   5cf32:      	addq	$-0xa, %r15
   5cf36:      	movl	$0x1, %ebp
   5cf3b:      	leaq	-0xb(%r14), %rsi
   5cf3f:      	jmp	0x5fcc2 <f.2+0x8b02>
   5cf44:      	incq	%rbp
   5cf47:      	leaq	-0xc(%r14), %r15
   5cf4b:      	jmp	0x5d111 <f.2+0x5f51>
   5cf50:      	movq	%rcx, 0x18(%rsp)
   5cf55:      	movq	$0x0, 0x50(%rsp)
   5cf5e:      	movq	$0x3, 0x38(%rsp)
   5cf67:      	xorl	%edi, %edi
   5cf69:      	leaq	-0xe(%r14), %r15
   5cf6d:      	movq	%r15, %rsi
   5cf70:      	callq	0x6e9d0 <f.3>
   5cf75:      	subq	$0x8, %rsp
   5cf79:      	cmpb	$0x0, 0x16930(%rip)     # 0x738b0 <g.4>
   5cf80:      	je	0x6e9c5 <f.2+0x17805>
   5cf86:      	movq	%rax, 0x58(%rsp)
   5cf8b:      	cmpq	$0x0, 0x16915(%rip)     # 0x738a8 <g.3>
   5cf93:      	je	0x6e9c5 <f.2+0x17805>
   5cf99:      	leaq	-0xf(%r14), %rsi
   5cf9d:      	movq	$0x0, 0x50(%rsp)
   5cfa6:      	movq	$0x3, 0x38(%rsp)
   5cfaf:      	xorl	%edi, %edi
   5cfb1:      	callq	0x6e9d0 <f.3>
   5cfb6:      	subq	$0x8, %rsp
   5cfba:      	cmpb	$0x0, 0x168ef(%rip)     # 0x738b0 <g.4>
   5cfc1:      	je	0x6e9c5 <f.2+0x17805>
   5cfc7:      	cmpq	$0x0, 0x168d9(%rip)     # 0x738a8 <g.3>
   5cfcf:      	je	0x6e9c5 <f.2+0x17805>
   5cfd5:      	movq	%rax, %rbp
   5cfd8:      	movq	$0x0, 0x50(%rsp)
   5cfe1:      	movq	$0x3, 0x38(%rsp)
   5cfea:      	xorl	%edi, %edi
   5cfec:      	movq	%r15, %rsi
   5cfef:      	callq	0x6e9d0 <f.3>
   5cff4:      	subq	$0x8, %rsp
   5cff8:      	cmpb	$0x0, 0x168b1(%rip)     # 0x738b0 <g.4>
   5cfff:      	je	0x6e9c5 <f.2+0x17805>
   5d005:      	movq	%rax, 0x60(%rsp)
   5d00a:      	cmpq	$0x0, 0x16896(%rip)     # 0x738a8 <g.3>
   5d012:      	je	0x6e9c5 <f.2+0x17805>
   5d018:      	movq	$0x0, 0x50(%rsp)
   5d021:      	movq	$0x3, 0x38(%rsp)
   5d02a:      	xorl	%edi, %edi
   5d02c:      	leaq	-0xf(%r14), %rsi
   5d030:      	callq	0x6e9d0 <f.3>
   5d035:      	subq	$0x8, %rsp
   5d039:      	cmpb	$0x0, 0x16870(%rip)     # 0x738b0 <g.4>
   5d040:      	je	0x6e9c5 <f.2+0x17805>
   5d046:      	movq	%rax, %r15
   5d049:      	cmpq	$0x0, 0x16857(%rip)     # 0x738a8 <g.3>
   5d051:      	movq	0x10(%rsp), %rax
   5d056:      	movq	0x18(%rsp), %rcx
   5d05b:      	je	0x6e9c5 <f.2+0x17805>
   5d061:      	addq	0x58(%rsp), %rbp
   5d066:      	addq	%rcx, %rbp
   5d069:      	addq	0x60(%rsp), %r15
   5d06e:      	cmpq	$0x10, %r14
   5d072:      	jae	0x5d08e <f.2+0x5ece>
   5d074:      	leaq	0x28(%rsp), %r8
   5d079:      	leaq	0x20(%rsp), %rdi
   5d07e:      	leaq	0x16743(%rip), %r9      # 0x737c8 <native_roots.0>
   5d085:      	leaq	-0xe(%r14), %rcx
   5d089:      	jmp	0x5d10e <f.2+0x5f4e>
   5d08e:      	movq	$0x0, 0x50(%rsp)
   5d097:      	movq	$0x3, 0x38(%rsp)
   5d0a0:      	xorl	%edi, %edi
   5d0a2:      	leaq	-0xf(%r14), %rsi
   5d0a6:      	callq	0x6e9d0 <f.3>
   5d0ab:      	subq	$0x8, %rsp
   5d0af:      	cmpb	$0x0, 0x167fa(%rip)     # 0x738b0 <g.4>
   5d0b6:      	je	0x6e9c5 <f.2+0x17805>
   5d0bc:      	movq	%rax, 0x18(%rsp)
   5d0c1:      	cmpq	$0x0, 0x167df(%rip)     # 0x738a8 <g.3>
   5d0c9:      	je	0x6e9c5 <f.2+0x17805>
   5d0cf:      	leaq	-0x10(%r14), %rsi
   5d0d3:      	movq	$0x0, 0x50(%rsp)
   5d0dc:      	movq	$0x3, 0x38(%rsp)
   5d0e5:      	xorl	%edi, %edi
   5d0e7:      	callq	0x6e9d0 <f.3>
   5d0ec:      	subq	$0x8, %rsp
   5d0f0:      	movq	%rax, %rcx
   5d0f3:      	addq	0x18(%rsp), %rcx
   5d0f8:      	leaq	0x28(%rsp), %r8
   5d0fd:      	leaq	0x20(%rsp), %rdi
   5d102:      	leaq	0x166bf(%rip), %r9      # 0x737c8 <native_roots.0>
   5d109:      	movq	0x10(%rsp), %rax
   5d10e:      	addq	%rcx, %r15
   5d111:      	cmpb	$0x0, 0x16798(%rip)     # 0x738b0 <g.4>
   5d118:      	je	0x6e9c5 <f.2+0x17805>
   5d11e:      	cmpq	$0x0, 0x16782(%rip)     # 0x738a8 <g.3>
   5d126:      	je	0x6e9c5 <f.2+0x17805>
   5d12c:      	addq	%rbp, %r15
   5d12f:      	addq	%rax, %r15
   5d132:      	cmpq	$0xc, %r14
   5d136:      	jbe	0x5d14a <f.2+0x5f8a>
   5d138:      	cmpq	$0xd, %r14
   5d13c:      	jne	0x5d157 <f.2+0x5f97>
   5d13e:      	movl	$0x1, %ebp
   5d143:      	xorl	%eax, %eax
   5d145:      	jmp	0x5d28f <f.2+0x60cf>
   5d14a:      	leaq	-0xb(%r14), %rbp
   5d14e:      	leaq	-0xb(%r14), %rsi
   5d152:      	jmp	0x5fcc2 <f.2+0x8b02>
   5d157:      	leaq	-0xd(%r14), %rsi
   5d15b:      	movq	$0x0, 0x50(%rsp)
   5d164:      	movq	$0x3, 0x38(%rsp)
   5d16d:      	xorl	%edi, %edi
   5d16f:      	callq	0x6e9d0 <f.3>
   5d174:      	subq	$0x8, %rsp
   5d178:      	cmpb	$0x0, 0x16731(%rip)     # 0x738b0 <g.4>
   5d17f:      	je	0x6e9c5 <f.2+0x17805>
   5d185:      	movq	%rax, 0x10(%rsp)
   5d18a:      	cmpq	$0x0, 0x16716(%rip)     # 0x738a8 <g.3>
   5d192:      	je	0x6e9c5 <f.2+0x17805>
   5d198:      	leaq	-0xe(%r14), %rsi
   5d19c:      	movq	$0x0, 0x50(%rsp)
   5d1a5:      	movq	$0x3, 0x38(%rsp)
   5d1ae:      	xorl	%edi, %edi
   5d1b0:      	callq	0x6e9d0 <f.3>
   5d1b5:      	subq	$0x8, %rsp
   5d1b9:      	cmpb	$0x0, 0x166f0(%rip)     # 0x738b0 <g.4>
   5d1c0:      	je	0x6e9c5 <f.2+0x17805>
   5d1c6:      	movq	%rax, %rbp
   5d1c9:      	cmpq	$0x0, 0x166d7(%rip)     # 0x738a8 <g.3>
   5d1d1:      	leaq	-0xd(%r14), %rax
   5d1d5:      	je	0x6e9c5 <f.2+0x17805>
   5d1db:      	addq	0x10(%rsp), %rbp
   5d1e0:      	cmpq	$0xe, %r14
   5d1e4:      	ja	0x5d1fc <f.2+0x603c>
   5d1e6:      	leaq	0x28(%rsp), %r8
   5d1eb:      	leaq	0x20(%rsp), %rdi
   5d1f0:      	leaq	0x165d1(%rip), %r9      # 0x737c8 <native_roots.0>
   5d1f7:      	jmp	0x5d28f <f.2+0x60cf>
   5d1fc:      	movq	$0x0, 0x50(%rsp)
   5d205:      	movq	$0x3, 0x38(%rsp)
   5d20e:      	xorl	%edi, %edi
   5d210:      	leaq	-0xe(%r14), %rsi
   5d214:      	callq	0x6e9d0 <f.3>
   5d219:      	subq	$0x8, %rsp
   5d21d:      	cmpb	$0x0, 0x1668c(%rip)     # 0x738b0 <g.4>
   5d224:      	je	0x6e9c5 <f.2+0x17805>
   5d22a:      	movq	%rax, 0x10(%rsp)
   5d22f:      	cmpq	$0x0, 0x16671(%rip)     # 0x738a8 <g.3>
   5d237:      	je	0x6e9c5 <f.2+0x17805>
   5d23d:      	leaq	-0xf(%r14), %rsi
   5d241:      	movq	$0x0, 0x50(%rsp)
   5d24a:      	movq	$0x3, 0x38(%rsp)
   5d253:      	xorl	%edi, %edi
   5d255:      	callq	0x6e9d0 <f.3>
   5d25a:      	subq	$0x8, %rsp
   5d25e:      	cmpb	$0x0, 0x1664b(%rip)     # 0x738b0 <g.4>
   5d265:      	je	0x6e9c5 <f.2+0x17805>
   5d26b:      	cmpq	$0x0, 0x16635(%rip)     # 0x738a8 <g.3>
   5d273:      	leaq	0x28(%rsp), %r8
   5d278:      	leaq	0x20(%rsp), %rdi
   5d27d:      	leaq	0x16544(%rip), %r9      # 0x737c8 <native_roots.0>
   5d284:      	je	0x6e9c5 <f.2+0x17805>
   5d28a:      	addq	0x10(%rsp), %rax
   5d28f:      	addq	%rbp, %rax
   5d292:      	cmpq	$0xd, %r14
   5d296:      	je	0x5d2aa <f.2+0x60ea>
   5d298:      	cmpq	$0xe, %r14
   5d29c:      	jne	0x5d2c0 <f.2+0x6100>
   5d29e:      	movl	$0x1, %ecx
   5d2a3:      	xorl	%ebp, %ebp
   5d2a5:      	jmp	0x5d3f8 <f.2+0x6238>
   5d2aa:      	leaq	(%r14,%rax), %rbp
   5d2ae:      	addq	$-0xc, %rbp
   5d2b2:      	movl	$0x1, %esi
   5d2b7:      	leaq	-0xd(%r14), %rdx
   5d2bb:      	jmp	0x5fcbf <f.2+0x8aff>
   5d2c0:      	movq	%rax, 0x10(%rsp)
   5d2c5:      	leaq	-0xe(%r14), %rbp
   5d2c9:      	movq	$0x0, 0x50(%rsp)
   5d2d2:      	movq	$0x3, 0x38(%rsp)
   5d2db:      	xorl	%edi, %edi
   5d2dd:      	movq	%rbp, %rsi
   5d2e0:      	callq	0x6e9d0 <f.3>
   5d2e5:      	subq	$0x8, %rsp
   5d2e9:      	cmpb	$0x0, 0x165c0(%rip)     # 0x738b0 <g.4>
   5d2f0:      	je	0x6e9c5 <f.2+0x17805>
   5d2f6:      	movq	%rax, 0x18(%rsp)
   5d2fb:      	cmpq	$0x0, 0x165a5(%rip)     # 0x738a8 <g.3>
   5d303:      	je	0x6e9c5 <f.2+0x17805>
   5d309:      	leaq	-0xf(%r14), %rsi
   5d30d:      	movq	$0x0, 0x50(%rsp)
   5d316:      	movq	$0x3, 0x38(%rsp)
   5d31f:      	xorl	%edi, %edi
   5d321:      	callq	0x6e9d0 <f.3>
   5d326:      	subq	$0x8, %rsp
   5d32a:      	cmpb	$0x0, 0x1657f(%rip)     # 0x738b0 <g.4>
   5d331:      	je	0x6e9c5 <f.2+0x17805>
   5d337:      	movq	%rax, %rcx
   5d33a:      	cmpq	$0x0, 0x16566(%rip)     # 0x738a8 <g.3>
   5d342:      	leaq	0x20(%rsp), %rdi
   5d347:      	movq	0x10(%rsp), %rax
   5d34c:      	je	0x6e9c5 <f.2+0x17805>
   5d352:      	addq	0x18(%rsp), %rcx
   5d357:      	cmpq	$0x10, %r14
   5d35b:      	jae	0x5d36e <f.2+0x61ae>
   5d35d:      	leaq	0x28(%rsp), %r8
   5d362:      	leaq	0x1645f(%rip), %r9      # 0x737c8 <native_roots.0>
   5d369:      	jmp	0x5d3f8 <f.2+0x6238>
   5d36e:      	movq	%rcx, 0x18(%rsp)
   5d373:      	movq	$0x0, 0x50(%rsp)
   5d37c:      	movq	$0x3, 0x38(%rsp)
   5d385:      	xorl	%edi, %edi
   5d387:      	leaq	-0xf(%r14), %rsi
   5d38b:      	callq	0x6e9d0 <f.3>
   5d390:      	subq	$0x8, %rsp
   5d394:      	cmpb	$0x0, 0x16515(%rip)     # 0x738b0 <g.4>
   5d39b:      	je	0x6e9c5 <f.2+0x17805>
   5d3a1:      	movq	%rax, 0x58(%rsp)
   5d3a6:      	cmpq	$0x0, 0x164fa(%rip)     # 0x738a8 <g.3>
   5d3ae:      	je	0x6e9c5 <f.2+0x17805>
   5d3b4:      	leaq	-0x10(%r14), %rsi
   5d3b8:      	movq	$0x0, 0x50(%rsp)
   5d3c1:      	movq	$0x3, 0x38(%rsp)
   5d3ca:      	xorl	%edi, %edi
   5d3cc:      	callq	0x6e9d0 <f.3>
   5d3d1:      	subq	$0x8, %rsp
   5d3d5:      	movq	%rax, %rbp
   5d3d8:      	addq	0x58(%rsp), %rbp
   5d3dd:      	leaq	0x28(%rsp), %r8
   5d3e2:      	leaq	0x20(%rsp), %rdi
   5d3e7:      	leaq	0x163da(%rip), %r9      # 0x737c8 <native_roots.0>
   5d3ee:      	movq	0x10(%rsp), %rax
   5d3f3:      	movq	0x18(%rsp), %rcx
   5d3f8:      	cmpb	$0x0, 0x164b1(%rip)     # 0x738b0 <g.4>
   5d3ff:      	je	0x6e9c5 <f.2+0x17805>
   5d405:      	cmpq	$0x0, 0x1649b(%rip)     # 0x738a8 <g.3>
   5d40d:      	je	0x6e9c5 <f.2+0x17805>
   5d413:      	addq	%rcx, %rbp
   5d416:      	addq	%rax, %rbp
   5d419:      	movq	%r14, %rsi
   5d41c:      	subq	$0xe, %rsi
   5d420:      	jbe	0x5d4cf <f.2+0x630f>
   5d426:      	movq	$0x0, 0x50(%rsp)
   5d42f:      	movq	$0x3, 0x38(%rsp)
   5d438:      	xorl	%edi, %edi
   5d43a:      	movq	%rsi, 0x10(%rsp)
   5d43f:      	callq	0x6e9d0 <f.3>
   5d444:      	subq	$0x8, %rsp
   5d448:      	cmpb	$0x0, 0x16461(%rip)     # 0x738b0 <g.4>
   5d44f:      	je	0x6e9c5 <f.2+0x17805>
   5d455:      	movq	%rax, 0x18(%rsp)
   5d45a:      	cmpq	$0x0, 0x16446(%rip)     # 0x738a8 <g.3>
   5d462:      	je	0x6e9c5 <f.2+0x17805>
   5d468:      	leaq	-0xf(%r14), %rsi
   5d46c:      	movq	$0x0, 0x50(%rsp)
   5d475:      	movq	$0x3, 0x38(%rsp)
   5d47e:      	xorl	%edi, %edi
   5d480:      	callq	0x6e9d0 <f.3>
   5d485:      	subq	$0x8, %rsp
   5d489:      	cmpb	$0x0, 0x16420(%rip)     # 0x738b0 <g.4>
   5d490:      	je	0x6e9c5 <f.2+0x17805>
   5d496:      	cmpq	$0x0, 0x1640a(%rip)     # 0x738a8 <g.3>
   5d49e:      	leaq	0x20(%rsp), %rdi
   5d4a3:      	movq	0x10(%rsp), %rsi
   5d4a8:      	je	0x6e9c5 <f.2+0x17805>
   5d4ae:      	movq	%rax, %rcx
   5d4b1:      	addq	0x18(%rsp), %rcx
   5d4b6:      	cmpq	$0xf, %r14
   5d4ba:      	leaq	-0xf(%r14), %rax
   5d4be:      	jne	0x5d4db <f.2+0x631b>
   5d4c0:      	addq	%rcx, %rsi
   5d4c3:      	movl	$0x1, %edx
   5d4c8:      	xorl	%eax, %eax
   5d4ca:      	jmp	0x5d60b <f.2+0x644b>
   5d4cf:      	incq	%rsi
   5d4d2:      	leaq	-0xd(%r14), %rdx
   5d4d6:      	jmp	0x5fcbf <f.2+0x8aff>
   5d4db:      	movq	%rcx, 0x18(%rsp)
   5d4e0:      	movq	$0x0, 0x50(%rsp)
   5d4e9:      	movq	$0x3, 0x38(%rsp)
   5d4f2:      	xorl	%edi, %edi
   5d4f4:      	movq	%rax, %rsi
   5d4f7:      	callq	0x6e9d0 <f.3>
   5d4fc:      	subq	$0x8, %rsp
   5d500:      	cmpb	$0x0, 0x163a9(%rip)     # 0x738b0 <g.4>
   5d507:      	je	0x6e9c5 <f.2+0x17805>
   5d50d:      	movq	%rax, 0x58(%rsp)
   5d512:      	cmpq	$0x0, 0x1638e(%rip)     # 0x738a8 <g.3>
   5d51a:      	je	0x6e9c5 <f.2+0x17805>
   5d520:      	leaq	-0x10(%r14), %rsi
   5d524:      	movq	$0x0, 0x50(%rsp)
   5d52d:      	movq	$0x3, 0x38(%rsp)
   5d536:      	xorl	%edi, %edi
   5d538:      	callq	0x6e9d0 <f.3>
   5d53d:      	subq	$0x8, %rsp
   5d541:      	cmpb	$0x0, 0x16368(%rip)     # 0x738b0 <g.4>
   5d548:      	je	0x6e9c5 <f.2+0x17805>
   5d54e:      	movq	%rax, 0x10(%rsp)
   5d553:      	cmpq	$0x0, 0x1634d(%rip)     # 0x738a8 <g.3>
   5d55b:      	je	0x6e9c5 <f.2+0x17805>
   5d561:      	movq	$0x0, 0x50(%rsp)
   5d56a:      	movq	$0x3, 0x38(%rsp)
   5d573:      	xorl	%edi, %edi
   5d575:      	leaq	-0xf(%r14), %rsi
   5d579:      	callq	0x6e9d0 <f.3>
   5d57e:      	subq	$0x8, %rsp
   5d582:      	cmpb	$0x0, 0x16327(%rip)     # 0x738b0 <g.4>
   5d589:      	je	0x6e9c5 <f.2+0x17805>
   5d58f:      	movq	%rax, 0x60(%rsp)
   5d594:      	cmpq	$0x0, 0x1630c(%rip)     # 0x738a8 <g.3>
   5d59c:      	je	0x6e9c5 <f.2+0x17805>
   5d5a2:      	movq	$0x0, 0x50(%rsp)
   5d5ab:      	movq	$0x3, 0x38(%rsp)
   5d5b4:      	xorl	%edi, %edi
   5d5b6:      	leaq	-0x10(%r14), %rsi
   5d5ba:      	callq	0x6e9d0 <f.3>
   5d5bf:      	subq	$0x8, %rsp
   5d5c3:      	cmpb	$0x0, 0x162e6(%rip)     # 0x738b0 <g.4>
   5d5ca:      	je	0x6e9c5 <f.2+0x17805>
   5d5d0:      	movq	%rax, %rdx
   5d5d3:      	cmpq	$0x0, 0x162cd(%rip)     # 0x738a8 <g.3>
   5d5db:      	leaq	0x20(%rsp), %rdi
   5d5e0:      	movq	0x10(%rsp), %rsi
   5d5e5:      	leaq	-0xf(%r14), %rax
   5d5e9:      	movq	0x18(%rsp), %rcx
   5d5ee:      	je	0x6e9c5 <f.2+0x17805>
   5d5f4:      	addq	0x58(%rsp), %rsi
   5d5f9:      	addq	%rcx, %rsi
   5d5fc:      	addq	0x60(%rsp), %rdx
   5d601:      	cmpq	$0x11, %r14
   5d605:      	jae	0x5fc30 <f.2+0x8a70>
   5d60b:      	leaq	0x28(%rsp), %r8
   5d610:      	leaq	0x161b1(%rip), %r9      # 0x737c8 <native_roots.0>
   5d617:      	jmp	0x5fcbc <f.2+0x8afc>
   5d61c:      	movq	$0x0, 0x50(%rsp)
   5d625:      	movq	$0x3, 0x38(%rsp)
   5d62e:      	xorl	%edi, %edi
   5d630:      	leaq	-0xf(%r14), %rsi
   5d634:      	callq	0x6e9d0 <f.3>
   5d639:      	subq	$0x8, %rsp
   5d63d:      	cmpb	$0x0, 0x1626c(%rip)     # 0x738b0 <g.4>
   5d644:      	je	0x6e9c5 <f.2+0x17805>
   5d64a:      	movq	%rax, 0x18(%rsp)
   5d64f:      	cmpq	$0x0, 0x16251(%rip)     # 0x738a8 <g.3>
   5d657:      	je	0x6e9c5 <f.2+0x17805>
   5d65d:      	leaq	-0x10(%r14), %rsi
   5d661:      	movq	$0x0, 0x50(%rsp)
   5d66a:      	movq	$0x3, 0x38(%rsp)
   5d673:      	xorl	%edi, %edi
   5d675:      	callq	0x6e9d0 <f.3>
   5d67a:      	subq	$0x8, %rsp
   5d67e:      	addq	0x18(%rsp), %rax
   5d683:      	leaq	0x28(%rsp), %r8
   5d688:      	leaq	0x20(%rsp), %rdi
   5d68d:      	leaq	0x16134(%rip), %r9      # 0x737c8 <native_roots.0>
   5d694:      	addq	%rax, %r13
   5d697:      	addq	%r13, %r15
   5d69a:      	movq	0x10(%rsp), %r13
   5d69f:      	cmpb	$0x0, 0x1620a(%rip)     # 0x738b0 <g.4>
   5d6a6:      	je	0x6e9c5 <f.2+0x17805>
   5d6ac:      	cmpq	$0x0, 0x161f4(%rip)     # 0x738a8 <g.3>
   5d6b4:      	je	0x6e9c5 <f.2+0x17805>
   5d6ba:      	addq	%rbp, %r15
   5d6bd:      	addq	%r13, %r15
   5d6c0:      	cmpq	$0xa, %r14
   5d6c4:      	jbe	0x5d78e <f.2+0x65ce>
   5d6ca:      	movl	$0x1, %r13d
   5d6d0:      	cmpq	$0xb, %r14
   5d6d4:      	je	0x5d79e <f.2+0x65de>
   5d6da:      	movq	%r14, %r13
   5d6dd:      	subq	$0xc, %r13
   5d6e1:      	jbe	0x5d79b <f.2+0x65db>
   5d6e7:      	movq	$0x0, 0x50(%rsp)
   5d6f0:      	movq	$0x3, 0x38(%rsp)
   5d6f9:      	xorl	%edi, %edi
   5d6fb:      	movq	%r13, %rsi
   5d6fe:      	callq	0x6e9d0 <f.3>
   5d703:      	subq	$0x8, %rsp
   5d707:      	cmpb	$0x0, 0x161a2(%rip)     # 0x738b0 <g.4>
   5d70e:      	je	0x6e9c5 <f.2+0x17805>
   5d714:      	cmpq	$0x0, 0x1618c(%rip)     # 0x738a8 <g.3>
   5d71c:      	je	0x6e9c5 <f.2+0x17805>
   5d722:      	movq	%rax, %rbp
   5d725:      	leaq	-0xd(%r14), %rsi
   5d729:      	movq	$0x0, 0x50(%rsp)
   5d732:      	movq	$0x3, 0x38(%rsp)
   5d73b:      	xorl	%edi, %edi
   5d73d:      	callq	0x6e9d0 <f.3>
   5d742:      	subq	$0x8, %rsp
   5d746:      	cmpb	$0x0, 0x16163(%rip)     # 0x738b0 <g.4>
   5d74d:      	je	0x6e9c5 <f.2+0x17805>
   5d753:      	cmpq	$0x0, 0x1614d(%rip)     # 0x738a8 <g.3>
   5d75b:      	leaq	0x28(%rsp), %r8
   5d760:      	leaq	0x20(%rsp), %rdi
   5d765:      	leaq	0x1605c(%rip), %r9      # 0x737c8 <native_roots.0>
   5d76c:      	je	0x6e9c5 <f.2+0x17805>
   5d772:      	addq	%rbp, %rax
   5d775:      	cmpq	$0xd, %r14
   5d779:      	leaq	-0xd(%r14), %rsi
   5d77d:      	jne	0x5d7ab <f.2+0x65eb>
   5d77f:      	addq	%rax, %r13
   5d782:      	movl	$0x1, %ecx
   5d787:      	xorl	%eax, %eax
   5d789:      	jmp	0x5d952 <f.2+0x6792>
   5d78e:      	leaq	-0x9(%r14), %rbp
   5d792:      	leaq	-0x9(%r14), %rax
   5d796:      	jmp	0x62a1c <f.2+0xb85c>
   5d79b:      	incq	%r13
   5d79e:      	leaq	(%r14,%r13), %rax
   5d7a2:      	addq	$-0xb, %rax
   5d7a6:      	jmp	0x5d973 <f.2+0x67b3>
   5d7ab:      	movq	%rax, 0x10(%rsp)
   5d7b0:      	movq	$0x0, 0x50(%rsp)
   5d7b9:      	movq	$0x3, 0x38(%rsp)
   5d7c2:      	xorl	%edi, %edi
   5d7c4:      	callq	0x6e9d0 <f.3>
   5d7c9:      	subq	$0x8, %rsp
   5d7cd:      	cmpb	$0x0, 0x160dc(%rip)     # 0x738b0 <g.4>
   5d7d4:      	je	0x6e9c5 <f.2+0x17805>
   5d7da:      	movq	%rax, 0x18(%rsp)
   5d7df:      	cmpq	$0x0, 0x160c1(%rip)     # 0x738a8 <g.3>
   5d7e7:      	je	0x6e9c5 <f.2+0x17805>
   5d7ed:      	leaq	-0xe(%r14), %rsi
   5d7f1:      	movq	$0x0, 0x50(%rsp)
   5d7fa:      	movq	$0x3, 0x38(%rsp)
   5d803:      	xorl	%edi, %edi
   5d805:      	callq	0x6e9d0 <f.3>
   5d80a:      	subq	$0x8, %rsp
   5d80e:      	cmpb	$0x0, 0x1609b(%rip)     # 0x738b0 <g.4>
   5d815:      	je	0x6e9c5 <f.2+0x17805>
   5d81b:      	cmpq	$0x0, 0x16085(%rip)     # 0x738a8 <g.3>
   5d823:      	leaq	-0xd(%r14), %rsi
   5d827:      	je	0x6e9c5 <f.2+0x17805>
   5d82d:      	movq	%rax, %r13
   5d830:      	movq	$0x0, 0x50(%rsp)
   5d839:      	movq	$0x3, 0x38(%rsp)
   5d842:      	xorl	%edi, %edi
   5d844:      	callq	0x6e9d0 <f.3>
   5d849:      	subq	$0x8, %rsp
   5d84d:      	cmpb	$0x0, 0x1605c(%rip)     # 0x738b0 <g.4>
   5d854:      	je	0x6e9c5 <f.2+0x17805>
   5d85a:      	cmpq	$0x0, 0x16046(%rip)     # 0x738a8 <g.3>
   5d862:      	je	0x6e9c5 <f.2+0x17805>
   5d868:      	movq	%rax, %rbp
   5d86b:      	movq	$0x0, 0x50(%rsp)
   5d874:      	movq	$0x3, 0x38(%rsp)
   5d87d:      	xorl	%edi, %edi
   5d87f:      	leaq	-0xe(%r14), %rsi
   5d883:      	callq	0x6e9d0 <f.3>
   5d888:      	subq	$0x8, %rsp
   5d88c:      	cmpb	$0x0, 0x1601d(%rip)     # 0x738b0 <g.4>
   5d893:      	je	0x6e9c5 <f.2+0x17805>
   5d899:      	movq	%rax, %rcx
   5d89c:      	cmpq	$0x0, 0x16004(%rip)     # 0x738a8 <g.3>
   5d8a4:      	leaq	0x28(%rsp), %r8
   5d8a9:      	leaq	0x15f18(%rip), %r9      # 0x737c8 <native_roots.0>
   5d8b0:      	leaq	-0xd(%r14), %rax
   5d8b4:      	je	0x6e9c5 <f.2+0x17805>
   5d8ba:      	addq	0x18(%rsp), %r13
   5d8bf:      	addq	0x10(%rsp), %r13
   5d8c4:      	addq	%rbp, %rcx
   5d8c7:      	cmpq	$0xf, %r14
   5d8cb:      	jae	0x5d8d4 <f.2+0x6714>
   5d8cd:      	leaq	0x20(%rsp), %rdi
   5d8d2:      	jmp	0x5d952 <f.2+0x6792>
   5d8d4:      	movq	%rcx, 0x10(%rsp)
   5d8d9:      	movq	$0x0, 0x50(%rsp)
   5d8e2:      	movq	$0x3, 0x38(%rsp)
   5d8eb:      	xorl	%edi, %edi
   5d8ed:      	leaq	-0xe(%r14), %rsi
   5d8f1:      	callq	0x6e9d0 <f.3>
   5d8f6:      	subq	$0x8, %rsp
   5d8fa:      	cmpb	$0x0, 0x15faf(%rip)     # 0x738b0 <g.4>
   5d901:      	je	0x6e9c5 <f.2+0x17805>
   5d907:      	cmpq	$0x0, 0x15f99(%rip)     # 0x738a8 <g.3>
   5d90f:      	je	0x6e9c5 <f.2+0x17805>
   5d915:      	movq	%rax, %rbp
   5d918:      	leaq	-0xf(%r14), %rsi
   5d91c:      	movq	$0x0, 0x50(%rsp)
   5d925:      	movq	$0x3, 0x38(%rsp)
   5d92e:      	xorl	%edi, %edi
   5d930:      	callq	0x6e9d0 <f.3>
   5d935:      	subq	$0x8, %rsp
   5d939:      	addq	%rbp, %rax
   5d93c:      	leaq	0x28(%rsp), %r8
   5d941:      	leaq	0x20(%rsp), %rdi
   5d946:      	leaq	0x15e7b(%rip), %r9      # 0x737c8 <native_roots.0>
   5d94d:      	movq	0x10(%rsp), %rcx
   5d952:      	cmpb	$0x0, 0x15f57(%rip)     # 0x738b0 <g.4>
   5d959:      	je	0x6e9c5 <f.2+0x17805>
   5d95f:      	cmpq	$0x0, 0x15f41(%rip)     # 0x738a8 <g.3>
   5d967:      	je	0x6e9c5 <f.2+0x17805>
   5d96d:      	addq	%rcx, %rax
   5d970:      	addq	%r13, %rax
   5d973:      	cmpq	$0xb, %r14
   5d977:      	je	0x5da4a <f.2+0x688a>
   5d97d:      	movl	$0x1, %r13d
   5d983:      	cmpq	$0xc, %r14
   5d987:      	je	0x5da63 <f.2+0x68a3>
   5d98d:      	movq	%r14, %r13
   5d990:      	subq	$0xd, %r13
   5d994:      	jbe	0x5da60 <f.2+0x68a0>
   5d99a:      	movq	%rax, 0x10(%rsp)
   5d99f:      	movq	$0x0, 0x50(%rsp)
   5d9a8:      	movq	$0x3, 0x38(%rsp)
   5d9b1:      	xorl	%edi, %edi
   5d9b3:      	movq	%r13, %rsi
   5d9b6:      	callq	0x6e9d0 <f.3>
   5d9bb:      	subq	$0x8, %rsp
   5d9bf:      	cmpb	$0x0, 0x15eea(%rip)     # 0x738b0 <g.4>
   5d9c6:      	je	0x6e9c5 <f.2+0x17805>
   5d9cc:      	cmpq	$0x0, 0x15ed4(%rip)     # 0x738a8 <g.3>
   5d9d4:      	je	0x6e9c5 <f.2+0x17805>
   5d9da:      	movq	%rax, %rbp
   5d9dd:      	leaq	-0xe(%r14), %rsi
   5d9e1:      	movq	$0x0, 0x50(%rsp)
   5d9ea:      	movq	$0x3, 0x38(%rsp)
   5d9f3:      	xorl	%edi, %edi
   5d9f5:      	callq	0x6e9d0 <f.3>
   5d9fa:      	subq	$0x8, %rsp
   5d9fe:      	cmpb	$0x0, 0x15eab(%rip)     # 0x738b0 <g.4>
   5da05:      	je	0x6e9c5 <f.2+0x17805>
   5da0b:      	movq	%rax, %rcx
   5da0e:      	cmpq	$0x0, 0x15e92(%rip)     # 0x738a8 <g.3>
   5da16:      	leaq	0x28(%rsp), %r8
   5da1b:      	leaq	0x15da6(%rip), %r9      # 0x737c8 <native_roots.0>
   5da22:      	movq	0x10(%rsp), %rax
   5da27:      	je	0x6e9c5 <f.2+0x17805>
   5da2d:      	addq	%rbp, %rcx
   5da30:      	cmpq	$0xe, %r14
   5da34:      	jne	0x5da6c <f.2+0x68ac>
   5da36:      	addq	%rcx, %r13
   5da39:      	movl	$0x1, %ebp
   5da3e:      	xorl	%ecx, %ecx
   5da40:      	leaq	0x20(%rsp), %rdi
   5da45:      	jmp	0x5dc2a <f.2+0x6a6a>
   5da4a:      	leaq	(%r14,%rax), %rbp
   5da4e:      	addq	$-0xa, %rbp
   5da52:      	movl	$0x1, %eax
   5da57:      	leaq	-0xb(%r14), %r13
   5da5b:      	jmp	0x62a19 <f.2+0xb859>
   5da60:      	incq	%r13
   5da63:      	leaq	-0xc(%r14), %rbp
   5da67:      	jmp	0x5dc2d <f.2+0x6a6d>
   5da6c:      	movq	%rcx, 0x18(%rsp)
   5da71:      	movq	$0x0, 0x50(%rsp)
   5da7a:      	movq	$0x3, 0x38(%rsp)
   5da83:      	xorl	%edi, %edi
   5da85:      	leaq	-0xe(%r14), %rbp
   5da89:      	movq	%rbp, %rsi
   5da8c:      	callq	0x6e9d0 <f.3>
   5da91:      	subq	$0x8, %rsp
   5da95:      	cmpb	$0x0, 0x15e14(%rip)     # 0x738b0 <g.4>
   5da9c:      	je	0x6e9c5 <f.2+0x17805>
   5daa2:      	movq	%rax, 0x58(%rsp)
   5daa7:      	cmpq	$0x0, 0x15df9(%rip)     # 0x738a8 <g.3>
   5daaf:      	je	0x6e9c5 <f.2+0x17805>
   5dab5:      	leaq	-0xf(%r14), %rsi
   5dab9:      	movq	$0x0, 0x50(%rsp)
   5dac2:      	movq	$0x3, 0x38(%rsp)
   5dacb:      	xorl	%edi, %edi
   5dacd:      	callq	0x6e9d0 <f.3>
   5dad2:      	subq	$0x8, %rsp
   5dad6:      	cmpb	$0x0, 0x15dd3(%rip)     # 0x738b0 <g.4>
   5dadd:      	je	0x6e9c5 <f.2+0x17805>
   5dae3:      	cmpq	$0x0, 0x15dbd(%rip)     # 0x738a8 <g.3>
   5daeb:      	je	0x6e9c5 <f.2+0x17805>
   5daf1:      	movq	%rax, %r13
   5daf4:      	movq	$0x0, 0x50(%rsp)
   5dafd:      	movq	$0x3, 0x38(%rsp)
   5db06:      	xorl	%edi, %edi
   5db08:      	movq	%rbp, %rsi
   5db0b:      	callq	0x6e9d0 <f.3>
   5db10:      	subq	$0x8, %rsp
   5db14:      	cmpb	$0x0, 0x15d95(%rip)     # 0x738b0 <g.4>
   5db1b:      	je	0x6e9c5 <f.2+0x17805>
   5db21:      	movq	%rax, 0x60(%rsp)
   5db26:      	cmpq	$0x0, 0x15d7a(%rip)     # 0x738a8 <g.3>
   5db2e:      	je	0x6e9c5 <f.2+0x17805>
   5db34:      	movq	$0x0, 0x50(%rsp)
   5db3d:      	movq	$0x3, 0x38(%rsp)
   5db46:      	xorl	%edi, %edi
   5db48:      	leaq	-0xf(%r14), %rsi
   5db4c:      	callq	0x6e9d0 <f.3>
   5db51:      	subq	$0x8, %rsp
   5db55:      	cmpb	$0x0, 0x15d54(%rip)     # 0x738b0 <g.4>
   5db5c:      	je	0x6e9c5 <f.2+0x17805>
   5db62:      	movq	%rax, %rbp
   5db65:      	cmpq	$0x0, 0x15d3b(%rip)     # 0x738a8 <g.3>
   5db6d:      	leaq	0x28(%rsp), %r8
   5db72:      	leaq	0x15c4f(%rip), %r9      # 0x737c8 <native_roots.0>
   5db79:      	movq	0x10(%rsp), %rax
   5db7e:      	movq	0x18(%rsp), %rcx
   5db83:      	je	0x6e9c5 <f.2+0x17805>
   5db89:      	addq	0x58(%rsp), %r13
   5db8e:      	addq	%rcx, %r13
   5db91:      	addq	0x60(%rsp), %rbp
   5db96:      	cmpq	$0x10, %r14
   5db9a:      	jae	0x5dbaa <f.2+0x69ea>
   5db9c:      	leaq	0x20(%rsp), %rdi
   5dba1:      	leaq	-0xe(%r14), %rcx
   5dba5:      	jmp	0x5dc2a <f.2+0x6a6a>
   5dbaa:      	movq	$0x0, 0x50(%rsp)
   5dbb3:      	movq	$0x3, 0x38(%rsp)
   5dbbc:      	xorl	%edi, %edi
   5dbbe:      	leaq	-0xf(%r14), %rsi
   5dbc2:      	callq	0x6e9d0 <f.3>
   5dbc7:      	subq	$0x8, %rsp
   5dbcb:      	cmpb	$0x0, 0x15cde(%rip)     # 0x738b0 <g.4>
   5dbd2:      	je	0x6e9c5 <f.2+0x17805>
   5dbd8:      	movq	%rax, 0x18(%rsp)
   5dbdd:      	cmpq	$0x0, 0x15cc3(%rip)     # 0x738a8 <g.3>
   5dbe5:      	je	0x6e9c5 <f.2+0x17805>
   5dbeb:      	leaq	-0x10(%r14), %rsi
   5dbef:      	movq	$0x0, 0x50(%rsp)
   5dbf8:      	movq	$0x3, 0x38(%rsp)
   5dc01:      	xorl	%edi, %edi
   5dc03:      	callq	0x6e9d0 <f.3>
   5dc08:      	subq	$0x8, %rsp
   5dc0c:      	movq	%rax, %rcx
   5dc0f:      	addq	0x18(%rsp), %rcx
   5dc14:      	leaq	0x28(%rsp), %r8
   5dc19:      	leaq	0x20(%rsp), %rdi
   5dc1e:      	leaq	0x15ba3(%rip), %r9      # 0x737c8 <native_roots.0>
   5dc25:      	movq	0x10(%rsp), %rax
   5dc2a:      	addq	%rcx, %rbp
   5dc2d:      	cmpb	$0x0, 0x15c7c(%rip)     # 0x738b0 <g.4>
   5dc34:      	je	0x6e9c5 <f.2+0x17805>
   5dc3a:      	cmpq	$0x0, 0x15c66(%rip)     # 0x738a8 <g.3>
   5dc42:      	je	0x6e9c5 <f.2+0x17805>
   5dc48:      	addq	%r13, %rbp
   5dc4b:      	addq	%rax, %rbp
   5dc4e:      	cmpq	$0xc, %r14
   5dc52:      	jbe	0x5dc67 <f.2+0x6aa7>
   5dc54:      	cmpq	$0xd, %r14
   5dc58:      	jne	0x5dc74 <f.2+0x6ab4>
   5dc5a:      	movl	$0x1, %r13d
   5dc60:      	xorl	%ecx, %ecx
   5dc62:      	jmp	0x5ddaf <f.2+0x6bef>
   5dc67:      	leaq	-0xb(%r14), %rax
   5dc6b:      	leaq	-0xb(%r14), %r13
   5dc6f:      	jmp	0x62a19 <f.2+0xb859>
   5dc74:      	leaq	-0xd(%r14), %rsi
   5dc78:      	movq	$0x0, 0x50(%rsp)
   5dc81:      	movq	$0x3, 0x38(%rsp)
   5dc8a:      	xorl	%edi, %edi
   5dc8c:      	callq	0x6e9d0 <f.3>
   5dc91:      	subq	$0x8, %rsp
   5dc95:      	cmpb	$0x0, 0x15c14(%rip)     # 0x738b0 <g.4>
   5dc9c:      	je	0x6e9c5 <f.2+0x17805>
   5dca2:      	movq	%rax, 0x10(%rsp)
   5dca7:      	cmpq	$0x0, 0x15bf9(%rip)     # 0x738a8 <g.3>
   5dcaf:      	je	0x6e9c5 <f.2+0x17805>
   5dcb5:      	leaq	-0xe(%r14), %rsi
   5dcb9:      	movq	$0x0, 0x50(%rsp)
   5dcc2:      	movq	$0x3, 0x38(%rsp)
   5dccb:      	xorl	%edi, %edi
   5dccd:      	callq	0x6e9d0 <f.3>
   5dcd2:      	subq	$0x8, %rsp
   5dcd6:      	cmpb	$0x0, 0x15bd3(%rip)     # 0x738b0 <g.4>
   5dcdd:      	je	0x6e9c5 <f.2+0x17805>
   5dce3:      	cmpq	$0x0, 0x15bbd(%rip)     # 0x738a8 <g.3>
   5dceb:      	leaq	0x20(%rsp), %rdi
   5dcf0:      	leaq	-0xd(%r14), %rcx
   5dcf4:      	je	0x6e9c5 <f.2+0x17805>
   5dcfa:      	movq	%rax, %r13
   5dcfd:      	addq	0x10(%rsp), %r13
   5dd02:      	cmpq	$0xe, %r14
   5dd06:      	ja	0x5dd19 <f.2+0x6b59>
   5dd08:      	leaq	0x28(%rsp), %r8
   5dd0d:      	leaq	0x15ab4(%rip), %r9      # 0x737c8 <native_roots.0>
   5dd14:      	jmp	0x5ddaf <f.2+0x6bef>
   5dd19:      	movq	$0x0, 0x50(%rsp)
   5dd22:      	movq	$0x3, 0x38(%rsp)
   5dd2b:      	xorl	%edi, %edi
   5dd2d:      	leaq	-0xe(%r14), %rsi
   5dd31:      	callq	0x6e9d0 <f.3>
   5dd36:      	subq	$0x8, %rsp
   5dd3a:      	cmpb	$0x0, 0x15b6f(%rip)     # 0x738b0 <g.4>
   5dd41:      	je	0x6e9c5 <f.2+0x17805>
   5dd47:      	movq	%rax, 0x10(%rsp)
   5dd4c:      	cmpq	$0x0, 0x15b54(%rip)     # 0x738a8 <g.3>
   5dd54:      	je	0x6e9c5 <f.2+0x17805>
   5dd5a:      	leaq	-0xf(%r14), %rsi
   5dd5e:      	movq	$0x0, 0x50(%rsp)
   5dd67:      	movq	$0x3, 0x38(%rsp)
   5dd70:      	xorl	%edi, %edi
   5dd72:      	callq	0x6e9d0 <f.3>
   5dd77:      	subq	$0x8, %rsp
   5dd7b:      	cmpb	$0x0, 0x15b2e(%rip)     # 0x738b0 <g.4>
   5dd82:      	je	0x6e9c5 <f.2+0x17805>
   5dd88:      	cmpq	$0x0, 0x15b18(%rip)     # 0x738a8 <g.3>
   5dd90:      	leaq	0x28(%rsp), %r8
   5dd95:      	leaq	0x20(%rsp), %rdi
   5dd9a:      	leaq	0x15a27(%rip), %r9      # 0x737c8 <native_roots.0>
   5dda1:      	je	0x6e9c5 <f.2+0x17805>
   5dda7:      	movq	%rax, %rcx
   5ddaa:      	addq	0x10(%rsp), %rcx
   5ddaf:      	addq	%r13, %rcx
   5ddb2:      	cmpq	$0xd, %r14
   5ddb6:      	je	0x5ddca <f.2+0x6c0a>
   5ddb8:      	cmpq	$0xe, %r14
   5ddbc:      	jne	0x5dde1 <f.2+0x6c21>
   5ddbe:      	movl	$0x1, %edx
   5ddc3:      	xorl	%eax, %eax
   5ddc5:      	jmp	0x5df0e <f.2+0x6d4e>
   5ddca:      	leaq	(%r14,%rcx), %rax
   5ddce:      	addq	$-0xc, %rax
   5ddd2:      	movl	$0x1, %r13d
   5ddd8:      	leaq	-0xd(%r14), %rdx
   5dddc:      	jmp	0x62a16 <f.2+0xb856>
   5dde1:      	movq	%rcx, 0x10(%rsp)
   5dde6:      	leaq	-0xe(%r14), %rsi
   5ddea:      	movq	$0x0, 0x50(%rsp)
   5ddf3:      	movq	$0x3, 0x38(%rsp)
   5ddfc:      	xorl	%edi, %edi
   5ddfe:      	callq	0x6e9d0 <f.3>
   5de03:      	subq	$0x8, %rsp
   5de07:      	cmpb	$0x0, 0x15aa2(%rip)     # 0x738b0 <g.4>
   5de0e:      	je	0x6e9c5 <f.2+0x17805>
   5de14:      	cmpq	$0x0, 0x15a8c(%rip)     # 0x738a8 <g.3>
   5de1c:      	je	0x6e9c5 <f.2+0x17805>
   5de22:      	movq	%rax, %r13
   5de25:      	leaq	-0xf(%r14), %rsi
   5de29:      	movq	$0x0, 0x50(%rsp)
   5de32:      	movq	$0x3, 0x38(%rsp)
   5de3b:      	xorl	%edi, %edi
   5de3d:      	callq	0x6e9d0 <f.3>
   5de42:      	subq	$0x8, %rsp
   5de46:      	cmpb	$0x0, 0x15a63(%rip)     # 0x738b0 <g.4>
   5de4d:      	je	0x6e9c5 <f.2+0x17805>
   5de53:      	movq	%rax, %rdx
   5de56:      	cmpq	$0x0, 0x15a4a(%rip)     # 0x738a8 <g.3>
   5de5e:      	leaq	0x28(%rsp), %r8
   5de63:      	leaq	0x20(%rsp), %rdi
   5de68:      	leaq	0x15959(%rip), %r9      # 0x737c8 <native_roots.0>
   5de6f:      	leaq	-0xe(%r14), %rax
   5de73:      	movq	0x10(%rsp), %rcx
   5de78:      	je	0x6e9c5 <f.2+0x17805>
   5de7e:      	addq	%r13, %rdx
   5de81:      	cmpq	$0x10, %r14
   5de85:      	jb	0x5df0e <f.2+0x6d4e>
   5de8b:      	movq	%rdx, 0x18(%rsp)
   5de90:      	movq	$0x0, 0x50(%rsp)
   5de99:      	movq	$0x3, 0x38(%rsp)
   5dea2:      	xorl	%edi, %edi
   5dea4:      	leaq	-0xf(%r14), %rsi
   5dea8:      	callq	0x6e9d0 <f.3>
   5dead:      	subq	$0x8, %rsp
   5deb1:      	cmpb	$0x0, 0x159f8(%rip)     # 0x738b0 <g.4>
   5deb8:      	je	0x6e9c5 <f.2+0x17805>
   5debe:      	cmpq	$0x0, 0x159e2(%rip)     # 0x738a8 <g.3>
   5dec6:      	je	0x6e9c5 <f.2+0x17805>
   5decc:      	movq	%rax, %r13
   5decf:      	leaq	-0x10(%r14), %rsi
   5ded3:      	movq	$0x0, 0x50(%rsp)
   5dedc:      	movq	$0x3, 0x38(%rsp)
   5dee5:      	xorl	%edi, %edi
   5dee7:      	callq	0x6e9d0 <f.3>
   5deec:      	subq	$0x8, %rsp
   5def0:      	addq	%r13, %rax
   5def3:      	leaq	0x28(%rsp), %r8
   5def8:      	leaq	0x20(%rsp), %rdi
   5defd:      	leaq	0x158c4(%rip), %r9      # 0x737c8 <native_roots.0>
   5df04:      	movq	0x10(%rsp), %rcx
   5df09:      	movq	0x18(%rsp), %rdx
   5df0e:      	cmpb	$0x0, 0x1599b(%rip)     # 0x738b0 <g.4>
   5df15:      	je	0x6e9c5 <f.2+0x17805>
   5df1b:      	cmpq	$0x0, 0x15985(%rip)     # 0x738a8 <g.3>
   5df23:      	je	0x6e9c5 <f.2+0x17805>
   5df29:      	addq	%rdx, %rax
   5df2c:      	addq	%rcx, %rax
   5df2f:      	movq	%r14, %r13
   5df32:      	subq	$0xe, %r13
   5df36:      	jbe	0x5dff4 <f.2+0x6e34>
   5df3c:      	movq	%rax, 0x10(%rsp)
   5df41:      	movq	$0x0, 0x50(%rsp)
   5df4a:      	movq	$0x3, 0x38(%rsp)
   5df53:      	xorl	%edi, %edi
   5df55:      	movq	%r13, %rsi
   5df58:      	callq	0x6e9d0 <f.3>
   5df5d:      	subq	$0x8, %rsp
   5df61:      	cmpb	$0x0, 0x15948(%rip)     # 0x738b0 <g.4>
   5df68:      	je	0x6e9c5 <f.2+0x17805>
   5df6e:      	movq	%rax, 0x18(%rsp)
   5df73:      	cmpq	$0x0, 0x1592d(%rip)     # 0x738a8 <g.3>
   5df7b:      	je	0x6e9c5 <f.2+0x17805>
   5df81:      	leaq	-0xf(%r14), %rsi
   5df85:      	movq	$0x0, 0x50(%rsp)
   5df8e:      	movq	$0x3, 0x38(%rsp)
   5df97:      	xorl	%edi, %edi
   5df99:      	callq	0x6e9d0 <f.3>
   5df9e:      	subq	$0x8, %rsp
   5dfa2:      	cmpb	$0x0, 0x15907(%rip)     # 0x738b0 <g.4>
   5dfa9:      	je	0x6e9c5 <f.2+0x17805>
   5dfaf:      	movq	%rax, %rcx
   5dfb2:      	cmpq	$0x0, 0x158ee(%rip)     # 0x738a8 <g.3>
   5dfba:      	leaq	0x20(%rsp), %rdi
   5dfbf:      	movq	0x10(%rsp), %rax
   5dfc4:      	je	0x6e9c5 <f.2+0x17805>
   5dfca:      	addq	0x18(%rsp), %rcx
   5dfcf:      	cmpq	$0xf, %r14
   5dfd3:      	leaq	-0xf(%r14), %rsi
   5dfd7:      	jne	0x5e000 <f.2+0x6e40>
   5dfd9:      	addq	%rcx, %r13
   5dfdc:      	movl	$0x1, %edx
   5dfe1:      	xorl	%ecx, %ecx
   5dfe3:      	leaq	0x28(%rsp), %r8
   5dfe8:      	leaq	0x157d9(%rip), %r9      # 0x737c8 <native_roots.0>
   5dfef:      	jmp	0x62a13 <f.2+0xb853>
   5dff4:      	incq	%r13
   5dff7:      	leaq	-0xd(%r14), %rdx
   5dffb:      	jmp	0x62a16 <f.2+0xb856>
   5e000:      	movq	%rcx, 0x18(%rsp)
   5e005:      	movq	$0x0, 0x50(%rsp)
   5e00e:      	movq	$0x3, 0x38(%rsp)
   5e017:      	xorl	%edi, %edi
   5e019:      	callq	0x6e9d0 <f.3>
   5e01e:      	subq	$0x8, %rsp
   5e022:      	cmpb	$0x0, 0x15887(%rip)     # 0x738b0 <g.4>
   5e029:      	je	0x6e9c5 <f.2+0x17805>
   5e02f:      	movq	%rax, 0x58(%rsp)
   5e034:      	cmpq	$0x0, 0x1586c(%rip)     # 0x738a8 <g.3>
   5e03c:      	je	0x6e9c5 <f.2+0x17805>
   5e042:      	leaq	-0x10(%r14), %rsi
   5e046:      	movq	$0x0, 0x50(%rsp)
   5e04f:      	movq	$0x3, 0x38(%rsp)
   5e058:      	xorl	%edi, %edi
   5e05a:      	callq	0x6e9d0 <f.3>
   5e05f:      	subq	$0x8, %rsp
   5e063:      	cmpb	$0x0, 0x15846(%rip)     # 0x738b0 <g.4>
   5e06a:      	je	0x6e9c5 <f.2+0x17805>
   5e070:      	cmpq	$0x0, 0x15830(%rip)     # 0x738a8 <g.3>
   5e078:      	leaq	-0xf(%r14), %rsi
   5e07c:      	je	0x6e9c5 <f.2+0x17805>
   5e082:      	movq	%rax, %r13
   5e085:      	movq	$0x0, 0x50(%rsp)
   5e08e:      	movq	$0x3, 0x38(%rsp)
   5e097:      	xorl	%edi, %edi
   5e099:      	callq	0x6e9d0 <f.3>
   5e09e:      	subq	$0x8, %rsp
   5e0a2:      	cmpb	$0x0, 0x15807(%rip)     # 0x738b0 <g.4>
   5e0a9:      	je	0x6e9c5 <f.2+0x17805>
   5e0af:      	movq	%rax, 0x60(%rsp)
   5e0b4:      	cmpq	$0x0, 0x157ec(%rip)     # 0x738a8 <g.3>
   5e0bc:      	je	0x6e9c5 <f.2+0x17805>
   5e0c2:      	movq	$0x0, 0x50(%rsp)
   5e0cb:      	movq	$0x3, 0x38(%rsp)
   5e0d4:      	xorl	%edi, %edi
   5e0d6:      	leaq	-0x10(%r14), %rsi
   5e0da:      	callq	0x6e9d0 <f.3>
   5e0df:      	subq	$0x8, %rsp
   5e0e3:      	cmpb	$0x0, 0x157c6(%rip)     # 0x738b0 <g.4>
   5e0ea:      	je	0x6e9c5 <f.2+0x17805>
   5e0f0:      	movq	%rax, %rdx
   5e0f3:      	cmpq	$0x0, 0x157ad(%rip)     # 0x738a8 <g.3>
   5e0fb:      	movq	0x10(%rsp), %rax
   5e100:      	leaq	-0xf(%r14), %rcx
   5e104:      	je	0x6e9c5 <f.2+0x17805>
   5e10a:      	addq	0x58(%rsp), %r13
   5e10f:      	addq	0x18(%rsp), %r13
   5e114:      	addq	0x60(%rsp), %rdx
   5e119:      	cmpq	$0x11, %r14
   5e11d:      	jae	0x62989 <f.2+0xb7c9>
   5e123:      	leaq	0x28(%rsp), %r8
   5e128:      	leaq	0x20(%rsp), %rdi
   5e12d:      	leaq	0x15694(%rip), %r9      # 0x737c8 <native_roots.0>
   5e134:      	jmp	0x62a13 <f.2+0xb853>
   5e139:      	movq	$0x0, 0x50(%rsp)
   5e142:      	movq	$0x3, 0x38(%rsp)
   5e14b:      	xorl	%edi, %edi
   5e14d:      	leaq	-0xf(%r14), %rsi
   5e151:      	callq	0x6e9d0 <f.3>
   5e156:      	subq	$0x8, %rsp
   5e15a:      	cmpb	$0x0, 0x1574f(%rip)     # 0x738b0 <g.4>
   5e161:      	je	0x6e9c5 <f.2+0x17805>
   5e167:      	cmpq	$0x0, 0x15739(%rip)     # 0x738a8 <g.3>
   5e16f:      	je	0x6e9c5 <f.2+0x17805>
   5e175:      	movq	%rax, %r13
   5e178:      	leaq	-0x10(%r14), %rsi
   5e17c:      	movq	$0x0, 0x50(%rsp)
   5e185:      	movq	$0x3, 0x38(%rsp)
   5e18e:      	xorl	%edi, %edi
   5e190:      	callq	0x6e9d0 <f.3>
   5e195:      	subq	$0x8, %rsp
   5e199:      	movq	%rax, %rcx
   5e19c:      	addq	%r13, %rcx
   5e19f:      	leaq	0x28(%rsp), %r8
   5e1a4:      	leaq	0x20(%rsp), %rdi
   5e1a9:      	leaq	0x15618(%rip), %r9      # 0x737c8 <native_roots.0>
   5e1b0:      	movq	0x10(%rsp), %rax
   5e1b5:      	addq	%rcx, %r15
   5e1b8:      	movq	0x18(%rsp), %rcx
   5e1bd:      	cmpb	$0x0, 0x156ec(%rip)     # 0x738b0 <g.4>
   5e1c4:      	je	0x6e9c5 <f.2+0x17805>
   5e1ca:      	cmpq	$0x0, 0x156d6(%rip)     # 0x738a8 <g.3>
   5e1d2:      	je	0x6e9c5 <f.2+0x17805>
   5e1d8:      	addq	%rbp, %r15
   5e1db:      	addq	%rcx, %r15
   5e1de:      	cmpq	$0xa, %r14
   5e1e2:      	jne	0x57be7 <f.2+0xa27>
   5e1e8:      	leaq	(%r14,%r15), %rbp
   5e1ec:      	addq	$-0x9, %rbp
   5e1f0:      	movl	$0x1, %r15d
   5e1f6:      	leaq	-0xa(%r14), %r13
   5e1fa:      	jmp	0x63e77 <f.2+0xccb7>
   5e1ff:      	movq	%rsi, 0x18(%rsp)
   5e204:      	movq	$0x0, 0x50(%rsp)
   5e20d:      	movq	$0x3, 0x38(%rsp)
   5e216:      	xorl	%edi, %edi
   5e218:      	leaq	-0xf(%r14), %rsi
   5e21c:      	callq	0x6e9d0 <f.3>
   5e221:      	subq	$0x8, %rsp
   5e225:      	cmpb	$0x0, 0x15684(%rip)     # 0x738b0 <g.4>
   5e22c:      	je	0x6e9c5 <f.2+0x17805>
   5e232:      	cmpq	$0x0, 0x1566e(%rip)     # 0x738a8 <g.3>
   5e23a:      	je	0x6e9c5 <f.2+0x17805>
   5e240:      	movq	%rax, %r12
   5e243:      	leaq	-0x10(%r14), %rsi
   5e247:      	movq	$0x0, 0x50(%rsp)
   5e250:      	movq	$0x3, 0x38(%rsp)
   5e259:      	xorl	%edi, %edi
   5e25b:      	callq	0x6e9d0 <f.3>
   5e260:      	subq	$0x8, %rsp
   5e264:      	cmpb	$0x0, 0x15645(%rip)     # 0x738b0 <g.4>
   5e26b:      	je	0x6e9c5 <f.2+0x17805>
   5e271:      	addq	%r12, %rax
   5e274:      	addq	%rax, %rbp
   5e277:      	leaq	0x28(%rsp), %r8
   5e27c:      	leaq	0x20(%rsp), %rdi
   5e281:      	leaq	0x15540(%rip), %r9      # 0x737c8 <native_roots.0>
   5e288:      	movq	0x10(%rsp), %r12
   5e28d:      	movq	0x18(%rsp), %rsi
   5e292:      	cmpq	$0x0, 0x1560e(%rip)     # 0x738a8 <g.3>
   5e29a:      	je	0x6e9c5 <f.2+0x17805>
   5e2a0:      	addq	%rsi, %rbp
   5e2a3:      	addq	%r12, %rbp
   5e2a6:      	cmpq	$0xc, %r14
   5e2aa:      	jbe	0x5e2bf <f.2+0x70ff>
   5e2ac:      	cmpq	$0xd, %r14
   5e2b0:      	jne	0x5e2d0 <f.2+0x7110>
   5e2b2:      	movl	$0x1, %r12d
   5e2b8:      	xorl	%eax, %eax
   5e2ba:      	jmp	0x5e407 <f.2+0x7247>
   5e2bf:      	leaq	-0xb(%r14), %rax
   5e2c3:      	leaq	(%r14,%rax), %r12
   5e2c7:      	addq	$-0xb, %r12
   5e2cb:      	jmp	0x579a5 <f.2+0x7e5>
   5e2d0:      	leaq	-0xd(%r14), %rsi
   5e2d4:      	movq	$0x0, 0x50(%rsp)
   5e2dd:      	movq	$0x3, 0x38(%rsp)
   5e2e6:      	xorl	%edi, %edi
   5e2e8:      	callq	0x6e9d0 <f.3>
   5e2ed:      	subq	$0x8, %rsp
   5e2f1:      	cmpb	$0x0, 0x155b8(%rip)     # 0x738b0 <g.4>
   5e2f8:      	je	0x6e9c5 <f.2+0x17805>
   5e2fe:      	movq	%rax, 0x10(%rsp)
   5e303:      	cmpq	$0x0, 0x1559d(%rip)     # 0x738a8 <g.3>
   5e30b:      	je	0x6e9c5 <f.2+0x17805>
   5e311:      	leaq	-0xe(%r14), %rsi
   5e315:      	movq	$0x0, 0x50(%rsp)
   5e31e:      	movq	$0x3, 0x38(%rsp)
   5e327:      	xorl	%edi, %edi
   5e329:      	callq	0x6e9d0 <f.3>
   5e32e:      	subq	$0x8, %rsp
   5e332:      	cmpb	$0x0, 0x15577(%rip)     # 0x738b0 <g.4>
   5e339:      	je	0x6e9c5 <f.2+0x17805>
   5e33f:      	movq	%rax, %r12
   5e342:      	cmpq	$0x0, 0x1555e(%rip)     # 0x738a8 <g.3>
   5e34a:      	leaq	0x28(%rsp), %r8
   5e34f:      	leaq	0x20(%rsp), %rdi
   5e354:      	leaq	0x1546d(%rip), %r9      # 0x737c8 <native_roots.0>
   5e35b:      	leaq	-0xd(%r14), %rax
   5e35f:      	je	0x6e9c5 <f.2+0x17805>
   5e365:      	addq	0x10(%rsp), %r12
   5e36a:      	cmpq	$0xe, %r14
   5e36e:      	jbe	0x5e407 <f.2+0x7247>
   5e374:      	movq	$0x0, 0x50(%rsp)
   5e37d:      	movq	$0x3, 0x38(%rsp)
   5e386:      	xorl	%edi, %edi
   5e388:      	leaq	-0xe(%r14), %rsi
   5e38c:      	callq	0x6e9d0 <f.3>
   5e391:      	subq	$0x8, %rsp
   5e395:      	cmpb	$0x0, 0x15514(%rip)     # 0x738b0 <g.4>
   5e39c:      	je	0x6e9c5 <f.2+0x17805>
   5e3a2:      	movq	%rax, 0x10(%rsp)
   5e3a7:      	cmpq	$0x0, 0x154f9(%rip)     # 0x738a8 <g.3>
   5e3af:      	je	0x6e9c5 <f.2+0x17805>
   5e3b5:      	leaq	-0xf(%r14), %rsi
   5e3b9:      	movq	$0x0, 0x50(%rsp)
   5e3c2:      	movq	$0x3, 0x38(%rsp)
   5e3cb:      	xorl	%edi, %edi
   5e3cd:      	callq	0x6e9d0 <f.3>
   5e3d2:      	subq	$0x8, %rsp
   5e3d6:      	cmpb	$0x0, 0x154d3(%rip)     # 0x738b0 <g.4>
   5e3dd:      	je	0x6e9c5 <f.2+0x17805>
   5e3e3:      	cmpq	$0x0, 0x154bd(%rip)     # 0x738a8 <g.3>
   5e3eb:      	leaq	0x28(%rsp), %r8
   5e3f0:      	leaq	0x20(%rsp), %rdi
   5e3f5:      	leaq	0x153cc(%rip), %r9      # 0x737c8 <native_roots.0>
   5e3fc:      	je	0x6e9c5 <f.2+0x17805>
   5e402:      	addq	0x10(%rsp), %rax
   5e407:      	addq	%r12, %rax
   5e40a:      	cmpq	$0xd, %r14
   5e40e:      	je	0x5e437 <f.2+0x7277>
   5e410:      	cmpq	$0xe, %r14
   5e414:      	jne	0x5e44c <f.2+0x728c>
   5e416:      	cmpq	$0x0, 0x1548a(%rip)     # 0x738a8 <g.3>
   5e41e:      	je	0x6e9c5 <f.2+0x17805>
   5e424:      	incq	%rax
   5e427:      	leaq	-0xe(%r14), %rsi
   5e42b:      	incq	%rsi
   5e42e:      	leaq	-0xd(%r14), %r12
   5e432:      	jmp	0x66d81 <f.2+0xfbc1>
   5e437:      	addq	%r14, %rax
   5e43a:      	addq	$-0xc, %rax
   5e43e:      	movl	$0x1, %esi
   5e443:      	leaq	-0xd(%r14), %r12
   5e447:      	jmp	0x66d81 <f.2+0xfbc1>
   5e44c:      	movq	%rax, 0x10(%rsp)
   5e451:      	leaq	-0xe(%r14), %rsi
   5e455:      	movq	$0x0, 0x50(%rsp)
   5e45e:      	movq	$0x3, 0x38(%rsp)
   5e467:      	xorl	%edi, %edi
   5e469:      	callq	0x6e9d0 <f.3>
   5e46e:      	subq	$0x8, %rsp
   5e472:      	cmpb	$0x0, 0x15437(%rip)     # 0x738b0 <g.4>
   5e479:      	je	0x6e9c5 <f.2+0x17805>
   5e47f:      	movq	%rax, 0x18(%rsp)
   5e484:      	cmpq	$0x0, 0x1541c(%rip)     # 0x738a8 <g.3>
   5e48c:      	je	0x6e9c5 <f.2+0x17805>
   5e492:      	leaq	-0xf(%r14), %rsi
   5e496:      	movq	$0x0, 0x50(%rsp)
   5e49f:      	movq	$0x3, 0x38(%rsp)
   5e4a8:      	xorl	%edi, %edi
   5e4aa:      	callq	0x6e9d0 <f.3>
   5e4af:      	subq	$0x8, %rsp
   5e4b3:      	cmpb	$0x0, 0x153f6(%rip)     # 0x738b0 <g.4>
   5e4ba:      	je	0x6e9c5 <f.2+0x17805>
   5e4c0:      	movq	%rax, %r12
   5e4c3:      	cmpq	$0x0, 0x153dd(%rip)     # 0x738a8 <g.3>
   5e4cb:      	leaq	-0xe(%r14), %rsi
   5e4cf:      	movq	0x10(%rsp), %rax
   5e4d4:      	je	0x6e9c5 <f.2+0x17805>
   5e4da:      	addq	0x18(%rsp), %r12
   5e4df:      	cmpq	$0xf, %r14
   5e4e3:      	ja	0x5e4f3 <f.2+0x7333>
   5e4e5:      	addq	%rsi, %r12
   5e4e8:      	addq	%rax, %r12
   5e4eb:      	movq	%r12, %rax
   5e4ee:      	jmp	0x5e59e <f.2+0x73de>
   5e4f3:      	movq	$0x0, 0x50(%rsp)
   5e4fc:      	movq	$0x3, 0x38(%rsp)
   5e505:      	xorl	%edi, %edi
   5e507:      	leaq	-0xf(%r14), %rsi
   5e50b:      	callq	0x6e9d0 <f.3>
   5e510:      	subq	$0x8, %rsp
   5e514:      	cmpb	$0x0, 0x15395(%rip)     # 0x738b0 <g.4>
   5e51b:      	je	0x6e9c5 <f.2+0x17805>
   5e521:      	movq	%rax, 0x18(%rsp)
   5e526:      	cmpq	$0x0, 0x1537a(%rip)     # 0x738a8 <g.3>
   5e52e:      	je	0x6e9c5 <f.2+0x17805>
   5e534:      	leaq	-0x10(%r14), %rsi
   5e538:      	movq	$0x0, 0x50(%rsp)
   5e541:      	movq	$0x3, 0x38(%rsp)
   5e54a:      	xorl	%edi, %edi
   5e54c:      	callq	0x6e9d0 <f.3>
   5e551:      	subq	$0x8, %rsp
   5e555:      	cmpb	$0x0, 0x15354(%rip)     # 0x738b0 <g.4>
   5e55c:      	je	0x6e9c5 <f.2+0x17805>
   5e562:      	cmpq	$0x0, 0x1533e(%rip)     # 0x738a8 <g.3>
   5e56a:      	leaq	0x28(%rsp), %r8
   5e56f:      	leaq	0x20(%rsp), %rdi
   5e574:      	leaq	0x1524d(%rip), %r9      # 0x737c8 <native_roots.0>
   5e57b:      	movq	0x10(%rsp), %rcx
   5e580:      	je	0x6e9c5 <f.2+0x17805>
   5e586:      	addq	0x18(%rsp), %rax
   5e58b:      	addq	%r12, %rax
   5e58e:      	addq	%rcx, %rax
   5e591:      	movq	%r14, %rsi
   5e594:      	subq	$0xe, %rsi
   5e598:      	jbe	0x5e42b <f.2+0x726b>
   5e59e:      	movq	%rax, 0x58(%rsp)
   5e5a3:      	movq	$0x0, 0x50(%rsp)
   5e5ac:      	movq	$0x3, 0x38(%rsp)
   5e5b5:      	xorl	%edi, %edi
   5e5b7:      	movq	%rsi, 0x10(%rsp)
   5e5bc:      	callq	0x6e9d0 <f.3>
   5e5c1:      	subq	$0x8, %rsp
   5e5c5:      	cmpb	$0x0, 0x152e4(%rip)     # 0x738b0 <g.4>
   5e5cc:      	je	0x6e9c5 <f.2+0x17805>
   5e5d2:      	cmpq	$0x0, 0x152ce(%rip)     # 0x738a8 <g.3>
   5e5da:      	je	0x6e9c5 <f.2+0x17805>
   5e5e0:      	movq	%rax, %r12
   5e5e3:      	movq	$0x0, 0x50(%rsp)
   5e5ec:      	movq	$0x3, 0x38(%rsp)
   5e5f5:      	xorl	%edi, %edi
   5e5f7:      	leaq	-0xf(%r14), %rsi
   5e5fb:      	callq	0x6e9d0 <f.3>
   5e600:      	subq	$0x8, %rsp
   5e604:      	cmpb	$0x0, 0x152a5(%rip)     # 0x738b0 <g.4>
   5e60b:      	je	0x6e9c5 <f.2+0x17805>
   5e611:      	movq	%rax, %rcx
   5e614:      	cmpq	$0x0, 0x1528c(%rip)     # 0x738a8 <g.3>
   5e61c:      	leaq	0x20(%rsp), %rdi
   5e621:      	movq	0x10(%rsp), %rsi
   5e626:      	movq	0x58(%rsp), %rax
   5e62b:      	je	0x6e9c5 <f.2+0x17805>
   5e631:      	addq	%r12, %rcx
   5e634:      	cmpq	$0xf, %r14
   5e638:      	leaq	-0xf(%r14), %r12
   5e63c:      	jne	0x5ebf5 <f.2+0x7a35>
   5e642:      	addq	%rcx, %rsi
   5e645:      	movl	$0x1, %r12d
   5e64b:      	xorl	%ecx, %ecx
   5e64d:      	leaq	0x28(%rsp), %r8
   5e652:      	leaq	0x1516f(%rip), %r9      # 0x737c8 <native_roots.0>
   5e659:      	jmp	0x66d7e <f.2+0xfbbe>
   5e65e:      	movq	$0x0, 0x50(%rsp)
   5e667:      	movq	$0x3, 0x38(%rsp)
   5e670:      	xorl	%edi, %edi
   5e672:      	leaq	-0xf(%r14), %rsi
   5e676:      	callq	0x6e9d0 <f.3>
   5e67b:      	subq	$0x8, %rsp
   5e67f:      	cmpb	$0x0, 0x1522a(%rip)     # 0x738b0 <g.4>
   5e686:      	je	0x6e9c5 <f.2+0x17805>
   5e68c:      	cmpq	$0x0, 0x15214(%rip)     # 0x738a8 <g.3>
   5e694:      	je	0x6e9c5 <f.2+0x17805>
   5e69a:      	movq	%rax, %r12
   5e69d:      	leaq	-0x10(%r14), %rsi
   5e6a1:      	movq	$0x0, 0x50(%rsp)
   5e6aa:      	movq	$0x3, 0x38(%rsp)
   5e6b3:      	xorl	%edi, %edi
   5e6b5:      	callq	0x6e9d0 <f.3>
   5e6ba:      	subq	$0x8, %rsp
   5e6be:      	addq	%r12, %rax
   5e6c1:      	movq	%rax, 0x18(%rsp)
   5e6c6:      	leaq	0x28(%rsp), %r8
   5e6cb:      	leaq	0x20(%rsp), %rdi
   5e6d0:      	leaq	0x150f1(%rip), %r9      # 0x737c8 <native_roots.0>
   5e6d7:      	movq	0x10(%rsp), %rcx
   5e6dc:      	cmpb	$0x0, 0x151cd(%rip)     # 0x738b0 <g.4>
   5e6e3:      	movq	0x58(%rsp), %r12
   5e6e8:      	je	0x6e9c5 <f.2+0x17805>
   5e6ee:      	movq	0x18(%rsp), %rax
   5e6f3:      	addq	%rbp, %rax
   5e6f6:      	movq	%rax, %rbp
   5e6f9:      	cmpq	$0x0, 0x151a7(%rip)     # 0x738a8 <g.3>
   5e701:      	je	0x6e9c5 <f.2+0x17805>
   5e707:      	addq	%r13, %rbp
   5e70a:      	addq	%r12, %rbp
   5e70d:      	cmpq	$0xc, %r14
   5e711:      	jbe	0x5e731 <f.2+0x7571>
   5e713:      	cmpq	$0xd, %r14
   5e717:      	movq	%rcx, 0x10(%rsp)
   5e71c:      	movq	%rbp, 0x18(%rsp)
   5e721:      	jne	0x5e73e <f.2+0x757e>
   5e723:      	movl	$0x1, %r13d
   5e729:      	xorl	%r12d, %r12d
   5e72c:      	jmp	0x5e87a <f.2+0x76ba>
   5e731:      	leaq	-0xb(%r14), %r13
   5e735:      	leaq	-0xb(%r14), %r12
   5e739:      	jmp	0x62c63 <f.2+0xbaa3>
   5e73e:      	leaq	-0xd(%r14), %r12
   5e742:      	movq	$0x0, 0x50(%rsp)
   5e74b:      	movq	$0x3, 0x38(%rsp)
   5e754:      	xorl	%edi, %edi
   5e756:      	movq	%r12, %rsi
   5e759:      	callq	0x6e9d0 <f.3>
   5e75e:      	subq	$0x8, %rsp
   5e762:      	cmpb	$0x0, 0x15147(%rip)     # 0x738b0 <g.4>
   5e769:      	je	0x6e9c5 <f.2+0x17805>
   5e76f:      	cmpq	$0x0, 0x15131(%rip)     # 0x738a8 <g.3>
   5e777:      	je	0x6e9c5 <f.2+0x17805>
   5e77d:      	movq	%rax, %rbp
   5e780:      	leaq	-0xe(%r14), %rsi
   5e784:      	movq	$0x0, 0x50(%rsp)
   5e78d:      	movq	$0x3, 0x38(%rsp)
   5e796:      	xorl	%edi, %edi
   5e798:      	callq	0x6e9d0 <f.3>
   5e79d:      	subq	$0x8, %rsp
   5e7a1:      	cmpb	$0x0, 0x15108(%rip)     # 0x738b0 <g.4>
   5e7a8:      	je	0x6e9c5 <f.2+0x17805>
   5e7ae:      	cmpq	$0x0, 0x150f2(%rip)     # 0x738a8 <g.3>
   5e7b6:      	je	0x6e9c5 <f.2+0x17805>
   5e7bc:      	movq	%rax, %r13
   5e7bf:      	addq	%rbp, %r13
   5e7c2:      	cmpq	$0xe, %r14
   5e7c6:      	ja	0x5e7e3 <f.2+0x7623>
   5e7c8:      	leaq	0x28(%rsp), %r8
   5e7cd:      	leaq	0x20(%rsp), %rdi
   5e7d2:      	leaq	0x14fef(%rip), %r9      # 0x737c8 <native_roots.0>
   5e7d9:      	movq	0x10(%rsp), %rcx
   5e7de:      	jmp	0x5e87a <f.2+0x76ba>
   5e7e3:      	movq	$0x0, 0x50(%rsp)
   5e7ec:      	movq	$0x3, 0x38(%rsp)
   5e7f5:      	xorl	%edi, %edi
   5e7f7:      	leaq	-0xe(%r14), %rsi
   5e7fb:      	callq	0x6e9d0 <f.3>
   5e800:      	subq	$0x8, %rsp
   5e804:      	cmpb	$0x0, 0x150a5(%rip)     # 0x738b0 <g.4>
   5e80b:      	je	0x6e9c5 <f.2+0x17805>
   5e811:      	cmpq	$0x0, 0x1508f(%rip)     # 0x738a8 <g.3>
   5e819:      	je	0x6e9c5 <f.2+0x17805>
   5e81f:      	movq	%rax, %rbp
   5e822:      	leaq	-0xf(%r14), %rsi
   5e826:      	movq	$0x0, 0x50(%rsp)
   5e82f:      	movq	$0x3, 0x38(%rsp)
   5e838:      	xorl	%edi, %edi
   5e83a:      	callq	0x6e9d0 <f.3>
   5e83f:      	subq	$0x8, %rsp
   5e843:      	cmpb	$0x0, 0x15066(%rip)     # 0x738b0 <g.4>
   5e84a:      	je	0x6e9c5 <f.2+0x17805>
   5e850:      	cmpq	$0x0, 0x15050(%rip)     # 0x738a8 <g.3>
   5e858:      	leaq	0x28(%rsp), %r8
   5e85d:      	leaq	0x20(%rsp), %rdi
   5e862:      	leaq	0x14f5f(%rip), %r9      # 0x737c8 <native_roots.0>
   5e869:      	movq	0x10(%rsp), %rcx
   5e86e:      	je	0x6e9c5 <f.2+0x17805>
   5e874:      	movq	%rax, %r12
   5e877:      	addq	%rbp, %r12
   5e87a:      	addq	%r13, %r12
   5e87d:      	cmpq	$0xd, %r14
   5e881:      	je	0x5e896 <f.2+0x76d6>
   5e883:      	cmpq	$0xe, %r14
   5e887:      	jne	0x5e8ad <f.2+0x76ed>
   5e889:      	movl	$0x1, %ebp
   5e88e:      	xorl	%r13d, %r13d
   5e891:      	jmp	0x5e9d6 <f.2+0x7816>
   5e896:      	leaq	(%r14,%r12), %r13
   5e89a:      	addq	$-0xc, %r13
   5e89e:      	movl	$0x1, %r12d
   5e8a4:      	leaq	-0xd(%r14), %rbp
   5e8a8:      	jmp	0x62c5b <f.2+0xba9b>
   5e8ad:      	leaq	-0xe(%r14), %r13
   5e8b1:      	movq	$0x0, 0x50(%rsp)
   5e8ba:      	movq	$0x3, 0x38(%rsp)
   5e8c3:      	xorl	%edi, %edi
   5e8c5:      	movq	%r13, %rsi
   5e8c8:      	callq	0x6e9d0 <f.3>
   5e8cd:      	subq	$0x8, %rsp
   5e8d1:      	cmpb	$0x0, 0x14fd8(%rip)     # 0x738b0 <g.4>
   5e8d8:      	je	0x6e9c5 <f.2+0x17805>
   5e8de:      	movq	%rax, 0x58(%rsp)
   5e8e3:      	cmpq	$0x0, 0x14fbd(%rip)     # 0x738a8 <g.3>
   5e8eb:      	je	0x6e9c5 <f.2+0x17805>
   5e8f1:      	leaq	-0xf(%r14), %rsi
   5e8f5:      	movq	$0x0, 0x50(%rsp)
   5e8fe:      	movq	$0x3, 0x38(%rsp)
   5e907:      	xorl	%edi, %edi
   5e909:      	callq	0x6e9d0 <f.3>
   5e90e:      	subq	$0x8, %rsp
   5e912:      	cmpb	$0x0, 0x14f97(%rip)     # 0x738b0 <g.4>
   5e919:      	je	0x6e9c5 <f.2+0x17805>
   5e91f:      	cmpq	$0x0, 0x14f81(%rip)     # 0x738a8 <g.3>
   5e927:      	leaq	0x28(%rsp), %r8
   5e92c:      	leaq	0x14e95(%rip), %r9      # 0x737c8 <native_roots.0>
   5e933:      	movq	0x10(%rsp), %rcx
   5e938:      	je	0x6e9c5 <f.2+0x17805>
   5e93e:      	movq	%rax, %rbp
   5e941:      	addq	0x58(%rsp), %rbp
   5e946:      	cmpq	$0x10, %r14
   5e94a:      	jae	0x5e956 <f.2+0x7796>
   5e94c:      	leaq	0x20(%rsp), %rdi
   5e951:      	jmp	0x5e9d6 <f.2+0x7816>
   5e956:      	movq	$0x0, 0x50(%rsp)
   5e95f:      	movq	$0x3, 0x38(%rsp)
   5e968:      	xorl	%edi, %edi
   5e96a:      	leaq	-0xf(%r14), %rsi
   5e96e:      	callq	0x6e9d0 <f.3>
   5e973:      	subq	$0x8, %rsp
   5e977:      	cmpb	$0x0, 0x14f32(%rip)     # 0x738b0 <g.4>
   5e97e:      	je	0x6e9c5 <f.2+0x17805>
   5e984:      	movq	%rax, 0x58(%rsp)
   5e989:      	cmpq	$0x0, 0x14f17(%rip)     # 0x738a8 <g.3>
   5e991:      	je	0x6e9c5 <f.2+0x17805>
   5e997:      	leaq	-0x10(%r14), %rsi
   5e99b:      	movq	$0x0, 0x50(%rsp)
   5e9a4:      	movq	$0x3, 0x38(%rsp)
   5e9ad:      	xorl	%edi, %edi
   5e9af:      	callq	0x6e9d0 <f.3>
   5e9b4:      	subq	$0x8, %rsp
   5e9b8:      	movq	%rax, %r13
   5e9bb:      	addq	0x58(%rsp), %r13
   5e9c0:      	leaq	0x28(%rsp), %r8
   5e9c5:      	leaq	0x20(%rsp), %rdi
   5e9ca:      	leaq	0x14df7(%rip), %r9      # 0x737c8 <native_roots.0>
   5e9d1:      	movq	0x10(%rsp), %rcx
   5e9d6:      	cmpb	$0x0, 0x14ed3(%rip)     # 0x738b0 <g.4>
   5e9dd:      	je	0x6e9c5 <f.2+0x17805>
   5e9e3:      	cmpq	$0x0, 0x14ebd(%rip)     # 0x738a8 <g.3>
   5e9eb:      	je	0x6e9c5 <f.2+0x17805>
   5e9f1:      	addq	%rbp, %r13
   5e9f4:      	addq	%r12, %r13
   5e9f7:      	movq	%r14, %r12
   5e9fa:      	subq	$0xe, %r12
   5e9fe:      	jbe	0x5eaa7 <f.2+0x78e7>
   5ea04:      	movq	$0x0, 0x50(%rsp)
   5ea0d:      	movq	$0x3, 0x38(%rsp)
   5ea16:      	xorl	%edi, %edi
   5ea18:      	movq	%r12, %rsi
   5ea1b:      	callq	0x6e9d0 <f.3>
   5ea20:      	subq	$0x8, %rsp
   5ea24:      	cmpb	$0x0, 0x14e85(%rip)     # 0x738b0 <g.4>
   5ea2b:      	je	0x6e9c5 <f.2+0x17805>
   5ea31:      	cmpq	$0x0, 0x14e6f(%rip)     # 0x738a8 <g.3>
   5ea39:      	je	0x6e9c5 <f.2+0x17805>
   5ea3f:      	movq	%rax, %rbp
   5ea42:      	leaq	-0xf(%r14), %rsi
   5ea46:      	movq	$0x0, 0x50(%rsp)
   5ea4f:      	movq	$0x3, 0x38(%rsp)
   5ea58:      	xorl	%edi, %edi
   5ea5a:      	callq	0x6e9d0 <f.3>
   5ea5f:      	subq	$0x8, %rsp
   5ea63:      	cmpb	$0x0, 0x14e46(%rip)     # 0x738b0 <g.4>
   5ea6a:      	je	0x6e9c5 <f.2+0x17805>
   5ea70:      	cmpq	$0x0, 0x14e30(%rip)     # 0x738a8 <g.3>
   5ea78:      	leaq	0x28(%rsp), %r8
   5ea7d:      	leaq	0x14d44(%rip), %r9      # 0x737c8 <native_roots.0>
   5ea84:      	je	0x6e9c5 <f.2+0x17805>
   5ea8a:      	addq	%rbp, %rax
   5ea8d:      	cmpq	$0xf, %r14
   5ea91:      	jne	0x5eab3 <f.2+0x78f3>
   5ea93:      	addq	%rax, %r12
   5ea96:      	movl	$0x1, %ebp
   5ea9b:      	xorl	%eax, %eax
   5ea9d:      	leaq	0x20(%rsp), %rdi
   5eaa2:      	jmp	0x62c53 <f.2+0xba93>
   5eaa7:      	incq	%r12
   5eaaa:      	leaq	-0xd(%r14), %rbp
   5eaae:      	jmp	0x62c5b <f.2+0xba9b>
   5eab3:      	movq	%rax, 0x58(%rsp)
   5eab8:      	movq	$0x0, 0x50(%rsp)
   5eac1:      	movq	$0x3, 0x38(%rsp)
   5eaca:      	xorl	%edi, %edi
   5eacc:      	leaq	-0xf(%r14), %rbp
   5ead0:      	movq	%rbp, %rsi
   5ead3:      	callq	0x6e9d0 <f.3>
   5ead8:      	subq	$0x8, %rsp
   5eadc:      	cmpb	$0x0, 0x14dcd(%rip)     # 0x738b0 <g.4>
   5eae3:      	je	0x6e9c5 <f.2+0x17805>
   5eae9:      	movq	%rax, 0x60(%rsp)
   5eaee:      	cmpq	$0x0, 0x14db2(%rip)     # 0x738a8 <g.3>
   5eaf6:      	je	0x6e9c5 <f.2+0x17805>
   5eafc:      	leaq	-0x10(%r14), %rsi
   5eb00:      	movq	$0x0, 0x50(%rsp)
   5eb09:      	movq	$0x3, 0x38(%rsp)
   5eb12:      	xorl	%edi, %edi
   5eb14:      	callq	0x6e9d0 <f.3>
   5eb19:      	subq	$0x8, %rsp
   5eb1d:      	cmpb	$0x0, 0x14d8c(%rip)     # 0x738b0 <g.4>
   5eb24:      	je	0x6e9c5 <f.2+0x17805>
   5eb2a:      	cmpq	$0x0, 0x14d76(%rip)     # 0x738a8 <g.3>
   5eb32:      	je	0x6e9c5 <f.2+0x17805>
   5eb38:      	movq	%rax, %r12
   5eb3b:      	movq	$0x0, 0x50(%rsp)
   5eb44:      	movq	$0x3, 0x38(%rsp)
   5eb4d:      	xorl	%edi, %edi
   5eb4f:      	movq	%rbp, %rsi
   5eb52:      	callq	0x6e9d0 <f.3>
   5eb57:      	subq	$0x8, %rsp
   5eb5b:      	cmpb	$0x0, 0x14d4e(%rip)     # 0x738b0 <g.4>
   5eb62:      	je	0x6e9c5 <f.2+0x17805>
   5eb68:      	movq	%rax, 0x68(%rsp)
   5eb6d:      	cmpq	$0x0, 0x14d33(%rip)     # 0x738a8 <g.3>
   5eb75:      	je	0x6e9c5 <f.2+0x17805>
   5eb7b:      	movq	$0x0, 0x50(%rsp)
   5eb84:      	movq	$0x3, 0x38(%rsp)
   5eb8d:      	xorl	%edi, %edi
   5eb8f:      	leaq	-0x10(%r14), %rsi
   5eb93:      	callq	0x6e9d0 <f.3>
   5eb98:      	subq	$0x8, %rsp
   5eb9c:      	cmpb	$0x0, 0x14d0d(%rip)     # 0x738b0 <g.4>
   5eba3:      	je	0x6e9c5 <f.2+0x17805>
   5eba9:      	movq	%rax, %rbp
   5ebac:      	cmpq	$0x0, 0x14cf4(%rip)     # 0x738a8 <g.3>
   5ebb4:      	leaq	0x28(%rsp), %r8
   5ebb9:      	leaq	0x14c08(%rip), %r9      # 0x737c8 <native_roots.0>
   5ebc0:      	movq	0x58(%rsp), %rax
   5ebc5:      	je	0x6e9c5 <f.2+0x17805>
   5ebcb:      	addq	0x60(%rsp), %r12
   5ebd0:      	addq	%rax, %r12
   5ebd3:      	addq	0x68(%rsp), %rbp
   5ebd8:      	cmpq	$0x11, %r14
   5ebdc:      	jae	0x62bdb <f.2+0xba1b>
   5ebe2:      	leaq	0x20(%rsp), %rdi
   5ebe7:      	movq	0x10(%rsp), %rcx
   5ebec:      	leaq	-0xf(%r14), %rax
   5ebf0:      	jmp	0x62c58 <f.2+0xba98>
   5ebf5:      	movq	%rcx, 0x18(%rsp)
   5ebfa:      	movq	$0x0, 0x50(%rsp)
   5ec03:      	movq	$0x3, 0x38(%rsp)
   5ec0c:      	xorl	%edi, %edi
   5ec0e:      	movq	%r12, %rsi
   5ec11:      	callq	0x6e9d0 <f.3>
   5ec16:      	subq	$0x8, %rsp
   5ec1a:      	cmpb	$0x0, 0x14c8f(%rip)     # 0x738b0 <g.4>
   5ec21:      	je	0x6e9c5 <f.2+0x17805>
   5ec27:      	movq	%rax, 0x60(%rsp)
   5ec2c:      	cmpq	$0x0, 0x14c74(%rip)     # 0x738a8 <g.3>
   5ec34:      	je	0x6e9c5 <f.2+0x17805>
   5ec3a:      	leaq	-0x10(%r14), %rsi
   5ec3e:      	movq	$0x0, 0x50(%rsp)
   5ec47:      	movq	$0x3, 0x38(%rsp)
   5ec50:      	xorl	%edi, %edi
   5ec52:      	callq	0x6e9d0 <f.3>
   5ec57:      	subq	$0x8, %rsp
   5ec5b:      	cmpb	$0x0, 0x14c4e(%rip)     # 0x738b0 <g.4>
   5ec62:      	je	0x6e9c5 <f.2+0x17805>
   5ec68:      	movq	%rax, 0x10(%rsp)
   5ec6d:      	cmpq	$0x0, 0x14c33(%rip)     # 0x738a8 <g.3>
   5ec75:      	je	0x6e9c5 <f.2+0x17805>
   5ec7b:      	movq	$0x0, 0x50(%rsp)
   5ec84:      	movq	$0x3, 0x38(%rsp)
   5ec8d:      	xorl	%edi, %edi
   5ec8f:      	movq	%r12, %rsi
   5ec92:      	callq	0x6e9d0 <f.3>
   5ec97:      	subq	$0x8, %rsp
   5ec9b:      	cmpb	$0x0, 0x14c0e(%rip)     # 0x738b0 <g.4>
   5eca2:      	je	0x6e9c5 <f.2+0x17805>
   5eca8:      	movq	%rax, 0x68(%rsp)
   5ecad:      	cmpq	$0x0, 0x14bf3(%rip)     # 0x738a8 <g.3>
   5ecb5:      	je	0x6e9c5 <f.2+0x17805>
   5ecbb:      	movq	$0x0, 0x50(%rsp)
   5ecc4:      	movq	$0x3, 0x38(%rsp)
   5eccd:      	xorl	%edi, %edi
   5eccf:      	leaq	-0x10(%r14), %rsi
   5ecd3:      	callq	0x6e9d0 <f.3>
   5ecd8:      	subq	$0x8, %rsp
   5ecdc:      	cmpb	$0x0, 0x14bcd(%rip)     # 0x738b0 <g.4>
   5ece3:      	je	0x6e9c5 <f.2+0x17805>
   5ece9:      	movq	%rax, %r12
   5ecec:      	cmpq	$0x0, 0x14bb4(%rip)     # 0x738a8 <g.3>
   5ecf4:      	leaq	0x20(%rsp), %rdi
   5ecf9:      	movq	0x10(%rsp), %rsi
   5ecfe:      	movq	0x58(%rsp), %rax
   5ed03:      	movq	0x18(%rsp), %rcx
   5ed08:      	je	0x6e9c5 <f.2+0x17805>
   5ed0e:      	addq	0x60(%rsp), %rsi
   5ed13:      	addq	%rcx, %rsi
   5ed16:      	addq	0x68(%rsp), %r12
   5ed1b:      	cmpq	$0x11, %r14
   5ed1f:      	jae	0x66cee <f.2+0xfb2e>
   5ed25:      	leaq	0x28(%rsp), %r8
   5ed2a:      	leaq	0x14a97(%rip), %r9      # 0x737c8 <native_roots.0>
   5ed31:      	leaq	-0xf(%r14), %rcx
   5ed35:      	jmp	0x66d7e <f.2+0xfbbe>
   5ed3a:      	movq	$0x0, 0x50(%rsp)
   5ed43:      	movq	$0x3, 0x38(%rsp)
   5ed4c:      	xorl	%edi, %edi
   5ed4e:      	leaq	-0xf(%r14), %rsi
   5ed52:      	callq	0x6e9d0 <f.3>
   5ed57:      	subq	$0x8, %rsp
   5ed5b:      	cmpb	$0x0, 0x14b4e(%rip)     # 0x738b0 <g.4>
   5ed62:      	je	0x6e9c5 <f.2+0x17805>
   5ed68:      	cmpq	$0x0, 0x14b38(%rip)     # 0x738a8 <g.3>
   5ed70:      	je	0x6e9c5 <f.2+0x17805>
   5ed76:      	movq	%rax, %rbp
   5ed79:      	leaq	-0x10(%r14), %rsi
   5ed7d:      	movq	$0x0, 0x50(%rsp)
   5ed86:      	movq	$0x3, 0x38(%rsp)
   5ed8f:      	xorl	%edi, %edi
   5ed91:      	callq	0x6e9d0 <f.3>
   5ed96:      	subq	$0x8, %rsp
   5ed9a:      	movq	%rax, %rcx
   5ed9d:      	addq	%rbp, %rcx
   5eda0:      	leaq	0x28(%rsp), %r8
   5eda5:      	leaq	0x20(%rsp), %rdi
   5edaa:      	leaq	0x14a17(%rip), %r9      # 0x737c8 <native_roots.0>
   5edb1:      	movq	0x18(%rsp), %rbp
   5edb6:      	movq	0x10(%rsp), %rax
   5edbb:      	addq	%rcx, %r12
   5edbe:      	cmpb	$0x0, 0x14aeb(%rip)     # 0x738b0 <g.4>
   5edc5:      	je	0x6e9c5 <f.2+0x17805>
   5edcb:      	addq	%rbp, %r12
   5edce:      	addq	%rax, %r12
   5edd1:      	jmp	0x580ba <f.2+0xefa>
   5edd6:      	movq	%rdx, 0x18(%rsp)
   5eddb:      	movq	$0x0, 0x50(%rsp)
   5ede4:      	movq	$0x3, 0x38(%rsp)
   5eded:      	xorl	%edi, %edi
   5edef:      	leaq	-0xf(%r14), %rsi
   5edf3:      	callq	0x6e9d0 <f.3>
   5edf8:      	subq	$0x8, %rsp
   5edfc:      	cmpb	$0x0, 0x14aad(%rip)     # 0x738b0 <g.4>
   5ee03:      	je	0x6e9c5 <f.2+0x17805>
   5ee09:      	cmpq	$0x0, 0x14a97(%rip)     # 0x738a8 <g.3>
   5ee11:      	je	0x6e9c5 <f.2+0x17805>
   5ee17:      	movq	%rax, %rbp
   5ee1a:      	leaq	-0x10(%r14), %rsi
   5ee1e:      	movq	$0x0, 0x50(%rsp)
   5ee27:      	movq	$0x3, 0x38(%rsp)
   5ee30:      	xorl	%edi, %edi
   5ee32:      	callq	0x6e9d0 <f.3>
   5ee37:      	subq	$0x8, %rsp
   5ee3b:      	addq	%rbp, %rax
   5ee3e:      	leaq	0x28(%rsp), %r8
   5ee43:      	leaq	0x20(%rsp), %rdi
   5ee48:      	leaq	0x14979(%rip), %r9      # 0x737c8 <native_roots.0>
   5ee4f:      	movq	0x10(%rsp), %rcx
   5ee54:      	movq	0x18(%rsp), %rdx
   5ee59:      	cmpb	$0x0, 0x14a50(%rip)     # 0x738b0 <g.4>
   5ee60:      	je	0x6e9c5 <f.2+0x17805>
   5ee66:      	cmpq	$0x0, 0x14a3a(%rip)     # 0x738a8 <g.3>
   5ee6e:      	je	0x6e9c5 <f.2+0x17805>
   5ee74:      	addq	%rdx, %rax
   5ee77:      	addq	%r13, %rax
   5ee7a:      	cmpq	$0xc, %r14
   5ee7e:      	je	0x5ef5b <f.2+0x7d9b>
   5ee84:      	movl	$0x1, %ebp
   5ee89:      	cmpq	$0xd, %r14
   5ee8d:      	je	0x5ef74 <f.2+0x7db4>
   5ee93:      	movq	%r14, %rbp
   5ee96:      	subq	$0xe, %rbp
   5ee9a:      	jbe	0x5ef71 <f.2+0x7db1>
   5eea0:      	movq	%rax, 0x18(%rsp)
   5eea5:      	movq	%rcx, 0x10(%rsp)
   5eeaa:      	movq	$0x0, 0x50(%rsp)
   5eeb3:      	movq	$0x3, 0x38(%rsp)
   5eebc:      	xorl	%edi, %edi
   5eebe:      	movq	%rbp, %rsi
   5eec1:      	callq	0x6e9d0 <f.3>
   5eec6:      	subq	$0x8, %rsp
   5eeca:      	cmpb	$0x0, 0x149df(%rip)     # 0x738b0 <g.4>
   5eed1:      	je	0x6e9c5 <f.2+0x17805>
   5eed7:      	cmpq	$0x0, 0x149c9(%rip)     # 0x738a8 <g.3>
   5eedf:      	je	0x6e9c5 <f.2+0x17805>
   5eee5:      	movq	%rax, %r13
   5eee8:      	leaq	-0xf(%r14), %rsi
   5eeec:      	movq	$0x0, 0x50(%rsp)
   5eef5:      	movq	$0x3, 0x38(%rsp)
   5eefe:      	xorl	%edi, %edi
   5ef00:      	callq	0x6e9d0 <f.3>
   5ef05:      	subq	$0x8, %rsp
   5ef09:      	cmpb	$0x0, 0x149a0(%rip)     # 0x738b0 <g.4>
   5ef10:      	je	0x6e9c5 <f.2+0x17805>
   5ef16:      	movq	%rax, %rcx
   5ef19:      	cmpq	$0x0, 0x14987(%rip)     # 0x738a8 <g.3>
   5ef21:      	leaq	0x28(%rsp), %r8
   5ef26:      	leaq	0x1489b(%rip), %r9      # 0x737c8 <native_roots.0>
   5ef2d:      	movq	0x18(%rsp), %rax
   5ef32:      	je	0x6e9c5 <f.2+0x17805>
   5ef38:      	addq	%r13, %rcx
   5ef3b:      	cmpq	$0xf, %r14
   5ef3f:      	jne	0x5ef7d <f.2+0x7dbd>
   5ef41:      	addq	%rcx, %rbp
   5ef44:      	movl	$0x1, %r13d
   5ef4a:      	xorl	%edx, %edx
   5ef4c:      	leaq	0x20(%rsp), %rdi
   5ef51:      	movq	0x10(%rsp), %rcx
   5ef56:      	jmp	0x62d2a <f.2+0xbb6a>
   5ef5b:      	leaq	(%r14,%rax), %r13
   5ef5f:      	addq	$-0xb, %r13
   5ef63:      	movl	$0x1, %ebp
   5ef68:      	leaq	-0xc(%r14), %rsi
   5ef6c:      	jmp	0x66fc3 <f.2+0xfe03>
   5ef71:      	incq	%rbp
   5ef74:      	leaq	-0xd(%r14), %r13
   5ef78:      	jmp	0x62d2d <f.2+0xbb6d>
   5ef7d:      	movq	%rcx, 0x58(%rsp)
   5ef82:      	movq	$0x0, 0x50(%rsp)
   5ef8b:      	movq	$0x3, 0x38(%rsp)
   5ef94:      	xorl	%edi, %edi
   5ef96:      	leaq	-0xf(%r14), %r13
   5ef9a:      	movq	%r13, %rsi
   5ef9d:      	callq	0x6e9d0 <f.3>
   5efa2:      	subq	$0x8, %rsp
   5efa6:      	cmpb	$0x0, 0x14903(%rip)     # 0x738b0 <g.4>
   5efad:      	je	0x6e9c5 <f.2+0x17805>
   5efb3:      	movq	%rax, 0x60(%rsp)
   5efb8:      	cmpq	$0x0, 0x148e8(%rip)     # 0x738a8 <g.3>
   5efc0:      	je	0x6e9c5 <f.2+0x17805>
   5efc6:      	leaq	-0x10(%r14), %rsi
   5efca:      	movq	$0x0, 0x50(%rsp)
   5efd3:      	movq	$0x3, 0x38(%rsp)
   5efdc:      	xorl	%edi, %edi
   5efde:      	callq	0x6e9d0 <f.3>
   5efe3:      	subq	$0x8, %rsp
   5efe7:      	cmpb	$0x0, 0x148c2(%rip)     # 0x738b0 <g.4>
   5efee:      	je	0x6e9c5 <f.2+0x17805>
   5eff4:      	cmpq	$0x0, 0x148ac(%rip)     # 0x738a8 <g.3>
   5effc:      	je	0x6e9c5 <f.2+0x17805>
   5f002:      	movq	%rax, %rbp
   5f005:      	movq	$0x0, 0x50(%rsp)
   5f00e:      	movq	$0x3, 0x38(%rsp)
   5f017:      	xorl	%edi, %edi
   5f019:      	movq	%r13, %rsi
   5f01c:      	callq	0x6e9d0 <f.3>
   5f021:      	subq	$0x8, %rsp
   5f025:      	cmpb	$0x0, 0x14884(%rip)     # 0x738b0 <g.4>
   5f02c:      	je	0x6e9c5 <f.2+0x17805>
   5f032:      	movq	%rax, 0x68(%rsp)
   5f037:      	cmpq	$0x0, 0x14869(%rip)     # 0x738a8 <g.3>
   5f03f:      	je	0x6e9c5 <f.2+0x17805>
   5f045:      	movq	$0x0, 0x50(%rsp)
   5f04e:      	movq	$0x3, 0x38(%rsp)
   5f057:      	xorl	%edi, %edi
   5f059:      	leaq	-0x10(%r14), %rsi
   5f05d:      	callq	0x6e9d0 <f.3>
   5f062:      	subq	$0x8, %rsp
   5f066:      	cmpb	$0x0, 0x14843(%rip)     # 0x738b0 <g.4>
   5f06d:      	je	0x6e9c5 <f.2+0x17805>
   5f073:      	movq	%rax, %r13
   5f076:      	cmpq	$0x0, 0x1482a(%rip)     # 0x738a8 <g.3>
   5f07e:      	leaq	0x28(%rsp), %r8
   5f083:      	leaq	0x1473e(%rip), %r9      # 0x737c8 <native_roots.0>
   5f08a:      	movq	0x18(%rsp), %rax
   5f08f:      	movq	0x58(%rsp), %rcx
   5f094:      	je	0x6e9c5 <f.2+0x17805>
   5f09a:      	addq	0x60(%rsp), %rbp
   5f09f:      	addq	%rcx, %rbp
   5f0a2:      	addq	0x68(%rsp), %r13
   5f0a7:      	cmpq	$0x11, %r14
   5f0ab:      	jae	0x62ca5 <f.2+0xbae5>
   5f0b1:      	leaq	0x20(%rsp), %rdi
   5f0b6:      	movq	0x10(%rsp), %rcx
   5f0bb:      	leaq	-0xf(%r14), %rdx
   5f0bf:      	jmp	0x62d2a <f.2+0xbb6a>
   5f0c4:      	movq	%rdx, 0x18(%rsp)
   5f0c9:      	movq	$0x0, 0x50(%rsp)
   5f0d2:      	movq	$0x3, 0x38(%rsp)
   5f0db:      	xorl	%edi, %edi
   5f0dd:      	leaq	-0x10(%r14), %rsi
   5f0e1:      	callq	0x6e9d0 <f.3>
   5f0e6:      	subq	$0x8, %rsp
   5f0ea:      	cmpb	$0x0, 0x147bf(%rip)     # 0x738b0 <g.4>
   5f0f1:      	je	0x6e9c5 <f.2+0x17805>
   5f0f7:      	movq	%rax, 0x58(%rsp)
   5f0fc:      	cmpq	$0x0, 0x147a4(%rip)     # 0x738a8 <g.3>
   5f104:      	je	0x6e9c5 <f.2+0x17805>
   5f10a:      	leaq	-0x11(%r14), %rsi
   5f10e:      	movq	$0x0, 0x50(%rsp)
   5f117:      	movq	$0x3, 0x38(%rsp)
   5f120:      	xorl	%edi, %edi
   5f122:      	callq	0x6e9d0 <f.3>
   5f127:      	subq	$0x8, %rsp
   5f12b:      	movq	%rax, %rcx
   5f12e:      	addq	0x58(%rsp), %rcx
   5f133:      	leaq	0x28(%rsp), %r8
   5f138:      	leaq	0x20(%rsp), %rdi
   5f13d:      	leaq	0x14684(%rip), %r9      # 0x737c8 <native_roots.0>
   5f144:      	movq	0x10(%rsp), %rax
   5f149:      	movq	0x18(%rsp), %rdx
   5f14e:      	addq	%rcx, %rdx
   5f151:      	addq	%rdx, %rbp
   5f154:      	cmpb	$0x0, 0x14755(%rip)     # 0x738b0 <g.4>
   5f15b:      	je	0x6e9c5 <f.2+0x17805>
   5f161:      	cmpq	$0x0, 0x1473f(%rip)     # 0x738a8 <g.3>
   5f169:      	je	0x6e9c5 <f.2+0x17805>
   5f16f:      	addq	%r13, %rbp
   5f172:      	addq	%r15, %rbp
   5f175:      	cmpq	$0xb, %r14
   5f179:      	jbe	0x5f23c <f.2+0x807c>
   5f17f:      	movl	$0x1, %r15d
   5f185:      	cmpq	$0xc, %r14
   5f189:      	je	0x5f24c <f.2+0x808c>
   5f18f:      	movq	%r14, %r15
   5f192:      	subq	$0xd, %r15
   5f196:      	jbe	0x5f249 <f.2+0x8089>
   5f19c:      	movq	%rax, 0x10(%rsp)
   5f1a1:      	movq	$0x0, 0x50(%rsp)
   5f1aa:      	movq	$0x3, 0x38(%rsp)
   5f1b3:      	xorl	%edi, %edi
   5f1b5:      	movq	%r15, %rsi
   5f1b8:      	callq	0x6e9d0 <f.3>
   5f1bd:      	subq	$0x8, %rsp
   5f1c1:      	cmpb	$0x0, 0x146e8(%rip)     # 0x738b0 <g.4>
   5f1c8:      	je	0x6e9c5 <f.2+0x17805>
   5f1ce:      	cmpq	$0x0, 0x146d2(%rip)     # 0x738a8 <g.3>
   5f1d6:      	je	0x6e9c5 <f.2+0x17805>
   5f1dc:      	movq	%rax, %r13
   5f1df:      	leaq	-0xe(%r14), %rsi
   5f1e3:      	movq	$0x0, 0x50(%rsp)
   5f1ec:      	movq	$0x3, 0x38(%rsp)
   5f1f5:      	xorl	%edi, %edi
   5f1f7:      	callq	0x6e9d0 <f.3>
   5f1fc:      	subq	$0x8, %rsp
   5f200:      	cmpb	$0x0, 0x146a9(%rip)     # 0x738b0 <g.4>
   5f207:      	je	0x6e9c5 <f.2+0x17805>
   5f20d:      	cmpq	$0x0, 0x14693(%rip)     # 0x738a8 <g.3>
   5f215:      	leaq	0x20(%rsp), %rdi
   5f21a:      	je	0x6e9c5 <f.2+0x17805>
   5f220:      	addq	%r13, %rax
   5f223:      	cmpq	$0xe, %r14
   5f227:      	leaq	-0xe(%r14), %rsi
   5f22b:      	jne	0x5f259 <f.2+0x8099>
   5f22d:      	addq	%rax, %r15
   5f230:      	movl	$0x1, %edx
   5f235:      	xorl	%ecx, %ecx
   5f237:      	jmp	0x5f374 <f.2+0x81b4>
   5f23c:      	leaq	-0xa(%r14), %r15
   5f240:      	leaq	-0xa(%r14), %r13
   5f244:      	jmp	0x63e77 <f.2+0xccb7>
   5f249:      	incq	%r15
   5f24c:      	leaq	(%r14,%r15), %rcx
   5f250:      	addq	$-0xc, %rcx
   5f254:      	jmp	0x5f431 <f.2+0x8271>
   5f259:      	movq	%rax, 0x18(%rsp)
   5f25e:      	movq	$0x0, 0x50(%rsp)
   5f267:      	movq	$0x3, 0x38(%rsp)
   5f270:      	xorl	%edi, %edi
   5f272:      	callq	0x6e9d0 <f.3>
   5f277:      	subq	$0x8, %rsp
   5f27b:      	cmpb	$0x0, 0x1462e(%rip)     # 0x738b0 <g.4>
   5f282:      	je	0x6e9c5 <f.2+0x17805>
   5f288:      	movq	%rax, 0x58(%rsp)
   5f28d:      	cmpq	$0x0, 0x14613(%rip)     # 0x738a8 <g.3>
   5f295:      	je	0x6e9c5 <f.2+0x17805>
   5f29b:      	leaq	-0xf(%r14), %rsi
   5f29f:      	movq	$0x0, 0x50(%rsp)
   5f2a8:      	movq	$0x3, 0x38(%rsp)
   5f2b1:      	xorl	%edi, %edi
   5f2b3:      	callq	0x6e9d0 <f.3>
   5f2b8:      	subq	$0x8, %rsp
   5f2bc:      	cmpb	$0x0, 0x145ed(%rip)     # 0x738b0 <g.4>
   5f2c3:      	je	0x6e9c5 <f.2+0x17805>
   5f2c9:      	cmpq	$0x0, 0x145d7(%rip)     # 0x738a8 <g.3>
   5f2d1:      	leaq	-0xe(%r14), %rsi
   5f2d5:      	je	0x6e9c5 <f.2+0x17805>
   5f2db:      	movq	%rax, %r15
   5f2de:      	movq	$0x0, 0x50(%rsp)
   5f2e7:      	movq	$0x3, 0x38(%rsp)
   5f2f0:      	xorl	%edi, %edi
   5f2f2:      	callq	0x6e9d0 <f.3>
   5f2f7:      	subq	$0x8, %rsp
   5f2fb:      	cmpb	$0x0, 0x145ae(%rip)     # 0x738b0 <g.4>
   5f302:      	je	0x6e9c5 <f.2+0x17805>
   5f308:      	cmpq	$0x0, 0x14598(%rip)     # 0x738a8 <g.3>
   5f310:      	je	0x6e9c5 <f.2+0x17805>
   5f316:      	movq	%rax, %r13
   5f319:      	movq	$0x0, 0x50(%rsp)
   5f322:      	movq	$0x3, 0x38(%rsp)
   5f32b:      	xorl	%edi, %edi
   5f32d:      	leaq	-0xf(%r14), %rsi
   5f331:      	callq	0x6e9d0 <f.3>
   5f336:      	subq	$0x8, %rsp
   5f33a:      	cmpb	$0x0, 0x1456f(%rip)     # 0x738b0 <g.4>
   5f341:      	je	0x6e9c5 <f.2+0x17805>
   5f347:      	cmpq	$0x0, 0x14559(%rip)     # 0x738a8 <g.3>
   5f34f:      	leaq	0x20(%rsp), %rdi
   5f354:      	leaq	-0xe(%r14), %rcx
   5f358:      	je	0x6e9c5 <f.2+0x17805>
   5f35e:      	movq	%rax, %rdx
   5f361:      	addq	0x58(%rsp), %r15
   5f366:      	addq	0x18(%rsp), %r15
   5f36b:      	addq	%r13, %rdx
   5f36e:      	cmpq	$0x10, %r14
   5f372:      	jae	0x5f38a <f.2+0x81ca>
   5f374:      	leaq	0x28(%rsp), %r8
   5f379:      	leaq	0x14448(%rip), %r9      # 0x737c8 <native_roots.0>
   5f380:      	movq	0x10(%rsp), %rax
   5f385:      	jmp	0x5f410 <f.2+0x8250>
   5f38a:      	movq	%rdx, 0x18(%rsp)
   5f38f:      	movq	$0x0, 0x50(%rsp)
   5f398:      	movq	$0x3, 0x38(%rsp)
   5f3a1:      	xorl	%edi, %edi
   5f3a3:      	leaq	-0xf(%r14), %rsi
   5f3a7:      	callq	0x6e9d0 <f.3>
   5f3ac:      	subq	$0x8, %rsp
   5f3b0:      	cmpb	$0x0, 0x144f9(%rip)     # 0x738b0 <g.4>
   5f3b7:      	je	0x6e9c5 <f.2+0x17805>
   5f3bd:      	cmpq	$0x0, 0x144e3(%rip)     # 0x738a8 <g.3>
   5f3c5:      	je	0x6e9c5 <f.2+0x17805>
   5f3cb:      	movq	%rax, %r13
   5f3ce:      	leaq	-0x10(%r14), %rsi
   5f3d2:      	movq	$0x0, 0x50(%rsp)
   5f3db:      	movq	$0x3, 0x38(%rsp)
   5f3e4:      	xorl	%edi, %edi
   5f3e6:      	callq	0x6e9d0 <f.3>
   5f3eb:      	subq	$0x8, %rsp
   5f3ef:      	movq	%rax, %rcx
   5f3f2:      	addq	%r13, %rcx
   5f3f5:      	leaq	0x28(%rsp), %r8
   5f3fa:      	leaq	0x20(%rsp), %rdi
   5f3ff:      	leaq	0x143c2(%rip), %r9      # 0x737c8 <native_roots.0>
   5f406:      	movq	0x10(%rsp), %rax
   5f40b:      	movq	0x18(%rsp), %rdx
   5f410:      	cmpb	$0x0, 0x14499(%rip)     # 0x738b0 <g.4>
   5f417:      	je	0x6e9c5 <f.2+0x17805>
   5f41d:      	cmpq	$0x0, 0x14483(%rip)     # 0x738a8 <g.3>
   5f425:      	je	0x6e9c5 <f.2+0x17805>
   5f42b:      	addq	%rdx, %rcx
   5f42e:      	addq	%r15, %rcx
   5f431:      	cmpq	$0xc, %r14
   5f435:      	je	0x5f513 <f.2+0x8353>
   5f43b:      	movl	$0x1, %r13d
   5f441:      	cmpq	$0xd, %r14
   5f445:      	je	0x5f52d <f.2+0x836d>
   5f44b:      	movq	%r14, %r13
   5f44e:      	subq	$0xe, %r13
   5f452:      	jbe	0x5f52a <f.2+0x836a>
   5f458:      	movq	%rcx, 0x18(%rsp)
   5f45d:      	movq	%rax, 0x10(%rsp)
   5f462:      	movq	$0x0, 0x50(%rsp)
   5f46b:      	movq	$0x3, 0x38(%rsp)
   5f474:      	xorl	%edi, %edi
   5f476:      	movq	%r13, %rsi
   5f479:      	callq	0x6e9d0 <f.3>
   5f47e:      	subq	$0x8, %rsp
   5f482:      	cmpb	$0x0, 0x14427(%rip)     # 0x738b0 <g.4>
   5f489:      	je	0x6e9c5 <f.2+0x17805>
   5f48f:      	cmpq	$0x0, 0x14411(%rip)     # 0x738a8 <g.3>
   5f497:      	je	0x6e9c5 <f.2+0x17805>
   5f49d:      	movq	%rax, %r15
   5f4a0:      	leaq	-0xf(%r14), %rsi
   5f4a4:      	movq	$0x0, 0x50(%rsp)
   5f4ad:      	movq	$0x3, 0x38(%rsp)
   5f4b6:      	xorl	%edi, %edi
   5f4b8:      	callq	0x6e9d0 <f.3>
   5f4bd:      	subq	$0x8, %rsp
   5f4c1:      	cmpb	$0x0, 0x143e8(%rip)     # 0x738b0 <g.4>
   5f4c8:      	je	0x6e9c5 <f.2+0x17805>
   5f4ce:      	movq	%rax, %rdx
   5f4d1:      	cmpq	$0x0, 0x143cf(%rip)     # 0x738a8 <g.3>
   5f4d9:      	leaq	0x28(%rsp), %r8
   5f4de:      	leaq	0x20(%rsp), %rdi
   5f4e3:      	leaq	0x142de(%rip), %r9      # 0x737c8 <native_roots.0>
   5f4ea:      	movq	0x10(%rsp), %rax
   5f4ef:      	movq	0x18(%rsp), %rcx
   5f4f4:      	je	0x6e9c5 <f.2+0x17805>
   5f4fa:      	addq	%r15, %rdx
   5f4fd:      	cmpq	$0xf, %r14
   5f501:      	jne	0x5f536 <f.2+0x8376>
   5f503:      	addq	%rdx, %r13
   5f506:      	movl	$0x1, %r15d
   5f50c:      	xorl	%edx, %edx
   5f50e:      	jmp	0x5f6fe <f.2+0x853e>
   5f513:      	leaq	(%r14,%rcx), %r15
   5f517:      	addq	$-0xb, %r15
   5f51b:      	movl	$0x1, %r13d
   5f521:      	leaq	-0xc(%r14), %rdx
   5f525:      	jmp	0x63e74 <f.2+0xccb4>
   5f52a:      	incq	%r13
   5f52d:      	leaq	-0xd(%r14), %r15
   5f531:      	jmp	0x5f701 <f.2+0x8541>
   5f536:      	movq	%rdx, 0x58(%rsp)
   5f53b:      	movq	$0x0, 0x50(%rsp)
   5f544:      	movq	$0x3, 0x38(%rsp)
   5f54d:      	xorl	%edi, %edi
   5f54f:      	leaq	-0xf(%r14), %r15
   5f553:      	movq	%r15, %rsi
   5f556:      	callq	0x6e9d0 <f.3>
   5f55b:      	subq	$0x8, %rsp
   5f55f:      	cmpb	$0x0, 0x1434a(%rip)     # 0x738b0 <g.4>
   5f566:      	je	0x6e9c5 <f.2+0x17805>
   5f56c:      	movq	%rax, 0x60(%rsp)
   5f571:      	cmpq	$0x0, 0x1432f(%rip)     # 0x738a8 <g.3>
   5f579:      	je	0x6e9c5 <f.2+0x17805>
   5f57f:      	leaq	-0x10(%r14), %rsi
   5f583:      	movq	$0x0, 0x50(%rsp)
   5f58c:      	movq	$0x3, 0x38(%rsp)
   5f595:      	xorl	%edi, %edi
   5f597:      	callq	0x6e9d0 <f.3>
   5f59c:      	subq	$0x8, %rsp
   5f5a0:      	cmpb	$0x0, 0x14309(%rip)     # 0x738b0 <g.4>
   5f5a7:      	je	0x6e9c5 <f.2+0x17805>
   5f5ad:      	cmpq	$0x0, 0x142f3(%rip)     # 0x738a8 <g.3>
   5f5b5:      	je	0x6e9c5 <f.2+0x17805>
   5f5bb:      	movq	%rax, %r13
   5f5be:      	movq	$0x0, 0x50(%rsp)
   5f5c7:      	movq	$0x3, 0x38(%rsp)
   5f5d0:      	xorl	%edi, %edi
   5f5d2:      	movq	%r15, %rsi
   5f5d5:      	callq	0x6e9d0 <f.3>
   5f5da:      	subq	$0x8, %rsp
   5f5de:      	cmpb	$0x0, 0x142cb(%rip)     # 0x738b0 <g.4>
   5f5e5:      	je	0x6e9c5 <f.2+0x17805>
   5f5eb:      	movq	%rax, 0x68(%rsp)
   5f5f0:      	cmpq	$0x0, 0x142b0(%rip)     # 0x738a8 <g.3>
   5f5f8:      	je	0x6e9c5 <f.2+0x17805>
   5f5fe:      	movq	$0x0, 0x50(%rsp)
   5f607:      	movq	$0x3, 0x38(%rsp)
   5f610:      	xorl	%edi, %edi
   5f612:      	leaq	-0x10(%r14), %rsi
   5f616:      	callq	0x6e9d0 <f.3>
   5f61b:      	subq	$0x8, %rsp
   5f61f:      	cmpb	$0x0, 0x1428a(%rip)     # 0x738b0 <g.4>
   5f626:      	je	0x6e9c5 <f.2+0x17805>
   5f62c:      	movq	%rax, %r15
   5f62f:      	cmpq	$0x0, 0x14271(%rip)     # 0x738a8 <g.3>
   5f637:      	leaq	0x28(%rsp), %r8
   5f63c:      	leaq	0x20(%rsp), %rdi
   5f641:      	leaq	0x14180(%rip), %r9      # 0x737c8 <native_roots.0>
   5f648:      	movq	0x10(%rsp), %rax
   5f64d:      	movq	0x18(%rsp), %rcx
   5f652:      	movq	0x58(%rsp), %rdx
   5f657:      	je	0x6e9c5 <f.2+0x17805>
   5f65d:      	addq	0x60(%rsp), %r13
   5f662:      	addq	%rdx, %r13
   5f665:      	addq	0x68(%rsp), %r15
   5f66a:      	cmpq	$0x11, %r14
   5f66e:      	jae	0x5f679 <f.2+0x84b9>
   5f670:      	leaq	-0xf(%r14), %rdx
   5f674:      	jmp	0x5f6fe <f.2+0x853e>
   5f679:      	movq	$0x0, 0x50(%rsp)
   5f682:      	movq	$0x3, 0x38(%rsp)
   5f68b:      	xorl	%edi, %edi
   5f68d:      	leaq	-0x10(%r14), %rsi
   5f691:      	callq	0x6e9d0 <f.3>
   5f696:      	subq	$0x8, %rsp
   5f69a:      	cmpb	$0x0, 0x1420f(%rip)     # 0x738b0 <g.4>
   5f6a1:      	je	0x6e9c5 <f.2+0x17805>
   5f6a7:      	movq	%rax, 0x58(%rsp)
   5f6ac:      	cmpq	$0x0, 0x141f4(%rip)     # 0x738a8 <g.3>
   5f6b4:      	je	0x6e9c5 <f.2+0x17805>
   5f6ba:      	leaq	-0x11(%r14), %rsi
   5f6be:      	movq	$0x0, 0x50(%rsp)
   5f6c7:      	movq	$0x3, 0x38(%rsp)
   5f6d0:      	xorl	%edi, %edi
   5f6d2:      	callq	0x6e9d0 <f.3>
   5f6d7:      	subq	$0x8, %rsp
   5f6db:      	movq	%rax, %rdx
   5f6de:      	addq	0x58(%rsp), %rdx
   5f6e3:      	leaq	0x28(%rsp), %r8
   5f6e8:      	leaq	0x20(%rsp), %rdi
   5f6ed:      	leaq	0x140d4(%rip), %r9      # 0x737c8 <native_roots.0>
   5f6f4:      	movq	0x10(%rsp), %rax
   5f6f9:      	movq	0x18(%rsp), %rcx
   5f6fe:      	addq	%rdx, %r15
   5f701:      	cmpb	$0x0, 0x141a8(%rip)     # 0x738b0 <g.4>
   5f708:      	je	0x6e9c5 <f.2+0x17805>
   5f70e:      	cmpq	$0x0, 0x14192(%rip)     # 0x738a8 <g.3>
   5f716:      	je	0x6e9c5 <f.2+0x17805>
   5f71c:      	addq	%r13, %r15
   5f71f:      	addq	%rcx, %r15
   5f722:      	cmpq	$0xd, %r14
   5f726:      	jbe	0x5f740 <f.2+0x8580>
   5f728:      	cmpq	$0xe, %r14
   5f72c:      	movq	%rax, 0x10(%rsp)
   5f731:      	jne	0x5f74d <f.2+0x858d>
   5f733:      	movl	$0x1, %r13d
   5f739:      	xorl	%ecx, %ecx
   5f73b:      	jmp	0x5f892 <f.2+0x86d2>
   5f740:      	leaq	-0xc(%r14), %r13
   5f744:      	leaq	-0xc(%r14), %rdx
   5f748:      	jmp	0x63e74 <f.2+0xccb4>
   5f74d:      	leaq	-0xe(%r14), %rsi
   5f751:      	movq	$0x0, 0x50(%rsp)
   5f75a:      	movq	$0x3, 0x38(%rsp)
   5f763:      	xorl	%edi, %edi
   5f765:      	callq	0x6e9d0 <f.3>
   5f76a:      	subq	$0x8, %rsp
   5f76e:      	cmpb	$0x0, 0x1413b(%rip)     # 0x738b0 <g.4>
   5f775:      	je	0x6e9c5 <f.2+0x17805>
   5f77b:      	movq	%rax, 0x18(%rsp)
   5f780:      	cmpq	$0x0, 0x14120(%rip)     # 0x738a8 <g.3>
   5f788:      	je	0x6e9c5 <f.2+0x17805>
   5f78e:      	leaq	-0xf(%r14), %rsi
   5f792:      	movq	$0x0, 0x50(%rsp)
   5f79b:      	movq	$0x3, 0x38(%rsp)
   5f7a4:      	xorl	%edi, %edi
   5f7a6:      	callq	0x6e9d0 <f.3>
   5f7ab:      	subq	$0x8, %rsp
   5f7af:      	cmpb	$0x0, 0x140fa(%rip)     # 0x738b0 <g.4>
   5f7b6:      	je	0x6e9c5 <f.2+0x17805>
   5f7bc:      	cmpq	$0x0, 0x140e4(%rip)     # 0x738a8 <g.3>
   5f7c4:      	leaq	-0xe(%r14), %rcx
   5f7c8:      	je	0x6e9c5 <f.2+0x17805>
   5f7ce:      	movq	%rax, %r13
   5f7d1:      	addq	0x18(%rsp), %r13
   5f7d6:      	cmpq	$0xf, %r14
   5f7da:      	ja	0x5f7f7 <f.2+0x8637>
   5f7dc:      	leaq	0x28(%rsp), %r8
   5f7e1:      	leaq	0x20(%rsp), %rdi
   5f7e6:      	leaq	0x13fdb(%rip), %r9      # 0x737c8 <native_roots.0>
   5f7ed:      	movq	0x10(%rsp), %rax
   5f7f2:      	jmp	0x5f892 <f.2+0x86d2>
   5f7f7:      	movq	$0x0, 0x50(%rsp)
   5f800:      	movq	$0x3, 0x38(%rsp)
   5f809:      	xorl	%edi, %edi
   5f80b:      	leaq	-0xf(%r14), %rsi
   5f80f:      	callq	0x6e9d0 <f.3>
   5f814:      	subq	$0x8, %rsp
   5f818:      	cmpb	$0x0, 0x14091(%rip)     # 0x738b0 <g.4>
   5f81f:      	je	0x6e9c5 <f.2+0x17805>
   5f825:      	movq	%rax, 0x18(%rsp)
   5f82a:      	cmpq	$0x0, 0x14076(%rip)     # 0x738a8 <g.3>
   5f832:      	je	0x6e9c5 <f.2+0x17805>
   5f838:      	leaq	-0x10(%r14), %rsi
   5f83c:      	movq	$0x0, 0x50(%rsp)
   5f845:      	movq	$0x3, 0x38(%rsp)
   5f84e:      	xorl	%edi, %edi
   5f850:      	callq	0x6e9d0 <f.3>
   5f855:      	subq	$0x8, %rsp
   5f859:      	cmpb	$0x0, 0x14050(%rip)     # 0x738b0 <g.4>
   5f860:      	je	0x6e9c5 <f.2+0x17805>
   5f866:      	movq	%rax, %rcx
   5f869:      	cmpq	$0x0, 0x14037(%rip)     # 0x738a8 <g.3>
   5f871:      	leaq	0x28(%rsp), %r8
   5f876:      	leaq	0x20(%rsp), %rdi
   5f87b:      	leaq	0x13f46(%rip), %r9      # 0x737c8 <native_roots.0>
   5f882:      	movq	0x10(%rsp), %rax
   5f887:      	je	0x6e9c5 <f.2+0x17805>
   5f88d:      	addq	0x18(%rsp), %rcx
   5f892:      	addq	%r13, %rcx
   5f895:      	cmpq	$0xe, %r14
   5f899:      	je	0x5f8ae <f.2+0x86ee>
   5f89b:      	cmpq	$0xf, %r14
   5f89f:      	jne	0x5f8c4 <f.2+0x8704>
   5f8a1:      	movl	$0x1, %edx
   5f8a6:      	xorl	%r13d, %r13d
   5f8a9:      	jmp	0x5fa06 <f.2+0x8846>
   5f8ae:      	leaq	(%r14,%rcx), %r13
   5f8b2:      	addq	$-0xd, %r13
   5f8b6:      	movl	$0x1, %edx
   5f8bb:      	leaq	-0xe(%r14), %rsi
   5f8bf:      	jmp	0x63e71 <f.2+0xccb1>
   5f8c4:      	movq	%rcx, 0x18(%rsp)
   5f8c9:      	leaq	-0xf(%r14), %r13
   5f8cd:      	movq	$0x0, 0x50(%rsp)
   5f8d6:      	movq	$0x3, 0x38(%rsp)
   5f8df:      	xorl	%edi, %edi
   5f8e1:      	movq	%r13, %rsi
   5f8e4:      	callq	0x6e9d0 <f.3>
   5f8e9:      	subq	$0x8, %rsp
   5f8ed:      	cmpb	$0x0, 0x13fbc(%rip)     # 0x738b0 <g.4>
   5f8f4:      	je	0x6e9c5 <f.2+0x17805>
   5f8fa:      	movq	%rax, 0x58(%rsp)
   5f8ff:      	cmpq	$0x0, 0x13fa1(%rip)     # 0x738a8 <g.3>
   5f907:      	je	0x6e9c5 <f.2+0x17805>
   5f90d:      	leaq	-0x10(%r14), %rsi
   5f911:      	movq	$0x0, 0x50(%rsp)
   5f91a:      	movq	$0x3, 0x38(%rsp)
   5f923:      	xorl	%edi, %edi
   5f925:      	callq	0x6e9d0 <f.3>
   5f92a:      	subq	$0x8, %rsp
   5f92e:      	cmpb	$0x0, 0x13f7b(%rip)     # 0x738b0 <g.4>
   5f935:      	je	0x6e9c5 <f.2+0x17805>
   5f93b:      	cmpq	$0x0, 0x13f65(%rip)     # 0x738a8 <g.3>
   5f943:      	leaq	0x20(%rsp), %rdi
   5f948:      	movq	0x18(%rsp), %rcx
   5f94d:      	je	0x6e9c5 <f.2+0x17805>
   5f953:      	movq	%rax, %rdx
   5f956:      	addq	0x58(%rsp), %rdx
   5f95b:      	cmpq	$0x11, %r14
   5f95f:      	jae	0x5f977 <f.2+0x87b7>
   5f961:      	leaq	0x28(%rsp), %r8
   5f966:      	leaq	0x13e5b(%rip), %r9      # 0x737c8 <native_roots.0>
   5f96d:      	movq	0x10(%rsp), %rax
   5f972:      	jmp	0x5fa06 <f.2+0x8846>
   5f977:      	movq	%rdx, 0x58(%rsp)
   5f97c:      	movq	$0x0, 0x50(%rsp)
   5f985:      	movq	$0x3, 0x38(%rsp)
   5f98e:      	xorl	%edi, %edi
   5f990:      	leaq	-0x10(%r14), %rsi
   5f994:      	callq	0x6e9d0 <f.3>
   5f999:      	subq	$0x8, %rsp
   5f99d:      	cmpb	$0x0, 0x13f0c(%rip)     # 0x738b0 <g.4>
   5f9a4:      	je	0x6e9c5 <f.2+0x17805>
   5f9aa:      	movq	%rax, 0x60(%rsp)
   5f9af:      	cmpq	$0x0, 0x13ef1(%rip)     # 0x738a8 <g.3>
   5f9b7:      	je	0x6e9c5 <f.2+0x17805>
   5f9bd:      	leaq	-0x11(%r14), %rsi
   5f9c1:      	movq	$0x0, 0x50(%rsp)
   5f9ca:      	movq	$0x3, 0x38(%rsp)
   5f9d3:      	xorl	%edi, %edi
   5f9d5:      	callq	0x6e9d0 <f.3>
   5f9da:      	subq	$0x8, %rsp
   5f9de:      	movq	%rax, %r13
   5f9e1:      	addq	0x60(%rsp), %r13
   5f9e6:      	leaq	0x28(%rsp), %r8
   5f9eb:      	leaq	0x20(%rsp), %rdi
   5f9f0:      	leaq	0x13dd1(%rip), %r9      # 0x737c8 <native_roots.0>
   5f9f7:      	movq	0x10(%rsp), %rax
   5f9fc:      	movq	0x18(%rsp), %rcx
   5fa01:      	movq	0x58(%rsp), %rdx
   5fa06:      	cmpb	$0x0, 0x13ea3(%rip)     # 0x738b0 <g.4>
   5fa0d:      	je	0x6e9c5 <f.2+0x17805>
   5fa13:      	cmpq	$0x0, 0x13e8d(%rip)     # 0x738a8 <g.3>
   5fa1b:      	je	0x6e9c5 <f.2+0x17805>
   5fa21:      	addq	%rdx, %r13
   5fa24:      	addq	%rcx, %r13
   5fa27:      	movq	%r14, %rdx
   5fa2a:      	subq	$0xf, %rdx
   5fa2e:      	jbe	0x5fae4 <f.2+0x8924>
   5fa34:      	movq	$0x0, 0x50(%rsp)
   5fa3d:      	movq	$0x3, 0x38(%rsp)
   5fa46:      	xorl	%edi, %edi
   5fa48:      	movq	%rdx, 0x18(%rsp)
   5fa4d:      	movq	%rdx, %rsi
   5fa50:      	callq	0x6e9d0 <f.3>
   5fa55:      	subq	$0x8, %rsp
   5fa59:      	cmpb	$0x0, 0x13e50(%rip)     # 0x738b0 <g.4>
   5fa60:      	je	0x6e9c5 <f.2+0x17805>
   5fa66:      	movq	%rax, 0x58(%rsp)
   5fa6b:      	cmpq	$0x0, 0x13e35(%rip)     # 0x738a8 <g.3>
   5fa73:      	je	0x6e9c5 <f.2+0x17805>
   5fa79:      	leaq	-0x10(%r14), %rsi
   5fa7d:      	movq	$0x0, 0x50(%rsp)
   5fa86:      	movq	$0x3, 0x38(%rsp)
   5fa8f:      	xorl	%edi, %edi
   5fa91:      	callq	0x6e9d0 <f.3>
   5fa96:      	subq	$0x8, %rsp
   5fa9a:      	cmpb	$0x0, 0x13e0f(%rip)     # 0x738b0 <g.4>
   5faa1:      	je	0x6e9c5 <f.2+0x17805>
   5faa7:      	cmpq	$0x0, 0x13df9(%rip)     # 0x738a8 <g.3>
   5faaf:      	leaq	0x28(%rsp), %r8
   5fab4:      	leaq	0x13d0d(%rip), %r9      # 0x737c8 <native_roots.0>
   5fabb:      	movq	0x18(%rsp), %rdx
   5fac0:      	je	0x6e9c5 <f.2+0x17805>
   5fac6:      	addq	0x58(%rsp), %rax
   5facb:      	cmpq	$0x10, %r14
   5facf:      	leaq	-0x10(%r14), %rsi
   5fad3:      	jne	0x5faf0 <f.2+0x8930>
   5fad5:      	addq	%rax, %rdx
   5fad8:      	movl	$0x1, %esi
   5fadd:      	xorl	%ecx, %ecx
   5fadf:      	jmp	0x5fc21 <f.2+0x8a61>
   5fae4:      	incq	%rdx
   5fae7:      	leaq	-0xe(%r14), %rsi
   5faeb:      	jmp	0x63e71 <f.2+0xccb1>
   5faf0:      	movq	%rax, 0x58(%rsp)
   5faf5:      	movq	$0x0, 0x50(%rsp)
   5fafe:      	movq	$0x3, 0x38(%rsp)
   5fb07:      	xorl	%edi, %edi
   5fb09:      	callq	0x6e9d0 <f.3>
   5fb0e:      	subq	$0x8, %rsp
   5fb12:      	cmpb	$0x0, 0x13d97(%rip)     # 0x738b0 <g.4>
   5fb19:      	je	0x6e9c5 <f.2+0x17805>
   5fb1f:      	movq	%rax, 0x60(%rsp)
   5fb24:      	cmpq	$0x0, 0x13d7c(%rip)     # 0x738a8 <g.3>
   5fb2c:      	je	0x6e9c5 <f.2+0x17805>
   5fb32:      	leaq	-0x11(%r14), %rsi
   5fb36:      	movq	$0x0, 0x50(%rsp)
   5fb3f:      	movq	$0x3, 0x38(%rsp)
   5fb48:      	xorl	%edi, %edi
   5fb4a:      	callq	0x6e9d0 <f.3>
   5fb4f:      	subq	$0x8, %rsp
   5fb53:      	cmpb	$0x0, 0x13d56(%rip)     # 0x738b0 <g.4>
   5fb5a:      	je	0x6e9c5 <f.2+0x17805>
   5fb60:      	movq	%rax, 0x18(%rsp)
   5fb65:      	cmpq	$0x0, 0x13d3b(%rip)     # 0x738a8 <g.3>
   5fb6d:      	leaq	-0x10(%r14), %rsi
   5fb71:      	je	0x6e9c5 <f.2+0x17805>
   5fb77:      	movq	$0x0, 0x50(%rsp)
   5fb80:      	movq	$0x3, 0x38(%rsp)
   5fb89:      	xorl	%edi, %edi
   5fb8b:      	callq	0x6e9d0 <f.3>
   5fb90:      	subq	$0x8, %rsp
   5fb94:      	cmpb	$0x0, 0x13d15(%rip)     # 0x738b0 <g.4>
   5fb9b:      	je	0x6e9c5 <f.2+0x17805>
   5fba1:      	movq	%rax, 0x68(%rsp)
   5fba6:      	cmpq	$0x0, 0x13cfa(%rip)     # 0x738a8 <g.3>
   5fbae:      	je	0x6e9c5 <f.2+0x17805>
   5fbb4:      	movq	$0x0, 0x50(%rsp)
   5fbbd:      	movq	$0x3, 0x38(%rsp)
   5fbc6:      	xorl	%edi, %edi
   5fbc8:      	leaq	-0x11(%r14), %rsi
   5fbcc:      	callq	0x6e9d0 <f.3>
   5fbd1:      	subq	$0x8, %rsp
   5fbd5:      	cmpb	$0x0, 0x13cd4(%rip)     # 0x738b0 <g.4>
   5fbdc:      	je	0x6e9c5 <f.2+0x17805>
   5fbe2:      	cmpq	$0x0, 0x13cbe(%rip)     # 0x738a8 <g.3>
   5fbea:      	leaq	0x28(%rsp), %r8
   5fbef:      	leaq	0x13bd2(%rip), %r9      # 0x737c8 <native_roots.0>
   5fbf6:      	movq	0x18(%rsp), %rdx
   5fbfb:      	leaq	-0x10(%r14), %rcx
   5fbff:      	je	0x6e9c5 <f.2+0x17805>
   5fc05:      	movq	%rax, %rsi
   5fc08:      	addq	0x60(%rsp), %rdx
   5fc0d:      	addq	0x58(%rsp), %rdx
   5fc12:      	addq	0x68(%rsp), %rsi
   5fc17:      	cmpq	$0x12, %r14
   5fc1b:      	jae	0x63dda <f.2+0xcc1a>
   5fc21:      	leaq	0x20(%rsp), %rdi
   5fc26:      	movq	0x10(%rsp), %rax
   5fc2b:      	jmp	0x63e6e <f.2+0xccae>
   5fc30:      	movq	%rdx, 0x18(%rsp)
   5fc35:      	movq	%rsi, 0x10(%rsp)
   5fc3a:      	movq	$0x0, 0x50(%rsp)
   5fc43:      	movq	$0x3, 0x38(%rsp)
   5fc4c:      	xorl	%edi, %edi
   5fc4e:      	leaq	-0x10(%r14), %rsi
   5fc52:      	callq	0x6e9d0 <f.3>
   5fc57:      	subq	$0x8, %rsp
   5fc5b:      	cmpb	$0x0, 0x13c4e(%rip)     # 0x738b0 <g.4>
   5fc62:      	je	0x6e9c5 <f.2+0x17805>
   5fc68:      	movq	%rax, 0x58(%rsp)
   5fc6d:      	cmpq	$0x0, 0x13c33(%rip)     # 0x738a8 <g.3>
   5fc75:      	je	0x6e9c5 <f.2+0x17805>
   5fc7b:      	leaq	-0x11(%r14), %rsi
   5fc7f:      	movq	$0x0, 0x50(%rsp)
   5fc88:      	movq	$0x3, 0x38(%rsp)
   5fc91:      	xorl	%edi, %edi
   5fc93:      	callq	0x6e9d0 <f.3>
   5fc98:      	subq	$0x8, %rsp
   5fc9c:      	addq	0x58(%rsp), %rax
   5fca1:      	leaq	0x28(%rsp), %r8
   5fca6:      	leaq	0x20(%rsp), %rdi
   5fcab:      	leaq	0x13b16(%rip), %r9      # 0x737c8 <native_roots.0>
   5fcb2:      	movq	0x10(%rsp), %rsi
   5fcb7:      	movq	0x18(%rsp), %rdx
   5fcbc:      	addq	%rax, %rdx
   5fcbf:      	addq	%rdx, %rsi
   5fcc2:      	addq	%rsi, %rbp
   5fcc5:      	addq	%rbp, %r15
   5fcc8:      	cmpb	$0x0, 0x13be1(%rip)     # 0x738b0 <g.4>
   5fccf:      	je	0x6e9c5 <f.2+0x17805>
   5fcd5:      	cmpq	$0x0, 0x13bcb(%rip)     # 0x738a8 <g.3>
   5fcdd:      	je	0x6e9c5 <f.2+0x17805>
   5fce3:      	addq	%r13, %r15
   5fce6:      	addq	%r12, %r15
   5fce9:      	cmpq	$0x7, %r14
   5fced:      	jbe	0x5fdc2 <f.2+0x8c02>
   5fcf3:      	movl	$0x1, %eax
   5fcf8:      	cmpq	$0x8, %r14
   5fcfc:      	je	0x5fdd3 <f.2+0x8c13>
   5fd02:      	cmpq	$0x9, %r14
   5fd06:      	jbe	0x5fdcf <f.2+0x8c0f>
   5fd0c:      	movl	$0x1, %r13d
   5fd12:      	cmpq	$0xa, %r14
   5fd16:      	je	0x5fee3 <f.2+0x8d23>
   5fd1c:      	movq	%r14, %r13
   5fd1f:      	subq	$0xb, %r13
   5fd23:      	jbe	0x5fee0 <f.2+0x8d20>
   5fd29:      	movq	$0x0, 0x50(%rsp)
   5fd32:      	movq	$0x3, 0x38(%rsp)
   5fd3b:      	xorl	%edi, %edi
   5fd3d:      	movq	%r13, %rsi
   5fd40:      	callq	0x6e9d0 <f.3>
   5fd45:      	subq	$0x8, %rsp
   5fd49:      	cmpb	$0x0, 0x13b60(%rip)     # 0x738b0 <g.4>
   5fd50:      	je	0x6e9c5 <f.2+0x17805>
   5fd56:      	cmpq	$0x0, 0x13b4a(%rip)     # 0x738a8 <g.3>
   5fd5e:      	je	0x6e9c5 <f.2+0x17805>
   5fd64:      	movq	%rax, %r12
   5fd67:      	leaq	-0xc(%r14), %rbp
   5fd6b:      	movq	$0x0, 0x50(%rsp)
   5fd74:      	movq	$0x3, 0x38(%rsp)
   5fd7d:      	xorl	%edi, %edi
   5fd7f:      	movq	%rbp, %rsi
   5fd82:      	callq	0x6e9d0 <f.3>
   5fd87:      	subq	$0x8, %rsp
   5fd8b:      	cmpb	$0x0, 0x13b1e(%rip)     # 0x738b0 <g.4>
   5fd92:      	je	0x6e9c5 <f.2+0x17805>
   5fd98:      	cmpq	$0x0, 0x13b08(%rip)     # 0x738a8 <g.3>
   5fda0:      	je	0x6e9c5 <f.2+0x17805>
   5fda6:      	addq	%r12, %rax
   5fda9:      	cmpq	$0xc, %r14
   5fdad:      	jne	0x5ff29 <f.2+0x8d69>
   5fdb3:      	addq	%rax, %r13
   5fdb6:      	movl	$0x1, %ebp
   5fdbb:      	xorl	%eax, %eax
   5fdbd:      	jmp	0x6099b <f.2+0x97db>
   5fdc2:      	leaq	-0x6(%r14), %r13
   5fdc6:      	leaq	-0x6(%r14), %r12
   5fdca:      	jmp	0x66ca4 <f.2+0xfae4>
   5fdcf:      	leaq	-0x8(%r14), %rax
   5fdd3:      	leaq	(%r14,%rax), %r12
   5fdd7:      	addq	$-0x8, %r12
   5fddb:      	cmpq	$0x8, %r14
   5fddf:      	je	0x60d10 <f.2+0x9b50>
   5fde5:      	movl	$0x1, %ebp
   5fdea:      	cmpq	$0x9, %r14
   5fdee:      	je	0x5feca <f.2+0x8d0a>
   5fdf4:      	cmpq	$0xa, %r14
   5fdf8:      	jbe	0x5fec6 <f.2+0x8d06>
   5fdfe:      	movl	$0x1, %r13d
   5fe04:      	cmpq	$0xb, %r14
   5fe08:      	je	0x5ff1c <f.2+0x8d5c>
   5fe0e:      	movq	%r14, %r13
   5fe11:      	subq	$0xc, %r13
   5fe15:      	jbe	0x5ff19 <f.2+0x8d59>
   5fe1b:      	movq	$0x0, 0x50(%rsp)
   5fe24:      	movq	$0x3, 0x38(%rsp)
   5fe2d:      	xorl	%edi, %edi
   5fe2f:      	movq	%r13, %rsi
   5fe32:      	callq	0x6e9d0 <f.3>
   5fe37:      	subq	$0x8, %rsp
   5fe3b:      	cmpb	$0x0, 0x13a6e(%rip)     # 0x738b0 <g.4>
   5fe42:      	je	0x6e9c5 <f.2+0x17805>
   5fe48:      	cmpq	$0x0, 0x13a58(%rip)     # 0x738a8 <g.3>
   5fe50:      	je	0x6e9c5 <f.2+0x17805>
   5fe56:      	movq	%rax, %rbp
   5fe59:      	leaq	-0xd(%r14), %rsi
   5fe5d:      	movq	$0x0, 0x50(%rsp)
   5fe66:      	movq	$0x3, 0x38(%rsp)
   5fe6f:      	xorl	%edi, %edi
   5fe71:      	callq	0x6e9d0 <f.3>
   5fe76:      	subq	$0x8, %rsp
   5fe7a:      	cmpb	$0x0, 0x13a2f(%rip)     # 0x738b0 <g.4>
   5fe81:      	je	0x6e9c5 <f.2+0x17805>
   5fe87:      	cmpq	$0x0, 0x13a19(%rip)     # 0x738a8 <g.3>
   5fe8f:      	leaq	0x28(%rsp), %r8
   5fe94:      	leaq	0x20(%rsp), %rdi
   5fe99:      	leaq	0x13928(%rip), %r9      # 0x737c8 <native_roots.0>
   5fea0:      	je	0x6e9c5 <f.2+0x17805>
   5fea6:      	addq	%rbp, %rax
   5fea9:      	cmpq	$0xd, %r14
   5fead:      	leaq	-0xd(%r14), %rsi
   5feb1:      	jne	0x60664 <f.2+0x94a4>
   5feb7:      	addq	%rax, %r13
   5feba:      	movl	$0x1, %ecx
   5febf:      	xorl	%eax, %eax
   5fec1:      	jmp	0x60809 <f.2+0x9649>
   5fec6:      	leaq	-0x9(%r14), %rbp
   5feca:      	leaq	-0x9(%r14), %r13
   5fece:      	cmpb	$0x0, 0x139db(%rip)     # 0x738b0 <g.4>
   5fed5:      	jne	0x61361 <f.2+0xa1a1>
   5fedb:      	jmp	0x6e9c5 <f.2+0x17805>
   5fee0:      	incq	%r13
   5fee3:      	leaq	(%r14,%r13), %r12
   5fee7:      	addq	$-0xa, %r12
   5feeb:      	cmpq	$0xa, %r14
   5feef:      	je	0x609cd <f.2+0x980d>
   5fef5:      	movl	$0x1, %ebp
   5fefa:      	cmpq	$0xb, %r14
   5fefe:      	je	0x5ff10 <f.2+0x8d50>
   5ff00:      	movq	%r14, %rbp
   5ff03:      	subq	$0xc, %rbp
   5ff07:      	ja	0x60050 <f.2+0x8e90>
   5ff0d:      	incq	%rbp
   5ff10:      	leaq	-0xb(%r14), %r13
   5ff14:      	jmp	0x602c4 <f.2+0x9104>
   5ff19:      	incq	%r13
   5ff1c:      	leaq	(%r14,%r13), %rax
   5ff20:      	addq	$-0xb, %rax
   5ff24:      	jmp	0x6082a <f.2+0x966a>
   5ff29:      	movq	%rax, 0x10(%rsp)
   5ff2e:      	movq	$0x0, 0x50(%rsp)
   5ff37:      	movq	$0x3, 0x38(%rsp)
   5ff40:      	xorl	%edi, %edi
   5ff42:      	movq	%rbp, %rsi
   5ff45:      	callq	0x6e9d0 <f.3>
   5ff4a:      	subq	$0x8, %rsp
   5ff4e:      	cmpb	$0x0, 0x1395b(%rip)     # 0x738b0 <g.4>
   5ff55:      	je	0x6e9c5 <f.2+0x17805>
   5ff5b:      	movq	%rax, 0x18(%rsp)
   5ff60:      	cmpq	$0x0, 0x13940(%rip)     # 0x738a8 <g.3>
   5ff68:      	je	0x6e9c5 <f.2+0x17805>
   5ff6e:      	leaq	-0xd(%r14), %r12
   5ff72:      	movq	$0x0, 0x50(%rsp)
   5ff7b:      	movq	$0x3, 0x38(%rsp)
   5ff84:      	xorl	%edi, %edi
   5ff86:      	movq	%r12, %rsi
   5ff89:      	callq	0x6e9d0 <f.3>
   5ff8e:      	subq	$0x8, %rsp
   5ff92:      	cmpb	$0x0, 0x13917(%rip)     # 0x738b0 <g.4>
   5ff99:      	je	0x6e9c5 <f.2+0x17805>
   5ff9f:      	cmpq	$0x0, 0x13901(%rip)     # 0x738a8 <g.3>
   5ffa7:      	je	0x6e9c5 <f.2+0x17805>
   5ffad:      	movq	%rax, %r13
   5ffb0:      	movq	$0x0, 0x50(%rsp)
   5ffb9:      	movq	$0x3, 0x38(%rsp)
   5ffc2:      	xorl	%edi, %edi
   5ffc4:      	movq	%rbp, %rsi
   5ffc7:      	callq	0x6e9d0 <f.3>
   5ffcc:      	subq	$0x8, %rsp
   5ffd0:      	cmpb	$0x0, 0x138d9(%rip)     # 0x738b0 <g.4>
   5ffd7:      	je	0x6e9c5 <f.2+0x17805>
   5ffdd:      	movq	%rax, 0x58(%rsp)
   5ffe2:      	cmpq	$0x0, 0x138be(%rip)     # 0x738a8 <g.3>
   5ffea:      	je	0x6e9c5 <f.2+0x17805>
   5fff0:      	movq	$0x0, 0x50(%rsp)
   5fff9:      	movq	$0x3, 0x38(%rsp)
   60002:      	xorl	%edi, %edi
   60004:      	movq	%r12, %rsi
   60007:      	callq	0x6e9d0 <f.3>
   6000c:      	subq	$0x8, %rsp
   60010:      	cmpb	$0x0, 0x13899(%rip)     # 0x738b0 <g.4>
   60017:      	je	0x6e9c5 <f.2+0x17805>
   6001d:      	movq	%rax, %r12
   60020:      	cmpq	$0x0, 0x13880(%rip)     # 0x738a8 <g.3>
   60028:      	movq	0x10(%rsp), %rax
   6002d:      	je	0x6e9c5 <f.2+0x17805>
   60033:      	addq	0x18(%rsp), %r13
   60038:      	addq	%rax, %r13
   6003b:      	addq	0x58(%rsp), %r12
   60040:      	cmpq	$0xd, %r14
   60044:      	ja	0x60928 <f.2+0x9768>
   6004a:      	addq	%rbp, %r12
   6004d:      	addq	%r13, %r12
   60050:      	movq	$0x0, 0x50(%rsp)
   60059:      	movq	$0x3, 0x38(%rsp)
   60062:      	xorl	%edi, %edi
   60064:      	movq	%rbp, %rsi
   60067:      	callq	0x6e9d0 <f.3>
   6006c:      	subq	$0x8, %rsp
   60070:      	cmpb	$0x0, 0x13839(%rip)     # 0x738b0 <g.4>
   60077:      	je	0x6e9c5 <f.2+0x17805>
   6007d:      	movq	%r12, 0x18(%rsp)
   60082:      	cmpq	$0x0, 0x1381e(%rip)     # 0x738a8 <g.3>
   6008a:      	je	0x6e9c5 <f.2+0x17805>
   60090:      	movq	%rax, %r13
   60093:      	leaq	-0xd(%r14), %rsi
   60097:      	movq	$0x0, 0x50(%rsp)
   600a0:      	movq	$0x3, 0x38(%rsp)
   600a9:      	xorl	%edi, %edi
   600ab:      	movq	%rsi, 0x10(%rsp)
   600b0:      	callq	0x6e9d0 <f.3>
   600b5:      	subq	$0x8, %rsp
   600b9:      	cmpb	$0x0, 0x137f0(%rip)     # 0x738b0 <g.4>
   600c0:      	je	0x6e9c5 <f.2+0x17805>
   600c6:      	cmpq	$0x0, 0x137da(%rip)     # 0x738a8 <g.3>
   600ce:      	leaq	0x28(%rsp), %r8
   600d3:      	leaq	0x136ee(%rip), %r9      # 0x737c8 <native_roots.0>
   600da:      	je	0x6e9c5 <f.2+0x17805>
   600e0:      	movq	%rax, %r12
   600e3:      	addq	%r13, %r12
   600e6:      	cmpq	$0xd, %r14
   600ea:      	jne	0x60108 <f.2+0x8f48>
   600ec:      	addq	%r12, %rbp
   600ef:      	movl	$0x1, %r13d
   600f5:      	movq	$0x0, 0x10(%rsp)
   600fe:      	leaq	0x20(%rsp), %rdi
   60103:      	jmp	0x602a7 <f.2+0x90e7>
   60108:      	movq	$0x0, 0x50(%rsp)
   60111:      	movq	$0x3, 0x38(%rsp)
   6011a:      	xorl	%edi, %edi
   6011c:      	leaq	-0xd(%r14), %r13
   60120:      	movq	%r13, %rsi
   60123:      	callq	0x6e9d0 <f.3>
   60128:      	subq	$0x8, %rsp
   6012c:      	cmpb	$0x0, 0x1377d(%rip)     # 0x738b0 <g.4>
   60133:      	je	0x6e9c5 <f.2+0x17805>
   60139:      	movq	%rax, 0x58(%rsp)
   6013e:      	cmpq	$0x0, 0x13762(%rip)     # 0x738a8 <g.3>
   60146:      	je	0x6e9c5 <f.2+0x17805>
   6014c:      	leaq	-0xe(%r14), %rsi
   60150:      	movq	$0x0, 0x50(%rsp)
   60159:      	movq	$0x3, 0x38(%rsp)
   60162:      	xorl	%edi, %edi
   60164:      	callq	0x6e9d0 <f.3>
   60169:      	subq	$0x8, %rsp
   6016d:      	cmpb	$0x0, 0x1373c(%rip)     # 0x738b0 <g.4>
   60174:      	je	0x6e9c5 <f.2+0x17805>
   6017a:      	cmpq	$0x0, 0x13726(%rip)     # 0x738a8 <g.3>
   60182:      	je	0x6e9c5 <f.2+0x17805>
   60188:      	movq	%rax, %rbp
   6018b:      	movq	$0x0, 0x50(%rsp)
   60194:      	movq	$0x3, 0x38(%rsp)
   6019d:      	xorl	%edi, %edi
   6019f:      	movq	%r13, %rsi
   601a2:      	callq	0x6e9d0 <f.3>
   601a7:      	subq	$0x8, %rsp
   601ab:      	cmpb	$0x0, 0x136fe(%rip)     # 0x738b0 <g.4>
   601b2:      	je	0x6e9c5 <f.2+0x17805>
   601b8:      	movq	%rax, 0x60(%rsp)
   601bd:      	cmpq	$0x0, 0x136e3(%rip)     # 0x738a8 <g.3>
   601c5:      	je	0x6e9c5 <f.2+0x17805>
   601cb:      	movq	$0x0, 0x50(%rsp)
   601d4:      	movq	$0x3, 0x38(%rsp)
   601dd:      	xorl	%edi, %edi
   601df:      	leaq	-0xe(%r14), %rsi
   601e3:      	callq	0x6e9d0 <f.3>
   601e8:      	subq	$0x8, %rsp
   601ec:      	cmpb	$0x0, 0x136bd(%rip)     # 0x738b0 <g.4>
   601f3:      	je	0x6e9c5 <f.2+0x17805>
   601f9:      	cmpq	$0x0, 0x136a7(%rip)     # 0x738a8 <g.3>
   60201:      	leaq	0x28(%rsp), %r8
   60206:      	leaq	0x20(%rsp), %rdi
   6020b:      	leaq	0x135b6(%rip), %r9      # 0x737c8 <native_roots.0>
   60212:      	je	0x6e9c5 <f.2+0x17805>
   60218:      	movq	%rax, %r13
   6021b:      	addq	0x58(%rsp), %rbp
   60220:      	addq	%r12, %rbp
   60223:      	addq	0x60(%rsp), %r13
   60228:      	cmpq	$0xf, %r14
   6022c:      	jb	0x602a7 <f.2+0x90e7>
   6022e:      	movq	$0x0, 0x50(%rsp)
   60237:      	movq	$0x3, 0x38(%rsp)
   60240:      	xorl	%edi, %edi
   60242:      	leaq	-0xe(%r14), %rsi
   60246:      	callq	0x6e9d0 <f.3>
   6024b:      	subq	$0x8, %rsp
   6024f:      	cmpb	$0x0, 0x1365a(%rip)     # 0x738b0 <g.4>
   60256:      	je	0x6e9c5 <f.2+0x17805>
   6025c:      	cmpq	$0x0, 0x13644(%rip)     # 0x738a8 <g.3>
   60264:      	je	0x6e9c5 <f.2+0x17805>
   6026a:      	movq	%rax, %r12
   6026d:      	leaq	-0xf(%r14), %rsi
   60271:      	movq	$0x0, 0x50(%rsp)
   6027a:      	movq	$0x3, 0x38(%rsp)
   60283:      	xorl	%edi, %edi
   60285:      	callq	0x6e9d0 <f.3>
   6028a:      	subq	$0x8, %rsp
   6028e:      	addq	%r12, %rax
   60291:      	movq	%rax, 0x10(%rsp)
   60296:      	leaq	0x28(%rsp), %r8
   6029b:      	leaq	0x20(%rsp), %rdi
   602a0:      	leaq	0x13521(%rip), %r9      # 0x737c8 <native_roots.0>
   602a7:      	cmpb	$0x0, 0x13602(%rip)     # 0x738b0 <g.4>
   602ae:      	movq	0x18(%rsp), %r12
   602b3:      	je	0x6e9c5 <f.2+0x17805>
   602b9:      	movq	0x10(%rsp), %rax
   602be:      	addq	%r13, %rax
   602c1:      	movq	%rax, %r13
   602c4:      	cmpq	$0x0, 0x135dc(%rip)     # 0x738a8 <g.3>
   602cc:      	je	0x6e9c5 <f.2+0x17805>
   602d2:      	addq	%rbp, %r13
   602d5:      	addq	%r12, %r13
   602d8:      	cmpq	$0xb, %r14
   602dc:      	jbe	0x602f7 <f.2+0x9137>
   602de:      	cmpq	$0xc, %r14
   602e2:      	movq	%r13, 0x10(%rsp)
   602e7:      	jne	0x60304 <f.2+0x9144>
   602e9:      	movl	$0x1, %r13d
   602ef:      	xorl	%r12d, %r12d
   602f2:      	jmp	0x60435 <f.2+0x9275>
   602f7:      	leaq	-0xa(%r14), %rbp
   602fb:      	leaq	-0xa(%r14), %r12
   602ff:      	jmp	0x60ce5 <f.2+0x9b25>
   60304:      	leaq	-0xc(%r14), %r12
   60308:      	movq	$0x0, 0x50(%rsp)
   60311:      	movq	$0x3, 0x38(%rsp)
   6031a:      	xorl	%edi, %edi
   6031c:      	movq	%r12, %rsi
   6031f:      	callq	0x6e9d0 <f.3>
   60324:      	subq	$0x8, %rsp
   60328:      	cmpb	$0x0, 0x13581(%rip)     # 0x738b0 <g.4>
   6032f:      	je	0x6e9c5 <f.2+0x17805>
   60335:      	cmpq	$0x0, 0x1356b(%rip)     # 0x738a8 <g.3>
   6033d:      	je	0x6e9c5 <f.2+0x17805>
   60343:      	movq	%rax, %rbp
   60346:      	leaq	-0xd(%r14), %rsi
   6034a:      	movq	$0x0, 0x50(%rsp)
   60353:      	movq	$0x3, 0x38(%rsp)
   6035c:      	xorl	%edi, %edi
   6035e:      	callq	0x6e9d0 <f.3>
   60363:      	subq	$0x8, %rsp
   60367:      	cmpb	$0x0, 0x13542(%rip)     # 0x738b0 <g.4>
   6036e:      	je	0x6e9c5 <f.2+0x17805>
   60374:      	cmpq	$0x0, 0x1352c(%rip)     # 0x738a8 <g.3>
   6037c:      	leaq	0x28(%rsp), %r8
   60381:      	leaq	0x20(%rsp), %rdi
   60386:      	leaq	0x1343b(%rip), %r9      # 0x737c8 <native_roots.0>
   6038d:      	je	0x6e9c5 <f.2+0x17805>
   60393:      	movq	%rax, %r13
   60396:      	addq	%rbp, %r13
   60399:      	cmpq	$0xd, %r14
   6039d:      	jbe	0x60435 <f.2+0x9275>
   603a3:      	movq	$0x0, 0x50(%rsp)
   603ac:      	movq	$0x3, 0x38(%rsp)
   603b5:      	xorl	%edi, %edi
   603b7:      	leaq	-0xd(%r14), %rsi
   603bb:      	callq	0x6e9d0 <f.3>
   603c0:      	subq	$0x8, %rsp
   603c4:      	cmpb	$0x0, 0x134e5(%rip)     # 0x738b0 <g.4>
   603cb:      	je	0x6e9c5 <f.2+0x17805>
   603d1:      	cmpq	$0x0, 0x134cf(%rip)     # 0x738a8 <g.3>
   603d9:      	je	0x6e9c5 <f.2+0x17805>
   603df:      	movq	%rax, %rbp
   603e2:      	leaq	-0xe(%r14), %rsi
   603e6:      	movq	$0x0, 0x50(%rsp)
   603ef:      	movq	$0x3, 0x38(%rsp)
   603f8:      	xorl	%edi, %edi
   603fa:      	callq	0x6e9d0 <f.3>
   603ff:      	subq	$0x8, %rsp
   60403:      	cmpb	$0x0, 0x134a6(%rip)     # 0x738b0 <g.4>
   6040a:      	je	0x6e9c5 <f.2+0x17805>
   60410:      	cmpq	$0x0, 0x13490(%rip)     # 0x738a8 <g.3>
   60418:      	leaq	0x28(%rsp), %r8
   6041d:      	leaq	0x20(%rsp), %rdi
   60422:      	leaq	0x1339f(%rip), %r9      # 0x737c8 <native_roots.0>
   60429:      	je	0x6e9c5 <f.2+0x17805>
   6042f:      	movq	%rax, %r12
   60432:      	addq	%rbp, %r12
   60435:      	addq	%r13, %r12
   60438:      	cmpq	$0xc, %r14
   6043c:      	je	0x60451 <f.2+0x9291>
   6043e:      	cmpq	$0xd, %r14
   60442:      	jne	0x60468 <f.2+0x92a8>
   60444:      	movl	$0x1, %r13d
   6044a:      	xorl	%ebp, %ebp
   6044c:      	jmp	0x60582 <f.2+0x93c2>
   60451:      	leaq	(%r14,%r12), %rbp
   60455:      	addq	$-0xb, %rbp
   60459:      	movl	$0x1, %r12d
   6045f:      	leaq	-0xc(%r14), %r13
   60463:      	jmp	0x60cdd <f.2+0x9b1d>
   60468:      	leaq	-0xd(%r14), %rbp
   6046c:      	movq	$0x0, 0x50(%rsp)
   60475:      	movq	$0x3, 0x38(%rsp)
   6047e:      	xorl	%edi, %edi
   60480:      	movq	%rbp, %rsi
   60483:      	callq	0x6e9d0 <f.3>
   60488:      	subq	$0x8, %rsp
   6048c:      	cmpb	$0x0, 0x1341d(%rip)     # 0x738b0 <g.4>
   60493:      	je	0x6e9c5 <f.2+0x17805>
   60499:      	movq	%rax, 0x18(%rsp)
   6049e:      	cmpq	$0x0, 0x13402(%rip)     # 0x738a8 <g.3>
   604a6:      	je	0x6e9c5 <f.2+0x17805>
   604ac:      	leaq	-0xe(%r14), %rsi
   604b0:      	movq	$0x0, 0x50(%rsp)
   604b9:      	movq	$0x3, 0x38(%rsp)
   604c2:      	xorl	%edi, %edi
   604c4:      	callq	0x6e9d0 <f.3>
   604c9:      	subq	$0x8, %rsp
   604cd:      	cmpb	$0x0, 0x133dc(%rip)     # 0x738b0 <g.4>
   604d4:      	je	0x6e9c5 <f.2+0x17805>
   604da:      	cmpq	$0x0, 0x133c6(%rip)     # 0x738a8 <g.3>
   604e2:      	leaq	0x28(%rsp), %r8
   604e7:      	leaq	0x20(%rsp), %rdi
   604ec:      	leaq	0x132d5(%rip), %r9      # 0x737c8 <native_roots.0>
   604f3:      	je	0x6e9c5 <f.2+0x17805>
   604f9:      	movq	%rax, %r13
   604fc:      	addq	0x18(%rsp), %r13
   60501:      	cmpq	$0xf, %r14
   60505:      	jb	0x60582 <f.2+0x93c2>
   60507:      	movq	$0x0, 0x50(%rsp)
   60510:      	movq	$0x3, 0x38(%rsp)
   60519:      	xorl	%edi, %edi
   6051b:      	leaq	-0xe(%r14), %rsi
   6051f:      	callq	0x6e9d0 <f.3>
   60524:      	subq	$0x8, %rsp
   60528:      	cmpb	$0x0, 0x13381(%rip)     # 0x738b0 <g.4>
   6052f:      	je	0x6e9c5 <f.2+0x17805>
   60535:      	movq	%rax, 0x18(%rsp)
   6053a:      	cmpq	$0x0, 0x13366(%rip)     # 0x738a8 <g.3>
   60542:      	je	0x6e9c5 <f.2+0x17805>
   60548:      	leaq	-0xf(%r14), %rsi
   6054c:      	movq	$0x0, 0x50(%rsp)
   60555:      	movq	$0x3, 0x38(%rsp)
   6055e:      	xorl	%edi, %edi
   60560:      	callq	0x6e9d0 <f.3>
   60565:      	subq	$0x8, %rsp
   60569:      	movq	%rax, %rbp
   6056c:      	addq	0x18(%rsp), %rbp
   60571:      	leaq	0x28(%rsp), %r8
   60576:      	leaq	0x20(%rsp), %rdi
   6057b:      	leaq	0x13246(%rip), %r9      # 0x737c8 <native_roots.0>
   60582:      	cmpb	$0x0, 0x13327(%rip)     # 0x738b0 <g.4>
   60589:      	je	0x6e9c5 <f.2+0x17805>
   6058f:      	cmpq	$0x0, 0x13311(%rip)     # 0x738a8 <g.3>
   60597:      	je	0x6e9c5 <f.2+0x17805>
   6059d:      	addq	%r13, %rbp
   605a0:      	addq	%r12, %rbp
   605a3:      	movq	%r14, %r12
   605a6:      	subq	$0xd, %r12
   605aa:      	jbe	0x60658 <f.2+0x9498>
   605b0:      	movq	$0x0, 0x50(%rsp)
   605b9:      	movq	$0x3, 0x38(%rsp)
   605c2:      	xorl	%edi, %edi
   605c4:      	movq	%r12, %rsi
   605c7:      	callq	0x6e9d0 <f.3>
   605cc:      	subq	$0x8, %rsp
   605d0:      	cmpb	$0x0, 0x132d9(%rip)     # 0x738b0 <g.4>
   605d7:      	je	0x6e9c5 <f.2+0x17805>
   605dd:      	cmpq	$0x0, 0x132c3(%rip)     # 0x738a8 <g.3>
   605e5:      	je	0x6e9c5 <f.2+0x17805>
   605eb:      	movq	%rax, %r13
   605ee:      	leaq	-0xe(%r14), %rsi
   605f2:      	movq	$0x0, 0x50(%rsp)
   605fb:      	movq	$0x3, 0x38(%rsp)
   60604:      	xorl	%edi, %edi
   60606:      	callq	0x6e9d0 <f.3>
   6060b:      	subq	$0x8, %rsp
   6060f:      	cmpb	$0x0, 0x1329a(%rip)     # 0x738b0 <g.4>
   60616:      	je	0x6e9c5 <f.2+0x17805>
   6061c:      	cmpq	$0x0, 0x13284(%rip)     # 0x738a8 <g.3>
   60624:      	leaq	0x28(%rsp), %r8
   60629:      	leaq	0x13198(%rip), %r9      # 0x737c8 <native_roots.0>
   60630:      	je	0x6e9c5 <f.2+0x17805>
   60636:      	addq	%r13, %rax
   60639:      	cmpq	$0xe, %r14
   6063d:      	jne	0x609e3 <f.2+0x9823>
   60643:      	addq	%rax, %r12
   60646:      	movl	$0x1, %r13d
   6064c:      	xorl	%eax, %eax
   6064e:      	leaq	0x20(%rsp), %rdi
   60653:      	jmp	0x60cda <f.2+0x9b1a>
   60658:      	incq	%r12
   6065b:      	leaq	-0xc(%r14), %r13
   6065f:      	jmp	0x60cdd <f.2+0x9b1d>
   60664:      	movq	%rax, 0x10(%rsp)
   60669:      	movq	$0x0, 0x50(%rsp)
   60672:      	movq	$0x3, 0x38(%rsp)
   6067b:      	xorl	%edi, %edi
   6067d:      	callq	0x6e9d0 <f.3>
   60682:      	subq	$0x8, %rsp
   60686:      	cmpb	$0x0, 0x13223(%rip)     # 0x738b0 <g.4>
   6068d:      	je	0x6e9c5 <f.2+0x17805>
   60693:      	movq	%rax, 0x18(%rsp)
   60698:      	cmpq	$0x0, 0x13208(%rip)     # 0x738a8 <g.3>
   606a0:      	je	0x6e9c5 <f.2+0x17805>
   606a6:      	leaq	-0xe(%r14), %rsi
   606aa:      	movq	$0x0, 0x50(%rsp)
   606b3:      	movq	$0x3, 0x38(%rsp)
   606bc:      	xorl	%edi, %edi
   606be:      	callq	0x6e9d0 <f.3>
   606c3:      	subq	$0x8, %rsp
   606c7:      	cmpb	$0x0, 0x131e2(%rip)     # 0x738b0 <g.4>
   606ce:      	je	0x6e9c5 <f.2+0x17805>
   606d4:      	cmpq	$0x0, 0x131cc(%rip)     # 0x738a8 <g.3>
   606dc:      	leaq	-0xd(%r14), %rsi
   606e0:      	je	0x6e9c5 <f.2+0x17805>
   606e6:      	movq	%rax, %r13
   606e9:      	movq	$0x0, 0x50(%rsp)
   606f2:      	movq	$0x3, 0x38(%rsp)
   606fb:      	xorl	%edi, %edi
   606fd:      	callq	0x6e9d0 <f.3>
   60702:      	subq	$0x8, %rsp
   60706:      	cmpb	$0x0, 0x131a3(%rip)     # 0x738b0 <g.4>
   6070d:      	je	0x6e9c5 <f.2+0x17805>
   60713:      	cmpq	$0x0, 0x1318d(%rip)     # 0x738a8 <g.3>
   6071b:      	je	0x6e9c5 <f.2+0x17805>
   60721:      	movq	%rax, %rbp
   60724:      	movq	$0x0, 0x50(%rsp)
   6072d:      	movq	$0x3, 0x38(%rsp)
   60736:      	xorl	%edi, %edi
   60738:      	leaq	-0xe(%r14), %rsi
   6073c:      	callq	0x6e9d0 <f.3>
   60741:      	subq	$0x8, %rsp
   60745:      	cmpb	$0x0, 0x13164(%rip)     # 0x738b0 <g.4>
   6074c:      	je	0x6e9c5 <f.2+0x17805>
   60752:      	movq	%rax, %rcx
   60755:      	cmpq	$0x0, 0x1314b(%rip)     # 0x738a8 <g.3>
   6075d:      	leaq	0x28(%rsp), %r8
   60762:      	leaq	0x20(%rsp), %rdi
   60767:      	leaq	0x1305a(%rip), %r9      # 0x737c8 <native_roots.0>
   6076e:      	leaq	-0xd(%r14), %rax
   60772:      	je	0x6e9c5 <f.2+0x17805>
   60778:      	addq	0x18(%rsp), %r13
   6077d:      	addq	0x10(%rsp), %r13
   60782:      	addq	%rbp, %rcx
   60785:      	cmpq	$0xf, %r14
   60789:      	jb	0x60809 <f.2+0x9649>
   6078b:      	movq	%rcx, 0x10(%rsp)
   60790:      	movq	$0x0, 0x50(%rsp)
   60799:      	movq	$0x3, 0x38(%rsp)
   607a2:      	xorl	%edi, %edi
   607a4:      	leaq	-0xe(%r14), %rsi
   607a8:      	callq	0x6e9d0 <f.3>
   607ad:      	subq	$0x8, %rsp
   607b1:      	cmpb	$0x0, 0x130f8(%rip)     # 0x738b0 <g.4>
   607b8:      	je	0x6e9c5 <f.2+0x17805>
   607be:      	cmpq	$0x0, 0x130e2(%rip)     # 0x738a8 <g.3>
   607c6:      	je	0x6e9c5 <f.2+0x17805>
   607cc:      	movq	%rax, %rbp
   607cf:      	leaq	-0xf(%r14), %rsi
   607d3:      	movq	$0x0, 0x50(%rsp)
   607dc:      	movq	$0x3, 0x38(%rsp)
   607e5:      	xorl	%edi, %edi
   607e7:      	callq	0x6e9d0 <f.3>
   607ec:      	subq	$0x8, %rsp
   607f0:      	addq	%rbp, %rax
   607f3:      	leaq	0x28(%rsp), %r8
   607f8:      	leaq	0x20(%rsp), %rdi
   607fd:      	leaq	0x12fc4(%rip), %r9      # 0x737c8 <native_roots.0>
   60804:      	movq	0x10(%rsp), %rcx
   60809:      	cmpb	$0x0, 0x130a0(%rip)     # 0x738b0 <g.4>
   60810:      	je	0x6e9c5 <f.2+0x17805>
   60816:      	cmpq	$0x0, 0x1308a(%rip)     # 0x738a8 <g.3>
   6081e:      	je	0x6e9c5 <f.2+0x17805>
   60824:      	addq	%rcx, %rax
   60827:      	addq	%r13, %rax
   6082a:      	cmpq	$0xb, %r14
   6082e:      	je	0x60905 <f.2+0x9745>
   60834:      	movl	$0x1, %r13d
   6083a:      	cmpq	$0xc, %r14
   6083e:      	je	0x6091f <f.2+0x975f>
   60844:      	movq	%r14, %r13
   60847:      	subq	$0xd, %r13
   6084b:      	jbe	0x6091c <f.2+0x975c>
   60851:      	movq	%rax, 0x10(%rsp)
   60856:      	movq	$0x0, 0x50(%rsp)
   6085f:      	movq	$0x3, 0x38(%rsp)
   60868:      	xorl	%edi, %edi
   6086a:      	movq	%r13, %rsi
   6086d:      	callq	0x6e9d0 <f.3>
   60872:      	subq	$0x8, %rsp
   60876:      	cmpb	$0x0, 0x13033(%rip)     # 0x738b0 <g.4>
   6087d:      	je	0x6e9c5 <f.2+0x17805>
   60883:      	cmpq	$0x0, 0x1301d(%rip)     # 0x738a8 <g.3>
   6088b:      	je	0x6e9c5 <f.2+0x17805>
   60891:      	movq	%rax, %rbp
   60894:      	leaq	-0xe(%r14), %rsi
   60898:      	movq	$0x0, 0x50(%rsp)
   608a1:      	movq	$0x3, 0x38(%rsp)
   608aa:      	xorl	%edi, %edi
   608ac:      	callq	0x6e9d0 <f.3>
   608b1:      	subq	$0x8, %rsp
   608b5:      	cmpb	$0x0, 0x12ff4(%rip)     # 0x738b0 <g.4>
   608bc:      	je	0x6e9c5 <f.2+0x17805>
   608c2:      	movq	%rax, %rcx
   608c5:      	cmpq	$0x0, 0x12fdb(%rip)     # 0x738a8 <g.3>
   608cd:      	leaq	0x28(%rsp), %r8
   608d2:      	leaq	0x12eef(%rip), %r9      # 0x737c8 <native_roots.0>
   608d9:      	movq	0x10(%rsp), %rax
   608de:      	je	0x6e9c5 <f.2+0x17805>
   608e4:      	addq	%rbp, %rcx
   608e7:      	cmpq	$0xe, %r14
   608eb:      	jne	0x60b20 <f.2+0x9960>
   608f1:      	addq	%rcx, %r13
   608f4:      	movl	$0x1, %ebp
   608f9:      	xorl	%ecx, %ecx
   608fb:      	leaq	0x20(%rsp), %rdi
   60900:      	jmp	0x60da7 <f.2+0x9be7>
   60905:      	leaq	(%r14,%rax), %rbp
   60909:      	addq	$-0xa, %rbp
   6090d:      	movl	$0x1, %r13d
   60913:      	leaq	-0xb(%r14), %rsi
   60917:      	jmp	0x61351 <f.2+0xa191>
   6091c:      	incq	%r13
   6091f:      	leaq	-0xc(%r14), %rbp
   60923:      	jmp	0x60daa <f.2+0x9bea>
   60928:      	movq	%r12, %rbp
   6092b:      	movq	$0x0, 0x50(%rsp)
   60934:      	movq	$0x3, 0x38(%rsp)
   6093d:      	xorl	%edi, %edi
   6093f:      	leaq	-0xd(%r14), %rsi
   60943:      	callq	0x6e9d0 <f.3>
   60948:      	subq	$0x8, %rsp
   6094c:      	cmpb	$0x0, 0x12f5d(%rip)     # 0x738b0 <g.4>
   60953:      	je	0x6e9c5 <f.2+0x17805>
   60959:      	cmpq	$0x0, 0x12f47(%rip)     # 0x738a8 <g.3>
   60961:      	je	0x6e9c5 <f.2+0x17805>
   60967:      	movq	%rax, %r12
   6096a:      	leaq	-0xe(%r14), %rsi
   6096e:      	movq	$0x0, 0x50(%rsp)
   60977:      	movq	$0x3, 0x38(%rsp)
   60980:      	xorl	%edi, %edi
   60982:      	callq	0x6e9d0 <f.3>
   60987:      	subq	$0x8, %rsp
   6098b:      	cmpb	$0x0, 0x12f1e(%rip)     # 0x738b0 <g.4>
   60992:      	je	0x6e9c5 <f.2+0x17805>
   60998:      	addq	%r12, %rax
   6099b:      	leaq	0x28(%rsp), %r8
   609a0:      	leaq	0x20(%rsp), %rdi
   609a5:      	leaq	0x12e1c(%rip), %r9      # 0x737c8 <native_roots.0>
   609ac:      	cmpq	$0x0, 0x12ef4(%rip)     # 0x738a8 <g.3>
   609b4:      	je	0x6e9c5 <f.2+0x17805>
   609ba:      	addq	%rbp, %rax
   609bd:      	addq	%r13, %rax
   609c0:      	movq	%rax, %r12
   609c3:      	cmpq	$0xa, %r14
   609c7:      	jne	0x5fef5 <f.2+0x8d35>
   609cd:      	leaq	(%r14,%r12), %r13
   609d1:      	addq	$-0x9, %r13
   609d5:      	movl	$0x1, %ebp
   609da:      	leaq	-0xa(%r14), %r12
   609de:      	jmp	0x60ce5 <f.2+0x9b25>
   609e3:      	movq	%rax, 0x18(%rsp)
   609e8:      	movq	$0x0, 0x50(%rsp)
   609f1:      	movq	$0x3, 0x38(%rsp)
   609fa:      	xorl	%edi, %edi
   609fc:      	leaq	-0xe(%r14), %r13
   60a00:      	movq	%r13, %rsi
   60a03:      	callq	0x6e9d0 <f.3>
   60a08:      	subq	$0x8, %rsp
   60a0c:      	cmpb	$0x0, 0x12e9d(%rip)     # 0x738b0 <g.4>
   60a13:      	je	0x6e9c5 <f.2+0x17805>
   60a19:      	movq	%rax, 0x58(%rsp)
   60a1e:      	cmpq	$0x0, 0x12e82(%rip)     # 0x738a8 <g.3>
   60a26:      	je	0x6e9c5 <f.2+0x17805>
   60a2c:      	leaq	-0xf(%r14), %rsi
   60a30:      	movq	$0x0, 0x50(%rsp)
   60a39:      	movq	$0x3, 0x38(%rsp)
   60a42:      	xorl	%edi, %edi
   60a44:      	callq	0x6e9d0 <f.3>
   60a49:      	subq	$0x8, %rsp
   60a4d:      	cmpb	$0x0, 0x12e5c(%rip)     # 0x738b0 <g.4>
   60a54:      	je	0x6e9c5 <f.2+0x17805>
   60a5a:      	cmpq	$0x0, 0x12e46(%rip)     # 0x738a8 <g.3>
   60a62:      	je	0x6e9c5 <f.2+0x17805>
   60a68:      	movq	%rax, %r12
   60a6b:      	movq	$0x0, 0x50(%rsp)
   60a74:      	movq	$0x3, 0x38(%rsp)
   60a7d:      	xorl	%edi, %edi
   60a7f:      	movq	%r13, %rsi
   60a82:      	callq	0x6e9d0 <f.3>
   60a87:      	subq	$0x8, %rsp
   60a8b:      	cmpb	$0x0, 0x12e1e(%rip)     # 0x738b0 <g.4>
   60a92:      	je	0x6e9c5 <f.2+0x17805>
   60a98:      	movq	%rax, 0x60(%rsp)
   60a9d:      	cmpq	$0x0, 0x12e03(%rip)     # 0x738a8 <g.3>
   60aa5:      	je	0x6e9c5 <f.2+0x17805>
   60aab:      	movq	$0x0, 0x50(%rsp)
   60ab4:      	movq	$0x3, 0x38(%rsp)
   60abd:      	xorl	%edi, %edi
   60abf:      	leaq	-0xf(%r14), %rsi
   60ac3:      	callq	0x6e9d0 <f.3>
   60ac8:      	subq	$0x8, %rsp
   60acc:      	cmpb	$0x0, 0x12ddd(%rip)     # 0x738b0 <g.4>
   60ad3:      	je	0x6e9c5 <f.2+0x17805>
   60ad9:      	movq	%rax, %r13
   60adc:      	cmpq	$0x0, 0x12dc4(%rip)     # 0x738a8 <g.3>
   60ae4:      	leaq	0x28(%rsp), %r8
   60ae9:      	leaq	0x12cd8(%rip), %r9      # 0x737c8 <native_roots.0>
   60af0:      	movq	0x18(%rsp), %rax
   60af5:      	je	0x6e9c5 <f.2+0x17805>
   60afb:      	addq	0x58(%rsp), %r12
   60b00:      	addq	%rax, %r12
   60b03:      	addq	0x60(%rsp), %r13
   60b08:      	cmpq	$0x10, %r14
   60b0c:      	jae	0x60c62 <f.2+0x9aa2>
   60b12:      	leaq	0x20(%rsp), %rdi
   60b17:      	leaq	-0xe(%r14), %rax
   60b1b:      	jmp	0x60cda <f.2+0x9b1a>
   60b20:      	movq	%rcx, 0x18(%rsp)
   60b25:      	movq	$0x0, 0x50(%rsp)
   60b2e:      	movq	$0x3, 0x38(%rsp)
   60b37:      	xorl	%edi, %edi
   60b39:      	leaq	-0xe(%r14), %rbp
   60b3d:      	movq	%rbp, %rsi
   60b40:      	callq	0x6e9d0 <f.3>
   60b45:      	subq	$0x8, %rsp
   60b49:      	cmpb	$0x0, 0x12d60(%rip)     # 0x738b0 <g.4>
   60b50:      	je	0x6e9c5 <f.2+0x17805>
   60b56:      	movq	%rax, 0x58(%rsp)
   60b5b:      	cmpq	$0x0, 0x12d45(%rip)     # 0x738a8 <g.3>
   60b63:      	je	0x6e9c5 <f.2+0x17805>
   60b69:      	leaq	-0xf(%r14), %rsi
   60b6d:      	movq	$0x0, 0x50(%rsp)
   60b76:      	movq	$0x3, 0x38(%rsp)
   60b7f:      	xorl	%edi, %edi
   60b81:      	callq	0x6e9d0 <f.3>
   60b86:      	subq	$0x8, %rsp
   60b8a:      	cmpb	$0x0, 0x12d1f(%rip)     # 0x738b0 <g.4>
   60b91:      	je	0x6e9c5 <f.2+0x17805>
   60b97:      	cmpq	$0x0, 0x12d09(%rip)     # 0x738a8 <g.3>
   60b9f:      	je	0x6e9c5 <f.2+0x17805>
   60ba5:      	movq	%rax, %r13
   60ba8:      	movq	$0x0, 0x50(%rsp)
   60bb1:      	movq	$0x3, 0x38(%rsp)
   60bba:      	xorl	%edi, %edi
   60bbc:      	movq	%rbp, %rsi
   60bbf:      	callq	0x6e9d0 <f.3>
   60bc4:      	subq	$0x8, %rsp
   60bc8:      	cmpb	$0x0, 0x12ce1(%rip)     # 0x738b0 <g.4>
   60bcf:      	je	0x6e9c5 <f.2+0x17805>
   60bd5:      	movq	%rax, 0x60(%rsp)
   60bda:      	cmpq	$0x0, 0x12cc6(%rip)     # 0x738a8 <g.3>
   60be2:      	je	0x6e9c5 <f.2+0x17805>
   60be8:      	movq	$0x0, 0x50(%rsp)
   60bf1:      	movq	$0x3, 0x38(%rsp)
   60bfa:      	xorl	%edi, %edi
   60bfc:      	leaq	-0xf(%r14), %rsi
   60c00:      	callq	0x6e9d0 <f.3>
   60c05:      	subq	$0x8, %rsp
   60c09:      	cmpb	$0x0, 0x12ca0(%rip)     # 0x738b0 <g.4>
   60c10:      	je	0x6e9c5 <f.2+0x17805>
   60c16:      	movq	%rax, %rbp
   60c19:      	cmpq	$0x0, 0x12c87(%rip)     # 0x738a8 <g.3>
   60c21:      	leaq	0x28(%rsp), %r8
   60c26:      	leaq	0x12b9b(%rip), %r9      # 0x737c8 <native_roots.0>
   60c2d:      	movq	0x10(%rsp), %rax
   60c32:      	movq	0x18(%rsp), %rcx
   60c37:      	je	0x6e9c5 <f.2+0x17805>
   60c3d:      	addq	0x58(%rsp), %r13
   60c42:      	addq	%rcx, %r13
   60c45:      	addq	0x60(%rsp), %rbp
   60c4a:      	cmpq	$0x10, %r14
   60c4e:      	jae	0x60d27 <f.2+0x9b67>
   60c54:      	leaq	0x20(%rsp), %rdi
   60c59:      	leaq	-0xe(%r14), %rcx
   60c5d:      	jmp	0x60da7 <f.2+0x9be7>
   60c62:      	movq	$0x0, 0x50(%rsp)
   60c6b:      	movq	$0x3, 0x38(%rsp)
   60c74:      	xorl	%edi, %edi
   60c76:      	leaq	-0xf(%r14), %rsi
   60c7a:      	callq	0x6e9d0 <f.3>
   60c7f:      	subq	$0x8, %rsp
   60c83:      	cmpb	$0x0, 0x12c26(%rip)     # 0x738b0 <g.4>
   60c8a:      	je	0x6e9c5 <f.2+0x17805>
   60c90:      	movq	%rax, 0x18(%rsp)
   60c95:      	cmpq	$0x0, 0x12c0b(%rip)     # 0x738a8 <g.3>
   60c9d:      	je	0x6e9c5 <f.2+0x17805>
   60ca3:      	leaq	-0x10(%r14), %rsi
   60ca7:      	movq	$0x0, 0x50(%rsp)
   60cb0:      	movq	$0x3, 0x38(%rsp)
   60cb9:      	xorl	%edi, %edi
   60cbb:      	callq	0x6e9d0 <f.3>
   60cc0:      	subq	$0x8, %rsp
   60cc4:      	addq	0x18(%rsp), %rax
   60cc9:      	leaq	0x28(%rsp), %r8
   60cce:      	leaq	0x20(%rsp), %rdi
   60cd3:      	leaq	0x12aee(%rip), %r9      # 0x737c8 <native_roots.0>
   60cda:      	addq	%rax, %r13
   60cdd:      	addq	%r13, %r12
   60ce0:      	movq	0x10(%rsp), %r13
   60ce5:      	cmpb	$0x0, 0x12bc4(%rip)     # 0x738b0 <g.4>
   60cec:      	je	0x6e9c5 <f.2+0x17805>
   60cf2:      	cmpq	$0x0, 0x12bae(%rip)     # 0x738a8 <g.3>
   60cfa:      	je	0x6e9c5 <f.2+0x17805>
   60d00:      	addq	%rbp, %r12
   60d03:      	addq	%r13, %r12
   60d06:      	cmpq	$0x8, %r14
   60d0a:      	jne	0x5fde5 <f.2+0x8c25>
   60d10:      	leaq	(%r14,%r12), %r13
   60d14:      	addq	$-0x7, %r13
   60d18:      	movl	$0x1, %r12d
   60d1e:      	leaq	-0x8(%r14), %rbp
   60d22:      	jmp	0x66ca1 <f.2+0xfae1>
   60d27:      	movq	$0x0, 0x50(%rsp)
   60d30:      	movq	$0x3, 0x38(%rsp)
   60d39:      	xorl	%edi, %edi
   60d3b:      	leaq	-0xf(%r14), %rsi
   60d3f:      	callq	0x6e9d0 <f.3>
   60d44:      	subq	$0x8, %rsp
   60d48:      	cmpb	$0x0, 0x12b61(%rip)     # 0x738b0 <g.4>
   60d4f:      	je	0x6e9c5 <f.2+0x17805>
   60d55:      	movq	%rax, 0x18(%rsp)
   60d5a:      	cmpq	$0x0, 0x12b46(%rip)     # 0x738a8 <g.3>
   60d62:      	je	0x6e9c5 <f.2+0x17805>
   60d68:      	leaq	-0x10(%r14), %rsi
   60d6c:      	movq	$0x0, 0x50(%rsp)
   60d75:      	movq	$0x3, 0x38(%rsp)
   60d7e:      	xorl	%edi, %edi
   60d80:      	callq	0x6e9d0 <f.3>
   60d85:      	subq	$0x8, %rsp
   60d89:      	movq	%rax, %rcx
   60d8c:      	addq	0x18(%rsp), %rcx
   60d91:      	leaq	0x28(%rsp), %r8
   60d96:      	leaq	0x20(%rsp), %rdi
   60d9b:      	leaq	0x12a26(%rip), %r9      # 0x737c8 <native_roots.0>
   60da2:      	movq	0x10(%rsp), %rax
   60da7:      	addq	%rcx, %rbp
   60daa:      	cmpb	$0x0, 0x12aff(%rip)     # 0x738b0 <g.4>
   60db1:      	je	0x6e9c5 <f.2+0x17805>
   60db7:      	cmpq	$0x0, 0x12ae9(%rip)     # 0x738a8 <g.3>
   60dbf:      	je	0x6e9c5 <f.2+0x17805>
   60dc5:      	addq	%r13, %rbp
   60dc8:      	addq	%rax, %rbp
   60dcb:      	cmpq	$0xc, %r14
   60dcf:      	jbe	0x60de4 <f.2+0x9c24>
   60dd1:      	cmpq	$0xd, %r14
   60dd5:      	jne	0x60df1 <f.2+0x9c31>
   60dd7:      	movl	$0x1, %r13d
   60ddd:      	xorl	%eax, %eax
   60ddf:      	jmp	0x60f29 <f.2+0x9d69>
   60de4:      	leaq	-0xb(%r14), %r13
   60de8:      	leaq	-0xb(%r14), %rsi
   60dec:      	jmp	0x61351 <f.2+0xa191>
   60df1:      	leaq	-0xd(%r14), %rsi
   60df5:      	movq	$0x0, 0x50(%rsp)
   60dfe:      	movq	$0x3, 0x38(%rsp)
   60e07:      	xorl	%edi, %edi
   60e09:      	callq	0x6e9d0 <f.3>
   60e0e:      	subq	$0x8, %rsp
   60e12:      	cmpb	$0x0, 0x12a97(%rip)     # 0x738b0 <g.4>
   60e19:      	je	0x6e9c5 <f.2+0x17805>
   60e1f:      	movq	%rax, 0x10(%rsp)
   60e24:      	cmpq	$0x0, 0x12a7c(%rip)     # 0x738a8 <g.3>
   60e2c:      	je	0x6e9c5 <f.2+0x17805>
   60e32:      	leaq	-0xe(%r14), %rsi
   60e36:      	movq	$0x0, 0x50(%rsp)
   60e3f:      	movq	$0x3, 0x38(%rsp)
   60e48:      	xorl	%edi, %edi
   60e4a:      	callq	0x6e9d0 <f.3>
   60e4f:      	subq	$0x8, %rsp
   60e53:      	cmpb	$0x0, 0x12a56(%rip)     # 0x738b0 <g.4>
   60e5a:      	je	0x6e9c5 <f.2+0x17805>
   60e60:      	movq	%rax, %r13
   60e63:      	cmpq	$0x0, 0x12a3d(%rip)     # 0x738a8 <g.3>
   60e6b:      	leaq	-0xd(%r14), %rax
   60e6f:      	je	0x6e9c5 <f.2+0x17805>
   60e75:      	addq	0x10(%rsp), %r13
   60e7a:      	cmpq	$0xe, %r14
   60e7e:      	ja	0x60e96 <f.2+0x9cd6>
   60e80:      	leaq	0x28(%rsp), %r8
   60e85:      	leaq	0x20(%rsp), %rdi
   60e8a:      	leaq	0x12937(%rip), %r9      # 0x737c8 <native_roots.0>
   60e91:      	jmp	0x60f29 <f.2+0x9d69>
   60e96:      	movq	$0x0, 0x50(%rsp)
   60e9f:      	movq	$0x3, 0x38(%rsp)
   60ea8:      	xorl	%edi, %edi
   60eaa:      	leaq	-0xe(%r14), %rsi
   60eae:      	callq	0x6e9d0 <f.3>
   60eb3:      	subq	$0x8, %rsp
   60eb7:      	cmpb	$0x0, 0x129f2(%rip)     # 0x738b0 <g.4>
   60ebe:      	je	0x6e9c5 <f.2+0x17805>
   60ec4:      	movq	%rax, 0x10(%rsp)
   60ec9:      	cmpq	$0x0, 0x129d7(%rip)     # 0x738a8 <g.3>
   60ed1:      	je	0x6e9c5 <f.2+0x17805>
   60ed7:      	leaq	-0xf(%r14), %rsi
   60edb:      	movq	$0x0, 0x50(%rsp)
   60ee4:      	movq	$0x3, 0x38(%rsp)
   60eed:      	xorl	%edi, %edi
   60eef:      	callq	0x6e9d0 <f.3>
   60ef4:      	subq	$0x8, %rsp
   60ef8:      	cmpb	$0x0, 0x129b1(%rip)     # 0x738b0 <g.4>
   60eff:      	je	0x6e9c5 <f.2+0x17805>
   60f05:      	cmpq	$0x0, 0x1299b(%rip)     # 0x738a8 <g.3>
   60f0d:      	leaq	0x28(%rsp), %r8
   60f12:      	leaq	0x20(%rsp), %rdi
   60f17:      	leaq	0x128aa(%rip), %r9      # 0x737c8 <native_roots.0>
   60f1e:      	je	0x6e9c5 <f.2+0x17805>
   60f24:      	addq	0x10(%rsp), %rax
   60f29:      	addq	%r13, %rax
   60f2c:      	cmpq	$0xd, %r14
   60f30:      	je	0x60f45 <f.2+0x9d85>
   60f32:      	cmpq	$0xe, %r14
   60f36:      	jne	0x60f5b <f.2+0x9d9b>
   60f38:      	movl	$0x1, %ecx
   60f3d:      	xorl	%r13d, %r13d
   60f40:      	jmp	0x61093 <f.2+0x9ed3>
   60f45:      	leaq	(%r14,%rax), %r13
   60f49:      	addq	$-0xc, %r13
   60f4d:      	movl	$0x1, %esi
   60f52:      	leaq	-0xd(%r14), %rdx
   60f56:      	jmp	0x6134e <f.2+0xa18e>
   60f5b:      	movq	%rax, 0x10(%rsp)
   60f60:      	leaq	-0xe(%r14), %r13
   60f64:      	movq	$0x0, 0x50(%rsp)
   60f6d:      	movq	$0x3, 0x38(%rsp)
   60f76:      	xorl	%edi, %edi
   60f78:      	movq	%r13, %rsi
   60f7b:      	callq	0x6e9d0 <f.3>
   60f80:      	subq	$0x8, %rsp
   60f84:      	cmpb	$0x0, 0x12925(%rip)     # 0x738b0 <g.4>
   60f8b:      	je	0x6e9c5 <f.2+0x17805>
   60f91:      	movq	%rax, 0x18(%rsp)
   60f96:      	cmpq	$0x0, 0x1290a(%rip)     # 0x738a8 <g.3>
   60f9e:      	je	0x6e9c5 <f.2+0x17805>
   60fa4:      	leaq	-0xf(%r14), %rsi
   60fa8:      	movq	$0x0, 0x50(%rsp)
   60fb1:      	movq	$0x3, 0x38(%rsp)
   60fba:      	xorl	%edi, %edi
   60fbc:      	callq	0x6e9d0 <f.3>
   60fc1:      	subq	$0x8, %rsp
   60fc5:      	cmpb	$0x0, 0x128e4(%rip)     # 0x738b0 <g.4>
   60fcc:      	je	0x6e9c5 <f.2+0x17805>
   60fd2:      	movq	%rax, %rcx
   60fd5:      	cmpq	$0x0, 0x128cb(%rip)     # 0x738a8 <g.3>
   60fdd:      	leaq	0x28(%rsp), %r8
   60fe2:      	leaq	0x127df(%rip), %r9      # 0x737c8 <native_roots.0>
   60fe9:      	movq	0x10(%rsp), %rax
   60fee:      	je	0x6e9c5 <f.2+0x17805>
   60ff4:      	addq	0x18(%rsp), %rcx
   60ff9:      	cmpq	$0x10, %r14
   60ffd:      	jae	0x61009 <f.2+0x9e49>
   60fff:      	leaq	0x20(%rsp), %rdi
   61004:      	jmp	0x61093 <f.2+0x9ed3>
   61009:      	movq	%rcx, 0x18(%rsp)
   6100e:      	movq	$0x0, 0x50(%rsp)
   61017:      	movq	$0x3, 0x38(%rsp)
   61020:      	xorl	%edi, %edi
   61022:      	leaq	-0xf(%r14), %rsi
   61026:      	callq	0x6e9d0 <f.3>
   6102b:      	subq	$0x8, %rsp
   6102f:      	cmpb	$0x0, 0x1287a(%rip)     # 0x738b0 <g.4>
   61036:      	je	0x6e9c5 <f.2+0x17805>
   6103c:      	movq	%rax, 0x58(%rsp)
   61041:      	cmpq	$0x0, 0x1285f(%rip)     # 0x738a8 <g.3>
   61049:      	je	0x6e9c5 <f.2+0x17805>
   6104f:      	leaq	-0x10(%r14), %rsi
   61053:      	movq	$0x0, 0x50(%rsp)
   6105c:      	movq	$0x3, 0x38(%rsp)
   61065:      	xorl	%edi, %edi
   61067:      	callq	0x6e9d0 <f.3>
   6106c:      	subq	$0x8, %rsp
   61070:      	movq	%rax, %r13
   61073:      	addq	0x58(%rsp), %r13
   61078:      	leaq	0x28(%rsp), %r8
   6107d:      	leaq	0x20(%rsp), %rdi
   61082:      	leaq	0x1273f(%rip), %r9      # 0x737c8 <native_roots.0>
   61089:      	movq	0x10(%rsp), %rax
   6108e:      	movq	0x18(%rsp), %rcx
   61093:      	cmpb	$0x0, 0x12816(%rip)     # 0x738b0 <g.4>
   6109a:      	je	0x6e9c5 <f.2+0x17805>
   610a0:      	cmpq	$0x0, 0x12800(%rip)     # 0x738a8 <g.3>
   610a8:      	je	0x6e9c5 <f.2+0x17805>
   610ae:      	addq	%rcx, %r13
   610b1:      	addq	%rax, %r13
   610b4:      	movq	%r14, %rsi
   610b7:      	subq	$0xe, %rsi
   610bb:      	jbe	0x61176 <f.2+0x9fb6>
   610c1:      	movq	$0x0, 0x50(%rsp)
   610ca:      	movq	$0x3, 0x38(%rsp)
   610d3:      	xorl	%edi, %edi
   610d5:      	movq	%rsi, 0x10(%rsp)
   610da:      	callq	0x6e9d0 <f.3>
   610df:      	subq	$0x8, %rsp
   610e3:      	cmpb	$0x0, 0x127c6(%rip)     # 0x738b0 <g.4>
   610ea:      	je	0x6e9c5 <f.2+0x17805>
   610f0:      	movq	%rax, 0x18(%rsp)
   610f5:      	cmpq	$0x0, 0x127ab(%rip)     # 0x738a8 <g.3>
   610fd:      	je	0x6e9c5 <f.2+0x17805>
   61103:      	leaq	-0xf(%r14), %rsi
   61107:      	movq	$0x0, 0x50(%rsp)
   61110:      	movq	$0x3, 0x38(%rsp)
   61119:      	xorl	%edi, %edi
   6111b:      	callq	0x6e9d0 <f.3>
   61120:      	subq	$0x8, %rsp
   61124:      	cmpb	$0x0, 0x12785(%rip)     # 0x738b0 <g.4>
   6112b:      	je	0x6e9c5 <f.2+0x17805>
   61131:      	cmpq	$0x0, 0x1276f(%rip)     # 0x738a8 <g.3>
   61139:      	leaq	0x28(%rsp), %r8
   6113e:      	leaq	0x12683(%rip), %r9      # 0x737c8 <native_roots.0>
   61145:      	movq	0x10(%rsp), %rsi
   6114a:      	je	0x6e9c5 <f.2+0x17805>
   61150:      	movq	%rax, %rcx
   61153:      	addq	0x18(%rsp), %rcx
   61158:      	cmpq	$0xf, %r14
   6115c:      	leaq	-0xf(%r14), %rax
   61160:      	jne	0x61182 <f.2+0x9fc2>
   61162:      	addq	%rcx, %rsi
   61165:      	movl	$0x1, %edx
   6116a:      	xorl	%eax, %eax
   6116c:      	leaq	0x20(%rsp), %rdi
   61171:      	jmp	0x6134b <f.2+0xa18b>
   61176:      	incq	%rsi
   61179:      	leaq	-0xd(%r14), %rdx
   6117d:      	jmp	0x6134e <f.2+0xa18e>
   61182:      	movq	%rcx, 0x18(%rsp)
   61187:      	movq	$0x0, 0x50(%rsp)
   61190:      	movq	$0x3, 0x38(%rsp)
   61199:      	xorl	%edi, %edi
   6119b:      	movq	%rax, %rsi
   6119e:      	callq	0x6e9d0 <f.3>
   611a3:      	subq	$0x8, %rsp
   611a7:      	cmpb	$0x0, 0x12702(%rip)     # 0x738b0 <g.4>
   611ae:      	je	0x6e9c5 <f.2+0x17805>
   611b4:      	movq	%rax, 0x58(%rsp)
   611b9:      	cmpq	$0x0, 0x126e7(%rip)     # 0x738a8 <g.3>
   611c1:      	je	0x6e9c5 <f.2+0x17805>
   611c7:      	leaq	-0x10(%r14), %rsi
   611cb:      	movq	$0x0, 0x50(%rsp)
   611d4:      	movq	$0x3, 0x38(%rsp)
   611dd:      	xorl	%edi, %edi
   611df:      	callq	0x6e9d0 <f.3>
   611e4:      	subq	$0x8, %rsp
   611e8:      	cmpb	$0x0, 0x126c1(%rip)     # 0x738b0 <g.4>
   611ef:      	je	0x6e9c5 <f.2+0x17805>
   611f5:      	movq	%rax, 0x10(%rsp)
   611fa:      	cmpq	$0x0, 0x126a6(%rip)     # 0x738a8 <g.3>
   61202:      	je	0x6e9c5 <f.2+0x17805>
   61208:      	movq	$0x0, 0x50(%rsp)
   61211:      	movq	$0x3, 0x38(%rsp)
   6121a:      	xorl	%edi, %edi
   6121c:      	leaq	-0xf(%r14), %rsi
   61220:      	callq	0x6e9d0 <f.3>
   61225:      	subq	$0x8, %rsp
   61229:      	cmpb	$0x0, 0x12680(%rip)     # 0x738b0 <g.4>
   61230:      	je	0x6e9c5 <f.2+0x17805>
   61236:      	movq	%rax, 0x60(%rsp)
   6123b:      	cmpq	$0x0, 0x12665(%rip)     # 0x738a8 <g.3>
   61243:      	je	0x6e9c5 <f.2+0x17805>
   61249:      	movq	$0x0, 0x50(%rsp)
   61252:      	movq	$0x3, 0x38(%rsp)
   6125b:      	xorl	%edi, %edi
   6125d:      	leaq	-0x10(%r14), %rsi
   61261:      	callq	0x6e9d0 <f.3>
   61266:      	subq	$0x8, %rsp
   6126a:      	cmpb	$0x0, 0x1263f(%rip)     # 0x738b0 <g.4>
   61271:      	je	0x6e9c5 <f.2+0x17805>
   61277:      	movq	%rax, %rdx
   6127a:      	cmpq	$0x0, 0x12626(%rip)     # 0x738a8 <g.3>
   61282:      	leaq	0x28(%rsp), %r8
   61287:      	leaq	0x1253a(%rip), %r9      # 0x737c8 <native_roots.0>
   6128e:      	movq	0x10(%rsp), %rsi
   61293:      	leaq	-0xf(%r14), %rax
   61297:      	movq	0x18(%rsp), %rcx
   6129c:      	je	0x6e9c5 <f.2+0x17805>
   612a2:      	addq	0x58(%rsp), %rsi
   612a7:      	addq	%rcx, %rsi
   612aa:      	addq	0x60(%rsp), %rdx
   612af:      	cmpq	$0x11, %r14
   612b3:      	jae	0x612bf <f.2+0xa0ff>
   612b5:      	leaq	0x20(%rsp), %rdi
   612ba:      	jmp	0x6134b <f.2+0xa18b>
   612bf:      	movq	%rdx, 0x18(%rsp)
   612c4:      	movq	%rsi, 0x10(%rsp)
   612c9:      	movq	$0x0, 0x50(%rsp)
   612d2:      	movq	$0x3, 0x38(%rsp)
   612db:      	xorl	%edi, %edi
   612dd:      	leaq	-0x10(%r14), %rsi
   612e1:      	callq	0x6e9d0 <f.3>
   612e6:      	subq	$0x8, %rsp
   612ea:      	cmpb	$0x0, 0x125bf(%rip)     # 0x738b0 <g.4>
   612f1:      	je	0x6e9c5 <f.2+0x17805>
   612f7:      	movq	%rax, 0x58(%rsp)
   612fc:      	cmpq	$0x0, 0x125a4(%rip)     # 0x738a8 <g.3>
   61304:      	je	0x6e9c5 <f.2+0x17805>
   6130a:      	leaq	-0x11(%r14), %rsi
   6130e:      	movq	$0x0, 0x50(%rsp)
   61317:      	movq	$0x3, 0x38(%rsp)
   61320:      	xorl	%edi, %edi
   61322:      	callq	0x6e9d0 <f.3>
   61327:      	subq	$0x8, %rsp
   6132b:      	addq	0x58(%rsp), %rax
   61330:      	leaq	0x28(%rsp), %r8
   61335:      	leaq	0x20(%rsp), %rdi
   6133a:      	leaq	0x12487(%rip), %r9      # 0x737c8 <native_roots.0>
   61341:      	movq	0x10(%rsp), %rsi
   61346:      	movq	0x18(%rsp), %rdx
   6134b:      	addq	%rax, %rdx
   6134e:      	addq	%rdx, %rsi
   61351:      	addq	%rsi, %r13
   61354:      	cmpb	$0x0, 0x12555(%rip)     # 0x738b0 <g.4>
   6135b:      	je	0x6e9c5 <f.2+0x17805>
   61361:      	cmpq	$0x0, 0x1253f(%rip)     # 0x738a8 <g.3>
   61369:      	je	0x6e9c5 <f.2+0x17805>
   6136f:      	addq	%rbp, %r13
   61372:      	addq	%r12, %r13
   61375:      	cmpq	$0x9, %r14
   61379:      	jbe	0x6139f <f.2+0xa1df>
   6137b:      	movl	$0x1, %eax
   61380:      	cmpq	$0xa, %r14
   61384:      	je	0x613b0 <f.2+0xa1f0>
   61386:      	cmpq	$0xb, %r14
   6138a:      	jbe	0x613ac <f.2+0xa1ec>
   6138c:      	cmpq	$0xc, %r14
   61390:      	jne	0x613f5 <f.2+0xa235>
   61392:      	movl	$0x1, %r12d
   61398:      	xorl	%eax, %eax
   6139a:      	jmp	0x615d3 <f.2+0xa413>
   6139f:      	leaq	-0x8(%r14), %r12
   613a3:      	leaq	-0x8(%r14), %rbp
   613a7:      	jmp	0x66ca1 <f.2+0xfae1>
   613ac:      	leaq	-0xa(%r14), %rax
   613b0:      	addq	%r14, %rax
   613b3:      	addq	$-0xa, %rax
   613b7:      	cmpq	$0xa, %r14
   613bb:      	je	0x626c1 <f.2+0xb501>
   613c1:      	movl	$0x1, %ebp
   613c6:      	cmpq	$0xb, %r14
   613ca:      	je	0x613ec <f.2+0xa22c>
   613cc:      	cmpq	$0xc, %r14
   613d0:      	jbe	0x613e8 <f.2+0xa228>
   613d2:      	cmpq	$0xd, %r14
   613d6:      	movq	%rax, 0x10(%rsp)
   613db:      	jne	0x6149a <f.2+0xa2da>
   613e1:      	xorl	%ecx, %ecx
   613e3:      	jmp	0x6173f <f.2+0xa57f>
   613e8:      	leaq	-0xb(%r14), %rbp
   613ec:      	leaq	-0xb(%r14), %r12
   613f0:      	jmp	0x61dfb <f.2+0xac3b>
   613f5:      	leaq	-0xc(%r14), %rsi
   613f9:      	movq	$0x0, 0x50(%rsp)
   61402:      	movq	$0x3, 0x38(%rsp)
   6140b:      	xorl	%edi, %edi
   6140d:      	callq	0x6e9d0 <f.3>
   61412:      	subq	$0x8, %rsp
   61416:      	cmpb	$0x0, 0x12493(%rip)     # 0x738b0 <g.4>
   6141d:      	je	0x6e9c5 <f.2+0x17805>
   61423:      	cmpq	$0x0, 0x1247d(%rip)     # 0x738a8 <g.3>
   6142b:      	je	0x6e9c5 <f.2+0x17805>
   61431:      	movq	%rax, %rbp
   61434:      	leaq	-0xd(%r14), %rsi
   61438:      	movq	$0x0, 0x50(%rsp)
   61441:      	movq	$0x3, 0x38(%rsp)
   6144a:      	xorl	%edi, %edi
   6144c:      	callq	0x6e9d0 <f.3>
   61451:      	subq	$0x8, %rsp
   61455:      	cmpb	$0x0, 0x12454(%rip)     # 0x738b0 <g.4>
   6145c:      	je	0x6e9c5 <f.2+0x17805>
   61462:      	cmpq	$0x0, 0x1243e(%rip)     # 0x738a8 <g.3>
   6146a:      	je	0x6e9c5 <f.2+0x17805>
   61470:      	movq	%rax, %r12
   61473:      	addq	%rbp, %r12
   61476:      	cmpq	$0xd, %r14
   6147a:      	ja	0x61544 <f.2+0xa384>
   61480:      	leaq	0x28(%rsp), %r8
   61485:      	leaq	0x20(%rsp), %rdi
   6148a:      	leaq	0x12337(%rip), %r9      # 0x737c8 <native_roots.0>
   61491:      	leaq	-0xc(%r14), %rax
   61495:      	jmp	0x615d3 <f.2+0xa413>
   6149a:      	leaq	-0xd(%r14), %rsi
   6149e:      	movq	$0x0, 0x50(%rsp)
   614a7:      	movq	$0x3, 0x38(%rsp)
   614b0:      	xorl	%edi, %edi
   614b2:      	callq	0x6e9d0 <f.3>
   614b7:      	subq	$0x8, %rsp
   614bb:      	cmpb	$0x0, 0x123ee(%rip)     # 0x738b0 <g.4>
   614c2:      	je	0x6e9c5 <f.2+0x17805>
   614c8:      	cmpq	$0x0, 0x123d8(%rip)     # 0x738a8 <g.3>
   614d0:      	je	0x6e9c5 <f.2+0x17805>
   614d6:      	movq	%rax, %r12
   614d9:      	leaq	-0xe(%r14), %rsi
   614dd:      	movq	$0x0, 0x50(%rsp)
   614e6:      	movq	$0x3, 0x38(%rsp)
   614ef:      	xorl	%edi, %edi
   614f1:      	callq	0x6e9d0 <f.3>
   614f6:      	subq	$0x8, %rsp
   614fa:      	cmpb	$0x0, 0x123af(%rip)     # 0x738b0 <g.4>
   61501:      	je	0x6e9c5 <f.2+0x17805>
   61507:      	movq	%rax, %rbp
   6150a:      	cmpq	$0x0, 0x12396(%rip)     # 0x738a8 <g.3>
   61512:      	leaq	0x20(%rsp), %rdi
   61517:      	movq	0x10(%rsp), %rax
   6151c:      	je	0x6e9c5 <f.2+0x17805>
   61522:      	addq	%r12, %rbp
   61525:      	cmpq	$0xe, %r14
   61529:      	ja	0x616a8 <f.2+0xa4e8>
   6152f:      	leaq	0x28(%rsp), %r8
   61534:      	leaq	0x1228d(%rip), %r9      # 0x737c8 <native_roots.0>
   6153b:      	leaq	-0xd(%r14), %rcx
   6153f:      	jmp	0x6173f <f.2+0xa57f>
   61544:      	movq	$0x0, 0x50(%rsp)
   6154d:      	movq	$0x3, 0x38(%rsp)
   61556:      	xorl	%edi, %edi
   61558:      	leaq	-0xd(%r14), %rsi
   6155c:      	callq	0x6e9d0 <f.3>
   61561:      	subq	$0x8, %rsp
   61565:      	cmpb	$0x0, 0x12344(%rip)     # 0x738b0 <g.4>
   6156c:      	je	0x6e9c5 <f.2+0x17805>
   61572:      	cmpq	$0x0, 0x1232e(%rip)     # 0x738a8 <g.3>
   6157a:      	je	0x6e9c5 <f.2+0x17805>
   61580:      	movq	%rax, %rbp
   61583:      	leaq	-0xe(%r14), %rsi
   61587:      	movq	$0x0, 0x50(%rsp)
   61590:      	movq	$0x3, 0x38(%rsp)
   61599:      	xorl	%edi, %edi
   6159b:      	callq	0x6e9d0 <f.3>
   615a0:      	subq	$0x8, %rsp
   615a4:      	cmpb	$0x0, 0x12305(%rip)     # 0x738b0 <g.4>
   615ab:      	je	0x6e9c5 <f.2+0x17805>
   615b1:      	cmpq	$0x0, 0x122ef(%rip)     # 0x738a8 <g.3>
   615b9:      	leaq	0x28(%rsp), %r8
   615be:      	leaq	0x20(%rsp), %rdi
   615c3:      	leaq	0x121fe(%rip), %r9      # 0x737c8 <native_roots.0>
   615ca:      	je	0x6e9c5 <f.2+0x17805>
   615d0:      	addq	%rbp, %rax
   615d3:      	addq	%r12, %rax
   615d6:      	cmpq	$0xc, %r14
   615da:      	je	0x615ef <f.2+0xa42f>
   615dc:      	cmpq	$0xd, %r14
   615e0:      	jne	0x61605 <f.2+0xa445>
   615e2:      	movl	$0x1, %r12d
   615e8:      	xorl	%ecx, %ecx
   615ea:      	jmp	0x618a0 <f.2+0xa6e0>
   615ef:      	leaq	(%r14,%rax), %rcx
   615f3:      	addq	$-0xb, %rcx
   615f7:      	movl	$0x1, %ebp
   615fc:      	leaq	-0xc(%r14), %rax
   61600:      	jmp	0x62696 <f.2+0xb4d6>
   61605:      	movq	%rax, 0x10(%rsp)
   6160a:      	leaq	-0xd(%r14), %rsi
   6160e:      	movq	$0x0, 0x50(%rsp)
   61617:      	movq	$0x3, 0x38(%rsp)
   61620:      	xorl	%edi, %edi
   61622:      	callq	0x6e9d0 <f.3>
   61627:      	subq	$0x8, %rsp
   6162b:      	cmpb	$0x0, 0x1227e(%rip)     # 0x738b0 <g.4>
   61632:      	je	0x6e9c5 <f.2+0x17805>
   61638:      	cmpq	$0x0, 0x12268(%rip)     # 0x738a8 <g.3>
   61640:      	je	0x6e9c5 <f.2+0x17805>
   61646:      	movq	%rax, %rbp
   61649:      	leaq	-0xe(%r14), %rsi
   6164d:      	movq	$0x0, 0x50(%rsp)
   61656:      	movq	$0x3, 0x38(%rsp)
   6165f:      	xorl	%edi, %edi
   61661:      	callq	0x6e9d0 <f.3>
   61666:      	subq	$0x8, %rsp
   6166a:      	cmpb	$0x0, 0x1223f(%rip)     # 0x738b0 <g.4>
   61671:      	je	0x6e9c5 <f.2+0x17805>
   61677:      	cmpq	$0x0, 0x12229(%rip)     # 0x738a8 <g.3>
   6167f:      	leaq	0x20(%rsp), %rdi
   61684:      	leaq	-0xd(%r14), %rcx
   61688:      	je	0x6e9c5 <f.2+0x17805>
   6168e:      	movq	%rax, %r12
   61691:      	addq	%rbp, %r12
   61694:      	cmpq	$0xf, %r14
   61698:      	jae	0x61824 <f.2+0xa664>
   6169e:      	leaq	0x28(%rsp), %r8
   616a3:      	jmp	0x61894 <f.2+0xa6d4>
   616a8:      	movq	$0x0, 0x50(%rsp)
   616b1:      	movq	$0x3, 0x38(%rsp)
   616ba:      	xorl	%edi, %edi
   616bc:      	leaq	-0xe(%r14), %rsi
   616c0:      	callq	0x6e9d0 <f.3>
   616c5:      	subq	$0x8, %rsp
   616c9:      	cmpb	$0x0, 0x121e0(%rip)     # 0x738b0 <g.4>
   616d0:      	je	0x6e9c5 <f.2+0x17805>
   616d6:      	cmpq	$0x0, 0x121ca(%rip)     # 0x738a8 <g.3>
   616de:      	je	0x6e9c5 <f.2+0x17805>
   616e4:      	movq	%rax, %r12
   616e7:      	leaq	-0xf(%r14), %rsi
   616eb:      	movq	$0x0, 0x50(%rsp)
   616f4:      	movq	$0x3, 0x38(%rsp)
   616fd:      	xorl	%edi, %edi
   616ff:      	callq	0x6e9d0 <f.3>
   61704:      	subq	$0x8, %rsp
   61708:      	cmpb	$0x0, 0x121a1(%rip)     # 0x738b0 <g.4>
   6170f:      	je	0x6e9c5 <f.2+0x17805>
   61715:      	movq	%rax, %rcx
   61718:      	cmpq	$0x0, 0x12188(%rip)     # 0x738a8 <g.3>
   61720:      	leaq	0x28(%rsp), %r8
   61725:      	leaq	0x20(%rsp), %rdi
   6172a:      	leaq	0x12097(%rip), %r9      # 0x737c8 <native_roots.0>
   61731:      	movq	0x10(%rsp), %rax
   61736:      	je	0x6e9c5 <f.2+0x17805>
   6173c:      	addq	%r12, %rcx
   6173f:      	addq	%rbp, %rcx
   61742:      	cmpq	$0xd, %r14
   61746:      	je	0x6175a <f.2+0xa59a>
   61748:      	cmpq	$0xe, %r14
   6174c:      	jne	0x61771 <f.2+0xa5b1>
   6174e:      	movl	$0x1, %edx
   61753:      	xorl	%ebp, %ebp
   61755:      	jmp	0x61b4a <f.2+0xa98a>
   6175a:      	leaq	(%r14,%rcx), %rbp
   6175e:      	addq	$-0xc, %rbp
   61762:      	movl	$0x1, %r12d
   61768:      	leaq	-0xd(%r14), %rdx
   6176c:      	jmp	0x61df8 <f.2+0xac38>
   61771:      	movq	%rcx, 0x18(%rsp)
   61776:      	leaq	-0xe(%r14), %rbp
   6177a:      	movq	$0x0, 0x50(%rsp)
   61783:      	movq	$0x3, 0x38(%rsp)
   6178c:      	xorl	%edi, %edi
   6178e:      	movq	%rbp, %rsi
   61791:      	callq	0x6e9d0 <f.3>
   61796:      	subq	$0x8, %rsp
   6179a:      	cmpb	$0x0, 0x1210f(%rip)     # 0x738b0 <g.4>
   617a1:      	je	0x6e9c5 <f.2+0x17805>
   617a7:      	cmpq	$0x0, 0x120f9(%rip)     # 0x738a8 <g.3>
   617af:      	je	0x6e9c5 <f.2+0x17805>
   617b5:      	movq	%rax, %r12
   617b8:      	leaq	-0xf(%r14), %rsi
   617bc:      	movq	$0x0, 0x50(%rsp)
   617c5:      	movq	$0x3, 0x38(%rsp)
   617ce:      	xorl	%edi, %edi
   617d0:      	callq	0x6e9d0 <f.3>
   617d5:      	subq	$0x8, %rsp
   617d9:      	cmpb	$0x0, 0x120d0(%rip)     # 0x738b0 <g.4>
   617e0:      	je	0x6e9c5 <f.2+0x17805>
   617e6:      	movq	%rax, %rdx
   617e9:      	cmpq	$0x0, 0x120b7(%rip)     # 0x738a8 <g.3>
   617f1:      	leaq	0x28(%rsp), %r8
   617f6:      	leaq	0x11fcb(%rip), %r9      # 0x737c8 <native_roots.0>
   617fd:      	movq	0x10(%rsp), %rax
   61802:      	je	0x6e9c5 <f.2+0x17805>
   61808:      	addq	%r12, %rdx
   6180b:      	cmpq	$0x10, %r14
   6180f:      	jae	0x61abf <f.2+0xa8ff>
   61815:      	leaq	0x20(%rsp), %rdi
   6181a:      	movq	0x18(%rsp), %rcx
   6181f:      	jmp	0x61b4a <f.2+0xa98a>
   61824:      	movq	$0x0, 0x50(%rsp)
   6182d:      	movq	$0x3, 0x38(%rsp)
   61836:      	xorl	%edi, %edi
   61838:      	leaq	-0xe(%r14), %rsi
   6183c:      	callq	0x6e9d0 <f.3>
   61841:      	subq	$0x8, %rsp
   61845:      	cmpb	$0x0, 0x12064(%rip)     # 0x738b0 <g.4>
   6184c:      	je	0x6e9c5 <f.2+0x17805>
   61852:      	cmpq	$0x0, 0x1204e(%rip)     # 0x738a8 <g.3>
   6185a:      	je	0x6e9c5 <f.2+0x17805>
   61860:      	movq	%rax, %rbp
   61863:      	leaq	-0xf(%r14), %rsi
   61867:      	movq	$0x0, 0x50(%rsp)
   61870:      	movq	$0x3, 0x38(%rsp)
   61879:      	xorl	%edi, %edi
   6187b:      	callq	0x6e9d0 <f.3>
   61880:      	subq	$0x8, %rsp
   61884:      	movq	%rax, %rcx
   61887:      	addq	%rbp, %rcx
   6188a:      	leaq	0x28(%rsp), %r8
   6188f:      	leaq	0x20(%rsp), %rdi
   61894:      	leaq	0x11f2d(%rip), %r9      # 0x737c8 <native_roots.0>
   6189b:      	movq	0x10(%rsp), %rax
   618a0:      	cmpb	$0x0, 0x12009(%rip)     # 0x738b0 <g.4>
   618a7:      	je	0x6e9c5 <f.2+0x17805>
   618ad:      	cmpq	$0x0, 0x11ff3(%rip)     # 0x738a8 <g.3>
   618b5:      	je	0x6e9c5 <f.2+0x17805>
   618bb:      	addq	%r12, %rcx
   618be:      	addq	%rax, %rcx
   618c1:      	movq	%r14, %rbp
   618c4:      	subq	$0xd, %rbp
   618c8:      	jbe	0x6197b <f.2+0xa7bb>
   618ce:      	movq	%rcx, 0x18(%rsp)
   618d3:      	movq	$0x0, 0x50(%rsp)
   618dc:      	movq	$0x3, 0x38(%rsp)
   618e5:      	xorl	%edi, %edi
   618e7:      	movq	%rbp, %rsi
   618ea:      	callq	0x6e9d0 <f.3>
   618ef:      	subq	$0x8, %rsp
   618f3:      	cmpb	$0x0, 0x11fb6(%rip)     # 0x738b0 <g.4>
   618fa:      	je	0x6e9c5 <f.2+0x17805>
   61900:      	cmpq	$0x0, 0x11fa0(%rip)     # 0x738a8 <g.3>
   61908:      	je	0x6e9c5 <f.2+0x17805>
   6190e:      	movq	%rax, %r12
   61911:      	leaq	-0xe(%r14), %rsi
   61915:      	movq	$0x0, 0x50(%rsp)
   6191e:      	movq	$0x3, 0x38(%rsp)
   61927:      	xorl	%edi, %edi
   61929:      	callq	0x6e9d0 <f.3>
   6192e:      	subq	$0x8, %rsp
   61932:      	cmpb	$0x0, 0x11f77(%rip)     # 0x738b0 <g.4>
   61939:      	je	0x6e9c5 <f.2+0x17805>
   6193f:      	cmpq	$0x0, 0x11f61(%rip)     # 0x738a8 <g.3>
   61947:      	leaq	0x28(%rsp), %r8
   6194c:      	leaq	0x11e75(%rip), %r9      # 0x737c8 <native_roots.0>
   61953:      	movq	0x18(%rsp), %rcx
   61958:      	je	0x6e9c5 <f.2+0x17805>
   6195e:      	addq	%r12, %rax
   61961:      	cmpq	$0xe, %r14
   61965:      	jne	0x61987 <f.2+0xa7c7>
   61967:      	addq	%rax, %rbp
   6196a:      	movl	$0x1, %eax
   6196f:      	xorl	%edx, %edx
   61971:      	leaq	0x20(%rsp), %rdi
   61976:      	jmp	0x62693 <f.2+0xb4d3>
   6197b:      	incq	%rbp
   6197e:      	leaq	-0xc(%r14), %rax
   61982:      	jmp	0x62696 <f.2+0xb4d6>
   61987:      	movq	%rax, 0x10(%rsp)
   6198c:      	movq	$0x0, 0x50(%rsp)
   61995:      	movq	$0x3, 0x38(%rsp)
   6199e:      	xorl	%edi, %edi
   619a0:      	leaq	-0xe(%r14), %r12
   619a4:      	movq	%r12, %rsi
   619a7:      	callq	0x6e9d0 <f.3>
   619ac:      	subq	$0x8, %rsp
   619b0:      	cmpb	$0x0, 0x11ef9(%rip)     # 0x738b0 <g.4>
   619b7:      	je	0x6e9c5 <f.2+0x17805>
   619bd:      	movq	%rax, 0x58(%rsp)
   619c2:      	cmpq	$0x0, 0x11ede(%rip)     # 0x738a8 <g.3>
   619ca:      	je	0x6e9c5 <f.2+0x17805>
   619d0:      	leaq	-0xf(%r14), %rsi
   619d4:      	movq	$0x0, 0x50(%rsp)
   619dd:      	movq	$0x3, 0x38(%rsp)
   619e6:      	xorl	%edi, %edi
   619e8:      	callq	0x6e9d0 <f.3>
   619ed:      	subq	$0x8, %rsp
   619f1:      	cmpb	$0x0, 0x11eb8(%rip)     # 0x738b0 <g.4>
   619f8:      	je	0x6e9c5 <f.2+0x17805>
   619fe:      	cmpq	$0x0, 0x11ea2(%rip)     # 0x738a8 <g.3>
   61a06:      	je	0x6e9c5 <f.2+0x17805>
   61a0c:      	movq	%rax, %rbp
   61a0f:      	movq	$0x0, 0x50(%rsp)
   61a18:      	movq	$0x3, 0x38(%rsp)
   61a21:      	xorl	%edi, %edi
   61a23:      	movq	%r12, %rsi
   61a26:      	callq	0x6e9d0 <f.3>
   61a2b:      	subq	$0x8, %rsp
   61a2f:      	cmpb	$0x0, 0x11e7a(%rip)     # 0x738b0 <g.4>
   61a36:      	je	0x6e9c5 <f.2+0x17805>
   61a3c:      	cmpq	$0x0, 0x11e64(%rip)     # 0x738a8 <g.3>
   61a44:      	je	0x6e9c5 <f.2+0x17805>
   61a4a:      	movq	%rax, %r12
   61a4d:      	movq	$0x0, 0x50(%rsp)
   61a56:      	movq	$0x3, 0x38(%rsp)
   61a5f:      	xorl	%edi, %edi
   61a61:      	leaq	-0xf(%r14), %rsi
   61a65:      	callq	0x6e9d0 <f.3>
   61a6a:      	subq	$0x8, %rsp
   61a6e:      	cmpb	$0x0, 0x11e3b(%rip)     # 0x738b0 <g.4>
   61a75:      	je	0x6e9c5 <f.2+0x17805>
   61a7b:      	cmpq	$0x0, 0x11e25(%rip)     # 0x738a8 <g.3>
   61a83:      	leaq	0x28(%rsp), %r8
   61a88:      	leaq	0x11d39(%rip), %r9      # 0x737c8 <native_roots.0>
   61a8f:      	movq	0x18(%rsp), %rcx
   61a94:      	je	0x6e9c5 <f.2+0x17805>
   61a9a:      	addq	0x58(%rsp), %rbp
   61a9f:      	addq	0x10(%rsp), %rbp
   61aa4:      	addq	%r12, %rax
   61aa7:      	cmpq	$0x10, %r14
   61aab:      	jae	0x6260d <f.2+0xb44d>
   61ab1:      	leaq	0x20(%rsp), %rdi
   61ab6:      	leaq	-0xe(%r14), %rdx
   61aba:      	jmp	0x62693 <f.2+0xb4d3>
   61abf:      	movq	%rdx, 0x58(%rsp)
   61ac4:      	movq	$0x0, 0x50(%rsp)
   61acd:      	movq	$0x3, 0x38(%rsp)
   61ad6:      	xorl	%edi, %edi
   61ad8:      	leaq	-0xf(%r14), %rsi
   61adc:      	callq	0x6e9d0 <f.3>
   61ae1:      	subq	$0x8, %rsp
   61ae5:      	cmpb	$0x0, 0x11dc4(%rip)     # 0x738b0 <g.4>
   61aec:      	je	0x6e9c5 <f.2+0x17805>
   61af2:      	cmpq	$0x0, 0x11dae(%rip)     # 0x738a8 <g.3>
   61afa:      	je	0x6e9c5 <f.2+0x17805>
   61b00:      	movq	%rax, %r12
   61b03:      	leaq	-0x10(%r14), %rsi
   61b07:      	movq	$0x0, 0x50(%rsp)
   61b10:      	movq	$0x3, 0x38(%rsp)
   61b19:      	xorl	%edi, %edi
   61b1b:      	callq	0x6e9d0 <f.3>
   61b20:      	subq	$0x8, %rsp
   61b24:      	movq	%rax, %rbp
   61b27:      	addq	%r12, %rbp
   61b2a:      	leaq	0x28(%rsp), %r8
   61b2f:      	leaq	0x20(%rsp), %rdi
   61b34:      	leaq	0x11c8d(%rip), %r9      # 0x737c8 <native_roots.0>
   61b3b:      	movq	0x10(%rsp), %rax
   61b40:      	movq	0x18(%rsp), %rcx
   61b45:      	movq	0x58(%rsp), %rdx
   61b4a:      	cmpb	$0x0, 0x11d5f(%rip)     # 0x738b0 <g.4>
   61b51:      	je	0x6e9c5 <f.2+0x17805>
   61b57:      	cmpq	$0x0, 0x11d49(%rip)     # 0x738a8 <g.3>
   61b5f:      	je	0x6e9c5 <f.2+0x17805>
   61b65:      	addq	%rdx, %rbp
   61b68:      	addq	%rcx, %rbp
   61b6b:      	movq	%r14, %r12
   61b6e:      	subq	$0xe, %r12
   61b72:      	jbe	0x61c2b <f.2+0xaa6b>
   61b78:      	movq	$0x0, 0x50(%rsp)
   61b81:      	movq	$0x3, 0x38(%rsp)
   61b8a:      	xorl	%edi, %edi
   61b8c:      	movq	%r12, %rsi
   61b8f:      	callq	0x6e9d0 <f.3>
   61b94:      	subq	$0x8, %rsp
   61b98:      	cmpb	$0x0, 0x11d11(%rip)     # 0x738b0 <g.4>
   61b9f:      	je	0x6e9c5 <f.2+0x17805>
   61ba5:      	movq	%rax, 0x18(%rsp)
   61baa:      	cmpq	$0x0, 0x11cf6(%rip)     # 0x738a8 <g.3>
   61bb2:      	je	0x6e9c5 <f.2+0x17805>
   61bb8:      	leaq	-0xf(%r14), %rsi
   61bbc:      	movq	$0x0, 0x50(%rsp)
   61bc5:      	movq	$0x3, 0x38(%rsp)
   61bce:      	xorl	%edi, %edi
   61bd0:      	callq	0x6e9d0 <f.3>
   61bd5:      	subq	$0x8, %rsp
   61bd9:      	cmpb	$0x0, 0x11cd0(%rip)     # 0x738b0 <g.4>
   61be0:      	je	0x6e9c5 <f.2+0x17805>
   61be6:      	movq	%rax, %rcx
   61be9:      	cmpq	$0x0, 0x11cb7(%rip)     # 0x738a8 <g.3>
   61bf1:      	leaq	0x28(%rsp), %r8
   61bf6:      	leaq	0x11bcb(%rip), %r9      # 0x737c8 <native_roots.0>
   61bfd:      	movq	0x10(%rsp), %rax
   61c02:      	je	0x6e9c5 <f.2+0x17805>
   61c08:      	addq	0x18(%rsp), %rcx
   61c0d:      	cmpq	$0xf, %r14
   61c11:      	leaq	-0xf(%r14), %rsi
   61c15:      	jne	0x61c37 <f.2+0xaa77>
   61c17:      	addq	%rcx, %r12
   61c1a:      	movl	$0x1, %edx
   61c1f:      	xorl	%ecx, %ecx
   61c21:      	leaq	0x20(%rsp), %rdi
   61c26:      	jmp	0x61df5 <f.2+0xac35>
   61c2b:      	incq	%r12
   61c2e:      	leaq	-0xd(%r14), %rdx
   61c32:      	jmp	0x61df8 <f.2+0xac38>
   61c37:      	movq	%rcx, 0x18(%rsp)
   61c3c:      	movq	$0x0, 0x50(%rsp)
   61c45:      	movq	$0x3, 0x38(%rsp)
   61c4e:      	xorl	%edi, %edi
   61c50:      	callq	0x6e9d0 <f.3>
   61c55:      	subq	$0x8, %rsp
   61c59:      	cmpb	$0x0, 0x11c50(%rip)     # 0x738b0 <g.4>
   61c60:      	je	0x6e9c5 <f.2+0x17805>
   61c66:      	movq	%rax, 0x58(%rsp)
   61c6b:      	cmpq	$0x0, 0x11c35(%rip)     # 0x738a8 <g.3>
   61c73:      	je	0x6e9c5 <f.2+0x17805>
   61c79:      	leaq	-0x10(%r14), %rsi
   61c7d:      	movq	$0x0, 0x50(%rsp)
   61c86:      	movq	$0x3, 0x38(%rsp)
   61c8f:      	xorl	%edi, %edi
   61c91:      	callq	0x6e9d0 <f.3>
   61c96:      	subq	$0x8, %rsp
   61c9a:      	cmpb	$0x0, 0x11c0f(%rip)     # 0x738b0 <g.4>
   61ca1:      	je	0x6e9c5 <f.2+0x17805>
   61ca7:      	cmpq	$0x0, 0x11bf9(%rip)     # 0x738a8 <g.3>
   61caf:      	leaq	-0xf(%r14), %rsi
   61cb3:      	je	0x6e9c5 <f.2+0x17805>
   61cb9:      	movq	%rax, %r12
   61cbc:      	movq	$0x0, 0x50(%rsp)
   61cc5:      	movq	$0x3, 0x38(%rsp)
   61cce:      	xorl	%edi, %edi
   61cd0:      	callq	0x6e9d0 <f.3>
   61cd5:      	subq	$0x8, %rsp
   61cd9:      	cmpb	$0x0, 0x11bd0(%rip)     # 0x738b0 <g.4>
   61ce0:      	je	0x6e9c5 <f.2+0x17805>
   61ce6:      	movq	%rax, 0x60(%rsp)
   61ceb:      	cmpq	$0x0, 0x11bb5(%rip)     # 0x738a8 <g.3>
   61cf3:      	je	0x6e9c5 <f.2+0x17805>
   61cf9:      	movq	$0x0, 0x50(%rsp)
   61d02:      	movq	$0x3, 0x38(%rsp)
   61d0b:      	xorl	%edi, %edi
   61d0d:      	leaq	-0x10(%r14), %rsi
   61d11:      	callq	0x6e9d0 <f.3>
   61d16:      	subq	$0x8, %rsp
   61d1a:      	cmpb	$0x0, 0x11b8f(%rip)     # 0x738b0 <g.4>
   61d21:      	je	0x6e9c5 <f.2+0x17805>
   61d27:      	movq	%rax, %rdx
   61d2a:      	cmpq	$0x0, 0x11b76(%rip)     # 0x738a8 <g.3>
   61d32:      	leaq	0x28(%rsp), %r8
   61d37:      	leaq	0x20(%rsp), %rdi
   61d3c:      	leaq	0x11a85(%rip), %r9      # 0x737c8 <native_roots.0>
   61d43:      	movq	0x10(%rsp), %rax
   61d48:      	leaq	-0xf(%r14), %rcx
   61d4c:      	je	0x6e9c5 <f.2+0x17805>
   61d52:      	addq	0x58(%rsp), %r12
   61d57:      	addq	0x18(%rsp), %r12
   61d5c:      	addq	0x60(%rsp), %rdx
   61d61:      	cmpq	$0x11, %r14
   61d65:      	jb	0x61df5 <f.2+0xac35>
   61d6b:      	movq	%rdx, 0x18(%rsp)
   61d70:      	movq	$0x0, 0x50(%rsp)
   61d79:      	movq	$0x3, 0x38(%rsp)
   61d82:      	xorl	%edi, %edi
   61d84:      	leaq	-0x10(%r14), %rsi
   61d88:      	callq	0x6e9d0 <f.3>
   61d8d:      	subq	$0x8, %rsp
   61d91:      	cmpb	$0x0, 0x11b18(%rip)     # 0x738b0 <g.4>
   61d98:      	je	0x6e9c5 <f.2+0x17805>
   61d9e:      	movq	%rax, 0x58(%rsp)
   61da3:      	cmpq	$0x0, 0x11afd(%rip)     # 0x738a8 <g.3>
   61dab:      	je	0x6e9c5 <f.2+0x17805>
   61db1:      	leaq	-0x11(%r14), %rsi
   61db5:      	movq	$0x0, 0x50(%rsp)
   61dbe:      	movq	$0x3, 0x38(%rsp)
   61dc7:      	xorl	%edi, %edi
   61dc9:      	callq	0x6e9d0 <f.3>
   61dce:      	subq	$0x8, %rsp
   61dd2:      	movq	%rax, %rcx
   61dd5:      	addq	0x58(%rsp), %rcx
   61dda:      	leaq	0x28(%rsp), %r8
   61ddf:      	leaq	0x20(%rsp), %rdi
   61de4:      	leaq	0x119dd(%rip), %r9      # 0x737c8 <native_roots.0>
   61deb:      	movq	0x10(%rsp), %rax
   61df0:      	movq	0x18(%rsp), %rdx
   61df5:      	addq	%rcx, %rdx
   61df8:      	addq	%rdx, %r12
   61dfb:      	cmpb	$0x0, 0x11aae(%rip)     # 0x738b0 <g.4>
   61e02:      	je	0x6e9c5 <f.2+0x17805>
   61e08:      	cmpq	$0x0, 0x11a98(%rip)     # 0x738a8 <g.3>
   61e10:      	je	0x6e9c5 <f.2+0x17805>
   61e16:      	addq	%rbp, %r12
   61e19:      	addq	%rax, %r12
   61e1c:      	cmpq	$0xb, %r14
   61e20:      	jbe	0x61ee1 <f.2+0xad21>
   61e26:      	movl	$0x1, %ebp
   61e2b:      	cmpq	$0xc, %r14
   61e2f:      	je	0x61ef1 <f.2+0xad31>
   61e35:      	movq	%r14, %rbp
   61e38:      	subq	$0xd, %rbp
   61e3c:      	jbe	0x61eee <f.2+0xad2e>
   61e42:      	movq	$0x0, 0x50(%rsp)
   61e4b:      	movq	$0x3, 0x38(%rsp)
   61e54:      	xorl	%edi, %edi
   61e56:      	movq	%rbp, %rsi
   61e59:      	callq	0x6e9d0 <f.3>
   61e5e:      	subq	$0x8, %rsp
   61e62:      	cmpb	$0x0, 0x11a47(%rip)     # 0x738b0 <g.4>
   61e69:      	je	0x6e9c5 <f.2+0x17805>
   61e6f:      	movq	%rax, 0x10(%rsp)
   61e74:      	cmpq	$0x0, 0x11a2c(%rip)     # 0x738a8 <g.3>
   61e7c:      	je	0x6e9c5 <f.2+0x17805>
   61e82:      	leaq	-0xe(%r14), %rsi
   61e86:      	movq	$0x0, 0x50(%rsp)
   61e8f:      	movq	$0x3, 0x38(%rsp)
   61e98:      	xorl	%edi, %edi
   61e9a:      	callq	0x6e9d0 <f.3>
   61e9f:      	subq	$0x8, %rsp
   61ea3:      	cmpb	$0x0, 0x11a06(%rip)     # 0x738b0 <g.4>
   61eaa:      	je	0x6e9c5 <f.2+0x17805>
   61eb0:      	cmpq	$0x0, 0x119f0(%rip)     # 0x738a8 <g.3>
   61eb8:      	leaq	0x20(%rsp), %rdi
   61ebd:      	je	0x6e9c5 <f.2+0x17805>
   61ec3:      	addq	0x10(%rsp), %rax
   61ec8:      	cmpq	$0xe, %r14
   61ecc:      	leaq	-0xe(%r14), %rsi
   61ed0:      	jne	0x61efe <f.2+0xad3e>
   61ed2:      	addq	%rax, %rbp
   61ed5:      	movl	$0x1, %ecx
   61eda:      	xorl	%eax, %eax
   61edc:      	jmp	0x6201d <f.2+0xae5d>
   61ee1:      	leaq	-0xa(%r14), %rbp
   61ee5:      	leaq	-0xa(%r14), %rax
   61ee9:      	jmp	0x66c9e <f.2+0xfade>
   61eee:      	incq	%rbp
   61ef1:      	leaq	(%r14,%rbp), %rax
   61ef5:      	addq	$-0xc, %rax
   61ef9:      	jmp	0x620d1 <f.2+0xaf11>
   61efe:      	movq	%rax, 0x10(%rsp)
   61f03:      	movq	$0x0, 0x50(%rsp)
   61f0c:      	movq	$0x3, 0x38(%rsp)
   61f15:      	xorl	%edi, %edi
   61f17:      	callq	0x6e9d0 <f.3>
   61f1c:      	subq	$0x8, %rsp
   61f20:      	cmpb	$0x0, 0x11989(%rip)     # 0x738b0 <g.4>
   61f27:      	je	0x6e9c5 <f.2+0x17805>
   61f2d:      	movq	%rax, 0x18(%rsp)
   61f32:      	cmpq	$0x0, 0x1196e(%rip)     # 0x738a8 <g.3>
   61f3a:      	je	0x6e9c5 <f.2+0x17805>
   61f40:      	leaq	-0xf(%r14), %rsi
   61f44:      	movq	$0x0, 0x50(%rsp)
   61f4d:      	movq	$0x3, 0x38(%rsp)
   61f56:      	xorl	%edi, %edi
   61f58:      	callq	0x6e9d0 <f.3>
   61f5d:      	subq	$0x8, %rsp
   61f61:      	cmpb	$0x0, 0x11948(%rip)     # 0x738b0 <g.4>
   61f68:      	je	0x6e9c5 <f.2+0x17805>
   61f6e:      	cmpq	$0x0, 0x11932(%rip)     # 0x738a8 <g.3>
   61f76:      	leaq	-0xe(%r14), %rsi
   61f7a:      	je	0x6e9c5 <f.2+0x17805>
   61f80:      	movq	%rax, %rbp
   61f83:      	movq	$0x0, 0x50(%rsp)
   61f8c:      	movq	$0x3, 0x38(%rsp)
   61f95:      	xorl	%edi, %edi
   61f97:      	callq	0x6e9d0 <f.3>
   61f9c:      	subq	$0x8, %rsp
   61fa0:      	cmpb	$0x0, 0x11909(%rip)     # 0x738b0 <g.4>
   61fa7:      	je	0x6e9c5 <f.2+0x17805>
   61fad:      	movq	%rax, 0x58(%rsp)
   61fb2:      	cmpq	$0x0, 0x118ee(%rip)     # 0x738a8 <g.3>
   61fba:      	je	0x6e9c5 <f.2+0x17805>
   61fc0:      	movq	$0x0, 0x50(%rsp)
   61fc9:      	movq	$0x3, 0x38(%rsp)
   61fd2:      	xorl	%edi, %edi
   61fd4:      	leaq	-0xf(%r14), %rsi
   61fd8:      	callq	0x6e9d0 <f.3>
   61fdd:      	subq	$0x8, %rsp
   61fe1:      	cmpb	$0x0, 0x118c8(%rip)     # 0x738b0 <g.4>
   61fe8:      	je	0x6e9c5 <f.2+0x17805>
   61fee:      	movq	%rax, %rcx
   61ff1:      	cmpq	$0x0, 0x118af(%rip)     # 0x738a8 <g.3>
   61ff9:      	leaq	0x20(%rsp), %rdi
   61ffe:      	leaq	-0xe(%r14), %rax
   62002:      	je	0x6e9c5 <f.2+0x17805>
   62008:      	addq	0x18(%rsp), %rbp
   6200d:      	addq	0x10(%rsp), %rbp
   62012:      	addq	0x58(%rsp), %rcx
   62017:      	cmpq	$0x10, %r14
   6201b:      	jae	0x6202e <f.2+0xae6e>
   6201d:      	leaq	0x28(%rsp), %r8
   62022:      	leaq	0x1179f(%rip), %r9      # 0x737c8 <native_roots.0>
   62029:      	jmp	0x620b0 <f.2+0xaef0>
   6202e:      	movq	%rcx, 0x10(%rsp)
   62033:      	movq	$0x0, 0x50(%rsp)
   6203c:      	movq	$0x3, 0x38(%rsp)
   62045:      	xorl	%edi, %edi
   62047:      	leaq	-0xf(%r14), %rsi
   6204b:      	callq	0x6e9d0 <f.3>
   62050:      	subq	$0x8, %rsp
   62054:      	cmpb	$0x0, 0x11855(%rip)     # 0x738b0 <g.4>
   6205b:      	je	0x6e9c5 <f.2+0x17805>
   62061:      	movq	%rax, 0x18(%rsp)
   62066:      	cmpq	$0x0, 0x1183a(%rip)     # 0x738a8 <g.3>
   6206e:      	je	0x6e9c5 <f.2+0x17805>
   62074:      	leaq	-0x10(%r14), %rsi
   62078:      	movq	$0x0, 0x50(%rsp)
   62081:      	movq	$0x3, 0x38(%rsp)
   6208a:      	xorl	%edi, %edi
   6208c:      	callq	0x6e9d0 <f.3>
   62091:      	subq	$0x8, %rsp
   62095:      	addq	0x18(%rsp), %rax
   6209a:      	leaq	0x28(%rsp), %r8
   6209f:      	leaq	0x20(%rsp), %rdi
   620a4:      	leaq	0x1171d(%rip), %r9      # 0x737c8 <native_roots.0>
   620ab:      	movq	0x10(%rsp), %rcx
   620b0:      	cmpb	$0x0, 0x117f9(%rip)     # 0x738b0 <g.4>
   620b7:      	je	0x6e9c5 <f.2+0x17805>
   620bd:      	cmpq	$0x0, 0x117e3(%rip)     # 0x738a8 <g.3>
   620c5:      	je	0x6e9c5 <f.2+0x17805>
   620cb:      	addq	%rcx, %rax
   620ce:      	addq	%rbp, %rax
   620d1:      	cmpq	$0xc, %r14
   620d5:      	je	0x621b5 <f.2+0xaff5>
   620db:      	movl	$0x1, %edx
   620e0:      	cmpq	$0xd, %r14
   620e4:      	je	0x621ce <f.2+0xb00e>
   620ea:      	movq	%r14, %rdx
   620ed:      	subq	$0xe, %rdx
   620f1:      	jbe	0x621cb <f.2+0xb00b>
   620f7:      	movq	%rax, 0x18(%rsp)
   620fc:      	movq	$0x0, 0x50(%rsp)
   62105:      	movq	$0x3, 0x38(%rsp)
   6210e:      	xorl	%edi, %edi
   62110:      	movq	%rdx, 0x10(%rsp)
   62115:      	movq	%rdx, %rsi
   62118:      	callq	0x6e9d0 <f.3>
   6211d:      	subq	$0x8, %rsp
   62121:      	cmpb	$0x0, 0x11788(%rip)     # 0x738b0 <g.4>
   62128:      	je	0x6e9c5 <f.2+0x17805>
   6212e:      	cmpq	$0x0, 0x11772(%rip)     # 0x738a8 <g.3>
   62136:      	je	0x6e9c5 <f.2+0x17805>
   6213c:      	movq	%rax, %rbp
   6213f:      	leaq	-0xf(%r14), %rsi
   62143:      	movq	$0x0, 0x50(%rsp)
   6214c:      	movq	$0x3, 0x38(%rsp)
   62155:      	xorl	%edi, %edi
   62157:      	callq	0x6e9d0 <f.3>
   6215c:      	subq	$0x8, %rsp
   62160:      	cmpb	$0x0, 0x11749(%rip)     # 0x738b0 <g.4>
   62167:      	je	0x6e9c5 <f.2+0x17805>
   6216d:      	movq	%rax, %rcx
   62170:      	cmpq	$0x0, 0x11730(%rip)     # 0x738a8 <g.3>
   62178:      	leaq	0x20(%rsp), %rdi
   6217d:      	movq	0x18(%rsp), %rax
   62182:      	movq	0x10(%rsp), %rdx
   62187:      	je	0x6e9c5 <f.2+0x17805>
   6218d:      	addq	%rbp, %rcx
   62190:      	cmpq	$0xf, %r14
   62194:      	leaq	-0xf(%r14), %rsi
   62198:      	jne	0x621d7 <f.2+0xb017>
   6219a:      	addq	%rcx, %rdx
   6219d:      	movl	$0x1, %ebp
   621a2:      	xorl	%ecx, %ecx
   621a4:      	leaq	0x28(%rsp), %r8
   621a9:      	leaq	0x11618(%rip), %r9      # 0x737c8 <native_roots.0>
   621b0:      	jmp	0x6239e <f.2+0xb1de>
   621b5:      	leaq	(%r14,%rax), %rbp
   621b9:      	addq	$-0xb, %rbp
   621bd:      	movl	$0x1, %eax
   621c2:      	leaq	-0xc(%r14), %rdx
   621c6:      	jmp	0x66c9b <f.2+0xfadb>
   621cb:      	incq	%rdx
   621ce:      	leaq	-0xd(%r14), %rbp
   621d2:      	jmp	0x623a1 <f.2+0xb1e1>
   621d7:      	movq	%rcx, 0x58(%rsp)
   621dc:      	movq	$0x0, 0x50(%rsp)
   621e5:      	movq	$0x3, 0x38(%rsp)
   621ee:      	xorl	%edi, %edi
   621f0:      	callq	0x6e9d0 <f.3>
   621f5:      	subq	$0x8, %rsp
   621f9:      	cmpb	$0x0, 0x116b0(%rip)     # 0x738b0 <g.4>
   62200:      	je	0x6e9c5 <f.2+0x17805>
   62206:      	movq	%rax, 0x60(%rsp)
   6220b:      	cmpq	$0x0, 0x11695(%rip)     # 0x738a8 <g.3>
   62213:      	je	0x6e9c5 <f.2+0x17805>
   62219:      	leaq	-0x10(%r14), %rbp
   6221d:      	movq	$0x0, 0x50(%rsp)
   62226:      	movq	$0x3, 0x38(%rsp)
   6222f:      	xorl	%edi, %edi
   62231:      	movq	%rbp, %rsi
   62234:      	callq	0x6e9d0 <f.3>
   62239:      	subq	$0x8, %rsp
   6223d:      	cmpb	$0x0, 0x1166c(%rip)     # 0x738b0 <g.4>
   62244:      	je	0x6e9c5 <f.2+0x17805>
   6224a:      	movq	%rax, 0x10(%rsp)
   6224f:      	cmpq	$0x0, 0x11651(%rip)     # 0x738a8 <g.3>
   62257:      	leaq	-0xf(%r14), %rsi
   6225b:      	je	0x6e9c5 <f.2+0x17805>
   62261:      	movq	$0x0, 0x50(%rsp)
   6226a:      	movq	$0x3, 0x38(%rsp)
   62273:      	xorl	%edi, %edi
   62275:      	callq	0x6e9d0 <f.3>
   6227a:      	subq	$0x8, %rsp
   6227e:      	cmpb	$0x0, 0x1162b(%rip)     # 0x738b0 <g.4>
   62285:      	je	0x6e9c5 <f.2+0x17805>
   6228b:      	movq	%rax, 0x68(%rsp)
   62290:      	cmpq	$0x0, 0x11610(%rip)     # 0x738a8 <g.3>
   62298:      	je	0x6e9c5 <f.2+0x17805>
   6229e:      	movq	$0x0, 0x50(%rsp)
   622a7:      	movq	$0x3, 0x38(%rsp)
   622b0:      	xorl	%edi, %edi
   622b2:      	movq	%rbp, %rsi
   622b5:      	callq	0x6e9d0 <f.3>
   622ba:      	subq	$0x8, %rsp
   622be:      	cmpb	$0x0, 0x115eb(%rip)     # 0x738b0 <g.4>
   622c5:      	je	0x6e9c5 <f.2+0x17805>
   622cb:      	movq	%rax, %rbp
   622ce:      	cmpq	$0x0, 0x115d2(%rip)     # 0x738a8 <g.3>
   622d6:      	leaq	0x28(%rsp), %r8
   622db:      	leaq	0x20(%rsp), %rdi
   622e0:      	leaq	0x114e1(%rip), %r9      # 0x737c8 <native_roots.0>
   622e7:      	movq	0x18(%rsp), %rax
   622ec:      	movq	0x10(%rsp), %rdx
   622f1:      	leaq	-0xf(%r14), %rcx
   622f5:      	je	0x6e9c5 <f.2+0x17805>
   622fb:      	addq	0x60(%rsp), %rdx
   62300:      	addq	0x58(%rsp), %rdx
   62305:      	addq	0x68(%rsp), %rbp
   6230a:      	cmpq	$0x11, %r14
   6230e:      	jb	0x6239e <f.2+0xb1de>
   62314:      	movq	%rdx, 0x10(%rsp)
   62319:      	movq	$0x0, 0x50(%rsp)
   62322:      	movq	$0x3, 0x38(%rsp)
   6232b:      	xorl	%edi, %edi
   6232d:      	leaq	-0x10(%r14), %rsi
   62331:      	callq	0x6e9d0 <f.3>
   62336:      	subq	$0x8, %rsp
   6233a:      	cmpb	$0x0, 0x1156f(%rip)     # 0x738b0 <g.4>
   62341:      	je	0x6e9c5 <f.2+0x17805>
   62347:      	movq	%rax, 0x58(%rsp)
   6234c:      	cmpq	$0x0, 0x11554(%rip)     # 0x738a8 <g.3>
   62354:      	je	0x6e9c5 <f.2+0x17805>
   6235a:      	leaq	-0x11(%r14), %rsi
   6235e:      	movq	$0x0, 0x50(%rsp)
   62367:      	movq	$0x3, 0x38(%rsp)
   62370:      	xorl	%edi, %edi
   62372:      	callq	0x6e9d0 <f.3>
   62377:      	subq	$0x8, %rsp
   6237b:      	movq	%rax, %rcx
   6237e:      	addq	0x58(%rsp), %rcx
   62383:      	leaq	0x28(%rsp), %r8
   62388:      	leaq	0x20(%rsp), %rdi
   6238d:      	leaq	0x11434(%rip), %r9      # 0x737c8 <native_roots.0>
   62394:      	movq	0x18(%rsp), %rax
   62399:      	movq	0x10(%rsp), %rdx
   6239e:      	addq	%rcx, %rbp
   623a1:      	cmpb	$0x0, 0x11508(%rip)     # 0x738b0 <g.4>
   623a8:      	je	0x6e9c5 <f.2+0x17805>
   623ae:      	cmpq	$0x0, 0x114f2(%rip)     # 0x738a8 <g.3>
   623b6:      	je	0x6e9c5 <f.2+0x17805>
   623bc:      	addq	%rdx, %rbp
   623bf:      	addq	%rax, %rbp
   623c2:      	cmpq	$0xd, %r14
   623c6:      	jbe	0x623da <f.2+0xb21a>
   623c8:      	cmpq	$0xe, %r14
   623cc:      	jne	0x623e7 <f.2+0xb227>
   623ce:      	movl	$0x1, %eax
   623d3:      	xorl	%ecx, %ecx
   623d5:      	jmp	0x62529 <f.2+0xb369>
   623da:      	leaq	-0xc(%r14), %rax
   623de:      	leaq	-0xc(%r14), %rdx
   623e2:      	jmp	0x66c9b <f.2+0xfadb>
   623e7:      	leaq	-0xe(%r14), %rsi
   623eb:      	movq	$0x0, 0x50(%rsp)
   623f4:      	movq	$0x3, 0x38(%rsp)
   623fd:      	xorl	%edi, %edi
   623ff:      	callq	0x6e9d0 <f.3>
   62404:      	subq	$0x8, %rsp
   62408:      	cmpb	$0x0, 0x114a1(%rip)     # 0x738b0 <g.4>
   6240f:      	je	0x6e9c5 <f.2+0x17805>
   62415:      	movq	%rax, 0x10(%rsp)
   6241a:      	cmpq	$0x0, 0x11486(%rip)     # 0x738a8 <g.3>
   62422:      	je	0x6e9c5 <f.2+0x17805>
   62428:      	leaq	-0xf(%r14), %rsi
   6242c:      	movq	$0x0, 0x50(%rsp)
   62435:      	movq	$0x3, 0x38(%rsp)
   6243e:      	xorl	%edi, %edi
   62440:      	callq	0x6e9d0 <f.3>
   62445:      	subq	$0x8, %rsp
   62449:      	cmpb	$0x0, 0x11460(%rip)     # 0x738b0 <g.4>
   62450:      	je	0x6e9c5 <f.2+0x17805>
   62456:      	cmpq	$0x0, 0x1144a(%rip)     # 0x738a8 <g.3>
   6245e:      	leaq	-0xe(%r14), %rcx
   62462:      	je	0x6e9c5 <f.2+0x17805>
   62468:      	addq	0x10(%rsp), %rax
   6246d:      	cmpq	$0xf, %r14
   62471:      	ja	0x62489 <f.2+0xb2c9>
   62473:      	leaq	0x28(%rsp), %r8
   62478:      	leaq	0x20(%rsp), %rdi
   6247d:      	leaq	0x11344(%rip), %r9      # 0x737c8 <native_roots.0>
   62484:      	jmp	0x62529 <f.2+0xb369>
   62489:      	movq	%rax, 0x10(%rsp)
   6248e:      	movq	$0x0, 0x50(%rsp)
   62497:      	movq	$0x3, 0x38(%rsp)
   624a0:      	xorl	%edi, %edi
   624a2:      	leaq	-0xf(%r14), %rsi
   624a6:      	callq	0x6e9d0 <f.3>
   624ab:      	subq	$0x8, %rsp
   624af:      	cmpb	$0x0, 0x113fa(%rip)     # 0x738b0 <g.4>
   624b6:      	je	0x6e9c5 <f.2+0x17805>
   624bc:      	movq	%rax, 0x18(%rsp)
   624c1:      	cmpq	$0x0, 0x113df(%rip)     # 0x738a8 <g.3>
   624c9:      	je	0x6e9c5 <f.2+0x17805>
   624cf:      	leaq	-0x10(%r14), %rsi
   624d3:      	movq	$0x0, 0x50(%rsp)
   624dc:      	movq	$0x3, 0x38(%rsp)
   624e5:      	xorl	%edi, %edi
   624e7:      	callq	0x6e9d0 <f.3>
   624ec:      	subq	$0x8, %rsp
   624f0:      	cmpb	$0x0, 0x113b9(%rip)     # 0x738b0 <g.4>
   624f7:      	je	0x6e9c5 <f.2+0x17805>
   624fd:      	movq	%rax, %rcx
   62500:      	cmpq	$0x0, 0x113a0(%rip)     # 0x738a8 <g.3>
   62508:      	leaq	0x28(%rsp), %r8
   6250d:      	leaq	0x20(%rsp), %rdi
   62512:      	leaq	0x112af(%rip), %r9      # 0x737c8 <native_roots.0>
   62519:      	movq	0x10(%rsp), %rax
   6251e:      	je	0x6e9c5 <f.2+0x17805>
   62524:      	addq	0x18(%rsp), %rcx
   62529:      	addq	%rax, %rcx
   6252c:      	cmpq	$0xe, %r14
   62530:      	je	0x62544 <f.2+0xb384>
   62532:      	cmpq	$0xf, %r14
   62536:      	jne	0x6255a <f.2+0xb39a>
   62538:      	movl	$0x1, %edx
   6253d:      	xorl	%eax, %eax
   6253f:      	jmp	0x6275e <f.2+0xb59e>
   62544:      	leaq	(%r14,%rcx), %rax
   62548:      	addq	$-0xd, %rax
   6254c:      	movl	$0x1, %edx
   62551:      	leaq	-0xe(%r14), %rsi
   62555:      	jmp	0x66c98 <f.2+0xfad8>
   6255a:      	movq	%rcx, 0x10(%rsp)
   6255f:      	leaq	-0xf(%r14), %rsi
   62563:      	movq	$0x0, 0x50(%rsp)
   6256c:      	movq	$0x3, 0x38(%rsp)
   62575:      	xorl	%edi, %edi
   62577:      	callq	0x6e9d0 <f.3>
   6257c:      	subq	$0x8, %rsp
   62580:      	cmpb	$0x0, 0x11329(%rip)     # 0x738b0 <g.4>
   62587:      	je	0x6e9c5 <f.2+0x17805>
   6258d:      	movq	%rax, 0x18(%rsp)
   62592:      	cmpq	$0x0, 0x1130e(%rip)     # 0x738a8 <g.3>
   6259a:      	je	0x6e9c5 <f.2+0x17805>
   625a0:      	leaq	-0x10(%r14), %rsi
   625a4:      	movq	$0x0, 0x50(%rsp)
   625ad:      	movq	$0x3, 0x38(%rsp)
   625b6:      	xorl	%edi, %edi
   625b8:      	callq	0x6e9d0 <f.3>
   625bd:      	subq	$0x8, %rsp
   625c1:      	cmpb	$0x0, 0x112e8(%rip)     # 0x738b0 <g.4>
   625c8:      	je	0x6e9c5 <f.2+0x17805>
   625ce:      	movq	%rax, %rdx
   625d1:      	cmpq	$0x0, 0x112cf(%rip)     # 0x738a8 <g.3>
   625d9:      	leaq	0x28(%rsp), %r8
   625de:      	leaq	0x111e3(%rip), %r9      # 0x737c8 <native_roots.0>
   625e5:      	leaq	-0xf(%r14), %rax
   625e9:      	movq	0x10(%rsp), %rcx
   625ee:      	je	0x6e9c5 <f.2+0x17805>
   625f4:      	addq	0x18(%rsp), %rdx
   625f9:      	cmpq	$0x11, %r14
   625fd:      	jae	0x626d7 <f.2+0xb517>
   62603:      	leaq	0x20(%rsp), %rdi
   62608:      	jmp	0x6275e <f.2+0xb59e>
   6260d:      	movq	%rax, 0x10(%rsp)
   62612:      	movq	$0x0, 0x50(%rsp)
   6261b:      	movq	$0x3, 0x38(%rsp)
   62624:      	xorl	%edi, %edi
   62626:      	leaq	-0xf(%r14), %rsi
   6262a:      	callq	0x6e9d0 <f.3>
   6262f:      	subq	$0x8, %rsp
   62633:      	cmpb	$0x0, 0x11276(%rip)     # 0x738b0 <g.4>
   6263a:      	je	0x6e9c5 <f.2+0x17805>
   62640:      	cmpq	$0x0, 0x11260(%rip)     # 0x738a8 <g.3>
   62648:      	je	0x6e9c5 <f.2+0x17805>
   6264e:      	movq	%rax, %r12
   62651:      	leaq	-0x10(%r14), %rsi
   62655:      	movq	$0x0, 0x50(%rsp)
   6265e:      	movq	$0x3, 0x38(%rsp)
   62667:      	xorl	%edi, %edi
   62669:      	callq	0x6e9d0 <f.3>
   6266e:      	subq	$0x8, %rsp
   62672:      	addq	%r12, %rax
   62675:      	movq	%rax, %rdx
   62678:      	leaq	0x28(%rsp), %r8
   6267d:      	leaq	0x20(%rsp), %rdi
   62682:      	leaq	0x1113f(%rip), %r9      # 0x737c8 <native_roots.0>
   62689:      	movq	0x10(%rsp), %rax
   6268e:      	movq	0x18(%rsp), %rcx
   62693:      	addq	%rdx, %rax
   62696:      	cmpb	$0x0, 0x11213(%rip)     # 0x738b0 <g.4>
   6269d:      	je	0x6e9c5 <f.2+0x17805>
   626a3:      	cmpq	$0x0, 0x111fd(%rip)     # 0x738a8 <g.3>
   626ab:      	je	0x6e9c5 <f.2+0x17805>
   626b1:      	addq	%rbp, %rax
   626b4:      	addq	%rcx, %rax
   626b7:      	cmpq	$0xa, %r14
   626bb:      	jne	0x613c1 <f.2+0xa201>
   626c1:      	leaq	(%r14,%rax), %r12
   626c5:      	addq	$-0x9, %r12
   626c9:      	movl	$0x1, %ebp
   626ce:      	leaq	-0xa(%r14), %rax
   626d2:      	jmp	0x66c9e <f.2+0xfade>
   626d7:      	movq	%rdx, 0x18(%rsp)
   626dc:      	movq	$0x0, 0x50(%rsp)
   626e5:      	movq	$0x3, 0x38(%rsp)
   626ee:      	xorl	%edi, %edi
   626f0:      	leaq	-0x10(%r14), %rsi
   626f4:      	callq	0x6e9d0 <f.3>
   626f9:      	subq	$0x8, %rsp
   626fd:      	cmpb	$0x0, 0x111ac(%rip)     # 0x738b0 <g.4>
   62704:      	je	0x6e9c5 <f.2+0x17805>
   6270a:      	movq	%rax, 0x58(%rsp)
   6270f:      	cmpq	$0x0, 0x11191(%rip)     # 0x738a8 <g.3>
   62717:      	je	0x6e9c5 <f.2+0x17805>
   6271d:      	leaq	-0x11(%r14), %rsi
   62721:      	movq	$0x0, 0x50(%rsp)
   6272a:      	movq	$0x3, 0x38(%rsp)
   62733:      	xorl	%edi, %edi
   62735:      	callq	0x6e9d0 <f.3>
   6273a:      	subq	$0x8, %rsp
   6273e:      	addq	0x58(%rsp), %rax
   62743:      	leaq	0x28(%rsp), %r8
   62748:      	leaq	0x20(%rsp), %rdi
   6274d:      	leaq	0x11074(%rip), %r9      # 0x737c8 <native_roots.0>
   62754:      	movq	0x10(%rsp), %rcx
   62759:      	movq	0x18(%rsp), %rdx
   6275e:      	cmpb	$0x0, 0x1114b(%rip)     # 0x738b0 <g.4>
   62765:      	je	0x6e9c5 <f.2+0x17805>
   6276b:      	cmpq	$0x0, 0x11135(%rip)     # 0x738a8 <g.3>
   62773:      	je	0x6e9c5 <f.2+0x17805>
   62779:      	addq	%rdx, %rax
   6277c:      	addq	%rcx, %rax
   6277f:      	movq	%r14, %rdx
   62782:      	subq	$0xf, %rdx
   62786:      	jbe	0x6283d <f.2+0xb67d>
   6278c:      	movq	%rax, 0x18(%rsp)
   62791:      	movq	$0x0, 0x50(%rsp)
   6279a:      	movq	$0x3, 0x38(%rsp)
   627a3:      	xorl	%edi, %edi
   627a5:      	movq	%rdx, 0x10(%rsp)
   627aa:      	movq	%rdx, %rsi
   627ad:      	callq	0x6e9d0 <f.3>
   627b2:      	subq	$0x8, %rsp
   627b6:      	cmpb	$0x0, 0x110f3(%rip)     # 0x738b0 <g.4>
   627bd:      	je	0x6e9c5 <f.2+0x17805>
   627c3:      	movq	%rax, 0x58(%rsp)
   627c8:      	cmpq	$0x0, 0x110d8(%rip)     # 0x738a8 <g.3>
   627d0:      	je	0x6e9c5 <f.2+0x17805>
   627d6:      	leaq	-0x10(%r14), %rsi
   627da:      	movq	$0x0, 0x50(%rsp)
   627e3:      	movq	$0x3, 0x38(%rsp)
   627ec:      	xorl	%edi, %edi
   627ee:      	callq	0x6e9d0 <f.3>
   627f3:      	subq	$0x8, %rsp
   627f7:      	cmpb	$0x0, 0x110b2(%rip)     # 0x738b0 <g.4>
   627fe:      	je	0x6e9c5 <f.2+0x17805>
   62804:      	movq	%rax, %rcx
   62807:      	cmpq	$0x0, 0x11099(%rip)     # 0x738a8 <g.3>
   6280f:      	movq	0x18(%rsp), %rax
   62814:      	movq	0x10(%rsp), %rdx
   62819:      	je	0x6e9c5 <f.2+0x17805>
   6281f:      	addq	0x58(%rsp), %rcx
   62824:      	cmpq	$0x10, %r14
   62828:      	leaq	-0x10(%r14), %rsi
   6282c:      	jne	0x62849 <f.2+0xb689>
   6282e:      	addq	%rcx, %rdx
   62831:      	movl	$0x1, %esi
   62836:      	xorl	%ecx, %ecx
   62838:      	jmp	0x62973 <f.2+0xb7b3>
   6283d:      	incq	%rdx
   62840:      	leaq	-0xe(%r14), %rsi
   62844:      	jmp	0x66c98 <f.2+0xfad8>
   62849:      	movq	%rcx, 0x58(%rsp)
   6284e:      	movq	$0x0, 0x50(%rsp)
   62857:      	movq	$0x3, 0x38(%rsp)
   62860:      	xorl	%edi, %edi
   62862:      	callq	0x6e9d0 <f.3>
   62867:      	subq	$0x8, %rsp
   6286b:      	cmpb	$0x0, 0x1103e(%rip)     # 0x738b0 <g.4>
   62872:      	je	0x6e9c5 <f.2+0x17805>
   62878:      	movq	%rax, 0x60(%rsp)
   6287d:      	cmpq	$0x0, 0x11023(%rip)     # 0x738a8 <g.3>
   62885:      	je	0x6e9c5 <f.2+0x17805>
   6288b:      	leaq	-0x11(%r14), %rsi
   6288f:      	movq	$0x0, 0x50(%rsp)
   62898:      	movq	$0x3, 0x38(%rsp)
   628a1:      	xorl	%edi, %edi
   628a3:      	callq	0x6e9d0 <f.3>
   628a8:      	subq	$0x8, %rsp
   628ac:      	cmpb	$0x0, 0x10ffd(%rip)     # 0x738b0 <g.4>
   628b3:      	je	0x6e9c5 <f.2+0x17805>
   628b9:      	movq	%rax, 0x10(%rsp)
   628be:      	cmpq	$0x0, 0x10fe2(%rip)     # 0x738a8 <g.3>
   628c6:      	leaq	-0x10(%r14), %rsi
   628ca:      	je	0x6e9c5 <f.2+0x17805>
   628d0:      	movq	$0x0, 0x50(%rsp)
   628d9:      	movq	$0x3, 0x38(%rsp)
   628e2:      	xorl	%edi, %edi
   628e4:      	callq	0x6e9d0 <f.3>
   628e9:      	subq	$0x8, %rsp
   628ed:      	cmpb	$0x0, 0x10fbc(%rip)     # 0x738b0 <g.4>
   628f4:      	je	0x6e9c5 <f.2+0x17805>
   628fa:      	movq	%rax, 0x68(%rsp)
   628ff:      	cmpq	$0x0, 0x10fa1(%rip)     # 0x738a8 <g.3>
   62907:      	je	0x6e9c5 <f.2+0x17805>
   6290d:      	movq	$0x0, 0x50(%rsp)
   62916:      	movq	$0x3, 0x38(%rsp)
   6291f:      	xorl	%edi, %edi
   62921:      	leaq	-0x11(%r14), %rsi
   62925:      	callq	0x6e9d0 <f.3>
   6292a:      	subq	$0x8, %rsp
   6292e:      	cmpb	$0x0, 0x10f7b(%rip)     # 0x738b0 <g.4>
   62935:      	je	0x6e9c5 <f.2+0x17805>
   6293b:      	movq	%rax, %rsi
   6293e:      	cmpq	$0x0, 0x10f62(%rip)     # 0x738a8 <g.3>
   62946:      	movq	0x18(%rsp), %rax
   6294b:      	movq	0x10(%rsp), %rdx
   62950:      	leaq	-0x10(%r14), %rcx
   62954:      	je	0x6e9c5 <f.2+0x17805>
   6295a:      	addq	0x60(%rsp), %rdx
   6295f:      	addq	0x58(%rsp), %rdx
   62964:      	addq	0x68(%rsp), %rsi
   62969:      	cmpq	$0x12, %r14
   6296d:      	jae	0x66c01 <f.2+0xfa41>
   62973:      	leaq	0x28(%rsp), %r8
   62978:      	leaq	0x20(%rsp), %rdi
   6297d:      	leaq	0x10e44(%rip), %r9      # 0x737c8 <native_roots.0>
   62984:      	jmp	0x66c95 <f.2+0xfad5>
   62989:      	movq	%rdx, 0x18(%rsp)
   6298e:      	movq	$0x0, 0x50(%rsp)
   62997:      	movq	$0x3, 0x38(%rsp)
   629a0:      	xorl	%edi, %edi
   629a2:      	leaq	-0x10(%r14), %rsi
   629a6:      	callq	0x6e9d0 <f.3>
   629ab:      	subq	$0x8, %rsp
   629af:      	cmpb	$0x0, 0x10efa(%rip)     # 0x738b0 <g.4>
   629b6:      	je	0x6e9c5 <f.2+0x17805>
   629bc:      	movq	%rax, 0x58(%rsp)
   629c1:      	cmpq	$0x0, 0x10edf(%rip)     # 0x738a8 <g.3>
   629c9:      	je	0x6e9c5 <f.2+0x17805>
   629cf:      	leaq	-0x11(%r14), %rsi
   629d3:      	movq	$0x0, 0x50(%rsp)
   629dc:      	movq	$0x3, 0x38(%rsp)
   629e5:      	xorl	%edi, %edi
   629e7:      	callq	0x6e9d0 <f.3>
   629ec:      	subq	$0x8, %rsp
   629f0:      	movq	%rax, %rcx
   629f3:      	addq	0x58(%rsp), %rcx
   629f8:      	leaq	0x28(%rsp), %r8
   629fd:      	leaq	0x20(%rsp), %rdi
   62a02:      	leaq	0x10dbf(%rip), %r9      # 0x737c8 <native_roots.0>
   62a09:      	movq	0x10(%rsp), %rax
   62a0e:      	movq	0x18(%rsp), %rdx
   62a13:      	addq	%rcx, %rdx
   62a16:      	addq	%rdx, %r13
   62a19:      	addq	%r13, %rax
   62a1c:      	cmpb	$0x0, 0x10e8d(%rip)     # 0x738b0 <g.4>
   62a23:      	je	0x6e9c5 <f.2+0x17805>
   62a29:      	cmpq	$0x0, 0x10e77(%rip)     # 0x738a8 <g.3>
   62a31:      	je	0x6e9c5 <f.2+0x17805>
   62a37:      	addq	%rbp, %rax
   62a3a:      	addq	%r15, %rax
   62a3d:      	cmpq	$0x7, %r14
   62a41:      	jne	0x57672 <f.2+0x4b2>
   62a47:      	leaq	(%r14,%rax), %r15
   62a4b:      	addq	$-0x6, %r15
   62a4f:      	movl	$0x1, %r13d
   62a55:      	leaq	-0x7(%r14), %rbp
   62a59:      	addq	%rbp, %r13
   62a5c:      	addq	%r13, %r15
   62a5f:      	cmpb	$0x0, 0x10e4a(%rip)     # 0x738b0 <g.4>
   62a66:      	jne	0x57357 <f.2+0x197>
   62a6c:      	jmp	0x6e9c5 <f.2+0x17805>
   62a71:      	movq	%rdx, 0x18(%rsp)
   62a76:      	movq	$0x0, 0x50(%rsp)
   62a7f:      	movq	$0x3, 0x38(%rsp)
   62a88:      	xorl	%edi, %edi
   62a8a:      	leaq	-0xf(%r14), %rsi
   62a8e:      	callq	0x6e9d0 <f.3>
   62a93:      	subq	$0x8, %rsp
   62a97:      	cmpb	$0x0, 0x10e12(%rip)     # 0x738b0 <g.4>
   62a9e:      	je	0x6e9c5 <f.2+0x17805>
   62aa4:      	cmpq	$0x0, 0x10dfc(%rip)     # 0x738a8 <g.3>
   62aac:      	je	0x6e9c5 <f.2+0x17805>
   62ab2:      	movq	%rax, %r12
   62ab5:      	leaq	-0x10(%r14), %rsi
   62ab9:      	movq	$0x0, 0x50(%rsp)
   62ac2:      	movq	$0x3, 0x38(%rsp)
   62acb:      	xorl	%edi, %edi
   62acd:      	callq	0x6e9d0 <f.3>
   62ad2:      	subq	$0x8, %rsp
   62ad6:      	cmpb	$0x0, 0x10dd3(%rip)     # 0x738b0 <g.4>
   62add:      	je	0x6e9c5 <f.2+0x17805>
   62ae3:      	addq	%r12, %rax
   62ae6:      	addq	%r13, %rax
   62ae9:      	addq	0x18(%rsp), %rax
   62aee:      	movq	%rax, %r13
   62af1:      	leaq	0x28(%rsp), %r8
   62af6:      	leaq	0x20(%rsp), %rdi
   62afb:      	leaq	0x10cc6(%rip), %r9      # 0x737c8 <native_roots.0>
   62b02:      	movq	0x10(%rsp), %rcx
   62b07:      	jmp	0x5bbad <f.2+0x49ed>
   62b0c:      	movq	%rsi, 0x58(%rsp)
   62b11:      	movq	$0x0, 0x50(%rsp)
   62b1a:      	movq	$0x3, 0x38(%rsp)
   62b23:      	xorl	%edi, %edi
   62b25:      	leaq	-0xf(%r14), %rsi
   62b29:      	callq	0x6e9d0 <f.3>
   62b2e:      	subq	$0x8, %rsp
   62b32:      	cmpb	$0x0, 0x10d77(%rip)     # 0x738b0 <g.4>
   62b39:      	je	0x6e9c5 <f.2+0x17805>
   62b3f:      	cmpq	$0x0, 0x10d61(%rip)     # 0x738a8 <g.3>
   62b47:      	je	0x6e9c5 <f.2+0x17805>
   62b4d:      	movq	%rax, %r12
   62b50:      	movq	%rbp, %r13
   62b53:      	leaq	-0x10(%r14), %rsi
   62b57:      	movq	$0x0, 0x50(%rsp)
   62b60:      	movq	$0x3, 0x38(%rsp)
   62b69:      	xorl	%edi, %edi
   62b6b:      	callq	0x6e9d0 <f.3>
   62b70:      	subq	$0x8, %rsp
   62b74:      	addq	%r12, %rax
   62b77:      	leaq	0x28(%rsp), %r8
   62b7c:      	leaq	0x20(%rsp), %rdi
   62b81:      	leaq	0x10c40(%rip), %r9      # 0x737c8 <native_roots.0>
   62b88:      	movq	0x18(%rsp), %r12
   62b8d:      	movq	0x10(%rsp), %rdx
   62b92:      	movq	0x58(%rsp), %rsi
   62b97:      	cmpb	$0x0, 0x10d12(%rip)     # 0x738b0 <g.4>
   62b9e:      	je	0x6e9c5 <f.2+0x17805>
   62ba4:      	addq	%rsi, %rax
   62ba7:      	cmpq	$0x0, 0x10cf9(%rip)     # 0x738a8 <g.3>
   62baf:      	je	0x6e9c5 <f.2+0x17805>
   62bb5:      	addq	%r13, %rax
   62bb8:      	addq	%rdx, %rax
   62bbb:      	cmpq	$0xa, %r14
   62bbf:      	jne	0x57f37 <f.2+0xd77>
   62bc5:      	leaq	(%r14,%rax), %rbp
   62bc9:      	addq	$-0x9, %rbp
   62bcd:      	movl	$0x1, %ecx
   62bd2:      	leaq	-0xa(%r14), %r13
   62bd6:      	jmp	0x686ff <f.2+0x1153f>
   62bdb:      	movq	$0x0, 0x50(%rsp)
   62be4:      	movq	$0x3, 0x38(%rsp)
   62bed:      	xorl	%edi, %edi
   62bef:      	leaq	-0x10(%r14), %rsi
   62bf3:      	callq	0x6e9d0 <f.3>
   62bf8:      	subq	$0x8, %rsp
   62bfc:      	cmpb	$0x0, 0x10cad(%rip)     # 0x738b0 <g.4>
   62c03:      	je	0x6e9c5 <f.2+0x17805>
   62c09:      	movq	%rax, 0x58(%rsp)
   62c0e:      	cmpq	$0x0, 0x10c92(%rip)     # 0x738a8 <g.3>
   62c16:      	je	0x6e9c5 <f.2+0x17805>
   62c1c:      	leaq	-0x11(%r14), %rsi
   62c20:      	movq	$0x0, 0x50(%rsp)
   62c29:      	movq	$0x3, 0x38(%rsp)
   62c32:      	xorl	%edi, %edi
   62c34:      	callq	0x6e9d0 <f.3>
   62c39:      	subq	$0x8, %rsp
   62c3d:      	addq	0x58(%rsp), %rax
   62c42:      	leaq	0x28(%rsp), %r8
   62c47:      	leaq	0x20(%rsp), %rdi
   62c4c:      	leaq	0x10b75(%rip), %r9      # 0x737c8 <native_roots.0>
   62c53:      	movq	0x10(%rsp), %rcx
   62c58:      	addq	%rax, %rbp
   62c5b:      	addq	%rbp, %r12
   62c5e:      	movq	0x18(%rsp), %rbp
   62c63:      	cmpb	$0x0, 0x10c46(%rip)     # 0x738b0 <g.4>
   62c6a:      	je	0x6e9c5 <f.2+0x17805>
   62c70:      	cmpq	$0x0, 0x10c30(%rip)     # 0x738a8 <g.3>
   62c78:      	je	0x6e9c5 <f.2+0x17805>
   62c7e:      	addq	%r13, %r12
   62c81:      	addq	%rbp, %r12
   62c84:      	cmpq	$0x9, %r14
   62c88:      	jne	0x57a1a <f.2+0x85a>
   62c8e:      	leaq	(%r14,%r12), %rbp
   62c92:      	addq	$-0x8, %rbp
   62c96:      	movl	$0x1, %r12d
   62c9c:      	leaq	-0x9(%r14), %r13
   62ca0:      	jmp	0x687e5 <f.2+0x11625>
   62ca5:      	movq	$0x0, 0x50(%rsp)
   62cae:      	movq	$0x3, 0x38(%rsp)
   62cb7:      	xorl	%edi, %edi
   62cb9:      	leaq	-0x10(%r14), %rsi
   62cbd:      	callq	0x6e9d0 <f.3>
   62cc2:      	subq	$0x8, %rsp
   62cc6:      	cmpb	$0x0, 0x10be3(%rip)     # 0x738b0 <g.4>
   62ccd:      	je	0x6e9c5 <f.2+0x17805>
   62cd3:      	movq	%rax, 0x58(%rsp)
   62cd8:      	cmpq	$0x0, 0x10bc8(%rip)     # 0x738a8 <g.3>
   62ce0:      	je	0x6e9c5 <f.2+0x17805>
   62ce6:      	leaq	-0x11(%r14), %rsi
   62cea:      	movq	$0x0, 0x50(%rsp)
   62cf3:      	movq	$0x3, 0x38(%rsp)
   62cfc:      	xorl	%edi, %edi
   62cfe:      	callq	0x6e9d0 <f.3>
   62d03:      	subq	$0x8, %rsp
   62d07:      	movq	%rax, %rdx
   62d0a:      	addq	0x58(%rsp), %rdx
   62d0f:      	leaq	0x28(%rsp), %r8
   62d14:      	leaq	0x20(%rsp), %rdi
   62d19:      	leaq	0x10aa8(%rip), %r9      # 0x737c8 <native_roots.0>
   62d20:      	movq	0x10(%rsp), %rcx
   62d25:      	movq	0x18(%rsp), %rax
   62d2a:      	addq	%rdx, %r13
   62d2d:      	cmpb	$0x0, 0x10b7c(%rip)     # 0x738b0 <g.4>
   62d34:      	je	0x6e9c5 <f.2+0x17805>
   62d3a:      	cmpq	$0x0, 0x10b66(%rip)     # 0x738a8 <g.3>
   62d42:      	je	0x6e9c5 <f.2+0x17805>
   62d48:      	addq	%rbp, %r13
   62d4b:      	addq	%rax, %r13
   62d4e:      	cmpq	$0xd, %r14
   62d52:      	jbe	0x62d6b <f.2+0xbbab>
   62d54:      	cmpq	$0xe, %r14
   62d58:      	movq	%rcx, 0x10(%rsp)
   62d5d:      	jne	0x62d78 <f.2+0xbbb8>
   62d5f:      	movl	$0x1, %ebp
   62d64:      	xorl	%eax, %eax
   62d66:      	jmp	0x62eba <f.2+0xbcfa>
   62d6b:      	leaq	-0xc(%r14), %rbp
   62d6f:      	leaq	-0xc(%r14), %rsi
   62d73:      	jmp	0x66fc3 <f.2+0xfe03>
   62d78:      	leaq	-0xe(%r14), %rsi
   62d7c:      	movq	$0x0, 0x50(%rsp)
   62d85:      	movq	$0x3, 0x38(%rsp)
   62d8e:      	xorl	%edi, %edi
   62d90:      	callq	0x6e9d0 <f.3>
   62d95:      	subq	$0x8, %rsp
   62d99:      	cmpb	$0x0, 0x10b10(%rip)     # 0x738b0 <g.4>
   62da0:      	je	0x6e9c5 <f.2+0x17805>
   62da6:      	movq	%rax, 0x18(%rsp)
   62dab:      	cmpq	$0x0, 0x10af5(%rip)     # 0x738a8 <g.3>
   62db3:      	je	0x6e9c5 <f.2+0x17805>
   62db9:      	leaq	-0xf(%r14), %rsi
   62dbd:      	movq	$0x0, 0x50(%rsp)
   62dc6:      	movq	$0x3, 0x38(%rsp)
   62dcf:      	xorl	%edi, %edi
   62dd1:      	callq	0x6e9d0 <f.3>
   62dd6:      	subq	$0x8, %rsp
   62dda:      	cmpb	$0x0, 0x10acf(%rip)     # 0x738b0 <g.4>
   62de1:      	je	0x6e9c5 <f.2+0x17805>
   62de7:      	movq	%rax, %rbp
   62dea:      	cmpq	$0x0, 0x10ab6(%rip)     # 0x738a8 <g.3>
   62df2:      	leaq	0x28(%rsp), %r8
   62df7:      	leaq	0x109ca(%rip), %r9      # 0x737c8 <native_roots.0>
   62dfe:      	leaq	-0xe(%r14), %rax
   62e02:      	je	0x6e9c5 <f.2+0x17805>
   62e08:      	addq	0x18(%rsp), %rbp
   62e0d:      	cmpq	$0xf, %r14
   62e11:      	ja	0x62e22 <f.2+0xbc62>
   62e13:      	leaq	0x20(%rsp), %rdi
   62e18:      	movq	0x10(%rsp), %rcx
   62e1d:      	jmp	0x62eba <f.2+0xbcfa>
   62e22:      	movq	$0x0, 0x50(%rsp)
   62e2b:      	movq	$0x3, 0x38(%rsp)
   62e34:      	xorl	%edi, %edi
   62e36:      	leaq	-0xf(%r14), %rsi
   62e3a:      	callq	0x6e9d0 <f.3>
   62e3f:      	subq	$0x8, %rsp
   62e43:      	cmpb	$0x0, 0x10a66(%rip)     # 0x738b0 <g.4>
   62e4a:      	je	0x6e9c5 <f.2+0x17805>
   62e50:      	movq	%rax, 0x18(%rsp)
   62e55:      	cmpq	$0x0, 0x10a4b(%rip)     # 0x738a8 <g.3>
   62e5d:      	je	0x6e9c5 <f.2+0x17805>
   62e63:      	leaq	-0x10(%r14), %rsi
   62e67:      	movq	$0x0, 0x50(%rsp)
   62e70:      	movq	$0x3, 0x38(%rsp)
   62e79:      	xorl	%edi, %edi
   62e7b:      	callq	0x6e9d0 <f.3>
   62e80:      	subq	$0x8, %rsp
   62e84:      	cmpb	$0x0, 0x10a25(%rip)     # 0x738b0 <g.4>
   62e8b:      	je	0x6e9c5 <f.2+0x17805>
   62e91:      	cmpq	$0x0, 0x10a0f(%rip)     # 0x738a8 <g.3>
   62e99:      	leaq	0x28(%rsp), %r8
   62e9e:      	leaq	0x20(%rsp), %rdi
   62ea3:      	leaq	0x1091e(%rip), %r9      # 0x737c8 <native_roots.0>
   62eaa:      	movq	0x10(%rsp), %rcx
   62eaf:      	je	0x6e9c5 <f.2+0x17805>
   62eb5:      	addq	0x18(%rsp), %rax
   62eba:      	addq	%rbp, %rax
   62ebd:      	cmpq	$0xe, %r14
   62ec1:      	je	0x62ed5 <f.2+0xbd15>
   62ec3:      	cmpq	$0xf, %r14
   62ec7:      	jne	0x62eeb <f.2+0xbd2b>
   62ec9:      	movl	$0x1, %edx
   62ece:      	xorl	%ebp, %ebp
   62ed0:      	jmp	0x6302d <f.2+0xbe6d>
   62ed5:      	leaq	(%r14,%rax), %rbp
   62ed9:      	addq	$-0xd, %rbp
   62edd:      	movl	$0x1, %esi
   62ee2:      	leaq	-0xe(%r14), %rdx
   62ee6:      	jmp	0x66fc0 <f.2+0xfe00>
   62eeb:      	movq	%rax, 0x18(%rsp)
   62ef0:      	leaq	-0xf(%r14), %rbp
   62ef4:      	movq	$0x0, 0x50(%rsp)
   62efd:      	movq	$0x3, 0x38(%rsp)
   62f06:      	xorl	%edi, %edi
   62f08:      	movq	%rbp, %rsi
   62f0b:      	callq	0x6e9d0 <f.3>
   62f10:      	subq	$0x8, %rsp
   62f14:      	cmpb	$0x0, 0x10995(%rip)     # 0x738b0 <g.4>
   62f1b:      	je	0x6e9c5 <f.2+0x17805>
   62f21:      	movq	%rax, 0x58(%rsp)
   62f26:      	cmpq	$0x0, 0x1097a(%rip)     # 0x738a8 <g.3>
   62f2e:      	je	0x6e9c5 <f.2+0x17805>
   62f34:      	leaq	-0x10(%r14), %rsi
   62f38:      	movq	$0x0, 0x50(%rsp)
   62f41:      	movq	$0x3, 0x38(%rsp)
   62f4a:      	xorl	%edi, %edi
   62f4c:      	callq	0x6e9d0 <f.3>
   62f51:      	subq	$0x8, %rsp
   62f55:      	cmpb	$0x0, 0x10954(%rip)     # 0x738b0 <g.4>
   62f5c:      	je	0x6e9c5 <f.2+0x17805>
   62f62:      	movq	%rax, %rdx
   62f65:      	cmpq	$0x0, 0x1093b(%rip)     # 0x738a8 <g.3>
   62f6d:      	movq	0x18(%rsp), %rax
   62f72:      	je	0x6e9c5 <f.2+0x17805>
   62f78:      	addq	0x58(%rsp), %rdx
   62f7d:      	cmpq	$0x11, %r14
   62f81:      	jae	0x62f9e <f.2+0xbdde>
   62f83:      	leaq	0x28(%rsp), %r8
   62f88:      	leaq	0x20(%rsp), %rdi
   62f8d:      	leaq	0x10834(%rip), %r9      # 0x737c8 <native_roots.0>
   62f94:      	movq	0x10(%rsp), %rcx
   62f99:      	jmp	0x6302d <f.2+0xbe6d>
   62f9e:      	movq	%rdx, 0x58(%rsp)
   62fa3:      	movq	$0x0, 0x50(%rsp)
   62fac:      	movq	$0x3, 0x38(%rsp)
   62fb5:      	xorl	%edi, %edi
   62fb7:      	leaq	-0x10(%r14), %rsi
   62fbb:      	callq	0x6e9d0 <f.3>
   62fc0:      	subq	$0x8, %rsp
   62fc4:      	cmpb	$0x0, 0x108e5(%rip)     # 0x738b0 <g.4>
   62fcb:      	je	0x6e9c5 <f.2+0x17805>
   62fd1:      	movq	%rax, 0x60(%rsp)
   62fd6:      	cmpq	$0x0, 0x108ca(%rip)     # 0x738a8 <g.3>
   62fde:      	je	0x6e9c5 <f.2+0x17805>
   62fe4:      	leaq	-0x11(%r14), %rsi
   62fe8:      	movq	$0x0, 0x50(%rsp)
   62ff1:      	movq	$0x3, 0x38(%rsp)
   62ffa:      	xorl	%edi, %edi
   62ffc:      	callq	0x6e9d0 <f.3>
   63001:      	subq	$0x8, %rsp
   63005:      	movq	%rax, %rbp
   63008:      	addq	0x60(%rsp), %rbp
   6300d:      	leaq	0x28(%rsp), %r8
   63012:      	leaq	0x20(%rsp), %rdi
   63017:      	leaq	0x107aa(%rip), %r9      # 0x737c8 <native_roots.0>
   6301e:      	movq	0x10(%rsp), %rcx
   63023:      	movq	0x18(%rsp), %rax
   63028:      	movq	0x58(%rsp), %rdx
   6302d:      	cmpb	$0x0, 0x1087c(%rip)     # 0x738b0 <g.4>
   63034:      	je	0x6e9c5 <f.2+0x17805>
   6303a:      	cmpq	$0x0, 0x10866(%rip)     # 0x738a8 <g.3>
   63042:      	je	0x6e9c5 <f.2+0x17805>
   63048:      	addq	%rdx, %rbp
   6304b:      	addq	%rax, %rbp
   6304e:      	movq	%r14, %rsi
   63051:      	subq	$0xf, %rsi
   63055:      	jbe	0x63104 <f.2+0xbf44>
   6305b:      	movq	$0x0, 0x50(%rsp)
   63064:      	movq	$0x3, 0x38(%rsp)
   6306d:      	xorl	%edi, %edi
   6306f:      	movq	%rsi, 0x18(%rsp)
   63074:      	callq	0x6e9d0 <f.3>
   63079:      	subq	$0x8, %rsp
   6307d:      	cmpb	$0x0, 0x1082c(%rip)     # 0x738b0 <g.4>
   63084:      	je	0x6e9c5 <f.2+0x17805>
   6308a:      	movq	%rax, 0x58(%rsp)
   6308f:      	cmpq	$0x0, 0x10811(%rip)     # 0x738a8 <g.3>
   63097:      	je	0x6e9c5 <f.2+0x17805>
   6309d:      	leaq	-0x10(%r14), %rsi
   630a1:      	movq	$0x0, 0x50(%rsp)
   630aa:      	movq	$0x3, 0x38(%rsp)
   630b3:      	xorl	%edi, %edi
   630b5:      	callq	0x6e9d0 <f.3>
   630ba:      	subq	$0x8, %rsp
   630be:      	cmpb	$0x0, 0x107eb(%rip)     # 0x738b0 <g.4>
   630c5:      	je	0x6e9c5 <f.2+0x17805>
   630cb:      	cmpq	$0x0, 0x107d5(%rip)     # 0x738a8 <g.3>
   630d3:      	leaq	0x20(%rsp), %rdi
   630d8:      	movq	0x18(%rsp), %rsi
   630dd:      	je	0x6e9c5 <f.2+0x17805>
   630e3:      	movq	%rax, %rcx
   630e6:      	addq	0x58(%rsp), %rcx
   630eb:      	cmpq	$0x10, %r14
   630ef:      	leaq	-0x10(%r14), %rax
   630f3:      	jne	0x63110 <f.2+0xbf50>
   630f5:      	addq	%rcx, %rsi
   630f8:      	movl	$0x1, %edx
   630fd:      	xorl	%eax, %eax
   630ff:      	jmp	0x63240 <f.2+0xc080>
   63104:      	incq	%rsi
   63107:      	leaq	-0xe(%r14), %rdx
   6310b:      	jmp	0x66fc0 <f.2+0xfe00>
   63110:      	movq	%rcx, 0x58(%rsp)
   63115:      	movq	$0x0, 0x50(%rsp)
   6311e:      	movq	$0x3, 0x38(%rsp)
   63127:      	xorl	%edi, %edi
   63129:      	movq	%rax, %rsi
   6312c:      	callq	0x6e9d0 <f.3>
   63131:      	subq	$0x8, %rsp
   63135:      	cmpb	$0x0, 0x10774(%rip)     # 0x738b0 <g.4>
   6313c:      	je	0x6e9c5 <f.2+0x17805>
   63142:      	movq	%rax, 0x60(%rsp)
   63147:      	cmpq	$0x0, 0x10759(%rip)     # 0x738a8 <g.3>
   6314f:      	je	0x6e9c5 <f.2+0x17805>
   63155:      	leaq	-0x11(%r14), %rsi
   63159:      	movq	$0x0, 0x50(%rsp)
   63162:      	movq	$0x3, 0x38(%rsp)
   6316b:      	xorl	%edi, %edi
   6316d:      	callq	0x6e9d0 <f.3>
   63172:      	subq	$0x8, %rsp
   63176:      	cmpb	$0x0, 0x10733(%rip)     # 0x738b0 <g.4>
   6317d:      	je	0x6e9c5 <f.2+0x17805>
   63183:      	movq	%rax, 0x18(%rsp)
   63188:      	cmpq	$0x0, 0x10718(%rip)     # 0x738a8 <g.3>
   63190:      	je	0x6e9c5 <f.2+0x17805>
   63196:      	movq	$0x0, 0x50(%rsp)
   6319f:      	movq	$0x3, 0x38(%rsp)
   631a8:      	xorl	%edi, %edi
   631aa:      	leaq	-0x10(%r14), %rsi
   631ae:      	callq	0x6e9d0 <f.3>
   631b3:      	subq	$0x8, %rsp
   631b7:      	cmpb	$0x0, 0x106f2(%rip)     # 0x738b0 <g.4>
   631be:      	je	0x6e9c5 <f.2+0x17805>
   631c4:      	movq	%rax, 0x68(%rsp)
   631c9:      	cmpq	$0x0, 0x106d7(%rip)     # 0x738a8 <g.3>
   631d1:      	je	0x6e9c5 <f.2+0x17805>
   631d7:      	movq	$0x0, 0x50(%rsp)
   631e0:      	movq	$0x3, 0x38(%rsp)
   631e9:      	xorl	%edi, %edi
   631eb:      	leaq	-0x11(%r14), %rsi
   631ef:      	callq	0x6e9d0 <f.3>
   631f4:      	subq	$0x8, %rsp
   631f8:      	cmpb	$0x0, 0x106b1(%rip)     # 0x738b0 <g.4>
   631ff:      	je	0x6e9c5 <f.2+0x17805>
   63205:      	movq	%rax, %rdx
   63208:      	cmpq	$0x0, 0x10698(%rip)     # 0x738a8 <g.3>
   63210:      	leaq	0x20(%rsp), %rdi
   63215:      	movq	0x18(%rsp), %rsi
   6321a:      	leaq	-0x10(%r14), %rax
   6321e:      	movq	0x58(%rsp), %rcx
   63223:      	je	0x6e9c5 <f.2+0x17805>
   63229:      	addq	0x60(%rsp), %rsi
   6322e:      	addq	%rcx, %rsi
   63231:      	addq	0x68(%rsp), %rdx
   63236:      	cmpq	$0x12, %r14
   6323a:      	jae	0x66f2c <f.2+0xfd6c>
   63240:      	leaq	0x28(%rsp), %r8
   63245:      	leaq	0x1057c(%rip), %r9      # 0x737c8 <native_roots.0>
   6324c:      	movq	0x10(%rsp), %rcx
   63251:      	jmp	0x66fbd <f.2+0xfdfd>
   63256:      	movq	%rdx, 0x58(%rsp)
   6325b:      	movq	$0x0, 0x50(%rsp)
   63264:      	movq	$0x3, 0x38(%rsp)
   6326d:      	xorl	%edi, %edi
   6326f:      	leaq	-0x10(%r14), %rsi
   63273:      	callq	0x6e9d0 <f.3>
   63278:      	subq	$0x8, %rsp
   6327c:      	cmpb	$0x0, 0x1062d(%rip)     # 0x738b0 <g.4>
   63283:      	je	0x6e9c5 <f.2+0x17805>
   63289:      	cmpq	$0x0, 0x10617(%rip)     # 0x738a8 <g.3>
   63291:      	je	0x6e9c5 <f.2+0x17805>
   63297:      	movq	%rax, %r12
   6329a:      	leaq	-0x11(%r14), %rsi
   6329e:      	movq	$0x0, 0x50(%rsp)
   632a7:      	movq	$0x3, 0x38(%rsp)
   632b0:      	xorl	%edi, %edi
   632b2:      	callq	0x6e9d0 <f.3>
   632b7:      	subq	$0x8, %rsp
   632bb:      	movq	%rax, %rcx
   632be:      	addq	%r12, %rcx
   632c1:      	leaq	0x28(%rsp), %r8
   632c6:      	leaq	0x20(%rsp), %rdi
   632cb:      	leaq	0x104f6(%rip), %r9      # 0x737c8 <native_roots.0>
   632d2:      	movq	0x18(%rsp), %r12
   632d7:      	movq	0x10(%rsp), %rax
   632dc:      	movq	0x58(%rsp), %rdx
   632e1:      	addq	%rcx, %rdx
   632e4:      	addq	%rdx, %rbp
   632e7:      	cmpb	$0x0, 0x105c2(%rip)     # 0x738b0 <g.4>
   632ee:      	je	0x6e9c5 <f.2+0x17805>
   632f4:      	cmpq	$0x0, 0x105ac(%rip)     # 0x738a8 <g.3>
   632fc:      	je	0x6e9c5 <f.2+0x17805>
   63302:      	addq	%r13, %rbp
   63305:      	addq	%rax, %rbp
   63308:      	cmpq	$0xb, %r14
   6330c:      	jbe	0x633e0 <f.2+0xc220>
   63312:      	movl	$0x1, %r13d
   63318:      	cmpq	$0xc, %r14
   6331c:      	je	0x633f0 <f.2+0xc230>
   63322:      	movq	%r14, %r13
   63325:      	subq	$0xd, %r13
   63329:      	jbe	0x633ed <f.2+0xc22d>
   6332f:      	movq	%r12, 0x18(%rsp)
   63334:      	movq	$0x0, 0x50(%rsp)
   6333d:      	movq	$0x3, 0x38(%rsp)
   63346:      	xorl	%edi, %edi
   63348:      	movq	%r13, %rsi
   6334b:      	callq	0x6e9d0 <f.3>
   63350:      	subq	$0x8, %rsp
   63354:      	cmpb	$0x0, 0x10555(%rip)     # 0x738b0 <g.4>
   6335b:      	je	0x6e9c5 <f.2+0x17805>
   63361:      	cmpq	$0x0, 0x1053f(%rip)     # 0x738a8 <g.3>
   63369:      	je	0x6e9c5 <f.2+0x17805>
   6336f:      	movq	%rax, %r12
   63372:      	leaq	-0xe(%r14), %rsi
   63376:      	movq	$0x0, 0x50(%rsp)
   6337f:      	movq	$0x3, 0x38(%rsp)
   63388:      	xorl	%edi, %edi
   6338a:      	callq	0x6e9d0 <f.3>
   6338f:      	subq	$0x8, %rsp
   63393:      	cmpb	$0x0, 0x10516(%rip)     # 0x738b0 <g.4>
   6339a:      	je	0x6e9c5 <f.2+0x17805>
   633a0:      	cmpq	$0x0, 0x10500(%rip)     # 0x738a8 <g.3>
   633a8:      	je	0x6e9c5 <f.2+0x17805>
   633ae:      	addq	%r12, %rax
   633b1:      	cmpq	$0xe, %r14
   633b5:      	leaq	-0xe(%r14), %rsi
   633b9:      	jne	0x633fd <f.2+0xc23d>
   633bb:      	addq	%rax, %r13
   633be:      	movl	$0x1, %ecx
   633c3:      	xorl	%eax, %eax
   633c5:      	leaq	0x28(%rsp), %r8
   633ca:      	leaq	0x20(%rsp), %rdi
   633cf:      	leaq	0x103f2(%rip), %r9      # 0x737c8 <native_roots.0>
   633d6:      	movq	0x18(%rsp), %r12
   633db:      	jmp	0x635b1 <f.2+0xc3f1>
   633e0:      	leaq	-0xa(%r14), %rcx
   633e4:      	leaq	-0xa(%r14), %r13
   633e8:      	jmp	0x686ff <f.2+0x1153f>
   633ed:      	incq	%r13
   633f0:      	leaq	(%r14,%r13), %rax
   633f4:      	addq	$-0xc, %rax
   633f8:      	jmp	0x635d2 <f.2+0xc412>
   633fd:      	movq	%rax, 0x10(%rsp)
   63402:      	movq	$0x0, 0x50(%rsp)
   6340b:      	movq	$0x3, 0x38(%rsp)
   63414:      	xorl	%edi, %edi
   63416:      	callq	0x6e9d0 <f.3>
   6341b:      	subq	$0x8, %rsp
   6341f:      	cmpb	$0x0, 0x1048a(%rip)     # 0x738b0 <g.4>
   63426:      	je	0x6e9c5 <f.2+0x17805>
   6342c:      	movq	%rax, 0x58(%rsp)
   63431:      	cmpq	$0x0, 0x1046f(%rip)     # 0x738a8 <g.3>
   63439:      	je	0x6e9c5 <f.2+0x17805>
   6343f:      	leaq	-0xf(%r14), %rsi
   63443:      	movq	$0x0, 0x50(%rsp)
   6344c:      	movq	$0x3, 0x38(%rsp)
   63455:      	xorl	%edi, %edi
   63457:      	callq	0x6e9d0 <f.3>
   6345c:      	subq	$0x8, %rsp
   63460:      	cmpb	$0x0, 0x10449(%rip)     # 0x738b0 <g.4>
   63467:      	je	0x6e9c5 <f.2+0x17805>
   6346d:      	cmpq	$0x0, 0x10433(%rip)     # 0x738a8 <g.3>
   63475:      	leaq	-0xe(%r14), %rsi
   63479:      	je	0x6e9c5 <f.2+0x17805>
   6347f:      	movq	%rax, %r13
   63482:      	movq	$0x0, 0x50(%rsp)
   6348b:      	movq	$0x3, 0x38(%rsp)
   63494:      	xorl	%edi, %edi
   63496:      	callq	0x6e9d0 <f.3>
   6349b:      	subq	$0x8, %rsp
   6349f:      	cmpb	$0x0, 0x1040a(%rip)     # 0x738b0 <g.4>
   634a6:      	je	0x6e9c5 <f.2+0x17805>
   634ac:      	cmpq	$0x0, 0x103f4(%rip)     # 0x738a8 <g.3>
   634b4:      	je	0x6e9c5 <f.2+0x17805>
   634ba:      	movq	%rax, %r12
   634bd:      	movq	$0x0, 0x50(%rsp)
   634c6:      	movq	$0x3, 0x38(%rsp)
   634cf:      	xorl	%edi, %edi
   634d1:      	leaq	-0xf(%r14), %rsi
   634d5:      	callq	0x6e9d0 <f.3>
   634da:      	subq	$0x8, %rsp
   634de:      	cmpb	$0x0, 0x103cb(%rip)     # 0x738b0 <g.4>
   634e5:      	je	0x6e9c5 <f.2+0x17805>
   634eb:      	movq	%rax, %rcx
   634ee:      	cmpq	$0x0, 0x103b2(%rip)     # 0x738a8 <g.3>
   634f6:      	leaq	0x28(%rsp), %r8
   634fb:      	leaq	0x102c6(%rip), %r9      # 0x737c8 <native_roots.0>
   63502:      	leaq	-0xe(%r14), %rax
   63506:      	je	0x6e9c5 <f.2+0x17805>
   6350c:      	addq	0x58(%rsp), %r13
   63511:      	addq	0x10(%rsp), %r13
   63516:      	addq	%r12, %rcx
   63519:      	cmpq	$0x10, %r14
   6351d:      	jae	0x6352e <f.2+0xc36e>
   6351f:      	leaq	0x20(%rsp), %rdi
   63524:      	movq	0x18(%rsp), %r12
   63529:      	jmp	0x635b1 <f.2+0xc3f1>
   6352e:      	movq	%rcx, 0x10(%rsp)
   63533:      	movq	$0x0, 0x50(%rsp)
   6353c:      	movq	$0x3, 0x38(%rsp)
   63545:      	xorl	%edi, %edi
   63547:      	leaq	-0xf(%r14), %rsi
   6354b:      	callq	0x6e9d0 <f.3>
   63550:      	subq	$0x8, %rsp
   63554:      	cmpb	$0x0, 0x10355(%rip)     # 0x738b0 <g.4>
   6355b:      	je	0x6e9c5 <f.2+0x17805>
   63561:      	cmpq	$0x0, 0x1033f(%rip)     # 0x738a8 <g.3>
   63569:      	je	0x6e9c5 <f.2+0x17805>
   6356f:      	movq	%rax, %r12
   63572:      	leaq	-0x10(%r14), %rsi
   63576:      	movq	$0x0, 0x50(%rsp)
   6357f:      	movq	$0x3, 0x38(%rsp)
   63588:      	xorl	%edi, %edi
   6358a:      	callq	0x6e9d0 <f.3>
   6358f:      	subq	$0x8, %rsp
   63593:      	addq	%r12, %rax
   63596:      	leaq	0x28(%rsp), %r8
   6359b:      	leaq	0x20(%rsp), %rdi
   635a0:      	leaq	0x10221(%rip), %r9      # 0x737c8 <native_roots.0>
   635a7:      	movq	0x18(%rsp), %r12
   635ac:      	movq	0x10(%rsp), %rcx
   635b1:      	cmpb	$0x0, 0x102f8(%rip)     # 0x738b0 <g.4>
   635b8:      	je	0x6e9c5 <f.2+0x17805>
   635be:      	cmpq	$0x0, 0x102e2(%rip)     # 0x738a8 <g.3>
   635c6:      	je	0x6e9c5 <f.2+0x17805>
   635cc:      	addq	%rcx, %rax
   635cf:      	addq	%r13, %rax
   635d2:      	cmpq	$0xc, %r14
   635d6:      	je	0x636b7 <f.2+0xc4f7>
   635dc:      	movl	$0x1, %r13d
   635e2:      	cmpq	$0xd, %r14
   635e6:      	je	0x636d1 <f.2+0xc511>
   635ec:      	movq	%r14, %r13
   635ef:      	subq	$0xe, %r13
   635f3:      	jbe	0x636ce <f.2+0xc50e>
   635f9:      	movq	%rax, 0x58(%rsp)
   635fe:      	movq	%r12, 0x18(%rsp)
   63603:      	movq	$0x0, 0x50(%rsp)
   6360c:      	movq	$0x3, 0x38(%rsp)
   63615:      	xorl	%edi, %edi
   63617:      	movq	%r13, %rsi
   6361a:      	callq	0x6e9d0 <f.3>
   6361f:      	subq	$0x8, %rsp
   63623:      	cmpb	$0x0, 0x10286(%rip)     # 0x738b0 <g.4>
   6362a:      	je	0x6e9c5 <f.2+0x17805>
   63630:      	cmpq	$0x0, 0x10270(%rip)     # 0x738a8 <g.3>
   63638:      	je	0x6e9c5 <f.2+0x17805>
   6363e:      	movq	%rax, %r12
   63641:      	leaq	-0xf(%r14), %rsi
   63645:      	movq	$0x0, 0x50(%rsp)
   6364e:      	movq	$0x3, 0x38(%rsp)
   63657:      	xorl	%edi, %edi
   63659:      	callq	0x6e9d0 <f.3>
   6365e:      	subq	$0x8, %rsp
   63662:      	cmpb	$0x0, 0x10247(%rip)     # 0x738b0 <g.4>
   63669:      	je	0x6e9c5 <f.2+0x17805>
   6366f:      	movq	%rax, %rcx
   63672:      	cmpq	$0x0, 0x1022e(%rip)     # 0x738a8 <g.3>
   6367a:      	leaq	0x28(%rsp), %r8
   6367f:      	leaq	0x10142(%rip), %r9      # 0x737c8 <native_roots.0>
   63686:      	movq	0x58(%rsp), %rax
   6368b:      	je	0x6e9c5 <f.2+0x17805>
   63691:      	addq	%r12, %rcx
   63694:      	cmpq	$0xf, %r14
   63698:      	leaq	-0xf(%r14), %rsi
   6369c:      	jne	0x636da <f.2+0xc51a>
   6369e:      	addq	%rcx, %r13
   636a1:      	movl	$0x1, %ecx
   636a6:      	xorl	%edx, %edx
   636a8:      	leaq	0x20(%rsp), %rdi
   636ad:      	movq	0x18(%rsp), %r12
   636b2:      	jmp	0x6389f <f.2+0xc6df>
   636b7:      	leaq	(%r14,%rax), %rcx
   636bb:      	addq	$-0xb, %rcx
   636bf:      	movl	$0x1, %r13d
   636c5:      	leaq	-0xc(%r14), %rsi
   636c9:      	jmp	0x686fc <f.2+0x1153c>
   636ce:      	incq	%r13
   636d1:      	leaq	-0xd(%r14), %rcx
   636d5:      	jmp	0x638a2 <f.2+0xc6e2>
   636da:      	movq	%rcx, 0x10(%rsp)
   636df:      	movq	$0x0, 0x50(%rsp)
   636e8:      	movq	$0x3, 0x38(%rsp)
   636f1:      	xorl	%edi, %edi
   636f3:      	callq	0x6e9d0 <f.3>
   636f8:      	subq	$0x8, %rsp
   636fc:      	cmpb	$0x0, 0x101ad(%rip)     # 0x738b0 <g.4>
   63703:      	movq	0x18(%rsp), %r12
   63708:      	je	0x6e9c5 <f.2+0x17805>
   6370e:      	movq	%rax, 0x60(%rsp)
   63713:      	cmpq	$0x0, 0x1018d(%rip)     # 0x738a8 <g.3>
   6371b:      	je	0x6e9c5 <f.2+0x17805>
   63721:      	leaq	-0x10(%r14), %rsi
   63725:      	movq	$0x0, 0x50(%rsp)
   6372e:      	movq	$0x3, 0x38(%rsp)
   63737:      	xorl	%edi, %edi
   63739:      	callq	0x6e9d0 <f.3>
   6373e:      	subq	$0x8, %rsp
   63742:      	cmpb	$0x0, 0x10167(%rip)     # 0x738b0 <g.4>
   63749:      	je	0x6e9c5 <f.2+0x17805>
   6374f:      	cmpq	$0x0, 0x10151(%rip)     # 0x738a8 <g.3>
   63757:      	leaq	-0xf(%r14), %rsi
   6375b:      	je	0x6e9c5 <f.2+0x17805>
   63761:      	movq	%rax, %r13
   63764:      	movq	$0x0, 0x50(%rsp)
   6376d:      	movq	$0x3, 0x38(%rsp)
   63776:      	xorl	%edi, %edi
   63778:      	callq	0x6e9d0 <f.3>
   6377d:      	subq	$0x8, %rsp
   63781:      	cmpb	$0x0, 0x10128(%rip)     # 0x738b0 <g.4>
   63788:      	je	0x6e9c5 <f.2+0x17805>
   6378e:      	movq	%rax, 0x68(%rsp)
   63793:      	cmpq	$0x0, 0x1010d(%rip)     # 0x738a8 <g.3>
   6379b:      	je	0x6e9c5 <f.2+0x17805>
   637a1:      	movq	$0x0, 0x50(%rsp)
   637aa:      	movq	$0x3, 0x38(%rsp)
   637b3:      	xorl	%edi, %edi
   637b5:      	leaq	-0x10(%r14), %rsi
   637b9:      	callq	0x6e9d0 <f.3>
   637be:      	subq	$0x8, %rsp
   637c2:      	cmpb	$0x0, 0x100e7(%rip)     # 0x738b0 <g.4>
   637c9:      	je	0x6e9c5 <f.2+0x17805>
   637cf:      	movq	%rax, %rcx
   637d2:      	cmpq	$0x0, 0x100ce(%rip)     # 0x738a8 <g.3>
   637da:      	leaq	0x28(%rsp), %r8
   637df:      	leaq	0xffe2(%rip), %r9       # 0x737c8 <native_roots.0>
   637e6:      	movq	0x58(%rsp), %rax
   637eb:      	leaq	-0xf(%r14), %rdx
   637ef:      	je	0x6e9c5 <f.2+0x17805>
   637f5:      	addq	0x60(%rsp), %r13
   637fa:      	addq	0x10(%rsp), %r13
   637ff:      	addq	0x68(%rsp), %rcx
   63804:      	cmpq	$0x11, %r14
   63808:      	jae	0x63814 <f.2+0xc654>
   6380a:      	leaq	0x20(%rsp), %rdi
   6380f:      	jmp	0x6389f <f.2+0xc6df>
   63814:      	movq	%rcx, 0x10(%rsp)
   63819:      	movq	$0x0, 0x50(%rsp)
   63822:      	movq	$0x3, 0x38(%rsp)
   6382b:      	xorl	%edi, %edi
   6382d:      	leaq	-0x10(%r14), %rsi
   63831:      	callq	0x6e9d0 <f.3>
   63836:      	subq	$0x8, %rsp
   6383a:      	cmpb	$0x0, 0x1006f(%rip)     # 0x738b0 <g.4>
   63841:      	je	0x6e9c5 <f.2+0x17805>
   63847:      	cmpq	$0x0, 0x10059(%rip)     # 0x738a8 <g.3>
   6384f:      	je	0x6e9c5 <f.2+0x17805>
   63855:      	movq	%rax, %r12
   63858:      	leaq	-0x11(%r14), %rsi
   6385c:      	movq	$0x0, 0x50(%rsp)
   63865:      	movq	$0x3, 0x38(%rsp)
   6386e:      	xorl	%edi, %edi
   63870:      	callq	0x6e9d0 <f.3>
   63875:      	subq	$0x8, %rsp
   63879:      	movq	%rax, %rdx
   6387c:      	addq	%r12, %rdx
   6387f:      	leaq	0x28(%rsp), %r8
   63884:      	leaq	0x20(%rsp), %rdi
   63889:      	leaq	0xff38(%rip), %r9       # 0x737c8 <native_roots.0>
   63890:      	movq	0x10(%rsp), %rcx
   63895:      	movq	0x18(%rsp), %r12
   6389a:      	movq	0x58(%rsp), %rax
   6389f:      	addq	%rdx, %rcx
   638a2:      	cmpb	$0x0, 0x10007(%rip)     # 0x738b0 <g.4>
   638a9:      	je	0x6e9c5 <f.2+0x17805>
   638af:      	cmpq	$0x0, 0xfff1(%rip)      # 0x738a8 <g.3>
   638b7:      	je	0x6e9c5 <f.2+0x17805>
   638bd:      	addq	%r13, %rcx
   638c0:      	addq	%rax, %rcx
   638c3:      	cmpq	$0xd, %r14
   638c7:      	jbe	0x638e9 <f.2+0xc729>
   638c9:      	cmpq	$0xe, %r14
   638cd:      	movq	%rcx, 0x10(%rsp)
   638d2:      	movq	%r12, 0x18(%rsp)
   638d7:      	jne	0x638f6 <f.2+0xc736>
   638d9:      	movl	$0x1, %r13d
   638df:      	xorl	%eax, %eax
   638e1:      	addq	%r13, %rax
   638e4:      	jmp	0x63a40 <f.2+0xc880>
   638e9:      	leaq	-0xc(%r14), %r13
   638ed:      	leaq	-0xc(%r14), %rsi
   638f1:      	jmp	0x686fc <f.2+0x1153c>
   638f6:      	leaq	-0xe(%r14), %rsi
   638fa:      	movq	$0x0, 0x50(%rsp)
   63903:      	movq	$0x3, 0x38(%rsp)
   6390c:      	xorl	%edi, %edi
   6390e:      	callq	0x6e9d0 <f.3>
   63913:      	subq	$0x8, %rsp
   63917:      	cmpb	$0x0, 0xff92(%rip)      # 0x738b0 <g.4>
   6391e:      	je	0x6e9c5 <f.2+0x17805>
   63924:      	cmpq	$0x0, 0xff7c(%rip)      # 0x738a8 <g.3>
   6392c:      	je	0x6e9c5 <f.2+0x17805>
   63932:      	movq	%rax, %r12
   63935:      	leaq	-0xf(%r14), %rsi
   63939:      	movq	$0x0, 0x50(%rsp)
   63942:      	movq	$0x3, 0x38(%rsp)
   6394b:      	xorl	%edi, %edi
   6394d:      	callq	0x6e9d0 <f.3>
   63952:      	subq	$0x8, %rsp
   63956:      	cmpb	$0x0, 0xff53(%rip)      # 0x738b0 <g.4>
   6395d:      	je	0x6e9c5 <f.2+0x17805>
   63963:      	movq	%rax, %r13
   63966:      	cmpq	$0x0, 0xff3a(%rip)      # 0x738a8 <g.3>
   6396e:      	leaq	-0xe(%r14), %rax
   63972:      	je	0x6e9c5 <f.2+0x17805>
   63978:      	addq	%r12, %r13
   6397b:      	cmpq	$0xf, %r14
   6397f:      	ja	0x639a4 <f.2+0xc7e4>
   63981:      	leaq	0x28(%rsp), %r8
   63986:      	leaq	0x20(%rsp), %rdi
   6398b:      	leaq	0xfe36(%rip), %r9       # 0x737c8 <native_roots.0>
   63992:      	movq	0x10(%rsp), %rcx
   63997:      	movq	0x18(%rsp), %r12
   6399c:      	addq	%r13, %rax
   6399f:      	jmp	0x63a40 <f.2+0xc880>
   639a4:      	movq	$0x0, 0x50(%rsp)
   639ad:      	movq	$0x3, 0x38(%rsp)
   639b6:      	xorl	%edi, %edi
   639b8:      	leaq	-0xf(%r14), %rsi
   639bc:      	callq	0x6e9d0 <f.3>
   639c1:      	subq	$0x8, %rsp
   639c5:      	cmpb	$0x0, 0xfee4(%rip)      # 0x738b0 <g.4>
   639cc:      	je	0x6e9c5 <f.2+0x17805>
   639d2:      	cmpq	$0x0, 0xfece(%rip)      # 0x738a8 <g.3>
   639da:      	je	0x6e9c5 <f.2+0x17805>
   639e0:      	movq	%rax, %r12
   639e3:      	leaq	-0x10(%r14), %rsi
   639e7:      	movq	$0x0, 0x50(%rsp)
   639f0:      	movq	$0x3, 0x38(%rsp)
   639f9:      	xorl	%edi, %edi
   639fb:      	callq	0x6e9d0 <f.3>
   63a00:      	subq	$0x8, %rsp
   63a04:      	cmpb	$0x0, 0xfea5(%rip)      # 0x738b0 <g.4>
   63a0b:      	je	0x6e9c5 <f.2+0x17805>
   63a11:      	cmpq	$0x0, 0xfe8f(%rip)      # 0x738a8 <g.3>
   63a19:      	leaq	0x28(%rsp), %r8
   63a1e:      	leaq	0x20(%rsp), %rdi
   63a23:      	leaq	0xfd9e(%rip), %r9       # 0x737c8 <native_roots.0>
   63a2a:      	movq	0x10(%rsp), %rcx
   63a2f:      	je	0x6e9c5 <f.2+0x17805>
   63a35:      	addq	%r12, %rax
   63a38:      	addq	%r13, %rax
   63a3b:      	movq	0x18(%rsp), %r12
   63a40:      	cmpq	$0xe, %r14
   63a44:      	je	0x63a59 <f.2+0xc899>
   63a46:      	cmpq	$0xf, %r14
   63a4a:      	jne	0x63a6f <f.2+0xc8af>
   63a4c:      	movl	$0x1, %edx
   63a51:      	xorl	%r13d, %r13d
   63a54:      	jmp	0x63bb3 <f.2+0xc9f3>
   63a59:      	leaq	(%r14,%rax), %r13
   63a5d:      	addq	$-0xd, %r13
   63a61:      	movl	$0x1, %esi
   63a66:      	leaq	-0xe(%r14), %r10
   63a6a:      	jmp	0x686f9 <f.2+0x11539>
   63a6f:      	movq	%rax, 0x58(%rsp)
   63a74:      	leaq	-0xf(%r14), %r13
   63a78:      	movq	$0x0, 0x50(%rsp)
   63a81:      	movq	$0x3, 0x38(%rsp)
   63a8a:      	xorl	%edi, %edi
   63a8c:      	movq	%r13, %rsi
   63a8f:      	callq	0x6e9d0 <f.3>
   63a94:      	subq	$0x8, %rsp
   63a98:      	cmpb	$0x0, 0xfe11(%rip)      # 0x738b0 <g.4>
   63a9f:      	je	0x6e9c5 <f.2+0x17805>
   63aa5:      	cmpq	$0x0, 0xfdfb(%rip)      # 0x738a8 <g.3>
   63aad:      	je	0x6e9c5 <f.2+0x17805>
   63ab3:      	movq	%rax, %r12
   63ab6:      	leaq	-0x10(%r14), %rsi
   63aba:      	movq	$0x0, 0x50(%rsp)
   63ac3:      	movq	$0x3, 0x38(%rsp)
   63acc:      	xorl	%edi, %edi
   63ace:      	callq	0x6e9d0 <f.3>
   63ad3:      	subq	$0x8, %rsp
   63ad7:      	cmpb	$0x0, 0xfdd2(%rip)      # 0x738b0 <g.4>
   63ade:      	je	0x6e9c5 <f.2+0x17805>
   63ae4:      	movq	%rax, %rdx
   63ae7:      	cmpq	$0x0, 0xfdb9(%rip)      # 0x738a8 <g.3>
   63aef:      	leaq	0x28(%rsp), %r8
   63af4:      	leaq	0xfccd(%rip), %r9       # 0x737c8 <native_roots.0>
   63afb:      	movq	0x10(%rsp), %rcx
   63b00:      	movq	0x58(%rsp), %rax
   63b05:      	je	0x6e9c5 <f.2+0x17805>
   63b0b:      	addq	%r12, %rdx
   63b0e:      	cmpq	$0x11, %r14
   63b12:      	jae	0x63b23 <f.2+0xc963>
   63b14:      	leaq	0x20(%rsp), %rdi
   63b19:      	movq	0x18(%rsp), %r12
   63b1e:      	jmp	0x63bb3 <f.2+0xc9f3>
   63b23:      	movq	%rdx, 0x60(%rsp)
   63b28:      	movq	$0x0, 0x50(%rsp)
   63b31:      	movq	$0x3, 0x38(%rsp)
   63b3a:      	xorl	%edi, %edi
   63b3c:      	leaq	-0x10(%r14), %rsi
   63b40:      	callq	0x6e9d0 <f.3>
   63b45:      	subq	$0x8, %rsp
   63b49:      	cmpb	$0x0, 0xfd60(%rip)      # 0x738b0 <g.4>
   63b50:      	je	0x6e9c5 <f.2+0x17805>
   63b56:      	cmpq	$0x0, 0xfd4a(%rip)      # 0x738a8 <g.3>
   63b5e:      	je	0x6e9c5 <f.2+0x17805>
   63b64:      	movq	%rax, %r12
   63b67:      	leaq	-0x11(%r14), %rsi
   63b6b:      	movq	$0x0, 0x50(%rsp)
   63b74:      	movq	$0x3, 0x38(%rsp)
   63b7d:      	xorl	%edi, %edi
   63b7f:      	callq	0x6e9d0 <f.3>
   63b84:      	subq	$0x8, %rsp
   63b88:      	movq	%rax, %r13
   63b8b:      	addq	%r12, %r13
   63b8e:      	leaq	0x28(%rsp), %r8
   63b93:      	leaq	0x20(%rsp), %rdi
   63b98:      	leaq	0xfc29(%rip), %r9       # 0x737c8 <native_roots.0>
   63b9f:      	movq	0x10(%rsp), %rcx
   63ba4:      	movq	0x18(%rsp), %r12
   63ba9:      	movq	0x58(%rsp), %rax
   63bae:      	movq	0x60(%rsp), %rdx
   63bb3:      	cmpb	$0x0, 0xfcf6(%rip)      # 0x738b0 <g.4>
   63bba:      	je	0x6e9c5 <f.2+0x17805>
   63bc0:      	cmpq	$0x0, 0xfce0(%rip)      # 0x738a8 <g.3>
   63bc8:      	je	0x6e9c5 <f.2+0x17805>
   63bce:      	addq	%rdx, %r13
   63bd1:      	addq	%rax, %r13
   63bd4:      	movq	%r14, %rsi
   63bd7:      	subq	$0xf, %rsi
   63bdb:      	jbe	0x63c87 <f.2+0xcac7>
   63be1:      	movq	$0x0, 0x50(%rsp)
   63bea:      	movq	$0x3, 0x38(%rsp)
   63bf3:      	xorl	%edi, %edi
   63bf5:      	movq	%rsi, 0x58(%rsp)
   63bfa:      	callq	0x6e9d0 <f.3>
   63bff:      	subq	$0x8, %rsp
   63c03:      	cmpb	$0x0, 0xfca6(%rip)      # 0x738b0 <g.4>
   63c0a:      	je	0x6e9c5 <f.2+0x17805>
   63c10:      	cmpq	$0x0, 0xfc90(%rip)      # 0x738a8 <g.3>
   63c18:      	je	0x6e9c5 <f.2+0x17805>
   63c1e:      	movq	%rax, %r12
   63c21:      	leaq	-0x10(%r14), %rsi
   63c25:      	movq	$0x0, 0x50(%rsp)
   63c2e:      	movq	$0x3, 0x38(%rsp)
   63c37:      	xorl	%edi, %edi
   63c39:      	callq	0x6e9d0 <f.3>
   63c3e:      	subq	$0x8, %rsp
   63c42:      	cmpb	$0x0, 0xfc67(%rip)      # 0x738b0 <g.4>
   63c49:      	je	0x6e9c5 <f.2+0x17805>
   63c4f:      	cmpq	$0x0, 0xfc51(%rip)      # 0x738a8 <g.3>
   63c57:      	movq	0x10(%rsp), %rcx
   63c5c:      	movq	0x58(%rsp), %rsi
   63c61:      	je	0x6e9c5 <f.2+0x17805>
   63c67:      	movq	%rax, %rdx
   63c6a:      	addq	%r12, %rdx
   63c6d:      	cmpq	$0x10, %r14
   63c71:      	leaq	-0x10(%r14), %rax
   63c75:      	jne	0x63c93 <f.2+0xcad3>
   63c77:      	addq	%rdx, %rsi
   63c7a:      	movl	$0x1, %r10d
   63c80:      	xorl	%eax, %eax
   63c82:      	jmp	0x63dbf <f.2+0xcbff>
   63c87:      	incq	%rsi
   63c8a:      	leaq	-0xe(%r14), %r10
   63c8e:      	jmp	0x686f9 <f.2+0x11539>
   63c93:      	movq	%rdx, 0x60(%rsp)
   63c98:      	movq	$0x0, 0x50(%rsp)
   63ca1:      	movq	$0x3, 0x38(%rsp)
   63caa:      	xorl	%edi, %edi
   63cac:      	movq	%rax, %rsi
   63caf:      	callq	0x6e9d0 <f.3>
   63cb4:      	subq	$0x8, %rsp
   63cb8:      	cmpb	$0x0, 0xfbf1(%rip)      # 0x738b0 <g.4>
   63cbf:      	je	0x6e9c5 <f.2+0x17805>
   63cc5:      	cmpq	$0x0, 0xfbdb(%rip)      # 0x738a8 <g.3>
   63ccd:      	je	0x6e9c5 <f.2+0x17805>
   63cd3:      	movq	%rax, 0x68(%rsp)
   63cd8:      	leaq	-0x11(%r14), %rsi
   63cdc:      	movq	$0x0, 0x50(%rsp)
   63ce5:      	movq	$0x3, 0x38(%rsp)
   63cee:      	xorl	%edi, %edi
   63cf0:      	callq	0x6e9d0 <f.3>
   63cf5:      	subq	$0x8, %rsp
   63cf9:      	cmpb	$0x0, 0xfbb0(%rip)      # 0x738b0 <g.4>
   63d00:      	je	0x6e9c5 <f.2+0x17805>
   63d06:      	movq	%rax, 0x58(%rsp)
   63d0b:      	cmpq	$0x0, 0xfb95(%rip)      # 0x738a8 <g.3>
   63d13:      	je	0x6e9c5 <f.2+0x17805>
   63d19:      	movq	$0x0, 0x50(%rsp)
   63d22:      	movq	$0x3, 0x38(%rsp)
   63d2b:      	xorl	%edi, %edi
   63d2d:      	leaq	-0x10(%r14), %rsi
   63d31:      	callq	0x6e9d0 <f.3>
   63d36:      	subq	$0x8, %rsp
   63d3a:      	cmpb	$0x0, 0xfb6f(%rip)      # 0x738b0 <g.4>
   63d41:      	je	0x6e9c5 <f.2+0x17805>
   63d47:      	cmpq	$0x0, 0xfb59(%rip)      # 0x738a8 <g.3>
   63d4f:      	je	0x6e9c5 <f.2+0x17805>
   63d55:      	movq	%rax, %r12
   63d58:      	movq	$0x0, 0x50(%rsp)
   63d61:      	movq	$0x3, 0x38(%rsp)
   63d6a:      	xorl	%edi, %edi
   63d6c:      	leaq	-0x11(%r14), %rsi
   63d70:      	callq	0x6e9d0 <f.3>
   63d75:      	subq	$0x8, %rsp
   63d79:      	cmpb	$0x0, 0xfb30(%rip)      # 0x738b0 <g.4>
   63d80:      	je	0x6e9c5 <f.2+0x17805>
   63d86:      	movq	%rax, %r10
   63d89:      	cmpq	$0x0, 0xfb17(%rip)      # 0x738a8 <g.3>
   63d91:      	movq	0x10(%rsp), %rcx
   63d96:      	movq	0x58(%rsp), %rsi
   63d9b:      	leaq	-0x10(%r14), %rax
   63d9f:      	movq	0x60(%rsp), %rdx
   63da4:      	je	0x6e9c5 <f.2+0x17805>
   63daa:      	addq	0x68(%rsp), %rsi
   63daf:      	addq	%rdx, %rsi
   63db2:      	addq	%r12, %r10
   63db5:      	cmpq	$0x12, %r14
   63db9:      	jae	0x68664 <f.2+0x114a4>
   63dbf:      	leaq	0x28(%rsp), %r8
   63dc4:      	leaq	0x20(%rsp), %rdi
   63dc9:      	leaq	0xf9f8(%rip), %r9       # 0x737c8 <native_roots.0>
   63dd0:      	movq	0x18(%rsp), %r12
   63dd5:      	jmp	0x686f6 <f.2+0x11536>
   63dda:      	movq	%rsi, 0x58(%rsp)
   63ddf:      	movq	%rdx, 0x18(%rsp)
   63de4:      	movq	$0x0, 0x50(%rsp)
   63ded:      	movq	$0x3, 0x38(%rsp)
   63df6:      	xorl	%edi, %edi
   63df8:      	leaq	-0x11(%r14), %rsi
   63dfc:      	callq	0x6e9d0 <f.3>
   63e01:      	subq	$0x8, %rsp
   63e05:      	cmpb	$0x0, 0xfaa4(%rip)      # 0x738b0 <g.4>
   63e0c:      	je	0x6e9c5 <f.2+0x17805>
   63e12:      	movq	%rax, 0x60(%rsp)
   63e17:      	cmpq	$0x0, 0xfa89(%rip)      # 0x738a8 <g.3>
   63e1f:      	je	0x6e9c5 <f.2+0x17805>
   63e25:      	leaq	-0x12(%r14), %rsi
   63e29:      	movq	$0x0, 0x50(%rsp)
   63e32:      	movq	$0x3, 0x38(%rsp)
   63e3b:      	xorl	%edi, %edi
   63e3d:      	callq	0x6e9d0 <f.3>
   63e42:      	subq	$0x8, %rsp
   63e46:      	movq	%rax, %rcx
   63e49:      	addq	0x60(%rsp), %rcx
   63e4e:      	leaq	0x28(%rsp), %r8
   63e53:      	leaq	0x20(%rsp), %rdi
   63e58:      	leaq	0xf969(%rip), %r9       # 0x737c8 <native_roots.0>
   63e5f:      	movq	0x10(%rsp), %rax
   63e64:      	movq	0x18(%rsp), %rdx
   63e69:      	movq	0x58(%rsp), %rsi
   63e6e:      	addq	%rcx, %rsi
   63e71:      	addq	%rsi, %rdx
   63e74:      	addq	%rdx, %r13
   63e77:      	addq	%r13, %r15
   63e7a:      	cmpb	$0x0, 0xfa2f(%rip)      # 0x738b0 <g.4>
   63e81:      	je	0x6e9c5 <f.2+0x17805>
   63e87:      	cmpq	$0x0, 0xfa19(%rip)      # 0x738a8 <g.3>
   63e8f:      	je	0x6e9c5 <f.2+0x17805>
   63e95:      	addq	%rbp, %r15
   63e98:      	addq	%rax, %r15
   63e9b:      	cmpq	$0x8, %r14
   63e9f:      	jbe	0x63f82 <f.2+0xcdc2>
   63ea5:      	movl	$0x1, %eax
   63eaa:      	cmpq	$0x9, %r14
   63eae:      	je	0x63fa6 <f.2+0xcde6>
   63eb4:      	cmpq	$0xa, %r14
   63eb8:      	jbe	0x63fa2 <f.2+0xcde2>
   63ebe:      	movl	$0x1, %r13d
   63ec4:      	cmpq	$0xb, %r14
   63ec8:      	je	0x640c3 <f.2+0xcf03>
   63ece:      	movq	%r14, %r13
   63ed1:      	subq	$0xc, %r13
   63ed5:      	jbe	0x640c0 <f.2+0xcf00>
   63edb:      	movq	$0x0, 0x50(%rsp)
   63ee4:      	movq	$0x3, 0x38(%rsp)
   63eed:      	xorl	%edi, %edi
   63eef:      	movq	%r13, %rsi
   63ef2:      	callq	0x6e9d0 <f.3>
   63ef7:      	subq	$0x8, %rsp
   63efb:      	cmpb	$0x0, 0xf9ae(%rip)      # 0x738b0 <g.4>
   63f02:      	je	0x6e9c5 <f.2+0x17805>
   63f08:      	cmpq	$0x0, 0xf998(%rip)      # 0x738a8 <g.3>
   63f10:      	je	0x6e9c5 <f.2+0x17805>
   63f16:      	movq	%rax, %rbp
   63f19:      	leaq	-0xd(%r14), %rsi
   63f1d:      	movq	$0x0, 0x50(%rsp)
   63f26:      	movq	$0x3, 0x38(%rsp)
   63f2f:      	xorl	%edi, %edi
   63f31:      	callq	0x6e9d0 <f.3>
   63f36:      	subq	$0x8, %rsp
   63f3a:      	cmpb	$0x0, 0xf96f(%rip)      # 0x738b0 <g.4>
   63f41:      	je	0x6e9c5 <f.2+0x17805>
   63f47:      	cmpq	$0x0, 0xf959(%rip)      # 0x738a8 <g.3>
   63f4f:      	leaq	0x20(%rsp), %rdi
   63f54:      	je	0x6e9c5 <f.2+0x17805>
   63f5a:      	addq	%rbp, %rax
   63f5d:      	cmpq	$0xd, %r14
   63f61:      	jne	0x640e0 <f.2+0xcf20>
   63f67:      	addq	%rax, %r13
   63f6a:      	movl	$0x1, %eax
   63f6f:      	xorl	%ebp, %ebp
   63f71:      	leaq	0x28(%rsp), %r8
   63f76:      	leaq	0xf84b(%rip), %r9       # 0x737c8 <native_roots.0>
   63f7d:      	jmp	0x6428f <f.2+0xd0cf>
   63f82:      	leaq	-0x7(%r14), %r13
   63f86:      	leaq	-0x7(%r14), %rbp
   63f8a:      	addq	%rbp, %r13
   63f8d:      	addq	%r13, %r15
   63f90:      	cmpb	$0x0, 0xf919(%rip)      # 0x738b0 <g.4>
   63f97:      	jne	0x57357 <f.2+0x197>
   63f9d:      	jmp	0x6e9c5 <f.2+0x17805>
   63fa2:      	leaq	-0x9(%r14), %rax
   63fa6:      	leaq	(%r14,%rax), %rsi
   63faa:      	addq	$-0x9, %rsi
   63fae:      	cmpq	$0x9, %r14
   63fb2:      	je	0x6551e <f.2+0xe35e>
   63fb8:      	movl	$0x1, %ebp
   63fbd:      	cmpq	$0xa, %r14
   63fc1:      	je	0x640aa <f.2+0xceea>
   63fc7:      	cmpq	$0xb, %r14
   63fcb:      	jbe	0x640a6 <f.2+0xcee6>
   63fd1:      	movl	$0x1, %r13d
   63fd7:      	cmpq	$0xc, %r14
   63fdb:      	je	0x640d3 <f.2+0xcf13>
   63fe1:      	movq	%r14, %r13
   63fe4:      	subq	$0xd, %r13
   63fe8:      	jbe	0x640d0 <f.2+0xcf10>
   63fee:      	movq	%rsi, 0x10(%rsp)
   63ff3:      	movq	$0x0, 0x50(%rsp)
   63ffc:      	movq	$0x3, 0x38(%rsp)
   64005:      	xorl	%edi, %edi
   64007:      	movq	%r13, %rsi
   6400a:      	callq	0x6e9d0 <f.3>
   6400f:      	subq	$0x8, %rsp
   64013:      	cmpb	$0x0, 0xf896(%rip)      # 0x738b0 <g.4>
   6401a:      	je	0x6e9c5 <f.2+0x17805>
   64020:      	cmpq	$0x0, 0xf880(%rip)      # 0x738a8 <g.3>
   64028:      	je	0x6e9c5 <f.2+0x17805>
   6402e:      	movq	%rax, %rbp
   64031:      	leaq	-0xe(%r14), %rsi
   64035:      	movq	$0x0, 0x50(%rsp)
   6403e:      	movq	$0x3, 0x38(%rsp)
   64047:      	xorl	%edi, %edi
   64049:      	callq	0x6e9d0 <f.3>
   6404e:      	subq	$0x8, %rsp
   64052:      	cmpb	$0x0, 0xf857(%rip)      # 0x738b0 <g.4>
   64059:      	je	0x6e9c5 <f.2+0x17805>
   6405f:      	cmpq	$0x0, 0xf841(%rip)      # 0x738a8 <g.3>
   64067:      	movq	0x10(%rsp), %rsi
   6406c:      	je	0x6e9c5 <f.2+0x17805>
   64072:      	movq	%rax, %rcx
   64075:      	addq	%rbp, %rcx
   64078:      	cmpq	$0xe, %r14
   6407c:      	leaq	-0xe(%r14), %rax
   64080:      	jne	0x643a9 <f.2+0xd1e9>
   64086:      	addq	%rcx, %r13
   64089:      	movl	$0x1, %ecx
   6408e:      	xorl	%eax, %eax
   64090:      	leaq	0x28(%rsp), %r8
   64095:      	leaq	0x20(%rsp), %rdi
   6409a:      	leaq	0xf727(%rip), %r9       # 0x737c8 <native_roots.0>
   640a1:      	jmp	0x64c47 <f.2+0xda87>
   640a6:      	leaq	-0xa(%r14), %rbp
   640aa:      	leaq	-0xa(%r14), %r13
   640ae:      	cmpb	$0x0, 0xf7fb(%rip)      # 0x738b0 <g.4>
   640b5:      	jne	0x655db <f.2+0xe41b>
   640bb:      	jmp	0x6e9c5 <f.2+0x17805>
   640c0:      	incq	%r13
   640c3:      	leaq	(%r14,%r13), %rbp
   640c7:      	addq	$-0xb, %rbp
   640cb:      	jmp	0x642b0 <f.2+0xd0f0>
   640d0:      	incq	%r13
   640d3:      	leaq	(%r14,%r13), %rax
   640d7:      	addq	$-0xc, %rax
   640db:      	jmp	0x64c68 <f.2+0xdaa8>
   640e0:      	movq	%rax, 0x10(%rsp)
   640e5:      	movq	$0x0, 0x50(%rsp)
   640ee:      	movq	$0x3, 0x38(%rsp)
   640f7:      	xorl	%edi, %edi
   640f9:      	leaq	-0xd(%r14), %rbp
   640fd:      	movq	%rbp, %rsi
   64100:      	callq	0x6e9d0 <f.3>
   64105:      	subq	$0x8, %rsp
   64109:      	cmpb	$0x0, 0xf7a0(%rip)      # 0x738b0 <g.4>
   64110:      	je	0x6e9c5 <f.2+0x17805>
   64116:      	movq	%rax, 0x18(%rsp)
   6411b:      	cmpq	$0x0, 0xf785(%rip)      # 0x738a8 <g.3>
   64123:      	je	0x6e9c5 <f.2+0x17805>
   64129:      	leaq	-0xe(%r14), %rsi
   6412d:      	movq	$0x0, 0x50(%rsp)
   64136:      	movq	$0x3, 0x38(%rsp)
   6413f:      	xorl	%edi, %edi
   64141:      	callq	0x6e9d0 <f.3>
   64146:      	subq	$0x8, %rsp
   6414a:      	cmpb	$0x0, 0xf75f(%rip)      # 0x738b0 <g.4>
   64151:      	je	0x6e9c5 <f.2+0x17805>
   64157:      	cmpq	$0x0, 0xf749(%rip)      # 0x738a8 <g.3>
   6415f:      	je	0x6e9c5 <f.2+0x17805>
   64165:      	movq	%rax, %r13
   64168:      	movq	$0x0, 0x50(%rsp)
   64171:      	movq	$0x3, 0x38(%rsp)
   6417a:      	xorl	%edi, %edi
   6417c:      	movq	%rbp, %rsi
   6417f:      	callq	0x6e9d0 <f.3>
   64184:      	subq	$0x8, %rsp
   64188:      	cmpb	$0x0, 0xf721(%rip)      # 0x738b0 <g.4>
   6418f:      	je	0x6e9c5 <f.2+0x17805>
   64195:      	movq	%rax, 0x58(%rsp)
   6419a:      	cmpq	$0x0, 0xf706(%rip)      # 0x738a8 <g.3>
   641a2:      	je	0x6e9c5 <f.2+0x17805>
   641a8:      	movq	$0x0, 0x50(%rsp)
   641b1:      	movq	$0x3, 0x38(%rsp)
   641ba:      	xorl	%edi, %edi
   641bc:      	leaq	-0xe(%r14), %rsi
   641c0:      	callq	0x6e9d0 <f.3>
   641c5:      	subq	$0x8, %rsp
   641c9:      	cmpb	$0x0, 0xf6e0(%rip)      # 0x738b0 <g.4>
   641d0:      	je	0x6e9c5 <f.2+0x17805>
   641d6:      	cmpq	$0x0, 0xf6ca(%rip)      # 0x738a8 <g.3>
   641de:      	leaq	0x28(%rsp), %r8
   641e3:      	leaq	0x20(%rsp), %rdi
   641e8:      	leaq	0xf5d9(%rip), %r9       # 0x737c8 <native_roots.0>
   641ef:      	je	0x6e9c5 <f.2+0x17805>
   641f5:      	addq	0x18(%rsp), %r13
   641fa:      	addq	0x10(%rsp), %r13
   641ff:      	addq	0x58(%rsp), %rax
   64204:      	cmpq	$0xf, %r14
   64208:      	jb	0x6428f <f.2+0xd0cf>
   6420e:      	movq	%rax, 0x10(%rsp)
   64213:      	movq	$0x0, 0x50(%rsp)
   6421c:      	movq	$0x3, 0x38(%rsp)
   64225:      	xorl	%edi, %edi
   64227:      	leaq	-0xe(%r14), %rsi
   6422b:      	callq	0x6e9d0 <f.3>
   64230:      	subq	$0x8, %rsp
   64234:      	cmpb	$0x0, 0xf675(%rip)      # 0x738b0 <g.4>
   6423b:      	je	0x6e9c5 <f.2+0x17805>
   64241:      	cmpq	$0x0, 0xf65f(%rip)      # 0x738a8 <g.3>
   64249:      	je	0x6e9c5 <f.2+0x17805>
   6424f:      	movq	%rax, %rbp
   64252:      	leaq	-0xf(%r14), %rsi
   64256:      	movq	$0x0, 0x50(%rsp)
   6425f:      	movq	$0x3, 0x38(%rsp)
   64268:      	xorl	%edi, %edi
   6426a:      	callq	0x6e9d0 <f.3>
   6426f:      	subq	$0x8, %rsp
   64273:      	addq	%rbp, %rax
   64276:      	movq	%rax, %rbp
   64279:      	leaq	0x28(%rsp), %r8
   6427e:      	leaq	0x20(%rsp), %rdi
   64283:      	leaq	0xf53e(%rip), %r9       # 0x737c8 <native_roots.0>
   6428a:      	movq	0x10(%rsp), %rax
   6428f:      	cmpb	$0x0, 0xf61a(%rip)      # 0x738b0 <g.4>
   64296:      	je	0x6e9c5 <f.2+0x17805>
   6429c:      	cmpq	$0x0, 0xf604(%rip)      # 0x738a8 <g.3>
   642a4:      	je	0x6e9c5 <f.2+0x17805>
   642aa:      	addq	%rax, %rbp
   642ad:      	addq	%r13, %rbp
   642b0:      	cmpq	$0xb, %r14
   642b4:      	je	0x64387 <f.2+0xd1c7>
   642ba:      	movl	$0x1, %r13d
   642c0:      	cmpq	$0xc, %r14
   642c4:      	je	0x643a0 <f.2+0xd1e0>
   642ca:      	movq	%r14, %r13
   642cd:      	subq	$0xd, %r13
   642d1:      	jbe	0x6439d <f.2+0xd1dd>
   642d7:      	movq	%rbp, 0x10(%rsp)
   642dc:      	movq	$0x0, 0x50(%rsp)
   642e5:      	movq	$0x3, 0x38(%rsp)
   642ee:      	xorl	%edi, %edi
   642f0:      	movq	%r13, %rsi
   642f3:      	callq	0x6e9d0 <f.3>
   642f8:      	subq	$0x8, %rsp
   642fc:      	cmpb	$0x0, 0xf5ad(%rip)      # 0x738b0 <g.4>
   64303:      	je	0x6e9c5 <f.2+0x17805>
   64309:      	cmpq	$0x0, 0xf597(%rip)      # 0x738a8 <g.3>
   64311:      	je	0x6e9c5 <f.2+0x17805>
   64317:      	movq	%rax, %rbp
   6431a:      	leaq	-0xe(%r14), %rsi
   6431e:      	movq	$0x0, 0x50(%rsp)
   64327:      	movq	$0x3, 0x38(%rsp)
   64330:      	xorl	%edi, %edi
   64332:      	callq	0x6e9d0 <f.3>
   64337:      	subq	$0x8, %rsp
   6433b:      	cmpb	$0x0, 0xf56e(%rip)      # 0x738b0 <g.4>
   64342:      	je	0x6e9c5 <f.2+0x17805>
   64348:      	cmpq	$0x0, 0xf558(%rip)      # 0x738a8 <g.3>
   64350:      	je	0x6e9c5 <f.2+0x17805>
   64356:      	addq	%rbp, %rax
   64359:      	cmpq	$0xe, %r14
   6435d:      	leaq	-0xe(%r14), %rsi
   64361:      	jne	0x644e1 <f.2+0xd321>
   64367:      	addq	%rax, %r13
   6436a:      	movl	$0x1, %eax
   6436f:      	xorl	%ecx, %ecx
   64371:      	leaq	0x28(%rsp), %r8
   64376:      	leaq	0x20(%rsp), %rdi
   6437b:      	leaq	0xf446(%rip), %r9       # 0x737c8 <native_roots.0>
   64382:      	jmp	0x64693 <f.2+0xd4d3>
   64387:      	leaq	(%r14,%rbp), %rax
   6438b:      	addq	$-0xa, %rax
   6438f:      	movl	$0x1, %ebp
   64394:      	leaq	-0xb(%r14), %rsi
   64398:      	jmp	0x654f3 <f.2+0xe333>
   6439d:      	incq	%r13
   643a0:      	leaq	-0xc(%r14), %rax
   643a4:      	jmp	0x6469b <f.2+0xd4db>
   643a9:      	movq	%rcx, 0x18(%rsp)
   643ae:      	movq	$0x0, 0x50(%rsp)
   643b7:      	movq	$0x3, 0x38(%rsp)
   643c0:      	xorl	%edi, %edi
   643c2:      	movq	%rax, %rsi
   643c5:      	callq	0x6e9d0 <f.3>
   643ca:      	subq	$0x8, %rsp
   643ce:      	cmpb	$0x0, 0xf4db(%rip)      # 0x738b0 <g.4>
   643d5:      	je	0x6e9c5 <f.2+0x17805>
   643db:      	movq	%rax, 0x58(%rsp)
   643e0:      	cmpq	$0x0, 0xf4c0(%rip)      # 0x738a8 <g.3>
   643e8:      	je	0x6e9c5 <f.2+0x17805>
   643ee:      	leaq	-0xf(%r14), %rsi
   643f2:      	movq	$0x0, 0x50(%rsp)
   643fb:      	movq	$0x3, 0x38(%rsp)
   64404:      	xorl	%edi, %edi
   64406:      	callq	0x6e9d0 <f.3>
   6440b:      	subq	$0x8, %rsp
   6440f:      	cmpb	$0x0, 0xf49a(%rip)      # 0x738b0 <g.4>
   64416:      	je	0x6e9c5 <f.2+0x17805>
   6441c:      	cmpq	$0x0, 0xf484(%rip)      # 0x738a8 <g.3>
   64424:      	leaq	-0xe(%r14), %rsi
   64428:      	je	0x6e9c5 <f.2+0x17805>
   6442e:      	movq	%rax, %r13
   64431:      	movq	$0x0, 0x50(%rsp)
   6443a:      	movq	$0x3, 0x38(%rsp)
   64443:      	xorl	%edi, %edi
   64445:      	callq	0x6e9d0 <f.3>
   6444a:      	subq	$0x8, %rsp
   6444e:      	cmpb	$0x0, 0xf45b(%rip)      # 0x738b0 <g.4>
   64455:      	je	0x6e9c5 <f.2+0x17805>
   6445b:      	cmpq	$0x0, 0xf445(%rip)      # 0x738a8 <g.3>
   64463:      	je	0x6e9c5 <f.2+0x17805>
   64469:      	movq	%rax, %rbp
   6446c:      	movq	$0x0, 0x50(%rsp)
   64475:      	movq	$0x3, 0x38(%rsp)
   6447e:      	xorl	%edi, %edi
   64480:      	leaq	-0xf(%r14), %rsi
   64484:      	callq	0x6e9d0 <f.3>
   64489:      	subq	$0x8, %rsp
   6448d:      	cmpb	$0x0, 0xf41c(%rip)      # 0x738b0 <g.4>
   64494:      	je	0x6e9c5 <f.2+0x17805>
   6449a:      	movq	%rax, %rcx
   6449d:      	cmpq	$0x0, 0xf403(%rip)      # 0x738a8 <g.3>
   644a5:      	leaq	0x28(%rsp), %r8
   644aa:      	leaq	0xf317(%rip), %r9       # 0x737c8 <native_roots.0>
   644b1:      	movq	0x10(%rsp), %rsi
   644b6:      	leaq	-0xe(%r14), %rax
   644ba:      	je	0x6e9c5 <f.2+0x17805>
   644c0:      	addq	0x58(%rsp), %r13
   644c5:      	addq	0x18(%rsp), %r13
   644ca:      	addq	%rbp, %rcx
   644cd:      	cmpq	$0x10, %r14
   644d1:      	jae	0x64bc4 <f.2+0xda04>
   644d7:      	leaq	0x20(%rsp), %rdi
   644dc:      	jmp	0x64c47 <f.2+0xda87>
   644e1:      	movq	%rax, 0x18(%rsp)
   644e6:      	movq	$0x0, 0x50(%rsp)
   644ef:      	movq	$0x3, 0x38(%rsp)
   644f8:      	xorl	%edi, %edi
   644fa:      	callq	0x6e9d0 <f.3>
   644ff:      	subq	$0x8, %rsp
   64503:      	cmpb	$0x0, 0xf3a6(%rip)      # 0x738b0 <g.4>
   6450a:      	movq	0x10(%rsp), %rbp
   6450f:      	je	0x6e9c5 <f.2+0x17805>
   64515:      	movq	%rax, 0x58(%rsp)
   6451a:      	cmpq	$0x0, 0xf386(%rip)      # 0x738a8 <g.3>
   64522:      	je	0x6e9c5 <f.2+0x17805>
   64528:      	leaq	-0xf(%r14), %rsi
   6452c:      	movq	$0x0, 0x50(%rsp)
   64535:      	movq	$0x3, 0x38(%rsp)
   6453e:      	xorl	%edi, %edi
   64540:      	callq	0x6e9d0 <f.3>
   64545:      	subq	$0x8, %rsp
   64549:      	cmpb	$0x0, 0xf360(%rip)      # 0x738b0 <g.4>
   64550:      	je	0x6e9c5 <f.2+0x17805>
   64556:      	cmpq	$0x0, 0xf34a(%rip)      # 0x738a8 <g.3>
   6455e:      	leaq	-0xe(%r14), %rsi
   64562:      	je	0x6e9c5 <f.2+0x17805>
   64568:      	movq	%rax, %r13
   6456b:      	movq	$0x0, 0x50(%rsp)
   64574:      	movq	$0x3, 0x38(%rsp)
   6457d:      	xorl	%edi, %edi
   6457f:      	callq	0x6e9d0 <f.3>
   64584:      	subq	$0x8, %rsp
   64588:      	cmpb	$0x0, 0xf321(%rip)      # 0x738b0 <g.4>
   6458f:      	je	0x6e9c5 <f.2+0x17805>
   64595:      	movq	%rax, 0x60(%rsp)
   6459a:      	cmpq	$0x0, 0xf306(%rip)      # 0x738a8 <g.3>
   645a2:      	je	0x6e9c5 <f.2+0x17805>
   645a8:      	movq	$0x0, 0x50(%rsp)
   645b1:      	movq	$0x3, 0x38(%rsp)
   645ba:      	xorl	%edi, %edi
   645bc:      	leaq	-0xf(%r14), %rsi
   645c0:      	callq	0x6e9d0 <f.3>
   645c5:      	subq	$0x8, %rsp
   645c9:      	cmpb	$0x0, 0xf2e0(%rip)      # 0x738b0 <g.4>
   645d0:      	je	0x6e9c5 <f.2+0x17805>
   645d6:      	cmpq	$0x0, 0xf2ca(%rip)      # 0x738a8 <g.3>
   645de:      	leaq	0x28(%rsp), %r8
   645e3:      	leaq	0x20(%rsp), %rdi
   645e8:      	leaq	0xf1d9(%rip), %r9       # 0x737c8 <native_roots.0>
   645ef:      	leaq	-0xe(%r14), %rcx
   645f3:      	je	0x6e9c5 <f.2+0x17805>
   645f9:      	addq	0x58(%rsp), %r13
   645fe:      	addq	0x18(%rsp), %r13
   64603:      	addq	0x60(%rsp), %rax
   64608:      	cmpq	$0x10, %r14
   6460c:      	jb	0x64698 <f.2+0xd4d8>
   64612:      	movq	%rax, 0x18(%rsp)
   64617:      	movq	$0x0, 0x50(%rsp)
   64620:      	movq	$0x3, 0x38(%rsp)
   64629:      	xorl	%edi, %edi
   6462b:      	leaq	-0xf(%r14), %rsi
   6462f:      	callq	0x6e9d0 <f.3>
   64634:      	subq	$0x8, %rsp
   64638:      	cmpb	$0x0, 0xf271(%rip)      # 0x738b0 <g.4>
   6463f:      	je	0x6e9c5 <f.2+0x17805>
   64645:      	cmpq	$0x0, 0xf25b(%rip)      # 0x738a8 <g.3>
   6464d:      	je	0x6e9c5 <f.2+0x17805>
   64653:      	movq	%rax, %rbp
   64656:      	leaq	-0x10(%r14), %rsi
   6465a:      	movq	$0x0, 0x50(%rsp)
   64663:      	movq	$0x3, 0x38(%rsp)
   6466c:      	xorl	%edi, %edi
   6466e:      	callq	0x6e9d0 <f.3>
   64673:      	subq	$0x8, %rsp
   64677:      	movq	%rax, %rcx
   6467a:      	addq	%rbp, %rcx
   6467d:      	leaq	0x28(%rsp), %r8
   64682:      	leaq	0x20(%rsp), %rdi
   64687:      	leaq	0xf13a(%rip), %r9       # 0x737c8 <native_roots.0>
   6468e:      	movq	0x18(%rsp), %rax
   64693:      	movq	0x10(%rsp), %rbp
   64698:      	addq	%rcx, %rax
   6469b:      	cmpb	$0x0, 0xf20e(%rip)      # 0x738b0 <g.4>
   646a2:      	je	0x6e9c5 <f.2+0x17805>
   646a8:      	cmpq	$0x0, 0xf1f8(%rip)      # 0x738a8 <g.3>
   646b0:      	je	0x6e9c5 <f.2+0x17805>
   646b6:      	addq	%r13, %rax
   646b9:      	addq	%rbp, %rax
   646bc:      	cmpq	$0xc, %r14
   646c0:      	jbe	0x646d9 <f.2+0xd519>
   646c2:      	cmpq	$0xd, %r14
   646c6:      	movq	%rax, 0x18(%rsp)
   646cb:      	jne	0x646e6 <f.2+0xd526>
   646cd:      	movl	$0x1, %ebp
   646d2:      	xorl	%ecx, %ecx
   646d4:      	jmp	0x64823 <f.2+0xd663>
   646d9:      	leaq	-0xb(%r14), %rbp
   646dd:      	leaq	-0xb(%r14), %rsi
   646e1:      	jmp	0x654f3 <f.2+0xe333>
   646e6:      	leaq	-0xd(%r14), %rsi
   646ea:      	movq	$0x0, 0x50(%rsp)
   646f3:      	movq	$0x3, 0x38(%rsp)
   646fc:      	xorl	%edi, %edi
   646fe:      	callq	0x6e9d0 <f.3>
   64703:      	subq	$0x8, %rsp
   64707:      	cmpb	$0x0, 0xf1a2(%rip)      # 0x738b0 <g.4>
   6470e:      	je	0x6e9c5 <f.2+0x17805>
   64714:      	cmpq	$0x0, 0xf18c(%rip)      # 0x738a8 <g.3>
   6471c:      	je	0x6e9c5 <f.2+0x17805>
   64722:      	movq	%rax, %r13
   64725:      	leaq	-0xe(%r14), %rsi
   64729:      	movq	$0x0, 0x50(%rsp)
   64732:      	movq	$0x3, 0x38(%rsp)
   6473b:      	xorl	%edi, %edi
   6473d:      	callq	0x6e9d0 <f.3>
   64742:      	subq	$0x8, %rsp
   64746:      	cmpb	$0x0, 0xf163(%rip)      # 0x738b0 <g.4>
   6474d:      	je	0x6e9c5 <f.2+0x17805>
   64753:      	movq	%rax, %rbp
   64756:      	cmpq	$0x0, 0xf14a(%rip)      # 0x738a8 <g.3>
   6475e:      	movq	0x18(%rsp), %rax
   64763:      	je	0x6e9c5 <f.2+0x17805>
   64769:      	addq	%r13, %rbp
   6476c:      	cmpq	$0xe, %r14
   64770:      	ja	0x6478c <f.2+0xd5cc>
   64772:      	leaq	0x28(%rsp), %r8
   64777:      	leaq	0x20(%rsp), %rdi
   6477c:      	leaq	0xf045(%rip), %r9       # 0x737c8 <native_roots.0>
   64783:      	leaq	-0xd(%r14), %rcx
   64787:      	jmp	0x64823 <f.2+0xd663>
   6478c:      	movq	$0x0, 0x50(%rsp)
   64795:      	movq	$0x3, 0x38(%rsp)
   6479e:      	xorl	%edi, %edi
   647a0:      	leaq	-0xe(%r14), %rsi
   647a4:      	callq	0x6e9d0 <f.3>
   647a9:      	subq	$0x8, %rsp
   647ad:      	cmpb	$0x0, 0xf0fc(%rip)      # 0x738b0 <g.4>
   647b4:      	je	0x6e9c5 <f.2+0x17805>
   647ba:      	cmpq	$0x0, 0xf0e6(%rip)      # 0x738a8 <g.3>
   647c2:      	je	0x6e9c5 <f.2+0x17805>
   647c8:      	movq	%rax, %r13
   647cb:      	leaq	-0xf(%r14), %rsi
   647cf:      	movq	$0x0, 0x50(%rsp)
   647d8:      	movq	$0x3, 0x38(%rsp)
   647e1:      	xorl	%edi, %edi
   647e3:      	callq	0x6e9d0 <f.3>
   647e8:      	subq	$0x8, %rsp
   647ec:      	cmpb	$0x0, 0xf0bd(%rip)      # 0x738b0 <g.4>
   647f3:      	je	0x6e9c5 <f.2+0x17805>
   647f9:      	movq	%rax, %rcx
   647fc:      	cmpq	$0x0, 0xf0a4(%rip)      # 0x738a8 <g.3>
   64804:      	leaq	0x28(%rsp), %r8
   64809:      	leaq	0x20(%rsp), %rdi
   6480e:      	leaq	0xefb3(%rip), %r9       # 0x737c8 <native_roots.0>
   64815:      	movq	0x18(%rsp), %rax
   6481a:      	je	0x6e9c5 <f.2+0x17805>
   64820:      	addq	%r13, %rcx
   64823:      	addq	%rbp, %rcx
   64826:      	cmpq	$0xd, %r14
   6482a:      	je	0x6483e <f.2+0xd67e>
   6482c:      	cmpq	$0xe, %r14
   64830:      	jne	0x64854 <f.2+0xd694>
   64832:      	movl	$0x1, %edx
   64837:      	xorl	%ebp, %ebp
   64839:      	jmp	0x6498e <f.2+0xd7ce>
   6483e:      	leaq	(%r14,%rcx), %rbp
   64842:      	addq	$-0xc, %rbp
   64846:      	movl	$0x1, %esi
   6484b:      	leaq	-0xd(%r14), %r13
   6484f:      	jmp	0x654f0 <f.2+0xe330>
   64854:      	movq	%rcx, 0x10(%rsp)
   64859:      	leaq	-0xe(%r14), %rbp
   6485d:      	movq	$0x0, 0x50(%rsp)
   64866:      	movq	$0x3, 0x38(%rsp)
   6486f:      	xorl	%edi, %edi
   64871:      	movq	%rbp, %rsi
   64874:      	callq	0x6e9d0 <f.3>
   64879:      	subq	$0x8, %rsp
   6487d:      	cmpb	$0x0, 0xf02c(%rip)      # 0x738b0 <g.4>
   64884:      	je	0x6e9c5 <f.2+0x17805>
   6488a:      	cmpq	$0x0, 0xf016(%rip)      # 0x738a8 <g.3>
   64892:      	je	0x6e9c5 <f.2+0x17805>
   64898:      	movq	%rax, %r13
   6489b:      	leaq	-0xf(%r14), %rsi
   6489f:      	movq	$0x0, 0x50(%rsp)
   648a8:      	movq	$0x3, 0x38(%rsp)
   648b1:      	xorl	%edi, %edi
   648b3:      	callq	0x6e9d0 <f.3>
   648b8:      	subq	$0x8, %rsp
   648bc:      	cmpb	$0x0, 0xefed(%rip)      # 0x738b0 <g.4>
   648c3:      	je	0x6e9c5 <f.2+0x17805>
   648c9:      	movq	%rax, %rdx
   648cc:      	cmpq	$0x0, 0xefd4(%rip)      # 0x738a8 <g.3>
   648d4:      	leaq	0x28(%rsp), %r8
   648d9:      	leaq	0xeee8(%rip), %r9       # 0x737c8 <native_roots.0>
   648e0:      	movq	0x18(%rsp), %rax
   648e5:      	je	0x6e9c5 <f.2+0x17805>
   648eb:      	addq	%r13, %rdx
   648ee:      	cmpq	$0x10, %r14
   648f2:      	jae	0x64903 <f.2+0xd743>
   648f4:      	leaq	0x20(%rsp), %rdi
   648f9:      	movq	0x10(%rsp), %rcx
   648fe:      	jmp	0x6498e <f.2+0xd7ce>
   64903:      	movq	%rdx, 0x58(%rsp)
   64908:      	movq	$0x0, 0x50(%rsp)
   64911:      	movq	$0x3, 0x38(%rsp)
   6491a:      	xorl	%edi, %edi
   6491c:      	leaq	-0xf(%r14), %rsi
   64920:      	callq	0x6e9d0 <f.3>
   64925:      	subq	$0x8, %rsp
   64929:      	cmpb	$0x0, 0xef80(%rip)      # 0x738b0 <g.4>
   64930:      	je	0x6e9c5 <f.2+0x17805>
   64936:      	cmpq	$0x0, 0xef6a(%rip)      # 0x738a8 <g.3>
   6493e:      	je	0x6e9c5 <f.2+0x17805>
   64944:      	movq	%rax, %r13
   64947:      	leaq	-0x10(%r14), %rsi
   6494b:      	movq	$0x0, 0x50(%rsp)
   64954:      	movq	$0x3, 0x38(%rsp)
   6495d:      	xorl	%edi, %edi
   6495f:      	callq	0x6e9d0 <f.3>
   64964:      	subq	$0x8, %rsp
   64968:      	movq	%rax, %rbp
   6496b:      	addq	%r13, %rbp
   6496e:      	leaq	0x28(%rsp), %r8
   64973:      	leaq	0x20(%rsp), %rdi
   64978:      	leaq	0xee49(%rip), %r9       # 0x737c8 <native_roots.0>
   6497f:      	movq	0x18(%rsp), %rax
   64984:      	movq	0x10(%rsp), %rcx
   64989:      	movq	0x58(%rsp), %rdx
   6498e:      	cmpb	$0x0, 0xef1b(%rip)      # 0x738b0 <g.4>
   64995:      	je	0x6e9c5 <f.2+0x17805>
   6499b:      	cmpq	$0x0, 0xef05(%rip)      # 0x738a8 <g.3>
   649a3:      	je	0x6e9c5 <f.2+0x17805>
   649a9:      	addq	%rdx, %rbp
   649ac:      	addq	%rcx, %rbp
   649af:      	movq	%r14, %rsi
   649b2:      	subq	$0xe, %rsi
   649b6:      	jbe	0x64a6f <f.2+0xd8af>
   649bc:      	movq	$0x0, 0x50(%rsp)
   649c5:      	movq	$0x3, 0x38(%rsp)
   649ce:      	xorl	%edi, %edi
   649d0:      	movq	%rsi, 0x10(%rsp)
   649d5:      	callq	0x6e9d0 <f.3>
   649da:      	subq	$0x8, %rsp
   649de:      	cmpb	$0x0, 0xeecb(%rip)      # 0x738b0 <g.4>
   649e5:      	je	0x6e9c5 <f.2+0x17805>
   649eb:      	cmpq	$0x0, 0xeeb5(%rip)      # 0x738a8 <g.3>
   649f3:      	je	0x6e9c5 <f.2+0x17805>
   649f9:      	movq	%rax, %r13
   649fc:      	leaq	-0xf(%r14), %rsi
   64a00:      	movq	$0x0, 0x50(%rsp)
   64a09:      	movq	$0x3, 0x38(%rsp)
   64a12:      	xorl	%edi, %edi
   64a14:      	callq	0x6e9d0 <f.3>
   64a19:      	subq	$0x8, %rsp
   64a1d:      	cmpb	$0x0, 0xee8c(%rip)      # 0x738b0 <g.4>
   64a24:      	je	0x6e9c5 <f.2+0x17805>
   64a2a:      	movq	%rax, %rcx
   64a2d:      	cmpq	$0x0, 0xee73(%rip)      # 0x738a8 <g.3>
   64a35:      	leaq	0x28(%rsp), %r8
   64a3a:      	leaq	0xed87(%rip), %r9       # 0x737c8 <native_roots.0>
   64a41:      	movq	0x10(%rsp), %rsi
   64a46:      	movq	0x18(%rsp), %rax
   64a4b:      	je	0x6e9c5 <f.2+0x17805>
   64a51:      	addq	%r13, %rcx
   64a54:      	cmpq	$0xf, %r14
   64a58:      	jne	0x64a7b <f.2+0xd8bb>
   64a5a:      	addq	%rcx, %rsi
   64a5d:      	movl	$0x1, %r13d
   64a63:      	xorl	%ecx, %ecx
   64a65:      	leaq	0x20(%rsp), %rdi
   64a6a:      	jmp	0x654ed <f.2+0xe32d>
   64a6f:      	incq	%rsi
   64a72:      	leaq	-0xd(%r14), %r13
   64a76:      	jmp	0x654f0 <f.2+0xe330>
   64a7b:      	movq	%rcx, 0x58(%rsp)
   64a80:      	movq	$0x0, 0x50(%rsp)
   64a89:      	movq	$0x3, 0x38(%rsp)
   64a92:      	xorl	%edi, %edi
   64a94:      	leaq	-0xf(%r14), %r13
   64a98:      	movq	%r13, %rsi
   64a9b:      	callq	0x6e9d0 <f.3>
   64aa0:      	subq	$0x8, %rsp
   64aa4:      	cmpb	$0x0, 0xee05(%rip)      # 0x738b0 <g.4>
   64aab:      	je	0x6e9c5 <f.2+0x17805>
   64ab1:      	movq	%rax, 0x60(%rsp)
   64ab6:      	cmpq	$0x0, 0xedea(%rip)      # 0x738a8 <g.3>
   64abe:      	je	0x6e9c5 <f.2+0x17805>
   64ac4:      	leaq	-0x10(%r14), %rsi
   64ac8:      	movq	$0x0, 0x50(%rsp)
   64ad1:      	movq	$0x3, 0x38(%rsp)
   64ada:      	xorl	%edi, %edi
   64adc:      	callq	0x6e9d0 <f.3>
   64ae1:      	subq	$0x8, %rsp
   64ae5:      	cmpb	$0x0, 0xedc4(%rip)      # 0x738b0 <g.4>
   64aec:      	je	0x6e9c5 <f.2+0x17805>
   64af2:      	movq	%rax, 0x10(%rsp)
   64af7:      	cmpq	$0x0, 0xeda9(%rip)      # 0x738a8 <g.3>
   64aff:      	je	0x6e9c5 <f.2+0x17805>
   64b05:      	movq	$0x0, 0x50(%rsp)
   64b0e:      	movq	$0x3, 0x38(%rsp)
   64b17:      	xorl	%edi, %edi
   64b19:      	movq	%r13, %rsi
   64b1c:      	callq	0x6e9d0 <f.3>
   64b21:      	subq	$0x8, %rsp
   64b25:      	cmpb	$0x0, 0xed84(%rip)      # 0x738b0 <g.4>
   64b2c:      	je	0x6e9c5 <f.2+0x17805>
   64b32:      	movq	%rax, 0x68(%rsp)
   64b37:      	cmpq	$0x0, 0xed69(%rip)      # 0x738a8 <g.3>
   64b3f:      	je	0x6e9c5 <f.2+0x17805>
   64b45:      	movq	$0x0, 0x50(%rsp)
   64b4e:      	movq	$0x3, 0x38(%rsp)
   64b57:      	xorl	%edi, %edi
   64b59:      	leaq	-0x10(%r14), %rsi
   64b5d:      	callq	0x6e9d0 <f.3>
   64b62:      	subq	$0x8, %rsp
   64b66:      	cmpb	$0x0, 0xed43(%rip)      # 0x738b0 <g.4>
   64b6d:      	je	0x6e9c5 <f.2+0x17805>
   64b73:      	movq	%rax, %r13
   64b76:      	cmpq	$0x0, 0xed2a(%rip)      # 0x738a8 <g.3>
   64b7e:      	movq	0x10(%rsp), %rsi
   64b83:      	movq	0x18(%rsp), %rax
   64b88:      	movq	0x58(%rsp), %rcx
   64b8d:      	je	0x6e9c5 <f.2+0x17805>
   64b93:      	addq	0x60(%rsp), %rsi
   64b98:      	addq	%rcx, %rsi
   64b9b:      	addq	0x68(%rsp), %r13
   64ba0:      	cmpq	$0x11, %r14
   64ba4:      	jae	0x65463 <f.2+0xe2a3>
   64baa:      	leaq	0x28(%rsp), %r8
   64baf:      	leaq	0x20(%rsp), %rdi
   64bb4:      	leaq	0xec0d(%rip), %r9       # 0x737c8 <native_roots.0>
   64bbb:      	leaq	-0xf(%r14), %rcx
   64bbf:      	jmp	0x654ed <f.2+0xe32d>
   64bc4:      	movq	%rcx, 0x18(%rsp)
   64bc9:      	movq	$0x0, 0x50(%rsp)
   64bd2:      	movq	$0x3, 0x38(%rsp)
   64bdb:      	xorl	%edi, %edi
   64bdd:      	leaq	-0xf(%r14), %rsi
   64be1:      	callq	0x6e9d0 <f.3>
   64be6:      	subq	$0x8, %rsp
   64bea:      	cmpb	$0x0, 0xecbf(%rip)      # 0x738b0 <g.4>
   64bf1:      	je	0x6e9c5 <f.2+0x17805>
   64bf7:      	cmpq	$0x0, 0xeca9(%rip)      # 0x738a8 <g.3>
   64bff:      	je	0x6e9c5 <f.2+0x17805>
   64c05:      	movq	%rax, %rbp
   64c08:      	leaq	-0x10(%r14), %rsi
   64c0c:      	movq	$0x0, 0x50(%rsp)
   64c15:      	movq	$0x3, 0x38(%rsp)
   64c1e:      	xorl	%edi, %edi
   64c20:      	callq	0x6e9d0 <f.3>
   64c25:      	subq	$0x8, %rsp
   64c29:      	addq	%rbp, %rax
   64c2c:      	leaq	0x28(%rsp), %r8
   64c31:      	leaq	0x20(%rsp), %rdi
   64c36:      	leaq	0xeb8b(%rip), %r9       # 0x737c8 <native_roots.0>
   64c3d:      	movq	0x10(%rsp), %rsi
   64c42:      	movq	0x18(%rsp), %rcx
   64c47:      	cmpb	$0x0, 0xec62(%rip)      # 0x738b0 <g.4>
   64c4e:      	je	0x6e9c5 <f.2+0x17805>
   64c54:      	cmpq	$0x0, 0xec4c(%rip)      # 0x738a8 <g.3>
   64c5c:      	je	0x6e9c5 <f.2+0x17805>
   64c62:      	addq	%rcx, %rax
   64c65:      	addq	%r13, %rax
   64c68:      	cmpq	$0xc, %r14
   64c6c:      	je	0x64d49 <f.2+0xdb89>
   64c72:      	movl	$0x1, %r13d
   64c78:      	cmpq	$0xd, %r14
   64c7c:      	je	0x64d63 <f.2+0xdba3>
   64c82:      	movq	%r14, %r13
   64c85:      	subq	$0xe, %r13
   64c89:      	jbe	0x64d60 <f.2+0xdba0>
   64c8f:      	movq	%rax, 0x18(%rsp)
   64c94:      	movq	%rsi, 0x10(%rsp)
   64c99:      	movq	$0x0, 0x50(%rsp)
   64ca2:      	movq	$0x3, 0x38(%rsp)
   64cab:      	xorl	%edi, %edi
   64cad:      	movq	%r13, %rsi
   64cb0:      	callq	0x6e9d0 <f.3>
   64cb5:      	subq	$0x8, %rsp
   64cb9:      	cmpb	$0x0, 0xebf0(%rip)      # 0x738b0 <g.4>
   64cc0:      	je	0x6e9c5 <f.2+0x17805>
   64cc6:      	cmpq	$0x0, 0xebda(%rip)      # 0x738a8 <g.3>
   64cce:      	je	0x6e9c5 <f.2+0x17805>
   64cd4:      	movq	%rax, %rbp
   64cd7:      	leaq	-0xf(%r14), %rsi
   64cdb:      	movq	$0x0, 0x50(%rsp)
   64ce4:      	movq	$0x3, 0x38(%rsp)
   64ced:      	xorl	%edi, %edi
   64cef:      	callq	0x6e9d0 <f.3>
   64cf4:      	subq	$0x8, %rsp
   64cf8:      	cmpb	$0x0, 0xebb1(%rip)      # 0x738b0 <g.4>
   64cff:      	je	0x6e9c5 <f.2+0x17805>
   64d05:      	movq	%rax, %rcx
   64d08:      	cmpq	$0x0, 0xeb98(%rip)      # 0x738a8 <g.3>
   64d10:      	leaq	0x28(%rsp), %r8
   64d15:      	leaq	0xeaac(%rip), %r9       # 0x737c8 <native_roots.0>
   64d1c:      	movq	0x10(%rsp), %rsi
   64d21:      	movq	0x18(%rsp), %rax
   64d26:      	je	0x6e9c5 <f.2+0x17805>
   64d2c:      	addq	%rbp, %rcx
   64d2f:      	cmpq	$0xf, %r14
   64d33:      	jne	0x64d6c <f.2+0xdbac>
   64d35:      	addq	%rcx, %r13
   64d38:      	movl	$0x1, %ebp
   64d3d:      	xorl	%ecx, %ecx
   64d3f:      	leaq	0x20(%rsp), %rdi
   64d44:      	jmp	0x64f34 <f.2+0xdd74>
   64d49:      	leaq	(%r14,%rax), %rbp
   64d4d:      	addq	$-0xb, %rbp
   64d51:      	movl	$0x1, %r13d
   64d57:      	leaq	-0xc(%r14), %rcx
   64d5b:      	jmp	0x655cb <f.2+0xe40b>
   64d60:      	incq	%r13
   64d63:      	leaq	-0xd(%r14), %rbp
   64d67:      	jmp	0x64f37 <f.2+0xdd77>
   64d6c:      	movq	%rcx, 0x58(%rsp)
   64d71:      	movq	$0x0, 0x50(%rsp)
   64d7a:      	movq	$0x3, 0x38(%rsp)
   64d83:      	xorl	%edi, %edi
   64d85:      	leaq	-0xf(%r14), %rbp
   64d89:      	movq	%rbp, %rsi
   64d8c:      	callq	0x6e9d0 <f.3>
   64d91:      	subq	$0x8, %rsp
   64d95:      	cmpb	$0x0, 0xeb14(%rip)      # 0x738b0 <g.4>
   64d9c:      	je	0x6e9c5 <f.2+0x17805>
   64da2:      	movq	%rax, 0x60(%rsp)
   64da7:      	cmpq	$0x0, 0xeaf9(%rip)      # 0x738a8 <g.3>
   64daf:      	je	0x6e9c5 <f.2+0x17805>
   64db5:      	leaq	-0x10(%r14), %rsi
   64db9:      	movq	$0x0, 0x50(%rsp)
   64dc2:      	movq	$0x3, 0x38(%rsp)
   64dcb:      	xorl	%edi, %edi
   64dcd:      	callq	0x6e9d0 <f.3>
   64dd2:      	subq	$0x8, %rsp
   64dd6:      	cmpb	$0x0, 0xead3(%rip)      # 0x738b0 <g.4>
   64ddd:      	je	0x6e9c5 <f.2+0x17805>
   64de3:      	cmpq	$0x0, 0xeabd(%rip)      # 0x738a8 <g.3>
   64deb:      	je	0x6e9c5 <f.2+0x17805>
   64df1:      	movq	%rax, %r13
   64df4:      	movq	$0x0, 0x50(%rsp)
   64dfd:      	movq	$0x3, 0x38(%rsp)
   64e06:      	xorl	%edi, %edi
   64e08:      	movq	%rbp, %rsi
   64e0b:      	callq	0x6e9d0 <f.3>
   64e10:      	subq	$0x8, %rsp
   64e14:      	cmpb	$0x0, 0xea95(%rip)      # 0x738b0 <g.4>
   64e1b:      	je	0x6e9c5 <f.2+0x17805>
   64e21:      	movq	%rax, 0x68(%rsp)
   64e26:      	cmpq	$0x0, 0xea7a(%rip)      # 0x738a8 <g.3>
   64e2e:      	je	0x6e9c5 <f.2+0x17805>
   64e34:      	movq	$0x0, 0x50(%rsp)
   64e3d:      	movq	$0x3, 0x38(%rsp)
   64e46:      	xorl	%edi, %edi
   64e48:      	leaq	-0x10(%r14), %rsi
   64e4c:      	callq	0x6e9d0 <f.3>
   64e51:      	subq	$0x8, %rsp
   64e55:      	cmpb	$0x0, 0xea54(%rip)      # 0x738b0 <g.4>
   64e5c:      	je	0x6e9c5 <f.2+0x17805>
   64e62:      	movq	%rax, %rbp
   64e65:      	cmpq	$0x0, 0xea3b(%rip)      # 0x738a8 <g.3>
   64e6d:      	leaq	0x28(%rsp), %r8
   64e72:      	leaq	0xe94f(%rip), %r9       # 0x737c8 <native_roots.0>
   64e79:      	movq	0x10(%rsp), %rsi
   64e7e:      	movq	0x18(%rsp), %rax
   64e83:      	movq	0x58(%rsp), %rcx
   64e88:      	je	0x6e9c5 <f.2+0x17805>
   64e8e:      	addq	0x60(%rsp), %r13
   64e93:      	addq	%rcx, %r13
   64e96:      	addq	0x68(%rsp), %rbp
   64e9b:      	cmpq	$0x11, %r14
   64e9f:      	jae	0x64eaf <f.2+0xdcef>
   64ea1:      	leaq	0x20(%rsp), %rdi
   64ea6:      	leaq	-0xf(%r14), %rcx
   64eaa:      	jmp	0x64f34 <f.2+0xdd74>
   64eaf:      	movq	$0x0, 0x50(%rsp)
   64eb8:      	movq	$0x3, 0x38(%rsp)
   64ec1:      	xorl	%edi, %edi
   64ec3:      	leaq	-0x10(%r14), %rsi
   64ec7:      	callq	0x6e9d0 <f.3>
   64ecc:      	subq	$0x8, %rsp
   64ed0:      	cmpb	$0x0, 0xe9d9(%rip)      # 0x738b0 <g.4>
   64ed7:      	je	0x6e9c5 <f.2+0x17805>
   64edd:      	movq	%rax, 0x58(%rsp)
   64ee2:      	cmpq	$0x0, 0xe9be(%rip)      # 0x738a8 <g.3>
   64eea:      	je	0x6e9c5 <f.2+0x17805>
   64ef0:      	leaq	-0x11(%r14), %rsi
   64ef4:      	movq	$0x0, 0x50(%rsp)
   64efd:      	movq	$0x3, 0x38(%rsp)
   64f06:      	xorl	%edi, %edi
   64f08:      	callq	0x6e9d0 <f.3>
   64f0d:      	subq	$0x8, %rsp
   64f11:      	movq	%rax, %rcx
   64f14:      	addq	0x58(%rsp), %rcx
   64f19:      	leaq	0x28(%rsp), %r8
   64f1e:      	leaq	0x20(%rsp), %rdi
   64f23:      	leaq	0xe89e(%rip), %r9       # 0x737c8 <native_roots.0>
   64f2a:      	movq	0x10(%rsp), %rsi
   64f2f:      	movq	0x18(%rsp), %rax
   64f34:      	addq	%rcx, %rbp
   64f37:      	cmpb	$0x0, 0xe972(%rip)      # 0x738b0 <g.4>
   64f3e:      	je	0x6e9c5 <f.2+0x17805>
   64f44:      	cmpq	$0x0, 0xe95c(%rip)      # 0x738a8 <g.3>
   64f4c:      	je	0x6e9c5 <f.2+0x17805>
   64f52:      	addq	%r13, %rbp
   64f55:      	addq	%rax, %rbp
   64f58:      	cmpq	$0xd, %r14
   64f5c:      	jbe	0x64f76 <f.2+0xddb6>
   64f5e:      	cmpq	$0xe, %r14
   64f62:      	movq	%rsi, 0x10(%rsp)
   64f67:      	jne	0x64f83 <f.2+0xddc3>
   64f69:      	movl	$0x1, %r13d
   64f6f:      	xorl	%eax, %eax
   64f71:      	jmp	0x650c5 <f.2+0xdf05>
   64f76:      	leaq	-0xc(%r14), %r13
   64f7a:      	leaq	-0xc(%r14), %rcx
   64f7e:      	jmp	0x655cb <f.2+0xe40b>
   64f83:      	leaq	-0xe(%r14), %rsi
   64f87:      	movq	$0x0, 0x50(%rsp)
   64f90:      	movq	$0x3, 0x38(%rsp)
   64f99:      	xorl	%edi, %edi
   64f9b:      	callq	0x6e9d0 <f.3>
   64fa0:      	subq	$0x8, %rsp
   64fa4:      	cmpb	$0x0, 0xe905(%rip)      # 0x738b0 <g.4>
   64fab:      	je	0x6e9c5 <f.2+0x17805>
   64fb1:      	movq	%rax, 0x18(%rsp)
   64fb6:      	cmpq	$0x0, 0xe8ea(%rip)      # 0x738a8 <g.3>
   64fbe:      	je	0x6e9c5 <f.2+0x17805>
   64fc4:      	leaq	-0xf(%r14), %rsi
   64fc8:      	movq	$0x0, 0x50(%rsp)
   64fd1:      	movq	$0x3, 0x38(%rsp)
   64fda:      	xorl	%edi, %edi
   64fdc:      	callq	0x6e9d0 <f.3>
   64fe1:      	subq	$0x8, %rsp
   64fe5:      	cmpb	$0x0, 0xe8c4(%rip)      # 0x738b0 <g.4>
   64fec:      	je	0x6e9c5 <f.2+0x17805>
   64ff2:      	movq	%rax, %r13
   64ff5:      	cmpq	$0x0, 0xe8ab(%rip)      # 0x738a8 <g.3>
   64ffd:      	leaq	-0xe(%r14), %rax
   65001:      	je	0x6e9c5 <f.2+0x17805>
   65007:      	addq	0x18(%rsp), %r13
   6500c:      	cmpq	$0xf, %r14
   65010:      	ja	0x6502d <f.2+0xde6d>
   65012:      	leaq	0x28(%rsp), %r8
   65017:      	leaq	0x20(%rsp), %rdi
   6501c:      	leaq	0xe7a5(%rip), %r9       # 0x737c8 <native_roots.0>
   65023:      	movq	0x10(%rsp), %rsi
   65028:      	jmp	0x650c5 <f.2+0xdf05>
   6502d:      	movq	$0x0, 0x50(%rsp)
   65036:      	movq	$0x3, 0x38(%rsp)
   6503f:      	xorl	%edi, %edi
   65041:      	leaq	-0xf(%r14), %rsi
   65045:      	callq	0x6e9d0 <f.3>
   6504a:      	subq	$0x8, %rsp
   6504e:      	cmpb	$0x0, 0xe85b(%rip)      # 0x738b0 <g.4>
   65055:      	je	0x6e9c5 <f.2+0x17805>
   6505b:      	movq	%rax, 0x18(%rsp)
   65060:      	cmpq	$0x0, 0xe840(%rip)      # 0x738a8 <g.3>
   65068:      	je	0x6e9c5 <f.2+0x17805>
   6506e:      	leaq	-0x10(%r14), %rsi
   65072:      	movq	$0x0, 0x50(%rsp)
   6507b:      	movq	$0x3, 0x38(%rsp)
   65084:      	xorl	%edi, %edi
   65086:      	callq	0x6e9d0 <f.3>
   6508b:      	subq	$0x8, %rsp
   6508f:      	cmpb	$0x0, 0xe81a(%rip)      # 0x738b0 <g.4>
   65096:      	je	0x6e9c5 <f.2+0x17805>
   6509c:      	cmpq	$0x0, 0xe804(%rip)      # 0x738a8 <g.3>
   650a4:      	leaq	0x28(%rsp), %r8
   650a9:      	leaq	0x20(%rsp), %rdi
   650ae:      	leaq	0xe713(%rip), %r9       # 0x737c8 <native_roots.0>
   650b5:      	movq	0x10(%rsp), %rsi
   650ba:      	je	0x6e9c5 <f.2+0x17805>
   650c0:      	addq	0x18(%rsp), %rax
   650c5:      	addq	%r13, %rax
   650c8:      	cmpq	$0xe, %r14
   650cc:      	je	0x650e1 <f.2+0xdf21>
   650ce:      	cmpq	$0xf, %r14
   650d2:      	jne	0x650f7 <f.2+0xdf37>
   650d4:      	movl	$0x1, %ecx
   650d9:      	xorl	%r13d, %r13d
   650dc:      	jmp	0x65239 <f.2+0xe079>
   650e1:      	leaq	(%r14,%rax), %r13
   650e5:      	addq	$-0xd, %r13
   650e9:      	movl	$0x1, %ecx
   650ee:      	leaq	-0xe(%r14), %rdx
   650f2:      	jmp	0x655c8 <f.2+0xe408>
   650f7:      	movq	%rax, 0x18(%rsp)
   650fc:      	leaq	-0xf(%r14), %r13
   65100:      	movq	$0x0, 0x50(%rsp)
   65109:      	movq	$0x3, 0x38(%rsp)
   65112:      	xorl	%edi, %edi
   65114:      	movq	%r13, %rsi
   65117:      	callq	0x6e9d0 <f.3>
   6511c:      	subq	$0x8, %rsp
   65120:      	cmpb	$0x0, 0xe789(%rip)      # 0x738b0 <g.4>
   65127:      	je	0x6e9c5 <f.2+0x17805>
   6512d:      	movq	%rax, 0x58(%rsp)
   65132:      	cmpq	$0x0, 0xe76e(%rip)      # 0x738a8 <g.3>
   6513a:      	je	0x6e9c5 <f.2+0x17805>
   65140:      	leaq	-0x10(%r14), %rsi
   65144:      	movq	$0x0, 0x50(%rsp)
   6514d:      	movq	$0x3, 0x38(%rsp)
   65156:      	xorl	%edi, %edi
   65158:      	callq	0x6e9d0 <f.3>
   6515d:      	subq	$0x8, %rsp
   65161:      	cmpb	$0x0, 0xe748(%rip)      # 0x738b0 <g.4>
   65168:      	je	0x6e9c5 <f.2+0x17805>
   6516e:      	movq	%rax, %rcx
   65171:      	cmpq	$0x0, 0xe72f(%rip)      # 0x738a8 <g.3>
   65179:      	leaq	0x28(%rsp), %r8
   6517e:      	leaq	0xe643(%rip), %r9       # 0x737c8 <native_roots.0>
   65185:      	movq	0x10(%rsp), %rsi
   6518a:      	movq	0x18(%rsp), %rax
   6518f:      	je	0x6e9c5 <f.2+0x17805>
   65195:      	addq	0x58(%rsp), %rcx
   6519a:      	cmpq	$0x11, %r14
   6519e:      	jae	0x651aa <f.2+0xdfea>
   651a0:      	leaq	0x20(%rsp), %rdi
   651a5:      	jmp	0x65239 <f.2+0xe079>
   651aa:      	movq	%rcx, 0x58(%rsp)
   651af:      	movq	$0x0, 0x50(%rsp)
   651b8:      	movq	$0x3, 0x38(%rsp)
   651c1:      	xorl	%edi, %edi
   651c3:      	leaq	-0x10(%r14), %rsi
   651c7:      	callq	0x6e9d0 <f.3>
   651cc:      	subq	$0x8, %rsp
   651d0:      	cmpb	$0x0, 0xe6d9(%rip)      # 0x738b0 <g.4>
   651d7:      	je	0x6e9c5 <f.2+0x17805>
   651dd:      	movq	%rax, 0x60(%rsp)
   651e2:      	cmpq	$0x0, 0xe6be(%rip)      # 0x738a8 <g.3>
   651ea:      	je	0x6e9c5 <f.2+0x17805>
   651f0:      	leaq	-0x11(%r14), %rsi
   651f4:      	movq	$0x0, 0x50(%rsp)
   651fd:      	movq	$0x3, 0x38(%rsp)
   65206:      	xorl	%edi, %edi
   65208:      	callq	0x6e9d0 <f.3>
   6520d:      	subq	$0x8, %rsp
   65211:      	movq	%rax, %r13
   65214:      	addq	0x60(%rsp), %r13
   65219:      	leaq	0x28(%rsp), %r8
   6521e:      	leaq	0x20(%rsp), %rdi
   65223:      	leaq	0xe59e(%rip), %r9       # 0x737c8 <native_roots.0>
   6522a:      	movq	0x10(%rsp), %rsi
   6522f:      	movq	0x18(%rsp), %rax
   65234:      	movq	0x58(%rsp), %rcx
   65239:      	cmpb	$0x0, 0xe670(%rip)      # 0x738b0 <g.4>
   65240:      	je	0x6e9c5 <f.2+0x17805>
   65246:      	cmpq	$0x0, 0xe65a(%rip)      # 0x738a8 <g.3>
   6524e:      	je	0x6e9c5 <f.2+0x17805>
   65254:      	addq	%rcx, %r13
   65257:      	addq	%rax, %r13
   6525a:      	movq	%r14, %rcx
   6525d:      	subq	$0xf, %rcx
   65261:      	jbe	0x65317 <f.2+0xe157>
   65267:      	movq	$0x0, 0x50(%rsp)
   65270:      	movq	$0x3, 0x38(%rsp)
   65279:      	xorl	%edi, %edi
   6527b:      	movq	%rcx, 0x18(%rsp)
   65280:      	movq	%rcx, %rsi
   65283:      	callq	0x6e9d0 <f.3>
   65288:      	subq	$0x8, %rsp
   6528c:      	cmpb	$0x0, 0xe61d(%rip)      # 0x738b0 <g.4>
   65293:      	je	0x6e9c5 <f.2+0x17805>
   65299:      	movq	%rax, 0x58(%rsp)
   6529e:      	cmpq	$0x0, 0xe602(%rip)      # 0x738a8 <g.3>
   652a6:      	je	0x6e9c5 <f.2+0x17805>
   652ac:      	leaq	-0x10(%r14), %rsi
   652b0:      	movq	$0x0, 0x50(%rsp)
   652b9:      	movq	$0x3, 0x38(%rsp)
   652c2:      	xorl	%edi, %edi
   652c4:      	callq	0x6e9d0 <f.3>
   652c9:      	subq	$0x8, %rsp
   652cd:      	cmpb	$0x0, 0xe5dc(%rip)      # 0x738b0 <g.4>
   652d4:      	je	0x6e9c5 <f.2+0x17805>
   652da:      	cmpq	$0x0, 0xe5c6(%rip)      # 0x738a8 <g.3>
   652e2:      	leaq	0x28(%rsp), %r8
   652e7:      	leaq	0xe4da(%rip), %r9       # 0x737c8 <native_roots.0>
   652ee:      	movq	0x18(%rsp), %rcx
   652f3:      	je	0x6e9c5 <f.2+0x17805>
   652f9:      	addq	0x58(%rsp), %rax
   652fe:      	cmpq	$0x10, %r14
   65302:      	leaq	-0x10(%r14), %rsi
   65306:      	jne	0x65323 <f.2+0xe163>
   65308:      	addq	%rax, %rcx
   6530b:      	movl	$0x1, %edx
   65310:      	xorl	%eax, %eax
   65312:      	jmp	0x65454 <f.2+0xe294>
   65317:      	incq	%rcx
   6531a:      	leaq	-0xe(%r14), %rdx
   6531e:      	jmp	0x655c8 <f.2+0xe408>
   65323:      	movq	%rax, 0x58(%rsp)
   65328:      	movq	$0x0, 0x50(%rsp)
   65331:      	movq	$0x3, 0x38(%rsp)
   6533a:      	xorl	%edi, %edi
   6533c:      	callq	0x6e9d0 <f.3>
   65341:      	subq	$0x8, %rsp
   65345:      	cmpb	$0x0, 0xe564(%rip)      # 0x738b0 <g.4>
   6534c:      	je	0x6e9c5 <f.2+0x17805>
   65352:      	movq	%rax, 0x60(%rsp)
   65357:      	cmpq	$0x0, 0xe549(%rip)      # 0x738a8 <g.3>
   6535f:      	je	0x6e9c5 <f.2+0x17805>
   65365:      	leaq	-0x11(%r14), %rsi
   65369:      	movq	$0x0, 0x50(%rsp)
   65372:      	movq	$0x3, 0x38(%rsp)
   6537b:      	xorl	%edi, %edi
   6537d:      	callq	0x6e9d0 <f.3>
   65382:      	subq	$0x8, %rsp
   65386:      	cmpb	$0x0, 0xe523(%rip)      # 0x738b0 <g.4>
   6538d:      	je	0x6e9c5 <f.2+0x17805>
   65393:      	movq	%rax, 0x18(%rsp)
   65398:      	cmpq	$0x0, 0xe508(%rip)      # 0x738a8 <g.3>
   653a0:      	leaq	-0x10(%r14), %rsi
   653a4:      	je	0x6e9c5 <f.2+0x17805>
   653aa:      	movq	$0x0, 0x50(%rsp)
   653b3:      	movq	$0x3, 0x38(%rsp)
   653bc:      	xorl	%edi, %edi
   653be:      	callq	0x6e9d0 <f.3>
   653c3:      	subq	$0x8, %rsp
   653c7:      	cmpb	$0x0, 0xe4e2(%rip)      # 0x738b0 <g.4>
   653ce:      	je	0x6e9c5 <f.2+0x17805>
   653d4:      	movq	%rax, 0x68(%rsp)
   653d9:      	cmpq	$0x0, 0xe4c7(%rip)      # 0x738a8 <g.3>
   653e1:      	je	0x6e9c5 <f.2+0x17805>
   653e7:      	movq	$0x0, 0x50(%rsp)
   653f0:      	movq	$0x3, 0x38(%rsp)
   653f9:      	xorl	%edi, %edi
   653fb:      	leaq	-0x11(%r14), %rsi
   653ff:      	callq	0x6e9d0 <f.3>
   65404:      	subq	$0x8, %rsp
   65408:      	cmpb	$0x0, 0xe4a1(%rip)      # 0x738b0 <g.4>
   6540f:      	je	0x6e9c5 <f.2+0x17805>
   65415:      	movq	%rax, %rdx
   65418:      	cmpq	$0x0, 0xe488(%rip)      # 0x738a8 <g.3>
   65420:      	leaq	0x28(%rsp), %r8
   65425:      	leaq	0xe39c(%rip), %r9       # 0x737c8 <native_roots.0>
   6542c:      	movq	0x18(%rsp), %rcx
   65431:      	leaq	-0x10(%r14), %rax
   65435:      	je	0x6e9c5 <f.2+0x17805>
   6543b:      	addq	0x60(%rsp), %rcx
   65440:      	addq	0x58(%rsp), %rcx
   65445:      	addq	0x68(%rsp), %rdx
   6544a:      	cmpq	$0x12, %r14
   6544e:      	jae	0x65534 <f.2+0xe374>
   65454:      	leaq	0x20(%rsp), %rdi
   65459:      	movq	0x10(%rsp), %rsi
   6545e:      	jmp	0x655c5 <f.2+0xe405>
   65463:      	movq	%rsi, 0x10(%rsp)
   65468:      	movq	$0x0, 0x50(%rsp)
   65471:      	movq	$0x3, 0x38(%rsp)
   6547a:      	xorl	%edi, %edi
   6547c:      	leaq	-0x10(%r14), %rsi
   65480:      	callq	0x6e9d0 <f.3>
   65485:      	subq	$0x8, %rsp
   65489:      	cmpb	$0x0, 0xe420(%rip)      # 0x738b0 <g.4>
   65490:      	je	0x6e9c5 <f.2+0x17805>
   65496:      	movq	%rax, 0x58(%rsp)
   6549b:      	cmpq	$0x0, 0xe405(%rip)      # 0x738a8 <g.3>
   654a3:      	je	0x6e9c5 <f.2+0x17805>
   654a9:      	leaq	-0x11(%r14), %rsi
   654ad:      	movq	$0x0, 0x50(%rsp)
   654b6:      	movq	$0x3, 0x38(%rsp)
   654bf:      	xorl	%edi, %edi
   654c1:      	callq	0x6e9d0 <f.3>
   654c6:      	subq	$0x8, %rsp
   654ca:      	movq	%rax, %rcx
   654cd:      	addq	0x58(%rsp), %rcx
   654d2:      	leaq	0x28(%rsp), %r8
   654d7:      	leaq	0x20(%rsp), %rdi
   654dc:      	leaq	0xe2e5(%rip), %r9       # 0x737c8 <native_roots.0>
   654e3:      	movq	0x10(%rsp), %rsi
   654e8:      	movq	0x18(%rsp), %rax
   654ed:      	addq	%rcx, %r13
   654f0:      	addq	%r13, %rsi
   654f3:      	cmpb	$0x0, 0xe3b6(%rip)      # 0x738b0 <g.4>
   654fa:      	je	0x6e9c5 <f.2+0x17805>
   65500:      	cmpq	$0x0, 0xe3a0(%rip)      # 0x738a8 <g.3>
   65508:      	je	0x6e9c5 <f.2+0x17805>
   6550e:      	addq	%rbp, %rsi
   65511:      	addq	%rax, %rsi
   65514:      	cmpq	$0x9, %r14
   65518:      	jne	0x63fb8 <f.2+0xcdf8>
   6551e:      	leaq	(%r14,%rsi), %r13
   65522:      	addq	$-0x8, %r13
   65526:      	movl	$0x1, %ebp
   6552b:      	leaq	-0x9(%r14), %rsi
   6552f:      	jmp	0x6e434 <f.2+0x17274>
   65534:      	movq	%rdx, 0x58(%rsp)
   65539:      	movq	%rcx, 0x18(%rsp)
   6553e:      	movq	$0x0, 0x50(%rsp)
   65547:      	movq	$0x3, 0x38(%rsp)
   65550:      	xorl	%edi, %edi
   65552:      	leaq	-0x11(%r14), %rsi
   65556:      	callq	0x6e9d0 <f.3>
   6555b:      	subq	$0x8, %rsp
   6555f:      	cmpb	$0x0, 0xe34a(%rip)      # 0x738b0 <g.4>
   65566:      	je	0x6e9c5 <f.2+0x17805>
   6556c:      	movq	%rax, 0x60(%rsp)
   65571:      	cmpq	$0x0, 0xe32f(%rip)      # 0x738a8 <g.3>
   65579:      	je	0x6e9c5 <f.2+0x17805>
   6557f:      	leaq	-0x12(%r14), %rsi
   65583:      	movq	$0x0, 0x50(%rsp)
   6558c:      	movq	$0x3, 0x38(%rsp)
   65595:      	xorl	%edi, %edi
   65597:      	callq	0x6e9d0 <f.3>
   6559c:      	subq	$0x8, %rsp
   655a0:      	addq	0x60(%rsp), %rax
   655a5:      	leaq	0x28(%rsp), %r8
   655aa:      	leaq	0x20(%rsp), %rdi
   655af:      	leaq	0xe212(%rip), %r9       # 0x737c8 <native_roots.0>
   655b6:      	movq	0x10(%rsp), %rsi
   655bb:      	movq	0x18(%rsp), %rcx
   655c0:      	movq	0x58(%rsp), %rdx
   655c5:      	addq	%rax, %rdx
   655c8:      	addq	%rdx, %rcx
   655cb:      	addq	%rcx, %r13
   655ce:      	cmpb	$0x0, 0xe2db(%rip)      # 0x738b0 <g.4>
   655d5:      	je	0x6e9c5 <f.2+0x17805>
   655db:      	cmpq	$0x0, 0xe2c5(%rip)      # 0x738a8 <g.3>
   655e3:      	je	0x6e9c5 <f.2+0x17805>
   655e9:      	addq	%rbp, %r13
   655ec:      	addq	%rsi, %r13
   655ef:      	cmpq	$0xa, %r14
   655f3:      	jbe	0x65618 <f.2+0xe458>
   655f5:      	movl	$0x1, %eax
   655fa:      	cmpq	$0xb, %r14
   655fe:      	je	0x65629 <f.2+0xe469>
   65600:      	cmpq	$0xc, %r14
   65604:      	jbe	0x65625 <f.2+0xe465>
   65606:      	cmpq	$0xd, %r14
   6560a:      	jne	0x65673 <f.2+0xe4b3>
   6560c:      	movl	$0x1, %ebp
   65611:      	xorl	%eax, %eax
   65613:      	jmp	0x6585d <f.2+0xe69d>
   65618:      	leaq	-0x9(%r14), %rbp
   6561c:      	leaq	-0x9(%r14), %rsi
   65620:      	jmp	0x6e434 <f.2+0x17274>
   65625:      	leaq	-0xb(%r14), %rax
   65629:      	addq	%r14, %rax
   6562c:      	addq	$-0xb, %rax
   65630:      	cmpq	$0xb, %r14
   65634:      	je	0x660e0 <f.2+0xef20>
   6563a:      	movl	$0x1, %ecx
   6563f:      	cmpq	$0xc, %r14
   65643:      	je	0x6566a <f.2+0xe4aa>
   65645:      	cmpq	$0xd, %r14
   65649:      	jbe	0x65666 <f.2+0xe4a6>
   6564b:      	cmpq	$0xe, %r14
   6564f:      	movq	%rax, 0x10(%rsp)
   65654:      	jne	0x6571c <f.2+0xe55c>
   6565a:      	movl	$0x1, %ebp
   6565f:      	xorl	%edx, %edx
   65661:      	jmp	0x659d8 <f.2+0xe818>
   65666:      	leaq	-0xc(%r14), %rcx
   6566a:      	leaq	-0xc(%r14), %rbp
   6566e:      	jmp	0x6618b <f.2+0xefcb>
   65673:      	leaq	-0xd(%r14), %rsi
   65677:      	movq	$0x0, 0x50(%rsp)
   65680:      	movq	$0x3, 0x38(%rsp)
   65689:      	xorl	%edi, %edi
   6568b:      	callq	0x6e9d0 <f.3>
   65690:      	subq	$0x8, %rsp
   65694:      	cmpb	$0x0, 0xe215(%rip)      # 0x738b0 <g.4>
   6569b:      	je	0x6e9c5 <f.2+0x17805>
   656a1:      	movq	%rax, 0x10(%rsp)
   656a6:      	cmpq	$0x0, 0xe1fa(%rip)      # 0x738a8 <g.3>
   656ae:      	je	0x6e9c5 <f.2+0x17805>
   656b4:      	leaq	-0xe(%r14), %rsi
   656b8:      	movq	$0x0, 0x50(%rsp)
   656c1:      	movq	$0x3, 0x38(%rsp)
   656ca:      	xorl	%edi, %edi
   656cc:      	callq	0x6e9d0 <f.3>
   656d1:      	subq	$0x8, %rsp
   656d5:      	cmpb	$0x0, 0xe1d4(%rip)      # 0x738b0 <g.4>
   656dc:      	je	0x6e9c5 <f.2+0x17805>
   656e2:      	movq	%rax, %rbp
   656e5:      	cmpq	$0x0, 0xe1bb(%rip)      # 0x738a8 <g.3>
   656ed:      	leaq	-0xd(%r14), %rax
   656f1:      	je	0x6e9c5 <f.2+0x17805>
   656f7:      	addq	0x10(%rsp), %rbp
   656fc:      	cmpq	$0xe, %r14
   65700:      	ja	0x657ca <f.2+0xe60a>
   65706:      	leaq	0x28(%rsp), %r8
   6570b:      	leaq	0x20(%rsp), %rdi
   65710:      	leaq	0xe0b1(%rip), %r9       # 0x737c8 <native_roots.0>
   65717:      	jmp	0x6585d <f.2+0xe69d>
   6571c:      	leaq	-0xe(%r14), %rsi
   65720:      	movq	$0x0, 0x50(%rsp)
   65729:      	movq	$0x3, 0x38(%rsp)
   65732:      	xorl	%edi, %edi
   65734:      	callq	0x6e9d0 <f.3>
   65739:      	subq	$0x8, %rsp
   6573d:      	cmpb	$0x0, 0xe16c(%rip)      # 0x738b0 <g.4>
   65744:      	je	0x6e9c5 <f.2+0x17805>
   6574a:      	movq	%rax, 0x18(%rsp)
   6574f:      	cmpq	$0x0, 0xe151(%rip)      # 0x738a8 <g.3>
   65757:      	je	0x6e9c5 <f.2+0x17805>
   6575d:      	leaq	-0xf(%r14), %rsi
   65761:      	movq	$0x0, 0x50(%rsp)
   6576a:      	movq	$0x3, 0x38(%rsp)
   65773:      	xorl	%edi, %edi
   65775:      	callq	0x6e9d0 <f.3>
   6577a:      	subq	$0x8, %rsp
   6577e:      	cmpb	$0x0, 0xe12b(%rip)      # 0x738b0 <g.4>
   65785:      	je	0x6e9c5 <f.2+0x17805>
   6578b:      	cmpq	$0x0, 0xe115(%rip)      # 0x738a8 <g.3>
   65793:      	leaq	0x28(%rsp), %r8
   65798:      	leaq	0xe029(%rip), %r9       # 0x737c8 <native_roots.0>
   6579f:      	leaq	-0xe(%r14), %rdx
   657a3:      	je	0x6e9c5 <f.2+0x17805>
   657a9:      	movq	%rax, %rbp
   657ac:      	addq	0x18(%rsp), %rbp
   657b1:      	cmpq	$0xf, %r14
   657b5:      	ja	0x6593d <f.2+0xe77d>
   657bb:      	leaq	0x20(%rsp), %rdi
   657c0:      	movq	0x10(%rsp), %rax
   657c5:      	jmp	0x659d8 <f.2+0xe818>
   657ca:      	movq	$0x0, 0x50(%rsp)
   657d3:      	movq	$0x3, 0x38(%rsp)
   657dc:      	xorl	%edi, %edi
   657de:      	leaq	-0xe(%r14), %rsi
   657e2:      	callq	0x6e9d0 <f.3>
   657e7:      	subq	$0x8, %rsp
   657eb:      	cmpb	$0x0, 0xe0be(%rip)      # 0x738b0 <g.4>
   657f2:      	je	0x6e9c5 <f.2+0x17805>
   657f8:      	movq	%rax, 0x10(%rsp)
   657fd:      	cmpq	$0x0, 0xe0a3(%rip)      # 0x738a8 <g.3>
   65805:      	je	0x6e9c5 <f.2+0x17805>
   6580b:      	leaq	-0xf(%r14), %rsi
   6580f:      	movq	$0x0, 0x50(%rsp)
   65818:      	movq	$0x3, 0x38(%rsp)
   65821:      	xorl	%edi, %edi
   65823:      	callq	0x6e9d0 <f.3>
   65828:      	subq	$0x8, %rsp
   6582c:      	cmpb	$0x0, 0xe07d(%rip)      # 0x738b0 <g.4>
   65833:      	je	0x6e9c5 <f.2+0x17805>
   65839:      	cmpq	$0x0, 0xe067(%rip)      # 0x738a8 <g.3>
   65841:      	leaq	0x28(%rsp), %r8
   65846:      	leaq	0x20(%rsp), %rdi
   6584b:      	leaq	0xdf76(%rip), %r9       # 0x737c8 <native_roots.0>
   65852:      	je	0x6e9c5 <f.2+0x17805>
   65858:      	addq	0x10(%rsp), %rax
   6585d:      	addq	%rbp, %rax
   65860:      	cmpq	$0xd, %r14
   65864:      	je	0x65878 <f.2+0xe6b8>
   65866:      	cmpq	$0xe, %r14
   6586a:      	jne	0x6588e <f.2+0xe6ce>
   6586c:      	movl	$0x1, %edx
   65871:      	xorl	%ecx, %ecx
   65873:      	jmp	0x65b43 <f.2+0xe983>
   65878:      	leaq	(%r14,%rax), %rcx
   6587c:      	addq	$-0xc, %rcx
   65880:      	movl	$0x1, %ebp
   65885:      	leaq	-0xd(%r14), %rax
   65889:      	jmp	0x660b5 <f.2+0xeef5>
   6588e:      	movq	%rax, 0x10(%rsp)
   65893:      	leaq	-0xe(%r14), %rsi
   65897:      	movq	$0x0, 0x50(%rsp)
   658a0:      	movq	$0x3, 0x38(%rsp)
   658a9:      	xorl	%edi, %edi
   658ab:      	callq	0x6e9d0 <f.3>
   658b0:      	subq	$0x8, %rsp
   658b4:      	cmpb	$0x0, 0xdff5(%rip)      # 0x738b0 <g.4>
   658bb:      	je	0x6e9c5 <f.2+0x17805>
   658c1:      	cmpq	$0x0, 0xdfdf(%rip)      # 0x738a8 <g.3>
   658c9:      	je	0x6e9c5 <f.2+0x17805>
   658cf:      	movq	%rax, %rbp
   658d2:      	leaq	-0xf(%r14), %rsi
   658d6:      	movq	$0x0, 0x50(%rsp)
   658df:      	movq	$0x3, 0x38(%rsp)
   658e8:      	xorl	%edi, %edi
   658ea:      	callq	0x6e9d0 <f.3>
   658ef:      	subq	$0x8, %rsp
   658f3:      	cmpb	$0x0, 0xdfb6(%rip)      # 0x738b0 <g.4>
   658fa:      	je	0x6e9c5 <f.2+0x17805>
   65900:      	movq	%rax, %rdx
   65903:      	cmpq	$0x0, 0xdf9d(%rip)      # 0x738a8 <g.3>
   6590b:      	leaq	0x28(%rsp), %r8
   65910:      	leaq	0xdeb1(%rip), %r9       # 0x737c8 <native_roots.0>
   65917:      	leaq	-0xe(%r14), %rcx
   6591b:      	movq	0x10(%rsp), %rax
   65920:      	je	0x6e9c5 <f.2+0x17805>
   65926:      	addq	%rbp, %rdx
   65929:      	cmpq	$0x10, %r14
   6592d:      	jae	0x65abd <f.2+0xe8fd>
   65933:      	leaq	0x20(%rsp), %rdi
   65938:      	jmp	0x65b43 <f.2+0xe983>
   6593d:      	movq	$0x0, 0x50(%rsp)
   65946:      	movq	$0x3, 0x38(%rsp)
   6594f:      	xorl	%edi, %edi
   65951:      	leaq	-0xf(%r14), %rsi
   65955:      	callq	0x6e9d0 <f.3>
   6595a:      	subq	$0x8, %rsp
   6595e:      	cmpb	$0x0, 0xdf4b(%rip)      # 0x738b0 <g.4>
   65965:      	je	0x6e9c5 <f.2+0x17805>
   6596b:      	movq	%rax, 0x18(%rsp)
   65970:      	cmpq	$0x0, 0xdf30(%rip)      # 0x738a8 <g.3>
   65978:      	je	0x6e9c5 <f.2+0x17805>
   6597e:      	leaq	-0x10(%r14), %rsi
   65982:      	movq	$0x0, 0x50(%rsp)
   6598b:      	movq	$0x3, 0x38(%rsp)
   65994:      	xorl	%edi, %edi
   65996:      	callq	0x6e9d0 <f.3>
   6599b:      	subq	$0x8, %rsp
   6599f:      	cmpb	$0x0, 0xdf0a(%rip)      # 0x738b0 <g.4>
   659a6:      	je	0x6e9c5 <f.2+0x17805>
   659ac:      	movq	%rax, %rdx
   659af:      	cmpq	$0x0, 0xdef1(%rip)      # 0x738a8 <g.3>
   659b7:      	leaq	0x28(%rsp), %r8
   659bc:      	leaq	0x20(%rsp), %rdi
   659c1:      	leaq	0xde00(%rip), %r9       # 0x737c8 <native_roots.0>
   659c8:      	movq	0x10(%rsp), %rax
   659cd:      	je	0x6e9c5 <f.2+0x17805>
   659d3:      	addq	0x18(%rsp), %rdx
   659d8:      	addq	%rbp, %rdx
   659db:      	cmpq	$0xe, %r14
   659df:      	je	0x659f3 <f.2+0xe833>
   659e1:      	cmpq	$0xf, %r14
   659e5:      	jne	0x65a09 <f.2+0xe849>
   659e7:      	movl	$0x1, %esi
   659ec:      	xorl	%ecx, %ecx
   659ee:      	jmp	0x65df3 <f.2+0xec33>
   659f3:      	leaq	(%r14,%rdx), %rcx
   659f7:      	addq	$-0xd, %rcx
   659fb:      	movl	$0x1, %ebp
   65a00:      	leaq	-0xe(%r14), %rsi
   65a04:      	jmp	0x66188 <f.2+0xefc8>
   65a09:      	movq	%rdx, 0x18(%rsp)
   65a0e:      	leaq	-0xf(%r14), %rsi
   65a12:      	movq	$0x0, 0x50(%rsp)
   65a1b:      	movq	$0x3, 0x38(%rsp)
   65a24:      	xorl	%edi, %edi
   65a26:      	callq	0x6e9d0 <f.3>
   65a2b:      	subq	$0x8, %rsp
   65a2f:      	cmpb	$0x0, 0xde7a(%rip)      # 0x738b0 <g.4>
   65a36:      	je	0x6e9c5 <f.2+0x17805>
   65a3c:      	cmpq	$0x0, 0xde64(%rip)      # 0x738a8 <g.3>
   65a44:      	je	0x6e9c5 <f.2+0x17805>
   65a4a:      	movq	%rax, %rbp
   65a4d:      	leaq	-0x10(%r14), %rsi
   65a51:      	movq	$0x0, 0x50(%rsp)
   65a5a:      	movq	$0x3, 0x38(%rsp)
   65a63:      	xorl	%edi, %edi
   65a65:      	callq	0x6e9d0 <f.3>
   65a6a:      	subq	$0x8, %rsp
   65a6e:      	cmpb	$0x0, 0xde3b(%rip)      # 0x738b0 <g.4>
   65a75:      	je	0x6e9c5 <f.2+0x17805>
   65a7b:      	movq	%rax, %rsi
   65a7e:      	cmpq	$0x0, 0xde22(%rip)      # 0x738a8 <g.3>
   65a86:      	leaq	0x20(%rsp), %rdi
   65a8b:      	movq	0x10(%rsp), %rax
   65a90:      	leaq	-0xf(%r14), %rcx
   65a94:      	movq	0x18(%rsp), %rdx
   65a99:      	je	0x6e9c5 <f.2+0x17805>
   65a9f:      	addq	%rbp, %rsi
   65aa2:      	cmpq	$0x11, %r14
   65aa6:      	jae	0x65d68 <f.2+0xeba8>
   65aac:      	leaq	0x28(%rsp), %r8
   65ab1:      	leaq	0xdd10(%rip), %r9       # 0x737c8 <native_roots.0>
   65ab8:      	jmp	0x65df3 <f.2+0xec33>
   65abd:      	movq	%rdx, 0x18(%rsp)
   65ac2:      	movq	$0x0, 0x50(%rsp)
   65acb:      	movq	$0x3, 0x38(%rsp)
   65ad4:      	xorl	%edi, %edi
   65ad6:      	leaq	-0xf(%r14), %rsi
   65ada:      	callq	0x6e9d0 <f.3>
   65adf:      	subq	$0x8, %rsp
   65ae3:      	cmpb	$0x0, 0xddc6(%rip)      # 0x738b0 <g.4>
   65aea:      	je	0x6e9c5 <f.2+0x17805>
   65af0:      	cmpq	$0x0, 0xddb0(%rip)      # 0x738a8 <g.3>
   65af8:      	je	0x6e9c5 <f.2+0x17805>
   65afe:      	movq	%rax, %rbp
   65b01:      	leaq	-0x10(%r14), %rsi
   65b05:      	movq	$0x0, 0x50(%rsp)
   65b0e:      	movq	$0x3, 0x38(%rsp)
   65b17:      	xorl	%edi, %edi
   65b19:      	callq	0x6e9d0 <f.3>
   65b1e:      	subq	$0x8, %rsp
   65b22:      	movq	%rax, %rcx
   65b25:      	addq	%rbp, %rcx
   65b28:      	leaq	0x28(%rsp), %r8
   65b2d:      	leaq	0x20(%rsp), %rdi
   65b32:      	leaq	0xdc8f(%rip), %r9       # 0x737c8 <native_roots.0>
   65b39:      	movq	0x10(%rsp), %rax
   65b3e:      	movq	0x18(%rsp), %rdx
   65b43:      	cmpb	$0x0, 0xdd66(%rip)      # 0x738b0 <g.4>
   65b4a:      	je	0x6e9c5 <f.2+0x17805>
   65b50:      	cmpq	$0x0, 0xdd50(%rip)      # 0x738a8 <g.3>
   65b58:      	je	0x6e9c5 <f.2+0x17805>
   65b5e:      	addq	%rdx, %rcx
   65b61:      	addq	%rax, %rcx
   65b64:      	movq	%r14, %rbp
   65b67:      	subq	$0xe, %rbp
   65b6b:      	jbe	0x65c26 <f.2+0xea66>
   65b71:      	movq	%rcx, 0x18(%rsp)
   65b76:      	movq	$0x0, 0x50(%rsp)
   65b7f:      	movq	$0x3, 0x38(%rsp)
   65b88:      	xorl	%edi, %edi
   65b8a:      	movq	%rbp, %rsi
   65b8d:      	callq	0x6e9d0 <f.3>
   65b92:      	subq	$0x8, %rsp
   65b96:      	cmpb	$0x0, 0xdd13(%rip)      # 0x738b0 <g.4>
   65b9d:      	je	0x6e9c5 <f.2+0x17805>
   65ba3:      	movq	%rax, 0x10(%rsp)
   65ba8:      	cmpq	$0x0, 0xdcf8(%rip)      # 0x738a8 <g.3>
   65bb0:      	je	0x6e9c5 <f.2+0x17805>
   65bb6:      	leaq	-0xf(%r14), %rsi
   65bba:      	movq	$0x0, 0x50(%rsp)
   65bc3:      	movq	$0x3, 0x38(%rsp)
   65bcc:      	xorl	%edi, %edi
   65bce:      	callq	0x6e9d0 <f.3>
   65bd3:      	subq	$0x8, %rsp
   65bd7:      	cmpb	$0x0, 0xdcd2(%rip)      # 0x738b0 <g.4>
   65bde:      	je	0x6e9c5 <f.2+0x17805>
   65be4:      	cmpq	$0x0, 0xdcbc(%rip)      # 0x738a8 <g.3>
   65bec:      	leaq	0x28(%rsp), %r8
   65bf1:      	leaq	0xdbd0(%rip), %r9       # 0x737c8 <native_roots.0>
   65bf8:      	movq	0x18(%rsp), %rcx
   65bfd:      	je	0x6e9c5 <f.2+0x17805>
   65c03:      	addq	0x10(%rsp), %rax
   65c08:      	cmpq	$0xf, %r14
   65c0c:      	leaq	-0xf(%r14), %rsi
   65c10:      	jne	0x65c32 <f.2+0xea72>
   65c12:      	addq	%rax, %rbp
   65c15:      	movl	$0x1, %eax
   65c1a:      	xorl	%edx, %edx
   65c1c:      	leaq	0x20(%rsp), %rdi
   65c21:      	jmp	0x660b2 <f.2+0xeef2>
   65c26:      	incq	%rbp
   65c29:      	leaq	-0xd(%r14), %rax
   65c2d:      	jmp	0x660b5 <f.2+0xeef5>
   65c32:      	movq	%rax, 0x10(%rsp)
   65c37:      	movq	$0x0, 0x50(%rsp)
   65c40:      	movq	$0x3, 0x38(%rsp)
   65c49:      	xorl	%edi, %edi
   65c4b:      	callq	0x6e9d0 <f.3>
   65c50:      	subq	$0x8, %rsp
   65c54:      	cmpb	$0x0, 0xdc55(%rip)      # 0x738b0 <g.4>
   65c5b:      	je	0x6e9c5 <f.2+0x17805>
   65c61:      	movq	%rax, 0x58(%rsp)
   65c66:      	cmpq	$0x0, 0xdc3a(%rip)      # 0x738a8 <g.3>
   65c6e:      	je	0x6e9c5 <f.2+0x17805>
   65c74:      	leaq	-0x10(%r14), %rsi
   65c78:      	movq	$0x0, 0x50(%rsp)
   65c81:      	movq	$0x3, 0x38(%rsp)
   65c8a:      	xorl	%edi, %edi
   65c8c:      	callq	0x6e9d0 <f.3>
   65c91:      	subq	$0x8, %rsp
   65c95:      	cmpb	$0x0, 0xdc14(%rip)      # 0x738b0 <g.4>
   65c9c:      	je	0x6e9c5 <f.2+0x17805>
   65ca2:      	cmpq	$0x0, 0xdbfe(%rip)      # 0x738a8 <g.3>
   65caa:      	leaq	-0xf(%r14), %rsi
   65cae:      	je	0x6e9c5 <f.2+0x17805>
   65cb4:      	movq	%rax, %rbp
   65cb7:      	movq	$0x0, 0x50(%rsp)
   65cc0:      	movq	$0x3, 0x38(%rsp)
   65cc9:      	xorl	%edi, %edi
   65ccb:      	callq	0x6e9d0 <f.3>
   65cd0:      	subq	$0x8, %rsp
   65cd4:      	cmpb	$0x0, 0xdbd5(%rip)      # 0x738b0 <g.4>
   65cdb:      	je	0x6e9c5 <f.2+0x17805>
   65ce1:      	movq	%rax, 0x60(%rsp)
   65ce6:      	cmpq	$0x0, 0xdbba(%rip)      # 0x738a8 <g.3>
   65cee:      	je	0x6e9c5 <f.2+0x17805>
   65cf4:      	movq	$0x0, 0x50(%rsp)
   65cfd:      	movq	$0x3, 0x38(%rsp)
   65d06:      	xorl	%edi, %edi
   65d08:      	leaq	-0x10(%r14), %rsi
   65d0c:      	callq	0x6e9d0 <f.3>
   65d11:      	subq	$0x8, %rsp
   65d15:      	cmpb	$0x0, 0xdb94(%rip)      # 0x738b0 <g.4>
   65d1c:      	je	0x6e9c5 <f.2+0x17805>
   65d22:      	cmpq	$0x0, 0xdb7e(%rip)      # 0x738a8 <g.3>
   65d2a:      	leaq	0x28(%rsp), %r8
   65d2f:      	leaq	0xda92(%rip), %r9       # 0x737c8 <native_roots.0>
   65d36:      	movq	0x18(%rsp), %rcx
   65d3b:      	leaq	-0xf(%r14), %rdx
   65d3f:      	je	0x6e9c5 <f.2+0x17805>
   65d45:      	addq	0x58(%rsp), %rbp
   65d4a:      	addq	0x10(%rsp), %rbp
   65d4f:      	addq	0x60(%rsp), %rax
   65d54:      	cmpq	$0x11, %r14
   65d58:      	jae	0x66028 <f.2+0xee68>
   65d5e:      	leaq	0x20(%rsp), %rdi
   65d63:      	jmp	0x660b2 <f.2+0xeef2>
   65d68:      	movq	%rsi, 0x58(%rsp)
   65d6d:      	movq	$0x0, 0x50(%rsp)
   65d76:      	movq	$0x3, 0x38(%rsp)
   65d7f:      	xorl	%edi, %edi
   65d81:      	leaq	-0x10(%r14), %rsi
   65d85:      	callq	0x6e9d0 <f.3>
   65d8a:      	subq	$0x8, %rsp
   65d8e:      	cmpb	$0x0, 0xdb1b(%rip)      # 0x738b0 <g.4>
   65d95:      	je	0x6e9c5 <f.2+0x17805>
   65d9b:      	cmpq	$0x0, 0xdb05(%rip)      # 0x738a8 <g.3>
   65da3:      	je	0x6e9c5 <f.2+0x17805>
   65da9:      	movq	%rax, %rbp
   65dac:      	leaq	-0x11(%r14), %rsi
   65db0:      	movq	$0x0, 0x50(%rsp)
   65db9:      	movq	$0x3, 0x38(%rsp)
   65dc2:      	xorl	%edi, %edi
   65dc4:      	callq	0x6e9d0 <f.3>
   65dc9:      	subq	$0x8, %rsp
   65dcd:      	movq	%rax, %rcx
   65dd0:      	addq	%rbp, %rcx
   65dd3:      	leaq	0x28(%rsp), %r8
   65dd8:      	leaq	0x20(%rsp), %rdi
   65ddd:      	leaq	0xd9e4(%rip), %r9       # 0x737c8 <native_roots.0>
   65de4:      	movq	0x10(%rsp), %rax
   65de9:      	movq	0x18(%rsp), %rdx
   65dee:      	movq	0x58(%rsp), %rsi
   65df3:      	cmpb	$0x0, 0xdab6(%rip)      # 0x738b0 <g.4>
   65dfa:      	je	0x6e9c5 <f.2+0x17805>
   65e00:      	cmpq	$0x0, 0xdaa0(%rip)      # 0x738a8 <g.3>
   65e08:      	je	0x6e9c5 <f.2+0x17805>
   65e0e:      	addq	%rsi, %rcx
   65e11:      	addq	%rdx, %rcx
   65e14:      	movq	%r14, %rbp
   65e17:      	subq	$0xf, %rbp
   65e1b:      	jbe	0x65ede <f.2+0xed1e>
   65e21:      	movq	%rcx, 0x18(%rsp)
   65e26:      	movq	$0x0, 0x50(%rsp)
   65e2f:      	movq	$0x3, 0x38(%rsp)
   65e38:      	xorl	%edi, %edi
   65e3a:      	movq	%rbp, %rsi
   65e3d:      	callq	0x6e9d0 <f.3>
   65e42:      	subq	$0x8, %rsp
   65e46:      	cmpb	$0x0, 0xda63(%rip)      # 0x738b0 <g.4>
   65e4d:      	je	0x6e9c5 <f.2+0x17805>
   65e53:      	movq	%rax, 0x58(%rsp)
   65e58:      	cmpq	$0x0, 0xda48(%rip)      # 0x738a8 <g.3>
   65e60:      	je	0x6e9c5 <f.2+0x17805>
   65e66:      	leaq	-0x10(%r14), %rsi
   65e6a:      	movq	$0x0, 0x50(%rsp)
   65e73:      	movq	$0x3, 0x38(%rsp)
   65e7c:      	xorl	%edi, %edi
   65e7e:      	callq	0x6e9d0 <f.3>
   65e83:      	subq	$0x8, %rsp
   65e87:      	cmpb	$0x0, 0xda22(%rip)      # 0x738b0 <g.4>
   65e8e:      	je	0x6e9c5 <f.2+0x17805>
   65e94:      	movq	%rax, %rdx
   65e97:      	cmpq	$0x0, 0xda09(%rip)      # 0x738a8 <g.3>
   65e9f:      	leaq	0x20(%rsp), %rdi
   65ea4:      	movq	0x10(%rsp), %rax
   65ea9:      	movq	0x18(%rsp), %rcx
   65eae:      	je	0x6e9c5 <f.2+0x17805>
   65eb4:      	addq	0x58(%rsp), %rdx
   65eb9:      	cmpq	$0x10, %r14
   65ebd:      	leaq	-0x10(%r14), %rsi
   65ec1:      	jne	0x65eea <f.2+0xed2a>
   65ec3:      	addq	%rdx, %rbp
   65ec6:      	movl	$0x1, %esi
   65ecb:      	xorl	%edx, %edx
   65ecd:      	leaq	0x28(%rsp), %r8
   65ed2:      	leaq	0xd8ef(%rip), %r9       # 0x737c8 <native_roots.0>
   65ed9:      	jmp	0x66185 <f.2+0xefc5>
   65ede:      	incq	%rbp
   65ee1:      	leaq	-0xe(%r14), %rsi
   65ee5:      	jmp	0x66188 <f.2+0xefc8>
   65eea:      	movq	%rdx, 0x58(%rsp)
   65eef:      	movq	$0x0, 0x50(%rsp)
   65ef8:      	movq	$0x3, 0x38(%rsp)
   65f01:      	xorl	%edi, %edi
   65f03:      	callq	0x6e9d0 <f.3>
   65f08:      	subq	$0x8, %rsp
   65f0c:      	cmpb	$0x0, 0xd99d(%rip)      # 0x738b0 <g.4>
   65f13:      	je	0x6e9c5 <f.2+0x17805>
   65f19:      	movq	%rax, 0x60(%rsp)
   65f1e:      	cmpq	$0x0, 0xd982(%rip)      # 0x738a8 <g.3>
   65f26:      	je	0x6e9c5 <f.2+0x17805>
   65f2c:      	leaq	-0x11(%r14), %rsi
   65f30:      	movq	$0x0, 0x50(%rsp)
   65f39:      	movq	$0x3, 0x38(%rsp)
   65f42:      	xorl	%edi, %edi
   65f44:      	callq	0x6e9d0 <f.3>
   65f49:      	subq	$0x8, %rsp
   65f4d:      	cmpb	$0x0, 0xd95c(%rip)      # 0x738b0 <g.4>
   65f54:      	je	0x6e9c5 <f.2+0x17805>
   65f5a:      	cmpq	$0x0, 0xd946(%rip)      # 0x738a8 <g.3>
   65f62:      	leaq	-0x10(%r14), %rsi
   65f66:      	je	0x6e9c5 <f.2+0x17805>
   65f6c:      	movq	%rax, %rbp
   65f6f:      	movq	$0x0, 0x50(%rsp)
   65f78:      	movq	$0x3, 0x38(%rsp)
   65f81:      	xorl	%edi, %edi
   65f83:      	callq	0x6e9d0 <f.3>
   65f88:      	subq	$0x8, %rsp
   65f8c:      	cmpb	$0x0, 0xd91d(%rip)      # 0x738b0 <g.4>
   65f93:      	je	0x6e9c5 <f.2+0x17805>
   65f99:      	movq	%rax, 0x68(%rsp)
   65f9e:      	cmpq	$0x0, 0xd902(%rip)      # 0x738a8 <g.3>
   65fa6:      	je	0x6e9c5 <f.2+0x17805>
   65fac:      	movq	$0x0, 0x50(%rsp)
   65fb5:      	movq	$0x3, 0x38(%rsp)
   65fbe:      	xorl	%edi, %edi
   65fc0:      	leaq	-0x11(%r14), %rsi
   65fc4:      	callq	0x6e9d0 <f.3>
   65fc9:      	subq	$0x8, %rsp
   65fcd:      	cmpb	$0x0, 0xd8dc(%rip)      # 0x738b0 <g.4>
   65fd4:      	je	0x6e9c5 <f.2+0x17805>
   65fda:      	movq	%rax, %rsi
   65fdd:      	cmpq	$0x0, 0xd8c3(%rip)      # 0x738a8 <g.3>
   65fe5:      	movq	0x10(%rsp), %rax
   65fea:      	movq	0x18(%rsp), %rcx
   65fef:      	leaq	-0x10(%r14), %rdx
   65ff3:      	je	0x6e9c5 <f.2+0x17805>
   65ff9:      	addq	0x60(%rsp), %rbp
   65ffe:      	addq	0x58(%rsp), %rbp
   66003:      	addq	0x68(%rsp), %rsi
   66008:      	cmpq	$0x12, %r14
   6600c:      	jae	0x660f6 <f.2+0xef36>
   66012:      	leaq	0x28(%rsp), %r8
   66017:      	leaq	0x20(%rsp), %rdi
   6601c:      	leaq	0xd7a5(%rip), %r9       # 0x737c8 <native_roots.0>
   66023:      	jmp	0x66185 <f.2+0xefc5>
   66028:      	movq	%rax, 0x10(%rsp)
   6602d:      	movq	$0x0, 0x50(%rsp)
   66036:      	movq	$0x3, 0x38(%rsp)
   6603f:      	xorl	%edi, %edi
   66041:      	leaq	-0x10(%r14), %rsi
   66045:      	callq	0x6e9d0 <f.3>
   6604a:      	subq	$0x8, %rsp
   6604e:      	cmpb	$0x0, 0xd85b(%rip)      # 0x738b0 <g.4>
   66055:      	je	0x6e9c5 <f.2+0x17805>
   6605b:      	movq	%rax, 0x58(%rsp)
   66060:      	cmpq	$0x0, 0xd840(%rip)      # 0x738a8 <g.3>
   66068:      	je	0x6e9c5 <f.2+0x17805>
   6606e:      	leaq	-0x11(%r14), %rsi
   66072:      	movq	$0x0, 0x50(%rsp)
   6607b:      	movq	$0x3, 0x38(%rsp)
   66084:      	xorl	%edi, %edi
   66086:      	callq	0x6e9d0 <f.3>
   6608b:      	subq	$0x8, %rsp
   6608f:      	movq	%rax, %rdx
   66092:      	addq	0x58(%rsp), %rdx
   66097:      	leaq	0x28(%rsp), %r8
   6609c:      	leaq	0x20(%rsp), %rdi
   660a1:      	leaq	0xd720(%rip), %r9       # 0x737c8 <native_roots.0>
   660a8:      	movq	0x10(%rsp), %rax
   660ad:      	movq	0x18(%rsp), %rcx
   660b2:      	addq	%rdx, %rax
   660b5:      	cmpb	$0x0, 0xd7f4(%rip)      # 0x738b0 <g.4>
   660bc:      	je	0x6e9c5 <f.2+0x17805>
   660c2:      	cmpq	$0x0, 0xd7de(%rip)      # 0x738a8 <g.3>
   660ca:      	je	0x6e9c5 <f.2+0x17805>
   660d0:      	addq	%rbp, %rax
   660d3:      	addq	%rcx, %rax
   660d6:      	cmpq	$0xb, %r14
   660da:      	jne	0x6563a <f.2+0xe47a>
   660e0:      	leaq	(%r14,%rax), %rbp
   660e4:      	addq	$-0xa, %rbp
   660e8:      	movl	$0x1, %esi
   660ed:      	leaq	-0xb(%r14), %rax
   660f1:      	jmp	0x6e431 <f.2+0x17271>
   660f6:      	movq	%rsi, 0x58(%rsp)
   660fb:      	movq	$0x0, 0x50(%rsp)
   66104:      	movq	$0x3, 0x38(%rsp)
   6610d:      	xorl	%edi, %edi
   6610f:      	leaq	-0x11(%r14), %rsi
   66113:      	callq	0x6e9d0 <f.3>
   66118:      	subq	$0x8, %rsp
   6611c:      	cmpb	$0x0, 0xd78d(%rip)      # 0x738b0 <g.4>
   66123:      	je	0x6e9c5 <f.2+0x17805>
   66129:      	movq	%rax, 0x60(%rsp)
   6612e:      	cmpq	$0x0, 0xd772(%rip)      # 0x738a8 <g.3>
   66136:      	je	0x6e9c5 <f.2+0x17805>
   6613c:      	leaq	-0x12(%r14), %rsi
   66140:      	movq	$0x0, 0x50(%rsp)
   66149:      	movq	$0x3, 0x38(%rsp)
   66152:      	xorl	%edi, %edi
   66154:      	callq	0x6e9d0 <f.3>
   66159:      	subq	$0x8, %rsp
   6615d:      	movq	%rax, %rdx
   66160:      	addq	0x60(%rsp), %rdx
   66165:      	leaq	0x28(%rsp), %r8
   6616a:      	leaq	0x20(%rsp), %rdi
   6616f:      	leaq	0xd652(%rip), %r9       # 0x737c8 <native_roots.0>
   66176:      	movq	0x10(%rsp), %rax
   6617b:      	movq	0x18(%rsp), %rcx
   66180:      	movq	0x58(%rsp), %rsi
   66185:      	addq	%rdx, %rsi
   66188:      	addq	%rsi, %rbp
   6618b:      	cmpb	$0x0, 0xd71e(%rip)      # 0x738b0 <g.4>
   66192:      	je	0x6e9c5 <f.2+0x17805>
   66198:      	cmpq	$0x0, 0xd708(%rip)      # 0x738a8 <g.3>
   661a0:      	je	0x6e9c5 <f.2+0x17805>
   661a6:      	movl	$0x1, %edx
   661ab:      	cmpq	$0xd, %r14
   661af:      	jb	0x664aa <f.2+0xf2ea>
   661b5:      	je	0x66298 <f.2+0xf0d8>
   661bb:      	movq	%r14, %rdx
   661be:      	subq	$0xe, %rdx
   661c2:      	jbe	0x66295 <f.2+0xf0d5>
   661c8:      	movq	%rcx, 0x18(%rsp)
   661cd:      	movq	%rax, 0x10(%rsp)
   661d2:      	movq	$0x0, 0x50(%rsp)
   661db:      	movq	$0x3, 0x38(%rsp)
   661e4:      	xorl	%edi, %edi
   661e6:      	movq	%rdx, 0x58(%rsp)
   661eb:      	movq	%rdx, %rsi
   661ee:      	callq	0x6e9d0 <f.3>
   661f3:      	subq	$0x8, %rsp
   661f7:      	cmpb	$0x0, 0xd6b2(%rip)      # 0x738b0 <g.4>
   661fe:      	je	0x6e9c5 <f.2+0x17805>
   66204:      	movq	%rax, 0x60(%rsp)
   66209:      	cmpq	$0x0, 0xd697(%rip)      # 0x738a8 <g.3>
   66211:      	je	0x6e9c5 <f.2+0x17805>
   66217:      	leaq	-0xf(%r14), %rsi
   6621b:      	movq	$0x0, 0x50(%rsp)
   66224:      	movq	$0x3, 0x38(%rsp)
   6622d:      	xorl	%edi, %edi
   6622f:      	callq	0x6e9d0 <f.3>
   66234:      	subq	$0x8, %rsp
   66238:      	cmpb	$0x0, 0xd671(%rip)      # 0x738b0 <g.4>
   6623f:      	je	0x6e9c5 <f.2+0x17805>
   66245:      	movq	%rax, %rdx
   66248:      	cmpq	$0x0, 0xd658(%rip)      # 0x738a8 <g.3>
   66250:      	leaq	0x28(%rsp), %r8
   66255:      	leaq	0x20(%rsp), %rdi
   6625a:      	leaq	0xd567(%rip), %r9       # 0x737c8 <native_roots.0>
   66261:      	movq	0x10(%rsp), %rax
   66266:      	movq	0x18(%rsp), %rcx
   6626b:      	je	0x6e9c5 <f.2+0x17805>
   66271:      	addq	0x60(%rsp), %rdx
   66276:      	cmpq	$0xf, %r14
   6627a:      	leaq	-0xf(%r14), %rsi
   6627e:      	jne	0x662a4 <f.2+0xf0e4>
   66280:      	movq	0x58(%rsp), %rsi
   66285:      	addq	%rdx, %rsi
   66288:      	movl	$0x1, %r10d
   6628e:      	xorl	%edx, %edx
   66290:      	jmp	0x6647d <f.2+0xf2bd>
   66295:      	incq	%rdx
   66298:      	addq	%r14, %rdx
   6629b:      	addq	$-0xd, %rdx
   6629f:      	jmp	0x6649e <f.2+0xf2de>
   662a4:      	movq	%rdx, 0x60(%rsp)
   662a9:      	movq	$0x0, 0x50(%rsp)
   662b2:      	movq	$0x3, 0x38(%rsp)
   662bb:      	xorl	%edi, %edi
   662bd:      	callq	0x6e9d0 <f.3>
   662c2:      	subq	$0x8, %rsp
   662c6:      	cmpb	$0x0, 0xd5e3(%rip)      # 0x738b0 <g.4>
   662cd:      	je	0x6e9c5 <f.2+0x17805>
   662d3:      	movq	%rax, 0x68(%rsp)
   662d8:      	cmpq	$0x0, 0xd5c8(%rip)      # 0x738a8 <g.3>
   662e0:      	je	0x6e9c5 <f.2+0x17805>
   662e6:      	leaq	-0x10(%r14), %rsi
   662ea:      	movq	$0x0, 0x50(%rsp)
   662f3:      	movq	$0x3, 0x38(%rsp)
   662fc:      	xorl	%edi, %edi
   662fe:      	callq	0x6e9d0 <f.3>
   66303:      	subq	$0x8, %rsp
   66307:      	movq	%rax, 0x58(%rsp)
   6630c:      	cmpb	$0x0, 0xd59d(%rip)      # 0x738b0 <g.4>
   66313:      	je	0x6e9c5 <f.2+0x17805>
   66319:      	cmpq	$0x0, 0xd587(%rip)      # 0x738a8 <g.3>
   66321:      	leaq	-0xf(%r14), %rsi
   66325:      	je	0x6e9c5 <f.2+0x17805>
   6632b:      	movq	$0x0, 0x50(%rsp)
   66334:      	movq	$0x3, 0x38(%rsp)
   6633d:      	xorl	%edi, %edi
   6633f:      	callq	0x6e9d0 <f.3>
   66344:      	subq	$0x8, %rsp
   66348:      	cmpb	$0x0, 0xd561(%rip)      # 0x738b0 <g.4>
   6634f:      	je	0x6e9c5 <f.2+0x17805>
   66355:      	movq	%rax, 0x70(%rsp)
   6635a:      	cmpq	$0x0, 0xd546(%rip)      # 0x738a8 <g.3>
   66362:      	je	0x6e9c5 <f.2+0x17805>
   66368:      	movq	$0x0, 0x50(%rsp)
   66371:      	movq	$0x3, 0x38(%rsp)
   6637a:      	xorl	%edi, %edi
   6637c:      	leaq	-0x10(%r14), %rsi
   66380:      	callq	0x6e9d0 <f.3>
   66385:      	subq	$0x8, %rsp
   66389:      	cmpb	$0x0, 0xd520(%rip)      # 0x738b0 <g.4>
   66390:      	je	0x6e9c5 <f.2+0x17805>
   66396:      	movq	%rax, %r10
   66399:      	cmpq	$0x0, 0xd507(%rip)      # 0x738a8 <g.3>
   663a1:      	leaq	0x28(%rsp), %r8
   663a6:      	leaq	0x20(%rsp), %rdi
   663ab:      	leaq	0xd416(%rip), %r9       # 0x737c8 <native_roots.0>
   663b2:      	movq	0x10(%rsp), %rax
   663b7:      	movq	0x18(%rsp), %rcx
   663bc:      	leaq	-0xf(%r14), %rdx
   663c0:      	movq	0x58(%rsp), %rsi
   663c5:      	je	0x6e9c5 <f.2+0x17805>
   663cb:      	addq	0x68(%rsp), %rsi
   663d0:      	addq	0x60(%rsp), %rsi
   663d5:      	addq	0x70(%rsp), %r10
   663da:      	cmpq	$0x11, %r14
   663de:      	jb	0x6647d <f.2+0xf2bd>
   663e4:      	movq	%r10, 0x60(%rsp)
   663e9:      	movq	%rsi, 0x58(%rsp)
   663ee:      	movq	$0x0, 0x50(%rsp)
   663f7:      	movq	$0x3, 0x38(%rsp)
   66400:      	xorl	%edi, %edi
   66402:      	leaq	-0x10(%r14), %rsi
   66406:      	callq	0x6e9d0 <f.3>
   6640b:      	subq	$0x8, %rsp
   6640f:      	cmpb	$0x0, 0xd49a(%rip)      # 0x738b0 <g.4>
   66416:      	je	0x6e9c5 <f.2+0x17805>
   6641c:      	movq	%rax, 0x68(%rsp)
   66421:      	cmpq	$0x0, 0xd47f(%rip)      # 0x738a8 <g.3>
   66429:      	je	0x6e9c5 <f.2+0x17805>
   6642f:      	leaq	-0x11(%r14), %rsi
   66433:      	movq	$0x0, 0x50(%rsp)
   6643c:      	movq	$0x3, 0x38(%rsp)
   66445:      	xorl	%edi, %edi
   66447:      	callq	0x6e9d0 <f.3>
   6644c:      	subq	$0x8, %rsp
   66450:      	movq	%rax, %rdx
   66453:      	addq	0x68(%rsp), %rdx
   66458:      	leaq	0x28(%rsp), %r8
   6645d:      	leaq	0x20(%rsp), %rdi
   66462:      	leaq	0xd35f(%rip), %r9       # 0x737c8 <native_roots.0>
   66469:      	movq	0x10(%rsp), %rax
   6646e:      	movq	0x18(%rsp), %rcx
   66473:      	movq	0x58(%rsp), %rsi
   66478:      	movq	0x60(%rsp), %r10
   6647d:      	cmpb	$0x0, 0xd42c(%rip)      # 0x738b0 <g.4>
   66484:      	je	0x6e9c5 <f.2+0x17805>
   6648a:      	cmpq	$0x0, 0xd416(%rip)      # 0x738a8 <g.3>
   66492:      	je	0x6e9c5 <f.2+0x17805>
   66498:      	addq	%r10, %rdx
   6649b:      	addq	%rsi, %rdx
   6649e:      	cmpq	$0xe, %r14
   664a2:      	je	0x664b3 <f.2+0xf2f3>
   664a4:      	cmpq	$0xd, %r14
   664a8:      	jne	0x664c1 <f.2+0xf301>
   664aa:      	leaq	-0xc(%r14), %rsi
   664ae:      	jmp	0x667d5 <f.2+0xf615>
   664b3:      	movl	$0x1, %esi
   664b8:      	leaq	-0xe(%r14), %r10
   664bc:      	jmp	0x667d2 <f.2+0xf612>
   664c1:      	leaq	-0xf(%r14), %rsi
   664c5:      	movl	$0x1, %r10d
   664cb:      	cmpq	$0x10, %r14
   664cf:      	jb	0x66628 <f.2+0xf468>
   664d5:      	movq	%rdx, 0x60(%rsp)
   664da:      	movq	%rcx, 0x18(%rsp)
   664df:      	movq	%rax, 0x10(%rsp)
   664e4:      	movq	$0x0, 0x50(%rsp)
   664ed:      	movq	$0x3, 0x38(%rsp)
   664f6:      	xorl	%edi, %edi
   664f8:      	callq	0x6e9d0 <f.3>
   664fd:      	subq	$0x8, %rsp
   66501:      	cmpb	$0x0, 0xd3a8(%rip)      # 0x738b0 <g.4>
   66508:      	je	0x6e9c5 <f.2+0x17805>
   6650e:      	movq	%rax, 0x58(%rsp)
   66513:      	cmpq	$0x0, 0xd38d(%rip)      # 0x738a8 <g.3>
   6651b:      	je	0x6e9c5 <f.2+0x17805>
   66521:      	leaq	-0x10(%r14), %rsi
   66525:      	movq	$0x0, 0x50(%rsp)
   6652e:      	movq	$0x3, 0x38(%rsp)
   66537:      	xorl	%edi, %edi
   66539:      	callq	0x6e9d0 <f.3>
   6653e:      	subq	$0x8, %rsp
   66542:      	cmpb	$0x0, 0xd367(%rip)      # 0x738b0 <g.4>
   66549:      	je	0x6e9c5 <f.2+0x17805>
   6654f:      	movq	%rax, %r10
   66552:      	cmpq	$0x0, 0xd34e(%rip)      # 0x738a8 <g.3>
   6655a:      	movq	0x10(%rsp), %rax
   6655f:      	movq	0x18(%rsp), %rcx
   66564:      	leaq	-0xf(%r14), %rsi
   66568:      	movq	0x60(%rsp), %rdx
   6656d:      	je	0x6e9c5 <f.2+0x17805>
   66573:      	addq	0x58(%rsp), %r10
   66578:      	cmpq	$0x10, %r14
   6657c:      	jne	0x66594 <f.2+0xf3d4>
   6657e:      	leaq	0x28(%rsp), %r8
   66583:      	leaq	0x20(%rsp), %rdi
   66588:      	leaq	0xd239(%rip), %r9       # 0x737c8 <native_roots.0>
   6658f:      	jmp	0x66628 <f.2+0xf468>
   66594:      	movq	%r10, 0x58(%rsp)
   66599:      	movq	$0x0, 0x50(%rsp)
   665a2:      	movq	$0x3, 0x38(%rsp)
   665ab:      	xorl	%edi, %edi
   665ad:      	leaq	-0x10(%r14), %rsi
   665b1:      	callq	0x6e9d0 <f.3>
   665b6:      	subq	$0x8, %rsp
   665ba:      	cmpb	$0x0, 0xd2ef(%rip)      # 0x738b0 <g.4>
   665c1:      	je	0x6e9c5 <f.2+0x17805>
   665c7:      	movq	%rax, 0x68(%rsp)
   665cc:      	cmpq	$0x0, 0xd2d4(%rip)      # 0x738a8 <g.3>
   665d4:      	je	0x6e9c5 <f.2+0x17805>
   665da:      	leaq	-0x11(%r14), %rsi
   665de:      	movq	$0x0, 0x50(%rsp)
   665e7:      	movq	$0x3, 0x38(%rsp)
   665f0:      	xorl	%edi, %edi
   665f2:      	callq	0x6e9d0 <f.3>
   665f7:      	subq	$0x8, %rsp
   665fb:      	movq	%rax, %rsi
   665fe:      	addq	0x68(%rsp), %rsi
   66603:      	leaq	0x28(%rsp), %r8
   66608:      	leaq	0x20(%rsp), %rdi
   6660d:      	leaq	0xd1b4(%rip), %r9       # 0x737c8 <native_roots.0>
   66614:      	movq	0x10(%rsp), %rax
   66619:      	movq	0x18(%rsp), %rcx
   6661e:      	movq	0x60(%rsp), %rdx
   66623:      	movq	0x58(%rsp), %r10
   66628:      	cmpb	$0x0, 0xd281(%rip)      # 0x738b0 <g.4>
   6662f:      	je	0x6e9c5 <f.2+0x17805>
   66635:      	cmpq	$0x0, 0xd26b(%rip)      # 0x738a8 <g.3>
   6663d:      	je	0x6e9c5 <f.2+0x17805>
   66643:      	addq	%r10, %rsi
   66646:      	cmpq	$0xf, %r14
   6664a:      	ja	0x66655 <f.2+0xf495>
   6664c:      	leaq	-0xe(%r14), %r10
   66650:      	jmp	0x667d2 <f.2+0xf612>
   66655:      	cmpq	$0x10, %r14
   66659:      	jne	0x66669 <f.2+0xf4a9>
   6665b:      	movl	$0x1, %r10d
   66661:      	xorl	%r11d, %r11d
   66664:      	jmp	0x667cf <f.2+0xf60f>
   66669:      	movq	%rdx, 0x60(%rsp)
   6666e:      	movq	%rsi, 0x58(%rsp)
   66673:      	movq	%rcx, 0x18(%rsp)
   66678:      	movq	%rax, 0x10(%rsp)
   6667d:      	leaq	-0x10(%r14), %rsi
   66681:      	movq	$0x0, 0x50(%rsp)
   6668a:      	movq	$0x3, 0x38(%rsp)
   66693:      	xorl	%edi, %edi
   66695:      	callq	0x6e9d0 <f.3>
   6669a:      	subq	$0x8, %rsp
   6669e:      	cmpb	$0x0, 0xd20b(%rip)      # 0x738b0 <g.4>
   666a5:      	je	0x6e9c5 <f.2+0x17805>
   666ab:      	movq	%rax, 0x68(%rsp)
   666b0:      	cmpq	$0x0, 0xd1f0(%rip)      # 0x738a8 <g.3>
   666b8:      	je	0x6e9c5 <f.2+0x17805>
   666be:      	leaq	-0x11(%r14), %rsi
   666c2:      	movq	$0x0, 0x50(%rsp)
   666cb:      	movq	$0x3, 0x38(%rsp)
   666d4:      	xorl	%edi, %edi
   666d6:      	callq	0x6e9d0 <f.3>
   666db:      	subq	$0x8, %rsp
   666df:      	cmpb	$0x0, 0xd1ca(%rip)      # 0x738b0 <g.4>
   666e6:      	je	0x6e9c5 <f.2+0x17805>
   666ec:      	cmpq	$0x0, 0xd1b4(%rip)      # 0x738a8 <g.3>
   666f4:      	movq	0x18(%rsp), %rcx
   666f9:      	movq	0x60(%rsp), %rdx
   666fe:      	leaq	-0x10(%r14), %r11
   66702:      	je	0x6e9c5 <f.2+0x17805>
   66708:      	movq	%rax, %r10
   6670b:      	addq	0x68(%rsp), %r10
   66710:      	cmpq	$0x12, %r14
   66714:      	jae	0x66736 <f.2+0xf576>
   66716:      	leaq	0x28(%rsp), %r8
   6671b:      	leaq	0x20(%rsp), %rdi
   66720:      	leaq	0xd0a1(%rip), %r9       # 0x737c8 <native_roots.0>
   66727:      	movq	0x10(%rsp), %rax
   6672c:      	movq	0x58(%rsp), %rsi
   66731:      	jmp	0x667cf <f.2+0xf60f>
   66736:      	movq	%r10, 0x68(%rsp)
   6673b:      	movq	$0x0, 0x50(%rsp)
   66744:      	movq	$0x3, 0x38(%rsp)
   6674d:      	xorl	%edi, %edi
   6674f:      	leaq	-0x11(%r14), %rsi
   66753:      	callq	0x6e9d0 <f.3>
   66758:      	subq	$0x8, %rsp
   6675c:      	cmpb	$0x0, 0xd14d(%rip)      # 0x738b0 <g.4>
   66763:      	je	0x6e9c5 <f.2+0x17805>
   66769:      	movq	%rax, 0x70(%rsp)
   6676e:      	cmpq	$0x0, 0xd132(%rip)      # 0x738a8 <g.3>
   66776:      	je	0x6e9c5 <f.2+0x17805>
   6677c:      	leaq	-0x12(%r14), %rsi
   66780:      	movq	$0x0, 0x50(%rsp)
   66789:      	movq	$0x3, 0x38(%rsp)
   66792:      	xorl	%edi, %edi
   66794:      	callq	0x6e9d0 <f.3>
   66799:      	subq	$0x8, %rsp
   6679d:      	movq	%rax, %r11
   667a0:      	addq	0x70(%rsp), %r11
   667a5:      	leaq	0x28(%rsp), %r8
   667aa:      	leaq	0x20(%rsp), %rdi
   667af:      	leaq	0xd012(%rip), %r9       # 0x737c8 <native_roots.0>
   667b6:      	movq	0x10(%rsp), %rax
   667bb:      	movq	0x18(%rsp), %rcx
   667c0:      	movq	0x58(%rsp), %rsi
   667c5:      	movq	0x60(%rsp), %rdx
   667ca:      	movq	0x68(%rsp), %r10
   667cf:      	addq	%r11, %r10
   667d2:      	addq	%r10, %rsi
   667d5:      	cmpb	$0x0, 0xd0d4(%rip)      # 0x738b0 <g.4>
   667dc:      	je	0x6e9c5 <f.2+0x17805>
   667e2:      	cmpq	$0x0, 0xd0be(%rip)      # 0x738a8 <g.3>
   667ea:      	je	0x6e9c5 <f.2+0x17805>
   667f0:      	addq	%rcx, %rbp
   667f3:      	addq	%rax, %rbp
   667f6:      	addq	%rdx, %rsi
   667f9:      	cmpq	$0xc, %r14
   667fd:      	ja	0x66808 <f.2+0xf648>
   667ff:      	leaq	-0xb(%r14), %rax
   66803:      	jmp	0x6e431 <f.2+0x17271>
   66808:      	movl	$0x1, %eax
   6680d:      	cmpq	$0xd, %r14
   66811:      	je	0x66b17 <f.2+0xf957>
   66817:      	movl	$0x1, %ecx
   6681c:      	cmpq	$0xf, %r14
   66820:      	jb	0x66995 <f.2+0xf7d5>
   66826:      	jne	0x66832 <f.2+0xf672>
   66828:      	xorl	%eax, %eax
   6682a:      	addq	%rax, %rcx
   6682d:      	jmp	0x6697b <f.2+0xf7bb>
   66832:      	movq	%rsi, 0x58(%rsp)
   66837:      	leaq	-0xf(%r14), %rsi
   6683b:      	movq	$0x0, 0x50(%rsp)
   66844:      	movq	$0x3, 0x38(%rsp)
   6684d:      	xorl	%edi, %edi
   6684f:      	callq	0x6e9d0 <f.3>
   66854:      	subq	$0x8, %rsp
   66858:      	cmpb	$0x0, 0xd051(%rip)      # 0x738b0 <g.4>
   6685f:      	je	0x6e9c5 <f.2+0x17805>
   66865:      	movq	%rax, 0x10(%rsp)
   6686a:      	cmpq	$0x0, 0xd036(%rip)      # 0x738a8 <g.3>
   66872:      	je	0x6e9c5 <f.2+0x17805>
   66878:      	leaq	-0x10(%r14), %rsi
   6687c:      	movq	$0x0, 0x50(%rsp)
   66885:      	movq	$0x3, 0x38(%rsp)
   6688e:      	xorl	%edi, %edi
   66890:      	callq	0x6e9d0 <f.3>
   66895:      	subq	$0x8, %rsp
   66899:      	cmpb	$0x0, 0xd010(%rip)      # 0x738b0 <g.4>
   668a0:      	je	0x6e9c5 <f.2+0x17805>
   668a6:      	movq	%rax, %rcx
   668a9:      	cmpq	$0x0, 0xcff7(%rip)      # 0x738a8 <g.3>
   668b1:      	leaq	-0xf(%r14), %rax
   668b5:      	je	0x6e9c5 <f.2+0x17805>
   668bb:      	addq	0x10(%rsp), %rcx
   668c0:      	cmpq	$0x11, %r14
   668c4:      	jae	0x668e4 <f.2+0xf724>
   668c6:      	leaq	0x28(%rsp), %r8
   668cb:      	leaq	0x20(%rsp), %rdi
   668d0:      	leaq	0xcef1(%rip), %r9       # 0x737c8 <native_roots.0>
   668d7:      	movq	0x58(%rsp), %rsi
   668dc:      	addq	%rax, %rcx
   668df:      	jmp	0x6697b <f.2+0xf7bb>
   668e4:      	movq	%rcx, 0x10(%rsp)
   668e9:      	movq	$0x0, 0x50(%rsp)
   668f2:      	movq	$0x3, 0x38(%rsp)
   668fb:      	xorl	%edi, %edi
   668fd:      	leaq	-0x10(%r14), %rsi
   66901:      	callq	0x6e9d0 <f.3>
   66906:      	subq	$0x8, %rsp
   6690a:      	cmpb	$0x0, 0xcf9f(%rip)      # 0x738b0 <g.4>
   66911:      	je	0x6e9c5 <f.2+0x17805>
   66917:      	movq	%rax, 0x18(%rsp)
   6691c:      	cmpq	$0x0, 0xcf84(%rip)      # 0x738a8 <g.3>
   66924:      	je	0x6e9c5 <f.2+0x17805>
   6692a:      	leaq	-0x11(%r14), %rsi
   6692e:      	movq	$0x0, 0x50(%rsp)
   66937:      	movq	$0x3, 0x38(%rsp)
   66940:      	xorl	%edi, %edi
   66942:      	callq	0x6e9d0 <f.3>
   66947:      	subq	$0x8, %rsp
   6694b:      	cmpb	$0x0, 0xcf5e(%rip)      # 0x738b0 <g.4>
   66952:      	je	0x6e9c5 <f.2+0x17805>
   66958:      	addq	0x18(%rsp), %rax
   6695d:      	movq	0x10(%rsp), %rcx
   66962:      	addq	%rax, %rcx
   66965:      	leaq	0x28(%rsp), %r8
   6696a:      	leaq	0x20(%rsp), %rdi
   6696f:      	leaq	0xce52(%rip), %r9       # 0x737c8 <native_roots.0>
   66976:      	movq	0x58(%rsp), %rsi
   6697b:      	cmpq	$0x0, 0xcf25(%rip)      # 0x738a8 <g.3>
   66983:      	je	0x6e9c5 <f.2+0x17805>
   66989:      	cmpq	$0x10, %r14
   6698d:      	je	0x669a2 <f.2+0xf7e2>
   6698f:      	cmpq	$0xf, %r14
   66993:      	jne	0x669ae <f.2+0xf7ee>
   66995:      	leaq	(%r14,%rcx), %rax
   66999:      	addq	$-0xe, %rax
   6699d:      	jmp	0x66b03 <f.2+0xf943>
   669a2:      	movl	$0x1, %eax
   669a7:      	xorl	%edx, %edx
   669a9:      	jmp	0x66a5f <f.2+0xf89f>
   669ae:      	movq	%rcx, 0x10(%rsp)
   669b3:      	movq	%rsi, 0x58(%rsp)
   669b8:      	leaq	-0x10(%r14), %rsi
   669bc:      	movq	$0x0, 0x50(%rsp)
   669c5:      	movq	$0x3, 0x38(%rsp)
   669ce:      	xorl	%edi, %edi
   669d0:      	callq	0x6e9d0 <f.3>
   669d5:      	subq	$0x8, %rsp
   669d9:      	cmpb	$0x0, 0xced0(%rip)      # 0x738b0 <g.4>
   669e0:      	je	0x6e9c5 <f.2+0x17805>
   669e6:      	movq	%rax, 0x18(%rsp)
   669eb:      	cmpq	$0x0, 0xceb5(%rip)      # 0x738a8 <g.3>
   669f3:      	je	0x6e9c5 <f.2+0x17805>
   669f9:      	leaq	-0x11(%r14), %rsi
   669fd:      	movq	$0x0, 0x50(%rsp)
   66a06:      	movq	$0x3, 0x38(%rsp)
   66a0f:      	xorl	%edi, %edi
   66a11:      	callq	0x6e9d0 <f.3>
   66a16:      	subq	$0x8, %rsp
   66a1a:      	cmpb	$0x0, 0xce8f(%rip)      # 0x738b0 <g.4>
   66a21:      	je	0x6e9c5 <f.2+0x17805>
   66a27:      	cmpq	$0x0, 0xce79(%rip)      # 0x738a8 <g.3>
   66a2f:      	movq	0x10(%rsp), %rcx
   66a34:      	leaq	-0x10(%r14), %rdx
   66a38:      	je	0x6e9c5 <f.2+0x17805>
   66a3e:      	addq	0x18(%rsp), %rax
   66a43:      	cmpq	$0x12, %r14
   66a47:      	jae	0x66a6a <f.2+0xf8aa>
   66a49:      	leaq	0x28(%rsp), %r8
   66a4e:      	leaq	0x20(%rsp), %rdi
   66a53:      	leaq	0xcd6e(%rip), %r9       # 0x737c8 <native_roots.0>
   66a5a:      	movq	0x58(%rsp), %rsi
   66a5f:      	addq	%rdx, %rax
   66a62:      	addq	%rcx, %rax
   66a65:      	jmp	0x66b03 <f.2+0xf943>
   66a6a:      	movq	%rax, 0x18(%rsp)
   66a6f:      	movq	$0x0, 0x50(%rsp)
   66a78:      	movq	$0x3, 0x38(%rsp)
   66a81:      	xorl	%edi, %edi
   66a83:      	leaq	-0x11(%r14), %rsi
   66a87:      	callq	0x6e9d0 <f.3>
   66a8c:      	subq	$0x8, %rsp
   66a90:      	cmpb	$0x0, 0xce19(%rip)      # 0x738b0 <g.4>
   66a97:      	je	0x6e9c5 <f.2+0x17805>
   66a9d:      	movq	%rax, 0x60(%rsp)
   66aa2:      	cmpq	$0x0, 0xcdfe(%rip)      # 0x738a8 <g.3>
   66aaa:      	je	0x6e9c5 <f.2+0x17805>
   66ab0:      	leaq	-0x12(%r14), %rsi
   66ab4:      	movq	$0x0, 0x50(%rsp)
   66abd:      	movq	$0x3, 0x38(%rsp)
   66ac6:      	xorl	%edi, %edi
   66ac8:      	callq	0x6e9d0 <f.3>
   66acd:      	subq	$0x8, %rsp
   66ad1:      	cmpb	$0x0, 0xcdd8(%rip)      # 0x738b0 <g.4>
   66ad8:      	je	0x6e9c5 <f.2+0x17805>
   66ade:      	addq	0x60(%rsp), %rax
   66ae3:      	addq	0x18(%rsp), %rax
   66ae8:      	addq	0x10(%rsp), %rax
   66aed:      	leaq	0x28(%rsp), %r8
   66af2:      	leaq	0x20(%rsp), %rdi
   66af7:      	leaq	0xccca(%rip), %r9       # 0x737c8 <native_roots.0>
   66afe:      	movq	0x58(%rsp), %rsi
   66b03:      	cmpq	$0x0, 0xcd9d(%rip)      # 0x738a8 <g.3>
   66b0b:      	je	0x6e9c5 <f.2+0x17805>
   66b11:      	cmpq	$0xe, %r14
   66b15:      	ja	0x66b20 <f.2+0xf960>
   66b17:      	leaq	-0xd(%r14), %rcx
   66b1b:      	jmp	0x6e42e <f.2+0x1726e>
   66b20:      	movl	$0x1, %ecx
   66b25:      	cmpq	$0xf, %r14
   66b29:      	je	0x66e49 <f.2+0xfc89>
   66b2f:      	leaq	-0x10(%r14), %rcx
   66b33:      	movl	$0x1, %edx
   66b38:      	cmpq	$0x11, %r14
   66b3c:      	jb	0x66bf9 <f.2+0xfa39>
   66b42:      	movq	%rax, 0x18(%rsp)
   66b47:      	movq	%rsi, 0x58(%rsp)
   66b4c:      	movq	$0x0, 0x50(%rsp)
   66b55:      	movq	$0x3, 0x38(%rsp)
   66b5e:      	xorl	%edi, %edi
   66b60:      	movq	%rcx, %rsi
   66b63:      	callq	0x6e9d0 <f.3>
   66b68:      	subq	$0x8, %rsp
   66b6c:      	cmpb	$0x0, 0xcd3d(%rip)      # 0x738b0 <g.4>
   66b73:      	je	0x6e9c5 <f.2+0x17805>
   66b79:      	movq	%rax, 0x10(%rsp)
   66b7e:      	cmpq	$0x0, 0xcd22(%rip)      # 0x738a8 <g.3>
   66b86:      	je	0x6e9c5 <f.2+0x17805>
   66b8c:      	leaq	-0x11(%r14), %rsi
   66b90:      	movq	$0x0, 0x50(%rsp)
   66b99:      	movq	$0x3, 0x38(%rsp)
   66ba2:      	xorl	%edi, %edi
   66ba4:      	callq	0x6e9d0 <f.3>
   66ba9:      	subq	$0x8, %rsp
   66bad:      	cmpb	$0x0, 0xccfc(%rip)      # 0x738b0 <g.4>
   66bb4:      	je	0x6e9c5 <f.2+0x17805>
   66bba:      	movq	%rax, %rdx
   66bbd:      	cmpq	$0x0, 0xcce3(%rip)      # 0x738a8 <g.3>
   66bc5:      	leaq	0x20(%rsp), %rdi
   66bca:      	movq	0x18(%rsp), %rax
   66bcf:      	leaq	-0x10(%r14), %rcx
   66bd3:      	je	0x6e9c5 <f.2+0x17805>
   66bd9:      	addq	0x10(%rsp), %rdx
   66bde:      	cmpq	$0x11, %r14
   66be2:      	jne	0x66d99 <f.2+0xfbd9>
   66be8:      	leaq	0x28(%rsp), %r8
   66bed:      	leaq	0xcbd4(%rip), %r9       # 0x737c8 <native_roots.0>
   66bf4:      	movq	0x58(%rsp), %rsi
   66bf9:      	addq	%rdx, %rcx
   66bfc:      	jmp	0x66e35 <f.2+0xfc75>
   66c01:      	movq	%rsi, 0x58(%rsp)
   66c06:      	movq	%rdx, 0x10(%rsp)
   66c0b:      	movq	$0x0, 0x50(%rsp)
   66c14:      	movq	$0x3, 0x38(%rsp)
   66c1d:      	xorl	%edi, %edi
   66c1f:      	leaq	-0x11(%r14), %rsi
   66c23:      	callq	0x6e9d0 <f.3>
   66c28:      	subq	$0x8, %rsp
   66c2c:      	cmpb	$0x0, 0xcc7d(%rip)      # 0x738b0 <g.4>
   66c33:      	je	0x6e9c5 <f.2+0x17805>
   66c39:      	movq	%rax, 0x60(%rsp)
   66c3e:      	cmpq	$0x0, 0xcc62(%rip)      # 0x738a8 <g.3>
   66c46:      	je	0x6e9c5 <f.2+0x17805>
   66c4c:      	leaq	-0x12(%r14), %rsi
   66c50:      	movq	$0x0, 0x50(%rsp)
   66c59:      	movq	$0x3, 0x38(%rsp)
   66c62:      	xorl	%edi, %edi
   66c64:      	callq	0x6e9d0 <f.3>
   66c69:      	subq	$0x8, %rsp
   66c6d:      	movq	%rax, %rcx
   66c70:      	addq	0x60(%rsp), %rcx
   66c75:      	leaq	0x28(%rsp), %r8
   66c7a:      	leaq	0x20(%rsp), %rdi
   66c7f:      	leaq	0xcb42(%rip), %r9       # 0x737c8 <native_roots.0>
   66c86:      	movq	0x18(%rsp), %rax
   66c8b:      	movq	0x10(%rsp), %rdx
   66c90:      	movq	0x58(%rsp), %rsi
   66c95:      	addq	%rcx, %rsi
   66c98:      	addq	%rsi, %rdx
   66c9b:      	addq	%rdx, %rax
   66c9e:      	addq	%rax, %rbp
   66ca1:      	addq	%rbp, %r12
   66ca4:      	cmpb	$0x0, 0xcc05(%rip)      # 0x738b0 <g.4>
   66cab:      	je	0x6e9c5 <f.2+0x17805>
   66cb1:      	cmpq	$0x0, 0xcbef(%rip)      # 0x738a8 <g.3>
   66cb9:      	je	0x6e9c5 <f.2+0x17805>
   66cbf:      	addq	%r13, %r12
   66cc2:      	addq	%r15, %r12
   66cc5:      	cmpq	$0x5, %r14
   66cc9:      	jne	0x5733c <f.2+0x17c>
   66ccf:      	movl	$0x1, %r15d
   66cd5:      	leaq	-0x5(%r14), %r13
   66cd9:      	addq	%r13, %r15
   66cdc:      	cmpb	$0x0, 0xcbcd(%rip)      # 0x738b0 <g.4>
   66ce3:      	jne	0x57357 <f.2+0x197>
   66ce9:      	jmp	0x6e9c5 <f.2+0x17805>
   66cee:      	movq	%rsi, 0x10(%rsp)
   66cf3:      	movq	%r12, 0x18(%rsp)
   66cf8:      	movq	$0x0, 0x50(%rsp)
   66d01:      	movq	$0x3, 0x38(%rsp)
   66d0a:      	xorl	%edi, %edi
   66d0c:      	leaq	-0x10(%r14), %rsi
   66d10:      	callq	0x6e9d0 <f.3>
   66d15:      	subq	$0x8, %rsp
   66d19:      	cmpb	$0x0, 0xcb90(%rip)      # 0x738b0 <g.4>
   66d20:      	je	0x6e9c5 <f.2+0x17805>
   66d26:      	cmpq	$0x0, 0xcb7a(%rip)      # 0x738a8 <g.3>
   66d2e:      	je	0x6e9c5 <f.2+0x17805>
   66d34:      	movq	%rax, %r12
   66d37:      	leaq	-0x11(%r14), %rsi
   66d3b:      	movq	$0x0, 0x50(%rsp)
   66d44:      	movq	$0x3, 0x38(%rsp)
   66d4d:      	xorl	%edi, %edi
   66d4f:      	callq	0x6e9d0 <f.3>
   66d54:      	subq	$0x8, %rsp
   66d58:      	movq	%rax, %rcx
   66d5b:      	addq	%r12, %rcx
   66d5e:      	leaq	0x28(%rsp), %r8
   66d63:      	leaq	0x20(%rsp), %rdi
   66d68:      	leaq	0xca59(%rip), %r9       # 0x737c8 <native_roots.0>
   66d6f:      	movq	0x18(%rsp), %r12
   66d74:      	movq	0x10(%rsp), %rsi
   66d79:      	movq	0x58(%rsp), %rax
   66d7e:      	addq	%rcx, %r12
   66d81:      	cmpb	$0x0, 0xcb28(%rip)      # 0x738b0 <g.4>
   66d88:      	je	0x6e9c5 <f.2+0x17805>
   66d8e:      	addq	%rsi, %r12
   66d91:      	addq	%rax, %r12
   66d94:      	jmp	0x579a5 <f.2+0x7e5>
   66d99:      	movq	%rdx, 0x10(%rsp)
   66d9e:      	movq	$0x0, 0x50(%rsp)
   66da7:      	movq	$0x3, 0x38(%rsp)
   66db0:      	xorl	%edi, %edi
   66db2:      	leaq	-0x11(%r14), %rsi
   66db6:      	callq	0x6e9d0 <f.3>
   66dbb:      	subq	$0x8, %rsp
   66dbf:      	cmpb	$0x0, 0xcaea(%rip)      # 0x738b0 <g.4>
   66dc6:      	je	0x6e9c5 <f.2+0x17805>
   66dcc:      	movq	%rax, 0x60(%rsp)
   66dd1:      	cmpq	$0x0, 0xcacf(%rip)      # 0x738a8 <g.3>
   66dd9:      	je	0x6e9c5 <f.2+0x17805>
   66ddf:      	leaq	-0x12(%r14), %rsi
   66de3:      	movq	$0x0, 0x50(%rsp)
   66dec:      	movq	$0x3, 0x38(%rsp)
   66df5:      	xorl	%edi, %edi
   66df7:      	callq	0x6e9d0 <f.3>
   66dfc:      	subq	$0x8, %rsp
   66e00:      	cmpb	$0x0, 0xcaa9(%rip)      # 0x738b0 <g.4>
   66e07:      	je	0x6e9c5 <f.2+0x17805>
   66e0d:      	movq	%rax, %rcx
   66e10:      	addq	0x60(%rsp), %rcx
   66e15:      	addq	0x10(%rsp), %rcx
   66e1a:      	leaq	0x28(%rsp), %r8
   66e1f:      	leaq	0x20(%rsp), %rdi
   66e24:      	leaq	0xc99d(%rip), %r9       # 0x737c8 <native_roots.0>
   66e2b:      	movq	0x58(%rsp), %rsi
   66e30:      	movq	0x18(%rsp), %rax
   66e35:      	cmpq	$0x0, 0xca6b(%rip)      # 0x738a8 <g.3>
   66e3d:      	je	0x6e9c5 <f.2+0x17805>
   66e43:      	cmpq	$0x10, %r14
   66e47:      	ja	0x66e52 <f.2+0xfc92>
   66e49:      	leaq	-0xf(%r14), %rdx
   66e4d:      	jmp	0x6e42b <f.2+0x1726b>
   66e52:      	cmpq	$0x11, %r14
   66e56:      	jne	0x66e65 <f.2+0xfca5>
   66e58:      	movl	$0x1, %edx
   66e5d:      	xorl	%r10d, %r10d
   66e60:      	jmp	0x6e428 <f.2+0x17268>
   66e65:      	movq	%rcx, 0x10(%rsp)
   66e6a:      	movq	%rax, 0x18(%rsp)
   66e6f:      	movq	%rsi, 0x58(%rsp)
   66e74:      	leaq	-0x11(%r14), %rsi
   66e78:      	movq	$0x0, 0x50(%rsp)
   66e81:      	movq	$0x3, 0x38(%rsp)
   66e8a:      	xorl	%edi, %edi
   66e8c:      	callq	0x6e9d0 <f.3>
   66e91:      	subq	$0x8, %rsp
   66e95:      	cmpb	$0x0, 0xca14(%rip)      # 0x738b0 <g.4>
   66e9c:      	je	0x6e9c5 <f.2+0x17805>
   66ea2:      	movq	%rax, 0x60(%rsp)
   66ea7:      	cmpq	$0x0, 0xc9f9(%rip)      # 0x738a8 <g.3>
   66eaf:      	je	0x6e9c5 <f.2+0x17805>
   66eb5:      	leaq	-0x12(%r14), %rsi
   66eb9:      	movq	$0x0, 0x50(%rsp)
   66ec2:      	movq	$0x3, 0x38(%rsp)
   66ecb:      	xorl	%edi, %edi
   66ecd:      	callq	0x6e9d0 <f.3>
   66ed2:      	subq	$0x8, %rsp
   66ed6:      	cmpb	$0x0, 0xc9d3(%rip)      # 0x738b0 <g.4>
   66edd:      	je	0x6e9c5 <f.2+0x17805>
   66ee3:      	movq	%rax, %rdx
   66ee6:      	cmpq	$0x0, 0xc9ba(%rip)      # 0x738a8 <g.3>
   66eee:      	movq	0x58(%rsp), %rsi
   66ef3:      	movq	0x18(%rsp), %rax
   66ef8:      	movq	0x10(%rsp), %rcx
   66efd:      	leaq	-0x11(%r14), %r10
   66f01:      	je	0x6e9c5 <f.2+0x17805>
   66f07:      	addq	0x60(%rsp), %rdx
   66f0c:      	cmpq	$0x13, %r14
   66f10:      	jae	0x6e394 <f.2+0x171d4>
   66f16:      	leaq	0x28(%rsp), %r8
   66f1b:      	leaq	0x20(%rsp), %rdi
   66f20:      	leaq	0xc8a1(%rip), %r9       # 0x737c8 <native_roots.0>
   66f27:      	jmp	0x6e428 <f.2+0x17268>
   66f2c:      	movq	%rdx, 0x58(%rsp)
   66f31:      	movq	%rsi, 0x18(%rsp)
   66f36:      	movq	$0x0, 0x50(%rsp)
   66f3f:      	movq	$0x3, 0x38(%rsp)
   66f48:      	xorl	%edi, %edi
   66f4a:      	leaq	-0x11(%r14), %rsi
   66f4e:      	callq	0x6e9d0 <f.3>
   66f53:      	subq	$0x8, %rsp
   66f57:      	cmpb	$0x0, 0xc952(%rip)      # 0x738b0 <g.4>
   66f5e:      	je	0x6e9c5 <f.2+0x17805>
   66f64:      	movq	%rax, 0x60(%rsp)
   66f69:      	cmpq	$0x0, 0xc937(%rip)      # 0x738a8 <g.3>
   66f71:      	je	0x6e9c5 <f.2+0x17805>
   66f77:      	leaq	-0x12(%r14), %rsi
   66f7b:      	movq	$0x0, 0x50(%rsp)
   66f84:      	movq	$0x3, 0x38(%rsp)
   66f8d:      	xorl	%edi, %edi
   66f8f:      	callq	0x6e9d0 <f.3>
   66f94:      	subq	$0x8, %rsp
   66f98:      	addq	0x60(%rsp), %rax
   66f9d:      	leaq	0x28(%rsp), %r8
   66fa2:      	leaq	0x20(%rsp), %rdi
   66fa7:      	leaq	0xc81a(%rip), %r9       # 0x737c8 <native_roots.0>
   66fae:      	movq	0x10(%rsp), %rcx
   66fb3:      	movq	0x18(%rsp), %rsi
   66fb8:      	movq	0x58(%rsp), %rdx
   66fbd:      	addq	%rax, %rdx
   66fc0:      	addq	%rdx, %rsi
   66fc3:      	addq	%rsi, %rbp
   66fc6:      	cmpb	$0x0, 0xc8e3(%rip)      # 0x738b0 <g.4>
   66fcd:      	je	0x6e9c5 <f.2+0x17805>
   66fd3:      	cmpq	$0x0, 0xc8cd(%rip)      # 0x738a8 <g.3>
   66fdb:      	je	0x6e9c5 <f.2+0x17805>
   66fe1:      	addq	%r13, %rbp
   66fe4:      	addq	%r12, %rbp
   66fe7:      	cmpq	$0xa, %r14
   66feb:      	jbe	0x67016 <f.2+0xfe56>
   66fed:      	movl	$0x1, %eax
   66ff2:      	cmpq	$0xb, %r14
   66ff6:      	je	0x67027 <f.2+0xfe67>
   66ff8:      	cmpq	$0xc, %r14
   66ffc:      	jbe	0x67023 <f.2+0xfe63>
   66ffe:      	cmpq	$0xd, %r14
   67002:      	movq	%rcx, 0x10(%rsp)
   67007:      	jne	0x67033 <f.2+0xfe73>
   67009:      	movl	$0x1, %r12d
   6700f:      	xorl	%eax, %eax
   67011:      	jmp	0x6716d <f.2+0xffad>
   67016:      	leaq	-0x9(%r14), %r12
   6701a:      	leaq	-0x9(%r14), %r13
   6701e:      	jmp	0x687e5 <f.2+0x11625>
   67023:      	leaq	-0xb(%r14), %rax
   67027:      	addq	%r14, %rax
   6702a:      	addq	$-0xb, %rax
   6702e:      	jmp	0x6759d <f.2+0x103dd>
   67033:      	leaq	-0xd(%r14), %rsi
   67037:      	movq	$0x0, 0x50(%rsp)
   67040:      	movq	$0x3, 0x38(%rsp)
   67049:      	xorl	%edi, %edi
   6704b:      	callq	0x6e9d0 <f.3>
   67050:      	subq	$0x8, %rsp
   67054:      	cmpb	$0x0, 0xc855(%rip)      # 0x738b0 <g.4>
   6705b:      	je	0x6e9c5 <f.2+0x17805>
   67061:      	cmpq	$0x0, 0xc83f(%rip)      # 0x738a8 <g.3>
   67069:      	je	0x6e9c5 <f.2+0x17805>
   6706f:      	movq	%rax, %r13
   67072:      	leaq	-0xe(%r14), %rsi
   67076:      	movq	$0x0, 0x50(%rsp)
   6707f:      	movq	$0x3, 0x38(%rsp)
   67088:      	xorl	%edi, %edi
   6708a:      	callq	0x6e9d0 <f.3>
   6708f:      	subq	$0x8, %rsp
   67093:      	cmpb	$0x0, 0xc816(%rip)      # 0x738b0 <g.4>
   6709a:      	je	0x6e9c5 <f.2+0x17805>
   670a0:      	cmpq	$0x0, 0xc800(%rip)      # 0x738a8 <g.3>
   670a8:      	je	0x6e9c5 <f.2+0x17805>
   670ae:      	movq	%rax, %r12
   670b1:      	addq	%r13, %r12
   670b4:      	cmpq	$0xe, %r14
   670b8:      	ja	0x670d9 <f.2+0xff19>
   670ba:      	leaq	0x28(%rsp), %r8
   670bf:      	leaq	0x20(%rsp), %rdi
   670c4:      	leaq	0xc6fd(%rip), %r9       # 0x737c8 <native_roots.0>
   670cb:      	movq	0x10(%rsp), %rcx
   670d0:      	leaq	-0xd(%r14), %rax
   670d4:      	jmp	0x6716d <f.2+0xffad>
   670d9:      	movq	$0x0, 0x50(%rsp)
   670e2:      	movq	$0x3, 0x38(%rsp)
   670eb:      	xorl	%edi, %edi
   670ed:      	leaq	-0xe(%r14), %rsi
   670f1:      	callq	0x6e9d0 <f.3>
   670f6:      	subq	$0x8, %rsp
   670fa:      	cmpb	$0x0, 0xc7af(%rip)      # 0x738b0 <g.4>
   67101:      	je	0x6e9c5 <f.2+0x17805>
   67107:      	cmpq	$0x0, 0xc799(%rip)      # 0x738a8 <g.3>
   6710f:      	je	0x6e9c5 <f.2+0x17805>
   67115:      	movq	%rax, %r13
   67118:      	leaq	-0xf(%r14), %rsi
   6711c:      	movq	$0x0, 0x50(%rsp)
   67125:      	movq	$0x3, 0x38(%rsp)
   6712e:      	xorl	%edi, %edi
   67130:      	callq	0x6e9d0 <f.3>
   67135:      	subq	$0x8, %rsp
   67139:      	cmpb	$0x0, 0xc770(%rip)      # 0x738b0 <g.4>
   67140:      	je	0x6e9c5 <f.2+0x17805>
   67146:      	cmpq	$0x0, 0xc75a(%rip)      # 0x738a8 <g.3>
   6714e:      	leaq	0x28(%rsp), %r8
   67153:      	leaq	0x20(%rsp), %rdi
   67158:      	leaq	0xc669(%rip), %r9       # 0x737c8 <native_roots.0>
   6715f:      	movq	0x10(%rsp), %rcx
   67164:      	je	0x6e9c5 <f.2+0x17805>
   6716a:      	addq	%r13, %rax
   6716d:      	addq	%r12, %rax
   67170:      	cmpq	$0xd, %r14
   67174:      	je	0x67189 <f.2+0xffc9>
   67176:      	cmpq	$0xe, %r14
   6717a:      	jne	0x671a0 <f.2+0xffe0>
   6717c:      	movl	$0x1, %r12d
   67182:      	xorl	%edx, %edx
   67184:      	jmp	0x672c9 <f.2+0x10109>
   67189:      	leaq	(%r14,%rax), %rdx
   6718d:      	addq	$-0xc, %rdx
   67191:      	movl	$0x1, %r13d
   67197:      	leaq	-0xd(%r14), %rax
   6719b:      	jmp	0x6757c <f.2+0x103bc>
   671a0:      	movq	%rax, 0x18(%rsp)
   671a5:      	leaq	-0xe(%r14), %rsi
   671a9:      	movq	$0x0, 0x50(%rsp)
   671b2:      	movq	$0x3, 0x38(%rsp)
   671bb:      	xorl	%edi, %edi
   671bd:      	callq	0x6e9d0 <f.3>
   671c2:      	subq	$0x8, %rsp
   671c6:      	cmpb	$0x0, 0xc6e3(%rip)      # 0x738b0 <g.4>
   671cd:      	je	0x6e9c5 <f.2+0x17805>
   671d3:      	cmpq	$0x0, 0xc6cd(%rip)      # 0x738a8 <g.3>
   671db:      	je	0x6e9c5 <f.2+0x17805>
   671e1:      	movq	%rax, %r13
   671e4:      	leaq	-0xf(%r14), %rsi
   671e8:      	movq	$0x0, 0x50(%rsp)
   671f1:      	movq	$0x3, 0x38(%rsp)
   671fa:      	xorl	%edi, %edi
   671fc:      	callq	0x6e9d0 <f.3>
   67201:      	subq	$0x8, %rsp
   67205:      	cmpb	$0x0, 0xc6a4(%rip)      # 0x738b0 <g.4>
   6720c:      	je	0x6e9c5 <f.2+0x17805>
   67212:      	cmpq	$0x0, 0xc68e(%rip)      # 0x738a8 <g.3>
   6721a:      	leaq	0x28(%rsp), %r8
   6721f:      	leaq	0xc5a2(%rip), %r9       # 0x737c8 <native_roots.0>
   67226:      	movq	0x10(%rsp), %rcx
   6722b:      	leaq	-0xe(%r14), %rdx
   6722f:      	je	0x6e9c5 <f.2+0x17805>
   67235:      	movq	%rax, %r12
   67238:      	addq	%r13, %r12
   6723b:      	cmpq	$0x10, %r14
   6723f:      	jae	0x67248 <f.2+0x10088>
   67241:      	leaq	0x20(%rsp), %rdi
   67246:      	jmp	0x672c4 <f.2+0x10104>
   67248:      	movq	$0x0, 0x50(%rsp)
   67251:      	movq	$0x3, 0x38(%rsp)
   6725a:      	xorl	%edi, %edi
   6725c:      	leaq	-0xf(%r14), %rsi
   67260:      	callq	0x6e9d0 <f.3>
   67265:      	subq	$0x8, %rsp
   67269:      	cmpb	$0x0, 0xc640(%rip)      # 0x738b0 <g.4>
   67270:      	je	0x6e9c5 <f.2+0x17805>
   67276:      	cmpq	$0x0, 0xc62a(%rip)      # 0x738a8 <g.3>
   6727e:      	je	0x6e9c5 <f.2+0x17805>
   67284:      	movq	%rax, %r13
   67287:      	leaq	-0x10(%r14), %rsi
   6728b:      	movq	$0x0, 0x50(%rsp)
   67294:      	movq	$0x3, 0x38(%rsp)
   6729d:      	xorl	%edi, %edi
   6729f:      	callq	0x6e9d0 <f.3>
   672a4:      	subq	$0x8, %rsp
   672a8:      	movq	%rax, %rdx
   672ab:      	addq	%r13, %rdx
   672ae:      	leaq	0x28(%rsp), %r8
   672b3:      	leaq	0x20(%rsp), %rdi
   672b8:      	leaq	0xc509(%rip), %r9       # 0x737c8 <native_roots.0>
   672bf:      	movq	0x10(%rsp), %rcx
   672c4:      	movq	0x18(%rsp), %rax
   672c9:      	cmpb	$0x0, 0xc5e0(%rip)      # 0x738b0 <g.4>
   672d0:      	je	0x6e9c5 <f.2+0x17805>
   672d6:      	cmpq	$0x0, 0xc5ca(%rip)      # 0x738a8 <g.3>
   672de:      	je	0x6e9c5 <f.2+0x17805>
   672e4:      	addq	%r12, %rdx
   672e7:      	addq	%rax, %rdx
   672ea:      	movq	%r14, %r13
   672ed:      	subq	$0xe, %r13
   672f1:      	jbe	0x673a9 <f.2+0x101e9>
   672f7:      	movq	%rdx, 0x58(%rsp)
   672fc:      	movq	$0x0, 0x50(%rsp)
   67305:      	movq	$0x3, 0x38(%rsp)
   6730e:      	xorl	%edi, %edi
   67310:      	movq	%r13, %rsi
   67313:      	callq	0x6e9d0 <f.3>
   67318:      	subq	$0x8, %rsp
   6731c:      	cmpb	$0x0, 0xc58d(%rip)      # 0x738b0 <g.4>
   67323:      	je	0x6e9c5 <f.2+0x17805>
   67329:      	cmpq	$0x0, 0xc577(%rip)      # 0x738a8 <g.3>
   67331:      	je	0x6e9c5 <f.2+0x17805>
   67337:      	movq	%rax, %r12
   6733a:      	leaq	-0xf(%r14), %rsi
   6733e:      	movq	$0x0, 0x50(%rsp)
   67347:      	movq	$0x3, 0x38(%rsp)
   67350:      	xorl	%edi, %edi
   67352:      	callq	0x6e9d0 <f.3>
   67357:      	subq	$0x8, %rsp
   6735b:      	cmpb	$0x0, 0xc54e(%rip)      # 0x738b0 <g.4>
   67362:      	je	0x6e9c5 <f.2+0x17805>
   67368:      	cmpq	$0x0, 0xc538(%rip)      # 0x738a8 <g.3>
   67370:      	movq	0x10(%rsp), %rcx
   67375:      	movq	0x58(%rsp), %rdx
   6737a:      	je	0x6e9c5 <f.2+0x17805>
   67380:      	addq	%r12, %rax
   67383:      	cmpq	$0xf, %r14
   67387:      	jne	0x673b5 <f.2+0x101f5>
   67389:      	addq	%rax, %r13
   6738c:      	movl	$0x1, %eax
   67391:      	xorl	%esi, %esi
   67393:      	leaq	0x28(%rsp), %r8
   67398:      	leaq	0x20(%rsp), %rdi
   6739d:      	leaq	0xc424(%rip), %r9       # 0x737c8 <native_roots.0>
   673a4:      	jmp	0x67579 <f.2+0x103b9>
   673a9:      	incq	%r13
   673ac:      	leaq	-0xd(%r14), %rax
   673b0:      	jmp	0x6757c <f.2+0x103bc>
   673b5:      	movq	%rax, 0x18(%rsp)
   673ba:      	movq	$0x0, 0x50(%rsp)
   673c3:      	movq	$0x3, 0x38(%rsp)
   673cc:      	xorl	%edi, %edi
   673ce:      	leaq	-0xf(%r14), %r12
   673d2:      	movq	%r12, %rsi
   673d5:      	callq	0x6e9d0 <f.3>
   673da:      	subq	$0x8, %rsp
   673de:      	cmpb	$0x0, 0xc4cb(%rip)      # 0x738b0 <g.4>
   673e5:      	je	0x6e9c5 <f.2+0x17805>
   673eb:      	movq	%rax, 0x60(%rsp)
   673f0:      	cmpq	$0x0, 0xc4b0(%rip)      # 0x738a8 <g.3>
   673f8:      	je	0x6e9c5 <f.2+0x17805>
   673fe:      	leaq	-0x10(%r14), %rsi
   67402:      	movq	$0x0, 0x50(%rsp)
   6740b:      	movq	$0x3, 0x38(%rsp)
   67414:      	xorl	%edi, %edi
   67416:      	callq	0x6e9d0 <f.3>
   6741b:      	subq	$0x8, %rsp
   6741f:      	cmpb	$0x0, 0xc48a(%rip)      # 0x738b0 <g.4>
   67426:      	je	0x6e9c5 <f.2+0x17805>
   6742c:      	cmpq	$0x0, 0xc474(%rip)      # 0x738a8 <g.3>
   67434:      	je	0x6e9c5 <f.2+0x17805>
   6743a:      	movq	%rax, %r13
   6743d:      	movq	$0x0, 0x50(%rsp)
   67446:      	movq	$0x3, 0x38(%rsp)
   6744f:      	xorl	%edi, %edi
   67451:      	movq	%r12, %rsi
   67454:      	callq	0x6e9d0 <f.3>
   67459:      	subq	$0x8, %rsp
   6745d:      	cmpb	$0x0, 0xc44c(%rip)      # 0x738b0 <g.4>
   67464:      	je	0x6e9c5 <f.2+0x17805>
   6746a:      	cmpq	$0x0, 0xc436(%rip)      # 0x738a8 <g.3>
   67472:      	je	0x6e9c5 <f.2+0x17805>
   67478:      	movq	%rax, %r12
   6747b:      	movq	$0x0, 0x50(%rsp)
   67484:      	movq	$0x3, 0x38(%rsp)
   6748d:      	xorl	%edi, %edi
   6748f:      	leaq	-0x10(%r14), %rsi
   67493:      	callq	0x6e9d0 <f.3>
   67498:      	subq	$0x8, %rsp
   6749c:      	cmpb	$0x0, 0xc40d(%rip)      # 0x738b0 <g.4>
   674a3:      	je	0x6e9c5 <f.2+0x17805>
   674a9:      	cmpq	$0x0, 0xc3f7(%rip)      # 0x738a8 <g.3>
   674b1:      	movq	0x10(%rsp), %rcx
   674b6:      	movq	0x58(%rsp), %rdx
   674bb:      	je	0x6e9c5 <f.2+0x17805>
   674c1:      	addq	0x60(%rsp), %r13
   674c6:      	addq	0x18(%rsp), %r13
   674cb:      	addq	%r12, %rax
   674ce:      	cmpq	$0x11, %r14
   674d2:      	jae	0x674ee <f.2+0x1032e>
   674d4:      	leaq	0x28(%rsp), %r8
   674d9:      	leaq	0x20(%rsp), %rdi
   674de:      	leaq	0xc2e3(%rip), %r9       # 0x737c8 <native_roots.0>
   674e5:      	leaq	-0xf(%r14), %rsi
   674e9:      	jmp	0x67579 <f.2+0x103b9>
   674ee:      	movq	%rax, 0x18(%rsp)
   674f3:      	movq	$0x0, 0x50(%rsp)
   674fc:      	movq	$0x3, 0x38(%rsp)
   67505:      	xorl	%edi, %edi
   67507:      	leaq	-0x10(%r14), %rsi
   6750b:      	callq	0x6e9d0 <f.3>
   67510:      	subq	$0x8, %rsp
   67514:      	cmpb	$0x0, 0xc395(%rip)      # 0x738b0 <g.4>
   6751b:      	je	0x6e9c5 <f.2+0x17805>
   67521:      	cmpq	$0x0, 0xc37f(%rip)      # 0x738a8 <g.3>
   67529:      	je	0x6e9c5 <f.2+0x17805>
   6752f:      	movq	%rax, %r12
   67532:      	leaq	-0x11(%r14), %rsi
   67536:      	movq	$0x0, 0x50(%rsp)
   6753f:      	movq	$0x3, 0x38(%rsp)
   67548:      	xorl	%edi, %edi
   6754a:      	callq	0x6e9d0 <f.3>
   6754f:      	subq	$0x8, %rsp
   67553:      	addq	%r12, %rax
   67556:      	movq	%rax, %rsi
   67559:      	leaq	0x28(%rsp), %r8
   6755e:      	leaq	0x20(%rsp), %rdi
   67563:      	leaq	0xc25e(%rip), %r9       # 0x737c8 <native_roots.0>
   6756a:      	movq	0x10(%rsp), %rcx
   6756f:      	movq	0x18(%rsp), %rax
   67574:      	movq	0x58(%rsp), %rdx
   67579:      	addq	%rsi, %rax
   6757c:      	cmpb	$0x0, 0xc32d(%rip)      # 0x738b0 <g.4>
   67583:      	je	0x6e9c5 <f.2+0x17805>
   67589:      	cmpq	$0x0, 0xc317(%rip)      # 0x738a8 <g.3>
   67591:      	je	0x6e9c5 <f.2+0x17805>
   67597:      	addq	%r13, %rax
   6759a:      	addq	%rdx, %rax
   6759d:      	cmpq	$0xb, %r14
   675a1:      	je	0x675cc <f.2+0x1040c>
   675a3:      	movl	$0x1, %r13d
   675a9:      	cmpq	$0xc, %r14
   675ad:      	je	0x675e7 <f.2+0x10427>
   675af:      	cmpq	$0xd, %r14
   675b3:      	jbe	0x675e3 <f.2+0x10423>
   675b5:      	cmpq	$0xe, %r14
   675b9:      	movq	%rax, 0x18(%rsp)
   675be:      	movq	%rcx, 0x10(%rsp)
   675c3:      	jne	0x675f0 <f.2+0x10430>
   675c5:      	xorl	%edx, %edx
   675c7:      	jmp	0x67737 <f.2+0x10577>
   675cc:      	leaq	(%r14,%rax), %r12
   675d0:      	addq	$-0xa, %r12
   675d4:      	movl	$0x1, %r13d
   675da:      	leaq	-0xb(%r14), %rax
   675de:      	jmp	0x687e2 <f.2+0x11622>
   675e3:      	leaq	-0xc(%r14), %r13
   675e7:      	leaq	-0xc(%r14), %r12
   675eb:      	jmp	0x67b6f <f.2+0x109af>
   675f0:      	leaq	-0xe(%r14), %rsi
   675f4:      	movq	$0x0, 0x50(%rsp)
   675fd:      	movq	$0x3, 0x38(%rsp)
   67606:      	xorl	%edi, %edi
   67608:      	callq	0x6e9d0 <f.3>
   6760d:      	subq	$0x8, %rsp
   67611:      	cmpb	$0x0, 0xc298(%rip)      # 0x738b0 <g.4>
   67618:      	je	0x6e9c5 <f.2+0x17805>
   6761e:      	cmpq	$0x0, 0xc282(%rip)      # 0x738a8 <g.3>
   67626:      	je	0x6e9c5 <f.2+0x17805>
   6762c:      	movq	%rax, %r12
   6762f:      	leaq	-0xf(%r14), %rsi
   67633:      	movq	$0x0, 0x50(%rsp)
   6763c:      	movq	$0x3, 0x38(%rsp)
   67645:      	xorl	%edi, %edi
   67647:      	callq	0x6e9d0 <f.3>
   6764c:      	subq	$0x8, %rsp
   67650:      	cmpb	$0x0, 0xc259(%rip)      # 0x738b0 <g.4>
   67657:      	je	0x6e9c5 <f.2+0x17805>
   6765d:      	movq	%rax, %r13
   67660:      	cmpq	$0x0, 0xc240(%rip)      # 0x738a8 <g.3>
   67668:      	leaq	0x28(%rsp), %r8
   6766d:      	leaq	0xc154(%rip), %r9       # 0x737c8 <native_roots.0>
   67674:      	movq	0x10(%rsp), %rcx
   67679:      	movq	0x18(%rsp), %rax
   6767e:      	je	0x6e9c5 <f.2+0x17805>
   67684:      	addq	%r12, %r13
   67687:      	cmpq	$0xf, %r14
   6768b:      	ja	0x6769b <f.2+0x104db>
   6768d:      	leaq	0x20(%rsp), %rdi
   67692:      	leaq	-0xe(%r14), %rdx
   67696:      	jmp	0x67737 <f.2+0x10577>
   6769b:      	movq	$0x0, 0x50(%rsp)
   676a4:      	movq	$0x3, 0x38(%rsp)
   676ad:      	xorl	%edi, %edi
   676af:      	leaq	-0xf(%r14), %rsi
   676b3:      	callq	0x6e9d0 <f.3>
   676b8:      	subq	$0x8, %rsp
   676bc:      	cmpb	$0x0, 0xc1ed(%rip)      # 0x738b0 <g.4>
   676c3:      	je	0x6e9c5 <f.2+0x17805>
   676c9:      	cmpq	$0x0, 0xc1d7(%rip)      # 0x738a8 <g.3>
   676d1:      	je	0x6e9c5 <f.2+0x17805>
   676d7:      	movq	%rax, %r12
   676da:      	leaq	-0x10(%r14), %rsi
   676de:      	movq	$0x0, 0x50(%rsp)
   676e7:      	movq	$0x3, 0x38(%rsp)
   676f0:      	xorl	%edi, %edi
   676f2:      	callq	0x6e9d0 <f.3>
   676f7:      	subq	$0x8, %rsp
   676fb:      	cmpb	$0x0, 0xc1ae(%rip)      # 0x738b0 <g.4>
   67702:      	je	0x6e9c5 <f.2+0x17805>
   67708:      	movq	%rax, %rdx
   6770b:      	cmpq	$0x0, 0xc195(%rip)      # 0x738a8 <g.3>
   67713:      	leaq	0x28(%rsp), %r8
   67718:      	leaq	0x20(%rsp), %rdi
   6771d:      	leaq	0xc0a4(%rip), %r9       # 0x737c8 <native_roots.0>
   67724:      	movq	0x10(%rsp), %rcx
   67729:      	movq	0x18(%rsp), %rax
   6772e:      	je	0x6e9c5 <f.2+0x17805>
   67734:      	addq	%r12, %rdx
   67737:      	addq	%r13, %rdx
   6773a:      	cmpq	$0xe, %r14
   6773e:      	je	0x67753 <f.2+0x10593>
   67740:      	cmpq	$0xf, %r14
   67744:      	jne	0x6776a <f.2+0x105aa>
   67746:      	movl	$0x1, %esi
   6774b:      	xorl	%r13d, %r13d
   6774e:      	jmp	0x678ae <f.2+0x106ee>
   67753:      	leaq	(%r14,%rdx), %r13
   67757:      	addq	$-0xd, %r13
   6775b:      	movl	$0x1, %r12d
   67761:      	leaq	-0xe(%r14), %rsi
   67765:      	jmp	0x67b6c <f.2+0x109ac>
   6776a:      	movq	%rdx, 0x58(%rsp)
   6776f:      	leaq	-0xf(%r14), %r13
   67773:      	movq	$0x0, 0x50(%rsp)
   6777c:      	movq	$0x3, 0x38(%rsp)
   67785:      	xorl	%edi, %edi
   67787:      	movq	%r13, %rsi
   6778a:      	callq	0x6e9d0 <f.3>
   6778f:      	subq	$0x8, %rsp
   67793:      	cmpb	$0x0, 0xc116(%rip)      # 0x738b0 <g.4>
   6779a:      	je	0x6e9c5 <f.2+0x17805>
   677a0:      	cmpq	$0x0, 0xc100(%rip)      # 0x738a8 <g.3>
   677a8:      	je	0x6e9c5 <f.2+0x17805>
   677ae:      	movq	%rax, %r12
   677b1:      	leaq	-0x10(%r14), %rsi
   677b5:      	movq	$0x0, 0x50(%rsp)
   677be:      	movq	$0x3, 0x38(%rsp)
   677c7:      	xorl	%edi, %edi
   677c9:      	callq	0x6e9d0 <f.3>
   677ce:      	subq	$0x8, %rsp
   677d2:      	cmpb	$0x0, 0xc0d7(%rip)      # 0x738b0 <g.4>
   677d9:      	je	0x6e9c5 <f.2+0x17805>
   677df:      	movq	%rax, %rsi
   677e2:      	cmpq	$0x0, 0xc0be(%rip)      # 0x738a8 <g.3>
   677ea:      	leaq	0x20(%rsp), %rdi
   677ef:      	movq	0x10(%rsp), %rcx
   677f4:      	movq	0x18(%rsp), %rax
   677f9:      	je	0x6e9c5 <f.2+0x17805>
   677ff:      	addq	%r12, %rsi
   67802:      	cmpq	$0x11, %r14
   67806:      	jae	0x6781e <f.2+0x1065e>
   67808:      	leaq	0x28(%rsp), %r8
   6780d:      	leaq	0xbfb4(%rip), %r9       # 0x737c8 <native_roots.0>
   67814:      	movq	0x58(%rsp), %rdx
   67819:      	jmp	0x678ae <f.2+0x106ee>
   6781e:      	movq	%rsi, 0x60(%rsp)
   67823:      	movq	$0x0, 0x50(%rsp)
   6782c:      	movq	$0x3, 0x38(%rsp)
   67835:      	xorl	%edi, %edi
   67837:      	leaq	-0x10(%r14), %rsi
   6783b:      	callq	0x6e9d0 <f.3>
   67840:      	subq	$0x8, %rsp
   67844:      	cmpb	$0x0, 0xc065(%rip)      # 0x738b0 <g.4>
   6784b:      	je	0x6e9c5 <f.2+0x17805>
   67851:      	cmpq	$0x0, 0xc04f(%rip)      # 0x738a8 <g.3>
   67859:      	je	0x6e9c5 <f.2+0x17805>
   6785f:      	movq	%rax, %r12
   67862:      	leaq	-0x11(%r14), %rsi
   67866:      	movq	$0x0, 0x50(%rsp)
   6786f:      	movq	$0x3, 0x38(%rsp)
   67878:      	xorl	%edi, %edi
   6787a:      	callq	0x6e9d0 <f.3>
   6787f:      	subq	$0x8, %rsp
   67883:      	movq	%rax, %r13
   67886:      	addq	%r12, %r13
   67889:      	leaq	0x28(%rsp), %r8
   6788e:      	leaq	0x20(%rsp), %rdi
   67893:      	leaq	0xbf2e(%rip), %r9       # 0x737c8 <native_roots.0>
   6789a:      	movq	0x10(%rsp), %rcx
   6789f:      	movq	0x18(%rsp), %rax
   678a4:      	movq	0x58(%rsp), %rdx
   678a9:      	movq	0x60(%rsp), %rsi
   678ae:      	cmpb	$0x0, 0xbffb(%rip)      # 0x738b0 <g.4>
   678b5:      	je	0x6e9c5 <f.2+0x17805>
   678bb:      	cmpq	$0x0, 0xbfe5(%rip)      # 0x738a8 <g.3>
   678c3:      	je	0x6e9c5 <f.2+0x17805>
   678c9:      	addq	%rsi, %r13
   678cc:      	addq	%rdx, %r13
   678cf:      	movq	%r14, %r12
   678d2:      	subq	$0xf, %r12
   678d6:      	jbe	0x67994 <f.2+0x107d4>
   678dc:      	movq	$0x0, 0x50(%rsp)
   678e5:      	movq	$0x3, 0x38(%rsp)
   678ee:      	xorl	%edi, %edi
   678f0:      	movq	%r12, %rsi
   678f3:      	callq	0x6e9d0 <f.3>
   678f8:      	subq	$0x8, %rsp
   678fc:      	cmpb	$0x0, 0xbfad(%rip)      # 0x738b0 <g.4>
   67903:      	je	0x6e9c5 <f.2+0x17805>
   67909:      	movq	%rax, 0x58(%rsp)
   6790e:      	cmpq	$0x0, 0xbf92(%rip)      # 0x738a8 <g.3>
   67916:      	je	0x6e9c5 <f.2+0x17805>
   6791c:      	leaq	-0x10(%r14), %rsi
   67920:      	movq	$0x0, 0x50(%rsp)
   67929:      	movq	$0x3, 0x38(%rsp)
   67932:      	xorl	%edi, %edi
   67934:      	callq	0x6e9d0 <f.3>
   67939:      	subq	$0x8, %rsp
   6793d:      	cmpb	$0x0, 0xbf6c(%rip)      # 0x738b0 <g.4>
   67944:      	je	0x6e9c5 <f.2+0x17805>
   6794a:      	movq	%rax, %rdx
   6794d:      	cmpq	$0x0, 0xbf53(%rip)      # 0x738a8 <g.3>
   67955:      	leaq	0x20(%rsp), %rdi
   6795a:      	movq	0x10(%rsp), %rcx
   6795f:      	movq	0x18(%rsp), %rax
   67964:      	je	0x6e9c5 <f.2+0x17805>
   6796a:      	addq	0x58(%rsp), %rdx
   6796f:      	cmpq	$0x10, %r14
   67973:      	leaq	-0x10(%r14), %rsi
   67977:      	jne	0x679a0 <f.2+0x107e0>
   67979:      	addq	%rdx, %r12
   6797c:      	movl	$0x1, %esi
   67981:      	xorl	%edx, %edx
   67983:      	leaq	0x28(%rsp), %r8
   67988:      	leaq	0xbe39(%rip), %r9       # 0x737c8 <native_roots.0>
   6798f:      	jmp	0x67b69 <f.2+0x109a9>
   67994:      	incq	%r12
   67997:      	leaq	-0xe(%r14), %rsi
   6799b:      	jmp	0x67b6c <f.2+0x109ac>
   679a0:      	movq	%rdx, 0x58(%rsp)
   679a5:      	movq	$0x0, 0x50(%rsp)
   679ae:      	movq	$0x3, 0x38(%rsp)
   679b7:      	xorl	%edi, %edi
   679b9:      	callq	0x6e9d0 <f.3>
   679be:      	subq	$0x8, %rsp
   679c2:      	cmpb	$0x0, 0xbee7(%rip)      # 0x738b0 <g.4>
   679c9:      	je	0x6e9c5 <f.2+0x17805>
   679cf:      	movq	%rax, 0x60(%rsp)
   679d4:      	cmpq	$0x0, 0xbecc(%rip)      # 0x738a8 <g.3>
   679dc:      	je	0x6e9c5 <f.2+0x17805>
   679e2:      	leaq	-0x11(%r14), %rsi
   679e6:      	movq	$0x0, 0x50(%rsp)
   679ef:      	movq	$0x3, 0x38(%rsp)
   679f8:      	xorl	%edi, %edi
   679fa:      	callq	0x6e9d0 <f.3>
   679ff:      	subq	$0x8, %rsp
   67a03:      	cmpb	$0x0, 0xbea6(%rip)      # 0x738b0 <g.4>
   67a0a:      	je	0x6e9c5 <f.2+0x17805>
   67a10:      	cmpq	$0x0, 0xbe90(%rip)      # 0x738a8 <g.3>
   67a18:      	leaq	-0x10(%r14), %rsi
   67a1c:      	je	0x6e9c5 <f.2+0x17805>
   67a22:      	movq	%rax, %r12
   67a25:      	movq	$0x0, 0x50(%rsp)
   67a2e:      	movq	$0x3, 0x38(%rsp)
   67a37:      	xorl	%edi, %edi
   67a39:      	callq	0x6e9d0 <f.3>
   67a3e:      	subq	$0x8, %rsp
   67a42:      	cmpb	$0x0, 0xbe67(%rip)      # 0x738b0 <g.4>
   67a49:      	je	0x6e9c5 <f.2+0x17805>
   67a4f:      	movq	%rax, 0x68(%rsp)
   67a54:      	cmpq	$0x0, 0xbe4c(%rip)      # 0x738a8 <g.3>
   67a5c:      	je	0x6e9c5 <f.2+0x17805>
   67a62:      	movq	$0x0, 0x50(%rsp)
   67a6b:      	movq	$0x3, 0x38(%rsp)
   67a74:      	xorl	%edi, %edi
   67a76:      	leaq	-0x11(%r14), %rsi
   67a7a:      	callq	0x6e9d0 <f.3>
   67a7f:      	subq	$0x8, %rsp
   67a83:      	cmpb	$0x0, 0xbe26(%rip)      # 0x738b0 <g.4>
   67a8a:      	je	0x6e9c5 <f.2+0x17805>
   67a90:      	movq	%rax, %rsi
   67a93:      	cmpq	$0x0, 0xbe0d(%rip)      # 0x738a8 <g.3>
   67a9b:      	movq	0x10(%rsp), %rcx
   67aa0:      	movq	0x18(%rsp), %rax
   67aa5:      	leaq	-0x10(%r14), %rdx
   67aa9:      	je	0x6e9c5 <f.2+0x17805>
   67aaf:      	addq	0x60(%rsp), %r12
   67ab4:      	addq	0x58(%rsp), %r12
   67ab9:      	addq	0x68(%rsp), %rsi
   67abe:      	cmpq	$0x12, %r14
   67ac2:      	jae	0x67ada <f.2+0x1091a>
   67ac4:      	leaq	0x28(%rsp), %r8
   67ac9:      	leaq	0x20(%rsp), %rdi
   67ace:      	leaq	0xbcf3(%rip), %r9       # 0x737c8 <native_roots.0>
   67ad5:      	jmp	0x67b69 <f.2+0x109a9>
   67ada:      	movq	%rsi, 0x58(%rsp)
   67adf:      	movq	$0x0, 0x50(%rsp)
   67ae8:      	movq	$0x3, 0x38(%rsp)
   67af1:      	xorl	%edi, %edi
   67af3:      	leaq	-0x11(%r14), %rsi
   67af7:      	callq	0x6e9d0 <f.3>
   67afc:      	subq	$0x8, %rsp
   67b00:      	cmpb	$0x0, 0xbda9(%rip)      # 0x738b0 <g.4>
   67b07:      	je	0x6e9c5 <f.2+0x17805>
   67b0d:      	movq	%rax, 0x60(%rsp)
   67b12:      	cmpq	$0x0, 0xbd8e(%rip)      # 0x738a8 <g.3>
   67b1a:      	je	0x6e9c5 <f.2+0x17805>
   67b20:      	leaq	-0x12(%r14), %rsi
   67b24:      	movq	$0x0, 0x50(%rsp)
   67b2d:      	movq	$0x3, 0x38(%rsp)
   67b36:      	xorl	%edi, %edi
   67b38:      	callq	0x6e9d0 <f.3>
   67b3d:      	subq	$0x8, %rsp
   67b41:      	movq	%rax, %rdx
   67b44:      	addq	0x60(%rsp), %rdx
   67b49:      	leaq	0x28(%rsp), %r8
   67b4e:      	leaq	0x20(%rsp), %rdi
   67b53:      	leaq	0xbc6e(%rip), %r9       # 0x737c8 <native_roots.0>
   67b5a:      	movq	0x10(%rsp), %rcx
   67b5f:      	movq	0x18(%rsp), %rax
   67b64:      	movq	0x58(%rsp), %rsi
   67b69:      	addq	%rdx, %rsi
   67b6c:      	addq	%rsi, %r12
   67b6f:      	cmpb	$0x0, 0xbd3a(%rip)      # 0x738b0 <g.4>
   67b76:      	je	0x6e9c5 <f.2+0x17805>
   67b7c:      	cmpq	$0x0, 0xbd24(%rip)      # 0x738a8 <g.3>
   67b84:      	je	0x6e9c5 <f.2+0x17805>
   67b8a:      	addq	%r13, %r12
   67b8d:      	addq	%rax, %r12
   67b90:      	cmpq	$0xc, %r14
   67b94:      	jbe	0x67c56 <f.2+0x10a96>
   67b9a:      	movl	$0x1, %r13d
   67ba0:      	cmpq	$0xd, %r14
   67ba4:      	je	0x67c66 <f.2+0x10aa6>
   67baa:      	movq	%r14, %r13
   67bad:      	subq	$0xe, %r13
   67bb1:      	jbe	0x67c63 <f.2+0x10aa3>
   67bb7:      	movq	%rcx, 0x10(%rsp)
   67bbc:      	movq	$0x0, 0x50(%rsp)
   67bc5:      	movq	$0x3, 0x38(%rsp)
   67bce:      	xorl	%edi, %edi
   67bd0:      	movq	%r13, %rsi
   67bd3:      	callq	0x6e9d0 <f.3>
   67bd8:      	subq	$0x8, %rsp
   67bdc:      	cmpb	$0x0, 0xbccd(%rip)      # 0x738b0 <g.4>
   67be3:      	je	0x6e9c5 <f.2+0x17805>
   67be9:      	movq	%rax, 0x18(%rsp)
   67bee:      	cmpq	$0x0, 0xbcb2(%rip)      # 0x738a8 <g.3>
   67bf6:      	je	0x6e9c5 <f.2+0x17805>
   67bfc:      	leaq	-0xf(%r14), %rsi
   67c00:      	movq	$0x0, 0x50(%rsp)
   67c09:      	movq	$0x3, 0x38(%rsp)
   67c12:      	xorl	%edi, %edi
   67c14:      	callq	0x6e9d0 <f.3>
   67c19:      	subq	$0x8, %rsp
   67c1d:      	cmpb	$0x0, 0xbc8c(%rip)      # 0x738b0 <g.4>
   67c24:      	je	0x6e9c5 <f.2+0x17805>
   67c2a:      	cmpq	$0x0, 0xbc76(%rip)      # 0x738a8 <g.3>
   67c32:      	je	0x6e9c5 <f.2+0x17805>
   67c38:      	addq	0x18(%rsp), %rax
   67c3d:      	cmpq	$0xf, %r14
   67c41:      	leaq	-0xf(%r14), %rsi
   67c45:      	jne	0x67c73 <f.2+0x10ab3>
   67c47:      	addq	%rax, %r13
   67c4a:      	movl	$0x1, %edx
   67c4f:      	xorl	%eax, %eax
   67c51:      	jmp	0x67d8d <f.2+0x10bcd>
   67c56:      	leaq	-0xb(%r14), %r13
   67c5a:      	leaq	-0xb(%r14), %rax
   67c5e:      	jmp	0x687e2 <f.2+0x11622>
   67c63:      	incq	%r13
   67c66:      	leaq	(%r14,%r13), %rax
   67c6a:      	addq	$-0xd, %rax
   67c6e:      	jmp	0x67e50 <f.2+0x10c90>
   67c73:      	movq	%rax, 0x18(%rsp)
   67c78:      	movq	$0x0, 0x50(%rsp)
   67c81:      	movq	$0x3, 0x38(%rsp)
   67c8a:      	xorl	%edi, %edi
   67c8c:      	callq	0x6e9d0 <f.3>
   67c91:      	subq	$0x8, %rsp
   67c95:      	cmpb	$0x0, 0xbc14(%rip)      # 0x738b0 <g.4>
   67c9c:      	je	0x6e9c5 <f.2+0x17805>
   67ca2:      	movq	%rax, 0x58(%rsp)
   67ca7:      	cmpq	$0x0, 0xbbf9(%rip)      # 0x738a8 <g.3>
   67caf:      	je	0x6e9c5 <f.2+0x17805>
   67cb5:      	leaq	-0x10(%r14), %rsi
   67cb9:      	movq	$0x0, 0x50(%rsp)
   67cc2:      	movq	$0x3, 0x38(%rsp)
   67ccb:      	xorl	%edi, %edi
   67ccd:      	callq	0x6e9d0 <f.3>
   67cd2:      	subq	$0x8, %rsp
   67cd6:      	cmpb	$0x0, 0xbbd3(%rip)      # 0x738b0 <g.4>
   67cdd:      	je	0x6e9c5 <f.2+0x17805>
   67ce3:      	cmpq	$0x0, 0xbbbd(%rip)      # 0x738a8 <g.3>
   67ceb:      	leaq	-0xf(%r14), %rsi
   67cef:      	je	0x6e9c5 <f.2+0x17805>
   67cf5:      	movq	%rax, %r13
   67cf8:      	movq	$0x0, 0x50(%rsp)
   67d01:      	movq	$0x3, 0x38(%rsp)
   67d0a:      	xorl	%edi, %edi
   67d0c:      	callq	0x6e9d0 <f.3>
   67d11:      	subq	$0x8, %rsp
   67d15:      	cmpb	$0x0, 0xbb94(%rip)      # 0x738b0 <g.4>
   67d1c:      	je	0x6e9c5 <f.2+0x17805>
   67d22:      	movq	%rax, 0x60(%rsp)
   67d27:      	cmpq	$0x0, 0xbb79(%rip)      # 0x738a8 <g.3>
   67d2f:      	je	0x6e9c5 <f.2+0x17805>
   67d35:      	movq	$0x0, 0x50(%rsp)
   67d3e:      	movq	$0x3, 0x38(%rsp)
   67d47:      	xorl	%edi, %edi
   67d49:      	leaq	-0x10(%r14), %rsi
   67d4d:      	callq	0x6e9d0 <f.3>
   67d52:      	subq	$0x8, %rsp
   67d56:      	cmpb	$0x0, 0xbb53(%rip)      # 0x738b0 <g.4>
   67d5d:      	je	0x6e9c5 <f.2+0x17805>
   67d63:      	movq	%rax, %rdx
   67d66:      	cmpq	$0x0, 0xbb3a(%rip)      # 0x738a8 <g.3>
   67d6e:      	leaq	-0xf(%r14), %rax
   67d72:      	je	0x6e9c5 <f.2+0x17805>
   67d78:      	addq	0x58(%rsp), %r13
   67d7d:      	addq	0x18(%rsp), %r13
   67d82:      	addq	0x60(%rsp), %rdx
   67d87:      	cmpq	$0x11, %r14
   67d8b:      	jae	0x67da8 <f.2+0x10be8>
   67d8d:      	leaq	0x28(%rsp), %r8
   67d92:      	leaq	0x20(%rsp), %rdi
   67d97:      	leaq	0xba2a(%rip), %r9       # 0x737c8 <native_roots.0>
   67d9e:      	movq	0x10(%rsp), %rcx
   67da3:      	jmp	0x67e2f <f.2+0x10c6f>
   67da8:      	movq	%rdx, 0x18(%rsp)
   67dad:      	movq	$0x0, 0x50(%rsp)
   67db6:      	movq	$0x3, 0x38(%rsp)
   67dbf:      	xorl	%edi, %edi
   67dc1:      	leaq	-0x10(%r14), %rsi
   67dc5:      	callq	0x6e9d0 <f.3>
   67dca:      	subq	$0x8, %rsp
   67dce:      	cmpb	$0x0, 0xbadb(%rip)      # 0x738b0 <g.4>
   67dd5:      	je	0x6e9c5 <f.2+0x17805>
   67ddb:      	movq	%rax, 0x58(%rsp)
   67de0:      	cmpq	$0x0, 0xbac0(%rip)      # 0x738a8 <g.3>
   67de8:      	je	0x6e9c5 <f.2+0x17805>
   67dee:      	leaq	-0x11(%r14), %rsi
   67df2:      	movq	$0x0, 0x50(%rsp)
   67dfb:      	movq	$0x3, 0x38(%rsp)
   67e04:      	xorl	%edi, %edi
   67e06:      	callq	0x6e9d0 <f.3>
   67e0b:      	subq	$0x8, %rsp
   67e0f:      	addq	0x58(%rsp), %rax
   67e14:      	leaq	0x28(%rsp), %r8
   67e19:      	leaq	0x20(%rsp), %rdi
   67e1e:      	leaq	0xb9a3(%rip), %r9       # 0x737c8 <native_roots.0>
   67e25:      	movq	0x10(%rsp), %rcx
   67e2a:      	movq	0x18(%rsp), %rdx
   67e2f:      	cmpb	$0x0, 0xba7a(%rip)      # 0x738b0 <g.4>
   67e36:      	je	0x6e9c5 <f.2+0x17805>
   67e3c:      	cmpq	$0x0, 0xba64(%rip)      # 0x738a8 <g.3>
   67e44:      	je	0x6e9c5 <f.2+0x17805>
   67e4a:      	addq	%rdx, %rax
   67e4d:      	addq	%r13, %rax
   67e50:      	cmpq	$0xd, %r14
   67e54:      	je	0x67f34 <f.2+0x10d74>
   67e5a:      	movl	$0x1, %r10d
   67e60:      	cmpq	$0xe, %r14
   67e64:      	je	0x67f4d <f.2+0x10d8d>
   67e6a:      	movq	%r14, %r10
   67e6d:      	subq	$0xf, %r10
   67e71:      	jbe	0x67f4a <f.2+0x10d8a>
   67e77:      	movq	%rax, 0x58(%rsp)
   67e7c:      	movq	%rcx, 0x10(%rsp)
   67e81:      	movq	$0x0, 0x50(%rsp)
   67e8a:      	movq	$0x3, 0x38(%rsp)
   67e93:      	xorl	%edi, %edi
   67e95:      	movq	%r10, 0x18(%rsp)
   67e9a:      	movq	%r10, %rsi
   67e9d:      	callq	0x6e9d0 <f.3>
   67ea2:      	subq	$0x8, %rsp
   67ea6:      	cmpb	$0x0, 0xba03(%rip)      # 0x738b0 <g.4>
   67ead:      	je	0x6e9c5 <f.2+0x17805>
   67eb3:      	cmpq	$0x0, 0xb9ed(%rip)      # 0x738a8 <g.3>
   67ebb:      	je	0x6e9c5 <f.2+0x17805>
   67ec1:      	movq	%rax, %r13
   67ec4:      	leaq	-0x10(%r14), %rsi
   67ec8:      	movq	$0x0, 0x50(%rsp)
   67ed1:      	movq	$0x3, 0x38(%rsp)
   67eda:      	xorl	%edi, %edi
   67edc:      	callq	0x6e9d0 <f.3>
   67ee1:      	subq	$0x8, %rsp
   67ee5:      	cmpb	$0x0, 0xb9c4(%rip)      # 0x738b0 <g.4>
   67eec:      	je	0x6e9c5 <f.2+0x17805>
   67ef2:      	movq	%rax, %rcx
   67ef5:      	cmpq	$0x0, 0xb9ab(%rip)      # 0x738a8 <g.3>
   67efd:      	movq	0x58(%rsp), %rax
   67f02:      	movq	0x18(%rsp), %r10
   67f07:      	je	0x6e9c5 <f.2+0x17805>
   67f0d:      	addq	%r13, %rcx
   67f10:      	cmpq	$0x10, %r14
   67f14:      	leaq	-0x10(%r14), %rsi
   67f18:      	jne	0x67f56 <f.2+0x10d96>
   67f1a:      	addq	%rcx, %r10
   67f1d:      	movl	$0x1, %r13d
   67f23:      	xorl	%edx, %edx
   67f25:      	leaq	0x28(%rsp), %r8
   67f2a:      	leaq	0x20(%rsp), %rdi
   67f2f:      	jmp	0x68088 <f.2+0x10ec8>
   67f34:      	leaq	(%r14,%rax), %r13
   67f38:      	addq	$-0xc, %r13
   67f3c:      	movl	$0x1, %eax
   67f41:      	leaq	-0xd(%r14), %r10
   67f45:      	jmp	0x687df <f.2+0x1161f>
   67f4a:      	incq	%r10
   67f4d:      	leaq	-0xe(%r14), %r13
   67f51:      	jmp	0x6812b <f.2+0x10f6b>
   67f56:      	movq	%rcx, 0x60(%rsp)
   67f5b:      	movq	$0x0, 0x50(%rsp)
   67f64:      	movq	$0x3, 0x38(%rsp)
   67f6d:      	xorl	%edi, %edi
   67f6f:      	callq	0x6e9d0 <f.3>
   67f74:      	subq	$0x8, %rsp
   67f78:      	cmpb	$0x0, 0xb931(%rip)      # 0x738b0 <g.4>
   67f7f:      	je	0x6e9c5 <f.2+0x17805>
   67f85:      	movq	%rax, 0x68(%rsp)
   67f8a:      	cmpq	$0x0, 0xb916(%rip)      # 0x738a8 <g.3>
   67f92:      	je	0x6e9c5 <f.2+0x17805>
   67f98:      	leaq	-0x11(%r14), %r13
   67f9c:      	movq	$0x0, 0x50(%rsp)
   67fa5:      	movq	$0x3, 0x38(%rsp)
   67fae:      	xorl	%edi, %edi
   67fb0:      	movq	%r13, %rsi
   67fb3:      	callq	0x6e9d0 <f.3>
   67fb8:      	subq	$0x8, %rsp
   67fbc:      	cmpb	$0x0, 0xb8ed(%rip)      # 0x738b0 <g.4>
   67fc3:      	je	0x6e9c5 <f.2+0x17805>
   67fc9:      	movq	%rax, 0x18(%rsp)
   67fce:      	cmpq	$0x0, 0xb8d2(%rip)      # 0x738a8 <g.3>
   67fd6:      	leaq	-0x10(%r14), %rsi
   67fda:      	je	0x6e9c5 <f.2+0x17805>
   67fe0:      	movq	$0x0, 0x50(%rsp)
   67fe9:      	movq	$0x3, 0x38(%rsp)
   67ff2:      	xorl	%edi, %edi
   67ff4:      	callq	0x6e9d0 <f.3>
   67ff9:      	subq	$0x8, %rsp
   67ffd:      	cmpb	$0x0, 0xb8ac(%rip)      # 0x738b0 <g.4>
   68004:      	je	0x6e9c5 <f.2+0x17805>
   6800a:      	movq	%rax, 0x70(%rsp)
   6800f:      	cmpq	$0x0, 0xb891(%rip)      # 0x738a8 <g.3>
   68017:      	je	0x6e9c5 <f.2+0x17805>
   6801d:      	movq	$0x0, 0x50(%rsp)
   68026:      	movq	$0x3, 0x38(%rsp)
   6802f:      	xorl	%edi, %edi
   68031:      	movq	%r13, %rsi
   68034:      	callq	0x6e9d0 <f.3>
   68039:      	subq	$0x8, %rsp
   6803d:      	cmpb	$0x0, 0xb86c(%rip)      # 0x738b0 <g.4>
   68044:      	je	0x6e9c5 <f.2+0x17805>
   6804a:      	movq	%rax, %r13
   6804d:      	cmpq	$0x0, 0xb853(%rip)      # 0x738a8 <g.3>
   68055:      	leaq	0x20(%rsp), %rdi
   6805a:      	movq	0x58(%rsp), %rax
   6805f:      	movq	0x18(%rsp), %r10
   68064:      	leaq	-0x10(%r14), %rdx
   68068:      	je	0x6e9c5 <f.2+0x17805>
   6806e:      	addq	0x68(%rsp), %r10
   68073:      	addq	0x60(%rsp), %r10
   68078:      	addq	0x70(%rsp), %r13
   6807d:      	cmpq	$0x12, %r14
   68081:      	jae	0x68099 <f.2+0x10ed9>
   68083:      	leaq	0x28(%rsp), %r8
   68088:      	leaq	0xb739(%rip), %r9       # 0x737c8 <native_roots.0>
   6808f:      	movq	0x10(%rsp), %rcx
   68094:      	jmp	0x68128 <f.2+0x10f68>
   68099:      	movq	%r10, 0x18(%rsp)
   6809e:      	movq	$0x0, 0x50(%rsp)
   680a7:      	movq	$0x3, 0x38(%rsp)
   680b0:      	xorl	%edi, %edi
   680b2:      	leaq	-0x11(%r14), %rsi
   680b6:      	callq	0x6e9d0 <f.3>
   680bb:      	subq	$0x8, %rsp
   680bf:      	cmpb	$0x0, 0xb7ea(%rip)      # 0x738b0 <g.4>
   680c6:      	je	0x6e9c5 <f.2+0x17805>
   680cc:      	movq	%rax, 0x60(%rsp)
   680d1:      	cmpq	$0x0, 0xb7cf(%rip)      # 0x738a8 <g.3>
   680d9:      	je	0x6e9c5 <f.2+0x17805>
   680df:      	leaq	-0x12(%r14), %rsi
   680e3:      	movq	$0x0, 0x50(%rsp)
   680ec:      	movq	$0x3, 0x38(%rsp)
   680f5:      	xorl	%edi, %edi
   680f7:      	callq	0x6e9d0 <f.3>
   680fc:      	subq	$0x8, %rsp
   68100:      	movq	%rax, %rdx
   68103:      	addq	0x60(%rsp), %rdx
   68108:      	leaq	0x28(%rsp), %r8
   6810d:      	leaq	0x20(%rsp), %rdi
   68112:      	leaq	0xb6af(%rip), %r9       # 0x737c8 <native_roots.0>
   68119:      	movq	0x10(%rsp), %rcx
   6811e:      	movq	0x58(%rsp), %rax
   68123:      	movq	0x18(%rsp), %r10
   68128:      	addq	%rdx, %r13
   6812b:      	cmpb	$0x0, 0xb77e(%rip)      # 0x738b0 <g.4>
   68132:      	je	0x6e9c5 <f.2+0x17805>
   68138:      	cmpq	$0x0, 0xb768(%rip)      # 0x738a8 <g.3>
   68140:      	je	0x6e9c5 <f.2+0x17805>
   68146:      	addq	%r10, %r13
   68149:      	addq	%rax, %r13
   6814c:      	cmpq	$0xe, %r14
   68150:      	jbe	0x68169 <f.2+0x10fa9>
   68152:      	cmpq	$0xf, %r14
   68156:      	movq	%rcx, 0x10(%rsp)
   6815b:      	jne	0x68176 <f.2+0x10fb6>
   6815d:      	movl	$0x1, %eax
   68162:      	xorl	%edx, %edx
   68164:      	jmp	0x682c2 <f.2+0x11102>
   68169:      	leaq	-0xd(%r14), %rax
   6816d:      	leaq	-0xd(%r14), %r10
   68171:      	jmp	0x687df <f.2+0x1161f>
   68176:      	leaq	-0xf(%r14), %rsi
   6817a:      	movq	$0x0, 0x50(%rsp)
   68183:      	movq	$0x3, 0x38(%rsp)
   6818c:      	xorl	%edi, %edi
   6818e:      	callq	0x6e9d0 <f.3>
   68193:      	subq	$0x8, %rsp
   68197:      	cmpb	$0x0, 0xb712(%rip)      # 0x738b0 <g.4>
   6819e:      	je	0x6e9c5 <f.2+0x17805>
   681a4:      	movq	%rax, 0x18(%rsp)
   681a9:      	cmpq	$0x0, 0xb6f7(%rip)      # 0x738a8 <g.3>
   681b1:      	je	0x6e9c5 <f.2+0x17805>
   681b7:      	leaq	-0x10(%r14), %rsi
   681bb:      	movq	$0x0, 0x50(%rsp)
   681c4:      	movq	$0x3, 0x38(%rsp)
   681cd:      	xorl	%edi, %edi
   681cf:      	callq	0x6e9d0 <f.3>
   681d4:      	subq	$0x8, %rsp
   681d8:      	cmpb	$0x0, 0xb6d1(%rip)      # 0x738b0 <g.4>
   681df:      	je	0x6e9c5 <f.2+0x17805>
   681e5:      	cmpq	$0x0, 0xb6bb(%rip)      # 0x738a8 <g.3>
   681ed:      	leaq	0x20(%rsp), %rdi
   681f2:      	leaq	-0xf(%r14), %rdx
   681f6:      	je	0x6e9c5 <f.2+0x17805>
   681fc:      	addq	0x18(%rsp), %rax
   68201:      	cmpq	$0x10, %r14
   68205:      	ja	0x6821d <f.2+0x1105d>
   68207:      	leaq	0x28(%rsp), %r8
   6820c:      	leaq	0xb5b5(%rip), %r9       # 0x737c8 <native_roots.0>
   68213:      	movq	0x10(%rsp), %rcx
   68218:      	jmp	0x682c2 <f.2+0x11102>
   6821d:      	movq	%rax, 0x18(%rsp)
   68222:      	movq	$0x0, 0x50(%rsp)
   6822b:      	movq	$0x3, 0x38(%rsp)
   68234:      	xorl	%edi, %edi
   68236:      	leaq	-0x10(%r14), %rsi
   6823a:      	callq	0x6e9d0 <f.3>
   6823f:      	subq	$0x8, %rsp
   68243:      	cmpb	$0x0, 0xb666(%rip)      # 0x738b0 <g.4>
   6824a:      	je	0x6e9c5 <f.2+0x17805>
   68250:      	movq	%rax, 0x58(%rsp)
   68255:      	cmpq	$0x0, 0xb64b(%rip)      # 0x738a8 <g.3>
   6825d:      	je	0x6e9c5 <f.2+0x17805>
   68263:      	leaq	-0x11(%r14), %rsi
   68267:      	movq	$0x0, 0x50(%rsp)
   68270:      	movq	$0x3, 0x38(%rsp)
   68279:      	xorl	%edi, %edi
   6827b:      	callq	0x6e9d0 <f.3>
   68280:      	subq	$0x8, %rsp
   68284:      	cmpb	$0x0, 0xb625(%rip)      # 0x738b0 <g.4>
   6828b:      	je	0x6e9c5 <f.2+0x17805>
   68291:      	movq	%rax, %rdx
   68294:      	cmpq	$0x0, 0xb60c(%rip)      # 0x738a8 <g.3>
   6829c:      	leaq	0x28(%rsp), %r8
   682a1:      	leaq	0x20(%rsp), %rdi
   682a6:      	leaq	0xb51b(%rip), %r9       # 0x737c8 <native_roots.0>
   682ad:      	movq	0x10(%rsp), %rcx
   682b2:      	movq	0x18(%rsp), %rax
   682b7:      	je	0x6e9c5 <f.2+0x17805>
   682bd:      	addq	0x58(%rsp), %rdx
   682c2:      	addq	%rax, %rdx
   682c5:      	cmpq	$0xf, %r14
   682c9:      	je	0x682dd <f.2+0x1111d>
   682cb:      	cmpq	$0x10, %r14
   682cf:      	jne	0x682f4 <f.2+0x11134>
   682d1:      	movl	$0x1, %esi
   682d6:      	xorl	%eax, %eax
   682d8:      	jmp	0x68434 <f.2+0x11274>
   682dd:      	leaq	(%r14,%rdx), %rax
   682e1:      	addq	$-0xe, %rax
   682e5:      	movl	$0x1, %r10d
   682eb:      	leaq	-0xf(%r14), %rsi
   682ef:      	jmp	0x687dc <f.2+0x1161c>
   682f4:      	movq	%rdx, 0x18(%rsp)
   682f9:      	leaq	-0x10(%r14), %rsi
   682fd:      	movq	$0x0, 0x50(%rsp)
   68306:      	movq	$0x3, 0x38(%rsp)
   6830f:      	xorl	%edi, %edi
   68311:      	callq	0x6e9d0 <f.3>
   68316:      	subq	$0x8, %rsp
   6831a:      	cmpb	$0x0, 0xb58f(%rip)      # 0x738b0 <g.4>
   68321:      	je	0x6e9c5 <f.2+0x17805>
   68327:      	movq	%rax, 0x58(%rsp)
   6832c:      	cmpq	$0x0, 0xb574(%rip)      # 0x738a8 <g.3>
   68334:      	je	0x6e9c5 <f.2+0x17805>
   6833a:      	leaq	-0x11(%r14), %rsi
   6833e:      	movq	$0x0, 0x50(%rsp)
   68347:      	movq	$0x3, 0x38(%rsp)
   68350:      	xorl	%edi, %edi
   68352:      	callq	0x6e9d0 <f.3>
   68357:      	subq	$0x8, %rsp
   6835b:      	cmpb	$0x0, 0xb54e(%rip)      # 0x738b0 <g.4>
   68362:      	je	0x6e9c5 <f.2+0x17805>
   68368:      	movq	%rax, %rsi
   6836b:      	cmpq	$0x0, 0xb535(%rip)      # 0x738a8 <g.3>
   68373:      	leaq	0x20(%rsp), %rdi
   68378:      	leaq	-0x10(%r14), %rax
   6837c:      	movq	0x18(%rsp), %rdx
   68381:      	je	0x6e9c5 <f.2+0x17805>
   68387:      	addq	0x58(%rsp), %rsi
   6838c:      	cmpq	$0x12, %r14
   68390:      	jae	0x683a8 <f.2+0x111e8>
   68392:      	leaq	0x28(%rsp), %r8
   68397:      	leaq	0xb42a(%rip), %r9       # 0x737c8 <native_roots.0>
   6839e:      	movq	0x10(%rsp), %rcx
   683a3:      	jmp	0x68434 <f.2+0x11274>
   683a8:      	movq	%rsi, 0x58(%rsp)
   683ad:      	movq	$0x0, 0x50(%rsp)
   683b6:      	movq	$0x3, 0x38(%rsp)
   683bf:      	xorl	%edi, %edi
   683c1:      	leaq	-0x11(%r14), %rsi
   683c5:      	callq	0x6e9d0 <f.3>
   683ca:      	subq	$0x8, %rsp
   683ce:      	cmpb	$0x0, 0xb4db(%rip)      # 0x738b0 <g.4>
   683d5:      	je	0x6e9c5 <f.2+0x17805>
   683db:      	movq	%rax, 0x60(%rsp)
   683e0:      	cmpq	$0x0, 0xb4c0(%rip)      # 0x738a8 <g.3>
   683e8:      	je	0x6e9c5 <f.2+0x17805>
   683ee:      	leaq	-0x12(%r14), %rsi
   683f2:      	movq	$0x0, 0x50(%rsp)
   683fb:      	movq	$0x3, 0x38(%rsp)
   68404:      	xorl	%edi, %edi
   68406:      	callq	0x6e9d0 <f.3>
   6840b:      	subq	$0x8, %rsp
   6840f:      	addq	0x60(%rsp), %rax
   68414:      	leaq	0x28(%rsp), %r8
   68419:      	leaq	0x20(%rsp), %rdi
   6841e:      	leaq	0xb3a3(%rip), %r9       # 0x737c8 <native_roots.0>
   68425:      	movq	0x10(%rsp), %rcx
   6842a:      	movq	0x18(%rsp), %rdx
   6842f:      	movq	0x58(%rsp), %rsi
   68434:      	cmpb	$0x0, 0xb475(%rip)      # 0x738b0 <g.4>
   6843b:      	je	0x6e9c5 <f.2+0x17805>
   68441:      	cmpq	$0x0, 0xb45f(%rip)      # 0x738a8 <g.3>
   68449:      	je	0x6e9c5 <f.2+0x17805>
   6844f:      	addq	%rsi, %rax
   68452:      	addq	%rdx, %rax
   68455:      	movq	%r14, %r10
   68458:      	subq	$0x10, %r10
   6845c:      	jbe	0x68513 <f.2+0x11353>
   68462:      	movq	%rax, 0x58(%rsp)
   68467:      	movq	$0x0, 0x50(%rsp)
   68470:      	movq	$0x3, 0x38(%rsp)
   68479:      	xorl	%edi, %edi
   6847b:      	movq	%r10, 0x18(%rsp)
   68480:      	movq	%r10, %rsi
   68483:      	callq	0x6e9d0 <f.3>
   68488:      	subq	$0x8, %rsp
   6848c:      	cmpb	$0x0, 0xb41d(%rip)      # 0x738b0 <g.4>
   68493:      	je	0x6e9c5 <f.2+0x17805>
   68499:      	movq	%rax, 0x60(%rsp)
   6849e:      	cmpq	$0x0, 0xb402(%rip)      # 0x738a8 <g.3>
   684a6:      	je	0x6e9c5 <f.2+0x17805>
   684ac:      	leaq	-0x11(%r14), %rsi
   684b0:      	movq	$0x0, 0x50(%rsp)
   684b9:      	movq	$0x3, 0x38(%rsp)
   684c2:      	xorl	%edi, %edi
   684c4:      	callq	0x6e9d0 <f.3>
   684c9:      	subq	$0x8, %rsp
   684cd:      	cmpb	$0x0, 0xb3dc(%rip)      # 0x738b0 <g.4>
   684d4:      	je	0x6e9c5 <f.2+0x17805>
   684da:      	movq	%rax, %rcx
   684dd:      	cmpq	$0x0, 0xb3c3(%rip)      # 0x738a8 <g.3>
   684e5:      	movq	0x58(%rsp), %rax
   684ea:      	movq	0x18(%rsp), %r10
   684ef:      	je	0x6e9c5 <f.2+0x17805>
   684f5:      	addq	0x60(%rsp), %rcx
   684fa:      	cmpq	$0x11, %r14
   684fe:      	leaq	-0x11(%r14), %rsi
   68502:      	jne	0x6851f <f.2+0x1135f>
   68504:      	addq	%rcx, %r10
   68507:      	movl	$0x1, %esi
   6850c:      	xorl	%edx, %edx
   6850e:      	jmp	0x68649 <f.2+0x11489>
   68513:      	incq	%r10
   68516:      	leaq	-0xf(%r14), %rsi
   6851a:      	jmp	0x687dc <f.2+0x1161c>
   6851f:      	movq	%rcx, 0x60(%rsp)
   68524:      	movq	$0x0, 0x50(%rsp)
   6852d:      	movq	$0x3, 0x38(%rsp)
   68536:      	xorl	%edi, %edi
   68538:      	callq	0x6e9d0 <f.3>
   6853d:      	subq	$0x8, %rsp
   68541:      	cmpb	$0x0, 0xb368(%rip)      # 0x738b0 <g.4>
   68548:      	je	0x6e9c5 <f.2+0x17805>
   6854e:      	movq	%rax, 0x68(%rsp)
   68553:      	cmpq	$0x0, 0xb34d(%rip)      # 0x738a8 <g.3>
   6855b:      	je	0x6e9c5 <f.2+0x17805>
   68561:      	leaq	-0x12(%r14), %rsi
   68565:      	movq	$0x0, 0x50(%rsp)
   6856e:      	movq	$0x3, 0x38(%rsp)
   68577:      	xorl	%edi, %edi
   68579:      	callq	0x6e9d0 <f.3>
   6857e:      	subq	$0x8, %rsp
   68582:      	cmpb	$0x0, 0xb327(%rip)      # 0x738b0 <g.4>
   68589:      	je	0x6e9c5 <f.2+0x17805>
   6858f:      	movq	%rax, 0x18(%rsp)
   68594:      	cmpq	$0x0, 0xb30c(%rip)      # 0x738a8 <g.3>
   6859c:      	leaq	-0x11(%r14), %rsi
   685a0:      	je	0x6e9c5 <f.2+0x17805>
   685a6:      	movq	$0x0, 0x50(%rsp)
   685af:      	movq	$0x3, 0x38(%rsp)
   685b8:      	xorl	%edi, %edi
   685ba:      	callq	0x6e9d0 <f.3>
   685bf:      	subq	$0x8, %rsp
   685c3:      	cmpb	$0x0, 0xb2e6(%rip)      # 0x738b0 <g.4>
   685ca:      	je	0x6e9c5 <f.2+0x17805>
   685d0:      	movq	%rax, 0x70(%rsp)
   685d5:      	cmpq	$0x0, 0xb2cb(%rip)      # 0x738a8 <g.3>
   685dd:      	je	0x6e9c5 <f.2+0x17805>
   685e3:      	movq	$0x0, 0x50(%rsp)
   685ec:      	movq	$0x3, 0x38(%rsp)
   685f5:      	xorl	%edi, %edi
   685f7:      	leaq	-0x12(%r14), %rsi
   685fb:      	callq	0x6e9d0 <f.3>
   68600:      	subq	$0x8, %rsp
   68604:      	cmpb	$0x0, 0xb2a5(%rip)      # 0x738b0 <g.4>
   6860b:      	je	0x6e9c5 <f.2+0x17805>
   68611:      	movq	%rax, %rsi
   68614:      	cmpq	$0x0, 0xb28c(%rip)      # 0x738a8 <g.3>
   6861c:      	movq	0x58(%rsp), %rax
   68621:      	movq	0x18(%rsp), %r10
   68626:      	leaq	-0x11(%r14), %rdx
   6862a:      	je	0x6e9c5 <f.2+0x17805>
   68630:      	addq	0x68(%rsp), %r10
   68635:      	addq	0x60(%rsp), %r10
   6863a:      	addq	0x70(%rsp), %rsi
   6863f:      	cmpq	$0x13, %r14
   68643:      	jae	0x68740 <f.2+0x11580>
   68649:      	leaq	0x28(%rsp), %r8
   6864e:      	leaq	0x20(%rsp), %rdi
   68653:      	leaq	0xb16e(%rip), %r9       # 0x737c8 <native_roots.0>
   6865a:      	movq	0x10(%rsp), %rcx
   6865f:      	jmp	0x687d9 <f.2+0x11619>
   68664:      	movq	%r10, 0x60(%rsp)
   68669:      	movq	%rsi, 0x58(%rsp)
   6866e:      	movq	$0x0, 0x50(%rsp)
   68677:      	movq	$0x3, 0x38(%rsp)
   68680:      	xorl	%edi, %edi
   68682:      	leaq	-0x11(%r14), %rsi
   68686:      	callq	0x6e9d0 <f.3>
   6868b:      	subq	$0x8, %rsp
   6868f:      	cmpb	$0x0, 0xb21a(%rip)      # 0x738b0 <g.4>
   68696:      	je	0x6e9c5 <f.2+0x17805>
   6869c:      	cmpq	$0x0, 0xb204(%rip)      # 0x738a8 <g.3>
   686a4:      	je	0x6e9c5 <f.2+0x17805>
   686aa:      	movq	%rax, %r12
   686ad:      	leaq	-0x12(%r14), %rsi
   686b1:      	movq	$0x0, 0x50(%rsp)
   686ba:      	movq	$0x3, 0x38(%rsp)
   686c3:      	xorl	%edi, %edi
   686c5:      	callq	0x6e9d0 <f.3>
   686ca:      	subq	$0x8, %rsp
   686ce:      	addq	%r12, %rax
   686d1:      	leaq	0x28(%rsp), %r8
   686d6:      	leaq	0x20(%rsp), %rdi
   686db:      	leaq	0xb0e6(%rip), %r9       # 0x737c8 <native_roots.0>
   686e2:      	movq	0x10(%rsp), %rcx
   686e7:      	movq	0x18(%rsp), %r12
   686ec:      	movq	0x58(%rsp), %rsi
   686f1:      	movq	0x60(%rsp), %r10
   686f6:      	addq	%rax, %r10
   686f9:      	addq	%r10, %rsi
   686fc:      	addq	%rsi, %r13
   686ff:      	addq	%r13, %rcx
   68702:      	cmpb	$0x0, 0xb1a7(%rip)      # 0x738b0 <g.4>
   68709:      	je	0x6e9c5 <f.2+0x17805>
   6870f:      	cmpq	$0x0, 0xb191(%rip)      # 0x738a8 <g.3>
   68717:      	je	0x6e9c5 <f.2+0x17805>
   6871d:      	addq	%rbp, %rcx
   68720:      	addq	%r12, %rcx
   68723:      	cmpq	$0x6, %r14
   68727:      	jne	0x5755b <f.2+0x39b>
   6872d:      	leaq	(%r14,%rcx), %r12
   68731:      	addq	$-0x5, %r12
   68735:      	movl	$0x1, %r13d
   6873b:      	jmp	0x6884f <f.2+0x1168f>
   68740:      	movq	%rsi, 0x60(%rsp)
   68745:      	movq	%r10, 0x18(%rsp)
   6874a:      	movq	$0x0, 0x50(%rsp)
   68753:      	movq	$0x3, 0x38(%rsp)
   6875c:      	xorl	%edi, %edi
   6875e:      	leaq	-0x12(%r14), %rsi
   68762:      	callq	0x6e9d0 <f.3>
   68767:      	subq	$0x8, %rsp
   6876b:      	cmpb	$0x0, 0xb13e(%rip)      # 0x738b0 <g.4>
   68772:      	je	0x6e9c5 <f.2+0x17805>
   68778:      	movq	%rax, 0x68(%rsp)
   6877d:      	cmpq	$0x0, 0xb123(%rip)      # 0x738a8 <g.3>
   68785:      	je	0x6e9c5 <f.2+0x17805>
   6878b:      	leaq	-0x13(%r14), %rsi
   6878f:      	movq	$0x0, 0x50(%rsp)
   68798:      	movq	$0x3, 0x38(%rsp)
   687a1:      	xorl	%edi, %edi
   687a3:      	callq	0x6e9d0 <f.3>
   687a8:      	subq	$0x8, %rsp
   687ac:      	movq	%rax, %rdx
   687af:      	addq	0x68(%rsp), %rdx
   687b4:      	leaq	0x28(%rsp), %r8
   687b9:      	leaq	0x20(%rsp), %rdi
   687be:      	leaq	0xb003(%rip), %r9       # 0x737c8 <native_roots.0>
   687c5:      	movq	0x10(%rsp), %rcx
   687ca:      	movq	0x58(%rsp), %rax
   687cf:      	movq	0x18(%rsp), %r10
   687d4:      	movq	0x60(%rsp), %rsi
   687d9:      	addq	%rdx, %rsi
   687dc:      	addq	%rsi, %r10
   687df:      	addq	%r10, %rax
   687e2:      	addq	%rax, %r13
   687e5:      	addq	%r13, %r12
   687e8:      	cmpb	$0x0, 0xb0c1(%rip)      # 0x738b0 <g.4>
   687ef:      	je	0x6e9c5 <f.2+0x17805>
   687f5:      	cmpq	$0x0, 0xb0ab(%rip)      # 0x738a8 <g.3>
   687fd:      	je	0x6e9c5 <f.2+0x17805>
   68803:      	addq	%rbp, %r12
   68806:      	addq	%rcx, %r12
   68809:      	cmpq	$0x7, %r14
   6880d:      	jbe	0x6884b <f.2+0x1168b>
   6880f:      	movl	$0x1, %eax
   68814:      	cmpq	$0x8, %r14
   68818:      	je	0x6885f <f.2+0x1169f>
   6881a:      	cmpq	$0x9, %r14
   6881e:      	jbe	0x6885b <f.2+0x1169b>
   68820:      	cmpq	$0xa, %r14
   68824:      	je	0x688d0 <f.2+0x11710>
   6882a:      	cmpq	$0xb, %r14
   6882e:      	jbe	0x688cc <f.2+0x1170c>
   68834:      	cmpq	$0xc, %r14
   68838:      	jne	0x68925 <f.2+0x11765>
   6883e:      	movl	$0x1, %r13d
   68844:      	xorl	%eax, %eax
   68846:      	jmp	0x68ba8 <f.2+0x119e8>
   6884b:      	leaq	-0x6(%r14), %r13
   6884f:      	addq	$-0x6, %r14
   68853:      	movq	%r14, %rbp
   68856:      	jmp	0x6e8f4 <f.2+0x17734>
   6885b:      	leaq	-0x8(%r14), %rax
   6885f:      	addq	%r14, %rax
   68862:      	addq	$-0x8, %rax
   68866:      	cmpq	$0x8, %r14
   6886a:      	je	0x6b5e8 <f.2+0x14428>
   68870:      	movl	$0x1, %ebp
   68875:      	cmpq	$0x9, %r14
   68879:      	je	0x688b6 <f.2+0x116f6>
   6887b:      	cmpq	$0xa, %r14
   6887f:      	jbe	0x688b2 <f.2+0x116f2>
   68881:      	movl	$0x1, %ecx
   68886:      	cmpq	$0xb, %r14
   6888a:      	je	0x68919 <f.2+0x11759>
   68890:      	cmpq	$0xc, %r14
   68894:      	jbe	0x68915 <f.2+0x11755>
   68896:      	cmpq	$0xd, %r14
   6889a:      	movq	%rax, 0x10(%rsp)
   6889f:      	jne	0x68a6f <f.2+0x118af>
   688a5:      	movl	$0x1, %r13d
   688ab:      	xorl	%ecx, %ecx
   688ad:      	jmp	0x68e96 <f.2+0x11cd6>
   688b2:      	leaq	-0x9(%r14), %rbp
   688b6:      	leaq	-0x9(%r14), %r13
   688ba:      	cmpb	$0x0, 0xafef(%rip)      # 0x738b0 <g.4>
   688c1:      	jne	0x6b6ac <f.2+0x144ec>
   688c7:      	jmp	0x6e9c5 <f.2+0x17805>
   688cc:      	leaq	-0xa(%r14), %rax
   688d0:      	addq	%r14, %rax
   688d3:      	addq	$-0xa, %rax
   688d7:      	cmpq	$0xa, %r14
   688db:      	je	0x69827 <f.2+0x12667>
   688e1:      	movl	$0x1, %ebp
   688e6:      	cmpq	$0xb, %r14
   688ea:      	je	0x6890c <f.2+0x1174c>
   688ec:      	cmpq	$0xc, %r14
   688f0:      	jbe	0x68908 <f.2+0x11748>
   688f2:      	cmpq	$0xd, %r14
   688f6:      	movq	%rax, 0x10(%rsp)
   688fb:      	jne	0x689ca <f.2+0x1180a>
   68901:      	xorl	%ecx, %ecx
   68903:      	jmp	0x68d23 <f.2+0x11b63>
   68908:      	leaq	-0xb(%r14), %rbp
   6890c:      	leaq	-0xb(%r14), %rcx
   68910:      	jmp	0x698ca <f.2+0x1270a>
   68915:      	leaq	-0xb(%r14), %rcx
   68919:      	addq	%r14, %rcx
   6891c:      	addq	$-0xb, %rcx
   68920:      	jmp	0x6a455 <f.2+0x13295>
   68925:      	leaq	-0xc(%r14), %rsi
   68929:      	movq	$0x0, 0x50(%rsp)
   68932:      	movq	$0x3, 0x38(%rsp)
   6893b:      	xorl	%edi, %edi
   6893d:      	callq	0x6e9d0 <f.3>
   68942:      	subq	$0x8, %rsp
   68946:      	cmpb	$0x0, 0xaf63(%rip)      # 0x738b0 <g.4>
   6894d:      	je	0x6e9c5 <f.2+0x17805>
   68953:      	cmpq	$0x0, 0xaf4d(%rip)      # 0x738a8 <g.3>
   6895b:      	je	0x6e9c5 <f.2+0x17805>
   68961:      	movq	%rax, %rbp
   68964:      	leaq	-0xd(%r14), %rsi
   68968:      	movq	$0x0, 0x50(%rsp)
   68971:      	movq	$0x3, 0x38(%rsp)
   6897a:      	xorl	%edi, %edi
   6897c:      	callq	0x6e9d0 <f.3>
   68981:      	subq	$0x8, %rsp
   68985:      	cmpb	$0x0, 0xaf24(%rip)      # 0x738b0 <g.4>
   6898c:      	je	0x6e9c5 <f.2+0x17805>
   68992:      	movq	%rax, %r13
   68995:      	cmpq	$0x0, 0xaf0b(%rip)      # 0x738a8 <g.3>
   6899d:      	leaq	-0xc(%r14), %rax
   689a1:      	je	0x6e9c5 <f.2+0x17805>
   689a7:      	addq	%rbp, %r13
   689aa:      	cmpq	$0xd, %r14
   689ae:      	ja	0x68b19 <f.2+0x11959>
   689b4:      	leaq	0x28(%rsp), %r8
   689b9:      	leaq	0x20(%rsp), %rdi
   689be:      	leaq	0xae03(%rip), %r9       # 0x737c8 <native_roots.0>
   689c5:      	jmp	0x68ba8 <f.2+0x119e8>
   689ca:      	leaq	-0xd(%r14), %rsi
   689ce:      	movq	$0x0, 0x50(%rsp)
   689d7:      	movq	$0x3, 0x38(%rsp)
   689e0:      	xorl	%edi, %edi
   689e2:      	callq	0x6e9d0 <f.3>
   689e7:      	subq	$0x8, %rsp
   689eb:      	cmpb	$0x0, 0xaebe(%rip)      # 0x738b0 <g.4>
   689f2:      	je	0x6e9c5 <f.2+0x17805>
   689f8:      	cmpq	$0x0, 0xaea8(%rip)      # 0x738a8 <g.3>
   68a00:      	je	0x6e9c5 <f.2+0x17805>
   68a06:      	movq	%rax, %r13
   68a09:      	leaq	-0xe(%r14), %rsi
   68a0d:      	movq	$0x0, 0x50(%rsp)
   68a16:      	movq	$0x3, 0x38(%rsp)
   68a1f:      	xorl	%edi, %edi
   68a21:      	callq	0x6e9d0 <f.3>
   68a26:      	subq	$0x8, %rsp
   68a2a:      	cmpb	$0x0, 0xae7f(%rip)      # 0x738b0 <g.4>
   68a31:      	je	0x6e9c5 <f.2+0x17805>
   68a37:      	cmpq	$0x0, 0xae69(%rip)      # 0x738a8 <g.3>
   68a3f:      	leaq	0x20(%rsp), %rdi
   68a44:      	je	0x6e9c5 <f.2+0x17805>
   68a4a:      	movq	%rax, %rbp
   68a4d:      	addq	%r13, %rbp
   68a50:      	cmpq	$0xe, %r14
   68a54:      	ja	0x68c91 <f.2+0x11ad1>
   68a5a:      	leaq	0x28(%rsp), %r8
   68a5f:      	leaq	0xad62(%rip), %r9       # 0x737c8 <native_roots.0>
   68a66:      	leaq	-0xd(%r14), %rcx
   68a6a:      	jmp	0x68d23 <f.2+0x11b63>
   68a6f:      	leaq	-0xd(%r14), %rsi
   68a73:      	movq	$0x0, 0x50(%rsp)
   68a7c:      	movq	$0x3, 0x38(%rsp)
   68a85:      	xorl	%edi, %edi
   68a87:      	callq	0x6e9d0 <f.3>
   68a8c:      	subq	$0x8, %rsp
   68a90:      	cmpb	$0x0, 0xae19(%rip)      # 0x738b0 <g.4>
   68a97:      	je	0x6e9c5 <f.2+0x17805>
   68a9d:      	cmpq	$0x0, 0xae03(%rip)      # 0x738a8 <g.3>
   68aa5:      	je	0x6e9c5 <f.2+0x17805>
   68aab:      	movq	%rax, %rbp
   68aae:      	leaq	-0xe(%r14), %rsi
   68ab2:      	movq	$0x0, 0x50(%rsp)
   68abb:      	movq	$0x3, 0x38(%rsp)
   68ac4:      	xorl	%edi, %edi
   68ac6:      	callq	0x6e9d0 <f.3>
   68acb:      	subq	$0x8, %rsp
   68acf:      	cmpb	$0x0, 0xadda(%rip)      # 0x738b0 <g.4>
   68ad6:      	je	0x6e9c5 <f.2+0x17805>
   68adc:      	cmpq	$0x0, 0xadc4(%rip)      # 0x738a8 <g.3>
   68ae4:      	je	0x6e9c5 <f.2+0x17805>
   68aea:      	movq	%rax, %r13
   68aed:      	addq	%rbp, %r13
   68af0:      	cmpq	$0xe, %r14
   68af4:      	ja	0x68dff <f.2+0x11c3f>
   68afa:      	leaq	0x28(%rsp), %r8
   68aff:      	leaq	0x20(%rsp), %rdi
   68b04:      	leaq	0xacbd(%rip), %r9       # 0x737c8 <native_roots.0>
   68b0b:      	movq	0x10(%rsp), %rax
   68b10:      	leaq	-0xd(%r14), %rcx
   68b14:      	jmp	0x68e96 <f.2+0x11cd6>
   68b19:      	movq	$0x0, 0x50(%rsp)
   68b22:      	movq	$0x3, 0x38(%rsp)
   68b2b:      	xorl	%edi, %edi
   68b2d:      	leaq	-0xd(%r14), %rsi
   68b31:      	callq	0x6e9d0 <f.3>
   68b36:      	subq	$0x8, %rsp
   68b3a:      	cmpb	$0x0, 0xad6f(%rip)      # 0x738b0 <g.4>
   68b41:      	je	0x6e9c5 <f.2+0x17805>
   68b47:      	cmpq	$0x0, 0xad59(%rip)      # 0x738a8 <g.3>
   68b4f:      	je	0x6e9c5 <f.2+0x17805>
   68b55:      	movq	%rax, %rbp
   68b58:      	leaq	-0xe(%r14), %rsi
   68b5c:      	movq	$0x0, 0x50(%rsp)
   68b65:      	movq	$0x3, 0x38(%rsp)
   68b6e:      	xorl	%edi, %edi
   68b70:      	callq	0x6e9d0 <f.3>
   68b75:      	subq	$0x8, %rsp
   68b79:      	cmpb	$0x0, 0xad30(%rip)      # 0x738b0 <g.4>
   68b80:      	je	0x6e9c5 <f.2+0x17805>
   68b86:      	cmpq	$0x0, 0xad1a(%rip)      # 0x738a8 <g.3>
   68b8e:      	leaq	0x28(%rsp), %r8
   68b93:      	leaq	0x20(%rsp), %rdi
   68b98:      	leaq	0xac29(%rip), %r9       # 0x737c8 <native_roots.0>
   68b9f:      	je	0x6e9c5 <f.2+0x17805>
   68ba5:      	addq	%rbp, %rax
   68ba8:      	addq	%r13, %rax
   68bab:      	cmpq	$0xc, %r14
   68baf:      	je	0x68bd4 <f.2+0x11a14>
   68bb1:      	cmpq	$0xd, %r14
   68bb5:      	jne	0x68bea <f.2+0x11a2a>
   68bb7:      	cmpq	$0x0, 0xace9(%rip)      # 0x738a8 <g.3>
   68bbf:      	je	0x6e9c5 <f.2+0x17805>
   68bc5:      	incq	%rax
   68bc8:      	leaq	-0xd(%r14), %rbp
   68bcc:      	movq	%rax, %rcx
   68bcf:      	incq	%rbp
   68bd2:      	jmp	0x68be1 <f.2+0x11a21>
   68bd4:      	leaq	(%r14,%rax), %rcx
   68bd8:      	addq	$-0xb, %rcx
   68bdc:      	movl	$0x1, %ebp
   68be1:      	leaq	-0xc(%r14), %rax
   68be5:      	jmp	0x69809 <f.2+0x12649>
   68bea:      	movq	%rax, 0x10(%rsp)
   68bef:      	leaq	-0xd(%r14), %rsi
   68bf3:      	movq	$0x0, 0x50(%rsp)
   68bfc:      	movq	$0x3, 0x38(%rsp)
   68c05:      	xorl	%edi, %edi
   68c07:      	callq	0x6e9d0 <f.3>
   68c0c:      	subq	$0x8, %rsp
   68c10:      	cmpb	$0x0, 0xac99(%rip)      # 0x738b0 <g.4>
   68c17:      	je	0x6e9c5 <f.2+0x17805>
   68c1d:      	cmpq	$0x0, 0xac83(%rip)      # 0x738a8 <g.3>
   68c25:      	je	0x6e9c5 <f.2+0x17805>
   68c2b:      	movq	%rax, %rbp
   68c2e:      	leaq	-0xe(%r14), %rsi
   68c32:      	movq	$0x0, 0x50(%rsp)
   68c3b:      	movq	$0x3, 0x38(%rsp)
   68c44:      	xorl	%edi, %edi
   68c46:      	callq	0x6e9d0 <f.3>
   68c4b:      	subq	$0x8, %rsp
   68c4f:      	cmpb	$0x0, 0xac5a(%rip)      # 0x738b0 <g.4>
   68c56:      	je	0x6e9c5 <f.2+0x17805>
   68c5c:      	movq	%rax, %r13
   68c5f:      	cmpq	$0x0, 0xac41(%rip)      # 0x738a8 <g.3>
   68c67:      	movq	0x10(%rsp), %rax
   68c6c:      	je	0x6e9c5 <f.2+0x17805>
   68c72:      	addq	%rbp, %r13
   68c75:      	cmpq	$0xe, %r14
   68c79:      	ja	0x68f77 <f.2+0x11db7>
   68c7f:      	leaq	-0xd(%r14), %rbp
   68c83:      	addq	%rbp, %r13
   68c86:      	addq	%rax, %r13
   68c89:      	movq	%r13, %rcx
   68c8c:      	jmp	0x69021 <f.2+0x11e61>
   68c91:      	movq	$0x0, 0x50(%rsp)
   68c9a:      	movq	$0x3, 0x38(%rsp)
   68ca3:      	xorl	%edi, %edi
   68ca5:      	leaq	-0xe(%r14), %rsi
   68ca9:      	callq	0x6e9d0 <f.3>
   68cae:      	subq	$0x8, %rsp
   68cb2:      	cmpb	$0x0, 0xabf7(%rip)      # 0x738b0 <g.4>
   68cb9:      	je	0x6e9c5 <f.2+0x17805>
   68cbf:      	cmpq	$0x0, 0xabe1(%rip)      # 0x738a8 <g.3>
   68cc7:      	je	0x6e9c5 <f.2+0x17805>
   68ccd:      	movq	%rax, %r13
   68cd0:      	leaq	-0xf(%r14), %rsi
   68cd4:      	movq	$0x0, 0x50(%rsp)
   68cdd:      	movq	$0x3, 0x38(%rsp)
   68ce6:      	xorl	%edi, %edi
   68ce8:      	callq	0x6e9d0 <f.3>
   68ced:      	subq	$0x8, %rsp
   68cf1:      	cmpb	$0x0, 0xabb8(%rip)      # 0x738b0 <g.4>
   68cf8:      	je	0x6e9c5 <f.2+0x17805>
   68cfe:      	cmpq	$0x0, 0xaba2(%rip)      # 0x738a8 <g.3>
   68d06:      	leaq	0x28(%rsp), %r8
   68d0b:      	leaq	0x20(%rsp), %rdi
   68d10:      	leaq	0xaab1(%rip), %r9       # 0x737c8 <native_roots.0>
   68d17:      	je	0x6e9c5 <f.2+0x17805>
   68d1d:      	addq	%r13, %rax
   68d20:      	movq	%rax, %rcx
   68d23:      	addq	%rbp, %rcx
   68d26:      	cmpq	$0xd, %r14
   68d2a:      	je	0x68d3e <f.2+0x11b7e>
   68d2c:      	cmpq	$0xe, %r14
   68d30:      	jne	0x68d54 <f.2+0x11b94>
   68d32:      	movl	$0x1, %eax
   68d37:      	xorl	%ebp, %ebp
   68d39:      	jmp	0x69295 <f.2+0x120d5>
   68d3e:      	leaq	(%r14,%rcx), %rbp
   68d42:      	addq	$-0xc, %rbp
   68d46:      	movl	$0x1, %ecx
   68d4b:      	leaq	-0xd(%r14), %r13
   68d4f:      	jmp	0x698c2 <f.2+0x12702>
   68d54:      	movq	%rcx, 0x18(%rsp)
   68d59:      	leaq	-0xe(%r14), %rbp
   68d5d:      	movq	$0x0, 0x50(%rsp)
   68d66:      	movq	$0x3, 0x38(%rsp)
   68d6f:      	xorl	%edi, %edi
   68d71:      	movq	%rbp, %rsi
   68d74:      	callq	0x6e9d0 <f.3>
   68d79:      	subq	$0x8, %rsp
   68d7d:      	cmpb	$0x0, 0xab2c(%rip)      # 0x738b0 <g.4>
   68d84:      	je	0x6e9c5 <f.2+0x17805>
   68d8a:      	cmpq	$0x0, 0xab16(%rip)      # 0x738a8 <g.3>
   68d92:      	je	0x6e9c5 <f.2+0x17805>
   68d98:      	movq	%rax, %r13
   68d9b:      	leaq	-0xf(%r14), %rsi
   68d9f:      	movq	$0x0, 0x50(%rsp)
   68da8:      	movq	$0x3, 0x38(%rsp)
   68db1:      	xorl	%edi, %edi
   68db3:      	callq	0x6e9d0 <f.3>
   68db8:      	subq	$0x8, %rsp
   68dbc:      	cmpb	$0x0, 0xaaed(%rip)      # 0x738b0 <g.4>
   68dc3:      	je	0x6e9c5 <f.2+0x17805>
   68dc9:      	cmpq	$0x0, 0xaad7(%rip)      # 0x738a8 <g.3>
   68dd1:      	je	0x6e9c5 <f.2+0x17805>
   68dd7:      	addq	%r13, %rax
   68dda:      	cmpq	$0x10, %r14
   68dde:      	jae	0x6920f <f.2+0x1204f>
   68de4:      	leaq	0x28(%rsp), %r8
   68de9:      	leaq	0x20(%rsp), %rdi
   68dee:      	leaq	0xa9d3(%rip), %r9       # 0x737c8 <native_roots.0>
   68df5:      	movq	0x18(%rsp), %rcx
   68dfa:      	jmp	0x69295 <f.2+0x120d5>
   68dff:      	movq	$0x0, 0x50(%rsp)
   68e08:      	movq	$0x3, 0x38(%rsp)
   68e11:      	xorl	%edi, %edi
   68e13:      	leaq	-0xe(%r14), %rsi
   68e17:      	callq	0x6e9d0 <f.3>
   68e1c:      	subq	$0x8, %rsp
   68e20:      	cmpb	$0x0, 0xaa89(%rip)      # 0x738b0 <g.4>
   68e27:      	je	0x6e9c5 <f.2+0x17805>
   68e2d:      	cmpq	$0x0, 0xaa73(%rip)      # 0x738a8 <g.3>
   68e35:      	je	0x6e9c5 <f.2+0x17805>
   68e3b:      	movq	%rax, %rbp
   68e3e:      	leaq	-0xf(%r14), %rsi
   68e42:      	movq	$0x0, 0x50(%rsp)
   68e4b:      	movq	$0x3, 0x38(%rsp)
   68e54:      	xorl	%edi, %edi
   68e56:      	callq	0x6e9d0 <f.3>
   68e5b:      	subq	$0x8, %rsp
   68e5f:      	cmpb	$0x0, 0xaa4a(%rip)      # 0x738b0 <g.4>
   68e66:      	je	0x6e9c5 <f.2+0x17805>
   68e6c:      	movq	%rax, %rcx
   68e6f:      	cmpq	$0x0, 0xaa31(%rip)      # 0x738a8 <g.3>
   68e77:      	leaq	0x28(%rsp), %r8
   68e7c:      	leaq	0x20(%rsp), %rdi
   68e81:      	leaq	0xa940(%rip), %r9       # 0x737c8 <native_roots.0>
   68e88:      	movq	0x10(%rsp), %rax
   68e8d:      	je	0x6e9c5 <f.2+0x17805>
   68e93:      	addq	%rbp, %rcx
   68e96:      	addq	%r13, %rcx
   68e99:      	cmpq	$0xd, %r14
   68e9d:      	je	0x68eb2 <f.2+0x11cf2>
   68e9f:      	cmpq	$0xe, %r14
   68ea3:      	jne	0x68ec8 <f.2+0x11d08>
   68ea5:      	movl	$0x1, %r13d
   68eab:      	xorl	%edx, %edx
   68ead:      	jmp	0x69406 <f.2+0x12246>
   68eb2:      	leaq	(%r14,%rcx), %rdx
   68eb6:      	addq	$-0xc, %rdx
   68eba:      	movl	$0x1, %ebp
   68ebf:      	leaq	-0xd(%r14), %rcx
   68ec3:      	jmp	0x6a434 <f.2+0x13274>
   68ec8:      	movq	%rcx, 0x18(%rsp)
   68ecd:      	leaq	-0xe(%r14), %rsi
   68ed1:      	movq	$0x0, 0x50(%rsp)
   68eda:      	movq	$0x3, 0x38(%rsp)
   68ee3:      	xorl	%edi, %edi
   68ee5:      	callq	0x6e9d0 <f.3>
   68eea:      	subq	$0x8, %rsp
   68eee:      	cmpb	$0x0, 0xa9bb(%rip)      # 0x738b0 <g.4>
   68ef5:      	je	0x6e9c5 <f.2+0x17805>
   68efb:      	cmpq	$0x0, 0xa9a5(%rip)      # 0x738a8 <g.3>
   68f03:      	je	0x6e9c5 <f.2+0x17805>
   68f09:      	movq	%rax, %rbp
   68f0c:      	leaq	-0xf(%r14), %rsi
   68f10:      	movq	$0x0, 0x50(%rsp)
   68f19:      	movq	$0x3, 0x38(%rsp)
   68f22:      	xorl	%edi, %edi
   68f24:      	callq	0x6e9d0 <f.3>
   68f29:      	subq	$0x8, %rsp
   68f2d:      	cmpb	$0x0, 0xa97c(%rip)      # 0x738b0 <g.4>
   68f34:      	je	0x6e9c5 <f.2+0x17805>
   68f3a:      	movq	%rax, %r13
   68f3d:      	cmpq	$0x0, 0xa963(%rip)      # 0x738a8 <g.3>
   68f45:      	leaq	0x28(%rsp), %r8
   68f4a:      	leaq	0xa877(%rip), %r9       # 0x737c8 <native_roots.0>
   68f51:      	movq	0x10(%rsp), %rax
   68f56:      	leaq	-0xe(%r14), %rdx
   68f5a:      	je	0x6e9c5 <f.2+0x17805>
   68f60:      	addq	%rbp, %r13
   68f63:      	cmpq	$0x10, %r14
   68f67:      	jae	0x69385 <f.2+0x121c5>
   68f6d:      	leaq	0x20(%rsp), %rdi
   68f72:      	jmp	0x69401 <f.2+0x12241>
   68f77:      	movq	$0x0, 0x50(%rsp)
   68f80:      	movq	$0x3, 0x38(%rsp)
   68f89:      	xorl	%edi, %edi
   68f8b:      	leaq	-0xe(%r14), %rsi
   68f8f:      	callq	0x6e9d0 <f.3>
   68f94:      	subq	$0x8, %rsp
   68f98:      	cmpb	$0x0, 0xa911(%rip)      # 0x738b0 <g.4>
   68f9f:      	je	0x6e9c5 <f.2+0x17805>
   68fa5:      	cmpq	$0x0, 0xa8fb(%rip)      # 0x738a8 <g.3>
   68fad:      	je	0x6e9c5 <f.2+0x17805>
   68fb3:      	movq	%rax, %rbp
   68fb6:      	leaq	-0xf(%r14), %rsi
   68fba:      	movq	$0x0, 0x50(%rsp)
   68fc3:      	movq	$0x3, 0x38(%rsp)
   68fcc:      	xorl	%edi, %edi
   68fce:      	callq	0x6e9d0 <f.3>
   68fd3:      	subq	$0x8, %rsp
   68fd7:      	cmpb	$0x0, 0xa8d2(%rip)      # 0x738b0 <g.4>
   68fde:      	je	0x6e9c5 <f.2+0x17805>
   68fe4:      	movq	%rax, %rcx
   68fe7:      	cmpq	$0x0, 0xa8b9(%rip)      # 0x738a8 <g.3>
   68fef:      	leaq	0x28(%rsp), %r8
   68ff4:      	leaq	0x20(%rsp), %rdi
   68ff9:      	leaq	0xa7c8(%rip), %r9       # 0x737c8 <native_roots.0>
   69000:      	movq	0x10(%rsp), %rax
   69005:      	je	0x6e9c5 <f.2+0x17805>
   6900b:      	addq	%rbp, %rcx
   6900e:      	addq	%r13, %rcx
   69011:      	addq	%rax, %rcx
   69014:      	movq	%r14, %rbp
   69017:      	subq	$0xd, %rbp
   6901b:      	jbe	0x68bcf <f.2+0x11a0f>
   69021:      	movq	%rcx, 0x10(%rsp)
   69026:      	movq	$0x0, 0x50(%rsp)
   6902f:      	movq	$0x3, 0x38(%rsp)
   69038:      	xorl	%edi, %edi
   6903a:      	movq	%rbp, %rsi
   6903d:      	callq	0x6e9d0 <f.3>
   69042:      	subq	$0x8, %rsp
   69046:      	cmpb	$0x0, 0xa863(%rip)      # 0x738b0 <g.4>
   6904d:      	je	0x6e9c5 <f.2+0x17805>
   69053:      	cmpq	$0x0, 0xa84d(%rip)      # 0x738a8 <g.3>
   6905b:      	je	0x6e9c5 <f.2+0x17805>
   69061:      	movq	%rax, %r13
   69064:      	movq	$0x0, 0x50(%rsp)
   6906d:      	movq	$0x3, 0x38(%rsp)
   69076:      	xorl	%edi, %edi
   69078:      	leaq	-0xe(%r14), %rsi
   6907c:      	callq	0x6e9d0 <f.3>
   69081:      	subq	$0x8, %rsp
   69085:      	cmpb	$0x0, 0xa824(%rip)      # 0x738b0 <g.4>
   6908c:      	je	0x6e9c5 <f.2+0x17805>
   69092:      	cmpq	$0x0, 0xa80e(%rip)      # 0x738a8 <g.3>
   6909a:      	leaq	0x28(%rsp), %r8
   6909f:      	leaq	0x20(%rsp), %rdi
   690a4:      	leaq	0xa71d(%rip), %r9       # 0x737c8 <native_roots.0>
   690ab:      	movq	0x10(%rsp), %rcx
   690b0:      	je	0x6e9c5 <f.2+0x17805>
   690b6:      	addq	%r13, %rax
   690b9:      	cmpq	$0xe, %r14
   690bd:      	jne	0x690ce <f.2+0x11f0e>
   690bf:      	addq	%rax, %rbp
   690c2:      	movl	$0x1, %edx
   690c7:      	xorl	%eax, %eax
   690c9:      	jmp	0x697f9 <f.2+0x12639>
   690ce:      	movq	%rax, %rbp
   690d1:      	movq	$0x0, 0x50(%rsp)
   690da:      	movq	$0x3, 0x38(%rsp)
   690e3:      	xorl	%edi, %edi
   690e5:      	leaq	-0xe(%r14), %r13
   690e9:      	movq	%r13, %rsi
   690ec:      	callq	0x6e9d0 <f.3>
   690f1:      	subq	$0x8, %rsp
   690f5:      	cmpb	$0x0, 0xa7b4(%rip)      # 0x738b0 <g.4>
   690fc:      	je	0x6e9c5 <f.2+0x17805>
   69102:      	movq	%rax, 0x18(%rsp)
   69107:      	cmpq	$0x0, 0xa799(%rip)      # 0x738a8 <g.3>
   6910f:      	je	0x6e9c5 <f.2+0x17805>
   69115:      	leaq	-0xf(%r14), %rsi
   69119:      	movq	$0x0, 0x50(%rsp)
   69122:      	movq	$0x3, 0x38(%rsp)
   6912b:      	xorl	%edi, %edi
   6912d:      	callq	0x6e9d0 <f.3>
   69132:      	subq	$0x8, %rsp
   69136:      	movq	%rax, 0x58(%rsp)
   6913b:      	cmpb	$0x0, 0xa76e(%rip)      # 0x738b0 <g.4>
   69142:      	je	0x6e9c5 <f.2+0x17805>
   69148:      	cmpq	$0x0, 0xa758(%rip)      # 0x738a8 <g.3>
   69150:      	je	0x6e9c5 <f.2+0x17805>
   69156:      	movq	$0x0, 0x50(%rsp)
   6915f:      	movq	$0x3, 0x38(%rsp)
   69168:      	xorl	%edi, %edi
   6916a:      	movq	%r13, %rsi
   6916d:      	callq	0x6e9d0 <f.3>
   69172:      	subq	$0x8, %rsp
   69176:      	cmpb	$0x0, 0xa733(%rip)      # 0x738b0 <g.4>
   6917d:      	je	0x6e9c5 <f.2+0x17805>
   69183:      	cmpq	$0x0, 0xa71d(%rip)      # 0x738a8 <g.3>
   6918b:      	je	0x6e9c5 <f.2+0x17805>
   69191:      	movq	%rax, %r13
   69194:      	movq	$0x0, 0x50(%rsp)
   6919d:      	movq	$0x3, 0x38(%rsp)
   691a6:      	xorl	%edi, %edi
   691a8:      	leaq	-0xf(%r14), %rsi
   691ac:      	callq	0x6e9d0 <f.3>
   691b1:      	subq	$0x8, %rsp
   691b5:      	cmpb	$0x0, 0xa6f4(%rip)      # 0x738b0 <g.4>
   691bc:      	je	0x6e9c5 <f.2+0x17805>
   691c2:      	cmpq	$0x0, 0xa6de(%rip)      # 0x738a8 <g.3>
   691ca:      	leaq	0x28(%rsp), %r8
   691cf:      	leaq	0xa5f2(%rip), %r9       # 0x737c8 <native_roots.0>
   691d6:      	movq	0x10(%rsp), %rcx
   691db:      	je	0x6e9c5 <f.2+0x17805>
   691e1:      	movq	%rax, %rdx
   691e4:      	movq	%rbp, %rax
   691e7:      	movq	0x58(%rsp), %rbp
   691ec:      	addq	0x18(%rsp), %rbp
   691f1:      	addq	%rax, %rbp
   691f4:      	addq	%r13, %rdx
   691f7:      	cmpq	$0x10, %r14
   691fb:      	jae	0x69776 <f.2+0x125b6>
   69201:      	leaq	0x20(%rsp), %rdi
   69206:      	leaq	-0xe(%r14), %rax
   6920a:      	jmp	0x697f9 <f.2+0x12639>
   6920f:      	movq	%rax, 0x58(%rsp)
   69214:      	movq	$0x0, 0x50(%rsp)
   6921d:      	movq	$0x3, 0x38(%rsp)
   69226:      	xorl	%edi, %edi
   69228:      	leaq	-0xf(%r14), %rsi
   6922c:      	callq	0x6e9d0 <f.3>
   69231:      	subq	$0x8, %rsp
   69235:      	cmpb	$0x0, 0xa674(%rip)      # 0x738b0 <g.4>
   6923c:      	je	0x6e9c5 <f.2+0x17805>
   69242:      	cmpq	$0x0, 0xa65e(%rip)      # 0x738a8 <g.3>
   6924a:      	je	0x6e9c5 <f.2+0x17805>
   69250:      	movq	%rax, %r13
   69253:      	leaq	-0x10(%r14), %rsi
   69257:      	movq	$0x0, 0x50(%rsp)
   69260:      	movq	$0x3, 0x38(%rsp)
   69269:      	xorl	%edi, %edi
   6926b:      	callq	0x6e9d0 <f.3>
   69270:      	subq	$0x8, %rsp
   69274:      	movq	%rax, %rbp
   69277:      	addq	%r13, %rbp
   6927a:      	leaq	0x28(%rsp), %r8
   6927f:      	leaq	0x20(%rsp), %rdi
   69284:      	leaq	0xa53d(%rip), %r9       # 0x737c8 <native_roots.0>
   6928b:      	movq	0x18(%rsp), %rcx
   69290:      	movq	0x58(%rsp), %rax
   69295:      	cmpb	$0x0, 0xa614(%rip)      # 0x738b0 <g.4>
   6929c:      	je	0x6e9c5 <f.2+0x17805>
   692a2:      	cmpq	$0x0, 0xa5fe(%rip)      # 0x738a8 <g.3>
   692aa:      	je	0x6e9c5 <f.2+0x17805>
   692b0:      	addq	%rax, %rbp
   692b3:      	addq	%rcx, %rbp
   692b6:      	movq	%r14, %rcx
   692b9:      	subq	$0xe, %rcx
   692bd:      	jbe	0x69379 <f.2+0x121b9>
   692c3:      	movq	$0x0, 0x50(%rsp)
   692cc:      	movq	$0x3, 0x38(%rsp)
   692d5:      	xorl	%edi, %edi
   692d7:      	movq	%rcx, 0x18(%rsp)
   692dc:      	movq	%rcx, %rsi
   692df:      	callq	0x6e9d0 <f.3>
   692e4:      	subq	$0x8, %rsp
   692e8:      	cmpb	$0x0, 0xa5c1(%rip)      # 0x738b0 <g.4>
   692ef:      	je	0x6e9c5 <f.2+0x17805>
   692f5:      	cmpq	$0x0, 0xa5ab(%rip)      # 0x738a8 <g.3>
   692fd:      	je	0x6e9c5 <f.2+0x17805>
   69303:      	movq	%rax, %r13
   69306:      	leaq	-0xf(%r14), %rsi
   6930a:      	movq	$0x0, 0x50(%rsp)
   69313:      	movq	$0x3, 0x38(%rsp)
   6931c:      	xorl	%edi, %edi
   6931e:      	callq	0x6e9d0 <f.3>
   69323:      	subq	$0x8, %rsp
   69327:      	cmpb	$0x0, 0xa582(%rip)      # 0x738b0 <g.4>
   6932e:      	je	0x6e9c5 <f.2+0x17805>
   69334:      	cmpq	$0x0, 0xa56c(%rip)      # 0x738a8 <g.3>
   6933c:      	movq	0x18(%rsp), %rcx
   69341:      	je	0x6e9c5 <f.2+0x17805>
   69347:      	addq	%r13, %rax
   6934a:      	cmpq	$0xf, %r14
   6934e:      	leaq	-0xf(%r14), %rsi
   69352:      	jne	0x694f9 <f.2+0x12339>
   69358:      	addq	%rax, %rcx
   6935b:      	movl	$0x1, %r13d
   69361:      	xorl	%eax, %eax
   69363:      	leaq	0x28(%rsp), %r8
   69368:      	leaq	0x20(%rsp), %rdi
   6936d:      	leaq	0xa454(%rip), %r9       # 0x737c8 <native_roots.0>
   69374:      	jmp	0x698bf <f.2+0x126ff>
   69379:      	incq	%rcx
   6937c:      	leaq	-0xd(%r14), %r13
   69380:      	jmp	0x698c2 <f.2+0x12702>
   69385:      	movq	$0x0, 0x50(%rsp)
   6938e:      	movq	$0x3, 0x38(%rsp)
   69397:      	xorl	%edi, %edi
   69399:      	leaq	-0xf(%r14), %rsi
   6939d:      	callq	0x6e9d0 <f.3>
   693a2:      	subq	$0x8, %rsp
   693a6:      	cmpb	$0x0, 0xa503(%rip)      # 0x738b0 <g.4>
   693ad:      	je	0x6e9c5 <f.2+0x17805>
   693b3:      	cmpq	$0x0, 0xa4ed(%rip)      # 0x738a8 <g.3>
   693bb:      	je	0x6e9c5 <f.2+0x17805>
   693c1:      	movq	%rax, %rbp
   693c4:      	leaq	-0x10(%r14), %rsi
   693c8:      	movq	$0x0, 0x50(%rsp)
   693d1:      	movq	$0x3, 0x38(%rsp)
   693da:      	xorl	%edi, %edi
   693dc:      	callq	0x6e9d0 <f.3>
   693e1:      	subq	$0x8, %rsp
   693e5:      	movq	%rax, %rdx
   693e8:      	addq	%rbp, %rdx
   693eb:      	leaq	0x28(%rsp), %r8
   693f0:      	leaq	0x20(%rsp), %rdi
   693f5:      	leaq	0xa3cc(%rip), %r9       # 0x737c8 <native_roots.0>
   693fc:      	movq	0x10(%rsp), %rax
   69401:      	movq	0x18(%rsp), %rcx
   69406:      	cmpb	$0x0, 0xa4a3(%rip)      # 0x738b0 <g.4>
   6940d:      	je	0x6e9c5 <f.2+0x17805>
   69413:      	cmpq	$0x0, 0xa48d(%rip)      # 0x738a8 <g.3>
   6941b:      	je	0x6e9c5 <f.2+0x17805>
   69421:      	addq	%r13, %rdx
   69424:      	addq	%rcx, %rdx
   69427:      	movq	%r14, %rbp
   6942a:      	subq	$0xe, %rbp
   6942e:      	jbe	0x694ed <f.2+0x1232d>
   69434:      	movq	%rdx, 0x58(%rsp)
   69439:      	movq	$0x0, 0x50(%rsp)
   69442:      	movq	$0x3, 0x38(%rsp)
   6944b:      	xorl	%edi, %edi
   6944d:      	movq	%rbp, %rsi
   69450:      	callq	0x6e9d0 <f.3>
   69455:      	subq	$0x8, %rsp
   69459:      	cmpb	$0x0, 0xa450(%rip)      # 0x738b0 <g.4>
   69460:      	je	0x6e9c5 <f.2+0x17805>
   69466:      	cmpq	$0x0, 0xa43a(%rip)      # 0x738a8 <g.3>
   6946e:      	je	0x6e9c5 <f.2+0x17805>
   69474:      	movq	%rax, %r13
   69477:      	leaq	-0xf(%r14), %rsi
   6947b:      	movq	$0x0, 0x50(%rsp)
   69484:      	movq	$0x3, 0x38(%rsp)
   6948d:      	xorl	%edi, %edi
   6948f:      	callq	0x6e9d0 <f.3>
   69494:      	subq	$0x8, %rsp
   69498:      	cmpb	$0x0, 0xa411(%rip)      # 0x738b0 <g.4>
   6949f:      	je	0x6e9c5 <f.2+0x17805>
   694a5:      	movq	%rax, %rcx
   694a8:      	cmpq	$0x0, 0xa3f8(%rip)      # 0x738a8 <g.3>
   694b0:      	movq	0x10(%rsp), %rax
   694b5:      	movq	0x58(%rsp), %rdx
   694ba:      	je	0x6e9c5 <f.2+0x17805>
   694c0:      	addq	%r13, %rcx
   694c3:      	cmpq	$0xf, %r14
   694c7:      	jne	0x69636 <f.2+0x12476>
   694cd:      	addq	%rcx, %rbp
   694d0:      	movl	$0x1, %ecx
   694d5:      	xorl	%esi, %esi
   694d7:      	leaq	0x28(%rsp), %r8
   694dc:      	leaq	0x20(%rsp), %rdi
   694e1:      	leaq	0xa2e0(%rip), %r9       # 0x737c8 <native_roots.0>
   694e8:      	jmp	0x6a431 <f.2+0x13271>
   694ed:      	incq	%rbp
   694f0:      	leaq	-0xd(%r14), %rcx
   694f4:      	jmp	0x6a434 <f.2+0x13274>
   694f9:      	movq	%rax, 0x58(%rsp)
   694fe:      	movq	$0x0, 0x50(%rsp)
   69507:      	movq	$0x3, 0x38(%rsp)
   69510:      	xorl	%edi, %edi
   69512:      	callq	0x6e9d0 <f.3>
   69517:      	subq	$0x8, %rsp
   6951b:      	cmpb	$0x0, 0xa38e(%rip)      # 0x738b0 <g.4>
   69522:      	je	0x6e9c5 <f.2+0x17805>
   69528:      	movq	%rax, 0x60(%rsp)
   6952d:      	cmpq	$0x0, 0xa373(%rip)      # 0x738a8 <g.3>
   69535:      	je	0x6e9c5 <f.2+0x17805>
   6953b:      	leaq	-0x10(%r14), %r13
   6953f:      	movq	$0x0, 0x50(%rsp)
   69548:      	movq	$0x3, 0x38(%rsp)
   69551:      	xorl	%edi, %edi
   69553:      	movq	%r13, %rsi
   69556:      	callq	0x6e9d0 <f.3>
   6955b:      	subq	$0x8, %rsp
   6955f:      	cmpb	$0x0, 0xa34a(%rip)      # 0x738b0 <g.4>
   69566:      	je	0x6e9c5 <f.2+0x17805>
   6956c:      	movq	%rax, 0x18(%rsp)
   69571:      	cmpq	$0x0, 0xa32f(%rip)      # 0x738a8 <g.3>
   69579:      	je	0x6e9c5 <f.2+0x17805>
   6957f:      	movq	$0x0, 0x50(%rsp)
   69588:      	movq	$0x3, 0x38(%rsp)
   69591:      	xorl	%edi, %edi
   69593:      	leaq	-0xf(%r14), %rsi
   69597:      	callq	0x6e9d0 <f.3>
   6959c:      	subq	$0x8, %rsp
   695a0:      	cmpb	$0x0, 0xa309(%rip)      # 0x738b0 <g.4>
   695a7:      	je	0x6e9c5 <f.2+0x17805>
   695ad:      	movq	%rax, 0x68(%rsp)
   695b2:      	cmpq	$0x0, 0xa2ee(%rip)      # 0x738a8 <g.3>
   695ba:      	je	0x6e9c5 <f.2+0x17805>
   695c0:      	movq	$0x0, 0x50(%rsp)
   695c9:      	movq	$0x3, 0x38(%rsp)
   695d2:      	xorl	%edi, %edi
   695d4:      	movq	%r13, %rsi
   695d7:      	callq	0x6e9d0 <f.3>
   695dc:      	subq	$0x8, %rsp
   695e0:      	cmpb	$0x0, 0xa2c9(%rip)      # 0x738b0 <g.4>
   695e7:      	je	0x6e9c5 <f.2+0x17805>
   695ed:      	movq	%rax, %r13
   695f0:      	cmpq	$0x0, 0xa2b0(%rip)      # 0x738a8 <g.3>
   695f8:      	leaq	0x20(%rsp), %rdi
   695fd:      	movq	0x18(%rsp), %rcx
   69602:      	leaq	-0xf(%r14), %rax
   69606:      	je	0x6e9c5 <f.2+0x17805>
   6960c:      	addq	0x60(%rsp), %rcx
   69611:      	addq	0x58(%rsp), %rcx
   69616:      	addq	0x68(%rsp), %r13
   6961b:      	cmpq	$0x11, %r14
   6961f:      	jae	0x6983d <f.2+0x1267d>
   69625:      	leaq	0x28(%rsp), %r8
   6962a:      	leaq	0xa197(%rip), %r9       # 0x737c8 <native_roots.0>
   69631:      	jmp	0x698bf <f.2+0x126ff>
   69636:      	movq	%rcx, 0x18(%rsp)
   6963b:      	movq	$0x0, 0x50(%rsp)
   69644:      	movq	$0x3, 0x38(%rsp)
   6964d:      	xorl	%edi, %edi
   6964f:      	leaq	-0xf(%r14), %r13
   69653:      	movq	%r13, %rsi
   69656:      	callq	0x6e9d0 <f.3>
   6965b:      	subq	$0x8, %rsp
   6965f:      	cmpb	$0x0, 0xa24a(%rip)      # 0x738b0 <g.4>
   69666:      	je	0x6e9c5 <f.2+0x17805>
   6966c:      	movq	%rax, 0x60(%rsp)
   69671:      	cmpq	$0x0, 0xa22f(%rip)      # 0x738a8 <g.3>
   69679:      	je	0x6e9c5 <f.2+0x17805>
   6967f:      	leaq	-0x10(%r14), %rsi
   69683:      	movq	$0x0, 0x50(%rsp)
   6968c:      	movq	$0x3, 0x38(%rsp)
   69695:      	xorl	%edi, %edi
   69697:      	callq	0x6e9d0 <f.3>
   6969c:      	subq	$0x8, %rsp
   696a0:      	cmpb	$0x0, 0xa209(%rip)      # 0x738b0 <g.4>
   696a7:      	je	0x6e9c5 <f.2+0x17805>
   696ad:      	cmpq	$0x0, 0xa1f3(%rip)      # 0x738a8 <g.3>
   696b5:      	je	0x6e9c5 <f.2+0x17805>
   696bb:      	movq	%rax, %rbp
   696be:      	movq	$0x0, 0x50(%rsp)
   696c7:      	movq	$0x3, 0x38(%rsp)
   696d0:      	xorl	%edi, %edi
   696d2:      	movq	%r13, %rsi
   696d5:      	callq	0x6e9d0 <f.3>
   696da:      	subq	$0x8, %rsp
   696de:      	cmpb	$0x0, 0xa1cb(%rip)      # 0x738b0 <g.4>
   696e5:      	je	0x6e9c5 <f.2+0x17805>
   696eb:      	cmpq	$0x0, 0xa1b5(%rip)      # 0x738a8 <g.3>
   696f3:      	je	0x6e9c5 <f.2+0x17805>
   696f9:      	movq	%rax, %r13
   696fc:      	movq	$0x0, 0x50(%rsp)
   69705:      	movq	$0x3, 0x38(%rsp)
   6970e:      	xorl	%edi, %edi
   69710:      	leaq	-0x10(%r14), %rsi
   69714:      	callq	0x6e9d0 <f.3>
   69719:      	subq	$0x8, %rsp
   6971d:      	cmpb	$0x0, 0xa18c(%rip)      # 0x738b0 <g.4>
   69724:      	je	0x6e9c5 <f.2+0x17805>
   6972a:      	movq	%rax, %rcx
   6972d:      	cmpq	$0x0, 0xa173(%rip)      # 0x738a8 <g.3>
   69735:      	movq	0x10(%rsp), %rax
   6973a:      	movq	0x58(%rsp), %rdx
   6973f:      	je	0x6e9c5 <f.2+0x17805>
   69745:      	addq	0x60(%rsp), %rbp
   6974a:      	addq	0x18(%rsp), %rbp
   6974f:      	addq	%r13, %rcx
   69752:      	cmpq	$0x11, %r14
   69756:      	jae	0x6a3a6 <f.2+0x131e6>
   6975c:      	leaq	0x28(%rsp), %r8
   69761:      	leaq	0x20(%rsp), %rdi
   69766:      	leaq	0xa05b(%rip), %r9       # 0x737c8 <native_roots.0>
   6976d:      	leaq	-0xf(%r14), %rsi
   69771:      	jmp	0x6a431 <f.2+0x13271>
   69776:      	movq	%rdx, 0x18(%rsp)
   6977b:      	movq	$0x0, 0x50(%rsp)
   69784:      	movq	$0x3, 0x38(%rsp)
   6978d:      	xorl	%edi, %edi
   6978f:      	leaq	-0xf(%r14), %rsi
   69793:      	callq	0x6e9d0 <f.3>
   69798:      	subq	$0x8, %rsp
   6979c:      	cmpb	$0x0, 0xa10d(%rip)      # 0x738b0 <g.4>
   697a3:      	je	0x6e9c5 <f.2+0x17805>
   697a9:      	cmpq	$0x0, 0xa0f7(%rip)      # 0x738a8 <g.3>
   697b1:      	je	0x6e9c5 <f.2+0x17805>
   697b7:      	movq	%rax, %r13
   697ba:      	leaq	-0x10(%r14), %rsi
   697be:      	movq	$0x0, 0x50(%rsp)
   697c7:      	movq	$0x3, 0x38(%rsp)
   697d0:      	xorl	%edi, %edi
   697d2:      	callq	0x6e9d0 <f.3>
   697d7:      	subq	$0x8, %rsp
   697db:      	addq	%r13, %rax
   697de:      	leaq	0x28(%rsp), %r8
   697e3:      	leaq	0x20(%rsp), %rdi
   697e8:      	leaq	0x9fd9(%rip), %r9       # 0x737c8 <native_roots.0>
   697ef:      	movq	0x10(%rsp), %rcx
   697f4:      	movq	0x18(%rsp), %rdx
   697f9:      	cmpb	$0x0, 0xa0b0(%rip)      # 0x738b0 <g.4>
   69800:      	je	0x6e9c5 <f.2+0x17805>
   69806:      	addq	%rdx, %rax
   69809:      	cmpq	$0x0, 0xa097(%rip)      # 0x738a8 <g.3>
   69811:      	je	0x6e9c5 <f.2+0x17805>
   69817:      	addq	%rbp, %rax
   6981a:      	addq	%rcx, %rax
   6981d:      	cmpq	$0xa, %r14
   69821:      	jne	0x688e1 <f.2+0x11721>
   69827:      	leaq	(%r14,%rax), %rcx
   6982b:      	addq	$-0x9, %rcx
   6982f:      	movl	$0x1, %ebp
   69834:      	leaq	-0xa(%r14), %rax
   69838:      	jmp	0x6b5bd <f.2+0x143fd>
   6983d:      	movq	%rcx, 0x18(%rsp)
   69842:      	movq	$0x0, 0x50(%rsp)
   6984b:      	movq	$0x3, 0x38(%rsp)
   69854:      	xorl	%edi, %edi
   69856:      	leaq	-0x10(%r14), %rsi
   6985a:      	callq	0x6e9d0 <f.3>
   6985f:      	subq	$0x8, %rsp
   69863:      	cmpb	$0x0, 0xa046(%rip)      # 0x738b0 <g.4>
   6986a:      	je	0x6e9c5 <f.2+0x17805>
   69870:      	movq	%rax, 0x58(%rsp)
   69875:      	cmpq	$0x0, 0xa02b(%rip)      # 0x738a8 <g.3>
   6987d:      	je	0x6e9c5 <f.2+0x17805>
   69883:      	leaq	-0x11(%r14), %rsi
   69887:      	movq	$0x0, 0x50(%rsp)
   69890:      	movq	$0x3, 0x38(%rsp)
   69899:      	xorl	%edi, %edi
   6989b:      	callq	0x6e9d0 <f.3>
   698a0:      	subq	$0x8, %rsp
   698a4:      	addq	0x58(%rsp), %rax
   698a9:      	leaq	0x28(%rsp), %r8
   698ae:      	leaq	0x20(%rsp), %rdi
   698b3:      	leaq	0x9f0e(%rip), %r9       # 0x737c8 <native_roots.0>
   698ba:      	movq	0x18(%rsp), %rcx
   698bf:      	addq	%rax, %r13
   698c2:      	addq	%r13, %rcx
   698c5:      	movq	0x10(%rsp), %rax
   698ca:      	cmpb	$0x0, 0x9fdf(%rip)      # 0x738b0 <g.4>
   698d1:      	je	0x6e9c5 <f.2+0x17805>
   698d7:      	cmpq	$0x0, 0x9fc9(%rip)      # 0x738a8 <g.3>
   698df:      	je	0x6e9c5 <f.2+0x17805>
   698e5:      	addq	%rbp, %rcx
   698e8:      	addq	%rax, %rcx
   698eb:      	cmpq	$0xb, %r14
   698ef:      	jbe	0x699c3 <f.2+0x12803>
   698f5:      	movl	$0x1, %r13d
   698fb:      	cmpq	$0xc, %r14
   698ff:      	je	0x699d3 <f.2+0x12813>
   69905:      	movq	%r14, %r13
   69908:      	subq	$0xd, %r13
   6990c:      	jbe	0x699d0 <f.2+0x12810>
   69912:      	movq	%rcx, 0x18(%rsp)
   69917:      	movq	$0x0, 0x50(%rsp)
   69920:      	movq	$0x3, 0x38(%rsp)
   69929:      	xorl	%edi, %edi
   6992b:      	movq	%r13, %rsi
   6992e:      	callq	0x6e9d0 <f.3>
   69933:      	subq	$0x8, %rsp
   69937:      	cmpb	$0x0, 0x9f72(%rip)      # 0x738b0 <g.4>
   6993e:      	je	0x6e9c5 <f.2+0x17805>
   69944:      	cmpq	$0x0, 0x9f5c(%rip)      # 0x738a8 <g.3>
   6994c:      	je	0x6e9c5 <f.2+0x17805>
   69952:      	movq	%rax, %rbp
   69955:      	leaq	-0xe(%r14), %rsi
   69959:      	movq	$0x0, 0x50(%rsp)
   69962:      	movq	$0x3, 0x38(%rsp)
   6996b:      	xorl	%edi, %edi
   6996d:      	callq	0x6e9d0 <f.3>
   69972:      	subq	$0x8, %rsp
   69976:      	cmpb	$0x0, 0x9f33(%rip)      # 0x738b0 <g.4>
   6997d:      	je	0x6e9c5 <f.2+0x17805>
   69983:      	cmpq	$0x0, 0x9f1d(%rip)      # 0x738a8 <g.3>
   6998b:      	movq	0x18(%rsp), %rcx
   69990:      	je	0x6e9c5 <f.2+0x17805>
   69996:      	addq	%rbp, %rax
   69999:      	cmpq	$0xe, %r14
   6999d:      	leaq	-0xe(%r14), %rsi
   699a1:      	jne	0x699e0 <f.2+0x12820>
   699a3:      	addq	%rax, %r13
   699a6:      	movl	$0x1, %edx
   699ab:      	xorl	%eax, %eax
   699ad:      	leaq	0x28(%rsp), %r8
   699b2:      	leaq	0x20(%rsp), %rdi
   699b7:      	leaq	0x9e0a(%rip), %r9       # 0x737c8 <native_roots.0>
   699be:      	jmp	0x69b93 <f.2+0x129d3>
   699c3:      	leaq	-0xa(%r14), %rbp
   699c7:      	leaq	-0xa(%r14), %rax
   699cb:      	jmp	0x6b5bd <f.2+0x143fd>
   699d0:      	incq	%r13
   699d3:      	leaq	(%r14,%r13), %rax
   699d7:      	addq	$-0xc, %rax
   699db:      	jmp	0x69bb4 <f.2+0x129f4>
   699e0:      	movq	%rax, 0x10(%rsp)
   699e5:      	movq	$0x0, 0x50(%rsp)
   699ee:      	movq	$0x3, 0x38(%rsp)
   699f7:      	xorl	%edi, %edi
   699f9:      	callq	0x6e9d0 <f.3>
   699fe:      	subq	$0x8, %rsp
   69a02:      	cmpb	$0x0, 0x9ea7(%rip)      # 0x738b0 <g.4>
   69a09:      	je	0x6e9c5 <f.2+0x17805>
   69a0f:      	movq	%rax, 0x58(%rsp)
   69a14:      	cmpq	$0x0, 0x9e8c(%rip)      # 0x738a8 <g.3>
   69a1c:      	je	0x6e9c5 <f.2+0x17805>
   69a22:      	leaq	-0xf(%r14), %rsi
   69a26:      	movq	$0x0, 0x50(%rsp)
   69a2f:      	movq	$0x3, 0x38(%rsp)
   69a38:      	xorl	%edi, %edi
   69a3a:      	callq	0x6e9d0 <f.3>
   69a3f:      	subq	$0x8, %rsp
   69a43:      	cmpb	$0x0, 0x9e66(%rip)      # 0x738b0 <g.4>
   69a4a:      	je	0x6e9c5 <f.2+0x17805>
   69a50:      	cmpq	$0x0, 0x9e50(%rip)      # 0x738a8 <g.3>
   69a58:      	leaq	-0xe(%r14), %rsi
   69a5c:      	je	0x6e9c5 <f.2+0x17805>
   69a62:      	movq	%rax, %r13
   69a65:      	movq	$0x0, 0x50(%rsp)
   69a6e:      	movq	$0x3, 0x38(%rsp)
   69a77:      	xorl	%edi, %edi
   69a79:      	callq	0x6e9d0 <f.3>
   69a7e:      	subq	$0x8, %rsp
   69a82:      	cmpb	$0x0, 0x9e27(%rip)      # 0x738b0 <g.4>
   69a89:      	je	0x6e9c5 <f.2+0x17805>
   69a8f:      	cmpq	$0x0, 0x9e11(%rip)      # 0x738a8 <g.3>
   69a97:      	je	0x6e9c5 <f.2+0x17805>
   69a9d:      	movq	%rax, %rbp
   69aa0:      	movq	$0x0, 0x50(%rsp)
   69aa9:      	movq	$0x3, 0x38(%rsp)
   69ab2:      	xorl	%edi, %edi
   69ab4:      	leaq	-0xf(%r14), %rsi
   69ab8:      	callq	0x6e9d0 <f.3>
   69abd:      	subq	$0x8, %rsp
   69ac1:      	cmpb	$0x0, 0x9de8(%rip)      # 0x738b0 <g.4>
   69ac8:      	je	0x6e9c5 <f.2+0x17805>
   69ace:      	movq	%rax, %rdx
   69ad1:      	cmpq	$0x0, 0x9dcf(%rip)      # 0x738a8 <g.3>
   69ad9:      	leaq	0x28(%rsp), %r8
   69ade:      	leaq	0x20(%rsp), %rdi
   69ae3:      	leaq	0x9cde(%rip), %r9       # 0x737c8 <native_roots.0>
   69aea:      	movq	0x18(%rsp), %rcx
   69aef:      	leaq	-0xe(%r14), %rax
   69af3:      	je	0x6e9c5 <f.2+0x17805>
   69af9:      	addq	0x58(%rsp), %r13
   69afe:      	addq	0x10(%rsp), %r13
   69b03:      	addq	%rbp, %rdx
   69b06:      	cmpq	$0x10, %r14
   69b0a:      	jb	0x69b93 <f.2+0x129d3>
   69b10:      	movq	%rdx, 0x10(%rsp)
   69b15:      	movq	$0x0, 0x50(%rsp)
   69b1e:      	movq	$0x3, 0x38(%rsp)
   69b27:      	xorl	%edi, %edi
   69b29:      	leaq	-0xf(%r14), %rsi
   69b2d:      	callq	0x6e9d0 <f.3>
   69b32:      	subq	$0x8, %rsp
   69b36:      	cmpb	$0x0, 0x9d73(%rip)      # 0x738b0 <g.4>
   69b3d:      	je	0x6e9c5 <f.2+0x17805>
   69b43:      	cmpq	$0x0, 0x9d5d(%rip)      # 0x738a8 <g.3>
   69b4b:      	je	0x6e9c5 <f.2+0x17805>
   69b51:      	movq	%rax, %rbp
   69b54:      	leaq	-0x10(%r14), %rsi
   69b58:      	movq	$0x0, 0x50(%rsp)
   69b61:      	movq	$0x3, 0x38(%rsp)
   69b6a:      	xorl	%edi, %edi
   69b6c:      	callq	0x6e9d0 <f.3>
   69b71:      	subq	$0x8, %rsp
   69b75:      	addq	%rbp, %rax
   69b78:      	leaq	0x28(%rsp), %r8
   69b7d:      	leaq	0x20(%rsp), %rdi
   69b82:      	leaq	0x9c3f(%rip), %r9       # 0x737c8 <native_roots.0>
   69b89:      	movq	0x18(%rsp), %rcx
   69b8e:      	movq	0x10(%rsp), %rdx
   69b93:      	cmpb	$0x0, 0x9d16(%rip)      # 0x738b0 <g.4>
   69b9a:      	je	0x6e9c5 <f.2+0x17805>
   69ba0:      	cmpq	$0x0, 0x9d00(%rip)      # 0x738a8 <g.3>
   69ba8:      	je	0x6e9c5 <f.2+0x17805>
   69bae:      	addq	%rdx, %rax
   69bb1:      	addq	%r13, %rax
   69bb4:      	cmpq	$0xc, %r14
   69bb8:      	je	0x69c95 <f.2+0x12ad5>
   69bbe:      	movl	$0x1, %r13d
   69bc4:      	cmpq	$0xd, %r14
   69bc8:      	je	0x69cae <f.2+0x12aee>
   69bce:      	movq	%r14, %r13
   69bd1:      	subq	$0xe, %r13
   69bd5:      	jbe	0x69cab <f.2+0x12aeb>
   69bdb:      	movq	%rax, 0x10(%rsp)
   69be0:      	movq	%rcx, 0x18(%rsp)
   69be5:      	movq	$0x0, 0x50(%rsp)
   69bee:      	movq	$0x3, 0x38(%rsp)
   69bf7:      	xorl	%edi, %edi
   69bf9:      	movq	%r13, %rsi
   69bfc:      	callq	0x6e9d0 <f.3>
   69c01:      	subq	$0x8, %rsp
   69c05:      	cmpb	$0x0, 0x9ca4(%rip)      # 0x738b0 <g.4>
   69c0c:      	je	0x6e9c5 <f.2+0x17805>
   69c12:      	cmpq	$0x0, 0x9c8e(%rip)      # 0x738a8 <g.3>
   69c1a:      	je	0x6e9c5 <f.2+0x17805>
   69c20:      	movq	%rax, %rbp
   69c23:      	leaq	-0xf(%r14), %rsi
   69c27:      	movq	$0x0, 0x50(%rsp)
   69c30:      	movq	$0x3, 0x38(%rsp)
   69c39:      	xorl	%edi, %edi
   69c3b:      	callq	0x6e9d0 <f.3>
   69c40:      	subq	$0x8, %rsp
   69c44:      	cmpb	$0x0, 0x9c65(%rip)      # 0x738b0 <g.4>
   69c4b:      	je	0x6e9c5 <f.2+0x17805>
   69c51:      	movq	%rax, %rdx
   69c54:      	cmpq	$0x0, 0x9c4c(%rip)      # 0x738a8 <g.3>
   69c5c:      	movq	0x18(%rsp), %rcx
   69c61:      	movq	0x10(%rsp), %rax
   69c66:      	je	0x6e9c5 <f.2+0x17805>
   69c6c:      	addq	%rbp, %rdx
   69c6f:      	cmpq	$0xf, %r14
   69c73:      	jne	0x69cb7 <f.2+0x12af7>
   69c75:      	addq	%rdx, %r13
   69c78:      	movl	$0x1, %ebp
   69c7d:      	xorl	%edx, %edx
   69c7f:      	leaq	0x28(%rsp), %r8
   69c84:      	leaq	0x20(%rsp), %rdi
   69c89:      	leaq	0x9b38(%rip), %r9       # 0x737c8 <native_roots.0>
   69c90:      	jmp	0x69e7f <f.2+0x12cbf>
   69c95:      	leaq	(%r14,%rax), %rbp
   69c99:      	addq	$-0xb, %rbp
   69c9d:      	movl	$0x1, %eax
   69ca2:      	leaq	-0xc(%r14), %r13
   69ca6:      	jmp	0x6b5ba <f.2+0x143fa>
   69cab:      	incq	%r13
   69cae:      	leaq	-0xd(%r14), %rbp
   69cb2:      	jmp	0x69e82 <f.2+0x12cc2>
   69cb7:      	movq	%rdx, 0x58(%rsp)
   69cbc:      	movq	$0x0, 0x50(%rsp)
   69cc5:      	movq	$0x3, 0x38(%rsp)
   69cce:      	xorl	%edi, %edi
   69cd0:      	leaq	-0xf(%r14), %rbp
   69cd4:      	movq	%rbp, %rsi
   69cd7:      	callq	0x6e9d0 <f.3>
   69cdc:      	subq	$0x8, %rsp
   69ce0:      	cmpb	$0x0, 0x9bc9(%rip)      # 0x738b0 <g.4>
   69ce7:      	je	0x6e9c5 <f.2+0x17805>
   69ced:      	movq	%rax, 0x60(%rsp)
   69cf2:      	cmpq	$0x0, 0x9bae(%rip)      # 0x738a8 <g.3>
   69cfa:      	je	0x6e9c5 <f.2+0x17805>
   69d00:      	leaq	-0x10(%r14), %rsi
   69d04:      	movq	$0x0, 0x50(%rsp)
   69d0d:      	movq	$0x3, 0x38(%rsp)
   69d16:      	xorl	%edi, %edi
   69d18:      	callq	0x6e9d0 <f.3>
   69d1d:      	subq	$0x8, %rsp
   69d21:      	cmpb	$0x0, 0x9b88(%rip)      # 0x738b0 <g.4>
   69d28:      	je	0x6e9c5 <f.2+0x17805>
   69d2e:      	cmpq	$0x0, 0x9b72(%rip)      # 0x738a8 <g.3>
   69d36:      	je	0x6e9c5 <f.2+0x17805>
   69d3c:      	movq	%rax, %r13
   69d3f:      	movq	$0x0, 0x50(%rsp)
   69d48:      	movq	$0x3, 0x38(%rsp)
   69d51:      	xorl	%edi, %edi
   69d53:      	movq	%rbp, %rsi
   69d56:      	callq	0x6e9d0 <f.3>
   69d5b:      	subq	$0x8, %rsp
   69d5f:      	cmpb	$0x0, 0x9b4a(%rip)      # 0x738b0 <g.4>
   69d66:      	je	0x6e9c5 <f.2+0x17805>
   69d6c:      	movq	%rax, 0x68(%rsp)
   69d71:      	cmpq	$0x0, 0x9b2f(%rip)      # 0x738a8 <g.3>
   69d79:      	je	0x6e9c5 <f.2+0x17805>
   69d7f:      	movq	$0x0, 0x50(%rsp)
   69d88:      	movq	$0x3, 0x38(%rsp)
   69d91:      	xorl	%edi, %edi
   69d93:      	leaq	-0x10(%r14), %rsi
   69d97:      	callq	0x6e9d0 <f.3>
   69d9c:      	subq	$0x8, %rsp
   69da0:      	cmpb	$0x0, 0x9b09(%rip)      # 0x738b0 <g.4>
   69da7:      	je	0x6e9c5 <f.2+0x17805>
   69dad:      	movq	%rax, %rbp
   69db0:      	cmpq	$0x0, 0x9af0(%rip)      # 0x738a8 <g.3>
   69db8:      	movq	0x18(%rsp), %rcx
   69dbd:      	movq	0x10(%rsp), %rax
   69dc2:      	movq	0x58(%rsp), %rdx
   69dc7:      	je	0x6e9c5 <f.2+0x17805>
   69dcd:      	addq	0x60(%rsp), %r13
   69dd2:      	addq	%rdx, %r13
   69dd5:      	addq	0x68(%rsp), %rbp
   69dda:      	cmpq	$0x11, %r14
   69dde:      	jae	0x69dfa <f.2+0x12c3a>
   69de0:      	leaq	0x28(%rsp), %r8
   69de5:      	leaq	0x20(%rsp), %rdi
   69dea:      	leaq	0x99d7(%rip), %r9       # 0x737c8 <native_roots.0>
   69df1:      	leaq	-0xf(%r14), %rdx
   69df5:      	jmp	0x69e7f <f.2+0x12cbf>
   69dfa:      	movq	$0x0, 0x50(%rsp)
   69e03:      	movq	$0x3, 0x38(%rsp)
   69e0c:      	xorl	%edi, %edi
   69e0e:      	leaq	-0x10(%r14), %rsi
   69e12:      	callq	0x6e9d0 <f.3>
   69e17:      	subq	$0x8, %rsp
   69e1b:      	cmpb	$0x0, 0x9a8e(%rip)      # 0x738b0 <g.4>
   69e22:      	je	0x6e9c5 <f.2+0x17805>
   69e28:      	movq	%rax, 0x58(%rsp)
   69e2d:      	cmpq	$0x0, 0x9a73(%rip)      # 0x738a8 <g.3>
   69e35:      	je	0x6e9c5 <f.2+0x17805>
   69e3b:      	leaq	-0x11(%r14), %rsi
   69e3f:      	movq	$0x0, 0x50(%rsp)
   69e48:      	movq	$0x3, 0x38(%rsp)
   69e51:      	xorl	%edi, %edi
   69e53:      	callq	0x6e9d0 <f.3>
   69e58:      	subq	$0x8, %rsp
   69e5c:      	movq	%rax, %rdx
   69e5f:      	addq	0x58(%rsp), %rdx
   69e64:      	leaq	0x28(%rsp), %r8
   69e69:      	leaq	0x20(%rsp), %rdi
   69e6e:      	leaq	0x9953(%rip), %r9       # 0x737c8 <native_roots.0>
   69e75:      	movq	0x18(%rsp), %rcx
   69e7a:      	movq	0x10(%rsp), %rax
   69e7f:      	addq	%rdx, %rbp
   69e82:      	cmpb	$0x0, 0x9a27(%rip)      # 0x738b0 <g.4>
   69e89:      	je	0x6e9c5 <f.2+0x17805>
   69e8f:      	cmpq	$0x0, 0x9a11(%rip)      # 0x738a8 <g.3>
   69e97:      	je	0x6e9c5 <f.2+0x17805>
   69e9d:      	addq	%r13, %rbp
   69ea0:      	addq	%rax, %rbp
   69ea3:      	cmpq	$0xd, %r14
   69ea7:      	jbe	0x69ec1 <f.2+0x12d01>
   69ea9:      	cmpq	$0xe, %r14
   69ead:      	movq	%rcx, 0x18(%rsp)
   69eb2:      	jne	0x69ece <f.2+0x12d0e>
   69eb4:      	movl	$0x1, %r13d
   69eba:      	xorl	%edx, %edx
   69ebc:      	jmp	0x6a013 <f.2+0x12e53>
   69ec1:      	leaq	-0xc(%r14), %rax
   69ec5:      	leaq	-0xc(%r14), %r13
   69ec9:      	jmp	0x6b5ba <f.2+0x143fa>
   69ece:      	leaq	-0xe(%r14), %rsi
   69ed2:      	movq	$0x0, 0x50(%rsp)
   69edb:      	movq	$0x3, 0x38(%rsp)
   69ee4:      	xorl	%edi, %edi
   69ee6:      	callq	0x6e9d0 <f.3>
   69eeb:      	subq	$0x8, %rsp
   69eef:      	cmpb	$0x0, 0x99ba(%rip)      # 0x738b0 <g.4>
   69ef6:      	je	0x6e9c5 <f.2+0x17805>
   69efc:      	movq	%rax, 0x10(%rsp)
   69f01:      	cmpq	$0x0, 0x999f(%rip)      # 0x738a8 <g.3>
   69f09:      	je	0x6e9c5 <f.2+0x17805>
   69f0f:      	leaq	-0xf(%r14), %rsi
   69f13:      	movq	$0x0, 0x50(%rsp)
   69f1c:      	movq	$0x3, 0x38(%rsp)
   69f25:      	xorl	%edi, %edi
   69f27:      	callq	0x6e9d0 <f.3>
   69f2c:      	subq	$0x8, %rsp
   69f30:      	cmpb	$0x0, 0x9979(%rip)      # 0x738b0 <g.4>
   69f37:      	je	0x6e9c5 <f.2+0x17805>
   69f3d:      	cmpq	$0x0, 0x9963(%rip)      # 0x738a8 <g.3>
   69f45:      	leaq	-0xe(%r14), %rdx
   69f49:      	je	0x6e9c5 <f.2+0x17805>
   69f4f:      	movq	%rax, %r13
   69f52:      	addq	0x10(%rsp), %r13
   69f57:      	cmpq	$0xf, %r14
   69f5b:      	ja	0x69f78 <f.2+0x12db8>
   69f5d:      	leaq	0x28(%rsp), %r8
   69f62:      	leaq	0x20(%rsp), %rdi
   69f67:      	leaq	0x985a(%rip), %r9       # 0x737c8 <native_roots.0>
   69f6e:      	movq	0x18(%rsp), %rcx
   69f73:      	jmp	0x6a013 <f.2+0x12e53>
   69f78:      	movq	$0x0, 0x50(%rsp)
   69f81:      	movq	$0x3, 0x38(%rsp)
   69f8a:      	xorl	%edi, %edi
   69f8c:      	leaq	-0xf(%r14), %rsi
   69f90:      	callq	0x6e9d0 <f.3>
   69f95:      	subq	$0x8, %rsp
   69f99:      	cmpb	$0x0, 0x9910(%rip)      # 0x738b0 <g.4>
   69fa0:      	je	0x6e9c5 <f.2+0x17805>
   69fa6:      	movq	%rax, 0x10(%rsp)
   69fab:      	cmpq	$0x0, 0x98f5(%rip)      # 0x738a8 <g.3>
   69fb3:      	je	0x6e9c5 <f.2+0x17805>
   69fb9:      	leaq	-0x10(%r14), %rsi
   69fbd:      	movq	$0x0, 0x50(%rsp)
   69fc6:      	movq	$0x3, 0x38(%rsp)
   69fcf:      	xorl	%edi, %edi
   69fd1:      	callq	0x6e9d0 <f.3>
   69fd6:      	subq	$0x8, %rsp
   69fda:      	cmpb	$0x0, 0x98cf(%rip)      # 0x738b0 <g.4>
   69fe1:      	je	0x6e9c5 <f.2+0x17805>
   69fe7:      	cmpq	$0x0, 0x98b9(%rip)      # 0x738a8 <g.3>
   69fef:      	leaq	0x28(%rsp), %r8
   69ff4:      	leaq	0x20(%rsp), %rdi
   69ff9:      	leaq	0x97c8(%rip), %r9       # 0x737c8 <native_roots.0>
   6a000:      	movq	0x18(%rsp), %rcx
   6a005:      	je	0x6e9c5 <f.2+0x17805>
   6a00b:      	movq	%rax, %rdx
   6a00e:      	addq	0x10(%rsp), %rdx
   6a013:      	addq	%r13, %rdx
   6a016:      	cmpq	$0xe, %r14
   6a01a:      	je	0x6a02e <f.2+0x12e6e>
   6a01c:      	cmpq	$0xf, %r14
   6a020:      	jne	0x6a045 <f.2+0x12e85>
   6a022:      	movl	$0x1, %esi
   6a027:      	xorl	%eax, %eax
   6a029:      	jmp	0x6a17d <f.2+0x12fbd>
   6a02e:      	leaq	(%r14,%rdx), %rax
   6a032:      	addq	$-0xd, %rax
   6a036:      	movl	$0x1, %r13d
   6a03c:      	leaq	-0xe(%r14), %rsi
   6a040:      	jmp	0x6b5b7 <f.2+0x143f7>
   6a045:      	movq	%rdx, 0x10(%rsp)
   6a04a:      	leaq	-0xf(%r14), %rsi
   6a04e:      	movq	$0x0, 0x50(%rsp)
   6a057:      	movq	$0x3, 0x38(%rsp)
   6a060:      	xorl	%edi, %edi
   6a062:      	callq	0x6e9d0 <f.3>
   6a067:      	subq	$0x8, %rsp
   6a06b:      	cmpb	$0x0, 0x983e(%rip)      # 0x738b0 <g.4>
   6a072:      	je	0x6e9c5 <f.2+0x17805>
   6a078:      	cmpq	$0x0, 0x9828(%rip)      # 0x738a8 <g.3>
   6a080:      	je	0x6e9c5 <f.2+0x17805>
   6a086:      	movq	%rax, %r13
   6a089:      	leaq	-0x10(%r14), %rsi
   6a08d:      	movq	$0x0, 0x50(%rsp)
   6a096:      	movq	$0x3, 0x38(%rsp)
   6a09f:      	xorl	%edi, %edi
   6a0a1:      	callq	0x6e9d0 <f.3>
   6a0a6:      	subq	$0x8, %rsp
   6a0aa:      	cmpb	$0x0, 0x97ff(%rip)      # 0x738b0 <g.4>
   6a0b1:      	je	0x6e9c5 <f.2+0x17805>
   6a0b7:      	movq	%rax, %rsi
   6a0ba:      	cmpq	$0x0, 0x97e6(%rip)      # 0x738a8 <g.3>
   6a0c2:      	leaq	0x20(%rsp), %rdi
   6a0c7:      	leaq	-0xf(%r14), %rax
   6a0cb:      	movq	0x18(%rsp), %rcx
   6a0d0:      	movq	0x10(%rsp), %rdx
   6a0d5:      	je	0x6e9c5 <f.2+0x17805>
   6a0db:      	addq	%r13, %rsi
   6a0de:      	cmpq	$0x11, %r14
   6a0e2:      	jae	0x6a0f5 <f.2+0x12f35>
   6a0e4:      	leaq	0x28(%rsp), %r8
   6a0e9:      	leaq	0x96d8(%rip), %r9       # 0x737c8 <native_roots.0>
   6a0f0:      	jmp	0x6a17d <f.2+0x12fbd>
   6a0f5:      	movq	%rsi, 0x58(%rsp)
   6a0fa:      	movq	$0x0, 0x50(%rsp)
   6a103:      	movq	$0x3, 0x38(%rsp)
   6a10c:      	xorl	%edi, %edi
   6a10e:      	leaq	-0x10(%r14), %rsi
   6a112:      	callq	0x6e9d0 <f.3>
   6a117:      	subq	$0x8, %rsp
   6a11b:      	cmpb	$0x0, 0x978e(%rip)      # 0x738b0 <g.4>
   6a122:      	je	0x6e9c5 <f.2+0x17805>
   6a128:      	cmpq	$0x0, 0x9778(%rip)      # 0x738a8 <g.3>
   6a130:      	je	0x6e9c5 <f.2+0x17805>
   6a136:      	movq	%rax, %r13
   6a139:      	leaq	-0x11(%r14), %rsi
   6a13d:      	movq	$0x0, 0x50(%rsp)
   6a146:      	movq	$0x3, 0x38(%rsp)
   6a14f:      	xorl	%edi, %edi
   6a151:      	callq	0x6e9d0 <f.3>
   6a156:      	subq	$0x8, %rsp
   6a15a:      	addq	%r13, %rax
   6a15d:      	leaq	0x28(%rsp), %r8
   6a162:      	leaq	0x20(%rsp), %rdi
   6a167:      	leaq	0x965a(%rip), %r9       # 0x737c8 <native_roots.0>
   6a16e:      	movq	0x18(%rsp), %rcx
   6a173:      	movq	0x10(%rsp), %rdx
   6a178:      	movq	0x58(%rsp), %rsi
   6a17d:      	cmpb	$0x0, 0x972c(%rip)      # 0x738b0 <g.4>
   6a184:      	je	0x6e9c5 <f.2+0x17805>
   6a18a:      	cmpq	$0x0, 0x9716(%rip)      # 0x738a8 <g.3>
   6a192:      	je	0x6e9c5 <f.2+0x17805>
   6a198:      	addq	%rsi, %rax
   6a19b:      	addq	%rdx, %rax
   6a19e:      	movq	%r14, %r13
   6a1a1:      	subq	$0xf, %r13
   6a1a5:      	jbe	0x6a25c <f.2+0x1309c>
   6a1ab:      	movq	%rax, 0x10(%rsp)
   6a1b0:      	movq	$0x0, 0x50(%rsp)
   6a1b9:      	movq	$0x3, 0x38(%rsp)
   6a1c2:      	xorl	%edi, %edi
   6a1c4:      	movq	%r13, %rsi
   6a1c7:      	callq	0x6e9d0 <f.3>
   6a1cc:      	subq	$0x8, %rsp
   6a1d0:      	cmpb	$0x0, 0x96d9(%rip)      # 0x738b0 <g.4>
   6a1d7:      	je	0x6e9c5 <f.2+0x17805>
   6a1dd:      	movq	%rax, 0x58(%rsp)
   6a1e2:      	cmpq	$0x0, 0x96be(%rip)      # 0x738a8 <g.3>
   6a1ea:      	je	0x6e9c5 <f.2+0x17805>
   6a1f0:      	leaq	-0x10(%r14), %rsi
   6a1f4:      	movq	$0x0, 0x50(%rsp)
   6a1fd:      	movq	$0x3, 0x38(%rsp)
   6a206:      	xorl	%edi, %edi
   6a208:      	callq	0x6e9d0 <f.3>
   6a20d:      	subq	$0x8, %rsp
   6a211:      	cmpb	$0x0, 0x9698(%rip)      # 0x738b0 <g.4>
   6a218:      	je	0x6e9c5 <f.2+0x17805>
   6a21e:      	movq	%rax, %rcx
   6a221:      	cmpq	$0x0, 0x967f(%rip)      # 0x738a8 <g.3>
   6a229:      	movq	0x10(%rsp), %rax
   6a22e:      	je	0x6e9c5 <f.2+0x17805>
   6a234:      	addq	0x58(%rsp), %rcx
   6a239:      	cmpq	$0x10, %r14
   6a23d:      	leaq	-0x10(%r14), %rsi
   6a241:      	jne	0x6a268 <f.2+0x130a8>
   6a243:      	addq	%rcx, %r13
   6a246:      	movl	$0x1, %esi
   6a24b:      	xorl	%edx, %edx
   6a24d:      	leaq	0x28(%rsp), %r8
   6a252:      	leaq	0x20(%rsp), %rdi
   6a257:      	jmp	0x6a395 <f.2+0x131d5>
   6a25c:      	incq	%r13
   6a25f:      	leaq	-0xe(%r14), %rsi
   6a263:      	jmp	0x6b5b7 <f.2+0x143f7>
   6a268:      	movq	%rcx, 0x58(%rsp)
   6a26d:      	movq	$0x0, 0x50(%rsp)
   6a276:      	movq	$0x3, 0x38(%rsp)
   6a27f:      	xorl	%edi, %edi
   6a281:      	callq	0x6e9d0 <f.3>
   6a286:      	subq	$0x8, %rsp
   6a28a:      	cmpb	$0x0, 0x961f(%rip)      # 0x738b0 <g.4>
   6a291:      	je	0x6e9c5 <f.2+0x17805>
   6a297:      	movq	%rax, 0x60(%rsp)
   6a29c:      	cmpq	$0x0, 0x9604(%rip)      # 0x738a8 <g.3>
   6a2a4:      	je	0x6e9c5 <f.2+0x17805>
   6a2aa:      	leaq	-0x11(%r14), %rsi
   6a2ae:      	movq	$0x0, 0x50(%rsp)
   6a2b7:      	movq	$0x3, 0x38(%rsp)
   6a2c0:      	xorl	%edi, %edi
   6a2c2:      	callq	0x6e9d0 <f.3>
   6a2c7:      	subq	$0x8, %rsp
   6a2cb:      	cmpb	$0x0, 0x95de(%rip)      # 0x738b0 <g.4>
   6a2d2:      	je	0x6e9c5 <f.2+0x17805>
   6a2d8:      	cmpq	$0x0, 0x95c8(%rip)      # 0x738a8 <g.3>
   6a2e0:      	leaq	-0x10(%r14), %rsi
   6a2e4:      	je	0x6e9c5 <f.2+0x17805>
   6a2ea:      	movq	%rax, %r13
   6a2ed:      	movq	$0x0, 0x50(%rsp)
   6a2f6:      	movq	$0x3, 0x38(%rsp)
   6a2ff:      	xorl	%edi, %edi
   6a301:      	callq	0x6e9d0 <f.3>
   6a306:      	subq	$0x8, %rsp
   6a30a:      	cmpb	$0x0, 0x959f(%rip)      # 0x738b0 <g.4>
   6a311:      	je	0x6e9c5 <f.2+0x17805>
   6a317:      	movq	%rax, 0x68(%rsp)
   6a31c:      	cmpq	$0x0, 0x9584(%rip)      # 0x738a8 <g.3>
   6a324:      	je	0x6e9c5 <f.2+0x17805>
   6a32a:      	movq	$0x0, 0x50(%rsp)
   6a333:      	movq	$0x3, 0x38(%rsp)
   6a33c:      	xorl	%edi, %edi
   6a33e:      	leaq	-0x11(%r14), %rsi
   6a342:      	callq	0x6e9d0 <f.3>
   6a347:      	subq	$0x8, %rsp
   6a34b:      	cmpb	$0x0, 0x955e(%rip)      # 0x738b0 <g.4>
   6a352:      	je	0x6e9c5 <f.2+0x17805>
   6a358:      	movq	%rax, %rsi
   6a35b:      	cmpq	$0x0, 0x9545(%rip)      # 0x738a8 <g.3>
   6a363:      	leaq	0x20(%rsp), %rdi
   6a368:      	movq	0x10(%rsp), %rax
   6a36d:      	leaq	-0x10(%r14), %rdx
   6a371:      	je	0x6e9c5 <f.2+0x17805>
   6a377:      	addq	0x60(%rsp), %r13
   6a37c:      	addq	0x58(%rsp), %r13
   6a381:      	addq	0x68(%rsp), %rsi
   6a386:      	cmpq	$0x12, %r14
   6a38a:      	jae	0x6b525 <f.2+0x14365>
   6a390:      	leaq	0x28(%rsp), %r8
   6a395:      	leaq	0x942c(%rip), %r9       # 0x737c8 <native_roots.0>
   6a39c:      	movq	0x18(%rsp), %rcx
   6a3a1:      	jmp	0x6b5b4 <f.2+0x143f4>
   6a3a6:      	movq	%rcx, 0x18(%rsp)
   6a3ab:      	movq	$0x0, 0x50(%rsp)
   6a3b4:      	movq	$0x3, 0x38(%rsp)
   6a3bd:      	xorl	%edi, %edi
   6a3bf:      	leaq	-0x10(%r14), %rsi
   6a3c3:      	callq	0x6e9d0 <f.3>
   6a3c8:      	subq	$0x8, %rsp
   6a3cc:      	cmpb	$0x0, 0x94dd(%rip)      # 0x738b0 <g.4>
   6a3d3:      	je	0x6e9c5 <f.2+0x17805>
   6a3d9:      	cmpq	$0x0, 0x94c7(%rip)      # 0x738a8 <g.3>
   6a3e1:      	je	0x6e9c5 <f.2+0x17805>
   6a3e7:      	movq	%rax, %r13
   6a3ea:      	leaq	-0x11(%r14), %rsi
   6a3ee:      	movq	$0x0, 0x50(%rsp)
   6a3f7:      	movq	$0x3, 0x38(%rsp)
   6a400:      	xorl	%edi, %edi
   6a402:      	callq	0x6e9d0 <f.3>
   6a407:      	subq	$0x8, %rsp
   6a40b:      	addq	%r13, %rax
   6a40e:      	movq	%rax, %rsi
   6a411:      	leaq	0x28(%rsp), %r8
   6a416:      	leaq	0x20(%rsp), %rdi
   6a41b:      	leaq	0x93a6(%rip), %r9       # 0x737c8 <native_roots.0>
   6a422:      	movq	0x10(%rsp), %rax
   6a427:      	movq	0x18(%rsp), %rcx
   6a42c:      	movq	0x58(%rsp), %rdx
   6a431:      	addq	%rsi, %rcx
   6a434:      	cmpb	$0x0, 0x9475(%rip)      # 0x738b0 <g.4>
   6a43b:      	je	0x6e9c5 <f.2+0x17805>
   6a441:      	cmpq	$0x0, 0x945f(%rip)      # 0x738a8 <g.3>
   6a449:      	je	0x6e9c5 <f.2+0x17805>
   6a44f:      	addq	%rbp, %rcx
   6a452:      	addq	%rdx, %rcx
   6a455:      	cmpq	$0xb, %r14
   6a459:      	je	0x6a484 <f.2+0x132c4>
   6a45b:      	movl	$0x1, %r13d
   6a461:      	cmpq	$0xc, %r14
   6a465:      	je	0x6a49f <f.2+0x132df>
   6a467:      	cmpq	$0xd, %r14
   6a46b:      	jbe	0x6a49b <f.2+0x132db>
   6a46d:      	cmpq	$0xe, %r14
   6a471:      	movq	%rcx, 0x18(%rsp)
   6a476:      	movq	%rax, 0x10(%rsp)
   6a47b:      	jne	0x6a4a8 <f.2+0x132e8>
   6a47d:      	xorl	%edx, %edx
   6a47f:      	jmp	0x6a5ef <f.2+0x1342f>
   6a484:      	leaq	(%r14,%rcx), %rbp
   6a488:      	addq	$-0xa, %rbp
   6a48c:      	movl	$0x1, %r13d
   6a492:      	leaq	-0xb(%r14), %rcx
   6a496:      	jmp	0x6b69c <f.2+0x144dc>
   6a49b:      	leaq	-0xc(%r14), %r13
   6a49f:      	leaq	-0xc(%r14), %rbp
   6a4a3:      	jmp	0x6aa19 <f.2+0x13859>
   6a4a8:      	leaq	-0xe(%r14), %rsi
   6a4ac:      	movq	$0x0, 0x50(%rsp)
   6a4b5:      	movq	$0x3, 0x38(%rsp)
   6a4be:      	xorl	%edi, %edi
   6a4c0:      	callq	0x6e9d0 <f.3>
   6a4c5:      	subq	$0x8, %rsp
   6a4c9:      	cmpb	$0x0, 0x93e0(%rip)      # 0x738b0 <g.4>
   6a4d0:      	je	0x6e9c5 <f.2+0x17805>
   6a4d6:      	cmpq	$0x0, 0x93ca(%rip)      # 0x738a8 <g.3>
   6a4de:      	je	0x6e9c5 <f.2+0x17805>
   6a4e4:      	movq	%rax, %rbp
   6a4e7:      	leaq	-0xf(%r14), %rsi
   6a4eb:      	movq	$0x0, 0x50(%rsp)
   6a4f4:      	movq	$0x3, 0x38(%rsp)
   6a4fd:      	xorl	%edi, %edi
   6a4ff:      	callq	0x6e9d0 <f.3>
   6a504:      	subq	$0x8, %rsp
   6a508:      	cmpb	$0x0, 0x93a1(%rip)      # 0x738b0 <g.4>
   6a50f:      	je	0x6e9c5 <f.2+0x17805>
   6a515:      	cmpq	$0x0, 0x938b(%rip)      # 0x738a8 <g.3>
   6a51d:      	movq	0x18(%rsp), %rcx
   6a522:      	je	0x6e9c5 <f.2+0x17805>
   6a528:      	movq	%rax, %r13
   6a52b:      	addq	%rbp, %r13
   6a52e:      	cmpq	$0xf, %r14
   6a532:      	ja	0x6a553 <f.2+0x13393>
   6a534:      	leaq	0x28(%rsp), %r8
   6a539:      	leaq	0x20(%rsp), %rdi
   6a53e:      	leaq	0x9283(%rip), %r9       # 0x737c8 <native_roots.0>
   6a545:      	movq	0x10(%rsp), %rax
   6a54a:      	leaq	-0xe(%r14), %rdx
   6a54e:      	jmp	0x6a5ef <f.2+0x1342f>
   6a553:      	movq	$0x0, 0x50(%rsp)
   6a55c:      	movq	$0x3, 0x38(%rsp)
   6a565:      	xorl	%edi, %edi
   6a567:      	leaq	-0xf(%r14), %rsi
   6a56b:      	callq	0x6e9d0 <f.3>
   6a570:      	subq	$0x8, %rsp
   6a574:      	cmpb	$0x0, 0x9335(%rip)      # 0x738b0 <g.4>
   6a57b:      	je	0x6e9c5 <f.2+0x17805>
   6a581:      	cmpq	$0x0, 0x931f(%rip)      # 0x738a8 <g.3>
   6a589:      	je	0x6e9c5 <f.2+0x17805>
   6a58f:      	movq	%rax, %rbp
   6a592:      	leaq	-0x10(%r14), %rsi
   6a596:      	movq	$0x0, 0x50(%rsp)
   6a59f:      	movq	$0x3, 0x38(%rsp)
   6a5a8:      	xorl	%edi, %edi
   6a5aa:      	callq	0x6e9d0 <f.3>
   6a5af:      	subq	$0x8, %rsp
   6a5b3:      	cmpb	$0x0, 0x92f6(%rip)      # 0x738b0 <g.4>
   6a5ba:      	je	0x6e9c5 <f.2+0x17805>
   6a5c0:      	movq	%rax, %rdx
   6a5c3:      	cmpq	$0x0, 0x92dd(%rip)      # 0x738a8 <g.3>
   6a5cb:      	leaq	0x28(%rsp), %r8
   6a5d0:      	leaq	0x20(%rsp), %rdi
   6a5d5:      	leaq	0x91ec(%rip), %r9       # 0x737c8 <native_roots.0>
   6a5dc:      	movq	0x10(%rsp), %rax
   6a5e1:      	movq	0x18(%rsp), %rcx
   6a5e6:      	je	0x6e9c5 <f.2+0x17805>
   6a5ec:      	addq	%rbp, %rdx
   6a5ef:      	addq	%r13, %rdx
   6a5f2:      	cmpq	$0xe, %r14
   6a5f6:      	je	0x6a60b <f.2+0x1344b>
   6a5f8:      	cmpq	$0xf, %r14
   6a5fc:      	jne	0x6a621 <f.2+0x13461>
   6a5fe:      	movl	$0x1, %esi
   6a603:      	xorl	%r13d, %r13d
   6a606:      	jmp	0x6a765 <f.2+0x135a5>
   6a60b:      	leaq	(%r14,%rdx), %r13
   6a60f:      	addq	$-0xd, %r13
   6a613:      	movl	$0x1, %ebp
   6a618:      	leaq	-0xe(%r14), %rsi
   6a61c:      	jmp	0x6aa16 <f.2+0x13856>
   6a621:      	movq	%rdx, 0x58(%rsp)
   6a626:      	leaq	-0xf(%r14), %r13
   6a62a:      	movq	$0x0, 0x50(%rsp)
   6a633:      	movq	$0x3, 0x38(%rsp)
   6a63c:      	xorl	%edi, %edi
   6a63e:      	movq	%r13, %rsi
   6a641:      	callq	0x6e9d0 <f.3>
   6a646:      	subq	$0x8, %rsp
   6a64a:      	cmpb	$0x0, 0x925f(%rip)      # 0x738b0 <g.4>
   6a651:      	je	0x6e9c5 <f.2+0x17805>
   6a657:      	cmpq	$0x0, 0x9249(%rip)      # 0x738a8 <g.3>
   6a65f:      	je	0x6e9c5 <f.2+0x17805>
   6a665:      	movq	%rax, %rbp
   6a668:      	leaq	-0x10(%r14), %rsi
   6a66c:      	movq	$0x0, 0x50(%rsp)
   6a675:      	movq	$0x3, 0x38(%rsp)
   6a67e:      	xorl	%edi, %edi
   6a680:      	callq	0x6e9d0 <f.3>
   6a685:      	subq	$0x8, %rsp
   6a689:      	cmpb	$0x0, 0x9220(%rip)      # 0x738b0 <g.4>
   6a690:      	je	0x6e9c5 <f.2+0x17805>
   6a696:      	movq	%rax, %rsi
   6a699:      	cmpq	$0x0, 0x9207(%rip)      # 0x738a8 <g.3>
   6a6a1:      	leaq	0x28(%rsp), %r8
   6a6a6:      	leaq	0x911b(%rip), %r9       # 0x737c8 <native_roots.0>
   6a6ad:      	movq	0x10(%rsp), %rax
   6a6b2:      	movq	0x18(%rsp), %rcx
   6a6b7:      	je	0x6e9c5 <f.2+0x17805>
   6a6bd:      	addq	%rbp, %rsi
   6a6c0:      	cmpq	$0x11, %r14
   6a6c4:      	jae	0x6a6d5 <f.2+0x13515>
   6a6c6:      	leaq	0x20(%rsp), %rdi
   6a6cb:      	movq	0x58(%rsp), %rdx
   6a6d0:      	jmp	0x6a765 <f.2+0x135a5>
   6a6d5:      	movq	%rsi, 0x60(%rsp)
   6a6da:      	movq	$0x0, 0x50(%rsp)
   6a6e3:      	movq	$0x3, 0x38(%rsp)
   6a6ec:      	xorl	%edi, %edi
   6a6ee:      	leaq	-0x10(%r14), %rsi
   6a6f2:      	callq	0x6e9d0 <f.3>
   6a6f7:      	subq	$0x8, %rsp
   6a6fb:      	cmpb	$0x0, 0x91ae(%rip)      # 0x738b0 <g.4>
   6a702:      	je	0x6e9c5 <f.2+0x17805>
   6a708:      	cmpq	$0x0, 0x9198(%rip)      # 0x738a8 <g.3>
   6a710:      	je	0x6e9c5 <f.2+0x17805>
   6a716:      	movq	%rax, %rbp
   6a719:      	leaq	-0x11(%r14), %rsi
   6a71d:      	movq	$0x0, 0x50(%rsp)
   6a726:      	movq	$0x3, 0x38(%rsp)
   6a72f:      	xorl	%edi, %edi
   6a731:      	callq	0x6e9d0 <f.3>
   6a736:      	subq	$0x8, %rsp
   6a73a:      	movq	%rax, %r13
   6a73d:      	addq	%rbp, %r13
   6a740:      	leaq	0x28(%rsp), %r8
   6a745:      	leaq	0x20(%rsp), %rdi
   6a74a:      	leaq	0x9077(%rip), %r9       # 0x737c8 <native_roots.0>
   6a751:      	movq	0x10(%rsp), %rax
   6a756:      	movq	0x18(%rsp), %rcx
   6a75b:      	movq	0x58(%rsp), %rdx
   6a760:      	movq	0x60(%rsp), %rsi
   6a765:      	cmpb	$0x0, 0x9144(%rip)      # 0x738b0 <g.4>
   6a76c:      	je	0x6e9c5 <f.2+0x17805>
   6a772:      	cmpq	$0x0, 0x912e(%rip)      # 0x738a8 <g.3>
   6a77a:      	je	0x6e9c5 <f.2+0x17805>
   6a780:      	addq	%rsi, %r13
   6a783:      	addq	%rdx, %r13
   6a786:      	movq	%r14, %rbp
   6a789:      	subq	$0xf, %rbp
   6a78d:      	jbe	0x6a83e <f.2+0x1367e>
   6a793:      	movq	$0x0, 0x50(%rsp)
   6a79c:      	movq	$0x3, 0x38(%rsp)
   6a7a5:      	xorl	%edi, %edi
   6a7a7:      	movq	%rbp, %rsi
   6a7aa:      	callq	0x6e9d0 <f.3>
   6a7af:      	subq	$0x8, %rsp
   6a7b3:      	cmpb	$0x0, 0x90f6(%rip)      # 0x738b0 <g.4>
   6a7ba:      	je	0x6e9c5 <f.2+0x17805>
   6a7c0:      	movq	%rax, 0x58(%rsp)
   6a7c5:      	cmpq	$0x0, 0x90db(%rip)      # 0x738a8 <g.3>
   6a7cd:      	je	0x6e9c5 <f.2+0x17805>
   6a7d3:      	leaq	-0x10(%r14), %rsi
   6a7d7:      	movq	$0x0, 0x50(%rsp)
   6a7e0:      	movq	$0x3, 0x38(%rsp)
   6a7e9:      	xorl	%edi, %edi
   6a7eb:      	callq	0x6e9d0 <f.3>
   6a7f0:      	subq	$0x8, %rsp
   6a7f4:      	cmpb	$0x0, 0x90b5(%rip)      # 0x738b0 <g.4>
   6a7fb:      	je	0x6e9c5 <f.2+0x17805>
   6a801:      	cmpq	$0x0, 0x909f(%rip)      # 0x738a8 <g.3>
   6a809:      	leaq	0x28(%rsp), %r8
   6a80e:      	leaq	0x8fb3(%rip), %r9       # 0x737c8 <native_roots.0>
   6a815:      	movq	0x18(%rsp), %rcx
   6a81a:      	je	0x6e9c5 <f.2+0x17805>
   6a820:      	addq	0x58(%rsp), %rax
   6a825:      	cmpq	$0x10, %r14
   6a829:      	leaq	-0x10(%r14), %rsi
   6a82d:      	jne	0x6a84a <f.2+0x1368a>
   6a82f:      	addq	%rax, %rbp
   6a832:      	movl	$0x1, %esi
   6a837:      	xorl	%edx, %edx
   6a839:      	jmp	0x6a975 <f.2+0x137b5>
   6a83e:      	incq	%rbp
   6a841:      	leaq	-0xe(%r14), %rsi
   6a845:      	jmp	0x6aa16 <f.2+0x13856>
   6a84a:      	movq	%rax, 0x58(%rsp)
   6a84f:      	movq	$0x0, 0x50(%rsp)
   6a858:      	movq	$0x3, 0x38(%rsp)
   6a861:      	xorl	%edi, %edi
   6a863:      	callq	0x6e9d0 <f.3>
   6a868:      	subq	$0x8, %rsp
   6a86c:      	cmpb	$0x0, 0x903d(%rip)      # 0x738b0 <g.4>
   6a873:      	je	0x6e9c5 <f.2+0x17805>
   6a879:      	movq	%rax, 0x60(%rsp)
   6a87e:      	cmpq	$0x0, 0x9022(%rip)      # 0x738a8 <g.3>
   6a886:      	je	0x6e9c5 <f.2+0x17805>
   6a88c:      	leaq	-0x11(%r14), %rsi
   6a890:      	movq	$0x0, 0x50(%rsp)
   6a899:      	movq	$0x3, 0x38(%rsp)
   6a8a2:      	xorl	%edi, %edi
   6a8a4:      	callq	0x6e9d0 <f.3>
   6a8a9:      	subq	$0x8, %rsp
   6a8ad:      	cmpb	$0x0, 0x8ffc(%rip)      # 0x738b0 <g.4>
   6a8b4:      	je	0x6e9c5 <f.2+0x17805>
   6a8ba:      	cmpq	$0x0, 0x8fe6(%rip)      # 0x738a8 <g.3>
   6a8c2:      	leaq	-0x10(%r14), %rsi
   6a8c6:      	je	0x6e9c5 <f.2+0x17805>
   6a8cc:      	movq	%rax, %rbp
   6a8cf:      	movq	$0x0, 0x50(%rsp)
   6a8d8:      	movq	$0x3, 0x38(%rsp)
   6a8e1:      	xorl	%edi, %edi
   6a8e3:      	callq	0x6e9d0 <f.3>
   6a8e8:      	subq	$0x8, %rsp
   6a8ec:      	cmpb	$0x0, 0x8fbd(%rip)      # 0x738b0 <g.4>
   6a8f3:      	je	0x6e9c5 <f.2+0x17805>
   6a8f9:      	movq	%rax, 0x68(%rsp)
   6a8fe:      	cmpq	$0x0, 0x8fa2(%rip)      # 0x738a8 <g.3>
   6a906:      	je	0x6e9c5 <f.2+0x17805>
   6a90c:      	movq	$0x0, 0x50(%rsp)
   6a915:      	movq	$0x3, 0x38(%rsp)
   6a91e:      	xorl	%edi, %edi
   6a920:      	leaq	-0x11(%r14), %rsi
   6a924:      	callq	0x6e9d0 <f.3>
   6a929:      	subq	$0x8, %rsp
   6a92d:      	cmpb	$0x0, 0x8f7c(%rip)      # 0x738b0 <g.4>
   6a934:      	je	0x6e9c5 <f.2+0x17805>
   6a93a:      	cmpq	$0x0, 0x8f66(%rip)      # 0x738a8 <g.3>
   6a942:      	leaq	0x28(%rsp), %r8
   6a947:      	leaq	0x8e7a(%rip), %r9       # 0x737c8 <native_roots.0>
   6a94e:      	movq	0x18(%rsp), %rcx
   6a953:      	leaq	-0x10(%r14), %rdx
   6a957:      	je	0x6e9c5 <f.2+0x17805>
   6a95d:      	movq	%rax, %rsi
   6a960:      	addq	0x60(%rsp), %rbp
   6a965:      	addq	0x58(%rsp), %rbp
   6a96a:      	addq	0x68(%rsp), %rsi
   6a96f:      	cmpq	$0x12, %r14
   6a973:      	jae	0x6a984 <f.2+0x137c4>
   6a975:      	leaq	0x20(%rsp), %rdi
   6a97a:      	movq	0x10(%rsp), %rax
   6a97f:      	jmp	0x6aa13 <f.2+0x13853>
   6a984:      	movq	%rsi, 0x58(%rsp)
   6a989:      	movq	$0x0, 0x50(%rsp)
   6a992:      	movq	$0x3, 0x38(%rsp)
   6a99b:      	xorl	%edi, %edi
   6a99d:      	leaq	-0x11(%r14), %rsi
   6a9a1:      	callq	0x6e9d0 <f.3>
   6a9a6:      	subq	$0x8, %rsp
   6a9aa:      	cmpb	$0x0, 0x8eff(%rip)      # 0x738b0 <g.4>
   6a9b1:      	je	0x6e9c5 <f.2+0x17805>
   6a9b7:      	movq	%rax, 0x60(%rsp)
   6a9bc:      	cmpq	$0x0, 0x8ee4(%rip)      # 0x738a8 <g.3>
   6a9c4:      	je	0x6e9c5 <f.2+0x17805>
   6a9ca:      	leaq	-0x12(%r14), %rsi
   6a9ce:      	movq	$0x0, 0x50(%rsp)
   6a9d7:      	movq	$0x3, 0x38(%rsp)
   6a9e0:      	xorl	%edi, %edi
   6a9e2:      	callq	0x6e9d0 <f.3>
   6a9e7:      	subq	$0x8, %rsp
   6a9eb:      	movq	%rax, %rdx
   6a9ee:      	addq	0x60(%rsp), %rdx
   6a9f3:      	leaq	0x28(%rsp), %r8
   6a9f8:      	leaq	0x20(%rsp), %rdi
   6a9fd:      	leaq	0x8dc4(%rip), %r9       # 0x737c8 <native_roots.0>
   6aa04:      	movq	0x10(%rsp), %rax
   6aa09:      	movq	0x18(%rsp), %rcx
   6aa0e:      	movq	0x58(%rsp), %rsi
   6aa13:      	addq	%rdx, %rsi
   6aa16:      	addq	%rsi, %rbp
   6aa19:      	cmpb	$0x0, 0x8e90(%rip)      # 0x738b0 <g.4>
   6aa20:      	je	0x6e9c5 <f.2+0x17805>
   6aa26:      	cmpq	$0x0, 0x8e7a(%rip)      # 0x738a8 <g.3>
   6aa2e:      	je	0x6e9c5 <f.2+0x17805>
   6aa34:      	addq	%r13, %rbp
   6aa37:      	addq	%rcx, %rbp
   6aa3a:      	cmpq	$0xc, %r14
   6aa3e:      	jbe	0x6ab16 <f.2+0x13956>
   6aa44:      	movl	$0x1, %r13d
   6aa4a:      	cmpq	$0xd, %r14
   6aa4e:      	je	0x6ab26 <f.2+0x13966>
   6aa54:      	movq	%r14, %r13
   6aa57:      	subq	$0xe, %r13
   6aa5b:      	jbe	0x6ab23 <f.2+0x13963>
   6aa61:      	movq	%rax, 0x10(%rsp)
   6aa66:      	movq	$0x0, 0x50(%rsp)
   6aa6f:      	movq	$0x3, 0x38(%rsp)
   6aa78:      	xorl	%edi, %edi
   6aa7a:      	movq	%r13, %rsi
   6aa7d:      	callq	0x6e9d0 <f.3>
   6aa82:      	subq	$0x8, %rsp
   6aa86:      	cmpb	$0x0, 0x8e23(%rip)      # 0x738b0 <g.4>
   6aa8d:      	je	0x6e9c5 <f.2+0x17805>
   6aa93:      	movq	%rax, 0x18(%rsp)
   6aa98:      	cmpq	$0x0, 0x8e08(%rip)      # 0x738a8 <g.3>
   6aaa0:      	je	0x6e9c5 <f.2+0x17805>
   6aaa6:      	leaq	-0xf(%r14), %rsi
   6aaaa:      	movq	$0x0, 0x50(%rsp)
   6aab3:      	movq	$0x3, 0x38(%rsp)
   6aabc:      	xorl	%edi, %edi
   6aabe:      	callq	0x6e9d0 <f.3>
   6aac3:      	subq	$0x8, %rsp
   6aac7:      	cmpb	$0x0, 0x8de2(%rip)      # 0x738b0 <g.4>
   6aace:      	je	0x6e9c5 <f.2+0x17805>
   6aad4:      	cmpq	$0x0, 0x8dcc(%rip)      # 0x738a8 <g.3>
   6aadc:      	je	0x6e9c5 <f.2+0x17805>
   6aae2:      	addq	0x18(%rsp), %rax
   6aae7:      	cmpq	$0xf, %r14
   6aaeb:      	leaq	-0xf(%r14), %rsi
   6aaef:      	jne	0x6ab33 <f.2+0x13973>
   6aaf1:      	addq	%rax, %r13
   6aaf4:      	movl	$0x1, %edx
   6aaf9:      	xorl	%ecx, %ecx
   6aafb:      	leaq	0x28(%rsp), %r8
   6ab00:      	leaq	0x20(%rsp), %rdi
   6ab05:      	leaq	0x8cbc(%rip), %r9       # 0x737c8 <native_roots.0>
   6ab0c:      	movq	0x10(%rsp), %rax
   6ab11:      	jmp	0x6acf2 <f.2+0x13b32>
   6ab16:      	leaq	-0xb(%r14), %r13
   6ab1a:      	leaq	-0xb(%r14), %rcx
   6ab1e:      	jmp	0x6b69c <f.2+0x144dc>
   6ab23:      	incq	%r13
   6ab26:      	leaq	(%r14,%r13), %rcx
   6ab2a:      	addq	$-0xd, %rcx
   6ab2e:      	jmp	0x6ad13 <f.2+0x13b53>
   6ab33:      	movq	%rax, 0x18(%rsp)
   6ab38:      	movq	$0x0, 0x50(%rsp)
   6ab41:      	movq	$0x3, 0x38(%rsp)
   6ab4a:      	xorl	%edi, %edi
   6ab4c:      	callq	0x6e9d0 <f.3>
   6ab51:      	subq	$0x8, %rsp
   6ab55:      	cmpb	$0x0, 0x8d54(%rip)      # 0x738b0 <g.4>
   6ab5c:      	je	0x6e9c5 <f.2+0x17805>
   6ab62:      	movq	%rax, 0x58(%rsp)
   6ab67:      	cmpq	$0x0, 0x8d39(%rip)      # 0x738a8 <g.3>
   6ab6f:      	je	0x6e9c5 <f.2+0x17805>
   6ab75:      	leaq	-0x10(%r14), %rsi
   6ab79:      	movq	$0x0, 0x50(%rsp)
   6ab82:      	movq	$0x3, 0x38(%rsp)
   6ab8b:      	xorl	%edi, %edi
   6ab8d:      	callq	0x6e9d0 <f.3>
   6ab92:      	subq	$0x8, %rsp
   6ab96:      	cmpb	$0x0, 0x8d13(%rip)      # 0x738b0 <g.4>
   6ab9d:      	je	0x6e9c5 <f.2+0x17805>
   6aba3:      	cmpq	$0x0, 0x8cfd(%rip)      # 0x738a8 <g.3>
   6abab:      	leaq	-0xf(%r14), %rsi
   6abaf:      	je	0x6e9c5 <f.2+0x17805>
   6abb5:      	movq	%rax, %r13
   6abb8:      	movq	$0x0, 0x50(%rsp)
   6abc1:      	movq	$0x3, 0x38(%rsp)
   6abca:      	xorl	%edi, %edi
   6abcc:      	callq	0x6e9d0 <f.3>
   6abd1:      	subq	$0x8, %rsp
   6abd5:      	cmpb	$0x0, 0x8cd4(%rip)      # 0x738b0 <g.4>
   6abdc:      	je	0x6e9c5 <f.2+0x17805>
   6abe2:      	movq	%rax, 0x60(%rsp)
   6abe7:      	cmpq	$0x0, 0x8cb9(%rip)      # 0x738a8 <g.3>
   6abef:      	je	0x6e9c5 <f.2+0x17805>
   6abf5:      	movq	$0x0, 0x50(%rsp)
   6abfe:      	movq	$0x3, 0x38(%rsp)
   6ac07:      	xorl	%edi, %edi
   6ac09:      	leaq	-0x10(%r14), %rsi
   6ac0d:      	callq	0x6e9d0 <f.3>
   6ac12:      	subq	$0x8, %rsp
   6ac16:      	cmpb	$0x0, 0x8c93(%rip)      # 0x738b0 <g.4>
   6ac1d:      	je	0x6e9c5 <f.2+0x17805>
   6ac23:      	cmpq	$0x0, 0x8c7d(%rip)      # 0x738a8 <g.3>
   6ac2b:      	leaq	0x28(%rsp), %r8
   6ac30:      	leaq	0x20(%rsp), %rdi
   6ac35:      	leaq	0x8b8c(%rip), %r9       # 0x737c8 <native_roots.0>
   6ac3c:      	leaq	-0xf(%r14), %rcx
   6ac40:      	je	0x6e9c5 <f.2+0x17805>
   6ac46:      	movq	%rax, %rdx
   6ac49:      	addq	0x58(%rsp), %r13
   6ac4e:      	addq	0x18(%rsp), %r13
   6ac53:      	addq	0x60(%rsp), %rdx
   6ac58:      	cmpq	$0x11, %r14
   6ac5c:      	jae	0x6ac68 <f.2+0x13aa8>
   6ac5e:      	movq	0x10(%rsp), %rax
   6ac63:      	jmp	0x6acf2 <f.2+0x13b32>
   6ac68:      	movq	%rdx, 0x18(%rsp)
   6ac6d:      	movq	$0x0, 0x50(%rsp)
   6ac76:      	movq	$0x3, 0x38(%rsp)
   6ac7f:      	xorl	%edi, %edi
   6ac81:      	leaq	-0x10(%r14), %rsi
   6ac85:      	callq	0x6e9d0 <f.3>
   6ac8a:      	subq	$0x8, %rsp
   6ac8e:      	cmpb	$0x0, 0x8c1b(%rip)      # 0x738b0 <g.4>
   6ac95:      	je	0x6e9c5 <f.2+0x17805>
   6ac9b:      	movq	%rax, 0x58(%rsp)
   6aca0:      	cmpq	$0x0, 0x8c00(%rip)      # 0x738a8 <g.3>
   6aca8:      	je	0x6e9c5 <f.2+0x17805>
   6acae:      	leaq	-0x11(%r14), %rsi
   6acb2:      	movq	$0x0, 0x50(%rsp)
   6acbb:      	movq	$0x3, 0x38(%rsp)
   6acc4:      	xorl	%edi, %edi
   6acc6:      	callq	0x6e9d0 <f.3>
   6accb:      	subq	$0x8, %rsp
   6accf:      	movq	%rax, %rcx
   6acd2:      	addq	0x58(%rsp), %rcx
   6acd7:      	leaq	0x28(%rsp), %r8
   6acdc:      	leaq	0x20(%rsp), %rdi
   6ace1:      	leaq	0x8ae0(%rip), %r9       # 0x737c8 <native_roots.0>
   6ace8:      	movq	0x10(%rsp), %rax
   6aced:      	movq	0x18(%rsp), %rdx
   6acf2:      	cmpb	$0x0, 0x8bb7(%rip)      # 0x738b0 <g.4>
   6acf9:      	je	0x6e9c5 <f.2+0x17805>
   6acff:      	cmpq	$0x0, 0x8ba1(%rip)      # 0x738a8 <g.3>
   6ad07:      	je	0x6e9c5 <f.2+0x17805>
   6ad0d:      	addq	%rdx, %rcx
   6ad10:      	addq	%r13, %rcx
   6ad13:      	cmpq	$0xd, %r14
   6ad17:      	je	0x6adf2 <f.2+0x13c32>
   6ad1d:      	movl	$0x1, %r10d
   6ad23:      	cmpq	$0xe, %r14
   6ad27:      	je	0x6ae0b <f.2+0x13c4b>
   6ad2d:      	movq	%r14, %r10
   6ad30:      	subq	$0xf, %r10
   6ad34:      	jbe	0x6ae08 <f.2+0x13c48>
   6ad3a:      	movq	%rcx, 0x58(%rsp)
   6ad3f:      	movq	%rax, 0x10(%rsp)
   6ad44:      	movq	$0x0, 0x50(%rsp)
   6ad4d:      	movq	$0x3, 0x38(%rsp)
   6ad56:      	xorl	%edi, %edi
   6ad58:      	movq	%r10, 0x18(%rsp)
   6ad5d:      	movq	%r10, %rsi
   6ad60:      	callq	0x6e9d0 <f.3>
   6ad65:      	subq	$0x8, %rsp
   6ad69:      	cmpb	$0x0, 0x8b40(%rip)      # 0x738b0 <g.4>
   6ad70:      	je	0x6e9c5 <f.2+0x17805>
   6ad76:      	cmpq	$0x0, 0x8b2a(%rip)      # 0x738a8 <g.3>
   6ad7e:      	je	0x6e9c5 <f.2+0x17805>
   6ad84:      	movq	%rax, %r13
   6ad87:      	leaq	-0x10(%r14), %rsi
   6ad8b:      	movq	$0x0, 0x50(%rsp)
   6ad94:      	movq	$0x3, 0x38(%rsp)
   6ad9d:      	xorl	%edi, %edi
   6ad9f:      	callq	0x6e9d0 <f.3>
   6ada4:      	subq	$0x8, %rsp
   6ada8:      	cmpb	$0x0, 0x8b01(%rip)      # 0x738b0 <g.4>
   6adaf:      	je	0x6e9c5 <f.2+0x17805>
   6adb5:      	movq	%rax, %rdx
   6adb8:      	cmpq	$0x0, 0x8ae8(%rip)      # 0x738a8 <g.3>
   6adc0:      	movq	0x10(%rsp), %rax
   6adc5:      	movq	0x58(%rsp), %rcx
   6adca:      	movq	0x18(%rsp), %r10
   6adcf:      	je	0x6e9c5 <f.2+0x17805>
   6add5:      	addq	%r13, %rdx
   6add8:      	cmpq	$0x10, %r14
   6addc:      	leaq	-0x10(%r14), %rsi
   6ade0:      	jne	0x6ae14 <f.2+0x13c54>
   6ade2:      	addq	%rdx, %r10
   6ade5:      	movl	$0x1, %r13d
   6adeb:      	xorl	%edx, %edx
   6aded:      	jmp	0x6af41 <f.2+0x13d81>
   6adf2:      	leaq	(%r14,%rcx), %r13
   6adf6:      	addq	$-0xc, %r13
   6adfa:      	movl	$0x1, %ecx
   6adff:      	leaq	-0xd(%r14), %r10
   6ae03:      	jmp	0x6b699 <f.2+0x144d9>
   6ae08:      	incq	%r10
   6ae0b:      	leaq	-0xe(%r14), %r13
   6ae0f:      	jmp	0x6afe9 <f.2+0x13e29>
   6ae14:      	movq	%rdx, 0x60(%rsp)
   6ae19:      	movq	$0x0, 0x50(%rsp)
   6ae22:      	movq	$0x3, 0x38(%rsp)
   6ae2b:      	xorl	%edi, %edi
   6ae2d:      	callq	0x6e9d0 <f.3>
   6ae32:      	subq	$0x8, %rsp
   6ae36:      	cmpb	$0x0, 0x8a73(%rip)      # 0x738b0 <g.4>
   6ae3d:      	je	0x6e9c5 <f.2+0x17805>
   6ae43:      	movq	%rax, 0x68(%rsp)
   6ae48:      	cmpq	$0x0, 0x8a58(%rip)      # 0x738a8 <g.3>
   6ae50:      	je	0x6e9c5 <f.2+0x17805>
   6ae56:      	leaq	-0x11(%r14), %r13
   6ae5a:      	movq	$0x0, 0x50(%rsp)
   6ae63:      	movq	$0x3, 0x38(%rsp)
   6ae6c:      	xorl	%edi, %edi
   6ae6e:      	movq	%r13, %rsi
   6ae71:      	callq	0x6e9d0 <f.3>
   6ae76:      	subq	$0x8, %rsp
   6ae7a:      	cmpb	$0x0, 0x8a2f(%rip)      # 0x738b0 <g.4>
   6ae81:      	je	0x6e9c5 <f.2+0x17805>
   6ae87:      	movq	%rax, 0x18(%rsp)
   6ae8c:      	cmpq	$0x0, 0x8a14(%rip)      # 0x738a8 <g.3>
   6ae94:      	leaq	-0x10(%r14), %rsi
   6ae98:      	je	0x6e9c5 <f.2+0x17805>
   6ae9e:      	movq	$0x0, 0x50(%rsp)
   6aea7:      	movq	$0x3, 0x38(%rsp)
   6aeb0:      	xorl	%edi, %edi
   6aeb2:      	callq	0x6e9d0 <f.3>
   6aeb7:      	subq	$0x8, %rsp
   6aebb:      	cmpb	$0x0, 0x89ee(%rip)      # 0x738b0 <g.4>
   6aec2:      	je	0x6e9c5 <f.2+0x17805>
   6aec8:      	movq	%rax, 0x70(%rsp)
   6aecd:      	cmpq	$0x0, 0x89d3(%rip)      # 0x738a8 <g.3>
   6aed5:      	je	0x6e9c5 <f.2+0x17805>
   6aedb:      	movq	$0x0, 0x50(%rsp)
   6aee4:      	movq	$0x3, 0x38(%rsp)
   6aeed:      	xorl	%edi, %edi
   6aeef:      	movq	%r13, %rsi
   6aef2:      	callq	0x6e9d0 <f.3>
   6aef7:      	subq	$0x8, %rsp
   6aefb:      	cmpb	$0x0, 0x89ae(%rip)      # 0x738b0 <g.4>
   6af02:      	je	0x6e9c5 <f.2+0x17805>
   6af08:      	movq	%rax, %r13
   6af0b:      	cmpq	$0x0, 0x8995(%rip)      # 0x738a8 <g.3>
   6af13:      	movq	0x10(%rsp), %rax
   6af18:      	movq	0x58(%rsp), %rcx
   6af1d:      	movq	0x18(%rsp), %r10
   6af22:      	leaq	-0x10(%r14), %rdx
   6af26:      	je	0x6e9c5 <f.2+0x17805>
   6af2c:      	addq	0x68(%rsp), %r10
   6af31:      	addq	0x60(%rsp), %r10
   6af36:      	addq	0x70(%rsp), %r13
   6af3b:      	cmpq	$0x12, %r14
   6af3f:      	jae	0x6af57 <f.2+0x13d97>
   6af41:      	leaq	0x28(%rsp), %r8
   6af46:      	leaq	0x20(%rsp), %rdi
   6af4b:      	leaq	0x8876(%rip), %r9       # 0x737c8 <native_roots.0>
   6af52:      	jmp	0x6afe6 <f.2+0x13e26>
   6af57:      	movq	%r10, 0x18(%rsp)
   6af5c:      	movq	$0x0, 0x50(%rsp)
   6af65:      	movq	$0x3, 0x38(%rsp)
   6af6e:      	xorl	%edi, %edi
   6af70:      	leaq	-0x11(%r14), %rsi
   6af74:      	callq	0x6e9d0 <f.3>
   6af79:      	subq	$0x8, %rsp
   6af7d:      	cmpb	$0x0, 0x892c(%rip)      # 0x738b0 <g.4>
   6af84:      	je	0x6e9c5 <f.2+0x17805>
   6af8a:      	movq	%rax, 0x60(%rsp)
   6af8f:      	cmpq	$0x0, 0x8911(%rip)      # 0x738a8 <g.3>
   6af97:      	je	0x6e9c5 <f.2+0x17805>
   6af9d:      	leaq	-0x12(%r14), %rsi
   6afa1:      	movq	$0x0, 0x50(%rsp)
   6afaa:      	movq	$0x3, 0x38(%rsp)
   6afb3:      	xorl	%edi, %edi
   6afb5:      	callq	0x6e9d0 <f.3>
   6afba:      	subq	$0x8, %rsp
   6afbe:      	movq	%rax, %rdx
   6afc1:      	addq	0x60(%rsp), %rdx
   6afc6:      	leaq	0x28(%rsp), %r8
   6afcb:      	leaq	0x20(%rsp), %rdi
   6afd0:      	leaq	0x87f1(%rip), %r9       # 0x737c8 <native_roots.0>
   6afd7:      	movq	0x10(%rsp), %rax
   6afdc:      	movq	0x58(%rsp), %rcx
   6afe1:      	movq	0x18(%rsp), %r10
   6afe6:      	addq	%rdx, %r13
   6afe9:      	cmpb	$0x0, 0x88c0(%rip)      # 0x738b0 <g.4>
   6aff0:      	je	0x6e9c5 <f.2+0x17805>
   6aff6:      	cmpq	$0x0, 0x88aa(%rip)      # 0x738a8 <g.3>
   6affe:      	je	0x6e9c5 <f.2+0x17805>
   6b004:      	addq	%r10, %r13
   6b007:      	addq	%rcx, %r13
   6b00a:      	cmpq	$0xe, %r14
   6b00e:      	jbe	0x6b027 <f.2+0x13e67>
   6b010:      	cmpq	$0xf, %r14
   6b014:      	movq	%rax, 0x10(%rsp)
   6b019:      	jne	0x6b034 <f.2+0x13e74>
   6b01b:      	movl	$0x1, %ecx
   6b020:      	xorl	%edx, %edx
   6b022:      	jmp	0x6b183 <f.2+0x13fc3>
   6b027:      	leaq	-0xd(%r14), %rcx
   6b02b:      	leaq	-0xd(%r14), %r10
   6b02f:      	jmp	0x6b699 <f.2+0x144d9>
   6b034:      	leaq	-0xf(%r14), %rsi
   6b038:      	movq	$0x0, 0x50(%rsp)
   6b041:      	movq	$0x3, 0x38(%rsp)
   6b04a:      	xorl	%edi, %edi
   6b04c:      	callq	0x6e9d0 <f.3>
   6b051:      	subq	$0x8, %rsp
   6b055:      	cmpb	$0x0, 0x8854(%rip)      # 0x738b0 <g.4>
   6b05c:      	je	0x6e9c5 <f.2+0x17805>
   6b062:      	movq	%rax, 0x18(%rsp)
   6b067:      	cmpq	$0x0, 0x8839(%rip)      # 0x738a8 <g.3>
   6b06f:      	je	0x6e9c5 <f.2+0x17805>
   6b075:      	leaq	-0x10(%r14), %rsi
   6b079:      	movq	$0x0, 0x50(%rsp)
   6b082:      	movq	$0x3, 0x38(%rsp)
   6b08b:      	xorl	%edi, %edi
   6b08d:      	callq	0x6e9d0 <f.3>
   6b092:      	subq	$0x8, %rsp
   6b096:      	cmpb	$0x0, 0x8813(%rip)      # 0x738b0 <g.4>
   6b09d:      	je	0x6e9c5 <f.2+0x17805>
   6b0a3:      	cmpq	$0x0, 0x87fd(%rip)      # 0x738a8 <g.3>
   6b0ab:      	leaq	-0xf(%r14), %rdx
   6b0af:      	je	0x6e9c5 <f.2+0x17805>
   6b0b5:      	movq	%rax, %rcx
   6b0b8:      	addq	0x18(%rsp), %rcx
   6b0bd:      	cmpq	$0x10, %r14
   6b0c1:      	ja	0x6b0de <f.2+0x13f1e>
   6b0c3:      	leaq	0x28(%rsp), %r8
   6b0c8:      	leaq	0x20(%rsp), %rdi
   6b0cd:      	leaq	0x86f4(%rip), %r9       # 0x737c8 <native_roots.0>
   6b0d4:      	movq	0x10(%rsp), %rax
   6b0d9:      	jmp	0x6b183 <f.2+0x13fc3>
   6b0de:      	movq	%rcx, 0x18(%rsp)
   6b0e3:      	movq	$0x0, 0x50(%rsp)
   6b0ec:      	movq	$0x3, 0x38(%rsp)
   6b0f5:      	xorl	%edi, %edi
   6b0f7:      	leaq	-0x10(%r14), %rsi
   6b0fb:      	callq	0x6e9d0 <f.3>
   6b100:      	subq	$0x8, %rsp
   6b104:      	cmpb	$0x0, 0x87a5(%rip)      # 0x738b0 <g.4>
   6b10b:      	je	0x6e9c5 <f.2+0x17805>
   6b111:      	movq	%rax, 0x58(%rsp)
   6b116:      	cmpq	$0x0, 0x878a(%rip)      # 0x738a8 <g.3>
   6b11e:      	je	0x6e9c5 <f.2+0x17805>
   6b124:      	leaq	-0x11(%r14), %rsi
   6b128:      	movq	$0x0, 0x50(%rsp)
   6b131:      	movq	$0x3, 0x38(%rsp)
   6b13a:      	xorl	%edi, %edi
   6b13c:      	callq	0x6e9d0 <f.3>
   6b141:      	subq	$0x8, %rsp
   6b145:      	cmpb	$0x0, 0x8764(%rip)      # 0x738b0 <g.4>
   6b14c:      	je	0x6e9c5 <f.2+0x17805>
   6b152:      	movq	%rax, %rdx
   6b155:      	cmpq	$0x0, 0x874b(%rip)      # 0x738a8 <g.3>
   6b15d:      	leaq	0x28(%rsp), %r8
   6b162:      	leaq	0x20(%rsp), %rdi
   6b167:      	leaq	0x865a(%rip), %r9       # 0x737c8 <native_roots.0>
   6b16e:      	movq	0x10(%rsp), %rax
   6b173:      	movq	0x18(%rsp), %rcx
   6b178:      	je	0x6e9c5 <f.2+0x17805>
   6b17e:      	addq	0x58(%rsp), %rdx
   6b183:      	addq	%rcx, %rdx
   6b186:      	cmpq	$0xf, %r14
   6b18a:      	je	0x6b19e <f.2+0x13fde>
   6b18c:      	cmpq	$0x10, %r14
   6b190:      	jne	0x6b1b5 <f.2+0x13ff5>
   6b192:      	movl	$0x1, %esi
   6b197:      	xorl	%ecx, %ecx
   6b199:      	jmp	0x6b2f8 <f.2+0x14138>
   6b19e:      	leaq	(%r14,%rdx), %rcx
   6b1a2:      	addq	$-0xe, %rcx
   6b1a6:      	movl	$0x1, %r10d
   6b1ac:      	leaq	-0xf(%r14), %rsi
   6b1b0:      	jmp	0x6b696 <f.2+0x144d6>
   6b1b5:      	movq	%rdx, 0x18(%rsp)
   6b1ba:      	leaq	-0x10(%r14), %rsi
   6b1be:      	movq	$0x0, 0x50(%rsp)
   6b1c7:      	movq	$0x3, 0x38(%rsp)
   6b1d0:      	xorl	%edi, %edi
   6b1d2:      	callq	0x6e9d0 <f.3>
   6b1d7:      	subq	$0x8, %rsp
   6b1db:      	cmpb	$0x0, 0x86ce(%rip)      # 0x738b0 <g.4>
   6b1e2:      	je	0x6e9c5 <f.2+0x17805>
   6b1e8:      	movq	%rax, 0x58(%rsp)
   6b1ed:      	cmpq	$0x0, 0x86b3(%rip)      # 0x738a8 <g.3>
   6b1f5:      	je	0x6e9c5 <f.2+0x17805>
   6b1fb:      	leaq	-0x11(%r14), %rsi
   6b1ff:      	movq	$0x0, 0x50(%rsp)
   6b208:      	movq	$0x3, 0x38(%rsp)
   6b211:      	xorl	%edi, %edi
   6b213:      	callq	0x6e9d0 <f.3>
   6b218:      	subq	$0x8, %rsp
   6b21c:      	cmpb	$0x0, 0x868d(%rip)      # 0x738b0 <g.4>
   6b223:      	je	0x6e9c5 <f.2+0x17805>
   6b229:      	cmpq	$0x0, 0x8677(%rip)      # 0x738a8 <g.3>
   6b231:      	leaq	0x28(%rsp), %r8
   6b236:      	leaq	0x858b(%rip), %r9       # 0x737c8 <native_roots.0>
   6b23d:      	leaq	-0x10(%r14), %rcx
   6b241:      	movq	0x18(%rsp), %rdx
   6b246:      	je	0x6e9c5 <f.2+0x17805>
   6b24c:      	movq	%rax, %rsi
   6b24f:      	addq	0x58(%rsp), %rsi
   6b254:      	cmpq	$0x12, %r14
   6b258:      	jae	0x6b269 <f.2+0x140a9>
   6b25a:      	leaq	0x20(%rsp), %rdi
   6b25f:      	movq	0x10(%rsp), %rax
   6b264:      	jmp	0x6b2f8 <f.2+0x14138>
   6b269:      	movq	%rsi, 0x58(%rsp)
   6b26e:      	movq	$0x0, 0x50(%rsp)
   6b277:      	movq	$0x3, 0x38(%rsp)
   6b280:      	xorl	%edi, %edi
   6b282:      	leaq	-0x11(%r14), %rsi
   6b286:      	callq	0x6e9d0 <f.3>
   6b28b:      	subq	$0x8, %rsp
   6b28f:      	cmpb	$0x0, 0x861a(%rip)      # 0x738b0 <g.4>
   6b296:      	je	0x6e9c5 <f.2+0x17805>
   6b29c:      	movq	%rax, 0x60(%rsp)
   6b2a1:      	cmpq	$0x0, 0x85ff(%rip)      # 0x738a8 <g.3>
   6b2a9:      	je	0x6e9c5 <f.2+0x17805>
   6b2af:      	leaq	-0x12(%r14), %rsi
   6b2b3:      	movq	$0x0, 0x50(%rsp)
   6b2bc:      	movq	$0x3, 0x38(%rsp)
   6b2c5:      	xorl	%edi, %edi
   6b2c7:      	callq	0x6e9d0 <f.3>
   6b2cc:      	subq	$0x8, %rsp
   6b2d0:      	movq	%rax, %rcx
   6b2d3:      	addq	0x60(%rsp), %rcx
   6b2d8:      	leaq	0x28(%rsp), %r8
   6b2dd:      	leaq	0x20(%rsp), %rdi
   6b2e2:      	leaq	0x84df(%rip), %r9       # 0x737c8 <native_roots.0>
   6b2e9:      	movq	0x10(%rsp), %rax
   6b2ee:      	movq	0x18(%rsp), %rdx
   6b2f3:      	movq	0x58(%rsp), %rsi
   6b2f8:      	cmpb	$0x0, 0x85b1(%rip)      # 0x738b0 <g.4>
   6b2ff:      	je	0x6e9c5 <f.2+0x17805>
   6b305:      	cmpq	$0x0, 0x859b(%rip)      # 0x738a8 <g.3>
   6b30d:      	je	0x6e9c5 <f.2+0x17805>
   6b313:      	addq	%rsi, %rcx
   6b316:      	addq	%rdx, %rcx
   6b319:      	movq	%r14, %r10
   6b31c:      	subq	$0x10, %r10
   6b320:      	jbe	0x6b3d4 <f.2+0x14214>
   6b326:      	movq	%rcx, 0x58(%rsp)
   6b32b:      	movq	$0x0, 0x50(%rsp)
   6b334:      	movq	$0x3, 0x38(%rsp)
   6b33d:      	xorl	%edi, %edi
   6b33f:      	movq	%r10, 0x18(%rsp)
   6b344:      	movq	%r10, %rsi
   6b347:      	callq	0x6e9d0 <f.3>
   6b34c:      	subq	$0x8, %rsp
   6b350:      	cmpb	$0x0, 0x8559(%rip)      # 0x738b0 <g.4>
   6b357:      	je	0x6e9c5 <f.2+0x17805>
   6b35d:      	movq	%rax, 0x60(%rsp)
   6b362:      	cmpq	$0x0, 0x853e(%rip)      # 0x738a8 <g.3>
   6b36a:      	je	0x6e9c5 <f.2+0x17805>
   6b370:      	leaq	-0x11(%r14), %rsi
   6b374:      	movq	$0x0, 0x50(%rsp)
   6b37d:      	movq	$0x3, 0x38(%rsp)
   6b386:      	xorl	%edi, %edi
   6b388:      	callq	0x6e9d0 <f.3>
   6b38d:      	subq	$0x8, %rsp
   6b391:      	cmpb	$0x0, 0x8518(%rip)      # 0x738b0 <g.4>
   6b398:      	je	0x6e9c5 <f.2+0x17805>
   6b39e:      	cmpq	$0x0, 0x8502(%rip)      # 0x738a8 <g.3>
   6b3a6:      	movq	0x58(%rsp), %rcx
   6b3ab:      	movq	0x18(%rsp), %r10
   6b3b0:      	je	0x6e9c5 <f.2+0x17805>
   6b3b6:      	addq	0x60(%rsp), %rax
   6b3bb:      	cmpq	$0x11, %r14
   6b3bf:      	leaq	-0x11(%r14), %rsi
   6b3c3:      	jne	0x6b3e0 <f.2+0x14220>
   6b3c5:      	addq	%rax, %r10
   6b3c8:      	movl	$0x1, %esi
   6b3cd:      	xorl	%edx, %edx
   6b3cf:      	jmp	0x6b50a <f.2+0x1434a>
   6b3d4:      	incq	%r10
   6b3d7:      	leaq	-0xf(%r14), %rsi
   6b3db:      	jmp	0x6b696 <f.2+0x144d6>
   6b3e0:      	movq	%rax, 0x60(%rsp)
   6b3e5:      	movq	$0x0, 0x50(%rsp)
   6b3ee:      	movq	$0x3, 0x38(%rsp)
   6b3f7:      	xorl	%edi, %edi
   6b3f9:      	callq	0x6e9d0 <f.3>
   6b3fe:      	subq	$0x8, %rsp
   6b402:      	cmpb	$0x0, 0x84a7(%rip)      # 0x738b0 <g.4>
   6b409:      	je	0x6e9c5 <f.2+0x17805>
   6b40f:      	movq	%rax, 0x68(%rsp)
   6b414:      	cmpq	$0x0, 0x848c(%rip)      # 0x738a8 <g.3>
   6b41c:      	je	0x6e9c5 <f.2+0x17805>
   6b422:      	leaq	-0x12(%r14), %rsi
   6b426:      	movq	$0x0, 0x50(%rsp)
   6b42f:      	movq	$0x3, 0x38(%rsp)
   6b438:      	xorl	%edi, %edi
   6b43a:      	callq	0x6e9d0 <f.3>
   6b43f:      	subq	$0x8, %rsp
   6b443:      	cmpb	$0x0, 0x8466(%rip)      # 0x738b0 <g.4>
   6b44a:      	je	0x6e9c5 <f.2+0x17805>
   6b450:      	movq	%rax, 0x18(%rsp)
   6b455:      	cmpq	$0x0, 0x844b(%rip)      # 0x738a8 <g.3>
   6b45d:      	leaq	-0x11(%r14), %rsi
   6b461:      	je	0x6e9c5 <f.2+0x17805>
   6b467:      	movq	$0x0, 0x50(%rsp)
   6b470:      	movq	$0x3, 0x38(%rsp)
   6b479:      	xorl	%edi, %edi
   6b47b:      	callq	0x6e9d0 <f.3>
   6b480:      	subq	$0x8, %rsp
   6b484:      	cmpb	$0x0, 0x8425(%rip)      # 0x738b0 <g.4>
   6b48b:      	je	0x6e9c5 <f.2+0x17805>
   6b491:      	movq	%rax, 0x70(%rsp)
   6b496:      	cmpq	$0x0, 0x840a(%rip)      # 0x738a8 <g.3>
   6b49e:      	je	0x6e9c5 <f.2+0x17805>
   6b4a4:      	movq	$0x0, 0x50(%rsp)
   6b4ad:      	movq	$0x3, 0x38(%rsp)
   6b4b6:      	xorl	%edi, %edi
   6b4b8:      	leaq	-0x12(%r14), %rsi
   6b4bc:      	callq	0x6e9d0 <f.3>
   6b4c1:      	subq	$0x8, %rsp
   6b4c5:      	cmpb	$0x0, 0x83e4(%rip)      # 0x738b0 <g.4>
   6b4cc:      	je	0x6e9c5 <f.2+0x17805>
   6b4d2:      	cmpq	$0x0, 0x83ce(%rip)      # 0x738a8 <g.3>
   6b4da:      	movq	0x58(%rsp), %rcx
   6b4df:      	movq	0x18(%rsp), %r10
   6b4e4:      	leaq	-0x11(%r14), %rdx
   6b4e8:      	je	0x6e9c5 <f.2+0x17805>
   6b4ee:      	movq	%rax, %rsi
   6b4f1:      	addq	0x68(%rsp), %r10
   6b4f6:      	addq	0x60(%rsp), %r10
   6b4fb:      	addq	0x70(%rsp), %rsi
   6b500:      	cmpq	$0x13, %r14
   6b504:      	jae	0x6b5fa <f.2+0x1443a>
   6b50a:      	leaq	0x28(%rsp), %r8
   6b50f:      	leaq	0x20(%rsp), %rdi
   6b514:      	leaq	0x82ad(%rip), %r9       # 0x737c8 <native_roots.0>
   6b51b:      	movq	0x10(%rsp), %rax
   6b520:      	jmp	0x6b693 <f.2+0x144d3>
   6b525:      	movq	%rsi, 0x58(%rsp)
   6b52a:      	movq	$0x0, 0x50(%rsp)
   6b533:      	movq	$0x3, 0x38(%rsp)
   6b53c:      	xorl	%edi, %edi
   6b53e:      	leaq	-0x11(%r14), %rsi
   6b542:      	callq	0x6e9d0 <f.3>
   6b547:      	subq	$0x8, %rsp
   6b54b:      	cmpb	$0x0, 0x835e(%rip)      # 0x738b0 <g.4>
   6b552:      	je	0x6e9c5 <f.2+0x17805>
   6b558:      	movq	%rax, 0x60(%rsp)
   6b55d:      	cmpq	$0x0, 0x8343(%rip)      # 0x738a8 <g.3>
   6b565:      	je	0x6e9c5 <f.2+0x17805>
   6b56b:      	leaq	-0x12(%r14), %rsi
   6b56f:      	movq	$0x0, 0x50(%rsp)
   6b578:      	movq	$0x3, 0x38(%rsp)
   6b581:      	xorl	%edi, %edi
   6b583:      	callq	0x6e9d0 <f.3>
   6b588:      	subq	$0x8, %rsp
   6b58c:      	movq	%rax, %rdx
   6b58f:      	addq	0x60(%rsp), %rdx
   6b594:      	leaq	0x28(%rsp), %r8
   6b599:      	leaq	0x20(%rsp), %rdi
   6b59e:      	leaq	0x8223(%rip), %r9       # 0x737c8 <native_roots.0>
   6b5a5:      	movq	0x10(%rsp), %rax
   6b5aa:      	movq	0x18(%rsp), %rcx
   6b5af:      	movq	0x58(%rsp), %rsi
   6b5b4:      	addq	%rdx, %rsi
   6b5b7:      	addq	%rsi, %r13
   6b5ba:      	addq	%r13, %rax
   6b5bd:      	cmpb	$0x0, 0x82ec(%rip)      # 0x738b0 <g.4>
   6b5c4:      	je	0x6e9c5 <f.2+0x17805>
   6b5ca:      	cmpq	$0x0, 0x82d6(%rip)      # 0x738a8 <g.3>
   6b5d2:      	je	0x6e9c5 <f.2+0x17805>
   6b5d8:      	addq	%rbp, %rax
   6b5db:      	addq	%rcx, %rax
   6b5de:      	cmpq	$0x8, %r14
   6b5e2:      	jne	0x68870 <f.2+0x116b0>
   6b5e8:      	leaq	(%r14,%rax), %r13
   6b5ec:      	addq	$-0x7, %r13
   6b5f0:      	movl	$0x1, %ebp
   6b5f5:      	jmp	0x6b7a6 <f.2+0x145e6>
   6b5fa:      	movq	%rsi, 0x60(%rsp)
   6b5ff:      	movq	%r10, 0x18(%rsp)
   6b604:      	movq	$0x0, 0x50(%rsp)
   6b60d:      	movq	$0x3, 0x38(%rsp)
   6b616:      	xorl	%edi, %edi
   6b618:      	leaq	-0x12(%r14), %rsi
   6b61c:      	callq	0x6e9d0 <f.3>
   6b621:      	subq	$0x8, %rsp
   6b625:      	cmpb	$0x0, 0x8284(%rip)      # 0x738b0 <g.4>
   6b62c:      	je	0x6e9c5 <f.2+0x17805>
   6b632:      	movq	%rax, 0x68(%rsp)
   6b637:      	cmpq	$0x0, 0x8269(%rip)      # 0x738a8 <g.3>
   6b63f:      	je	0x6e9c5 <f.2+0x17805>
   6b645:      	leaq	-0x13(%r14), %rsi
   6b649:      	movq	$0x0, 0x50(%rsp)
   6b652:      	movq	$0x3, 0x38(%rsp)
   6b65b:      	xorl	%edi, %edi
   6b65d:      	callq	0x6e9d0 <f.3>
   6b662:      	subq	$0x8, %rsp
   6b666:      	movq	%rax, %rdx
   6b669:      	addq	0x68(%rsp), %rdx
   6b66e:      	leaq	0x28(%rsp), %r8
   6b673:      	leaq	0x20(%rsp), %rdi
   6b678:      	leaq	0x8149(%rip), %r9       # 0x737c8 <native_roots.0>
   6b67f:      	movq	0x10(%rsp), %rax
   6b684:      	movq	0x58(%rsp), %rcx
   6b689:      	movq	0x18(%rsp), %r10
   6b68e:      	movq	0x60(%rsp), %rsi
   6b693:      	addq	%rdx, %rsi
   6b696:      	addq	%rsi, %r10
   6b699:      	addq	%r10, %rcx
   6b69c:      	addq	%rcx, %r13
   6b69f:      	cmpb	$0x0, 0x820a(%rip)      # 0x738b0 <g.4>
   6b6a6:      	je	0x6e9c5 <f.2+0x17805>
   6b6ac:      	cmpq	$0x0, 0x81f4(%rip)      # 0x738a8 <g.3>
   6b6b4:      	je	0x6e9c5 <f.2+0x17805>
   6b6ba:      	addq	%rbp, %r13
   6b6bd:      	addq	%rax, %r13
   6b6c0:      	cmpq	$0x9, %r14
   6b6c4:      	jbe	0x6b7a2 <f.2+0x145e2>
   6b6ca:      	movl	$0x1, %eax
   6b6cf:      	cmpq	$0xa, %r14
   6b6d3:      	je	0x6b7b6 <f.2+0x145f6>
   6b6d9:      	cmpq	$0xb, %r14
   6b6dd:      	jbe	0x6b7b2 <f.2+0x145f2>
   6b6e3:      	movl	$0x1, %ebp
   6b6e8:      	cmpq	$0xc, %r14
   6b6ec:      	je	0x6b8c6 <f.2+0x14706>
   6b6f2:      	movq	%r14, %rbp
   6b6f5:      	subq	$0xd, %rbp
   6b6f9:      	jbe	0x6b8c3 <f.2+0x14703>
   6b6ff:      	movq	$0x0, 0x50(%rsp)
   6b708:      	movq	$0x3, 0x38(%rsp)
   6b711:      	xorl	%edi, %edi
   6b713:      	movq	%rbp, %rsi
   6b716:      	callq	0x6e9d0 <f.3>
   6b71b:      	subq	$0x8, %rsp
   6b71f:      	cmpb	$0x0, 0x818a(%rip)      # 0x738b0 <g.4>
   6b726:      	je	0x6e9c5 <f.2+0x17805>
   6b72c:      	movq	%rax, 0x10(%rsp)
   6b731:      	cmpq	$0x0, 0x816f(%rip)      # 0x738a8 <g.3>
   6b739:      	je	0x6e9c5 <f.2+0x17805>
   6b73f:      	leaq	-0xe(%r14), %rsi
   6b743:      	movq	$0x0, 0x50(%rsp)
   6b74c:      	movq	$0x3, 0x38(%rsp)
   6b755:      	xorl	%edi, %edi
   6b757:      	callq	0x6e9d0 <f.3>
   6b75c:      	subq	$0x8, %rsp
   6b760:      	cmpb	$0x0, 0x8149(%rip)      # 0x738b0 <g.4>
   6b767:      	je	0x6e9c5 <f.2+0x17805>
   6b76d:      	cmpq	$0x0, 0x8133(%rip)      # 0x738a8 <g.3>
   6b775:      	leaq	0x20(%rsp), %rdi
   6b77a:      	je	0x6e9c5 <f.2+0x17805>
   6b780:      	addq	0x10(%rsp), %rax
   6b785:      	cmpq	$0xe, %r14
   6b789:      	leaq	-0xe(%r14), %rsi
   6b78d:      	jne	0x6b8e3 <f.2+0x14723>
   6b793:      	addq	%rax, %rbp
   6b796:      	movl	$0x1, %eax
   6b79b:      	xorl	%ecx, %ecx
   6b79d:      	jmp	0x6ba03 <f.2+0x14843>
   6b7a2:      	leaq	-0x8(%r14), %rbp
   6b7a6:      	addq	$-0x8, %r14
   6b7aa:      	movq	%r14, %rcx
   6b7ad:      	jmp	0x6e8f1 <f.2+0x17731>
   6b7b2:      	leaq	-0xa(%r14), %rax
   6b7b6:      	leaq	(%r14,%rax), %r10
   6b7ba:      	addq	$-0xa, %r10
   6b7be:      	cmpq	$0xa, %r14
   6b7c2:      	je	0x6cd7c <f.2+0x15bbc>
   6b7c8:      	movl	$0x1, %eax
   6b7cd:      	cmpq	$0xb, %r14
   6b7d1:      	je	0x6b8ba <f.2+0x146fa>
   6b7d7:      	cmpq	$0xc, %r14
   6b7db:      	jbe	0x6b8b6 <f.2+0x146f6>
   6b7e1:      	movl	$0x1, %ebp
   6b7e6:      	cmpq	$0xd, %r14
   6b7ea:      	je	0x6b8d6 <f.2+0x14716>
   6b7f0:      	movq	%r14, %rbp
   6b7f3:      	subq	$0xe, %rbp
   6b7f7:      	jbe	0x6b8d3 <f.2+0x14713>
   6b7fd:      	movq	%r10, 0x10(%rsp)
   6b802:      	movq	$0x0, 0x50(%rsp)
   6b80b:      	movq	$0x3, 0x38(%rsp)
   6b814:      	xorl	%edi, %edi
   6b816:      	movq	%rbp, %rsi
   6b819:      	callq	0x6e9d0 <f.3>
   6b81e:      	subq	$0x8, %rsp
   6b822:      	cmpb	$0x0, 0x8087(%rip)      # 0x738b0 <g.4>
   6b829:      	je	0x6e9c5 <f.2+0x17805>
   6b82f:      	movq	%rax, 0x18(%rsp)
   6b834:      	cmpq	$0x0, 0x806c(%rip)      # 0x738a8 <g.3>
   6b83c:      	je	0x6e9c5 <f.2+0x17805>
   6b842:      	leaq	-0xf(%r14), %rsi
   6b846:      	movq	$0x0, 0x50(%rsp)
   6b84f:      	movq	$0x3, 0x38(%rsp)
   6b858:      	xorl	%edi, %edi
   6b85a:      	callq	0x6e9d0 <f.3>
   6b85f:      	subq	$0x8, %rsp
   6b863:      	cmpb	$0x0, 0x8046(%rip)      # 0x738b0 <g.4>
   6b86a:      	je	0x6e9c5 <f.2+0x17805>
   6b870:      	cmpq	$0x0, 0x8030(%rip)      # 0x738a8 <g.3>
   6b878:      	leaq	0x28(%rsp), %r8
   6b87d:      	leaq	0x7f44(%rip), %r9       # 0x737c8 <native_roots.0>
   6b884:      	movq	0x10(%rsp), %r10
   6b889:      	je	0x6e9c5 <f.2+0x17805>
   6b88f:      	addq	0x18(%rsp), %rax
   6b894:      	cmpq	$0xf, %r14
   6b898:      	leaq	-0xf(%r14), %rsi
   6b89c:      	jne	0x6ba14 <f.2+0x14854>
   6b8a2:      	addq	%rax, %rbp
   6b8a5:      	movl	$0x1, %eax
   6b8aa:      	xorl	%ecx, %ecx
   6b8ac:      	leaq	0x20(%rsp), %rdi
   6b8b1:      	jmp	0x6bbcf <f.2+0x14a0f>
   6b8b6:      	leaq	-0xb(%r14), %rax
   6b8ba:      	leaq	-0xb(%r14), %rbp
   6b8be:      	jmp	0x6ce34 <f.2+0x15c74>
   6b8c3:      	incq	%rbp
   6b8c6:      	leaq	(%r14,%rbp), %rcx
   6b8ca:      	addq	$-0xc, %rcx
   6b8ce:      	jmp	0x6bda1 <f.2+0x14be1>
   6b8d3:      	incq	%rbp
   6b8d6:      	leaq	(%r14,%rbp), %rcx
   6b8da:      	addq	$-0xd, %rcx
   6b8de:      	jmp	0x6bbf0 <f.2+0x14a30>
   6b8e3:      	movq	%rax, 0x10(%rsp)
   6b8e8:      	movq	$0x0, 0x50(%rsp)
   6b8f1:      	movq	$0x3, 0x38(%rsp)
   6b8fa:      	xorl	%edi, %edi
   6b8fc:      	callq	0x6e9d0 <f.3>
   6b901:      	subq	$0x8, %rsp
   6b905:      	cmpb	$0x0, 0x7fa4(%rip)      # 0x738b0 <g.4>
   6b90c:      	je	0x6e9c5 <f.2+0x17805>
   6b912:      	movq	%rax, 0x18(%rsp)
   6b917:      	cmpq	$0x0, 0x7f89(%rip)      # 0x738a8 <g.3>
   6b91f:      	je	0x6e9c5 <f.2+0x17805>
   6b925:      	leaq	-0xf(%r14), %rsi
   6b929:      	movq	$0x0, 0x50(%rsp)
   6b932:      	movq	$0x3, 0x38(%rsp)
   6b93b:      	xorl	%edi, %edi
   6b93d:      	callq	0x6e9d0 <f.3>
   6b942:      	subq	$0x8, %rsp
   6b946:      	cmpb	$0x0, 0x7f63(%rip)      # 0x738b0 <g.4>
   6b94d:      	je	0x6e9c5 <f.2+0x17805>
   6b953:      	cmpq	$0x0, 0x7f4d(%rip)      # 0x738a8 <g.3>
   6b95b:      	leaq	-0xe(%r14), %rsi
   6b95f:      	je	0x6e9c5 <f.2+0x17805>
   6b965:      	movq	%rax, %rbp
   6b968:      	movq	$0x0, 0x50(%rsp)
   6b971:      	movq	$0x3, 0x38(%rsp)
   6b97a:      	xorl	%edi, %edi
   6b97c:      	callq	0x6e9d0 <f.3>
   6b981:      	subq	$0x8, %rsp
   6b985:      	cmpb	$0x0, 0x7f24(%rip)      # 0x738b0 <g.4>
   6b98c:      	je	0x6e9c5 <f.2+0x17805>
   6b992:      	movq	%rax, 0x58(%rsp)
   6b997:      	cmpq	$0x0, 0x7f09(%rip)      # 0x738a8 <g.3>
   6b99f:      	je	0x6e9c5 <f.2+0x17805>
   6b9a5:      	movq	$0x0, 0x50(%rsp)
   6b9ae:      	movq	$0x3, 0x38(%rsp)
   6b9b7:      	xorl	%edi, %edi
   6b9b9:      	leaq	-0xf(%r14), %rsi
   6b9bd:      	callq	0x6e9d0 <f.3>
   6b9c2:      	subq	$0x8, %rsp
   6b9c6:      	cmpb	$0x0, 0x7ee3(%rip)      # 0x738b0 <g.4>
   6b9cd:      	je	0x6e9c5 <f.2+0x17805>
   6b9d3:      	cmpq	$0x0, 0x7ecd(%rip)      # 0x738a8 <g.3>
   6b9db:      	leaq	0x20(%rsp), %rdi
   6b9e0:      	leaq	-0xe(%r14), %rcx
   6b9e4:      	je	0x6e9c5 <f.2+0x17805>
   6b9ea:      	addq	0x18(%rsp), %rbp
   6b9ef:      	addq	0x10(%rsp), %rbp
   6b9f4:      	addq	0x58(%rsp), %rax
   6b9f9:      	cmpq	$0x10, %r14
   6b9fd:      	jae	0x6bcfb <f.2+0x14b3b>
   6ba03:      	leaq	0x28(%rsp), %r8
   6ba08:      	leaq	0x7db9(%rip), %r9       # 0x737c8 <native_roots.0>
   6ba0f:      	jmp	0x6bd80 <f.2+0x14bc0>
   6ba14:      	movq	%rax, 0x18(%rsp)
   6ba19:      	movq	$0x0, 0x50(%rsp)
   6ba22:      	movq	$0x3, 0x38(%rsp)
   6ba2b:      	xorl	%edi, %edi
   6ba2d:      	callq	0x6e9d0 <f.3>
   6ba32:      	subq	$0x8, %rsp
   6ba36:      	cmpb	$0x0, 0x7e73(%rip)      # 0x738b0 <g.4>
   6ba3d:      	je	0x6e9c5 <f.2+0x17805>
   6ba43:      	movq	%rax, 0x58(%rsp)
   6ba48:      	cmpq	$0x0, 0x7e58(%rip)      # 0x738a8 <g.3>
   6ba50:      	je	0x6e9c5 <f.2+0x17805>
   6ba56:      	leaq	-0x10(%r14), %rsi
   6ba5a:      	movq	$0x0, 0x50(%rsp)
   6ba63:      	movq	$0x3, 0x38(%rsp)
   6ba6c:      	xorl	%edi, %edi
   6ba6e:      	callq	0x6e9d0 <f.3>
   6ba73:      	subq	$0x8, %rsp
   6ba77:      	cmpb	$0x0, 0x7e32(%rip)      # 0x738b0 <g.4>
   6ba7e:      	je	0x6e9c5 <f.2+0x17805>
   6ba84:      	cmpq	$0x0, 0x7e1c(%rip)      # 0x738a8 <g.3>
   6ba8c:      	leaq	-0xf(%r14), %rsi
   6ba90:      	je	0x6e9c5 <f.2+0x17805>
   6ba96:      	movq	%rax, %rbp
   6ba99:      	movq	$0x0, 0x50(%rsp)
   6baa2:      	movq	$0x3, 0x38(%rsp)
   6baab:      	xorl	%edi, %edi
   6baad:      	callq	0x6e9d0 <f.3>
   6bab2:      	subq	$0x8, %rsp
   6bab6:      	cmpb	$0x0, 0x7df3(%rip)      # 0x738b0 <g.4>
   6babd:      	je	0x6e9c5 <f.2+0x17805>
   6bac3:      	movq	%rax, 0x60(%rsp)
   6bac8:      	cmpq	$0x0, 0x7dd8(%rip)      # 0x738a8 <g.3>
   6bad0:      	je	0x6e9c5 <f.2+0x17805>
   6bad6:      	movq	$0x0, 0x50(%rsp)
   6badf:      	movq	$0x3, 0x38(%rsp)
   6bae8:      	xorl	%edi, %edi
   6baea:      	leaq	-0x10(%r14), %rsi
   6baee:      	callq	0x6e9d0 <f.3>
   6baf3:      	subq	$0x8, %rsp
   6baf7:      	cmpb	$0x0, 0x7db2(%rip)      # 0x738b0 <g.4>
   6bafe:      	je	0x6e9c5 <f.2+0x17805>
   6bb04:      	cmpq	$0x0, 0x7d9c(%rip)      # 0x738a8 <g.3>
   6bb0c:      	leaq	0x28(%rsp), %r8
   6bb11:      	leaq	0x20(%rsp), %rdi
   6bb16:      	leaq	0x7cab(%rip), %r9       # 0x737c8 <native_roots.0>
   6bb1d:      	movq	0x10(%rsp), %r10
   6bb22:      	leaq	-0xf(%r14), %rcx
   6bb26:      	je	0x6e9c5 <f.2+0x17805>
   6bb2c:      	addq	0x58(%rsp), %rbp
   6bb31:      	addq	0x18(%rsp), %rbp
   6bb36:      	addq	0x60(%rsp), %rax
   6bb3b:      	cmpq	$0x11, %r14
   6bb3f:      	jb	0x6bbcf <f.2+0x14a0f>
   6bb45:      	movq	%rax, 0x18(%rsp)
   6bb4a:      	movq	$0x0, 0x50(%rsp)
   6bb53:      	movq	$0x3, 0x38(%rsp)
   6bb5c:      	xorl	%edi, %edi
   6bb5e:      	leaq	-0x10(%r14), %rsi
   6bb62:      	callq	0x6e9d0 <f.3>
   6bb67:      	subq	$0x8, %rsp
   6bb6b:      	cmpb	$0x0, 0x7d3e(%rip)      # 0x738b0 <g.4>
   6bb72:      	je	0x6e9c5 <f.2+0x17805>
   6bb78:      	movq	%rax, 0x58(%rsp)
   6bb7d:      	cmpq	$0x0, 0x7d23(%rip)      # 0x738a8 <g.3>
   6bb85:      	je	0x6e9c5 <f.2+0x17805>
   6bb8b:      	leaq	-0x11(%r14), %rsi
   6bb8f:      	movq	$0x0, 0x50(%rsp)
   6bb98:      	movq	$0x3, 0x38(%rsp)
   6bba1:      	xorl	%edi, %edi
   6bba3:      	callq	0x6e9d0 <f.3>
   6bba8:      	subq	$0x8, %rsp
   6bbac:      	movq	%rax, %rcx
   6bbaf:      	addq	0x58(%rsp), %rcx
   6bbb4:      	leaq	0x28(%rsp), %r8
   6bbb9:      	leaq	0x20(%rsp), %rdi
   6bbbe:      	leaq	0x7c03(%rip), %r9       # 0x737c8 <native_roots.0>
   6bbc5:      	movq	0x10(%rsp), %r10
   6bbca:      	movq	0x18(%rsp), %rax
   6bbcf:      	cmpb	$0x0, 0x7cda(%rip)      # 0x738b0 <g.4>
   6bbd6:      	je	0x6e9c5 <f.2+0x17805>
   6bbdc:      	cmpq	$0x0, 0x7cc4(%rip)      # 0x738a8 <g.3>
   6bbe4:      	je	0x6e9c5 <f.2+0x17805>
   6bbea:      	addq	%rax, %rcx
   6bbed:      	addq	%rbp, %rcx
   6bbf0:      	cmpq	$0xd, %r14
   6bbf4:      	je	0x6bcd9 <f.2+0x14b19>
   6bbfa:      	movl	$0x1, %ebp
   6bbff:      	cmpq	$0xe, %r14
   6bc03:      	je	0x6bcf2 <f.2+0x14b32>
   6bc09:      	movq	%r14, %rbp
   6bc0c:      	subq	$0xf, %rbp
   6bc10:      	jbe	0x6bcef <f.2+0x14b2f>
   6bc16:      	movq	%rcx, 0x58(%rsp)
   6bc1b:      	movq	%r10, 0x10(%rsp)
   6bc20:      	movq	$0x0, 0x50(%rsp)
   6bc29:      	movq	$0x3, 0x38(%rsp)
   6bc32:      	xorl	%edi, %edi
   6bc34:      	movq	%rbp, %rsi
   6bc37:      	callq	0x6e9d0 <f.3>
   6bc3c:      	subq	$0x8, %rsp
   6bc40:      	cmpb	$0x0, 0x7c69(%rip)      # 0x738b0 <g.4>
   6bc47:      	je	0x6e9c5 <f.2+0x17805>
   6bc4d:      	movq	%rax, 0x18(%rsp)
   6bc52:      	cmpq	$0x0, 0x7c4e(%rip)      # 0x738a8 <g.3>
   6bc5a:      	je	0x6e9c5 <f.2+0x17805>
   6bc60:      	leaq	-0x10(%r14), %rsi
   6bc64:      	movq	$0x0, 0x50(%rsp)
   6bc6d:      	movq	$0x3, 0x38(%rsp)
   6bc76:      	xorl	%edi, %edi
   6bc78:      	callq	0x6e9d0 <f.3>
   6bc7d:      	subq	$0x8, %rsp
   6bc81:      	cmpb	$0x0, 0x7c28(%rip)      # 0x738b0 <g.4>
   6bc88:      	je	0x6e9c5 <f.2+0x17805>
   6bc8e:      	cmpq	$0x0, 0x7c12(%rip)      # 0x738a8 <g.3>
   6bc96:      	leaq	0x20(%rsp), %rdi
   6bc9b:      	movq	0x10(%rsp), %r10
   6bca0:      	movq	0x58(%rsp), %rcx
   6bca5:      	je	0x6e9c5 <f.2+0x17805>
   6bcab:      	addq	0x18(%rsp), %rax
   6bcb0:      	cmpq	$0x10, %r14
   6bcb4:      	leaq	-0x10(%r14), %rsi
   6bcb8:      	jne	0x6bfc3 <f.2+0x14e03>
   6bcbe:      	addq	%rax, %rbp
   6bcc1:      	movl	$0x1, %eax
   6bcc6:      	xorl	%edx, %edx
   6bcc8:      	leaq	0x28(%rsp), %r8
   6bccd:      	leaq	0x7af4(%rip), %r9       # 0x737c8 <native_roots.0>
   6bcd4:      	jmp	0x6c188 <f.2+0x14fc8>
   6bcd9:      	leaq	(%r14,%rcx), %rax
   6bcdd:      	addq	$-0xc, %rax
   6bce1:      	movl	$0x1, %ebp
   6bce6:      	leaq	-0xd(%r14), %rdx
   6bcea:      	jmp	0x6ce31 <f.2+0x15c71>
   6bcef:      	incq	%rbp
   6bcf2:      	leaq	-0xe(%r14), %rax
   6bcf6:      	jmp	0x6c18b <f.2+0x14fcb>
   6bcfb:      	movq	%rax, 0x10(%rsp)
   6bd00:      	movq	$0x0, 0x50(%rsp)
   6bd09:      	movq	$0x3, 0x38(%rsp)
   6bd12:      	xorl	%edi, %edi
   6bd14:      	leaq	-0xf(%r14), %rsi
   6bd18:      	callq	0x6e9d0 <f.3>
   6bd1d:      	subq	$0x8, %rsp
   6bd21:      	cmpb	$0x0, 0x7b88(%rip)      # 0x738b0 <g.4>
   6bd28:      	je	0x6e9c5 <f.2+0x17805>
   6bd2e:      	movq	%rax, 0x18(%rsp)
   6bd33:      	cmpq	$0x0, 0x7b6d(%rip)      # 0x738a8 <g.3>
   6bd3b:      	je	0x6e9c5 <f.2+0x17805>
   6bd41:      	leaq	-0x10(%r14), %rsi
   6bd45:      	movq	$0x0, 0x50(%rsp)
   6bd4e:      	movq	$0x3, 0x38(%rsp)
   6bd57:      	xorl	%edi, %edi
   6bd59:      	callq	0x6e9d0 <f.3>
   6bd5e:      	subq	$0x8, %rsp
   6bd62:      	movq	%rax, %rcx
   6bd65:      	addq	0x18(%rsp), %rcx
   6bd6a:      	leaq	0x28(%rsp), %r8
   6bd6f:      	leaq	0x20(%rsp), %rdi
   6bd74:      	leaq	0x7a4d(%rip), %r9       # 0x737c8 <native_roots.0>
   6bd7b:      	movq	0x10(%rsp), %rax
   6bd80:      	cmpb	$0x0, 0x7b29(%rip)      # 0x738b0 <g.4>
   6bd87:      	je	0x6e9c5 <f.2+0x17805>
   6bd8d:      	cmpq	$0x0, 0x7b13(%rip)      # 0x738a8 <g.3>
   6bd95:      	je	0x6e9c5 <f.2+0x17805>
   6bd9b:      	addq	%rax, %rcx
   6bd9e:      	addq	%rbp, %rcx
   6bda1:      	cmpq	$0xc, %r14
   6bda5:      	je	0x6be6b <f.2+0x14cab>
   6bdab:      	movl	$0x1, %ebp
   6bdb0:      	cmpq	$0xd, %r14
   6bdb4:      	je	0x6be84 <f.2+0x14cc4>
   6bdba:      	movq	%r14, %rbp
   6bdbd:      	subq	$0xe, %rbp
   6bdc1:      	jbe	0x6be81 <f.2+0x14cc1>
   6bdc7:      	movq	%rcx, 0x10(%rsp)
   6bdcc:      	movq	$0x0, 0x50(%rsp)
   6bdd5:      	movq	$0x3, 0x38(%rsp)
   6bdde:      	xorl	%edi, %edi
   6bde0:      	movq	%rbp, %rsi
   6bde3:      	callq	0x6e9d0 <f.3>
   6bde8:      	subq	$0x8, %rsp
   6bdec:      	cmpb	$0x0, 0x7abd(%rip)      # 0x738b0 <g.4>
   6bdf3:      	je	0x6e9c5 <f.2+0x17805>
   6bdf9:      	movq	%rax, 0x18(%rsp)
   6bdfe:      	cmpq	$0x0, 0x7aa2(%rip)      # 0x738a8 <g.3>
   6be06:      	je	0x6e9c5 <f.2+0x17805>
   6be0c:      	leaq	-0xf(%r14), %rsi
   6be10:      	movq	$0x0, 0x50(%rsp)
   6be19:      	movq	$0x3, 0x38(%rsp)
   6be22:      	xorl	%edi, %edi
   6be24:      	callq	0x6e9d0 <f.3>
   6be29:      	subq	$0x8, %rsp
   6be2d:      	cmpb	$0x0, 0x7a7c(%rip)      # 0x738b0 <g.4>
   6be34:      	je	0x6e9c5 <f.2+0x17805>
   6be3a:      	cmpq	$0x0, 0x7a66(%rip)      # 0x738a8 <g.3>
   6be42:      	movq	0x10(%rsp), %rcx
   6be47:      	je	0x6e9c5 <f.2+0x17805>
   6be4d:      	addq	0x18(%rsp), %rax
   6be52:      	cmpq	$0xf, %r14
   6be56:      	leaq	-0xf(%r14), %rsi
   6be5a:      	jne	0x6be8d <f.2+0x14ccd>
   6be5c:      	addq	%rax, %rbp
   6be5f:      	movl	$0x1, %eax
   6be64:      	xorl	%edx, %edx
   6be66:      	jmp	0x6bfad <f.2+0x14ded>
   6be6b:      	leaq	(%r14,%rcx), %rax
   6be6f:      	addq	$-0xb, %rax
   6be73:      	movl	$0x1, %ecx
   6be78:      	leaq	-0xc(%r14), %r10
   6be7c:      	jmp	0x6cd51 <f.2+0x15b91>
   6be81:      	incq	%rbp
   6be84:      	leaq	-0xd(%r14), %rax
   6be88:      	jmp	0x6c633 <f.2+0x15473>
   6be8d:      	movq	%rax, 0x18(%rsp)
   6be92:      	movq	$0x0, 0x50(%rsp)
   6be9b:      	movq	$0x3, 0x38(%rsp)
   6bea4:      	xorl	%edi, %edi
   6bea6:      	callq	0x6e9d0 <f.3>
   6beab:      	subq	$0x8, %rsp
   6beaf:      	cmpb	$0x0, 0x79fa(%rip)      # 0x738b0 <g.4>
   6beb6:      	je	0x6e9c5 <f.2+0x17805>
   6bebc:      	movq	%rax, 0x58(%rsp)
   6bec1:      	cmpq	$0x0, 0x79df(%rip)      # 0x738a8 <g.3>
   6bec9:      	je	0x6e9c5 <f.2+0x17805>
   6becf:      	leaq	-0x10(%r14), %rsi
   6bed3:      	movq	$0x0, 0x50(%rsp)
   6bedc:      	movq	$0x3, 0x38(%rsp)
   6bee5:      	xorl	%edi, %edi
   6bee7:      	callq	0x6e9d0 <f.3>
   6beec:      	subq	$0x8, %rsp
   6bef0:      	cmpb	$0x0, 0x79b9(%rip)      # 0x738b0 <g.4>
   6bef7:      	je	0x6e9c5 <f.2+0x17805>
   6befd:      	cmpq	$0x0, 0x79a3(%rip)      # 0x738a8 <g.3>
   6bf05:      	leaq	-0xf(%r14), %rsi
   6bf09:      	je	0x6e9c5 <f.2+0x17805>
   6bf0f:      	movq	%rax, %rbp
   6bf12:      	movq	$0x0, 0x50(%rsp)
   6bf1b:      	movq	$0x3, 0x38(%rsp)
   6bf24:      	xorl	%edi, %edi
   6bf26:      	callq	0x6e9d0 <f.3>
   6bf2b:      	subq	$0x8, %rsp
   6bf2f:      	cmpb	$0x0, 0x797a(%rip)      # 0x738b0 <g.4>
   6bf36:      	je	0x6e9c5 <f.2+0x17805>
   6bf3c:      	movq	%rax, 0x60(%rsp)
   6bf41:      	cmpq	$0x0, 0x795f(%rip)      # 0x738a8 <g.3>
   6bf49:      	je	0x6e9c5 <f.2+0x17805>
   6bf4f:      	movq	$0x0, 0x50(%rsp)
   6bf58:      	movq	$0x3, 0x38(%rsp)
   6bf61:      	xorl	%edi, %edi
   6bf63:      	leaq	-0x10(%r14), %rsi
   6bf67:      	callq	0x6e9d0 <f.3>
   6bf6c:      	subq	$0x8, %rsp
   6bf70:      	cmpb	$0x0, 0x7939(%rip)      # 0x738b0 <g.4>
   6bf77:      	je	0x6e9c5 <f.2+0x17805>
   6bf7d:      	cmpq	$0x0, 0x7923(%rip)      # 0x738a8 <g.3>
   6bf85:      	movq	0x10(%rsp), %rcx
   6bf8a:      	leaq	-0xf(%r14), %rdx
   6bf8e:      	je	0x6e9c5 <f.2+0x17805>
   6bf94:      	addq	0x58(%rsp), %rbp
   6bf99:      	addq	0x18(%rsp), %rbp
   6bf9e:      	addq	0x60(%rsp), %rax
   6bfa3:      	cmpq	$0x11, %r14
   6bfa7:      	jae	0x6c5a6 <f.2+0x153e6>
   6bfad:      	leaq	0x28(%rsp), %r8
   6bfb2:      	leaq	0x20(%rsp), %rdi
   6bfb7:      	leaq	0x780a(%rip), %r9       # 0x737c8 <native_roots.0>
   6bfbe:      	jmp	0x6c630 <f.2+0x15470>
   6bfc3:      	movq	%rax, 0x18(%rsp)
   6bfc8:      	movq	$0x0, 0x50(%rsp)
   6bfd1:      	movq	$0x3, 0x38(%rsp)
   6bfda:      	xorl	%edi, %edi
   6bfdc:      	callq	0x6e9d0 <f.3>
   6bfe1:      	subq	$0x8, %rsp
   6bfe5:      	cmpb	$0x0, 0x78c4(%rip)      # 0x738b0 <g.4>
   6bfec:      	je	0x6e9c5 <f.2+0x17805>
   6bff2:      	movq	%rax, 0x60(%rsp)
   6bff7:      	cmpq	$0x0, 0x78a9(%rip)      # 0x738a8 <g.3>
   6bfff:      	je	0x6e9c5 <f.2+0x17805>
   6c005:      	leaq	-0x11(%r14), %rsi
   6c009:      	movq	$0x0, 0x50(%rsp)
   6c012:      	movq	$0x3, 0x38(%rsp)
   6c01b:      	xorl	%edi, %edi
   6c01d:      	callq	0x6e9d0 <f.3>
   6c022:      	subq	$0x8, %rsp
   6c026:      	cmpb	$0x0, 0x7883(%rip)      # 0x738b0 <g.4>
   6c02d:      	je	0x6e9c5 <f.2+0x17805>
   6c033:      	cmpq	$0x0, 0x786d(%rip)      # 0x738a8 <g.3>
   6c03b:      	leaq	-0x10(%r14), %rsi
   6c03f:      	je	0x6e9c5 <f.2+0x17805>
   6c045:      	movq	%rax, %rbp
   6c048:      	movq	$0x0, 0x50(%rsp)
   6c051:      	movq	$0x3, 0x38(%rsp)
   6c05a:      	xorl	%edi, %edi
   6c05c:      	callq	0x6e9d0 <f.3>
   6c061:      	subq	$0x8, %rsp
   6c065:      	cmpb	$0x0, 0x7844(%rip)      # 0x738b0 <g.4>
   6c06c:      	je	0x6e9c5 <f.2+0x17805>
   6c072:      	movq	%rax, 0x68(%rsp)
   6c077:      	cmpq	$0x0, 0x7829(%rip)      # 0x738a8 <g.3>
   6c07f:      	je	0x6e9c5 <f.2+0x17805>
   6c085:      	movq	$0x0, 0x50(%rsp)
   6c08e:      	movq	$0x3, 0x38(%rsp)
   6c097:      	xorl	%edi, %edi
   6c099:      	leaq	-0x11(%r14), %rsi
   6c09d:      	callq	0x6e9d0 <f.3>
   6c0a2:      	subq	$0x8, %rsp
   6c0a6:      	cmpb	$0x0, 0x7803(%rip)      # 0x738b0 <g.4>
   6c0ad:      	je	0x6e9c5 <f.2+0x17805>
   6c0b3:      	cmpq	$0x0, 0x77ed(%rip)      # 0x738a8 <g.3>
   6c0bb:      	leaq	0x28(%rsp), %r8
   6c0c0:      	leaq	0x20(%rsp), %rdi
   6c0c5:      	leaq	0x76fc(%rip), %r9       # 0x737c8 <native_roots.0>
   6c0cc:      	movq	0x10(%rsp), %r10
   6c0d1:      	movq	0x58(%rsp), %rcx
   6c0d6:      	leaq	-0x10(%r14), %rdx
   6c0da:      	je	0x6e9c5 <f.2+0x17805>
   6c0e0:      	addq	0x60(%rsp), %rbp
   6c0e5:      	addq	0x18(%rsp), %rbp
   6c0ea:      	addq	0x68(%rsp), %rax
   6c0ef:      	cmpq	$0x12, %r14
   6c0f3:      	jb	0x6c188 <f.2+0x14fc8>
   6c0f9:      	movq	%rax, 0x18(%rsp)
   6c0fe:      	movq	$0x0, 0x50(%rsp)
   6c107:      	movq	$0x3, 0x38(%rsp)
   6c110:      	xorl	%edi, %edi
   6c112:      	leaq	-0x11(%r14), %rsi
   6c116:      	callq	0x6e9d0 <f.3>
   6c11b:      	subq	$0x8, %rsp
   6c11f:      	cmpb	$0x0, 0x778a(%rip)      # 0x738b0 <g.4>
   6c126:      	je	0x6e9c5 <f.2+0x17805>
   6c12c:      	movq	%rax, 0x60(%rsp)
   6c131:      	cmpq	$0x0, 0x776f(%rip)      # 0x738a8 <g.3>
   6c139:      	je	0x6e9c5 <f.2+0x17805>
   6c13f:      	leaq	-0x12(%r14), %rsi
   6c143:      	movq	$0x0, 0x50(%rsp)
   6c14c:      	movq	$0x3, 0x38(%rsp)
   6c155:      	xorl	%edi, %edi
   6c157:      	callq	0x6e9d0 <f.3>
   6c15c:      	subq	$0x8, %rsp
   6c160:      	movq	%rax, %rdx
   6c163:      	addq	0x60(%rsp), %rdx
   6c168:      	leaq	0x28(%rsp), %r8
   6c16d:      	leaq	0x20(%rsp), %rdi
   6c172:      	leaq	0x764f(%rip), %r9       # 0x737c8 <native_roots.0>
   6c179:      	movq	0x10(%rsp), %r10
   6c17e:      	movq	0x18(%rsp), %rax
   6c183:      	movq	0x58(%rsp), %rcx
   6c188:      	addq	%rdx, %rax
   6c18b:      	cmpb	$0x0, 0x771e(%rip)      # 0x738b0 <g.4>
   6c192:      	je	0x6e9c5 <f.2+0x17805>
   6c198:      	cmpq	$0x0, 0x7708(%rip)      # 0x738a8 <g.3>
   6c1a0:      	je	0x6e9c5 <f.2+0x17805>
   6c1a6:      	addq	%rbp, %rax
   6c1a9:      	addq	%rcx, %rax
   6c1ac:      	cmpq	$0xe, %r14
   6c1b0:      	jbe	0x6c1ce <f.2+0x1500e>
   6c1b2:      	cmpq	$0xf, %r14
   6c1b6:      	movq	%rax, 0x18(%rsp)
   6c1bb:      	movq	%r10, 0x10(%rsp)
   6c1c0:      	jne	0x6c1db <f.2+0x1501b>
   6c1c2:      	movl	$0x1, %ebp
   6c1c7:      	xorl	%ecx, %ecx
   6c1c9:      	jmp	0x6c32a <f.2+0x1516a>
   6c1ce:      	leaq	-0xd(%r14), %rbp
   6c1d2:      	leaq	-0xd(%r14), %rdx
   6c1d6:      	jmp	0x6ce31 <f.2+0x15c71>
   6c1db:      	leaq	-0xf(%r14), %rsi
   6c1df:      	movq	$0x0, 0x50(%rsp)
   6c1e8:      	movq	$0x3, 0x38(%rsp)
   6c1f1:      	xorl	%edi, %edi
   6c1f3:      	callq	0x6e9d0 <f.3>
   6c1f8:      	subq	$0x8, %rsp
   6c1fc:      	cmpb	$0x0, 0x76ad(%rip)      # 0x738b0 <g.4>
   6c203:      	je	0x6e9c5 <f.2+0x17805>
   6c209:      	movq	%rax, 0x58(%rsp)
   6c20e:      	cmpq	$0x0, 0x7692(%rip)      # 0x738a8 <g.3>
   6c216:      	je	0x6e9c5 <f.2+0x17805>
   6c21c:      	leaq	-0x10(%r14), %rsi
   6c220:      	movq	$0x0, 0x50(%rsp)
   6c229:      	movq	$0x3, 0x38(%rsp)
   6c232:      	xorl	%edi, %edi
   6c234:      	callq	0x6e9d0 <f.3>
   6c239:      	subq	$0x8, %rsp
   6c23d:      	cmpb	$0x0, 0x766c(%rip)      # 0x738b0 <g.4>
   6c244:      	je	0x6e9c5 <f.2+0x17805>
   6c24a:      	cmpq	$0x0, 0x7656(%rip)      # 0x738a8 <g.3>
   6c252:      	leaq	-0xf(%r14), %rcx
   6c256:      	je	0x6e9c5 <f.2+0x17805>
   6c25c:      	movq	%rax, %rbp
   6c25f:      	addq	0x58(%rsp), %rbp
   6c264:      	cmpq	$0x10, %r14
   6c268:      	ja	0x6c28a <f.2+0x150ca>
   6c26a:      	leaq	0x28(%rsp), %r8
   6c26f:      	leaq	0x20(%rsp), %rdi
   6c274:      	leaq	0x754d(%rip), %r9       # 0x737c8 <native_roots.0>
   6c27b:      	movq	0x10(%rsp), %r10
   6c280:      	movq	0x18(%rsp), %rax
   6c285:      	jmp	0x6c32a <f.2+0x1516a>
   6c28a:      	movq	$0x0, 0x50(%rsp)
   6c293:      	movq	$0x3, 0x38(%rsp)
   6c29c:      	xorl	%edi, %edi
   6c29e:      	leaq	-0x10(%r14), %rsi
   6c2a2:      	callq	0x6e9d0 <f.3>
   6c2a7:      	subq	$0x8, %rsp
   6c2ab:      	cmpb	$0x0, 0x75fe(%rip)      # 0x738b0 <g.4>
   6c2b2:      	je	0x6e9c5 <f.2+0x17805>
   6c2b8:      	movq	%rax, 0x58(%rsp)
   6c2bd:      	cmpq	$0x0, 0x75e3(%rip)      # 0x738a8 <g.3>
   6c2c5:      	je	0x6e9c5 <f.2+0x17805>
   6c2cb:      	leaq	-0x11(%r14), %rsi
   6c2cf:      	movq	$0x0, 0x50(%rsp)
   6c2d8:      	movq	$0x3, 0x38(%rsp)
   6c2e1:      	xorl	%edi, %edi
   6c2e3:      	callq	0x6e9d0 <f.3>
   6c2e8:      	subq	$0x8, %rsp
   6c2ec:      	cmpb	$0x0, 0x75bd(%rip)      # 0x738b0 <g.4>
   6c2f3:      	je	0x6e9c5 <f.2+0x17805>
   6c2f9:      	movq	%rax, %rcx
   6c2fc:      	cmpq	$0x0, 0x75a4(%rip)      # 0x738a8 <g.3>
   6c304:      	leaq	0x28(%rsp), %r8
   6c309:      	leaq	0x20(%rsp), %rdi
   6c30e:      	leaq	0x74b3(%rip), %r9       # 0x737c8 <native_roots.0>
   6c315:      	movq	0x10(%rsp), %r10
   6c31a:      	movq	0x18(%rsp), %rax
   6c31f:      	je	0x6e9c5 <f.2+0x17805>
   6c325:      	addq	0x58(%rsp), %rcx
   6c32a:      	addq	%rbp, %rcx
   6c32d:      	cmpq	$0xf, %r14
   6c331:      	je	0x6c345 <f.2+0x15185>
   6c333:      	cmpq	$0x10, %r14
   6c337:      	jne	0x6c35b <f.2+0x1519b>
   6c339:      	movl	$0x1, %edx
   6c33e:      	xorl	%ebp, %ebp
   6c340:      	jmp	0x6c4a6 <f.2+0x152e6>
   6c345:      	leaq	(%r14,%rcx), %rbp
   6c349:      	addq	$-0xe, %rbp
   6c34d:      	movl	$0x1, %edx
   6c352:      	leaq	-0xf(%r14), %rsi
   6c356:      	jmp	0x6ce2e <f.2+0x15c6e>
   6c35b:      	movq	%rcx, 0x58(%rsp)
   6c360:      	leaq	-0x10(%r14), %rbp
   6c364:      	movq	$0x0, 0x50(%rsp)
   6c36d:      	movq	$0x3, 0x38(%rsp)
   6c376:      	xorl	%edi, %edi
   6c378:      	movq	%rbp, %rsi
   6c37b:      	callq	0x6e9d0 <f.3>
   6c380:      	subq	$0x8, %rsp
   6c384:      	cmpb	$0x0, 0x7525(%rip)      # 0x738b0 <g.4>
   6c38b:      	je	0x6e9c5 <f.2+0x17805>
   6c391:      	movq	%rax, 0x60(%rsp)
   6c396:      	cmpq	$0x0, 0x750a(%rip)      # 0x738a8 <g.3>
   6c39e:      	je	0x6e9c5 <f.2+0x17805>
   6c3a4:      	leaq	-0x11(%r14), %rsi
   6c3a8:      	movq	$0x0, 0x50(%rsp)
   6c3b1:      	movq	$0x3, 0x38(%rsp)
   6c3ba:      	xorl	%edi, %edi
   6c3bc:      	callq	0x6e9d0 <f.3>
   6c3c1:      	subq	$0x8, %rsp
   6c3c5:      	cmpb	$0x0, 0x74e4(%rip)      # 0x738b0 <g.4>
   6c3cc:      	je	0x6e9c5 <f.2+0x17805>
   6c3d2:      	movq	%rax, %rdx
   6c3d5:      	cmpq	$0x0, 0x74cb(%rip)      # 0x738a8 <g.3>
   6c3dd:      	leaq	0x28(%rsp), %r8
   6c3e2:      	leaq	0x20(%rsp), %rdi
   6c3e7:      	leaq	0x73da(%rip), %r9       # 0x737c8 <native_roots.0>
   6c3ee:      	movq	0x10(%rsp), %r10
   6c3f3:      	movq	0x18(%rsp), %rax
   6c3f8:      	movq	0x58(%rsp), %rcx
   6c3fd:      	je	0x6e9c5 <f.2+0x17805>
   6c403:      	addq	0x60(%rsp), %rdx
   6c408:      	cmpq	$0x12, %r14
   6c40c:      	jb	0x6c4a6 <f.2+0x152e6>
   6c412:      	movq	%rdx, 0x60(%rsp)
   6c417:      	movq	$0x0, 0x50(%rsp)
   6c420:      	movq	$0x3, 0x38(%rsp)
   6c429:      	xorl	%edi, %edi
   6c42b:      	leaq	-0x11(%r14), %rsi
   6c42f:      	callq	0x6e9d0 <f.3>
   6c434:      	subq	$0x8, %rsp
   6c438:      	cmpb	$0x0, 0x7471(%rip)      # 0x738b0 <g.4>
   6c43f:      	je	0x6e9c5 <f.2+0x17805>
   6c445:      	movq	%rax, 0x68(%rsp)
   6c44a:      	cmpq	$0x0, 0x7456(%rip)      # 0x738a8 <g.3>
   6c452:      	je	0x6e9c5 <f.2+0x17805>
   6c458:      	leaq	-0x12(%r14), %rsi
   6c45c:      	movq	$0x0, 0x50(%rsp)
   6c465:      	movq	$0x3, 0x38(%rsp)
   6c46e:      	xorl	%edi, %edi
   6c470:      	callq	0x6e9d0 <f.3>
   6c475:      	subq	$0x8, %rsp
   6c479:      	movq	%rax, %rbp
   6c47c:      	addq	0x68(%rsp), %rbp
   6c481:      	leaq	0x28(%rsp), %r8
   6c486:      	leaq	0x20(%rsp), %rdi
   6c48b:      	leaq	0x7336(%rip), %r9       # 0x737c8 <native_roots.0>
   6c492:      	movq	0x10(%rsp), %r10
   6c497:      	movq	0x18(%rsp), %rax
   6c49c:      	movq	0x58(%rsp), %rcx
   6c4a1:      	movq	0x60(%rsp), %rdx
   6c4a6:      	cmpb	$0x0, 0x7403(%rip)      # 0x738b0 <g.4>
   6c4ad:      	je	0x6e9c5 <f.2+0x17805>
   6c4b3:      	cmpq	$0x0, 0x73ed(%rip)      # 0x738a8 <g.3>
   6c4bb:      	je	0x6e9c5 <f.2+0x17805>
   6c4c1:      	addq	%rdx, %rbp
   6c4c4:      	addq	%rcx, %rbp
   6c4c7:      	movq	%r14, %rdx
   6c4ca:      	subq	$0x10, %rdx
   6c4ce:      	jbe	0x6c59a <f.2+0x153da>
   6c4d4:      	movq	$0x0, 0x50(%rsp)
   6c4dd:      	movq	$0x3, 0x38(%rsp)
   6c4e6:      	xorl	%edi, %edi
   6c4e8:      	movq	%rdx, 0x58(%rsp)
   6c4ed:      	movq	%rdx, %rsi
   6c4f0:      	callq	0x6e9d0 <f.3>
   6c4f5:      	subq	$0x8, %rsp
   6c4f9:      	cmpb	$0x0, 0x73b0(%rip)      # 0x738b0 <g.4>
   6c500:      	je	0x6e9c5 <f.2+0x17805>
   6c506:      	movq	%rax, 0x60(%rsp)
   6c50b:      	cmpq	$0x0, 0x7395(%rip)      # 0x738a8 <g.3>
   6c513:      	je	0x6e9c5 <f.2+0x17805>
   6c519:      	leaq	-0x11(%r14), %rsi
   6c51d:      	movq	$0x0, 0x50(%rsp)
   6c526:      	movq	$0x3, 0x38(%rsp)
   6c52f:      	xorl	%edi, %edi
   6c531:      	callq	0x6e9d0 <f.3>
   6c536:      	subq	$0x8, %rsp
   6c53a:      	cmpb	$0x0, 0x736f(%rip)      # 0x738b0 <g.4>
   6c541:      	je	0x6e9c5 <f.2+0x17805>
   6c547:      	movq	%rax, %rcx
   6c54a:      	cmpq	$0x0, 0x7356(%rip)      # 0x738a8 <g.3>
   6c552:      	movq	0x18(%rsp), %rax
   6c557:      	movq	0x58(%rsp), %rdx
   6c55c:      	je	0x6e9c5 <f.2+0x17805>
   6c562:      	addq	0x60(%rsp), %rcx
   6c567:      	cmpq	$0x11, %r14
   6c56b:      	leaq	-0x11(%r14), %rsi
   6c56f:      	jne	0x6cb77 <f.2+0x159b7>
   6c575:      	addq	%rcx, %rdx
   6c578:      	movl	$0x1, %esi
   6c57d:      	xorl	%ecx, %ecx
   6c57f:      	leaq	0x28(%rsp), %r8
   6c584:      	leaq	0x20(%rsp), %rdi
   6c589:      	leaq	0x7238(%rip), %r9       # 0x737c8 <native_roots.0>
   6c590:      	movq	0x10(%rsp), %r10
   6c595:      	jmp	0x6ce2b <f.2+0x15c6b>
   6c59a:      	incq	%rdx
   6c59d:      	leaq	-0xf(%r14), %rsi
   6c5a1:      	jmp	0x6ce2e <f.2+0x15c6e>
   6c5a6:      	movq	%rax, 0x18(%rsp)
   6c5ab:      	movq	$0x0, 0x50(%rsp)
   6c5b4:      	movq	$0x3, 0x38(%rsp)
   6c5bd:      	xorl	%edi, %edi
   6c5bf:      	leaq	-0x10(%r14), %rsi
   6c5c3:      	callq	0x6e9d0 <f.3>
   6c5c8:      	subq	$0x8, %rsp
   6c5cc:      	cmpb	$0x0, 0x72dd(%rip)      # 0x738b0 <g.4>
   6c5d3:      	je	0x6e9c5 <f.2+0x17805>
   6c5d9:      	movq	%rax, 0x58(%rsp)
   6c5de:      	cmpq	$0x0, 0x72c2(%rip)      # 0x738a8 <g.3>
   6c5e6:      	je	0x6e9c5 <f.2+0x17805>
   6c5ec:      	leaq	-0x11(%r14), %rsi
   6c5f0:      	movq	$0x0, 0x50(%rsp)
   6c5f9:      	movq	$0x3, 0x38(%rsp)
   6c602:      	xorl	%edi, %edi
   6c604:      	callq	0x6e9d0 <f.3>
   6c609:      	subq	$0x8, %rsp
   6c60d:      	movq	%rax, %rdx
   6c610:      	addq	0x58(%rsp), %rdx
   6c615:      	leaq	0x28(%rsp), %r8
   6c61a:      	leaq	0x20(%rsp), %rdi
   6c61f:      	leaq	0x71a2(%rip), %r9       # 0x737c8 <native_roots.0>
   6c626:      	movq	0x18(%rsp), %rax
   6c62b:      	movq	0x10(%rsp), %rcx
   6c630:      	addq	%rdx, %rax
   6c633:      	cmpb	$0x0, 0x7276(%rip)      # 0x738b0 <g.4>
   6c63a:      	je	0x6e9c5 <f.2+0x17805>
   6c640:      	cmpq	$0x0, 0x7260(%rip)      # 0x738a8 <g.3>
   6c648:      	je	0x6e9c5 <f.2+0x17805>
   6c64e:      	addq	%rbp, %rax
   6c651:      	addq	%rcx, %rax
   6c654:      	cmpq	$0xd, %r14
   6c658:      	jbe	0x6c671 <f.2+0x154b1>
   6c65a:      	cmpq	$0xe, %r14
   6c65e:      	movq	%rax, 0x18(%rsp)
   6c663:      	jne	0x6c67e <f.2+0x154be>
   6c665:      	movl	$0x1, %ebp
   6c66a:      	xorl	%edx, %edx
   6c66c:      	jmp	0x6c7c3 <f.2+0x15603>
   6c671:      	leaq	-0xc(%r14), %rcx
   6c675:      	leaq	-0xc(%r14), %r10
   6c679:      	jmp	0x6cd51 <f.2+0x15b91>
   6c67e:      	leaq	-0xe(%r14), %rsi
   6c682:      	movq	$0x0, 0x50(%rsp)
   6c68b:      	movq	$0x3, 0x38(%rsp)
   6c694:      	xorl	%edi, %edi
   6c696:      	callq	0x6e9d0 <f.3>
   6c69b:      	subq	$0x8, %rsp
   6c69f:      	cmpb	$0x0, 0x720a(%rip)      # 0x738b0 <g.4>
   6c6a6:      	je	0x6e9c5 <f.2+0x17805>
   6c6ac:      	movq	%rax, 0x10(%rsp)
   6c6b1:      	cmpq	$0x0, 0x71ef(%rip)      # 0x738a8 <g.3>
   6c6b9:      	je	0x6e9c5 <f.2+0x17805>
   6c6bf:      	leaq	-0xf(%r14), %rsi
   6c6c3:      	movq	$0x0, 0x50(%rsp)
   6c6cc:      	movq	$0x3, 0x38(%rsp)
   6c6d5:      	xorl	%edi, %edi
   6c6d7:      	callq	0x6e9d0 <f.3>
   6c6dc:      	subq	$0x8, %rsp
   6c6e0:      	cmpb	$0x0, 0x71c9(%rip)      # 0x738b0 <g.4>
   6c6e7:      	je	0x6e9c5 <f.2+0x17805>
   6c6ed:      	movq	%rax, %rbp
   6c6f0:      	cmpq	$0x0, 0x71b0(%rip)      # 0x738a8 <g.3>
   6c6f8:      	leaq	0x20(%rsp), %rdi
   6c6fd:      	movq	0x18(%rsp), %rax
   6c702:      	leaq	-0xe(%r14), %rdx
   6c706:      	je	0x6e9c5 <f.2+0x17805>
   6c70c:      	addq	0x10(%rsp), %rbp
   6c711:      	cmpq	$0xf, %r14
   6c715:      	ja	0x6c728 <f.2+0x15568>
   6c717:      	leaq	0x28(%rsp), %r8
   6c71c:      	leaq	0x70a5(%rip), %r9       # 0x737c8 <native_roots.0>
   6c723:      	jmp	0x6c7c3 <f.2+0x15603>
   6c728:      	movq	$0x0, 0x50(%rsp)
   6c731:      	movq	$0x3, 0x38(%rsp)
   6c73a:      	xorl	%edi, %edi
   6c73c:      	leaq	-0xf(%r14), %rsi
   6c740:      	callq	0x6e9d0 <f.3>
   6c745:      	subq	$0x8, %rsp
   6c749:      	cmpb	$0x0, 0x7160(%rip)      # 0x738b0 <g.4>
   6c750:      	je	0x6e9c5 <f.2+0x17805>
   6c756:      	movq	%rax, 0x10(%rsp)
   6c75b:      	cmpq	$0x0, 0x7145(%rip)      # 0x738a8 <g.3>
   6c763:      	je	0x6e9c5 <f.2+0x17805>
   6c769:      	leaq	-0x10(%r14), %rsi
   6c76d:      	movq	$0x0, 0x50(%rsp)
   6c776:      	movq	$0x3, 0x38(%rsp)
   6c77f:      	xorl	%edi, %edi
   6c781:      	callq	0x6e9d0 <f.3>
   6c786:      	subq	$0x8, %rsp
   6c78a:      	cmpb	$0x0, 0x711f(%rip)      # 0x738b0 <g.4>
   6c791:      	je	0x6e9c5 <f.2+0x17805>
   6c797:      	movq	%rax, %rdx
   6c79a:      	cmpq	$0x0, 0x7106(%rip)      # 0x738a8 <g.3>
   6c7a2:      	leaq	0x28(%rsp), %r8
   6c7a7:      	leaq	0x20(%rsp), %rdi
   6c7ac:      	leaq	0x7015(%rip), %r9       # 0x737c8 <native_roots.0>
   6c7b3:      	movq	0x18(%rsp), %rax
   6c7b8:      	je	0x6e9c5 <f.2+0x17805>
   6c7be:      	addq	0x10(%rsp), %rdx
   6c7c3:      	addq	%rbp, %rdx
   6c7c6:      	cmpq	$0xe, %r14
   6c7ca:      	je	0x6c7de <f.2+0x1561e>
   6c7cc:      	cmpq	$0xf, %r14
   6c7d0:      	jne	0x6c7f5 <f.2+0x15635>
   6c7d2:      	movl	$0x1, %esi
   6c7d7:      	xorl	%ecx, %ecx
   6c7d9:      	jmp	0x6c930 <f.2+0x15770>
   6c7de:      	leaq	(%r14,%rdx), %rcx
   6c7e2:      	addq	$-0xd, %rcx
   6c7e6:      	movl	$0x1, %r10d
   6c7ec:      	leaq	-0xe(%r14), %rbp
   6c7f0:      	jmp	0x6cd4e <f.2+0x15b8e>
   6c7f5:      	movq	%rdx, 0x10(%rsp)
   6c7fa:      	leaq	-0xf(%r14), %rsi
   6c7fe:      	movq	$0x0, 0x50(%rsp)
   6c807:      	movq	$0x3, 0x38(%rsp)
   6c810:      	xorl	%edi, %edi
   6c812:      	callq	0x6e9d0 <f.3>
   6c817:      	subq	$0x8, %rsp
   6c81b:      	cmpb	$0x0, 0x708e(%rip)      # 0x738b0 <g.4>
   6c822:      	je	0x6e9c5 <f.2+0x17805>
   6c828:      	cmpq	$0x0, 0x7078(%rip)      # 0x738a8 <g.3>
   6c830:      	je	0x6e9c5 <f.2+0x17805>
   6c836:      	movq	%rax, %rbp
   6c839:      	leaq	-0x10(%r14), %rsi
   6c83d:      	movq	$0x0, 0x50(%rsp)
   6c846:      	movq	$0x3, 0x38(%rsp)
   6c84f:      	xorl	%edi, %edi
   6c851:      	callq	0x6e9d0 <f.3>
   6c856:      	subq	$0x8, %rsp
   6c85a:      	cmpb	$0x0, 0x704f(%rip)      # 0x738b0 <g.4>
   6c861:      	je	0x6e9c5 <f.2+0x17805>
   6c867:      	movq	%rax, %rsi
   6c86a:      	cmpq	$0x0, 0x7036(%rip)      # 0x738a8 <g.3>
   6c872:      	leaq	0x28(%rsp), %r8
   6c877:      	leaq	0x6f4a(%rip), %r9       # 0x737c8 <native_roots.0>
   6c87e:      	movq	0x18(%rsp), %rax
   6c883:      	leaq	-0xf(%r14), %rcx
   6c887:      	movq	0x10(%rsp), %rdx
   6c88c:      	je	0x6e9c5 <f.2+0x17805>
   6c892:      	addq	%rbp, %rsi
   6c895:      	cmpq	$0x11, %r14
   6c899:      	jae	0x6c8a5 <f.2+0x156e5>
   6c89b:      	leaq	0x20(%rsp), %rdi
   6c8a0:      	jmp	0x6c930 <f.2+0x15770>
   6c8a5:      	movq	%rsi, 0x58(%rsp)
   6c8aa:      	movq	$0x0, 0x50(%rsp)
   6c8b3:      	movq	$0x3, 0x38(%rsp)
   6c8bc:      	xorl	%edi, %edi
   6c8be:      	leaq	-0x10(%r14), %rsi
   6c8c2:      	callq	0x6e9d0 <f.3>
   6c8c7:      	subq	$0x8, %rsp
   6c8cb:      	cmpb	$0x0, 0x6fde(%rip)      # 0x738b0 <g.4>
   6c8d2:      	je	0x6e9c5 <f.2+0x17805>
   6c8d8:      	cmpq	$0x0, 0x6fc8(%rip)      # 0x738a8 <g.3>
   6c8e0:      	je	0x6e9c5 <f.2+0x17805>
   6c8e6:      	movq	%rax, %rbp
   6c8e9:      	leaq	-0x11(%r14), %rsi
   6c8ed:      	movq	$0x0, 0x50(%rsp)
   6c8f6:      	movq	$0x3, 0x38(%rsp)
   6c8ff:      	xorl	%edi, %edi
   6c901:      	callq	0x6e9d0 <f.3>
   6c906:      	subq	$0x8, %rsp
   6c90a:      	movq	%rax, %rcx
   6c90d:      	addq	%rbp, %rcx
   6c910:      	leaq	0x28(%rsp), %r8
   6c915:      	leaq	0x20(%rsp), %rdi
   6c91a:      	leaq	0x6ea7(%rip), %r9       # 0x737c8 <native_roots.0>
   6c921:      	movq	0x18(%rsp), %rax
   6c926:      	movq	0x10(%rsp), %rdx
   6c92b:      	movq	0x58(%rsp), %rsi
   6c930:      	cmpb	$0x0, 0x6f79(%rip)      # 0x738b0 <g.4>
   6c937:      	je	0x6e9c5 <f.2+0x17805>
   6c93d:      	cmpq	$0x0, 0x6f63(%rip)      # 0x738a8 <g.3>
   6c945:      	je	0x6e9c5 <f.2+0x17805>
   6c94b:      	addq	%rsi, %rcx
   6c94e:      	addq	%rdx, %rcx
   6c951:      	movq	%r14, %r10
   6c954:      	subq	$0xf, %r10
   6c958:      	jbe	0x6ca1d <f.2+0x1585d>
   6c95e:      	movq	%rcx, 0x58(%rsp)
   6c963:      	movq	$0x0, 0x50(%rsp)
   6c96c:      	movq	$0x3, 0x38(%rsp)
   6c975:      	xorl	%edi, %edi
   6c977:      	movq	%r10, 0x10(%rsp)
   6c97c:      	movq	%r10, %rsi
   6c97f:      	callq	0x6e9d0 <f.3>
   6c984:      	subq	$0x8, %rsp
   6c988:      	cmpb	$0x0, 0x6f21(%rip)      # 0x738b0 <g.4>
   6c98f:      	je	0x6e9c5 <f.2+0x17805>
   6c995:      	cmpq	$0x0, 0x6f0b(%rip)      # 0x738a8 <g.3>
   6c99d:      	je	0x6e9c5 <f.2+0x17805>
   6c9a3:      	movq	%rax, %rbp
   6c9a6:      	leaq	-0x10(%r14), %rsi
   6c9aa:      	movq	$0x0, 0x50(%rsp)
   6c9b3:      	movq	$0x3, 0x38(%rsp)
   6c9bc:      	xorl	%edi, %edi
   6c9be:      	callq	0x6e9d0 <f.3>
   6c9c3:      	subq	$0x8, %rsp
   6c9c7:      	cmpb	$0x0, 0x6ee2(%rip)      # 0x738b0 <g.4>
   6c9ce:      	je	0x6e9c5 <f.2+0x17805>
   6c9d4:      	movq	%rax, %rdx
   6c9d7:      	cmpq	$0x0, 0x6ec9(%rip)      # 0x738a8 <g.3>
   6c9df:      	leaq	0x28(%rsp), %r8
   6c9e4:      	leaq	0x20(%rsp), %rdi
   6c9e9:      	leaq	0x6dd8(%rip), %r9       # 0x737c8 <native_roots.0>
   6c9f0:      	movq	0x10(%rsp), %r10
   6c9f5:      	movq	0x18(%rsp), %rax
   6c9fa:      	movq	0x58(%rsp), %rcx
   6c9ff:      	je	0x6e9c5 <f.2+0x17805>
   6ca05:      	addq	%rbp, %rdx
   6ca08:      	cmpq	$0x10, %r14
   6ca0c:      	jne	0x6ca29 <f.2+0x15869>
   6ca0e:      	addq	%rdx, %r10
   6ca11:      	movl	$0x1, %ebp
   6ca16:      	xorl	%edx, %edx
   6ca18:      	jmp	0x6cd4b <f.2+0x15b8b>
   6ca1d:      	incq	%r10
   6ca20:      	leaq	-0xe(%r14), %rbp
   6ca24:      	jmp	0x6cd4e <f.2+0x15b8e>
   6ca29:      	movq	%rdx, 0x60(%rsp)
   6ca2e:      	movq	$0x0, 0x50(%rsp)
   6ca37:      	movq	$0x3, 0x38(%rsp)
   6ca40:      	xorl	%edi, %edi
   6ca42:      	leaq	-0x10(%r14), %rbp
   6ca46:      	movq	%rbp, %rsi
   6ca49:      	callq	0x6e9d0 <f.3>
   6ca4e:      	subq	$0x8, %rsp
   6ca52:      	cmpb	$0x0, 0x6e57(%rip)      # 0x738b0 <g.4>
   6ca59:      	je	0x6e9c5 <f.2+0x17805>
   6ca5f:      	movq	%rax, 0x68(%rsp)
   6ca64:      	cmpq	$0x0, 0x6e3c(%rip)      # 0x738a8 <g.3>
   6ca6c:      	je	0x6e9c5 <f.2+0x17805>
   6ca72:      	leaq	-0x11(%r14), %rsi
   6ca76:      	movq	$0x0, 0x50(%rsp)
   6ca7f:      	movq	$0x3, 0x38(%rsp)
   6ca88:      	xorl	%edi, %edi
   6ca8a:      	callq	0x6e9d0 <f.3>
   6ca8f:      	subq	$0x8, %rsp
   6ca93:      	cmpb	$0x0, 0x6e16(%rip)      # 0x738b0 <g.4>
   6ca9a:      	je	0x6e9c5 <f.2+0x17805>
   6caa0:      	movq	%rax, 0x10(%rsp)
   6caa5:      	cmpq	$0x0, 0x6dfb(%rip)      # 0x738a8 <g.3>
   6caad:      	je	0x6e9c5 <f.2+0x17805>
   6cab3:      	movq	$0x0, 0x50(%rsp)
   6cabc:      	movq	$0x3, 0x38(%rsp)
   6cac5:      	xorl	%edi, %edi
   6cac7:      	movq	%rbp, %rsi
   6caca:      	callq	0x6e9d0 <f.3>
   6cacf:      	subq	$0x8, %rsp
   6cad3:      	cmpb	$0x0, 0x6dd6(%rip)      # 0x738b0 <g.4>
   6cada:      	je	0x6e9c5 <f.2+0x17805>
   6cae0:      	movq	%rax, 0x70(%rsp)
   6cae5:      	cmpq	$0x0, 0x6dbb(%rip)      # 0x738a8 <g.3>
   6caed:      	je	0x6e9c5 <f.2+0x17805>
   6caf3:      	movq	$0x0, 0x50(%rsp)
   6cafc:      	movq	$0x3, 0x38(%rsp)
   6cb05:      	xorl	%edi, %edi
   6cb07:      	leaq	-0x11(%r14), %rsi
   6cb0b:      	callq	0x6e9d0 <f.3>
   6cb10:      	subq	$0x8, %rsp
   6cb14:      	cmpb	$0x0, 0x6d95(%rip)      # 0x738b0 <g.4>
   6cb1b:      	je	0x6e9c5 <f.2+0x17805>
   6cb21:      	movq	%rax, %rbp
   6cb24:      	cmpq	$0x0, 0x6d7c(%rip)      # 0x738a8 <g.3>
   6cb2c:      	leaq	0x28(%rsp), %r8
   6cb31:      	leaq	0x20(%rsp), %rdi
   6cb36:      	leaq	0x6c8b(%rip), %r9       # 0x737c8 <native_roots.0>
   6cb3d:      	movq	0x10(%rsp), %r10
   6cb42:      	movq	0x18(%rsp), %rax
   6cb47:      	movq	0x58(%rsp), %rcx
   6cb4c:      	movq	0x60(%rsp), %rdx
   6cb51:      	je	0x6e9c5 <f.2+0x17805>
   6cb57:      	addq	0x68(%rsp), %r10
   6cb5c:      	addq	%rdx, %r10
   6cb5f:      	addq	0x70(%rsp), %rbp
   6cb64:      	cmpq	$0x12, %r14
   6cb68:      	jae	0x6ccbc <f.2+0x15afc>
   6cb6e:      	leaq	-0x10(%r14), %rdx
   6cb72:      	jmp	0x6cd4b <f.2+0x15b8b>
   6cb77:      	movq	%rcx, 0x60(%rsp)
   6cb7c:      	movq	$0x0, 0x50(%rsp)
   6cb85:      	movq	$0x3, 0x38(%rsp)
   6cb8e:      	xorl	%edi, %edi
   6cb90:      	callq	0x6e9d0 <f.3>
   6cb95:      	subq	$0x8, %rsp
   6cb99:      	cmpb	$0x0, 0x6d10(%rip)      # 0x738b0 <g.4>
   6cba0:      	je	0x6e9c5 <f.2+0x17805>
   6cba6:      	movq	%rax, 0x68(%rsp)
   6cbab:      	cmpq	$0x0, 0x6cf5(%rip)      # 0x738a8 <g.3>
   6cbb3:      	je	0x6e9c5 <f.2+0x17805>
   6cbb9:      	leaq	-0x12(%r14), %rsi
   6cbbd:      	movq	$0x0, 0x50(%rsp)
   6cbc6:      	movq	$0x3, 0x38(%rsp)
   6cbcf:      	xorl	%edi, %edi
   6cbd1:      	callq	0x6e9d0 <f.3>
   6cbd6:      	subq	$0x8, %rsp
   6cbda:      	cmpb	$0x0, 0x6ccf(%rip)      # 0x738b0 <g.4>
   6cbe1:      	je	0x6e9c5 <f.2+0x17805>
   6cbe7:      	movq	%rax, 0x58(%rsp)
   6cbec:      	cmpq	$0x0, 0x6cb4(%rip)      # 0x738a8 <g.3>
   6cbf4:      	leaq	-0x11(%r14), %rsi
   6cbf8:      	je	0x6e9c5 <f.2+0x17805>
   6cbfe:      	movq	$0x0, 0x50(%rsp)
   6cc07:      	movq	$0x3, 0x38(%rsp)
   6cc10:      	xorl	%edi, %edi
   6cc12:      	callq	0x6e9d0 <f.3>
   6cc17:      	subq	$0x8, %rsp
   6cc1b:      	cmpb	$0x0, 0x6c8e(%rip)      # 0x738b0 <g.4>
   6cc22:      	je	0x6e9c5 <f.2+0x17805>
   6cc28:      	movq	%rax, 0x70(%rsp)
   6cc2d:      	cmpq	$0x0, 0x6c73(%rip)      # 0x738a8 <g.3>
   6cc35:      	je	0x6e9c5 <f.2+0x17805>
   6cc3b:      	movq	$0x0, 0x50(%rsp)
   6cc44:      	movq	$0x3, 0x38(%rsp)
   6cc4d:      	xorl	%edi, %edi
   6cc4f:      	leaq	-0x12(%r14), %rsi
   6cc53:      	callq	0x6e9d0 <f.3>
   6cc58:      	subq	$0x8, %rsp
   6cc5c:      	cmpb	$0x0, 0x6c4d(%rip)      # 0x738b0 <g.4>
   6cc63:      	je	0x6e9c5 <f.2+0x17805>
   6cc69:      	movq	%rax, %rsi
   6cc6c:      	cmpq	$0x0, 0x6c34(%rip)      # 0x738a8 <g.3>
   6cc74:      	leaq	0x28(%rsp), %r8
   6cc79:      	leaq	0x6b48(%rip), %r9       # 0x737c8 <native_roots.0>
   6cc80:      	movq	0x18(%rsp), %rax
   6cc85:      	movq	0x58(%rsp), %rdx
   6cc8a:      	leaq	-0x11(%r14), %rcx
   6cc8e:      	je	0x6e9c5 <f.2+0x17805>
   6cc94:      	addq	0x68(%rsp), %rdx
   6cc99:      	addq	0x60(%rsp), %rdx
   6cc9e:      	addq	0x70(%rsp), %rsi
   6cca3:      	cmpq	$0x13, %r14
   6cca7:      	jae	0x6cd92 <f.2+0x15bd2>
   6ccad:      	leaq	0x20(%rsp), %rdi
   6ccb2:      	movq	0x10(%rsp), %r10
   6ccb7:      	jmp	0x6ce2b <f.2+0x15c6b>
   6ccbc:      	movq	%r10, 0x10(%rsp)
   6ccc1:      	movq	$0x0, 0x50(%rsp)
   6ccca:      	movq	$0x3, 0x38(%rsp)
   6ccd3:      	xorl	%edi, %edi
   6ccd5:      	leaq	-0x11(%r14), %rsi
   6ccd9:      	callq	0x6e9d0 <f.3>
   6ccde:      	subq	$0x8, %rsp
   6cce2:      	cmpb	$0x0, 0x6bc7(%rip)      # 0x738b0 <g.4>
   6cce9:      	je	0x6e9c5 <f.2+0x17805>
   6ccef:      	movq	%rax, 0x60(%rsp)
   6ccf4:      	cmpq	$0x0, 0x6bac(%rip)      # 0x738a8 <g.3>
   6ccfc:      	je	0x6e9c5 <f.2+0x17805>
   6cd02:      	leaq	-0x12(%r14), %rsi
   6cd06:      	movq	$0x0, 0x50(%rsp)
   6cd0f:      	movq	$0x3, 0x38(%rsp)
   6cd18:      	xorl	%edi, %edi
   6cd1a:      	callq	0x6e9d0 <f.3>
   6cd1f:      	subq	$0x8, %rsp
   6cd23:      	movq	%rax, %rdx
   6cd26:      	addq	0x60(%rsp), %rdx
   6cd2b:      	leaq	0x28(%rsp), %r8
   6cd30:      	leaq	0x20(%rsp), %rdi
   6cd35:      	leaq	0x6a8c(%rip), %r9       # 0x737c8 <native_roots.0>
   6cd3c:      	movq	0x10(%rsp), %r10
   6cd41:      	movq	0x18(%rsp), %rax
   6cd46:      	movq	0x58(%rsp), %rcx
   6cd4b:      	addq	%rdx, %rbp
   6cd4e:      	addq	%rbp, %r10
   6cd51:      	cmpb	$0x0, 0x6b58(%rip)      # 0x738b0 <g.4>
   6cd58:      	je	0x6e9c5 <f.2+0x17805>
   6cd5e:      	cmpq	$0x0, 0x6b42(%rip)      # 0x738a8 <g.3>
   6cd66:      	je	0x6e9c5 <f.2+0x17805>
   6cd6c:      	addq	%rcx, %r10
   6cd6f:      	addq	%rax, %r10
   6cd72:      	cmpq	$0xa, %r14
   6cd76:      	jne	0x6b7c8 <f.2+0x14608>
   6cd7c:      	leaq	(%r14,%r10), %rbp
   6cd80:      	addq	$-0x9, %rbp
   6cd84:      	movl	$0x1, %ecx
   6cd89:      	addq	$-0xa, %r14
   6cd8d:      	jmp	0x6e8ee <f.2+0x1772e>
   6cd92:      	movq	%rsi, 0x60(%rsp)
   6cd97:      	movq	%rdx, 0x58(%rsp)
   6cd9c:      	movq	$0x0, 0x50(%rsp)
   6cda5:      	movq	$0x3, 0x38(%rsp)
   6cdae:      	xorl	%edi, %edi
   6cdb0:      	leaq	-0x12(%r14), %rsi
   6cdb4:      	callq	0x6e9d0 <f.3>
   6cdb9:      	subq	$0x8, %rsp
   6cdbd:      	cmpb	$0x0, 0x6aec(%rip)      # 0x738b0 <g.4>
   6cdc4:      	je	0x6e9c5 <f.2+0x17805>
   6cdca:      	movq	%rax, 0x68(%rsp)
   6cdcf:      	cmpq	$0x0, 0x6ad1(%rip)      # 0x738a8 <g.3>
   6cdd7:      	je	0x6e9c5 <f.2+0x17805>
   6cddd:      	leaq	-0x13(%r14), %rsi
   6cde1:      	movq	$0x0, 0x50(%rsp)
   6cdea:      	movq	$0x3, 0x38(%rsp)
   6cdf3:      	xorl	%edi, %edi
   6cdf5:      	callq	0x6e9d0 <f.3>
   6cdfa:      	subq	$0x8, %rsp
   6cdfe:      	movq	%rax, %rcx
   6ce01:      	addq	0x68(%rsp), %rcx
   6ce06:      	leaq	0x28(%rsp), %r8
   6ce0b:      	leaq	0x20(%rsp), %rdi
   6ce10:      	leaq	0x69b1(%rip), %r9       # 0x737c8 <native_roots.0>
   6ce17:      	movq	0x10(%rsp), %r10
   6ce1c:      	movq	0x18(%rsp), %rax
   6ce21:      	movq	0x58(%rsp), %rdx
   6ce26:      	movq	0x60(%rsp), %rsi
   6ce2b:      	addq	%rcx, %rsi
   6ce2e:      	addq	%rsi, %rdx
   6ce31:      	addq	%rdx, %rbp
   6ce34:      	cmpb	$0x0, 0x6a75(%rip)      # 0x738b0 <g.4>
   6ce3b:      	je	0x6e9c5 <f.2+0x17805>
   6ce41:      	cmpq	$0x0, 0x6a5f(%rip)      # 0x738a8 <g.3>
   6ce49:      	je	0x6e9c5 <f.2+0x17805>
   6ce4f:      	movl	$0x1, %edx
   6ce54:      	cmpq	$0xc, %r14
   6ce58:      	jb	0x6d487 <f.2+0x162c7>
   6ce5e:      	movl	$0x1, %ecx
   6ce63:      	je	0x6ce86 <f.2+0x15cc6>
   6ce65:      	cmpq	$0xd, %r14
   6ce69:      	jbe	0x6ce82 <f.2+0x15cc2>
   6ce6b:      	cmpq	$0xe, %r14
   6ce6f:      	movq	%r10, 0x10(%rsp)
   6ce74:      	movq	%rax, 0x18(%rsp)
   6ce79:      	jne	0x6ce93 <f.2+0x15cd3>
   6ce7b:      	xorl	%edx, %edx
   6ce7d:      	jmp	0x6cfec <f.2+0x15e2c>
   6ce82:      	leaq	-0xc(%r14), %rcx
   6ce86:      	leaq	(%r14,%rcx), %rdx
   6ce8a:      	addq	$-0xc, %rdx
   6ce8e:      	jmp	0x6d47b <f.2+0x162bb>
   6ce93:      	leaq	-0xe(%r14), %rsi
   6ce97:      	movq	$0x0, 0x50(%rsp)
   6cea0:      	movq	$0x3, 0x38(%rsp)
   6cea9:      	xorl	%edi, %edi
   6ceab:      	callq	0x6e9d0 <f.3>
   6ceb0:      	subq	$0x8, %rsp
   6ceb4:      	cmpb	$0x0, 0x69f5(%rip)      # 0x738b0 <g.4>
   6cebb:      	je	0x6e9c5 <f.2+0x17805>
   6cec1:      	movq	%rax, 0x58(%rsp)
   6cec6:      	cmpq	$0x0, 0x69da(%rip)      # 0x738a8 <g.3>
   6cece:      	je	0x6e9c5 <f.2+0x17805>
   6ced4:      	leaq	-0xf(%r14), %rsi
   6ced8:      	movq	$0x0, 0x50(%rsp)
   6cee1:      	movq	$0x3, 0x38(%rsp)
   6ceea:      	xorl	%edi, %edi
   6ceec:      	callq	0x6e9d0 <f.3>
   6cef1:      	subq	$0x8, %rsp
   6cef5:      	cmpb	$0x0, 0x69b4(%rip)      # 0x738b0 <g.4>
   6cefc:      	je	0x6e9c5 <f.2+0x17805>
   6cf02:      	cmpq	$0x0, 0x699e(%rip)      # 0x738a8 <g.3>
   6cf0a:      	movq	0x10(%rsp), %r10
   6cf0f:      	leaq	-0xe(%r14), %rdx
   6cf13:      	je	0x6e9c5 <f.2+0x17805>
   6cf19:      	movq	%rax, %rcx
   6cf1c:      	addq	0x58(%rsp), %rcx
   6cf21:      	cmpq	$0xf, %r14
   6cf25:      	ja	0x6cf42 <f.2+0x15d82>
   6cf27:      	leaq	0x28(%rsp), %r8
   6cf2c:      	leaq	0x20(%rsp), %rdi
   6cf31:      	leaq	0x6890(%rip), %r9       # 0x737c8 <native_roots.0>
   6cf38:      	movq	0x18(%rsp), %rax
   6cf3d:      	jmp	0x6cfec <f.2+0x15e2c>
   6cf42:      	movq	%rcx, 0x58(%rsp)
   6cf47:      	movq	$0x0, 0x50(%rsp)
   6cf50:      	movq	$0x3, 0x38(%rsp)
   6cf59:      	xorl	%edi, %edi
   6cf5b:      	leaq	-0xf(%r14), %rsi
   6cf5f:      	callq	0x6e9d0 <f.3>
   6cf64:      	subq	$0x8, %rsp
   6cf68:      	cmpb	$0x0, 0x6941(%rip)      # 0x738b0 <g.4>
   6cf6f:      	je	0x6e9c5 <f.2+0x17805>
   6cf75:      	movq	%rax, 0x60(%rsp)
   6cf7a:      	cmpq	$0x0, 0x6926(%rip)      # 0x738a8 <g.3>
   6cf82:      	je	0x6e9c5 <f.2+0x17805>
   6cf88:      	leaq	-0x10(%r14), %rsi
   6cf8c:      	movq	$0x0, 0x50(%rsp)
   6cf95:      	movq	$0x3, 0x38(%rsp)
   6cf9e:      	xorl	%edi, %edi
   6cfa0:      	callq	0x6e9d0 <f.3>
   6cfa5:      	subq	$0x8, %rsp
   6cfa9:      	cmpb	$0x0, 0x6900(%rip)      # 0x738b0 <g.4>
   6cfb0:      	je	0x6e9c5 <f.2+0x17805>
   6cfb6:      	movq	%rax, %rdx
   6cfb9:      	cmpq	$0x0, 0x68e7(%rip)      # 0x738a8 <g.3>
   6cfc1:      	leaq	0x28(%rsp), %r8
   6cfc6:      	leaq	0x20(%rsp), %rdi
   6cfcb:      	leaq	0x67f6(%rip), %r9       # 0x737c8 <native_roots.0>
   6cfd2:      	movq	0x10(%rsp), %r10
   6cfd7:      	movq	0x18(%rsp), %rax
   6cfdc:      	movq	0x58(%rsp), %rcx
   6cfe1:      	je	0x6e9c5 <f.2+0x17805>
   6cfe7:      	addq	0x60(%rsp), %rdx
   6cfec:      	addq	%rcx, %rdx
   6cfef:      	cmpq	$0xe, %r14
   6cff3:      	je	0x6d008 <f.2+0x15e48>
   6cff5:      	cmpq	$0xf, %r14
   6cff9:      	jne	0x6d01e <f.2+0x15e5e>
   6cffb:      	movl	$0x1, %r11d
   6d001:      	xorl	%esi, %esi
   6d003:      	jmp	0x6d16a <f.2+0x15faa>
   6d008:      	leaq	(%r14,%rdx), %rsi
   6d00c:      	addq	$-0xd, %rsi
   6d010:      	movl	$0x1, %ecx
   6d015:      	leaq	-0xe(%r14), %rdx
   6d019:      	jmp	0x6d45a <f.2+0x1629a>
   6d01e:      	movq	%rdx, 0x58(%rsp)
   6d023:      	leaq	-0xf(%r14), %rsi
   6d027:      	movq	$0x0, 0x50(%rsp)
   6d030:      	movq	$0x3, 0x38(%rsp)
   6d039:      	xorl	%edi, %edi
   6d03b:      	callq	0x6e9d0 <f.3>
   6d040:      	subq	$0x8, %rsp
   6d044:      	cmpb	$0x0, 0x6865(%rip)      # 0x738b0 <g.4>
   6d04b:      	je	0x6e9c5 <f.2+0x17805>
   6d051:      	movq	%rax, 0x60(%rsp)
   6d056:      	cmpq	$0x0, 0x684a(%rip)      # 0x738a8 <g.3>
   6d05e:      	je	0x6e9c5 <f.2+0x17805>
   6d064:      	leaq	-0x10(%r14), %rsi
   6d068:      	movq	$0x0, 0x50(%rsp)
   6d071:      	movq	$0x3, 0x38(%rsp)
   6d07a:      	xorl	%edi, %edi
   6d07c:      	callq	0x6e9d0 <f.3>
   6d081:      	subq	$0x8, %rsp
   6d085:      	cmpb	$0x0, 0x6824(%rip)      # 0x738b0 <g.4>
   6d08c:      	je	0x6e9c5 <f.2+0x17805>
   6d092:      	movq	%rax, %r11
   6d095:      	cmpq	$0x0, 0x680b(%rip)      # 0x738a8 <g.3>
   6d09d:      	leaq	0x28(%rsp), %r8
   6d0a2:      	leaq	0x20(%rsp), %rdi
   6d0a7:      	leaq	0x671a(%rip), %r9       # 0x737c8 <native_roots.0>
   6d0ae:      	movq	0x10(%rsp), %r10
   6d0b3:      	movq	0x18(%rsp), %rax
   6d0b8:      	leaq	-0xf(%r14), %rsi
   6d0bc:      	movq	0x58(%rsp), %rdx
   6d0c1:      	je	0x6e9c5 <f.2+0x17805>
   6d0c7:      	addq	0x60(%rsp), %r11
   6d0cc:      	cmpq	$0x11, %r14
   6d0d0:      	jb	0x6d16a <f.2+0x15faa>
   6d0d6:      	movq	%r11, 0x60(%rsp)
   6d0db:      	movq	$0x0, 0x50(%rsp)
   6d0e4:      	movq	$0x3, 0x38(%rsp)
   6d0ed:      	xorl	%edi, %edi
   6d0ef:      	leaq	-0x10(%r14), %rsi
   6d0f3:      	callq	0x6e9d0 <f.3>
   6d0f8:      	subq	$0x8, %rsp
   6d0fc:      	cmpb	$0x0, 0x67ad(%rip)      # 0x738b0 <g.4>
   6d103:      	je	0x6e9c5 <f.2+0x17805>
   6d109:      	movq	%rax, 0x68(%rsp)
   6d10e:      	cmpq	$0x0, 0x6792(%rip)      # 0x738a8 <g.3>
   6d116:      	je	0x6e9c5 <f.2+0x17805>
   6d11c:      	leaq	-0x11(%r14), %rsi
   6d120:      	movq	$0x0, 0x50(%rsp)
   6d129:      	movq	$0x3, 0x38(%rsp)
   6d132:      	xorl	%edi, %edi
   6d134:      	callq	0x6e9d0 <f.3>
   6d139:      	subq	$0x8, %rsp
   6d13d:      	movq	%rax, %rsi
   6d140:      	addq	0x68(%rsp), %rsi
   6d145:      	leaq	0x28(%rsp), %r8
   6d14a:      	leaq	0x20(%rsp), %rdi
   6d14f:      	leaq	0x6672(%rip), %r9       # 0x737c8 <native_roots.0>
   6d156:      	movq	0x10(%rsp), %r10
   6d15b:      	movq	0x18(%rsp), %rax
   6d160:      	movq	0x58(%rsp), %rdx
   6d165:      	movq	0x60(%rsp), %r11
   6d16a:      	cmpb	$0x0, 0x673f(%rip)      # 0x738b0 <g.4>
   6d171:      	je	0x6e9c5 <f.2+0x17805>
   6d177:      	cmpq	$0x0, 0x6729(%rip)      # 0x738a8 <g.3>
   6d17f:      	je	0x6e9c5 <f.2+0x17805>
   6d185:      	addq	%r11, %rsi
   6d188:      	addq	%rdx, %rsi
   6d18b:      	movq	%r14, %rcx
   6d18e:      	subq	$0xf, %rcx
   6d192:      	jbe	0x6d268 <f.2+0x160a8>
   6d198:      	movq	%rsi, 0x68(%rsp)
   6d19d:      	movq	$0x0, 0x50(%rsp)
   6d1a6:      	movq	$0x3, 0x38(%rsp)
   6d1af:      	xorl	%edi, %edi
   6d1b1:      	movq	%rcx, 0x58(%rsp)
   6d1b6:      	movq	%rcx, %rsi
   6d1b9:      	callq	0x6e9d0 <f.3>
   6d1be:      	subq	$0x8, %rsp
   6d1c2:      	cmpb	$0x0, 0x66e7(%rip)      # 0x738b0 <g.4>
   6d1c9:      	je	0x6e9c5 <f.2+0x17805>
   6d1cf:      	movq	%rax, 0x60(%rsp)
   6d1d4:      	cmpq	$0x0, 0x66cc(%rip)      # 0x738a8 <g.3>
   6d1dc:      	je	0x6e9c5 <f.2+0x17805>
   6d1e2:      	leaq	-0x10(%r14), %rsi
   6d1e6:      	movq	$0x0, 0x50(%rsp)
   6d1ef:      	movq	$0x3, 0x38(%rsp)
   6d1f8:      	xorl	%edi, %edi
   6d1fa:      	callq	0x6e9d0 <f.3>
   6d1ff:      	subq	$0x8, %rsp
   6d203:      	cmpb	$0x0, 0x66a6(%rip)      # 0x738b0 <g.4>
   6d20a:      	je	0x6e9c5 <f.2+0x17805>
   6d210:      	movq	%rax, %rdx
   6d213:      	cmpq	$0x0, 0x668d(%rip)      # 0x738a8 <g.3>
   6d21b:      	leaq	0x28(%rsp), %r8
   6d220:      	leaq	0x20(%rsp), %rdi
   6d225:      	leaq	0x659c(%rip), %r9       # 0x737c8 <native_roots.0>
   6d22c:      	movq	0x10(%rsp), %r10
   6d231:      	movq	0x18(%rsp), %rax
   6d236:      	movq	0x68(%rsp), %r11
   6d23b:      	movq	0x58(%rsp), %rcx
   6d240:      	je	0x6e9c5 <f.2+0x17805>
   6d246:      	addq	0x60(%rsp), %rdx
   6d24b:      	cmpq	$0x10, %r14
   6d24f:      	leaq	-0x10(%r14), %rsi
   6d253:      	jne	0x6d274 <f.2+0x160b4>
   6d255:      	addq	%rdx, %rcx
   6d258:      	movl	$0x1, %edx
   6d25d:      	movq	%r11, %rsi
   6d260:      	xorl	%r11d, %r11d
   6d263:      	jmp	0x6d457 <f.2+0x16297>
   6d268:      	incq	%rcx
   6d26b:      	leaq	-0xe(%r14), %rdx
   6d26f:      	jmp	0x6d45a <f.2+0x1629a>
   6d274:      	movq	%rdx, 0x60(%rsp)
   6d279:      	movq	$0x0, 0x50(%rsp)
   6d282:      	movq	$0x3, 0x38(%rsp)
   6d28b:      	xorl	%edi, %edi
   6d28d:      	callq	0x6e9d0 <f.3>
   6d292:      	subq	$0x8, %rsp
   6d296:      	cmpb	$0x0, 0x6613(%rip)      # 0x738b0 <g.4>
   6d29d:      	je	0x6e9c5 <f.2+0x17805>
   6d2a3:      	movq	%rax, 0x70(%rsp)
   6d2a8:      	cmpq	$0x0, 0x65f8(%rip)      # 0x738a8 <g.3>
   6d2b0:      	je	0x6e9c5 <f.2+0x17805>
   6d2b6:      	leaq	-0x11(%r14), %rsi
   6d2ba:      	movq	$0x0, 0x50(%rsp)
   6d2c3:      	movq	$0x3, 0x38(%rsp)
   6d2cc:      	xorl	%edi, %edi
   6d2ce:      	callq	0x6e9d0 <f.3>
   6d2d3:      	subq	$0x8, %rsp
   6d2d7:      	cmpb	$0x0, 0x65d2(%rip)      # 0x738b0 <g.4>
   6d2de:      	je	0x6e9c5 <f.2+0x17805>
   6d2e4:      	movq	%rax, 0x58(%rsp)
   6d2e9:      	cmpq	$0x0, 0x65b7(%rip)      # 0x738a8 <g.3>
   6d2f1:      	leaq	-0x10(%r14), %rsi
   6d2f5:      	je	0x6e9c5 <f.2+0x17805>
   6d2fb:      	movq	$0x0, 0x50(%rsp)
   6d304:      	movq	$0x3, 0x38(%rsp)
   6d30d:      	xorl	%edi, %edi
   6d30f:      	callq	0x6e9d0 <f.3>
   6d314:      	subq	$0x8, %rsp
   6d318:      	cmpb	$0x0, 0x6591(%rip)      # 0x738b0 <g.4>
   6d31f:      	je	0x6e9c5 <f.2+0x17805>
   6d325:      	movq	%rax, 0x78(%rsp)
   6d32a:      	cmpq	$0x0, 0x6576(%rip)      # 0x738a8 <g.3>
   6d332:      	je	0x6e9c5 <f.2+0x17805>
   6d338:      	movq	$0x0, 0x50(%rsp)
   6d341:      	movq	$0x3, 0x38(%rsp)
   6d34a:      	xorl	%edi, %edi
   6d34c:      	leaq	-0x11(%r14), %rsi
   6d350:      	callq	0x6e9d0 <f.3>
   6d355:      	subq	$0x8, %rsp
   6d359:      	cmpb	$0x0, 0x6550(%rip)      # 0x738b0 <g.4>
   6d360:      	je	0x6e9c5 <f.2+0x17805>
   6d366:      	movq	%rax, %rdx
   6d369:      	cmpq	$0x0, 0x6537(%rip)      # 0x738a8 <g.3>
   6d371:      	leaq	0x28(%rsp), %r8
   6d376:      	leaq	0x20(%rsp), %rdi
   6d37b:      	leaq	0x6446(%rip), %r9       # 0x737c8 <native_roots.0>
   6d382:      	movq	0x10(%rsp), %r10
   6d387:      	movq	0x18(%rsp), %rax
   6d38c:      	movq	0x68(%rsp), %rsi
   6d391:      	movq	0x58(%rsp), %rcx
   6d396:      	leaq	-0x10(%r14), %r11
   6d39a:      	je	0x6e9c5 <f.2+0x17805>
   6d3a0:      	addq	0x70(%rsp), %rcx
   6d3a5:      	addq	0x60(%rsp), %rcx
   6d3aa:      	addq	0x78(%rsp), %rdx
   6d3af:      	cmpq	$0x12, %r14
   6d3b3:      	jb	0x6d457 <f.2+0x16297>
   6d3b9:      	movq	%rcx, 0x58(%rsp)
   6d3be:      	movq	%rdx, 0x60(%rsp)
   6d3c3:      	movq	$0x0, 0x50(%rsp)
   6d3cc:      	movq	$0x3, 0x38(%rsp)
   6d3d5:      	xorl	%edi, %edi
   6d3d7:      	leaq	-0x11(%r14), %rsi
   6d3db:      	callq	0x6e9d0 <f.3>
   6d3e0:      	subq	$0x8, %rsp
   6d3e4:      	cmpb	$0x0, 0x64c5(%rip)      # 0x738b0 <g.4>
   6d3eb:      	je	0x6e9c5 <f.2+0x17805>
   6d3f1:      	movq	%rax, 0x70(%rsp)
   6d3f6:      	cmpq	$0x0, 0x64aa(%rip)      # 0x738a8 <g.3>
   6d3fe:      	je	0x6e9c5 <f.2+0x17805>
   6d404:      	leaq	-0x12(%r14), %rsi
   6d408:      	movq	$0x0, 0x50(%rsp)
   6d411:      	movq	$0x3, 0x38(%rsp)
   6d41a:      	xorl	%edi, %edi
   6d41c:      	callq	0x6e9d0 <f.3>
   6d421:      	subq	$0x8, %rsp
   6d425:      	movq	%rax, %r11
   6d428:      	addq	0x70(%rsp), %r11
   6d42d:      	leaq	0x28(%rsp), %r8
   6d432:      	leaq	0x20(%rsp), %rdi
   6d437:      	leaq	0x638a(%rip), %r9       # 0x737c8 <native_roots.0>
   6d43e:      	movq	0x10(%rsp), %r10
   6d443:      	movq	0x18(%rsp), %rax
   6d448:      	movq	0x60(%rsp), %rdx
   6d44d:      	movq	0x68(%rsp), %rsi
   6d452:      	movq	0x58(%rsp), %rcx
   6d457:      	addq	%r11, %rdx
   6d45a:      	cmpb	$0x0, 0x644f(%rip)      # 0x738b0 <g.4>
   6d461:      	je	0x6e9c5 <f.2+0x17805>
   6d467:      	cmpq	$0x0, 0x6439(%rip)      # 0x738a8 <g.3>
   6d46f:      	je	0x6e9c5 <f.2+0x17805>
   6d475:      	addq	%rcx, %rdx
   6d478:      	addq	%rsi, %rdx
   6d47b:      	cmpq	$0xd, %r14
   6d47f:      	je	0x6d490 <f.2+0x162d0>
   6d481:      	cmpq	$0xc, %r14
   6d485:      	jne	0x6d49e <f.2+0x162de>
   6d487:      	leaq	-0xb(%r14), %rcx
   6d48b:      	jmp	0x6db14 <f.2+0x16954>
   6d490:      	movl	$0x1, %ecx
   6d495:      	leaq	-0xd(%r14), %rsi
   6d499:      	jmp	0x6db11 <f.2+0x16951>
   6d49e:      	cmpq	$0xe, %r14
   6d4a2:      	jbe	0x6d4c5 <f.2+0x16305>
   6d4a4:      	cmpq	$0xf, %r14
   6d4a8:      	movq	%rdx, 0x60(%rsp)
   6d4ad:      	movq	%r10, 0x10(%rsp)
   6d4b2:      	movq	%rax, 0x18(%rsp)
   6d4b7:      	jne	0x6d4d2 <f.2+0x16312>
   6d4b9:      	movl	$0x1, %esi
   6d4be:      	xorl	%ecx, %ecx
   6d4c0:      	jmp	0x6d635 <f.2+0x16475>
   6d4c5:      	leaq	-0xd(%r14), %rcx
   6d4c9:      	leaq	-0xd(%r14), %rsi
   6d4cd:      	jmp	0x6db11 <f.2+0x16951>
   6d4d2:      	leaq	-0xf(%r14), %rsi
   6d4d6:      	movq	$0x0, 0x50(%rsp)
   6d4df:      	movq	$0x3, 0x38(%rsp)
   6d4e8:      	xorl	%edi, %edi
   6d4ea:      	callq	0x6e9d0 <f.3>
   6d4ef:      	subq	$0x8, %rsp
   6d4f3:      	cmpb	$0x0, 0x63b6(%rip)      # 0x738b0 <g.4>
   6d4fa:      	je	0x6e9c5 <f.2+0x17805>
   6d500:      	movq	%rax, 0x58(%rsp)
   6d505:      	cmpq	$0x0, 0x639b(%rip)      # 0x738a8 <g.3>
   6d50d:      	je	0x6e9c5 <f.2+0x17805>
   6d513:      	leaq	-0x10(%r14), %rsi
   6d517:      	movq	$0x0, 0x50(%rsp)
   6d520:      	movq	$0x3, 0x38(%rsp)
   6d529:      	xorl	%edi, %edi
   6d52b:      	callq	0x6e9d0 <f.3>
   6d530:      	subq	$0x8, %rsp
   6d534:      	cmpb	$0x0, 0x6375(%rip)      # 0x738b0 <g.4>
   6d53b:      	je	0x6e9c5 <f.2+0x17805>
   6d541:      	cmpq	$0x0, 0x635f(%rip)      # 0x738a8 <g.3>
   6d549:      	movq	0x10(%rsp), %r10
   6d54e:      	movq	0x60(%rsp), %rdx
   6d553:      	leaq	-0xf(%r14), %rcx
   6d557:      	je	0x6e9c5 <f.2+0x17805>
   6d55d:      	movq	%rax, %rsi
   6d560:      	addq	0x58(%rsp), %rsi
   6d565:      	cmpq	$0x10, %r14
   6d569:      	ja	0x6d586 <f.2+0x163c6>
   6d56b:      	leaq	0x28(%rsp), %r8
   6d570:      	leaq	0x20(%rsp), %rdi
   6d575:      	leaq	0x624c(%rip), %r9       # 0x737c8 <native_roots.0>
   6d57c:      	movq	0x18(%rsp), %rax
   6d581:      	jmp	0x6d635 <f.2+0x16475>
   6d586:      	movq	%rsi, 0x58(%rsp)
   6d58b:      	movq	$0x0, 0x50(%rsp)
   6d594:      	movq	$0x3, 0x38(%rsp)
   6d59d:      	xorl	%edi, %edi
   6d59f:      	leaq	-0x10(%r14), %rsi
   6d5a3:      	callq	0x6e9d0 <f.3>
   6d5a8:      	subq	$0x8, %rsp
   6d5ac:      	cmpb	$0x0, 0x62fd(%rip)      # 0x738b0 <g.4>
   6d5b3:      	je	0x6e9c5 <f.2+0x17805>
   6d5b9:      	movq	%rax, 0x68(%rsp)
   6d5be:      	cmpq	$0x0, 0x62e2(%rip)      # 0x738a8 <g.3>
   6d5c6:      	je	0x6e9c5 <f.2+0x17805>
   6d5cc:      	leaq	-0x11(%r14), %rsi
   6d5d0:      	movq	$0x0, 0x50(%rsp)
   6d5d9:      	movq	$0x3, 0x38(%rsp)
   6d5e2:      	xorl	%edi, %edi
   6d5e4:      	callq	0x6e9d0 <f.3>
   6d5e9:      	subq	$0x8, %rsp
   6d5ed:      	cmpb	$0x0, 0x62bc(%rip)      # 0x738b0 <g.4>
   6d5f4:      	je	0x6e9c5 <f.2+0x17805>
   6d5fa:      	movq	%rax, %rcx
   6d5fd:      	cmpq	$0x0, 0x62a3(%rip)      # 0x738a8 <g.3>
   6d605:      	leaq	0x28(%rsp), %r8
   6d60a:      	leaq	0x20(%rsp), %rdi
   6d60f:      	leaq	0x61b2(%rip), %r9       # 0x737c8 <native_roots.0>
   6d616:      	movq	0x10(%rsp), %r10
   6d61b:      	movq	0x18(%rsp), %rax
   6d620:      	movq	0x60(%rsp), %rdx
   6d625:      	movq	0x58(%rsp), %rsi
   6d62a:      	je	0x6e9c5 <f.2+0x17805>
   6d630:      	addq	0x68(%rsp), %rcx
   6d635:      	addq	%rsi, %rcx
   6d638:      	cmpq	$0xf, %r14
   6d63c:      	je	0x6d655 <f.2+0x16495>
   6d63e:      	movq	%rcx, 0x78(%rsp)
   6d643:      	cmpq	$0x10, %r14
   6d647:      	jne	0x6d66a <f.2+0x164aa>
   6d649:      	movl	$0x1, %esi
   6d64e:      	xorl	%ecx, %ecx
   6d650:      	jmp	0x6d7b2 <f.2+0x165f2>
   6d655:      	addq	%r14, %rcx
   6d658:      	addq	$-0xe, %rcx
   6d65c:      	movl	$0x1, %esi
   6d661:      	leaq	-0xf(%r14), %r11
   6d665:      	jmp	0x6db0e <f.2+0x1694e>
   6d66a:      	leaq	-0x10(%r14), %rsi
   6d66e:      	movq	$0x0, 0x50(%rsp)
   6d677:      	movq	$0x3, 0x38(%rsp)
   6d680:      	xorl	%edi, %edi
   6d682:      	callq	0x6e9d0 <f.3>
   6d687:      	subq	$0x8, %rsp
   6d68b:      	cmpb	$0x0, 0x621e(%rip)      # 0x738b0 <g.4>
   6d692:      	je	0x6e9c5 <f.2+0x17805>
   6d698:      	movq	%rax, 0x58(%rsp)
   6d69d:      	cmpq	$0x0, 0x6203(%rip)      # 0x738a8 <g.3>
   6d6a5:      	je	0x6e9c5 <f.2+0x17805>
   6d6ab:      	leaq	-0x11(%r14), %rsi
   6d6af:      	movq	$0x0, 0x50(%rsp)
   6d6b8:      	movq	$0x3, 0x38(%rsp)
   6d6c1:      	xorl	%edi, %edi
   6d6c3:      	callq	0x6e9d0 <f.3>
   6d6c8:      	subq	$0x8, %rsp
   6d6cc:      	cmpb	$0x0, 0x61dd(%rip)      # 0x738b0 <g.4>
   6d6d3:      	je	0x6e9c5 <f.2+0x17805>
   6d6d9:      	cmpq	$0x0, 0x61c7(%rip)      # 0x738a8 <g.3>
   6d6e1:      	leaq	0x20(%rsp), %rdi
   6d6e6:      	leaq	-0x10(%r14), %rcx
   6d6ea:      	movq	0x60(%rsp), %rdx
   6d6ef:      	je	0x6e9c5 <f.2+0x17805>
   6d6f5:      	movq	%rax, %rsi
   6d6f8:      	addq	0x58(%rsp), %rsi
   6d6fd:      	cmpq	$0x12, %r14
   6d701:      	jae	0x6d71e <f.2+0x1655e>
   6d703:      	leaq	0x28(%rsp), %r8
   6d708:      	leaq	0x60b9(%rip), %r9       # 0x737c8 <native_roots.0>
   6d70f:      	movq	0x10(%rsp), %r10
   6d714:      	movq	0x18(%rsp), %rax
   6d719:      	jmp	0x6d7b2 <f.2+0x165f2>
   6d71e:      	movq	%rsi, 0x70(%rsp)
   6d723:      	movq	$0x0, 0x50(%rsp)
   6d72c:      	movq	$0x3, 0x38(%rsp)
   6d735:      	xorl	%edi, %edi
   6d737:      	leaq	-0x11(%r14), %rsi
   6d73b:      	callq	0x6e9d0 <f.3>
   6d740:      	subq	$0x8, %rsp
   6d744:      	cmpb	$0x0, 0x6165(%rip)      # 0x738b0 <g.4>
   6d74b:      	je	0x6e9c5 <f.2+0x17805>
   6d751:      	movq	%rax, 0x58(%rsp)
   6d756:      	cmpq	$0x0, 0x614a(%rip)      # 0x738a8 <g.3>
   6d75e:      	je	0x6e9c5 <f.2+0x17805>
   6d764:      	leaq	-0x12(%r14), %rsi
   6d768:      	movq	$0x0, 0x50(%rsp)
   6d771:      	movq	$0x3, 0x38(%rsp)
   6d77a:      	xorl	%edi, %edi
   6d77c:      	callq	0x6e9d0 <f.3>
   6d781:      	subq	$0x8, %rsp
   6d785:      	movq	%rax, %rcx
   6d788:      	addq	0x58(%rsp), %rcx
   6d78d:      	leaq	0x28(%rsp), %r8
   6d792:      	leaq	0x20(%rsp), %rdi
   6d797:      	leaq	0x602a(%rip), %r9       # 0x737c8 <native_roots.0>
   6d79e:      	movq	0x10(%rsp), %r10
   6d7a3:      	movq	0x18(%rsp), %rax
   6d7a8:      	movq	0x60(%rsp), %rdx
   6d7ad:      	movq	0x70(%rsp), %rsi
   6d7b2:      	cmpb	$0x0, 0x60f7(%rip)      # 0x738b0 <g.4>
   6d7b9:      	je	0x6e9c5 <f.2+0x17805>
   6d7bf:      	movq	%rsi, 0x70(%rsp)
   6d7c4:      	cmpq	$0x0, 0x60dc(%rip)      # 0x738a8 <g.3>
   6d7cc:      	je	0x6e9c5 <f.2+0x17805>
   6d7d2:      	leaq	-0x10(%r14), %rsi
   6d7d6:      	movl	$0x1, %r11d
   6d7dc:      	movq	%r11, 0x68(%rsp)
   6d7e1:      	cmpq	$0x11, %r14
   6d7e5:      	jb	0x6d946 <f.2+0x16786>
   6d7eb:      	movq	%rcx, 0x58(%rsp)
   6d7f0:      	movq	$0x0, 0x50(%rsp)
   6d7f9:      	movq	$0x3, 0x38(%rsp)
   6d802:      	xorl	%edi, %edi
   6d804:      	callq	0x6e9d0 <f.3>
   6d809:      	subq	$0x8, %rsp
   6d80d:      	cmpb	$0x0, 0x609c(%rip)      # 0x738b0 <g.4>
   6d814:      	je	0x6e9c5 <f.2+0x17805>
   6d81a:      	movq	%rax, 0x80(%rsp)
   6d822:      	cmpq	$0x0, 0x607e(%rip)      # 0x738a8 <g.3>
   6d82a:      	je	0x6e9c5 <f.2+0x17805>
   6d830:      	leaq	-0x11(%r14), %rsi
   6d834:      	movq	$0x0, 0x50(%rsp)
   6d83d:      	movq	$0x3, 0x38(%rsp)
   6d846:      	xorl	%edi, %edi
   6d848:      	callq	0x6e9d0 <f.3>
   6d84d:      	subq	$0x8, %rsp
   6d851:      	movq	%rax, 0x68(%rsp)
   6d856:      	cmpb	$0x0, 0x6053(%rip)      # 0x738b0 <g.4>
   6d85d:      	je	0x6e9c5 <f.2+0x17805>
   6d863:      	cmpq	$0x0, 0x603d(%rip)      # 0x738a8 <g.3>
   6d86b:      	leaq	0x28(%rsp), %r8
   6d870:      	leaq	0x20(%rsp), %rdi
   6d875:      	leaq	0x5f4c(%rip), %r9       # 0x737c8 <native_roots.0>
   6d87c:      	movq	0x10(%rsp), %r10
   6d881:      	movq	0x18(%rsp), %rax
   6d886:      	movq	0x58(%rsp), %rcx
   6d88b:      	movq	0x60(%rsp), %rdx
   6d890:      	leaq	-0x10(%r14), %rsi
   6d894:      	je	0x6e9c5 <f.2+0x17805>
   6d89a:      	movq	0x80(%rsp), %r11
   6d8a2:      	addq	%r11, 0x68(%rsp)
   6d8a7:      	cmpq	$0x11, %r14
   6d8ab:      	je	0x6d946 <f.2+0x16786>
   6d8b1:      	movq	$0x0, 0x50(%rsp)
   6d8ba:      	movq	$0x3, 0x38(%rsp)
   6d8c3:      	xorl	%edi, %edi
   6d8c5:      	leaq	-0x11(%r14), %rsi
   6d8c9:      	callq	0x6e9d0 <f.3>
   6d8ce:      	subq	$0x8, %rsp
   6d8d2:      	cmpb	$0x0, 0x5fd7(%rip)      # 0x738b0 <g.4>
   6d8d9:      	je	0x6e9c5 <f.2+0x17805>
   6d8df:      	movq	%rax, 0x80(%rsp)
   6d8e7:      	cmpq	$0x0, 0x5fb9(%rip)      # 0x738a8 <g.3>
   6d8ef:      	je	0x6e9c5 <f.2+0x17805>
   6d8f5:      	leaq	-0x12(%r14), %rsi
   6d8f9:      	movq	$0x0, 0x50(%rsp)
   6d902:      	movq	$0x3, 0x38(%rsp)
   6d90b:      	xorl	%edi, %edi
   6d90d:      	callq	0x6e9d0 <f.3>
   6d912:      	subq	$0x8, %rsp
   6d916:      	movq	%rax, %rsi
   6d919:      	addq	0x80(%rsp), %rsi
   6d921:      	leaq	0x28(%rsp), %r8
   6d926:      	leaq	0x20(%rsp), %rdi
   6d92b:      	leaq	0x5e96(%rip), %r9       # 0x737c8 <native_roots.0>
   6d932:      	movq	0x10(%rsp), %r10
   6d937:      	movq	0x18(%rsp), %rax
   6d93c:      	movq	0x58(%rsp), %rcx
   6d941:      	movq	0x60(%rsp), %rdx
   6d946:      	movq	0x70(%rsp), %r11
   6d94b:      	cmpb	$0x0, 0x5f5e(%rip)      # 0x738b0 <g.4>
   6d952:      	je	0x6e9c5 <f.2+0x17805>
   6d958:      	cmpq	$0x0, 0x5f48(%rip)      # 0x738a8 <g.3>
   6d960:      	je	0x6e9c5 <f.2+0x17805>
   6d966:      	addq	%r11, %rcx
   6d969:      	addq	0x78(%rsp), %rcx
   6d96e:      	addq	0x68(%rsp), %rsi
   6d973:      	cmpq	$0x10, %r14
   6d977:      	ja	0x6d982 <f.2+0x167c2>
   6d979:      	leaq	-0xf(%r14), %r11
   6d97d:      	jmp	0x6db0e <f.2+0x1694e>
   6d982:      	cmpq	$0x11, %r14
   6d986:      	jne	0x6d99c <f.2+0x167dc>
   6d988:      	movl	$0x1, %r11d
   6d98e:      	movq	$0x0, 0x68(%rsp)
   6d997:      	jmp	0x6db09 <f.2+0x16949>
   6d99c:      	movq	%rsi, 0x70(%rsp)
   6d9a1:      	movq	%rcx, 0x58(%rsp)
   6d9a6:      	leaq	-0x11(%r14), %rsi
   6d9aa:      	movq	$0x0, 0x50(%rsp)
   6d9b3:      	movq	$0x3, 0x38(%rsp)
   6d9bc:      	xorl	%edi, %edi
   6d9be:      	callq	0x6e9d0 <f.3>
   6d9c3:      	subq	$0x8, %rsp
   6d9c7:      	cmpb	$0x0, 0x5ee2(%rip)      # 0x738b0 <g.4>
   6d9ce:      	je	0x6e9c5 <f.2+0x17805>
   6d9d4:      	movq	%rax, 0x68(%rsp)
   6d9d9:      	cmpq	$0x0, 0x5ec7(%rip)      # 0x738a8 <g.3>
   6d9e1:      	je	0x6e9c5 <f.2+0x17805>
   6d9e7:      	leaq	-0x12(%r14), %rsi
   6d9eb:      	movq	$0x0, 0x50(%rsp)
   6d9f4:      	movq	$0x3, 0x38(%rsp)
   6d9fd:      	xorl	%edi, %edi
   6d9ff:      	callq	0x6e9d0 <f.3>
   6da04:      	subq	$0x8, %rsp
   6da08:      	cmpb	$0x0, 0x5ea1(%rip)      # 0x738b0 <g.4>
   6da0f:      	je	0x6e9c5 <f.2+0x17805>
   6da15:      	movq	%rax, %r11
   6da18:      	cmpq	$0x0, 0x5e88(%rip)      # 0x738a8 <g.3>
   6da20:      	leaq	0x28(%rsp), %r8
   6da25:      	leaq	0x5d9c(%rip), %r9       # 0x737c8 <native_roots.0>
   6da2c:      	movq	0x10(%rsp), %r10
   6da31:      	movq	0x18(%rsp), %rax
   6da36:      	movq	0x58(%rsp), %rcx
   6da3b:      	movq	0x60(%rsp), %rdx
   6da40:      	movq	0x70(%rsp), %rsi
   6da45:      	je	0x6e9c5 <f.2+0x17805>
   6da4b:      	addq	0x68(%rsp), %r11
   6da50:      	cmpq	$0x13, %r14
   6da54:      	movq	%r11, 0x78(%rsp)
   6da59:      	jae	0x6da6e <f.2+0x168ae>
   6da5b:      	leaq	0x20(%rsp), %rdi
   6da60:      	leaq	-0x11(%r14), %r11
   6da64:      	movq	%r11, 0x68(%rsp)
   6da69:      	jmp	0x6db04 <f.2+0x16944>
   6da6e:      	movq	$0x0, 0x50(%rsp)
   6da77:      	movq	$0x3, 0x38(%rsp)
   6da80:      	xorl	%edi, %edi
   6da82:      	leaq	-0x12(%r14), %rsi
   6da86:      	callq	0x6e9d0 <f.3>
   6da8b:      	subq	$0x8, %rsp
   6da8f:      	cmpb	$0x0, 0x5e1a(%rip)      # 0x738b0 <g.4>
   6da96:      	je	0x6e9c5 <f.2+0x17805>
   6da9c:      	movq	%rax, 0x68(%rsp)
   6daa1:      	cmpq	$0x0, 0x5dff(%rip)      # 0x738a8 <g.3>
   6daa9:      	je	0x6e9c5 <f.2+0x17805>
   6daaf:      	leaq	-0x13(%r14), %rsi
   6dab3:      	movq	$0x0, 0x50(%rsp)
   6dabc:      	movq	$0x3, 0x38(%rsp)
   6dac5:      	xorl	%edi, %edi
   6dac7:      	callq	0x6e9d0 <f.3>
   6dacc:      	subq	$0x8, %rsp
   6dad0:      	addq	0x68(%rsp), %rax
   6dad5:      	movq	%rax, 0x68(%rsp)
   6dada:      	leaq	0x28(%rsp), %r8
   6dadf:      	leaq	0x20(%rsp), %rdi
   6dae4:      	leaq	0x5cdd(%rip), %r9       # 0x737c8 <native_roots.0>
   6daeb:      	movq	0x10(%rsp), %r10
   6daf0:      	movq	0x18(%rsp), %rax
   6daf5:      	movq	0x58(%rsp), %rcx
   6dafa:      	movq	0x60(%rsp), %rdx
   6daff:      	movq	0x70(%rsp), %rsi
   6db04:      	movq	0x78(%rsp), %r11
   6db09:      	addq	0x68(%rsp), %r11
   6db0e:      	addq	%r11, %rsi
   6db11:      	addq	%rsi, %rcx
   6db14:      	cmpb	$0x0, 0x5d95(%rip)      # 0x738b0 <g.4>
   6db1b:      	je	0x6e9c5 <f.2+0x17805>
   6db21:      	cmpq	$0x0, 0x5d7f(%rip)      # 0x738a8 <g.3>
   6db29:      	je	0x6e9c5 <f.2+0x17805>
   6db2f:      	addq	%rax, %rbp
   6db32:      	addq	%r10, %rbp
   6db35:      	addq	%rdx, %rcx
   6db38:      	cmpq	$0xb, %r14
   6db3c:      	ja	0x6db47 <f.2+0x16987>
   6db3e:      	addq	$-0xa, %r14
   6db42:      	jmp	0x6e8ee <f.2+0x1772e>
   6db47:      	movl	$0x1, %eax
   6db4c:      	cmpq	$0xc, %r14
   6db50:      	je	0x6df7f <f.2+0x16dbf>
   6db56:      	movl	$0x1, %edx
   6db5b:      	cmpq	$0xe, %r14
   6db5f:      	jb	0x6dcf8 <f.2+0x16b38>
   6db65:      	je	0x6dcd6 <f.2+0x16b16>
   6db6b:      	leaq	-0xf(%r14), %rax
   6db6f:      	cmpq	$0x10, %r14
   6db73:      	jb	0x6dc22 <f.2+0x16a62>
   6db79:      	movq	%rcx, 0x58(%rsp)
   6db7e:      	movq	$0x0, 0x50(%rsp)
   6db87:      	movq	$0x3, 0x38(%rsp)
   6db90:      	xorl	%edi, %edi
   6db92:      	movq	%rax, %rsi
   6db95:      	callq	0x6e9d0 <f.3>
   6db9a:      	subq	$0x8, %rsp
   6db9e:      	cmpb	$0x0, 0x5d0b(%rip)      # 0x738b0 <g.4>
   6dba5:      	je	0x6e9c5 <f.2+0x17805>
   6dbab:      	movq	%rax, 0x10(%rsp)
   6dbb0:      	cmpq	$0x0, 0x5cf0(%rip)      # 0x738a8 <g.3>
   6dbb8:      	je	0x6e9c5 <f.2+0x17805>
   6dbbe:      	leaq	-0x10(%r14), %rsi
   6dbc2:      	movq	$0x0, 0x50(%rsp)
   6dbcb:      	movq	$0x3, 0x38(%rsp)
   6dbd4:      	xorl	%edi, %edi
   6dbd6:      	callq	0x6e9d0 <f.3>
   6dbdb:      	subq	$0x8, %rsp
   6dbdf:      	cmpb	$0x0, 0x5cca(%rip)      # 0x738b0 <g.4>
   6dbe6:      	je	0x6e9c5 <f.2+0x17805>
   6dbec:      	movq	%rax, %rdx
   6dbef:      	cmpq	$0x0, 0x5cb1(%rip)      # 0x738a8 <g.3>
   6dbf7:      	movq	0x58(%rsp), %rcx
   6dbfc:      	leaq	-0xf(%r14), %rax
   6dc00:      	je	0x6e9c5 <f.2+0x17805>
   6dc06:      	addq	0x10(%rsp), %rdx
   6dc0b:      	cmpq	$0x10, %r14
   6dc0f:      	jne	0x6dc2a <f.2+0x16a6a>
   6dc11:      	leaq	0x28(%rsp), %r8
   6dc16:      	leaq	0x20(%rsp), %rdi
   6dc1b:      	leaq	0x5ba6(%rip), %r9       # 0x737c8 <native_roots.0>
   6dc22:      	addq	%rdx, %rax
   6dc25:      	jmp	0x6dcbe <f.2+0x16afe>
   6dc2a:      	movq	%rdx, 0x10(%rsp)
   6dc2f:      	movq	$0x0, 0x50(%rsp)
   6dc38:      	movq	$0x3, 0x38(%rsp)
   6dc41:      	xorl	%edi, %edi
   6dc43:      	leaq	-0x10(%r14), %rsi
   6dc47:      	callq	0x6e9d0 <f.3>
   6dc4c:      	subq	$0x8, %rsp
   6dc50:      	cmpb	$0x0, 0x5c59(%rip)      # 0x738b0 <g.4>
   6dc57:      	je	0x6e9c5 <f.2+0x17805>
   6dc5d:      	movq	%rax, 0x18(%rsp)
   6dc62:      	cmpq	$0x0, 0x5c3e(%rip)      # 0x738a8 <g.3>
   6dc6a:      	je	0x6e9c5 <f.2+0x17805>
   6dc70:      	leaq	-0x11(%r14), %rsi
   6dc74:      	movq	$0x0, 0x50(%rsp)
   6dc7d:      	movq	$0x3, 0x38(%rsp)
   6dc86:      	xorl	%edi, %edi
   6dc88:      	callq	0x6e9d0 <f.3>
   6dc8d:      	subq	$0x8, %rsp
   6dc91:      	cmpb	$0x0, 0x5c18(%rip)      # 0x738b0 <g.4>
   6dc98:      	je	0x6e9c5 <f.2+0x17805>
   6dc9e:      	addq	0x18(%rsp), %rax
   6dca3:      	addq	0x10(%rsp), %rax
   6dca8:      	leaq	0x28(%rsp), %r8
   6dcad:      	leaq	0x20(%rsp), %rdi
   6dcb2:      	leaq	0x5b0f(%rip), %r9       # 0x737c8 <native_roots.0>
   6dcb9:      	movq	0x58(%rsp), %rcx
   6dcbe:      	cmpq	$0x0, 0x5be2(%rip)      # 0x738a8 <g.3>
   6dcc6:      	je	0x6e9c5 <f.2+0x17805>
   6dccc:      	cmpq	$0xf, %r14
   6dcd0:      	ja	0x6dddb <f.2+0x16c1b>
   6dcd6:      	leaq	(%r14,%rax), %rdx
   6dcda:      	addq	$-0xe, %rdx
   6dcde:      	cmpq	$0x0, 0x5bc2(%rip)      # 0x738a8 <g.3>
   6dce6:      	je	0x6e9c5 <f.2+0x17805>
   6dcec:      	cmpq	$0xf, %r14
   6dcf0:      	je	0x6dd05 <f.2+0x16b45>
   6dcf2:      	cmpq	$0xe, %r14
   6dcf6:      	jne	0x6dd0f <f.2+0x16b4f>
   6dcf8:      	leaq	(%r14,%rdx), %rax
   6dcfc:      	addq	$-0xd, %rax
   6dd00:      	jmp	0x6df6b <f.2+0x16dab>
   6dd05:      	movl	$0x1, %esi
   6dd0a:      	jmp	0x6df60 <f.2+0x16da0>
   6dd0f:      	leaq	-0x10(%r14), %rsi
   6dd13:      	movl	$0x1, %eax
   6dd18:      	cmpq	$0x11, %r14
   6dd1c:      	jb	0x6ddd3 <f.2+0x16c13>
   6dd22:      	movq	%rdx, 0x18(%rsp)
   6dd27:      	movq	%rcx, 0x58(%rsp)
   6dd2c:      	movq	$0x0, 0x50(%rsp)
   6dd35:      	movq	$0x3, 0x38(%rsp)
   6dd3e:      	xorl	%edi, %edi
   6dd40:      	callq	0x6e9d0 <f.3>
   6dd45:      	subq	$0x8, %rsp
   6dd49:      	cmpb	$0x0, 0x5b60(%rip)      # 0x738b0 <g.4>
   6dd50:      	je	0x6e9c5 <f.2+0x17805>
   6dd56:      	movq	%rax, 0x10(%rsp)
   6dd5b:      	cmpq	$0x0, 0x5b45(%rip)      # 0x738a8 <g.3>
   6dd63:      	je	0x6e9c5 <f.2+0x17805>
   6dd69:      	leaq	-0x11(%r14), %rsi
   6dd6d:      	movq	$0x0, 0x50(%rsp)
   6dd76:      	movq	$0x3, 0x38(%rsp)
   6dd7f:      	xorl	%edi, %edi
   6dd81:      	callq	0x6e9d0 <f.3>
   6dd86:      	subq	$0x8, %rsp
   6dd8a:      	cmpb	$0x0, 0x5b1f(%rip)      # 0x738b0 <g.4>
   6dd91:      	je	0x6e9c5 <f.2+0x17805>
   6dd97:      	cmpq	$0x0, 0x5b09(%rip)      # 0x738a8 <g.3>
   6dd9f:      	leaq	0x28(%rsp), %r8
   6dda4:      	leaq	0x20(%rsp), %rdi
   6dda9:      	leaq	0x5a18(%rip), %r9       # 0x737c8 <native_roots.0>
   6ddb0:      	movq	0x18(%rsp), %rdx
   6ddb5:      	leaq	-0x10(%r14), %rsi
   6ddb9:      	je	0x6e9c5 <f.2+0x17805>
   6ddbf:      	addq	0x10(%rsp), %rax
   6ddc4:      	cmpq	$0x11, %r14
   6ddc8:      	jne	0x6deb0 <f.2+0x16cf0>
   6ddce:      	movq	0x58(%rsp), %rcx
   6ddd3:      	addq	%rax, %rsi
   6ddd6:      	jmp	0x6df4c <f.2+0x16d8c>
   6dddb:      	cmpq	$0x10, %r14
   6dddf:      	jne	0x6dded <f.2+0x16c2d>
   6dde1:      	movl	$0x1, %edx
   6dde6:      	xorl	%esi, %esi
   6dde8:      	jmp	0x6dea5 <f.2+0x16ce5>
   6dded:      	movq	%rax, 0x10(%rsp)
   6ddf2:      	movq	%rcx, 0x58(%rsp)
   6ddf7:      	leaq	-0x10(%r14), %rsi
   6ddfb:      	movq	$0x0, 0x50(%rsp)
   6de04:      	movq	$0x3, 0x38(%rsp)
   6de0d:      	xorl	%edi, %edi
   6de0f:      	callq	0x6e9d0 <f.3>
   6de14:      	subq	$0x8, %rsp
   6de18:      	cmpb	$0x0, 0x5a91(%rip)      # 0x738b0 <g.4>
   6de1f:      	je	0x6e9c5 <f.2+0x17805>
   6de25:      	movq	%rax, 0x18(%rsp)
   6de2a:      	cmpq	$0x0, 0x5a76(%rip)      # 0x738a8 <g.3>
   6de32:      	je	0x6e9c5 <f.2+0x17805>
   6de38:      	leaq	-0x11(%r14), %rsi
   6de3c:      	movq	$0x0, 0x50(%rsp)
   6de45:      	movq	$0x3, 0x38(%rsp)
   6de4e:      	xorl	%edi, %edi
   6de50:      	callq	0x6e9d0 <f.3>
   6de55:      	subq	$0x8, %rsp
   6de59:      	cmpb	$0x0, 0x5a50(%rip)      # 0x738b0 <g.4>
   6de60:      	je	0x6e9c5 <f.2+0x17805>
   6de66:      	movq	%rax, %rdx
   6de69:      	cmpq	$0x0, 0x5a37(%rip)      # 0x738a8 <g.3>
   6de71:      	movq	0x10(%rsp), %rax
   6de76:      	leaq	-0x10(%r14), %rsi
   6de7a:      	je	0x6e9c5 <f.2+0x17805>
   6de80:      	addq	0x18(%rsp), %rdx
   6de85:      	cmpq	$0x12, %r14
   6de89:      	jae	0x6e2f3 <f.2+0x17133>
   6de8f:      	leaq	0x28(%rsp), %r8
   6de94:      	leaq	0x20(%rsp), %rdi
   6de99:      	leaq	0x5928(%rip), %r9       # 0x737c8 <native_roots.0>
   6dea0:      	movq	0x58(%rsp), %rcx
   6dea5:      	addq	%rsi, %rdx
   6dea8:      	addq	%rax, %rdx
   6deab:      	jmp	0x6dcde <f.2+0x16b1e>
   6deb0:      	movq	%rax, 0x10(%rsp)
   6deb5:      	movq	$0x0, 0x50(%rsp)
   6debe:      	movq	$0x3, 0x38(%rsp)
   6dec7:      	xorl	%edi, %edi
   6dec9:      	leaq	-0x11(%r14), %rsi
   6decd:      	callq	0x6e9d0 <f.3>
   6ded2:      	subq	$0x8, %rsp
   6ded6:      	cmpb	$0x0, 0x59d3(%rip)      # 0x738b0 <g.4>
   6dedd:      	je	0x6e9c5 <f.2+0x17805>
   6dee3:      	movq	%rax, 0x60(%rsp)
   6dee8:      	cmpq	$0x0, 0x59b8(%rip)      # 0x738a8 <g.3>
   6def0:      	je	0x6e9c5 <f.2+0x17805>
   6def6:      	leaq	-0x12(%r14), %rsi
   6defa:      	movq	$0x0, 0x50(%rsp)
   6df03:      	movq	$0x3, 0x38(%rsp)
   6df0c:      	xorl	%edi, %edi
   6df0e:      	callq	0x6e9d0 <f.3>
   6df13:      	subq	$0x8, %rsp
   6df17:      	cmpb	$0x0, 0x5992(%rip)      # 0x738b0 <g.4>
   6df1e:      	je	0x6e9c5 <f.2+0x17805>
   6df24:      	movq	%rax, %rsi
   6df27:      	addq	0x60(%rsp), %rsi
   6df2c:      	addq	0x10(%rsp), %rsi
   6df31:      	leaq	0x28(%rsp), %r8
   6df36:      	leaq	0x20(%rsp), %rdi
   6df3b:      	leaq	0x5886(%rip), %r9       # 0x737c8 <native_roots.0>
   6df42:      	movq	0x58(%rsp), %rcx
   6df47:      	movq	0x18(%rsp), %rdx
   6df4c:      	cmpq	$0x0, 0x5954(%rip)      # 0x738a8 <g.3>
   6df54:      	je	0x6e9c5 <f.2+0x17805>
   6df5a:      	cmpq	$0x10, %r14
   6df5e:      	ja	0x6dfb2 <f.2+0x16df2>
   6df60:      	addq	%r14, %rsi
   6df63:      	leaq	(%rdx,%rsi), %rax
   6df67:      	addq	$-0xf, %rax
   6df6b:      	cmpq	$0x0, 0x5935(%rip)      # 0x738a8 <g.3>
   6df73:      	je	0x6e9c5 <f.2+0x17805>
   6df79:      	cmpq	$0xd, %r14
   6df7d:      	ja	0x6df88 <f.2+0x16dc8>
   6df7f:      	addq	$-0xc, %r14
   6df83:      	jmp	0x6e8eb <f.2+0x1772b>
   6df88:      	movl	$0x1, %edx
   6df8d:      	cmpq	$0xe, %r14
   6df91:      	je	0x6e5ad <f.2+0x173ed>
   6df97:      	movl	$0x1, %esi
   6df9c:      	cmpq	$0x10, %r14
   6dfa0:      	jb	0x6e20c <f.2+0x1704c>
   6dfa6:      	jne	0x6dfc9 <f.2+0x16e09>
   6dfa8:      	xorl	%edx, %edx
   6dfaa:      	addq	%rdx, %rsi
   6dfad:      	jmp	0x6e1f2 <f.2+0x17032>
   6dfb2:      	cmpq	$0x11, %r14
   6dfb6:      	jne	0x6e089 <f.2+0x16ec9>
   6dfbc:      	movl	$0x1, %eax
   6dfc1:      	xorl	%r10d, %r10d
   6dfc4:      	jmp	0x6e148 <f.2+0x16f88>
   6dfc9:      	movq	%rax, 0x10(%rsp)
   6dfce:      	movq	%rcx, 0x58(%rsp)
   6dfd3:      	leaq	-0x10(%r14), %rsi
   6dfd7:      	movq	$0x0, 0x50(%rsp)
   6dfe0:      	movq	$0x3, 0x38(%rsp)
   6dfe9:      	xorl	%edi, %edi
   6dfeb:      	callq	0x6e9d0 <f.3>
   6dff0:      	subq	$0x8, %rsp
   6dff4:      	cmpb	$0x0, 0x58b5(%rip)      # 0x738b0 <g.4>
   6dffb:      	je	0x6e9c5 <f.2+0x17805>
   6e001:      	movq	%rax, 0x18(%rsp)
   6e006:      	cmpq	$0x0, 0x589a(%rip)      # 0x738a8 <g.3>
   6e00e:      	je	0x6e9c5 <f.2+0x17805>
   6e014:      	leaq	-0x11(%r14), %rsi
   6e018:      	movq	$0x0, 0x50(%rsp)
   6e021:      	movq	$0x3, 0x38(%rsp)
   6e02a:      	xorl	%edi, %edi
   6e02c:      	callq	0x6e9d0 <f.3>
   6e031:      	subq	$0x8, %rsp
   6e035:      	cmpb	$0x0, 0x5874(%rip)      # 0x738b0 <g.4>
   6e03c:      	je	0x6e9c5 <f.2+0x17805>
   6e042:      	movq	%rax, %rsi
   6e045:      	cmpq	$0x0, 0x585b(%rip)      # 0x738a8 <g.3>
   6e04d:      	movq	0x58(%rsp), %rcx
   6e052:      	movq	0x10(%rsp), %rax
   6e057:      	leaq	-0x10(%r14), %rdx
   6e05b:      	je	0x6e9c5 <f.2+0x17805>
   6e061:      	addq	0x18(%rsp), %rsi
   6e066:      	cmpq	$0x12, %r14
   6e06a:      	jae	0x6e156 <f.2+0x16f96>
   6e070:      	leaq	0x28(%rsp), %r8
   6e075:      	leaq	0x20(%rsp), %rdi
   6e07a:      	leaq	0x5747(%rip), %r9       # 0x737c8 <native_roots.0>
   6e081:      	addq	%rdx, %rsi
   6e084:      	jmp	0x6e1f2 <f.2+0x17032>
   6e089:      	movq	%rsi, 0x60(%rsp)
   6e08e:      	movq	%rdx, 0x18(%rsp)
   6e093:      	movq	%rcx, 0x58(%rsp)
   6e098:      	leaq	-0x11(%r14), %rsi
   6e09c:      	movq	$0x0, 0x50(%rsp)
   6e0a5:      	movq	$0x3, 0x38(%rsp)
   6e0ae:      	xorl	%edi, %edi
   6e0b0:      	callq	0x6e9d0 <f.3>
   6e0b5:      	subq	$0x8, %rsp
   6e0b9:      	cmpb	$0x0, 0x57f0(%rip)      # 0x738b0 <g.4>
   6e0c0:      	je	0x6e9c5 <f.2+0x17805>
   6e0c6:      	movq	%rax, 0x10(%rsp)
   6e0cb:      	cmpq	$0x0, 0x57d5(%rip)      # 0x738a8 <g.3>
   6e0d3:      	je	0x6e9c5 <f.2+0x17805>
   6e0d9:      	leaq	-0x12(%r14), %rsi
   6e0dd:      	movq	$0x0, 0x50(%rsp)
   6e0e6:      	movq	$0x3, 0x38(%rsp)
   6e0ef:      	xorl	%edi, %edi
   6e0f1:      	callq	0x6e9d0 <f.3>
   6e0f6:      	subq	$0x8, %rsp
   6e0fa:      	cmpb	$0x0, 0x57af(%rip)      # 0x738b0 <g.4>
   6e101:      	je	0x6e9c5 <f.2+0x17805>
   6e107:      	cmpq	$0x0, 0x5799(%rip)      # 0x738a8 <g.3>
   6e10f:      	leaq	0x28(%rsp), %r8
   6e114:      	leaq	0x56ad(%rip), %r9       # 0x737c8 <native_roots.0>
   6e11b:      	movq	0x58(%rsp), %rcx
   6e120:      	movq	0x18(%rsp), %rdx
   6e125:      	movq	0x60(%rsp), %rsi
   6e12a:      	leaq	-0x11(%r14), %r10
   6e12e:      	je	0x6e9c5 <f.2+0x17805>
   6e134:      	addq	0x10(%rsp), %rax
   6e139:      	cmpq	$0x13, %r14
   6e13d:      	jae	0x6e44f <f.2+0x1728f>
   6e143:      	leaq	0x20(%rsp), %rdi
   6e148:      	addq	%r10, %rax
   6e14b:      	addq	%rdx, %rax
   6e14e:      	addq	%rsi, %rax
   6e151:      	jmp	0x6df6b <f.2+0x16dab>
   6e156:      	movq	%rsi, 0x18(%rsp)
   6e15b:      	movq	$0x0, 0x50(%rsp)
   6e164:      	movq	$0x3, 0x38(%rsp)
   6e16d:      	xorl	%edi, %edi
   6e16f:      	leaq	-0x11(%r14), %rsi
   6e173:      	callq	0x6e9d0 <f.3>
   6e178:      	subq	$0x8, %rsp
   6e17c:      	cmpb	$0x0, 0x572d(%rip)      # 0x738b0 <g.4>
   6e183:      	je	0x6e9c5 <f.2+0x17805>
   6e189:      	movq	%rax, 0x60(%rsp)
   6e18e:      	cmpq	$0x0, 0x5712(%rip)      # 0x738a8 <g.3>
   6e196:      	je	0x6e9c5 <f.2+0x17805>
   6e19c:      	leaq	-0x12(%r14), %rsi
   6e1a0:      	movq	$0x0, 0x50(%rsp)
   6e1a9:      	movq	$0x3, 0x38(%rsp)
   6e1b2:      	xorl	%edi, %edi
   6e1b4:      	callq	0x6e9d0 <f.3>
   6e1b9:      	subq	$0x8, %rsp
   6e1bd:      	cmpb	$0x0, 0x56ec(%rip)      # 0x738b0 <g.4>
   6e1c4:      	je	0x6e9c5 <f.2+0x17805>
   6e1ca:      	addq	0x60(%rsp), %rax
   6e1cf:      	movq	0x18(%rsp), %rsi
   6e1d4:      	addq	%rax, %rsi
   6e1d7:      	leaq	0x28(%rsp), %r8
   6e1dc:      	leaq	0x20(%rsp), %rdi
   6e1e1:      	leaq	0x55e0(%rip), %r9       # 0x737c8 <native_roots.0>
   6e1e8:      	movq	0x58(%rsp), %rcx
   6e1ed:      	movq	0x10(%rsp), %rax
   6e1f2:      	cmpq	$0x0, 0x56ae(%rip)      # 0x738a8 <g.3>
   6e1fa:      	je	0x6e9c5 <f.2+0x17805>
   6e200:      	cmpq	$0x11, %r14
   6e204:      	je	0x6e219 <f.2+0x17059>
   6e206:      	cmpq	$0x10, %r14
   6e20a:      	jne	0x6e226 <f.2+0x17066>
   6e20c:      	leaq	(%r14,%rsi), %rdx
   6e210:      	addq	$-0xf, %rdx
   6e214:      	jmp	0x6e599 <f.2+0x173d9>
   6e219:      	movl	$0x1, %edx
   6e21e:      	xorl	%r10d, %r10d
   6e221:      	jmp	0x6e2e8 <f.2+0x17128>
   6e226:      	movq	%rsi, 0x18(%rsp)
   6e22b:      	movq	%rax, 0x10(%rsp)
   6e230:      	movq	%rcx, 0x58(%rsp)
   6e235:      	leaq	-0x11(%r14), %rsi
   6e239:      	movq	$0x0, 0x50(%rsp)
   6e242:      	movq	$0x3, 0x38(%rsp)
   6e24b:      	xorl	%edi, %edi
   6e24d:      	callq	0x6e9d0 <f.3>
   6e252:      	subq	$0x8, %rsp
   6e256:      	cmpb	$0x0, 0x5653(%rip)      # 0x738b0 <g.4>
   6e25d:      	je	0x6e9c5 <f.2+0x17805>
   6e263:      	movq	%rax, 0x60(%rsp)
   6e268:      	cmpq	$0x0, 0x5638(%rip)      # 0x738a8 <g.3>
   6e270:      	je	0x6e9c5 <f.2+0x17805>
   6e276:      	leaq	-0x12(%r14), %rsi
   6e27a:      	movq	$0x0, 0x50(%rsp)
   6e283:      	movq	$0x3, 0x38(%rsp)
   6e28c:      	xorl	%edi, %edi
   6e28e:      	callq	0x6e9d0 <f.3>
   6e293:      	subq	$0x8, %rsp
   6e297:      	cmpb	$0x0, 0x5612(%rip)      # 0x738b0 <g.4>
   6e29e:      	je	0x6e9c5 <f.2+0x17805>
   6e2a4:      	movq	%rax, %rdx
   6e2a7:      	cmpq	$0x0, 0x55f9(%rip)      # 0x738a8 <g.3>
   6e2af:      	leaq	0x20(%rsp), %rdi
   6e2b4:      	movq	0x58(%rsp), %rcx
   6e2b9:      	movq	0x10(%rsp), %rax
   6e2be:      	movq	0x18(%rsp), %rsi
   6e2c3:      	leaq	-0x11(%r14), %r10
   6e2c7:      	je	0x6e9c5 <f.2+0x17805>
   6e2cd:      	addq	0x60(%rsp), %rdx
   6e2d2:      	cmpq	$0x13, %r14
   6e2d6:      	jae	0x6e4f8 <f.2+0x17338>
   6e2dc:      	leaq	0x28(%rsp), %r8
   6e2e1:      	leaq	0x54e0(%rip), %r9       # 0x737c8 <native_roots.0>
   6e2e8:      	addq	%r10, %rdx
   6e2eb:      	addq	%rsi, %rdx
   6e2ee:      	jmp	0x6e599 <f.2+0x173d9>
   6e2f3:      	movq	%rdx, 0x18(%rsp)
   6e2f8:      	movq	$0x0, 0x50(%rsp)
   6e301:      	movq	$0x3, 0x38(%rsp)
   6e30a:      	xorl	%edi, %edi
   6e30c:      	leaq	-0x11(%r14), %rsi
   6e310:      	callq	0x6e9d0 <f.3>
   6e315:      	subq	$0x8, %rsp
   6e319:      	cmpb	$0x0, 0x5590(%rip)      # 0x738b0 <g.4>
   6e320:      	je	0x6e9c5 <f.2+0x17805>
   6e326:      	movq	%rax, 0x60(%rsp)
   6e32b:      	cmpq	$0x0, 0x5575(%rip)      # 0x738a8 <g.3>
   6e333:      	je	0x6e9c5 <f.2+0x17805>
   6e339:      	leaq	-0x12(%r14), %rsi
   6e33d:      	movq	$0x0, 0x50(%rsp)
   6e346:      	movq	$0x3, 0x38(%rsp)
   6e34f:      	xorl	%edi, %edi
   6e351:      	callq	0x6e9d0 <f.3>
   6e356:      	subq	$0x8, %rsp
   6e35a:      	cmpb	$0x0, 0x554f(%rip)      # 0x738b0 <g.4>
   6e361:      	je	0x6e9c5 <f.2+0x17805>
   6e367:      	addq	0x60(%rsp), %rax
   6e36c:      	addq	0x18(%rsp), %rax
   6e371:      	addq	0x10(%rsp), %rax
   6e376:      	movq	%rax, %rdx
   6e379:      	leaq	0x28(%rsp), %r8
   6e37e:      	leaq	0x20(%rsp), %rdi
   6e383:      	leaq	0x543e(%rip), %r9       # 0x737c8 <native_roots.0>
   6e38a:      	movq	0x58(%rsp), %rcx
   6e38f:      	jmp	0x6dcde <f.2+0x16b1e>
   6e394:      	movq	%rdx, 0x60(%rsp)
   6e399:      	movq	$0x0, 0x50(%rsp)
   6e3a2:      	movq	$0x3, 0x38(%rsp)
   6e3ab:      	xorl	%edi, %edi
   6e3ad:      	leaq	-0x12(%r14), %rsi
   6e3b1:      	callq	0x6e9d0 <f.3>
   6e3b6:      	subq	$0x8, %rsp
   6e3ba:      	cmpb	$0x0, 0x54ef(%rip)      # 0x738b0 <g.4>
   6e3c1:      	je	0x6e9c5 <f.2+0x17805>
   6e3c7:      	movq	%rax, 0x68(%rsp)
   6e3cc:      	cmpq	$0x0, 0x54d4(%rip)      # 0x738a8 <g.3>
   6e3d4:      	je	0x6e9c5 <f.2+0x17805>
   6e3da:      	leaq	-0x13(%r14), %rsi
   6e3de:      	movq	$0x0, 0x50(%rsp)
   6e3e7:      	movq	$0x3, 0x38(%rsp)
   6e3f0:      	xorl	%edi, %edi
   6e3f2:      	callq	0x6e9d0 <f.3>
   6e3f7:      	subq	$0x8, %rsp
   6e3fb:      	movq	%rax, %r10
   6e3fe:      	addq	0x68(%rsp), %r10
   6e403:      	leaq	0x28(%rsp), %r8
   6e408:      	leaq	0x20(%rsp), %rdi
   6e40d:      	leaq	0x53b4(%rip), %r9       # 0x737c8 <native_roots.0>
   6e414:      	movq	0x58(%rsp), %rsi
   6e419:      	movq	0x18(%rsp), %rax
   6e41e:      	movq	0x10(%rsp), %rcx
   6e423:      	movq	0x60(%rsp), %rdx
   6e428:      	addq	%r10, %rdx
   6e42b:      	addq	%rdx, %rcx
   6e42e:      	addq	%rcx, %rax
   6e431:      	addq	%rax, %rsi
   6e434:      	addq	%rsi, %rbp
   6e437:      	addq	%rbp, %r13
   6e43a:      	addq	%r13, %r15
   6e43d:      	cmpb	$0x0, 0x546c(%rip)      # 0x738b0 <g.4>
   6e444:      	jne	0x57357 <f.2+0x197>
   6e44a:      	jmp	0x6e9c5 <f.2+0x17805>
   6e44f:      	movq	%rax, 0x10(%rsp)
   6e454:      	movq	$0x0, 0x50(%rsp)
   6e45d:      	movq	$0x3, 0x38(%rsp)
   6e466:      	xorl	%edi, %edi
   6e468:      	leaq	-0x12(%r14), %rsi
   6e46c:      	callq	0x6e9d0 <f.3>
   6e471:      	subq	$0x8, %rsp
   6e475:      	cmpb	$0x0, 0x5434(%rip)      # 0x738b0 <g.4>
   6e47c:      	je	0x6e9c5 <f.2+0x17805>
   6e482:      	movq	%rax, 0x68(%rsp)
   6e487:      	cmpq	$0x0, 0x5419(%rip)      # 0x738a8 <g.3>
   6e48f:      	je	0x6e9c5 <f.2+0x17805>
   6e495:      	leaq	-0x13(%r14), %rsi
   6e499:      	movq	$0x0, 0x50(%rsp)
   6e4a2:      	movq	$0x3, 0x38(%rsp)
   6e4ab:      	xorl	%edi, %edi
   6e4ad:      	callq	0x6e9d0 <f.3>
   6e4b2:      	subq	$0x8, %rsp
   6e4b6:      	cmpb	$0x0, 0x53f3(%rip)      # 0x738b0 <g.4>
   6e4bd:      	je	0x6e9c5 <f.2+0x17805>
   6e4c3:      	addq	0x68(%rsp), %rax
   6e4c8:      	addq	0x10(%rsp), %rax
   6e4cd:      	movq	0x60(%rsp), %rcx
   6e4d2:      	addq	0x18(%rsp), %rcx
   6e4d7:      	addq	%rax, %rcx
   6e4da:      	movq	%rcx, %rax
   6e4dd:      	leaq	0x28(%rsp), %r8
   6e4e2:      	leaq	0x20(%rsp), %rdi
   6e4e7:      	leaq	0x52da(%rip), %r9       # 0x737c8 <native_roots.0>
   6e4ee:      	movq	0x58(%rsp), %rcx
   6e4f3:      	jmp	0x6df6b <f.2+0x16dab>
   6e4f8:      	movq	%rdx, 0x60(%rsp)
   6e4fd:      	movq	$0x0, 0x50(%rsp)
   6e506:      	movq	$0x3, 0x38(%rsp)
   6e50f:      	xorl	%edi, %edi
   6e511:      	leaq	-0x12(%r14), %rsi
   6e515:      	callq	0x6e9d0 <f.3>
   6e51a:      	subq	$0x8, %rsp
   6e51e:      	cmpb	$0x0, 0x538b(%rip)      # 0x738b0 <g.4>
   6e525:      	je	0x6e9c5 <f.2+0x17805>
   6e52b:      	movq	%rax, 0x68(%rsp)
   6e530:      	cmpq	$0x0, 0x5370(%rip)      # 0x738a8 <g.3>
   6e538:      	je	0x6e9c5 <f.2+0x17805>
   6e53e:      	leaq	-0x13(%r14), %rsi
   6e542:      	movq	$0x0, 0x50(%rsp)
   6e54b:      	movq	$0x3, 0x38(%rsp)
   6e554:      	xorl	%edi, %edi
   6e556:      	callq	0x6e9d0 <f.3>
   6e55b:      	subq	$0x8, %rsp
   6e55f:      	cmpb	$0x0, 0x534a(%rip)      # 0x738b0 <g.4>
   6e566:      	je	0x6e9c5 <f.2+0x17805>
   6e56c:      	addq	0x68(%rsp), %rax
   6e571:      	addq	0x60(%rsp), %rax
   6e576:      	addq	0x18(%rsp), %rax
   6e57b:      	movq	%rax, %rdx
   6e57e:      	leaq	0x28(%rsp), %r8
   6e583:      	leaq	0x20(%rsp), %rdi
   6e588:      	leaq	0x5239(%rip), %r9       # 0x737c8 <native_roots.0>
   6e58f:      	movq	0x58(%rsp), %rcx
   6e594:      	movq	0x10(%rsp), %rax
   6e599:      	cmpq	$0x0, 0x5307(%rip)      # 0x738a8 <g.3>
   6e5a1:      	je	0x6e9c5 <f.2+0x17805>
   6e5a7:      	cmpq	$0xf, %r14
   6e5ab:      	ja	0x6e5b6 <f.2+0x173f6>
   6e5ad:      	addq	$-0xe, %r14
   6e5b1:      	jmp	0x6e8e8 <f.2+0x17728>
   6e5b6:      	movl	$0x1, %esi
   6e5bb:      	cmpq	$0x10, %r14
   6e5bf:      	je	0x6e750 <f.2+0x17590>
   6e5c5:      	leaq	-0x11(%r14), %rsi
   6e5c9:      	movl	$0x1, %r10d
   6e5cf:      	cmpq	$0x12, %r14
   6e5d3:      	jb	0x6e693 <f.2+0x174d3>
   6e5d9:      	movq	%rdx, 0x60(%rsp)
   6e5de:      	movq	%rax, 0x10(%rsp)
   6e5e3:      	movq	%rcx, 0x58(%rsp)
   6e5e8:      	movq	$0x0, 0x50(%rsp)
   6e5f1:      	movq	$0x3, 0x38(%rsp)
   6e5fa:      	xorl	%edi, %edi
   6e5fc:      	callq	0x6e9d0 <f.3>
   6e601:      	subq	$0x8, %rsp
   6e605:      	cmpb	$0x0, 0x52a4(%rip)      # 0x738b0 <g.4>
   6e60c:      	je	0x6e9c5 <f.2+0x17805>
   6e612:      	movq	%rax, 0x18(%rsp)
   6e617:      	cmpq	$0x0, 0x5289(%rip)      # 0x738a8 <g.3>
   6e61f:      	je	0x6e9c5 <f.2+0x17805>
   6e625:      	leaq	-0x12(%r14), %rsi
   6e629:      	movq	$0x0, 0x50(%rsp)
   6e632:      	movq	$0x3, 0x38(%rsp)
   6e63b:      	xorl	%edi, %edi
   6e63d:      	callq	0x6e9d0 <f.3>
   6e642:      	subq	$0x8, %rsp
   6e646:      	cmpb	$0x0, 0x5263(%rip)      # 0x738b0 <g.4>
   6e64d:      	je	0x6e9c5 <f.2+0x17805>
   6e653:      	movq	%rax, %r10
   6e656:      	cmpq	$0x0, 0x524a(%rip)      # 0x738a8 <g.3>
   6e65e:      	leaq	0x20(%rsp), %rdi
   6e663:      	movq	0x10(%rsp), %rax
   6e668:      	movq	0x60(%rsp), %rdx
   6e66d:      	leaq	-0x11(%r14), %rsi
   6e671:      	je	0x6e9c5 <f.2+0x17805>
   6e677:      	addq	0x18(%rsp), %r10
   6e67c:      	cmpq	$0x12, %r14
   6e680:      	jne	0x6e69b <f.2+0x174db>
   6e682:      	leaq	0x28(%rsp), %r8
   6e687:      	leaq	0x513a(%rip), %r9       # 0x737c8 <native_roots.0>
   6e68e:      	movq	0x58(%rsp), %rcx
   6e693:      	addq	%r10, %rsi
   6e696:      	jmp	0x6e73c <f.2+0x1757c>
   6e69b:      	movq	%r10, 0x18(%rsp)
   6e6a0:      	movq	$0x0, 0x50(%rsp)
   6e6a9:      	movq	$0x3, 0x38(%rsp)
   6e6b2:      	xorl	%edi, %edi
   6e6b4:      	leaq	-0x12(%r14), %rsi
   6e6b8:      	callq	0x6e9d0 <f.3>
   6e6bd:      	subq	$0x8, %rsp
   6e6c1:      	cmpb	$0x0, 0x51e8(%rip)      # 0x738b0 <g.4>
   6e6c8:      	je	0x6e9c5 <f.2+0x17805>
   6e6ce:      	movq	%rax, 0x68(%rsp)
   6e6d3:      	cmpq	$0x0, 0x51cd(%rip)      # 0x738a8 <g.3>
   6e6db:      	je	0x6e9c5 <f.2+0x17805>
   6e6e1:      	leaq	-0x13(%r14), %rsi
   6e6e5:      	movq	$0x0, 0x50(%rsp)
   6e6ee:      	movq	$0x3, 0x38(%rsp)
   6e6f7:      	xorl	%edi, %edi
   6e6f9:      	callq	0x6e9d0 <f.3>
   6e6fe:      	subq	$0x8, %rsp
   6e702:      	cmpb	$0x0, 0x51a7(%rip)      # 0x738b0 <g.4>
   6e709:      	je	0x6e9c5 <f.2+0x17805>
   6e70f:      	movq	%rax, %rsi
   6e712:      	addq	0x68(%rsp), %rsi
   6e717:      	addq	0x18(%rsp), %rsi
   6e71c:      	leaq	0x28(%rsp), %r8
   6e721:      	leaq	0x20(%rsp), %rdi
   6e726:      	leaq	0x509b(%rip), %r9       # 0x737c8 <native_roots.0>
   6e72d:      	movq	0x58(%rsp), %rcx
   6e732:      	movq	0x10(%rsp), %rax
   6e737:      	movq	0x60(%rsp), %rdx
   6e73c:      	cmpq	$0x0, 0x5164(%rip)      # 0x738a8 <g.3>
   6e744:      	je	0x6e9c5 <f.2+0x17805>
   6e74a:      	cmpq	$0x11, %r14
   6e74e:      	ja	0x6e75c <f.2+0x1759c>
   6e750:      	addq	$-0x10, %r14
   6e754:      	movq	%r14, %r10
   6e757:      	jmp	0x6e8e2 <f.2+0x17722>
   6e75c:      	cmpq	$0x12, %r14
   6e760:      	jne	0x6e770 <f.2+0x175b0>
   6e762:      	movl	$0x1, %r10d
   6e768:      	xorl	%r11d, %r11d
   6e76b:      	jmp	0x6e8df <f.2+0x1771f>
   6e770:      	movq	%rsi, 0x18(%rsp)
   6e775:      	movq	%rdx, 0x60(%rsp)
   6e77a:      	movq	%rax, 0x10(%rsp)
   6e77f:      	movq	%rcx, 0x58(%rsp)
   6e784:      	leaq	-0x12(%r14), %rsi
   6e788:      	movq	$0x0, 0x50(%rsp)
   6e791:      	movq	$0x3, 0x38(%rsp)
   6e79a:      	xorl	%edi, %edi
   6e79c:      	movq	%rsi, 0x70(%rsp)
   6e7a1:      	callq	0x6e9d0 <f.3>
   6e7a6:      	subq	$0x8, %rsp
   6e7aa:      	cmpb	$0x0, 0x50ff(%rip)      # 0x738b0 <g.4>
   6e7b1:      	je	0x6e9c5 <f.2+0x17805>
   6e7b7:      	movq	%rax, 0x68(%rsp)
   6e7bc:      	cmpq	$0x0, 0x50e4(%rip)      # 0x738a8 <g.3>
   6e7c4:      	je	0x6e9c5 <f.2+0x17805>
   6e7ca:      	leaq	-0x13(%r14), %rsi
   6e7ce:      	movq	$0x0, 0x50(%rsp)
   6e7d7:      	movq	$0x3, 0x38(%rsp)
   6e7e0:      	xorl	%edi, %edi
   6e7e2:      	callq	0x6e9d0 <f.3>
   6e7e7:      	subq	$0x8, %rsp
   6e7eb:      	cmpb	$0x0, 0x50be(%rip)      # 0x738b0 <g.4>
   6e7f2:      	je	0x6e9c5 <f.2+0x17805>
   6e7f8:      	cmpq	$0x0, 0x50a8(%rip)      # 0x738a8 <g.3>
   6e800:      	je	0x6e9c5 <f.2+0x17805>
   6e806:      	movq	%rax, %r10
   6e809:      	addq	0x68(%rsp), %r10
   6e80e:      	cmpq	$0x14, %r14
   6e812:      	jae	0x6e843 <f.2+0x17683>
   6e814:      	leaq	0x28(%rsp), %r8
   6e819:      	leaq	0x20(%rsp), %rdi
   6e81e:      	leaq	0x4fa3(%rip), %r9       # 0x737c8 <native_roots.0>
   6e825:      	movq	0x58(%rsp), %rcx
   6e82a:      	movq	0x10(%rsp), %rax
   6e82f:      	movq	0x60(%rsp), %rdx
   6e834:      	movq	0x18(%rsp), %rsi
   6e839:      	movq	0x70(%rsp), %r11
   6e83e:      	jmp	0x6e8df <f.2+0x1771f>
   6e843:      	movq	%r10, 0x68(%rsp)
   6e848:      	movq	$0x0, 0x50(%rsp)
   6e851:      	movq	$0x3, 0x38(%rsp)
   6e85a:      	xorl	%edi, %edi
   6e85c:      	leaq	-0x13(%r14), %rsi
   6e860:      	callq	0x6e9d0 <f.3>
   6e865:      	subq	$0x8, %rsp
   6e869:      	movq	%rax, 0x70(%rsp)
   6e86e:      	cmpb	$0x0, 0x503b(%rip)      # 0x738b0 <g.4>
   6e875:      	je	0x6e9c5 <f.2+0x17805>
   6e87b:      	cmpq	$0x0, 0x5025(%rip)      # 0x738a8 <g.3>
   6e883:      	je	0x6e9c5 <f.2+0x17805>
   6e889:      	addq	$-0x14, %r14
   6e88d:      	movq	$0x0, 0x50(%rsp)
   6e896:      	movq	$0x3, 0x38(%rsp)
   6e89f:      	xorl	%edi, %edi
   6e8a1:      	movq	%r14, %rsi
   6e8a4:      	callq	0x6e9d0 <f.3>
   6e8a9:      	subq	$0x8, %rsp
   6e8ad:      	movq	%rax, %r11
   6e8b0:      	addq	0x70(%rsp), %r11
   6e8b5:      	leaq	0x28(%rsp), %r8
   6e8ba:      	leaq	0x20(%rsp), %rdi
   6e8bf:      	leaq	0x4f02(%rip), %r9       # 0x737c8 <native_roots.0>
   6e8c6:      	movq	0x58(%rsp), %rcx
   6e8cb:      	movq	0x10(%rsp), %rax
   6e8d0:      	movq	0x60(%rsp), %rdx
   6e8d5:      	movq	0x18(%rsp), %rsi
   6e8da:      	movq	0x68(%rsp), %r10
   6e8df:      	addq	%r11, %r10
   6e8e2:      	addq	%r10, %rsi
   6e8e5:      	movq	%rsi, %r14
   6e8e8:      	addq	%rdx, %r14
   6e8eb:      	addq	%rax, %r14
   6e8ee:      	addq	%r14, %rcx
   6e8f1:      	addq	%rcx, %rbp
   6e8f4:      	addq	%rbp, %r13
   6e8f7:      	addq	%r13, %r12
   6e8fa:      	movq	%r12, %r14
   6e8fd:      	addq	%r15, %r14
   6e900:      	movq	0x48(%rsp), %rdx
   6e905:      	testq	%rdx, %rdx
   6e908:      	je	0x6e9c5 <f.2+0x17805>
   6e90e:      	movq	0x10(%rdx), %rax
   6e912:      	testq	%rax, %rax
   6e915:      	je	0x6e9c5 <f.2+0x17805>
   6e91b:      	cmpl	$0x0, 0x8(%rax)
   6e91f:      	je	0x6e9c5 <f.2+0x17805>
   6e925:      	cmpq	$0x0, 0x10(%rax)
   6e92a:      	je	0x6e9c5 <f.2+0x17805>
   6e930:      	incq	%rbx
   6e933:      	xorl	%eax, %eax
   6e935:      	cmpq	$0x0, 0x30(%rsp)
   6e93b:      	sete	%al
   6e93e:      	movq	%r8, %rcx
   6e941:      	cmoveq	%r9, %rcx
   6e945:      	addq	0x4e5c(%rip), %rax      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6e94c:      	movq	(%rcx), %rcx
   6e94f:      	movq	$0x3, 0x30(%rsp)
   6e958:      	movq	$0x0, 0x38(%rsp)
   6e961:      	movq	%rcx, 0x28(%rsp)
   6e966:      	movq	%r8, 0x4e5b(%rip)       # 0x737c8 <native_roots.0>
   6e96d:      	movq	%rax, 0x4e34(%rip)      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6e974:      	movq	0x4e35(%rip), %rsi      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6e97b:      	cmpq	%rsi, %rax
   6e97e:      	cmovaq	%rax, %rsi
   6e982:      	movq	%rsi, 0x4e27(%rip)      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6e989:      	movq	%rdx, 0x40(%rsp)
   6e98e:      	movq	%rdx, 0x48(%rsp)
   6e993:      	cmpq	%rbx, 0x8(%rdx)
   6e997:      	jg	0x57260 <f.2+0xa0>
   6e99d:      	decq	%rax
   6e9a0:      	movq	%rcx, 0x4e21(%rip)      # 0x737c8 <native_roots.0>
   6e9a7:      	movq	%rax, 0x4dfa(%rip)      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6e9ae:      	movq	%r14, %rax
   6e9b1:      	addq	$0x88, %rsp
   6e9b8:      	popq	%rbx
   6e9b9:      	popq	%r12
   6e9bb:      	popq	%r13
   6e9bd:      	popq	%r14
   6e9bf:      	popq	%r15
   6e9c1:      	popq	%rbp
   6e9c2:      	retq	$0x8
   6e9c5:      	callq	0x54020 <native_trap>
   6e9ca:      	int3
   6e9cb:      	int3
   6e9cc:      	int3
   6e9cd:      	int3
   6e9ce:      	int3
   6e9cf:      	int3

000000000006e9d0 <f.3>:
   6e9d0:      	pushq	%r14
   6e9d2:      	pushq	%rbx
   6e9d3:      	subq	$0x38, %rsp
   6e9d7:      	movq	%rsi, %rax
   6e9da:      	movq	$0x2, 0x18(%rsp)
   6e9e3:      	movq	$0x0, 0x20(%rsp)
   6e9ec:      	movq	0x4dd5(%rip), %rcx      # 0x737c8 <native_roots.0>
   6e9f3:      	movq	%rcx, 0x10(%rsp)
   6e9f8:      	movq	0x4da9(%rip), %rcx      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6e9ff:      	incq	%rcx
   6ea02:      	movq	%rcx, 0x4d9f(%rip)      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6ea09:      	movq	0x4da0(%rip), %rdx      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6ea10:      	cmpq	%rdx, %rcx
   6ea13:      	cmovbeq	%rdx, %rcx
   6ea17:      	leaq	0x10(%rsp), %rdx
   6ea1c:      	movq	%rdx, 0x4da5(%rip)      # 0x737c8 <native_roots.0>
   6ea23:      	movq	%rcx, 0x4d86(%rip)      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6ea2a:      	movq	%rdi, 0x28(%rsp)
   6ea2f:      	cmpq	$0x2, %rsi
   6ea33:      	jl	0x6eaae <f.3+0xde>
   6ea35:      	cmpb	$0x0, 0x4e74(%rip)      # 0x738b0 <g.4>
   6ea3c:      	je	0x6eacb <f.3+0xfb>
   6ea42:      	cmpq	$0x0, 0x4e5e(%rip)      # 0x738a8 <g.3>
   6ea4a:      	je	0x6eacb <f.3+0xfb>
   6ea4c:      	movq	%rax, %r14
   6ea4f:      	leaq	-0x1(%rax), %rsi
   6ea53:      	movq	%rdi, 0x30(%rsp)
   6ea58:      	movq	$0x2, 0x20(%rsp)
   6ea61:      	callq	0x6e9d0 <f.3>
   6ea66:      	subq	$0x8, %rsp
   6ea6a:      	cmpb	$0x0, 0x4e3f(%rip)      # 0x738b0 <g.4>
   6ea71:      	je	0x6eacb <f.3+0xfb>
   6ea73:      	cmpq	$0x0, 0x4e2d(%rip)      # 0x738a8 <g.3>
   6ea7b:      	je	0x6eacb <f.3+0xfb>
   6ea7d:      	movq	%rax, %rbx
   6ea80:      	movq	0x28(%rsp), %rdi
   6ea85:      	movq	%r14, %rsi
   6ea88:      	addq	$-0x2, %rsi
   6ea8c:      	movq	%rdi, 0x30(%rsp)
   6ea91:      	movq	$0x2, 0x20(%rsp)
   6ea9a:      	callq	0x6e9d0 <f.3>
   6ea9f:      	subq	$0x8, %rsp
   6eaa3:      	addq	%rbx, %rax
   6eaa6:      	cmpq	$0x0, 0x18(%rsp)
   6eaac:      	je	0x6eac1 <f.3+0xf1>
   6eaae:      	movq	0x10(%rsp), %rcx
   6eab3:      	movq	%rcx, 0x4d0e(%rip)      # 0x737c8 <native_roots.0>
   6eaba:      	decq	0x4ce7(%rip)            # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6eac1:      	addq	$0x38, %rsp
   6eac5:      	popq	%rbx
   6eac6:      	popq	%r14
   6eac8:      	retq	$0x8
   6eacb:      	callq	0x54020 <native_trap>

000000000006ead0 <f.4>:
   6ead0:      	movq	$0x1, -0x18(%rsp)
   6ead9:      	movq	0x4ce8(%rip), %rax      # 0x737c8 <native_roots.0>
   6eae0:      	movq	%rax, -0x20(%rsp)
   6eae5:      	leaq	-0x20(%rsp), %rax
   6eaea:      	movq	%rax, 0x4cd7(%rip)      # 0x737c8 <native_roots.0>
   6eaf1:      	movq	0x4cb0(%rip), %rax      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6eaf8:      	incq	%rax
   6eafb:      	movq	%rax, 0x4ca6(%rip)      # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6eb02:      	movq	0x4ca7(%rip), %rcx      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6eb09:      	cmpq	%rcx, %rax
   6eb0c:      	cmovbeq	%rcx, %rax
   6eb10:      	movq	%rax, 0x4c99(%rip)      # 0x737b0 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   6eb17:      	movq	%rdi, -0x8(%rsp)
   6eb1c:      	movq	$0x1, -0x10(%rsp)
   6eb25:      	movq	%rdx, -0x28(%rsp)
   6eb2a:      	leaq	-0x28(%rsp), %rax
   6eb2f:      	movq	-0x28(%rsp), %rax
   6eb34:      	cmpq	$0x0, -0x18(%rsp)
   6eb3a:      	je	0x6eb4f <f.4+0x7f>
   6eb3c:      	movq	-0x20(%rsp), %rcx
   6eb41:      	movq	%rcx, 0x4c80(%rip)      # 0x737c8 <native_roots.0>
   6eb48:      	decq	0x4c59(%rip)            # 0x737a8 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   6eb4f:      	retq	$0x8

Disassembly of section .init:
