000000000004b1c0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887>:
   4b1c0:      	pushq	%rbp
   4b1c1:      	pushq	%r15
   4b1c3:      	pushq	%r14
   4b1c5:      	pushq	%r13
   4b1c7:      	pushq	%r12
   4b1c9:      	pushq	%rbx
   4b1ca:      	subq	$0x3c8, %rsp            # imm = 0x3C8
   4b1d1:      	cmpq	$0x0, 0x138ff(%rip)     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b1d9:      	jne	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b1df:      	movl	$0x198, %edi            # imm = 0x198
   4b1e4:      	callq	*0x11df6(%rip)          # 0x5cfe0 <writev+0x5cfe0>
   4b1ea:      	testq	%rax, %rax
   4b1ed:      	je	0x4c74d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x158d>
   4b1f3:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b1fd:      	movq	%rax, 0x28(%rsp)
   4b202:      	movq	%rax, %r13
   4b205:      	addq	$0x10, %r13
   4b209:      	leaq	0x119d8(%rip), %rbp     # 0x5cbe8 <native_gc_layouts+0x8>
   4b210:      	xorl	%r14d, %r14d
   4b213:      	movl	$0x1ce12, %eax          # imm = 0x1CE12
   4b218:      	jmp	0x4b246 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x86>
   4b21a:      	nopw	(%rax,%rax)
   4b220:      	movq	%rcx, %r12
   4b223:      	jne	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b229:      	movq	%r12, -0x10(%r13)
   4b22d:      	movq	%rbx, -0x8(%r13)
   4b231:      	movq	%r12, (%r13)
   4b235:      	incq	%r14
   4b238:      	addq	$0x18, %r13
   4b23c:      	addq	$0x10, %rbp
   4b240:      	cmpq	$0x11, %r14
   4b244:      	je	0x4b2af <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xef>
   4b246:      	cmpl	$0x2, -0x8(%rbp)
   4b24a:      	jae	0x4b220 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x60>
   4b24c:      	btq	%r14, %rax
   4b250:      	jae	0x4b260 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xa0>
   4b252:      	movl	$0x4, %ebx
   4b257:      	xorl	%r12d, %r12d
   4b25a:      	jmp	0x4b229 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x69>
   4b25c:      	nopl	(%rax)
   4b260:      	movl	-0x4(%rbp), %r12d
   4b264:      	leaq	(,%r12,4), %r15
   4b26c:      	movq	(%rbp), %rax
   4b270:      	movq	%rax, 0x10(%rsp)
   4b275:      	movq	%r15, %rdi
   4b278:      	callq	*0x11d62(%rip)          # 0x5cfe0 <writev+0x5cfe0>
   4b27e:      	testq	%rax, %rax
   4b281:      	je	0x4c745 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1585>
   4b287:      	movq	%rax, %rbx
   4b28a:      	movq	%rax, %rdi
   4b28d:      	movq	0x10(%rsp), %rsi
   4b292:      	movq	%r15, %rdx
   4b295:      	callq	*0x11e3d(%rip)          # 0x5d0d8 <writev+0x5d0d8>
   4b29b:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b2a5:      	movl	$0x1ce12, %eax          # imm = 0x1CE12
   4b2aa:      	jmp	0x4b229 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x69>
   4b2af:      	movl	$0x30, %edi
   4b2b4:      	callq	*0x11d26(%rip)          # 0x5cfe0 <writev+0x5cfe0>
   4b2ba:      	testq	%rax, %rax
   4b2bd:      	je	0x4c757 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1597>
   4b2c3:      	movq	%rax, %r15
   4b2c6:      	movaps	0x11a43(%rip), %xmm0    # 0x5cd10 <native_gc_globals+0x20>
   4b2cd:      	movups	%xmm0, 0x20(%rax)
   4b2d1:      	movaps	0x11a28(%rip), %xmm0    # 0x5cd00 <native_gc_globals+0x10>
   4b2d8:      	movups	%xmm0, 0x10(%rax)
   4b2dc:      	movapd	0x11a0c(%rip), %xmm0    # 0x5ccf0 <native_gc_globals>
   4b2e4:      	movupd	%xmm0, (%rax)
   4b2e8:      	movl	$0x1, %edi
   4b2ed:      	movl	$0x88, %esi
   4b2f2:      	callq	*0x11c40(%rip)          # 0x5cf38 <writev+0x5cf38>
   4b2f8:      	testq	%rax, %rax
   4b2fb:      	je	0x4c761 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15a1>
   4b301:      	movq	%rax, %r13
   4b304:      	movabsq	$0x3fffffffffff8000, %rbx # imm = 0x3FFFFFFFFFFF8000
   4b30e:      	leaq	-0x4277a(%rip), %rsi    # 0x8b9b <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4b315:      	leaq	0x80(%rsp), %rdi
   4b31d:      	movl	$0x13, %edx
   4b322:      	callq	0x54a20 <std::env::_var_os>
   4b327:      	movq	0x80(%rsp), %rax
   4b32f:      	negq	%rax
   4b332:      	jo	0x4b374 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1b4>
   4b334:      	jae	0x4b344 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x184>
   4b336:      	movq	0x88(%rsp), %rdi
   4b33e:      	callq	*0x11bfc(%rip)          # 0x5cf40 <writev+0x5cf40>
   4b344:      	leaq	-0x427b0(%rip), %rdi    # 0x8b9b <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4b34b:      	movl	$0x13, %esi
   4b350:      	xorl	%edx, %edx
   4b352:      	callq	0x54c10 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b357:      	movq	%rax, %rdx
   4b35a:      	addq	$-0x8000, %rax          # imm = 0x8000
   4b360:      	cmpq	%rbx, %rax
   4b363:      	jae	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b369:      	andq	%rbx, %rdx
   4b36c:      	movq	%rdx, %rbp
   4b36f:      	movq	%rdx, %r14
   4b372:      	jmp	0x4b37f <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1bf>
   4b374:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4b379:      	xorl	%r14d, %r14d
   4b37c:      	movq	%rbx, %rbp
   4b37f:      	leaq	-0x427d8(%rip), %rdi    # 0x8bae <core::num::flt2dec::strategy::dragon::POW5TO256+0x60a>
   4b386:      	movl	$0x16, %esi
   4b38b:      	callq	0x54c10 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b390:      	movq	%rax, %r12
   4b393:      	addq	$-0x8000, %rax          # imm = 0x8000
   4b399:      	cmpq	%rbx, %rax
   4b39c:      	jae	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b3a2:      	movq	%r13, 0x10(%rsp)
   4b3a7:      	andq	%rbx, %r12
   4b3aa:      	cmpq	%rbp, %r12
   4b3ad:      	ja	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b3b3:      	leaq	-0x427f6(%rip), %rdi    # 0x8bc4 <core::num::flt2dec::strategy::dragon::POW5TO256+0x620>
   4b3ba:      	movl	$0x12, %esi
   4b3bf:      	movl	$0x800000, %edx         # imm = 0x800000
   4b3c4:      	callq	0x54c10 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b3c9:      	movq	%rax, %r13
   4b3cc:      	leaq	-0x427fd(%rip), %rsi    # 0x8bd6 <core::num::flt2dec::strategy::dragon::POW5TO256+0x632>
   4b3d3:      	leaq	0x80(%rsp), %rdi
   4b3db:      	movl	$0xe, %edx
   4b3e0:      	callq	0x54a20 <std::env::_var_os>
   4b3e5:      	movq	0x80(%rsp), %rax
   4b3ed:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b3f7:      	cmpq	%rcx, %rax
   4b3fa:      	setne	%bl
   4b3fd:      	testq	%rax, %rax
   4b400:      	jle	0x4b410 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x250>
   4b402:      	movq	0x88(%rsp), %rdi
   4b40a:      	callq	*0x11b30(%rip)          # 0x5cf40 <writev+0x5cf40>
   4b410:      	movq	$0x0, 0x80(%rsp)
   4b41c:      	movq	$0x8, 0x88(%rsp)
   4b428:      	xorpd	%xmm0, %xmm0
   4b42c:      	movupd	%xmm0, 0x90(%rsp)
   4b435:      	movupd	%xmm0, 0x138(%rsp)
   4b43e:      	movupd	%xmm0, 0x148(%rsp)
   4b447:      	movupd	%xmm0, 0x158(%rsp)
   4b450:      	movq	%r12, 0x110(%rsp)
   4b458:      	movq	%rbp, 0x118(%rsp)
   4b460:      	movq	%r14, 0x120(%rsp)
   4b468:      	movq	%r13, 0x128(%rsp)
   4b470:      	movb	%bl, 0x130(%rsp)
   4b477:      	movq	%r13, 0x168(%rsp)
   4b47f:      	movq	$0x8, 0xa0(%rsp)
   4b48b:      	movupd	%xmm0, 0xa8(%rsp)
   4b494:      	movq	$0x8, 0xb8(%rsp)
   4b4a0:      	movq	$0x0, 0xc0(%rsp)
   4b4ac:      	movq	$0x11, 0xc8(%rsp)
   4b4b8:      	movq	0x28(%rsp), %rax
   4b4bd:      	movq	%rax, 0xd0(%rsp)
   4b4c5:      	movq	$0x11, 0xd8(%rsp)
   4b4d1:      	movq	$0x6, 0xe0(%rsp)
   4b4dd:      	movq	%r15, 0xe8(%rsp)
   4b4e5:      	movq	$0x6, 0xf0(%rsp)
   4b4f1:      	movq	$0x0, 0xf8(%rsp)
   4b4fd:      	movq	$0x8, 0x100(%rsp)
   4b509:      	movq	$0x0, 0x108(%rsp)
   4b515:      	movupd	%xmm0, 0x1c0(%rsp)
   4b51e:      	movupd	%xmm0, 0x1b0(%rsp)
   4b527:      	movupd	%xmm0, 0x1a0(%rsp)
   4b530:      	movupd	%xmm0, 0x190(%rsp)
   4b539:      	movupd	%xmm0, 0x180(%rsp)
   4b542:      	movupd	%xmm0, 0x170(%rsp)
   4b54b:      	movq	$0x0, 0x1d0(%rsp)
   4b557:      	leaq	0x80(%rsp), %r14
   4b55f:      	movq	%r14, %rdi
   4b562:      	movq	%r12, %rsi
   4b565:      	callq	0x54e60 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4b56a:      	movq	0x80(%rsp), %r13
   4b572:      	movq	0x88(%rsp), %rcx
   4b57a:      	movq	%rcx, 0x38(%rsp)
   4b57f:      	movq	0x90(%rsp), %rbx
   4b587:      	movq	0x98(%rsp), %rcx
   4b58f:      	movq	%rcx, 0x60(%rsp)
   4b594:      	movq	0xa0(%rsp), %rcx
   4b59c:      	movq	%rcx, 0x48(%rsp)
   4b5a1:      	movq	0xb0(%rsp), %rcx
   4b5a9:      	movq	%rcx, 0x68(%rsp)
   4b5ae:      	movq	0xb8(%rsp), %rcx
   4b5b6:      	movq	%rcx, 0x50(%rsp)
   4b5bb:      	movq	0xc8(%rsp), %rcx
   4b5c3:      	movq	%rcx, 0x70(%rsp)
   4b5c8:      	movq	0xd0(%rsp), %rcx
   4b5d0:      	movq	%rcx, 0x40(%rsp)
   4b5d5:      	movq	0xd8(%rsp), %r15
   4b5dd:      	movq	0xe0(%rsp), %rcx
   4b5e5:      	movq	%rcx, 0x78(%rsp)
   4b5ea:      	movq	0xe8(%rsp), %rcx
   4b5f2:      	movq	%rcx, 0x58(%rsp)
   4b5f7:      	movq	0xf8(%rsp), %rbp
   4b5ff:      	movq	0x100(%rsp), %r12
   4b607:      	testb	%al, %al
   4b609:      	movq	%rbp, 0x28(%rsp)
   4b60e:      	je	0x4c76b <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15ab>
   4b614:      	leaq	0x108(%rsp), %rsi
   4b61c:      	movq	0xf0(%rsp), %rax
   4b624:      	movq	%rax, 0x210(%rsp)
   4b62c:      	movq	0xa8(%rsp), %rax
   4b634:      	movq	%rax, 0x200(%rsp)
   4b63c:      	movq	0xc0(%rsp), %rax
   4b644:      	movq	%rax, 0x208(%rsp)
   4b64c:      	leaq	0x228(%rsp), %rdi
   4b654:      	movl	$0xd0, %edx
   4b659:      	callq	*0x11a79(%rip)          # 0x5d0d8 <writev+0x5d0d8>
   4b65f:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4b669:      	cmpq	%rax, %r13
   4b66c:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b672:      	leaq	0x2f8(%rsp), %rdi
   4b67a:      	leaq	0x228(%rsp), %rsi
   4b682:      	movl	$0xd0, %edx
   4b687:      	callq	*0x11a4b(%rip)          # 0x5d0d8 <writev+0x5d0d8>
   4b68d:      	movupd	-0x4289a(%rip), %xmm0   # 0x8dfb <core::num::flt2dec::strategy::dragon::POW5TO256+0x857>
   4b695:      	movapd	%xmm0, 0x80(%rsp)
   4b69e:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4b6a8:      	movq	%rax, 0x90(%rsp)
   4b6b0:      	movb	$0x0, 0x98(%rsp)
   4b6b8:      	movb	$0x1, %al
   4b6ba:      	testb	%al, %al
   4b6bc:      	je	0x4b6ca <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x50a>
   4b6be:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4b6c8:      	jmp	0x4b6e7 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x527>
   4b6ca:      	xorl	%eax, %eax
   4b6cc:      	nopl	(%rax)
   4b6d0:      	cmpb	$0x0, 0x80(%rsp,%rax)
   4b6d8:      	je	0x4b753 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x593>
   4b6da:      	incq	%rax
   4b6dd:      	jne	0x4b6d0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x510>
   4b6df:      	movq	0x80(%rsp), %rax
   4b6e7:      	movq	0x88(%rsp), %rcx
   4b6ef:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4b6f9:      	movq	%rdx, %rsi
   4b6fc:      	subq	%rax, %rsi
   4b6ff:      	orq	%rax, %rsi
   4b702:      	subq	%rcx, %rdx
   4b705:      	orq	%rcx, %rdx
   4b708:      	andq	%rsi, %rdx
   4b70b:      	notq	%rdx
   4b70e:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4b718:      	xorl	%ecx, %ecx
   4b71a:      	testq	%rax, %rdx
   4b71d:      	sete	%cl
   4b720:      	shll	$0x4, %ecx
   4b723:      	leaq	(%rsp,%rcx), %rdx
   4b727:      	addq	$0x80, %rdx
   4b72e:      	movq	%rcx, %rsi
   4b731:      	xorq	$0x19, %rsi
   4b735:      	xorl	%eax, %eax
   4b737:      	nopw	(%rax,%rax)
   4b740:      	cmpb	$0x0, (%rdx,%rax)
   4b744:      	je	0x4b750 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x590>
   4b746:      	incq	%rax
   4b749:      	cmpq	%rax, %rsi
   4b74c:      	jne	0x4b740 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x580>
   4b74e:      	jmp	0x4b7a1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x5e1>
   4b750:      	addq	%rcx, %rax
   4b753:      	cmpq	$0x18, %rax
   4b757:      	jne	0x4b7a1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x5e1>
   4b759:      	movq	%r13, 0x8(%rsp)
   4b75e:      	leaq	0x228(%rsp), %rdi
   4b766:      	leaq	0x80(%rsp), %rsi
   4b76e:      	callq	0x463f0 <std::sys::env::unix::getenv::{closure#0}>
   4b773:      	movq	0x228(%rsp), %rdx
   4b77b:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b785:      	leaq	0x1(%rcx), %rax
   4b789:      	cmpq	%rax, %rdx
   4b78c:      	jne	0x4c349 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1189>
   4b792:      	movq	0x230(%rsp), %rax
   4b79a:      	movq	0x8(%rsp), %r13
   4b79f:      	jmp	0x4b7bd <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x5fd>
   4b7a1:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4b7ab:      	incq	%rax
   4b7ae:      	movq	%rax, 0x228(%rsp)
   4b7b6:      	leaq	0x10893(%rip), %rax     # 0x5c050 <writev+0x5c050>
   4b7bd:      	movl	%eax, %ecx
   4b7bf:      	andl	$0x3, %ecx
   4b7c2:      	leal	-0x2(%rcx), %edx
   4b7c5:      	cmpl	$0x2, %edx
   4b7c8:      	jb	0x4b817 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x657>
   4b7ca:      	testq	%rcx, %rcx
   4b7cd:      	je	0x4b817 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x657>
   4b7cf:      	movq	%r13, %r14
   4b7d2:      	leaq	-0x1(%rax), %rcx
   4b7d6:      	movq	%rcx, 0x8(%rsp)
   4b7db:      	movq	-0x1(%rax), %rbp
   4b7df:      	movq	0x7(%rax), %r13
   4b7e3:      	movq	(%r13), %rax
   4b7e7:      	testq	%rax, %rax
   4b7ea:      	je	0x4b7f1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x631>
   4b7ec:      	movq	%rbp, %rdi
   4b7ef:      	callq	*%rax
   4b7f1:      	cmpq	$0x0, 0x8(%r13)
   4b7f6:      	je	0x4b801 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x641>
   4b7f8:      	movq	%rbp, %rdi
   4b7fb:      	callq	*0x1173f(%rip)          # 0x5cf40 <writev+0x5cf40>
   4b801:      	movq	0x8(%rsp), %rdi
   4b806:      	callq	*0x11734(%rip)          # 0x5cf40 <writev+0x5cf40>
   4b80c:      	movq	%r14, %r13
   4b80f:      	leaq	0x80(%rsp), %r14
   4b817:      	xorl	%ebp, %ebp
   4b819:      	movl	$0x180, %edi            # imm = 0x180
   4b81e:      	callq	*0x117bc(%rip)          # 0x5cfe0 <writev+0x5cfe0>
   4b824:      	testq	%rax, %rax
   4b827:      	je	0x4c4d1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1311>
   4b82d:      	movq	%r13, %rcx
   4b830:      	movq	%rax, %r13
   4b833:      	movq	%rcx, (%rax)
   4b836:      	movq	0x38(%rsp), %rcx
   4b83b:      	movq	%rcx, 0x8(%rax)
   4b83f:      	movq	%rbx, 0x10(%rax)
   4b843:      	movq	0x60(%rsp), %rcx
   4b848:      	movq	%rcx, 0x18(%rax)
   4b84c:      	movq	0x48(%rsp), %rcx
   4b851:      	movq	%rcx, 0x20(%rax)
   4b855:      	movq	0x200(%rsp), %rcx
   4b85d:      	movq	%rcx, 0x28(%rax)
   4b861:      	movq	0x68(%rsp), %rcx
   4b866:      	movq	%rcx, 0x30(%rax)
   4b86a:      	movq	0x50(%rsp), %rcx
   4b86f:      	movq	%rcx, 0x38(%rax)
   4b873:      	movq	0x208(%rsp), %rcx
   4b87b:      	movq	%rcx, 0x40(%rax)
   4b87f:      	movq	0x70(%rsp), %rcx
   4b884:      	movq	%rcx, 0x48(%rax)
   4b888:      	movq	0x40(%rsp), %rcx
   4b88d:      	movq	%rcx, 0x50(%rax)
   4b891:      	movq	%r15, 0x58(%rax)
   4b895:      	movq	0x78(%rsp), %rcx
   4b89a:      	movq	%rcx, 0x60(%rax)
   4b89e:      	movq	0x58(%rsp), %rcx
   4b8a3:      	movq	%rcx, 0x68(%rax)
   4b8a7:      	movq	0x210(%rsp), %rcx
   4b8af:      	movq	%rcx, 0x70(%rax)
   4b8b3:      	movq	0x28(%rsp), %rcx
   4b8b8:      	movq	%rcx, 0x78(%rax)
   4b8bc:      	movq	%r12, 0x80(%rax)
   4b8c3:      	addq	$0x88, %rax
   4b8c9:      	leaq	0x2f8(%rsp), %rsi
   4b8d1:      	movl	$0xd0, %edx
   4b8d6:      	movq	%rax, %rdi
   4b8d9:      	callq	*0x117f9(%rip)          # 0x5d0d8 <writev+0x5d0d8>
   4b8df:      	movq	$0x11, 0x158(%r13)
   4b8ea:      	movq	0x10(%rsp), %rax
   4b8ef:      	movq	%rax, 0x160(%r13)
   4b8f6:      	movq	$0x11, 0x168(%r13)
   4b901:      	movq	$0x0, 0x170(%r13)
   4b90c:      	movq	%rbp, 0x178(%r13)
   4b913:      	movq	%r13, 0x131be(%rip)     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b91a:      	leaq	0x972f(%rip), %rdi      # 0x55050 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4b921:      	callq	0x12260 <atexit>
   4b926:      	movq	$0x2, 0x88(%rsp)
   4b932:      	movq	$0x0, 0x90(%rsp)
   4b93e:      	movq	0x1319b(%rip), %rax     # 0x5eae0 <native_roots.0>
   4b945:      	movq	%rax, 0x80(%rsp)
   4b94d:      	movq	0x1316c(%rip), %rax     # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b954:      	incq	%rax
   4b957:      	movq	%rax, 0x13162(%rip)     # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b95e:      	movq	0x13163(%rip), %rcx     # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b965:      	cmpq	%rcx, %rax
   4b968:      	cmovbeq	%rcx, %rax
   4b96c:      	movq	%r14, 0x1316d(%rip)     # 0x5eae0 <native_roots.0>
   4b973:      	movq	%rax, 0x1314e(%rip)     # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b97a:      	cmpl	$0x0, 0x1322b(%rip)     # 0x5ebac <g.0>
   4b981:      	jne	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b987:      	movl	$0x1, 0x1321b(%rip)     # 0x5ebac <g.0>
   4b991:      	movq	$0x0, 0x98(%rsp)
   4b99d:      	leaq	0x111f4(%rip), %r15     # 0x5cb98 <ref.5>
   4b9a4:      	movq	%r15, 0xa0(%rsp)
   4b9ac:      	movq	$0x2, 0x90(%rsp)
   4b9b8:      	movq	0x13119(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b9bf:      	testq	%rdi, %rdi
   4b9c2:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4b9c8:      	movq	0x178(%rdi), %rcx
   4b9cf:      	testq	%rcx, %rcx
   4b9d2:      	je	0x4ba19 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x859>
   4b9d4:      	movq	0x170(%rdi), %rax
   4b9db:      	incq	%rax
   4b9de:      	movq	%rax, 0x170(%rdi)
   4b9e5:      	movq	%rax, %rdx
   4b9e8:      	orq	%rcx, %rdx
   4b9eb:      	shrq	$0x20, %rdx
   4b9ef:      	je	0x4c2a7 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x10e7>
   4b9f5:      	xorl	%edx, %edx
   4b9f7:      	divq	%rcx
   4b9fa:      	testq	%rdx, %rdx
   4b9fd:      	jne	0x4ba19 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x859>
   4b9ff:      	leaq	0x80(%rsp), %rsi
   4ba07:      	movq	%rdi, %rbx
   4ba0a:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ba0f:      	movq	%rbx, %rdi
   4ba12:      	movq	0x130c7(%rip), %r14     # 0x5eae0 <native_roots.0>
   4ba19:      	movl	$0x18, %esi
   4ba1e:      	movq	%r14, %rdx
   4ba21:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ba26:      	testq	%rax, %rax
   4ba29:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4ba2f:      	movq	$0x3a, (%rax)
   4ba36:      	movq	%r15, 0x8(%rax)
   4ba3a:      	movq	$0x0, 0x10(%rax)
   4ba42:      	movq	%rax, 0x13167(%rip)     # 0x5ebb0 <g.1>
   4ba49:      	movb	$0x1, 0x13168(%rip)     # 0x5ebb8 <g.2>
   4ba50:      	movq	$0x0, 0x98(%rsp)
   4ba5c:      	leaq	0x11155(%rip), %r14     # 0x5cbb8 <ref.7>
   4ba63:      	movq	%r14, 0xa0(%rsp)
   4ba6b:      	movq	$0x2, 0x90(%rsp)
   4ba77:      	movq	0x1305a(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ba7e:      	testq	%rdi, %rdi
   4ba81:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4ba87:      	movq	0x178(%rdi), %rcx
   4ba8e:      	testq	%rcx, %rcx
   4ba91:      	je	0x4bad0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x910>
   4ba93:      	movq	0x170(%rdi), %rax
   4ba9a:      	incq	%rax
   4ba9d:      	movq	%rax, 0x170(%rdi)
   4baa4:      	movq	%rax, %rdx
   4baa7:      	orq	%rcx, %rdx
   4baaa:      	shrq	$0x20, %rdx
   4baae:      	je	0x4c2b9 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x10f9>
   4bab4:      	xorl	%edx, %edx
   4bab6:      	divq	%rcx
   4bab9:      	testq	%rdx, %rdx
   4babc:      	jne	0x4bad0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x910>
   4babe:      	movq	0x1301b(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bac5:      	movq	%rdi, %rbx
   4bac8:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bacd:      	movq	%rbx, %rdi
   4bad0:      	movq	0x13009(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bad7:      	movl	$0x18, %esi
   4badc:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bae1:      	testq	%rax, %rax
   4bae4:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4baea:      	movq	$0x36, (%rax)
   4baf1:      	movq	%r14, 0x8(%rax)
   4baf5:      	movq	$0x0, 0x10(%rax)
   4bafd:      	movq	%rax, 0x130bc(%rip)     # 0x5ebc0 <g.3>
   4bb04:      	movb	$0x1, 0x130bd(%rip)     # 0x5ebc8 <g.4>
   4bb0b:      	movq	$0x0, 0x90(%rsp)
   4bb17:      	movq	0x12fba(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bb1e:      	testq	%rdi, %rdi
   4bb21:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bb27:      	movq	0x178(%rdi), %rcx
   4bb2e:      	testq	%rcx, %rcx
   4bb31:      	je	0x4bb70 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x9b0>
   4bb33:      	movq	0x170(%rdi), %rax
   4bb3a:      	incq	%rax
   4bb3d:      	movq	%rax, 0x170(%rdi)
   4bb44:      	movq	%rax, %rdx
   4bb47:      	orq	%rcx, %rdx
   4bb4a:      	shrq	$0x20, %rdx
   4bb4e:      	je	0x4c2cb <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x110b>
   4bb54:      	xorl	%edx, %edx
   4bb56:      	divq	%rcx
   4bb59:      	testq	%rdx, %rdx
   4bb5c:      	jne	0x4bb70 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x9b0>
   4bb5e:      	movq	0x12f7b(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bb65:      	movq	%rdi, %rbx
   4bb68:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bb6d:      	movq	%rbx, %rdi
   4bb70:      	movq	0x12f69(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bb77:      	movl	$0x8, %esi
   4bb7c:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bb81:      	testq	%rax, %rax
   4bb84:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bb8a:      	movq	$0x32, (%rax)
   4bb91:      	movq	%rax, 0x13038(%rip)     # 0x5ebd0 <g.5>
   4bb98:      	movb	$0x1, 0x13039(%rip)     # 0x5ebd8 <g.6>
   4bb9f:      	movq	$0x0, 0x90(%rsp)
   4bbab:      	movq	0x12f26(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bbb2:      	testq	%rdi, %rdi
   4bbb5:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bbbb:      	movq	0x178(%rdi), %rcx
   4bbc2:      	testq	%rcx, %rcx
   4bbc5:      	je	0x4bc04 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xa44>
   4bbc7:      	movq	0x170(%rdi), %rax
   4bbce:      	incq	%rax
   4bbd1:      	movq	%rax, 0x170(%rdi)
   4bbd8:      	movq	%rax, %rdx
   4bbdb:      	orq	%rcx, %rdx
   4bbde:      	shrq	$0x20, %rdx
   4bbe2:      	je	0x4c2dd <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x111d>
   4bbe8:      	xorl	%edx, %edx
   4bbea:      	divq	%rcx
   4bbed:      	testq	%rdx, %rdx
   4bbf0:      	jne	0x4bc04 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xa44>
   4bbf2:      	movq	0x12ee7(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bbf9:      	movq	%rdi, %rbx
   4bbfc:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bc01:      	movq	%rbx, %rdi
   4bc04:      	movq	0x12ed5(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bc0b:      	movl	$0x8, %esi
   4bc10:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bc15:      	testq	%rax, %rax
   4bc18:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bc1e:      	movq	$0x2e, (%rax)
   4bc25:      	movq	%rax, 0x12fb4(%rip)     # 0x5ebe0 <g.7>
   4bc2c:      	movb	$0x1, 0x12fb5(%rip)     # 0x5ebe8 <g.8>
   4bc33:      	movq	$0x0, 0x98(%rsp)
   4bc3f:      	leaq	0x10f32(%rip), %r14     # 0x5cb78 <ref.3>
   4bc46:      	movq	%r14, 0xa0(%rsp)
   4bc4e:      	movq	$0x2, 0x90(%rsp)
   4bc5a:      	movq	0x12e77(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bc61:      	testq	%rdi, %rdi
   4bc64:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bc6a:      	movq	0x178(%rdi), %rcx
   4bc71:      	testq	%rcx, %rcx
   4bc74:      	je	0x4bcb3 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xaf3>
   4bc76:      	movq	0x170(%rdi), %rax
   4bc7d:      	incq	%rax
   4bc80:      	movq	%rax, 0x170(%rdi)
   4bc87:      	movq	%rax, %rdx
   4bc8a:      	orq	%rcx, %rdx
   4bc8d:      	shrq	$0x20, %rdx
   4bc91:      	je	0x4c2ef <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x112f>
   4bc97:      	xorl	%edx, %edx
   4bc99:      	divq	%rcx
   4bc9c:      	testq	%rdx, %rdx
   4bc9f:      	jne	0x4bcb3 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xaf3>
   4bca1:      	movq	0x12e38(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bca8:      	movq	%rdi, %rbx
   4bcab:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bcb0:      	movq	%rbx, %rdi
   4bcb3:      	movq	0x12e26(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bcba:      	movl	$0x18, %esi
   4bcbf:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bcc4:      	testq	%rax, %rax
   4bcc7:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bccd:      	movq	$0x3a, (%rax)
   4bcd4:      	movq	%r14, 0x8(%rax)
   4bcd8:      	movq	$0x0, 0x10(%rax)
   4bce0:      	movq	%rax, 0x12f09(%rip)     # 0x5ebf0 <g.9>
   4bce7:      	movb	$0x1, 0x12f0a(%rip)     # 0x5ebf8 <g.10>
   4bcee:      	movq	$0x0, 0x90(%rsp)
   4bcfa:      	movq	$0x1f4, 0x228(%rsp)     # imm = 0x1F4
   4bd06:      	leaq	0x228(%rsp), %rax
   4bd0e:      	movq	0x228(%rsp), %rax
   4bd16:      	movq	%rax, 0x12ee3(%rip)     # 0x5ec00 <g.11>
   4bd1d:      	movb	$0x1, 0x12ee4(%rip)     # 0x5ec08 <g.12>
   4bd24:      	movq	$0x0, 0x90(%rsp)
   4bd30:      	movq	$0xf4240, 0x228(%rsp)   # imm = 0xF4240
   4bd3c:      	leaq	0x228(%rsp), %rax
   4bd44:      	movq	0x228(%rsp), %rax
   4bd4c:      	movq	%rax, 0x12ebd(%rip)     # 0x5ec10 <g.13>
   4bd53:      	movb	$0x1, 0x12ebe(%rip)     # 0x5ec18 <g.14>
   4bd5a:      	movq	$0x0, 0x90(%rsp)
   4bd66:      	movq	0x12d6b(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bd6d:      	testq	%rdi, %rdi
   4bd70:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bd76:      	movq	0x178(%rdi), %rcx
   4bd7d:      	testq	%rcx, %rcx
   4bd80:      	je	0x4bdbf <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xbff>
   4bd82:      	movq	0x170(%rdi), %rax
   4bd89:      	incq	%rax
   4bd8c:      	movq	%rax, 0x170(%rdi)
   4bd93:      	movq	%rax, %rdx
   4bd96:      	orq	%rcx, %rdx
   4bd99:      	shrq	$0x20, %rdx
   4bd9d:      	je	0x4c301 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1141>
   4bda3:      	xorl	%edx, %edx
   4bda5:      	divq	%rcx
   4bda8:      	testq	%rdx, %rdx
   4bdab:      	jne	0x4bdbf <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xbff>
   4bdad:      	movq	0x12d2c(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bdb4:      	movq	%rdi, %rbx
   4bdb7:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bdbc:      	movq	%rbx, %rdi
   4bdbf:      	movq	0x12d1a(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bdc6:      	movl	$0x8, %esi
   4bdcb:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bdd0:      	testq	%rax, %rax
   4bdd3:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bdd9:      	movq	$0x2e, (%rax)
   4bde0:      	movq	%rax, 0x12e39(%rip)     # 0x5ec20 <g.15>
   4bde7:      	movl	$0x2, 0x12dbb(%rip)     # 0x5ebac <g.0>
   4bdf1:      	cmpq	$0x0, 0x88(%rsp)
   4bdfa:      	je	0x4be12 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xc52>
   4bdfc:      	movq	0x80(%rsp), %rax
   4be04:      	movq	%rax, 0x12cd5(%rip)     # 0x5eae0 <native_roots.0>
   4be0b:      	decq	0x12cae(%rip)           # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4be12:      	callq	0x4ca10 <<std::sys::pal::unix::time::Timespec>::now>
   4be17:      	movq	%rax, %rbx
   4be1a:      	movl	%edx, %ebp
   4be1c:      	movq	$0x5, 0x88(%rsp)
   4be28:      	movq	$0x0, 0x90(%rsp)
   4be34:      	movq	0x12ca5(%rip), %rax     # 0x5eae0 <native_roots.0>
   4be3b:      	movq	%rax, 0x80(%rsp)
   4be43:      	leaq	0x80(%rsp), %rcx
   4be4b:      	movq	%rcx, 0x12c8e(%rip)     # 0x5eae0 <native_roots.0>
   4be52:      	movq	0x12c67(%rip), %rax     # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4be59:      	incq	%rax
   4be5c:      	movq	%rax, 0x12c5d(%rip)     # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4be63:      	movq	0x12c5e(%rip), %rdx     # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4be6a:      	cmpq	%rdx, %rax
   4be6d:      	cmovbeq	%rdx, %rax
   4be71:      	movq	%rax, 0x12c50(%rip)     # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4be78:      	xorpd	%xmm0, %xmm0
   4be7c:      	movupd	%xmm0, 0x98(%rsp)
   4be85:      	cmpl	$0x2, 0x12d20(%rip)     # 0x5ebac <g.0>
   4be8c:      	jne	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4be92:      	cmpq	$0x0, 0x12d86(%rip)     # 0x5ec20 <g.15>
   4be9a:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bea0:      	movq	$0x2, 0x90(%rsp)
   4beac:      	movq	0x12c25(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4beb3:      	testq	%rdi, %rdi
   4beb6:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bebc:      	movq	0x178(%rdi), %rsi
   4bec3:      	testq	%rsi, %rsi
   4bec6:      	je	0x4bf0d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xd4d>
   4bec8:      	movq	0x170(%rdi), %rax
   4becf:      	incq	%rax
   4bed2:      	movq	%rax, 0x170(%rdi)
   4bed9:      	movq	%rax, %rdx
   4bedc:      	orq	%rsi, %rdx
   4bedf:      	shrq	$0x20, %rdx
   4bee3:      	je	0x4c313 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1153>
   4bee9:      	xorl	%edx, %edx
   4beeb:      	divq	%rsi
   4beee:      	testq	%rdx, %rdx
   4bef1:      	jne	0x4bf0d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xd4d>
   4bef3:      	leaq	0x80(%rsp), %rsi
   4befb:      	movq	%rdi, %r14
   4befe:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bf03:      	movq	%r14, %rdi
   4bf06:      	movq	0x12bd3(%rip), %rcx     # 0x5eae0 <native_roots.0>
   4bf0d:      	movl	$0x18, %esi
   4bf12:      	movq	%rcx, %rdx
   4bf15:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bf1a:      	testq	%rax, %rax
   4bf1d:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bf23:      	movq	%rax, %r14
   4bf26:      	movq	$0x26, (%rax)
   4bf2d:      	movl	$0x0, 0x8(%rax)
   4bf34:      	movq	$0x0, 0x10(%rax)
   4bf3c:      	movq	%rax, 0x98(%rsp)
   4bf44:      	movq	%rax, 0xa8(%rsp)
   4bf4c:      	leaq	0x10c15(%rip), %r13     # 0x5cb68 <ref.2>
   4bf53:      	movq	%r13, 0xb0(%rsp)
   4bf5b:      	movq	%rax, 0xb8(%rsp)
   4bf63:      	movq	$0x5, 0x90(%rsp)
   4bf6f:      	movq	0x12b62(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bf76:      	testq	%rdi, %rdi
   4bf79:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4bf7f:      	movq	0x178(%rdi), %rcx
   4bf86:      	testq	%rcx, %rcx
   4bf89:      	je	0x4bfc8 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xe08>
   4bf8b:      	movq	0x170(%rdi), %rax
   4bf92:      	incq	%rax
   4bf95:      	movq	%rax, 0x170(%rdi)
   4bf9c:      	movq	%rax, %rdx
   4bf9f:      	orq	%rcx, %rdx
   4bfa2:      	shrq	$0x20, %rdx
   4bfa6:      	je	0x4c325 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1165>
   4bfac:      	xorl	%edx, %edx
   4bfae:      	divq	%rcx
   4bfb1:      	testq	%rdx, %rdx
   4bfb4:      	jne	0x4bfc8 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xe08>
   4bfb6:      	movq	0x12b23(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4bfbd:      	movq	%rdi, %r15
   4bfc0:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bfc5:      	movq	%r15, %rdi
   4bfc8:      	movq	0x12b11(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4bfcf:      	movl	$0x18, %esi
   4bfd4:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bfd9:      	testq	%rax, %rax
   4bfdc:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4bfe2:      	movq	%rax, %r15
   4bfe5:      	movq	$0x22, (%rax)
   4bfec:      	movq	$0x1, 0x8(%rax)
   4bff4:      	movq	%r14, 0x10(%rax)
   4bff8:      	movq	%rax, 0xa8(%rsp)
   4c000:      	movq	%r13, 0xb0(%rsp)
   4c008:      	movq	%r14, 0xb8(%rsp)
   4c010:      	movq	$0x5, 0x90(%rsp)
   4c01c:      	movq	0x12ab5(%rip), %rdi     # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c023:      	testq	%rdi, %rdi
   4c026:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c02c:      	movq	0x178(%rdi), %rcx
   4c033:      	testq	%rcx, %rcx
   4c036:      	je	0x4c075 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xeb5>
   4c038:      	movq	0x170(%rdi), %rax
   4c03f:      	incq	%rax
   4c042:      	movq	%rax, 0x170(%rdi)
   4c049:      	movq	%rax, %rdx
   4c04c:      	orq	%rcx, %rdx
   4c04f:      	shrq	$0x20, %rdx
   4c053:      	je	0x4c337 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1177>
   4c059:      	xorl	%edx, %edx
   4c05b:      	divq	%rcx
   4c05e:      	testq	%rdx, %rdx
   4c061:      	jne	0x4c075 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xeb5>
   4c063:      	movq	0x12a76(%rip), %rsi     # 0x5eae0 <native_roots.0>
   4c06a:      	movq	%rdi, %r12
   4c06d:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c072:      	movq	%r12, %rdi
   4c075:      	movq	0x12a64(%rip), %rdx     # 0x5eae0 <native_roots.0>
   4c07c:      	movl	$0x18, %esi
   4c081:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c086:      	testq	%rax, %rax
   4c089:      	je	0x4c734 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1574>
   4c08f:      	movq	$0x3a, (%rax)
   4c096:      	movq	%r13, 0x8(%rax)
   4c09a:      	movq	%r15, 0x10(%rax)
   4c09e:      	movq	%rax, 0x10(%r14)
   4c0a2:      	movq	0x98(%rsp), %rax
   4c0aa:      	testq	%rax, %rax
   4c0ad:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c0b3:      	movl	$0x1, 0x8(%rax)
   4c0ba:      	movq	0x98(%rsp), %rax
   4c0c2:      	testq	%rax, %rax
   4c0c5:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c0cb:      	cmpl	$0x0, 0x8(%rax)
   4c0cf:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c0d5:      	movq	0x10(%rax), %rax
   4c0d9:      	testq	%rax, %rax
   4c0dc:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c0e2:      	movq	%rax, 0xa0(%rsp)
   4c0ea:      	movq	0x8(%rax), %rcx
   4c0ee:      	testq	%rcx, %rcx
   4c0f1:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c0f7:      	movq	0x10(%rax), %rdi
   4c0fb:      	movq	0x8(%rcx), %rax
   4c0ff:      	cmpq	$0x0, 0x88(%rsp)
   4c108:      	je	0x4c120 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xf60>
   4c10a:      	movq	0x80(%rsp), %rcx
   4c112:      	movq	%rcx, 0x129c7(%rip)     # 0x5eae0 <native_roots.0>
   4c119:      	decq	0x129a0(%rip)           # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c120:      	xorl	%esi, %esi
   4c122:      	xorl	%edx, %edx
   4c124:      	callq	*%rax
   4c126:      	subq	$0x8, %rsp
   4c12a:      	movq	%rax, %r14
   4c12d:      	movq	%rax, 0x218(%rsp)
   4c135:      	callq	0x4ca10 <<std::sys::pal::unix::time::Timespec>::now>
   4c13a:      	movq	%rax, 0x2f8(%rsp)
   4c142:      	movl	%edx, 0x300(%rsp)
   4c149:      	movq	%rbx, 0x228(%rsp)
   4c151:      	movl	%ebp, 0x230(%rsp)
   4c158:      	leaq	0x80(%rsp), %rdi
   4c160:      	leaq	0x2f8(%rsp), %rbx
   4c168:      	leaq	0x228(%rsp), %rdx
   4c170:      	movq	%rbx, %rsi
   4c173:      	callq	0x4cae0 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4c178:      	cmpb	$0x0, 0x80(%rsp)
   4c180:      	xorpd	%xmm0, %xmm0
   4c184:      	jne	0x4c1c2 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1002>
   4c186:      	movsd	0x88(%rsp), %xmm1
   4c18f:      	unpcklps	-0x48346(%rip), %xmm1   # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x3e50 <writev+0x3e50>
   4c196:      	subpd	-0x483ae(%rip), %xmm1   # 0x3df0 <writev+0x3df0>
   4c19e:      	movapd	%xmm1, %xmm2
   4c1a2:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   4c1a6:      	xorps	%xmm0, %xmm0
   4c1a9:      	cvtsi2sdl	0x90(%rsp), %xmm0
   4c1b2:      	addsd	%xmm1, %xmm2
   4c1b6:      	divsd	-0x467f6(%rip), %xmm0   # 0x59c8 <writev+0x59c8>
   4c1be:      	addsd	%xmm2, %xmm0
   4c1c2:      	movsd	%xmm0, 0x220(%rsp)
   4c1cb:      	cmpq	$0xf4240, %r14          # imm = 0xF4240
   4c1d2:      	jne	0x4c277 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x10b7>
   4c1d8:      	leaq	0x218(%rsp), %rax
   4c1e0:      	movq	%rax, 0x228(%rsp)
   4c1e8:      	leaq	0x12d1(%rip), %rax      # 0x4d4c0 <<i64 as core::fmt::Display>::fmt>
   4c1ef:      	movq	%rax, 0x230(%rsp)
   4c1f7:      	leaq	0x220(%rsp), %rax
   4c1ff:      	movq	%rax, 0x238(%rsp)
   4c207:      	leaq	0x13d2(%rip), %rax      # 0x4d5e0 <<f64 as core::fmt::Display>::fmt>
   4c20e:      	movq	%rax, 0x240(%rsp)
   4c216:      	leaq	-0x42926(%rip), %rax    # 0x98f7 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1353>
   4c21d:      	movq	%rax, 0x2f8(%rsp)
   4c225:      	movq	$0x6, 0x300(%rsp)
   4c231:      	movl	0x11f19(%rip), %eax     # 0x5e150 <std::io::stdio::STDOUT+0x38>
   4c237:      	testl	%eax, %eax
   4c239:      	jne	0x4c4db <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x131b>
   4c23f:      	movq	%fs:-0x8, %r14
   4c248:      	testq	%r14, %r14
   4c24b:      	je	0x4c4f2 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1332>
   4c251:      	movq	0x11ec0(%rip), %rax     # 0x5e118 <std::io::stdio::STDOUT>
   4c258:      	cmpq	%rax, %r14
   4c25b:      	jne	0x4c532 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1372>
   4c261:      	movl	0x11ebd(%rip), %ebp     # 0x5e124 <std::io::stdio::STDOUT+0xc>
   4c267:      	cmpl	$-0x1, %ebp
   4c26a:      	je	0x4c699 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x14d9>
   4c270:      	incl	%ebp
   4c272:      	jmp	0x4c54e <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x138e>
   4c277:      	leaq	0x80(%rsp), %rdi
   4c27f:      	callq	0x4cbb0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4c284:      	cmpq	$0x0, 0x80(%rsp)
   4c28d:      	jle	0x4c29d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x10dd>
   4c28f:      	movq	0x88(%rsp), %rdi
   4c297:      	callq	*0x10ca3(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c29d:      	movl	$0x1, %eax
   4c2a2:      	jmp	0x4c682 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x14c2>
   4c2a7:      	xorl	%edx, %edx
   4c2a9:      	divl	%ecx
   4c2ab:      	testq	%rdx, %rdx
   4c2ae:      	jne	0x4ba19 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x859>
   4c2b4:      	jmp	0x4b9ff <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x83f>
   4c2b9:      	xorl	%edx, %edx
   4c2bb:      	divl	%ecx
   4c2bd:      	testq	%rdx, %rdx
   4c2c0:      	jne	0x4bad0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x910>
   4c2c6:      	jmp	0x4babe <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x8fe>
   4c2cb:      	xorl	%edx, %edx
   4c2cd:      	divl	%ecx
   4c2cf:      	testq	%rdx, %rdx
   4c2d2:      	jne	0x4bb70 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x9b0>
   4c2d8:      	jmp	0x4bb5e <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x99e>
   4c2dd:      	xorl	%edx, %edx
   4c2df:      	divl	%ecx
   4c2e1:      	testq	%rdx, %rdx
   4c2e4:      	jne	0x4bc04 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xa44>
   4c2ea:      	jmp	0x4bbf2 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xa32>
   4c2ef:      	xorl	%edx, %edx
   4c2f1:      	divl	%ecx
   4c2f3:      	testq	%rdx, %rdx
   4c2f6:      	jne	0x4bcb3 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xaf3>
   4c2fc:      	jmp	0x4bca1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xae1>
   4c301:      	xorl	%edx, %edx
   4c303:      	divl	%ecx
   4c305:      	testq	%rdx, %rdx
   4c308:      	jne	0x4bdbf <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xbff>
   4c30e:      	jmp	0x4bdad <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xbed>
   4c313:      	xorl	%edx, %edx
   4c315:      	divl	%esi
   4c317:      	testq	%rdx, %rdx
   4c31a:      	jne	0x4bf0d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xd4d>
   4c320:      	jmp	0x4bef3 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xd33>
   4c325:      	xorl	%edx, %edx
   4c327:      	divl	%ecx
   4c329:      	testq	%rdx, %rdx
   4c32c:      	jne	0x4bfc8 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xe08>
   4c332:      	jmp	0x4bfb6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xdf6>
   4c337:      	xorl	%edx, %edx
   4c339:      	divl	%ecx
   4c33b:      	testq	%rdx, %rdx
   4c33e:      	jne	0x4c075 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xeb5>
   4c344:      	jmp	0x4c063 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0xea3>
   4c349:      	cmpq	%rcx, %rdx
   4c34c:      	jne	0x4c35a <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x119a>
   4c34e:      	xorl	%ebp, %ebp
   4c350:      	movq	0x8(%rsp), %r13
   4c355:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c35a:      	movq	%rdx, 0x20(%rsp)
   4c35f:      	movq	0x230(%rsp), %rsi
   4c367:      	movq	0x238(%rsp), %r13
   4c36f:      	leaq	0x80(%rsp), %rdi
   4c377:      	movq	%rsi, 0x30(%rsp)
   4c37c:      	movq	%r13, %rdx
   4c37f:      	callq	0x19ed0 <core::str::converts::from_utf8>
   4c384:      	cmpb	$0x0, 0x80(%rsp)
   4c38c:      	je	0x4c3ab <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x11eb>
   4c38e:      	xorl	%ebp, %ebp
   4c390:      	cmpq	$0x0, 0x20(%rsp)
   4c396:      	movq	0x8(%rsp), %r13
   4c39b:      	movq	0x30(%rsp), %rdi
   4c3a0:      	jg	0x4c4b4 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12f4>
   4c3a6:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c3ab:      	testq	%r13, %r13
   4c3ae:      	je	0x4c3d9 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1219>
   4c3b0:      	cmpq	$0x1, %r13
   4c3b4:      	movq	0x30(%rsp), %rdi
   4c3b9:      	jne	0x4c3f9 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1239>
   4c3bb:      	movzbl	(%rdi), %eax
   4c3be:      	xorl	%ebp, %ebp
   4c3c0:      	cmpl	$0x2b, %eax
   4c3c3:      	movq	0x20(%rsp), %r11
   4c3c8:      	je	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c3ce:      	cmpl	$0x2d, %eax
   4c3d1:      	je	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c3d7:      	jmp	0x4c401 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1241>
   4c3d9:      	movq	%r13, %rbp
   4c3dc:      	movq	0x30(%rsp), %rdi
   4c3e1:      	movq	0x20(%rsp), %r11
   4c3e6:      	testq	%r11, %r11
   4c3e9:      	movq	0x8(%rsp), %r13
   4c3ee:      	jne	0x4c4b4 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12f4>
   4c3f4:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c3f9:      	movzbl	(%rdi), %eax
   4c3fc:      	movq	0x20(%rsp), %r11
   4c401:      	xorl	%ecx, %ecx
   4c403:      	cmpb	$0x2b, %al
   4c405:      	sete	%cl
   4c408:      	movq	%rcx, %rax
   4c40b:      	negq	%rax
   4c40e:      	movq	%r13, %rdx
   4c411:      	subq	%rcx, %rdx
   4c414:      	addq	%rdi, %rcx
   4c417:      	cmpq	$0x11, %rdx
   4c41b:      	jae	0x4c456 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1296>
   4c41d:      	testq	%rdx, %rdx
   4c420:      	je	0x4c493 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12d3>
   4c422:      	addq	%rax, %r13
   4c425:      	negq	%r13
   4c428:      	xorl	%eax, %eax
   4c42a:      	xorl	%ebp, %ebp
   4c42c:      	movzbl	(%rcx,%rax), %edx
   4c430:      	addl	$-0x30, %edx
   4c433:      	cmpl	$0x9, %edx
   4c436:      	ja	0x4c4a4 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e4>
   4c438:      	leaq	(,%rbp,4), %rsi
   4c440:      	addq	%rbp, %rsi
   4c443:      	movl	%edx, %edx
   4c445:      	leaq	(%rdx,%rsi,2), %rbp
   4c449:      	incq	%rax
   4c44c:      	movq	%r13, %rdx
   4c44f:      	addq	%rax, %rdx
   4c452:      	jne	0x4c42c <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x126c>
   4c454:      	jmp	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c456:      	addq	%rax, %r13
   4c459:      	negq	%r13
   4c45c:      	xorl	%ebp, %ebp
   4c45e:      	movl	$0xa, %esi
   4c463:      	xorl	%r9d, %r9d
   4c466:      	xorl	%eax, %eax
   4c468:      	movq	%r13, %rdx
   4c46b:      	addq	%r9, %rdx
   4c46e:      	je	0x4c4bf <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12ff>
   4c470:      	mulq	%rsi
   4c473:      	jo	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c475:      	movzbl	(%rcx,%r9), %r8d
   4c47a:      	addl	$-0x30, %r8d
   4c47e:      	addq	%r8, %rax
   4c481:      	setb	%dl
   4c484:      	cmpl	$0x9, %r8d
   4c488:      	ja	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c48a:      	incq	%r9
   4c48d:      	testb	%dl, %dl
   4c48f:      	je	0x4c468 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12a8>
   4c491:      	jmp	0x4c4a6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12e6>
   4c493:      	xorl	%ebp, %ebp
   4c495:      	testq	%r11, %r11
   4c498:      	movq	0x8(%rsp), %r13
   4c49d:      	jne	0x4c4b4 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12f4>
   4c49f:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c4a4:      	xorl	%ebp, %ebp
   4c4a6:      	testq	%r11, %r11
   4c4a9:      	movq	0x8(%rsp), %r13
   4c4ae:      	je	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c4b4:      	callq	*0x10a86(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c4ba:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c4bf:      	movq	%rax, %rbp
   4c4c2:      	testq	%r11, %r11
   4c4c5:      	movq	0x8(%rsp), %r13
   4c4ca:      	jne	0x4c4b4 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x12f4>
   4c4cc:      	jmp	0x4b819 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x659>
   4c4d1:      	movl	$0x180, %edi            # imm = 0x180
   4c4d6:      	callq	0x13470 <alloc::alloc::handle_alloc_error>
   4c4db:      	callq	0x4d612 <<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::get_or_init<std::io::stdio::stdout::{closure#0}>::{closure#0}, !>>
   4c4e0:      	movq	%fs:-0x8, %r14
   4c4e9:      	testq	%r14, %r14
   4c4ec:      	jne	0x4c251 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1091>
   4c4f2:      	movq	0x12677(%rip), %rax     # 0x5eb70 <<std::thread::id::ThreadId>::new::COUNTER>
   4c4f9:      	nopl	(%rax)
   4c500:      	cmpq	$-0x1, %rax
   4c504:      	je	0x4c694 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x14d4>
   4c50a:      	leaq	0x1(%rax), %r14
   4c50e:      	lock
   4c50f:      	cmpxchgq	%r14, 0x12659(%rip)     # 0x5eb70 <<std::thread::id::ThreadId>::new::COUNTER>
   4c517:      	jne	0x4c500 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1340>
   4c519:      	movq	%r14, %fs:-0x8
   4c522:      	movq	0x11bef(%rip), %rax     # 0x5e118 <std::io::stdio::STDOUT>
   4c529:      	cmpq	%rax, %r14
   4c52c:      	je	0x4c261 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x10a1>
   4c532:      	movl	$0x1, %ebp
   4c537:      	xorl	%eax, %eax
   4c539:      	lock
   4c53a:      	cmpxchgl	%ebp, 0x11bdf(%rip)     # 0x5e120 <std::io::stdio::STDOUT+0x8>
   4c541:      	jne	0x4c6b1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x14f1>
   4c547:      	movq	%r14, 0x11bca(%rip)     # 0x5e118 <std::io::stdio::STDOUT>
   4c54e:      	movl	%ebp, 0x11bd0(%rip)     # 0x5e124 <std::io::stdio::STDOUT+0xc>
   4c554:      	leaq	0x11bbd(%rip), %rax     # 0x5e118 <std::io::stdio::STDOUT>
   4c55b:      	movq	%rax, 0x18(%rsp)
   4c560:      	leaq	0x18(%rsp), %r12
   4c565:      	movq	%r12, 0x80(%rsp)
   4c56d:      	leaq	0x88(%rsp), %r14
   4c575:      	movq	$0x0, 0x88(%rsp)
   4c581:      	leaq	0xfa20(%rip), %rsi      # 0x5bfa8 <writev+0x5bfa8>
   4c588:      	leaq	-0x46b37(%rip), %rdx    # 0x5a58 <writev+0x5a58>
   4c58f:      	leaq	0x80(%rsp), %rdi
   4c597:      	leaq	0x228(%rsp), %rcx
   4c59f:      	callq	0x12f70 <core::fmt::write>
   4c5a4:      	movq	0x88(%rsp), %rcx
   4c5ac:      	testb	%al, %al
   4c5ae:      	je	0x4c5d0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1410>
   4c5b0:      	movq	%rcx, %r15
   4c5b3:      	testq	%rcx, %rcx
   4c5b6:      	jne	0x4c620 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1460>
   4c5b8:      	leaq	-0x436a3(%rip), %rdi    # 0x8f1c <core::num::flt2dec::strategy::dragon::POW5TO256+0x978>
   4c5bf:      	leaq	0xf99a(%rip), %rdx      # 0x5bf60 <writev+0x5bf60>
   4c5c6:      	movl	$0xad, %esi
   4c5cb:      	callq	0x134a0 <core::panicking::panic_fmt>
   4c5d0:      	testq	%rcx, %rcx
   4c5d3:      	je	0x4c61d <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x145d>
   4c5d5:      	movl	%ecx, %eax
   4c5d7:      	andl	$0x3, %eax
   4c5da:      	xorl	%r15d, %r15d
   4c5dd:      	leal	-0x2(%rax), %edx
   4c5e0:      	cmpl	$0x2, %edx
   4c5e3:      	jb	0x4c620 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1460>
   4c5e5:      	testq	%rax, %rax
   4c5e8:      	je	0x4c620 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1460>
   4c5ea:      	leaq	-0x1(%rcx), %r14
   4c5ee:      	movq	-0x1(%rcx), %r15
   4c5f2:      	movq	0x7(%rcx), %r13
   4c5f6:      	movq	(%r13), %rax
   4c5fa:      	testq	%rax, %rax
   4c5fd:      	je	0x4c604 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1444>
   4c5ff:      	movq	%r15, %rdi
   4c602:      	callq	*%rax
   4c604:      	cmpq	$0x0, 0x8(%r13)
   4c609:      	je	0x4c614 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1454>
   4c60b:      	movq	%r15, %rdi
   4c60e:      	callq	*0x1092c(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c614:      	movq	%r14, %rdi
   4c617:      	callq	*0x10923(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c61d:      	xorl	%r15d, %r15d
   4c620:      	movq	0x18(%rsp), %rsi
   4c625:      	decl	0xc(%rsi)
   4c628:      	jne	0x4c63f <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x147f>
   4c62a:      	movq	$0x0, (%rsi)
   4c631:      	xorl	%eax, %eax
   4c633:      	xchgl	%eax, 0x8(%rsi)
   4c636:      	cmpl	$0x2, %eax
   4c639:      	je	0x4c6c2 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1502>
   4c63f:      	testq	%r15, %r15
   4c642:      	jne	0x4c6e6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1526>
   4c648:      	leaq	0x80(%rsp), %rdi
   4c650:      	callq	0x4cbb0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4c655:      	movq	0x80(%rsp), %rbx
   4c65d:      	testq	%rbx, %rbx
   4c660:      	jle	0x4c670 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x14b0>
   4c662:      	movq	0x88(%rsp), %rdi
   4c66a:      	callq	*0x108d0(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c670:      	xorl	%eax, %eax
   4c672:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4c67c:      	cmpq	%rcx, %rbx
   4c67f:      	setne	%al
   4c682:      	addq	$0x3c8, %rsp            # imm = 0x3C8
   4c689:      	popq	%rbx
   4c68a:      	popq	%r12
   4c68c:      	popq	%r13
   4c68e:      	popq	%r14
   4c690:      	popq	%r15
   4c692:      	popq	%rbp
   4c693:      	retq
   4c694:      	callq	0x47b10 <<std::thread::id::ThreadId>::new::exhausted>
   4c699:      	leaq	-0x42f8c(%rip), %rdi    # 0x9714 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1170>
   4c6a0:      	leaq	0xfd71(%rip), %rdx      # 0x5c418 <writev+0x5c418>
   4c6a7:      	movl	$0x26, %esi
   4c6ac:      	callq	0x4d670 <core::option::expect_failed>
   4c6b1:      	leaq	0x11a68(%rip), %rdi     # 0x5e120 <std::io::stdio::STDOUT+0x8>
   4c6b8:      	callq	0x467a0 <<std::sys::sync::mutex::futex::Mutex>::lock_contended>
   4c6bd:      	jmp	0x4c547 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1387>
   4c6c2:      	addq	$0x8, %rsi
   4c6c6:      	movl	$0xca, %edi
   4c6cb:      	movl	$0x81, %edx
   4c6d0:      	movl	$0x1, %ecx
   4c6d5:      	xorl	%eax, %eax
   4c6d7:      	callq	*0x1086b(%rip)          # 0x5cf48 <writev+0x5cf48>
   4c6dd:      	testq	%r15, %r15
   4c6e0:      	je	0x4c648 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1488>
   4c6e6:      	movq	%r15, 0x18(%rsp)
   4c6eb:      	movq	%rbx, 0x80(%rsp)
   4c6f3:      	leaq	-0x339aa(%rip), %rax    # 0x18d50 <<&str as core::fmt::Display>::fmt>
   4c6fa:      	movq	%rax, 0x88(%rsp)
   4c702:      	movq	%r12, 0x90(%rsp)
   4c70a:      	leaq	0x153f(%rip), %rax      # 0x4dc50 <<std::io::error::Error as core::fmt::Display>::fmt>
   4c711:      	movq	%rax, 0x98(%rsp)
   4c719:      	leaq	-0x45f7d(%rip), %rdi    # 0x67a3 <writev+0x67a3>
   4c720:      	leaq	0xf911(%rip), %rdx      # 0x5c038 <writev+0x5c038>
   4c727:      	leaq	0x80(%rsp), %rsi
   4c72f:      	callq	0x134a0 <core::panicking::panic_fmt>
   4c734:      	leaq	-0x4396f(%rip), %rdi    # 0x8dcc <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   4c73b:      	movl	$0x2f, %esi
   4c740:      	callq	0x55a00 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   4c745:      	movq	%r15, %rdi
   4c748:      	callq	0x13470 <alloc::alloc::handle_alloc_error>
   4c74d:      	movl	$0x198, %edi            # imm = 0x198
   4c752:      	callq	0x13470 <alloc::alloc::handle_alloc_error>
   4c757:      	movl	$0x30, %edi
   4c75c:      	callq	0x13470 <alloc::alloc::handle_alloc_error>
   4c761:      	movl	$0x88, %edi
   4c766:      	callq	0x13470 <alloc::alloc::handle_alloc_error>
   4c76b:      	movq	%r13, 0x8(%rsp)
   4c770:      	movq	%r12, 0x10(%rsp)
   4c775:      	testq	%rbx, %rbx
   4c778:      	jne	0x4c7a0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15e0>
   4c77a:      	cmpq	$0x0, 0x8(%rsp)
   4c780:      	jne	0x4c7e6 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1626>
   4c782:      	cmpq	$0x0, 0x60(%rsp)
   4c788:      	jne	0x4c7f9 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1639>
   4c78a:      	cmpq	$0x0, 0x68(%rsp)
   4c790:      	jne	0x4c80c <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x164c>
   4c792:      	testq	%r15, %r15
   4c795:      	je	0x4c81c <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x165c>
   4c79b:      	jmp	0x4c839 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1679>
   4c7a0:      	movq	0x38(%rsp), %rax
   4c7a5:      	leaq	0x18(%rax), %r14
   4c7a9:      	movq	0x10748(%rip), %r13     # 0x5cef8 <writev+0x5cef8>
   4c7b0:      	movq	0x10789(%rip), %rbp     # 0x5cf40 <writev+0x5cf40>
   4c7b7:      	jmp	0x4c7c9 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1609>
   4c7b9:      	nopl	(%rax)
   4c7c0:      	addq	$0x38, %r14
   4c7c4:      	decq	%rbx
   4c7c7:      	je	0x4c77a <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15ba>
   4c7c9:      	movq	-0x8(%r14), %rsi
   4c7cd:      	movq	(%r14), %rdi
   4c7d0:      	shlq	$0xf, %rsi
   4c7d4:      	callq	*%r13
   4c7d7:      	cmpq	$0x0, -0x18(%r14)
   4c7dc:      	je	0x4c7c0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1600>
   4c7de:      	movq	-0x10(%r14), %rdi
   4c7e2:      	callq	*%rbp
   4c7e4:      	jmp	0x4c7c0 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1600>
   4c7e6:      	movq	0x38(%rsp), %rdi
   4c7eb:      	callq	*0x1074f(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c7f1:      	cmpq	$0x0, 0x60(%rsp)
   4c7f7:      	je	0x4c78a <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15ca>
   4c7f9:      	movq	0x48(%rsp), %rdi
   4c7fe:      	callq	*0x1073c(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c804:      	cmpq	$0x0, 0x68(%rsp)
   4c80a:      	je	0x4c792 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x15d2>
   4c80c:      	movq	0x50(%rsp), %rdi
   4c811:      	callq	*0x10729(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c817:      	testq	%r15, %r15
   4c81a:      	jne	0x4c839 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1679>
   4c81c:      	cmpq	$0x0, 0x70(%rsp)
   4c822:      	jne	0x4c868 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x16a8>
   4c824:      	cmpq	$0x0, 0x78(%rsp)
   4c82a:      	jne	0x4c87b <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x16bb>
   4c82c:      	cmpq	$0x0, 0x28(%rsp)
   4c832:      	jne	0x4c88e <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x16ce>
   4c834:      	callq	0x54a00 <native_trap>
   4c839:      	movq	0x40(%rsp), %rax
   4c83e:      	leaq	0x8(%rax), %rbx
   4c842:      	movq	0x106f7(%rip), %r14     # 0x5cf40 <writev+0x5cf40>
   4c849:      	jmp	0x4c859 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1699>
   4c84b:      	nopl	(%rax,%rax)
   4c850:      	addq	$0x18, %rbx
   4c854:      	decq	%r15
   4c857:      	je	0x4c81c <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x165c>
   4c859:      	cmpq	$0x0, -0x8(%rbx)
   4c85e:      	jle	0x4c850 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1690>
   4c860:      	movq	(%rbx), %rdi
   4c863:      	callq	*%r14
   4c866:      	jmp	0x4c850 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1690>
   4c868:      	movq	0x40(%rsp), %rdi
   4c86d:      	callq	*0x106cd(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c873:      	cmpq	$0x0, 0x78(%rsp)
   4c879:      	je	0x4c82c <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x166c>
   4c87b:      	movq	0x58(%rsp), %rdi
   4c880:      	callq	*0x106ba(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c886:      	cmpq	$0x0, 0x28(%rsp)
   4c88c:      	je	0x4c834 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1674>
   4c88e:      	movq	0x10(%rsp), %rdi
   4c893:      	callq	*0x106a7(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c899:      	callq	0x54a00 <native_trap>
   4c89e:      	movq	%rax, %rbx
   4c8a1:      	cmpq	$0x0, 0x8(%r13)
   4c8a6:      	je	0x4c8b1 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x16f1>
   4c8a8:      	movq	%r15, %rdi
   4c8ab:      	callq	*0x1068f(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c8b1:      	movq	%r14, %rdi
   4c8b4:      	callq	*0x10686(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c8ba:      	movq	0x18(%rsp), %rdi
   4c8bf:      	callq	0x4dc10 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4c8c4:      	movq	%rbx, %rdi
   4c8c7:      	callq	0x59ca0 <_Unwind_Resume@plt>
   4c8cc:      	movq	%rax, %rbx
   4c8cf:      	cmpq	$0x0, 0x8(%r13)
   4c8d4:      	je	0x4c8df <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x171f>
   4c8d6:      	movq	%rbp, %rdi
   4c8d9:      	callq	*0x10661(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c8df:      	movq	0x8(%rsp), %rdi
   4c8e4:      	callq	*0x10656(%rip)          # 0x5cf40 <writev+0x5cf40>
   4c8ea:      	movq	%rbx, %rdi
   4c8ed:      	callq	0x59ca0 <_Unwind_Resume@plt>
   4c8f2:      	movq	%rax, %rbx
   4c8f5:      	cmpq	$0x0, 0x88(%rsp)
   4c8fe:      	je	0x4c908 <wasm_native_928a03dfb2368d885a7cb3fbb6bba7e8cd6f50e1b7fd05af0d37e3d14ce5a695::run::hdcb0eb7a9e33a887+0x1748>
   4c900:      	movq	%r14, %rdi
   4c903:      	callq	0x20ed0 <core::ptr::drop_in_place::<std::io::error::Error>>
   4c908:      	movq	0x18(%rsp), %rdi
   4c90d:      	callq	0x4dc10 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4c912:      	movq	%rbx, %rdi
   4c915:      	callq	0x59ca0 <_Unwind_Resume@plt>
   4c91a:      	callq	0x13eec <core::panicking::panic_in_cleanup>
   4c91f:      	movq	%rax, %rbx
   4c922:      	leaq	0x18(%rsp), %rdi
   4c927:      	callq	0x20ed0 <core::ptr::drop_in_place::<std::io::error::Error>>
   4c92c:      	movq	%rbx, %rdi
   4c92f:      	callq	0x59ca0 <_Unwind_Resume@plt>
   4c934:      	callq	0x13eec <core::panicking::panic_in_cleanup>
   4c939:      	int3
   4c93a:      	int3
   4c93b:      	int3
   4c93c:      	int3
   4c93d:      	int3
   4c93e:      	int3
   4c93f:      	int3
