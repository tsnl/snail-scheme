# Production shared-LTO work review

The six candidate timing executables retain their canonical computational work.
This is a review of the exact observation-disabled production executables, not
an inference from their barrier counts and not a performance measurement.

Control source is `bb2e90f713ad96b381b1843438c56724620c046e`; candidate source is
`f320ef2f1b160ed85b3823696d4a916ab352f0d4`. Both preparation processes exited zero
and were reaped. No compiler, test, profiler, or benchmark process from this
review remained when the coordinator started its measurement window.

`identities.json` binds every binary and assembly file to SHA-256, records the
source/manifest/plan identities, and supplies each final function-descriptor
relocation. `bind-artifacts.mjs` verified all 792 plan file references, all 66
available timing-artifact validation predicates and successful supervisor
cleanup records, and the six unavailable adapted-Chez rows (three per arm).
These validation executions happened during preparation and are not quiet
timing evidence. It also checks that each native artifact has exactly one
retained build attempt and that the Wasm actually lowered for native execution
equals the corresponding V8 artifact.

For each of the six cases, control and candidate have byte-identical canonical
inputs/specifications, timing entry, observation-disabled configuration, raw
Wasm, optimized Wasm, and lowered LLVM text. The frozen front end, lowering, and
Rust runtime are identical. Provider bodies differ only by the reviewed native
`black_box` value boundaries; executable linkage exposes the guest bitcode to
Rust LTO. The source inventory comparison is `../provenance.json`, and the
independent normal-validation route/Wasm audit is `../wasm-parity.json`.

Every timing configuration has `OBSERVE_BARRIERS = false`. The frozen execution
environment has no extra Rust flags, GC statistics, forced-GC interval, profiler,
preload, or Node coverage/options. These binaries were built by the ordinary
production scripts; no save-temps or diagnostic code-generation flags were
added. Candidate Cargo builds use the product's explicit native target and
shared fat-LTO settings. Historical trampoline providers were not used.

## Evidence method

Full disassembly was captured with LLVM objdump 22.1.8:

```
llvm-objdump --disassemble --demangle --no-show-raw-insn <program.native>
readelf --relocs --wide <candidate program.native>
```

The full `*-candidate.asm` and `*-control.asm` files are retained. The `*-run.asm`
and `*-guest.asm` files are exact section extracts. Final ELF relative
relocations connect the `ref.N` descriptors used by the live entry code to
their `f.N` bodies; 36 distinct candidate descriptor identities were checked
against the unchanged lowered LLVM declarations. This avoids relying on a
retained but unreachable recursive function as evidence. The addresses below
are relative virtual addresses in these exact executables.

The candidate's Rust `run` function contains the following live dispatches
between its two clock calls. Each passes an initial loop index of zero and a
closure environment containing the configured count. The complete source
predicate and expected result remain in the unchanged timing entry; the
artifact validation checks them before the artifact becomes eligible.

| Case | Count | First clock | Descriptor | Count store | Guest dispatch | Second clock |
| --- | ---: | --- | --- | --- | --- | --- |
| fib | 5 | `4b62c` | `ref.2 -> f.2` | `4b728` | `4b7f7` | `4b808` |
| fibfp | 10 | `4b634` | `ref.2 -> f.2` | `4b730` | `4b801` | `4b816` |
| mbrot | 1000 | `4bd3a` | `ref.2 -> f.2` | `4bf14` | `4c04c` | `4c05d` |
| array1 | 1 | `4be12` | `ref.2 -> f.2` | `4bfec` | `4c124` | `4c135` |
| bv2string | 100 | `4cb0c` | `ref.7 -> f.7` | `4cce6` | `4ce1e` | `4ce2f` |
| gcbench | 1 | `4cd2e` | `ref.5 -> f.5` | `4cefc` | `4d025` | `4d052` |

## Surviving computation

- **fib**, input 40, final result 102334155: `f.2` starts at `571c0`. Its loop
  body at `57260` reloads the opaque input through the stack (`57298` store,
  `572b8` reload), performs the expanded recursive computation, increments the
  outer index at `6e930`, and branches back at `6e997` after comparing the
  captured count. Recursive `f.3` at `6e9d0` retains both calls for n-1 and n-2
  (`6ea61`, `6ea9a`) and their addition. The recursive work remains inside every
  outer iteration, including iterations whose returned scalar is later
  replaced. The 1024 static calls in the Binaryen-expanded outer body are not
  asserted to be a dynamic call count.
- **fibfp**, input 35.0, final result 9227465.0: `f.2` at `570b0` has the same
  structure. Its body at `57160` stores/reloads the opaque F64 input at `57199`
  and `571bd`, then performs recursive arithmetic. Index increment `7cc4e`
  precedes the bound comparison `7ccb4` and backedge `7ccb8 -> 57160`.
  Recursive `f.4` at `7cf30` retains the two recursive calls (`7cfda`, `7d01d`)
  and floating addition. All ten computations remain, not only the final one.
- **mbrot**, input 75, final result 5: outer `f.2` at `57e70` reloads the hidden
  size (`57f38`/`57f5d`), allocates the matrix, and enters the row/column loops.
  Its outer increment `5859e` and bound/backedge `5861c`/`58620 -> 57f00` enclose
  that work. `f.4` (`58740`) and `f.5` (`58b60`) retain row/column traversal;
  `f.5` retains the complex recurrence, escape test and 64-iteration limit
  (`59013`, backedge `59017 -> 58fa0`). It stores each computed element at
  `59048`, repeats columns at `590f8 -> 58c00`, and returns to the next row at
  `5922a -> f.4`. Matrix construction has not collapsed to the selected result.
- **array1**, inputs 500 and 1000000, final result 1000000: `f.2` calls the
  captured `ref.4` worker. `f.4` (`58630`) retains both array allocations
  (`58841`, `58ba6`), initializes the source through `ref.8`/`f.8`, and copies
  through `ref.6`/`f.6` before its repetition decrement/backedge at
  `58f2a`/`58f2d`. `f.8` (`59320`) checks its upper bound and writes the index
  at `59410`, with an incrementing backedge. `f.6` (`590b0`) loads the source
  element at `59216`, stores it at `5921b`, then decrements the reverse index
  and repeats. Both million-element loops remain inside the 500 repetitions.
- **bv2string**, inputs 1000, 1000, 0, final result 1: outer `f.7` (`58ee0`)
  reloads both opaque inputs at `59030`/`5907b`; its `5b15f -> 58fc0` backedge
  repeats the entire test setup and work 100 times. It retains the initial
  small round trip and constructs the stress-loop closure `ref.10` at `5a369`,
  invoked at `5a6c0`. Stress `f.10` (`5bdc0`) increments at `5bef0`, compares
  the captured stress count at `5befd`, and returns to that loop after the
  round trip at `5c7f6` and related type-check exits. Random `f.16` (`5d970`)
  retains multiply/add/remainder and state stores (`5dacb` through `5dae8`);
  the setup retains 701, 743483 and 524287. Fill `f.13` (`5cd80`) invokes the
  generator with bound 128 at `5cef3`, stores each generated byte at `5cf4d`,
  and loops until the captured size. The string/bytevector conversions remain
  in `f.5`, `f.4` and their live callers. Round-trip comparison `f.11` (`5b5e0`)
  loads and compares bytes at `5b6e3`/`5b6e9`, loops at `5b6fb -> 5b6d0`, and
  retains failure reporting/list accumulation. The final failed-test-count
  comparison remains at `5b175`.
- **gcbench**, input depth 20, final result 1 plus full diagnostic output:
  live `f.5` calls the main work `f.8` at `59588`. `f.8` calls bottom-up tree
  construction at `59fcd` and top-down population at `5a366`, then invokes
  the reciprocal-array and depth-loop closures. `f.18` (`5aff0`) decrements
  depth at `5b097`, recursively constructs both children (`5b0ab`, `5b108`),
  allocates their parent (`5b389`) and stores both links (`5b39a`, `5b39e`).
  `f.17` (`5b420`) retains allocation/child writes, one recursive call
  (`5bd8d`) and the second-child tail loop (`5c04f -> 5b4b0`). Depth loop
  `f.10` increments by two at `5c2b0` and calls the construction pair `f.12`
  at `5c573`. `f.12` invokes both `ref.14` and `ref.13`; their workers compare
  the repetition index with the computed iteration count at `5d9a0` and
  `5d630`, call `f.17`/`f.18` at `5dd16`/`5d6f9`, and increment/repeat.
  Array worker `f.16` checks half the array length (`5e21c` through `5e230`)
  and retains reciprocal division and element stores (`5e2fd`, `5e301`).
  Stretch tree, long-lived tree/array, and both timed construction styles
  remain executable work; a constant final success value did not replace them.

These are concrete code-generation checks on the recorded Rust 1.95 / LLVM 22
toolchain and these six frozen executables. `black_box` is an optimization
boundary, not a portable mathematical guarantee that arbitrary discarded pure
work survives every compiler. No dynamic allocation/recursion counts or
performance percentages are inferred from static instruction counts. The
existing normal validation separately checks canonical inputs, complete
predicates, and hook counts; future compiler/provider changes need a fresh
final-binary check if they change this boundary.
