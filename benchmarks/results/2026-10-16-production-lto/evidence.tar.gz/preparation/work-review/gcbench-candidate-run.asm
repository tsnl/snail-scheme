000000000004bc60 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b>:
   4bc60:      	pushq	%rbp
   4bc61:      	pushq	%r15
   4bc63:      	pushq	%r14
   4bc65:      	pushq	%r13
   4bc67:      	pushq	%r12
   4bc69:      	pushq	%rbx
   4bc6a:      	subq	$0x3b8, %rsp            # imm = 0x3B8
   4bc71:      	cmpq	$0x0, 0x1824f(%rip)     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bc79:      	jne	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4bc7f:      	movl	$0x468, %edi            # imm = 0x468
   4bc84:      	callq	*0x16746(%rip)          # 0x623d0 <writev+0x623d0>
   4bc8a:      	testq	%rax, %rax
   4bc8d:      	je	0x4d43a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17da>
   4bc93:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bc9d:      	movq	%rax, 0x28(%rsp)
   4bca2:      	movq	%rax, %r13
   4bca5:      	addq	$0x10, %r13
   4bca9:      	leaq	0x16108(%rip), %rbp     # 0x61db8 <native_gc_layouts+0x8>
   4bcb0:      	xorl	%r14d, %r14d
   4bcb3:      	movabsq	$0x7fe74424004f, %rax   # imm = 0x7FE74424004F
   4bcbd:      	jmp	0x4bce6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x86>
   4bcbf:      	nop
   4bcc0:      	movq	%rcx, %r12
   4bcc3:      	jne	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4bcc9:      	movq	%r12, -0x10(%r13)
   4bccd:      	movq	%rbx, -0x8(%r13)
   4bcd1:      	movq	%r12, (%r13)
   4bcd5:      	incq	%r14
   4bcd8:      	addq	$0x18, %r13
   4bcdc:      	addq	$0x10, %rbp
   4bce0:      	cmpq	$0x2f, %r14
   4bce4:      	je	0x4bd54 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xf4>
   4bce6:      	cmpl	$0x2, -0x8(%rbp)
   4bcea:      	jae	0x4bcc0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x60>
   4bcec:      	btq	%r14, %rax
   4bcf0:      	jae	0x4bd00 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xa0>
   4bcf2:      	movl	$0x4, %ebx
   4bcf7:      	xorl	%r12d, %r12d
   4bcfa:      	jmp	0x4bcc9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x69>
   4bcfc:      	nopl	(%rax)
   4bd00:      	movl	-0x4(%rbp), %r12d
   4bd04:      	leaq	(,%r12,4), %r15
   4bd0c:      	movq	(%rbp), %rax
   4bd10:      	movq	%rax, 0x18(%rsp)
   4bd15:      	movq	%r15, %rdi
   4bd18:      	callq	*0x166b2(%rip)          # 0x623d0 <writev+0x623d0>
   4bd1e:      	testq	%rax, %rax
   4bd21:      	je	0x4d432 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17d2>
   4bd27:      	movq	%rax, %rbx
   4bd2a:      	movq	%rax, %rdi
   4bd2d:      	movq	0x18(%rsp), %rsi
   4bd32:      	movq	%r15, %rdx
   4bd35:      	callq	*0x1678d(%rip)          # 0x624c8 <writev+0x624c8>
   4bd3b:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bd45:      	movabsq	$0x7fe74424004f, %rax   # imm = 0x7FE74424004F
   4bd4f:      	jmp	0x4bcc9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x69>
   4bd54:      	movl	$0x70, %edi
   4bd59:      	callq	*0x16671(%rip)          # 0x623d0 <writev+0x623d0>
   4bd5f:      	testq	%rax, %rax
   4bd62:      	je	0x4d444 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17e4>
   4bd68:      	movq	%rax, %r15
   4bd6b:      	movaps	0x1638e(%rip), %xmm0    # 0x62100 <native_gc_globals+0x60>
   4bd72:      	movups	%xmm0, 0x60(%rax)
   4bd76:      	movaps	0x16373(%rip), %xmm0    # 0x620f0 <native_gc_globals+0x50>
   4bd7d:      	movups	%xmm0, 0x50(%rax)
   4bd81:      	movaps	0x16358(%rip), %xmm0    # 0x620e0 <native_gc_globals+0x40>
   4bd88:      	movups	%xmm0, 0x40(%rax)
   4bd8c:      	movaps	0x1633d(%rip), %xmm0    # 0x620d0 <native_gc_globals+0x30>
   4bd93:      	movups	%xmm0, 0x30(%rax)
   4bd97:      	movaps	0x16322(%rip), %xmm0    # 0x620c0 <native_gc_globals+0x20>
   4bd9e:      	movups	%xmm0, 0x20(%rax)
   4bda2:      	movaps	0x16307(%rip), %xmm0    # 0x620b0 <native_gc_globals+0x10>
   4bda9:      	movups	%xmm0, 0x10(%rax)
   4bdad:      	movapd	0x162eb(%rip), %xmm0    # 0x620a0 <native_gc_globals>
   4bdb5:      	movupd	%xmm0, (%rax)
   4bdb9:      	movl	$0x178, %edi            # imm = 0x178
   4bdbe:      	callq	*0x1660c(%rip)          # 0x623d0 <writev+0x623d0>
   4bdc4:      	testq	%rax, %rax
   4bdc7:      	je	0x4d44e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17ee>
   4bdcd:      	movq	%rax, %rbx
   4bdd0:      	movabsq	$0x3fffffffffff8000, %r13 # imm = 0x3FFFFFFFFFFF8000
   4bdda:      	leaq	-0x41101(%rip), %rsi    # 0xace0 <native_gc_parents>
   4bde1:      	movl	$0x178, %edx            # imm = 0x178
   4bde6:      	movq	%rax, %rdi
   4bde9:      	callq	*0x166d9(%rip)          # 0x624c8 <writev+0x624c8>
   4bdef:      	leaq	-0x42c13(%rip), %rsi    # 0x91e3 <core::num::flt2dec::strategy::dragon::POW5TO256+0x5b7>
   4bdf6:      	leaq	0x70(%rsp), %rdi
   4bdfb:      	movl	$0x13, %edx
   4be00:      	callq	0x55940 <std::env::_var_os>
   4be05:      	movq	0x70(%rsp), %rax
   4be0a:      	negq	%rax
   4be0d:      	movq	%rbx, 0x18(%rsp)
   4be12:      	jo	0x4be51 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1f1>
   4be14:      	jae	0x4be21 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1c1>
   4be16:      	movq	0x78(%rsp), %rdi
   4be1b:      	callq	*0x1650f(%rip)          # 0x62330 <writev+0x62330>
   4be21:      	leaq	-0x42c45(%rip), %rdi    # 0x91e3 <core::num::flt2dec::strategy::dragon::POW5TO256+0x5b7>
   4be28:      	movl	$0x13, %esi
   4be2d:      	xorl	%edx, %edx
   4be2f:      	callq	0x55b30 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4be34:      	movq	%rax, %rdx
   4be37:      	addq	$-0x8000, %rax          # imm = 0x8000
   4be3d:      	cmpq	%r13, %rax
   4be40:      	jae	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4be46:      	andq	%r13, %rdx
   4be49:      	movq	%rdx, %rbp
   4be4c:      	movq	%rdx, %r14
   4be4f:      	jmp	0x4be5c <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1fc>
   4be51:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4be56:      	xorl	%r14d, %r14d
   4be59:      	movq	%r13, %rbp
   4be5c:      	leaq	-0x42c6d(%rip), %rdi    # 0x91f6 <core::num::flt2dec::strategy::dragon::POW5TO256+0x5ca>
   4be63:      	movl	$0x16, %esi
   4be68:      	callq	0x55b30 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4be6d:      	movq	%rax, %r12
   4be70:      	addq	$-0x8000, %rax          # imm = 0x8000
   4be76:      	cmpq	%r13, %rax
   4be79:      	jae	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4be7f:      	andq	%r13, %r12
   4be82:      	cmpq	%rbp, %r12
   4be85:      	ja	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4be8b:      	leaq	-0x42c86(%rip), %rdi    # 0x920c <core::num::flt2dec::strategy::dragon::POW5TO256+0x5e0>
   4be92:      	movl	$0x12, %esi
   4be97:      	movl	$0x800000, %edx         # imm = 0x800000
   4be9c:      	callq	0x55b30 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4bea1:      	movq	%rax, %r13
   4bea4:      	leaq	-0x42c8d(%rip), %rsi    # 0x921e <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f2>
   4beab:      	leaq	0x70(%rsp), %rdi
   4beb0:      	movl	$0xe, %edx
   4beb5:      	callq	0x55940 <std::env::_var_os>
   4beba:      	movq	0x70(%rsp), %rax
   4bebf:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bec9:      	cmpq	%rcx, %rax
   4becc:      	setne	%bl
   4becf:      	testq	%rax, %rax
   4bed2:      	jle	0x4bedf <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x27f>
   4bed4:      	movq	0x78(%rsp), %rdi
   4bed9:      	callq	*0x16451(%rip)          # 0x62330 <writev+0x62330>
   4bedf:      	movq	$0x0, 0x70(%rsp)
   4bee8:      	movq	$0x8, 0x78(%rsp)
   4bef1:      	xorpd	%xmm0, %xmm0
   4bef5:      	movupd	%xmm0, 0x80(%rsp)
   4befe:      	movupd	%xmm0, 0x128(%rsp)
   4bf07:      	movupd	%xmm0, 0x138(%rsp)
   4bf10:      	movupd	%xmm0, 0x148(%rsp)
   4bf19:      	movq	%r12, 0x100(%rsp)
   4bf21:      	movq	%rbp, 0x108(%rsp)
   4bf29:      	movq	%r14, 0x110(%rsp)
   4bf31:      	movq	%r13, 0x118(%rsp)
   4bf39:      	movb	%bl, 0x120(%rsp)
   4bf40:      	movq	%r13, 0x158(%rsp)
   4bf48:      	movq	$0x8, 0x90(%rsp)
   4bf54:      	movupd	%xmm0, 0x98(%rsp)
   4bf5d:      	movq	$0x8, 0xa8(%rsp)
   4bf69:      	movq	$0x0, 0xb0(%rsp)
   4bf75:      	movq	$0x2f, 0xb8(%rsp)
   4bf81:      	movq	0x28(%rsp), %rax
   4bf86:      	movq	%rax, 0xc0(%rsp)
   4bf8e:      	movq	$0x2f, 0xc8(%rsp)
   4bf9a:      	movq	$0xe, 0xd0(%rsp)
   4bfa6:      	movq	%r15, 0xd8(%rsp)
   4bfae:      	movq	$0xe, 0xe0(%rsp)
   4bfba:      	movq	$0x0, 0xe8(%rsp)
   4bfc6:      	movq	$0x8, 0xf0(%rsp)
   4bfd2:      	movq	$0x0, 0xf8(%rsp)
   4bfde:      	movupd	%xmm0, 0x1b0(%rsp)
   4bfe7:      	movupd	%xmm0, 0x1a0(%rsp)
   4bff0:      	movupd	%xmm0, 0x190(%rsp)
   4bff9:      	movupd	%xmm0, 0x180(%rsp)
   4c002:      	movupd	%xmm0, 0x170(%rsp)
   4c00b:      	movupd	%xmm0, 0x160(%rsp)
   4c014:      	movq	$0x0, 0x1c0(%rsp)
   4c020:      	leaq	0x70(%rsp), %r15
   4c025:      	movq	%r15, %rdi
   4c028:      	movq	%r12, %rsi
   4c02b:      	callq	0x55d80 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4c030:      	movq	0x70(%rsp), %r13
   4c035:      	movq	0x78(%rsp), %rcx
   4c03a:      	movq	%rcx, 0x30(%rsp)
   4c03f:      	movq	0x80(%rsp), %r12
   4c047:      	movq	0x88(%rsp), %rcx
   4c04f:      	movq	%rcx, 0x58(%rsp)
   4c054:      	movq	0x90(%rsp), %rcx
   4c05c:      	movq	%rcx, 0x40(%rsp)
   4c061:      	movq	0xa0(%rsp), %rcx
   4c069:      	movq	%rcx, 0x60(%rsp)
   4c06e:      	movq	0xa8(%rsp), %rcx
   4c076:      	movq	%rcx, 0x48(%rsp)
   4c07b:      	movq	0xb8(%rsp), %rcx
   4c083:      	movq	%rcx, 0x68(%rsp)
   4c088:      	movq	0xc0(%rsp), %rcx
   4c090:      	movq	%rcx, 0x38(%rsp)
   4c095:      	movq	0xc8(%rsp), %r14
   4c09d:      	movq	0xd0(%rsp), %rcx
   4c0a5:      	movq	%rcx, 0x28(%rsp)
   4c0aa:      	movq	0xd8(%rsp), %rcx
   4c0b2:      	movq	%rcx, 0x50(%rsp)
   4c0b7:      	movq	0xe8(%rsp), %rbp
   4c0bf:      	movq	0xf0(%rsp), %rbx
   4c0c7:      	testb	%al, %al
   4c0c9:      	je	0x4d458 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17f8>
   4c0cf:      	leaq	0xf8(%rsp), %rsi
   4c0d7:      	movq	0xe0(%rsp), %rax
   4c0df:      	movq	%rax, 0x208(%rsp)
   4c0e7:      	movq	0x98(%rsp), %rax
   4c0ef:      	movq	%rax, 0x1f8(%rsp)
   4c0f7:      	movq	0xb0(%rsp), %rax
   4c0ff:      	movq	%rax, 0x200(%rsp)
   4c107:      	leaq	0x218(%rsp), %rdi
   4c10f:      	movl	$0xd0, %edx
   4c114:      	callq	*0x163ae(%rip)          # 0x624c8 <writev+0x624c8>
   4c11a:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4c124:      	cmpq	%rax, %r13
   4c127:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c12d:      	leaq	0x2e8(%rsp), %rdi
   4c135:      	leaq	0x218(%rsp), %rsi
   4c13d:      	movl	$0xd0, %edx
   4c142:      	callq	*0x16380(%rip)          # 0x624c8 <writev+0x624c8>
   4c148:      	movupd	-0x42d0d(%rip), %xmm0   # 0x9443 <core::num::flt2dec::strategy::dragon::POW5TO256+0x817>
   4c150:      	movapd	%xmm0, 0x70(%rsp)
   4c156:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4c160:      	movq	%rax, 0x80(%rsp)
   4c168:      	movb	$0x0, 0x88(%rsp)
   4c170:      	movb	$0x1, %al
   4c172:      	testb	%al, %al
   4c174:      	movq	%rbp, 0x1f0(%rsp)
   4c17c:      	je	0x4c18a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x52a>
   4c17e:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4c188:      	jmp	0x4c1a1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x541>
   4c18a:      	xorl	%eax, %eax
   4c18c:      	nopl	(%rax)
   4c190:      	cmpb	$0x0, 0x70(%rsp,%rax)
   4c195:      	je	0x4c203 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x5a3>
   4c197:      	incq	%rax
   4c19a:      	jne	0x4c190 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x530>
   4c19c:      	movq	0x70(%rsp), %rax
   4c1a1:      	movq	0x78(%rsp), %rcx
   4c1a6:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4c1b0:      	movq	%rdx, %rsi
   4c1b3:      	subq	%rax, %rsi
   4c1b6:      	orq	%rax, %rsi
   4c1b9:      	subq	%rcx, %rdx
   4c1bc:      	orq	%rcx, %rdx
   4c1bf:      	andq	%rsi, %rdx
   4c1c2:      	notq	%rdx
   4c1c5:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4c1cf:      	xorl	%ecx, %ecx
   4c1d1:      	testq	%rax, %rdx
   4c1d4:      	sete	%cl
   4c1d7:      	shll	$0x4, %ecx
   4c1da:      	leaq	(%rsp,%rcx), %rdx
   4c1de:      	addq	$0x70, %rdx
   4c1e2:      	movq	%rcx, %rsi
   4c1e5:      	xorq	$0x19, %rsi
   4c1e9:      	xorl	%eax, %eax
   4c1eb:      	nopl	(%rax,%rax)
   4c1f0:      	cmpb	$0x0, (%rdx,%rax)
   4c1f4:      	je	0x4c200 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x5a0>
   4c1f6:      	incq	%rax
   4c1f9:      	cmpq	%rax, %rsi
   4c1fc:      	jne	0x4c1f0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x590>
   4c1fe:      	jmp	0x4c24e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x5ee>
   4c200:      	addq	%rcx, %rax
   4c203:      	cmpq	$0x18, %rax
   4c207:      	jne	0x4c24e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x5ee>
   4c209:      	movq	%r13, 0x8(%rsp)
   4c20e:      	leaq	0x218(%rsp), %rdi
   4c216:      	leaq	0x70(%rsp), %rsi
   4c21b:      	callq	0x46e90 <std::sys::env::unix::getenv::{closure#0}>
   4c220:      	movq	0x218(%rsp), %rdx
   4c228:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4c232:      	leaq	0x1(%rcx), %rax
   4c236:      	cmpq	%rax, %rdx
   4c239:      	jne	0x4d295 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1635>
   4c23f:      	movq	0x220(%rsp), %rax
   4c247:      	movq	0x8(%rsp), %r13
   4c24c:      	jmp	0x4c26a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x60a>
   4c24e:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4c258:      	incq	%rax
   4c25b:      	movq	%rax, 0x218(%rsp)
   4c263:      	leaq	0x14f86(%rip), %rax     # 0x611f0 <writev+0x611f0>
   4c26a:      	movl	%eax, %ecx
   4c26c:      	andl	$0x3, %ecx
   4c26f:      	leal	-0x2(%rcx), %edx
   4c272:      	cmpl	$0x2, %edx
   4c275:      	jb	0x4c2c5 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x665>
   4c277:      	testq	%rcx, %rcx
   4c27a:      	je	0x4c2c5 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x665>
   4c27c:      	movq	%r13, 0x8(%rsp)
   4c281:      	movq	%rbx, %r13
   4c284:      	leaq	-0x1(%rax), %rcx
   4c288:      	movq	%rcx, 0x10(%rsp)
   4c28d:      	movq	-0x1(%rax), %rbp
   4c291:      	movq	0x7(%rax), %rbx
   4c295:      	movq	(%rbx), %rax
   4c298:      	testq	%rax, %rax
   4c29b:      	je	0x4c2a2 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x642>
   4c29d:      	movq	%rbp, %rdi
   4c2a0:      	callq	*%rax
   4c2a2:      	cmpq	$0x0, 0x8(%rbx)
   4c2a7:      	je	0x4c2b2 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x652>
   4c2a9:      	movq	%rbp, %rdi
   4c2ac:      	callq	*0x1607e(%rip)          # 0x62330 <writev+0x62330>
   4c2b2:      	movq	0x10(%rsp), %rdi
   4c2b7:      	callq	*0x16073(%rip)          # 0x62330 <writev+0x62330>
   4c2bd:      	movq	%r13, %rbx
   4c2c0:      	movq	0x8(%rsp), %r13
   4c2c5:      	xorl	%ebp, %ebp
   4c2c7:      	movl	$0x180, %edi            # imm = 0x180
   4c2cc:      	callq	*0x160fe(%rip)          # 0x623d0 <writev+0x623d0>
   4c2d2:      	testq	%rax, %rax
   4c2d5:      	je	0x4d417 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17b7>
   4c2db:      	movq	%r13, %rcx
   4c2de:      	movq	%rax, %r13
   4c2e1:      	movq	%rcx, (%rax)
   4c2e4:      	movq	0x30(%rsp), %rcx
   4c2e9:      	movq	%rcx, 0x8(%rax)
   4c2ed:      	movq	%r12, 0x10(%rax)
   4c2f1:      	movq	0x58(%rsp), %rcx
   4c2f6:      	movq	%rcx, 0x18(%rax)
   4c2fa:      	movq	0x40(%rsp), %rcx
   4c2ff:      	movq	%rcx, 0x20(%rax)
   4c303:      	movq	0x1f8(%rsp), %rcx
   4c30b:      	movq	%rcx, 0x28(%rax)
   4c30f:      	movq	0x60(%rsp), %rcx
   4c314:      	movq	%rcx, 0x30(%rax)
   4c318:      	movq	0x48(%rsp), %rcx
   4c31d:      	movq	%rcx, 0x38(%rax)
   4c321:      	movq	0x200(%rsp), %rcx
   4c329:      	movq	%rcx, 0x40(%rax)
   4c32d:      	movq	0x68(%rsp), %rcx
   4c332:      	movq	%rcx, 0x48(%rax)
   4c336:      	movq	0x38(%rsp), %rcx
   4c33b:      	movq	%rcx, 0x50(%rax)
   4c33f:      	movq	%r14, 0x58(%rax)
   4c343:      	movq	0x28(%rsp), %rcx
   4c348:      	movq	%rcx, 0x60(%rax)
   4c34c:      	movq	0x50(%rsp), %rcx
   4c351:      	movq	%rcx, 0x68(%rax)
   4c355:      	movq	0x208(%rsp), %rcx
   4c35d:      	movq	%rcx, 0x70(%rax)
   4c361:      	movq	0x1f0(%rsp), %rcx
   4c369:      	movq	%rcx, 0x78(%rax)
   4c36d:      	movq	%rbx, 0x80(%rax)
   4c374:      	addq	$0x88, %rax
   4c37a:      	leaq	0x2e8(%rsp), %rsi
   4c382:      	movl	$0xd0, %edx
   4c387:      	movq	%rax, %rdi
   4c38a:      	callq	*0x16138(%rip)          # 0x624c8 <writev+0x624c8>
   4c390:      	movq	$0x2f, 0x158(%r13)
   4c39b:      	movq	0x18(%rsp), %rax
   4c3a0:      	movq	%rax, 0x160(%r13)
   4c3a7:      	movq	$0x2f, 0x168(%r13)
   4c3b2:      	movq	$0x0, 0x170(%r13)
   4c3bd:      	movq	%rbp, 0x178(%r13)
   4c3c4:      	movq	%r13, 0x17afd(%rip)     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c3cb:      	leaq	0x9b9e(%rip), %rdi      # 0x55f70 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4c3d2:      	callq	0x12d00 <atexit>
   4c3d7:      	movq	$0x2, 0x78(%rsp)
   4c3e0:      	movq	$0x0, 0x80(%rsp)
   4c3ec:      	movq	0x17add(%rip), %rax     # 0x63ed0 <native_roots.0>
   4c3f3:      	movq	%rax, 0x70(%rsp)
   4c3f8:      	movq	0x17ab1(%rip), %rax     # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c3ff:      	incq	%rax
   4c402:      	movq	%rax, 0x17aa7(%rip)     # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c409:      	movq	0x17aa8(%rip), %rcx     # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4c410:      	cmpq	%rcx, %rax
   4c413:      	cmovbeq	%rcx, %rax
   4c417:      	movq	%r15, 0x17ab2(%rip)     # 0x63ed0 <native_roots.0>
   4c41e:      	movq	%rax, 0x17a93(%rip)     # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4c425:      	cmpl	$0x0, 0x17b70(%rip)     # 0x63f9c <g.0>
   4c42c:      	jne	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c432:      	movl	$0x1, 0x17b60(%rip)     # 0x63f9c <g.0>
   4c43c:      	movq	$0x0, 0x80(%rsp)
   4c448:      	movq	0x17a79(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c44f:      	testq	%rdi, %rdi
   4c452:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c458:      	movq	0x178(%rdi), %rcx
   4c45f:      	testq	%rcx, %rcx
   4c462:      	je	0x4c4a6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x846>
   4c464:      	movq	0x170(%rdi), %rax
   4c46b:      	incq	%rax
   4c46e:      	movq	%rax, 0x170(%rdi)
   4c475:      	movq	%rax, %rdx
   4c478:      	orq	%rcx, %rdx
   4c47b:      	shrq	$0x20, %rdx
   4c47f:      	je	0x4d163 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1503>
   4c485:      	xorl	%edx, %edx
   4c487:      	divq	%rcx
   4c48a:      	testq	%rdx, %rdx
   4c48d:      	jne	0x4c4a6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x846>
   4c48f:      	leaq	0x70(%rsp), %rsi
   4c494:      	movq	%rdi, %rbx
   4c497:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c49c:      	movq	%rbx, %rdi
   4c49f:      	movq	0x17a2a(%rip), %r15     # 0x63ed0 <native_roots.0>
   4c4a6:      	movl	$0x8, %esi
   4c4ab:      	movq	%r15, %rdx
   4c4ae:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c4b3:      	testq	%rax, %rax
   4c4b6:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c4bc:      	movq	$0xa6, (%rax)
   4c4c3:      	movq	%rax, 0x17ad6(%rip)     # 0x63fa0 <g.2>
   4c4ca:      	movb	$0x1, 0x17ad7(%rip)     # 0x63fa8 <g.3>
   4c4d1:      	movq	$0x0, 0x80(%rsp)
   4c4dd:      	movq	0x179e4(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c4e4:      	testq	%rdi, %rdi
   4c4e7:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c4ed:      	movq	0x178(%rdi), %rcx
   4c4f4:      	testq	%rcx, %rcx
   4c4f7:      	je	0x4c536 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x8d6>
   4c4f9:      	movq	0x170(%rdi), %rax
   4c500:      	incq	%rax
   4c503:      	movq	%rax, 0x170(%rdi)
   4c50a:      	movq	%rax, %rdx
   4c50d:      	orq	%rcx, %rdx
   4c510:      	shrq	$0x20, %rdx
   4c514:      	je	0x4d175 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1515>
   4c51a:      	xorl	%edx, %edx
   4c51c:      	divq	%rcx
   4c51f:      	testq	%rdx, %rdx
   4c522:      	jne	0x4c536 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x8d6>
   4c524:      	movq	0x179a5(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c52b:      	movq	%rdi, %rbx
   4c52e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c533:      	movq	%rbx, %rdi
   4c536:      	movq	0x17993(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c53d:      	movl	$0x8, %esi
   4c542:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c547:      	testq	%rax, %rax
   4c54a:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c550:      	movq	$0xa2, (%rax)
   4c557:      	movq	%rax, 0x17a52(%rip)     # 0x63fb0 <g.4>
   4c55e:      	movb	$0x1, 0x17a53(%rip)     # 0x63fb8 <g.5>
   4c565:      	movq	$0x0, 0x80(%rsp)
   4c571:      	movq	0x17950(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c578:      	testq	%rdi, %rdi
   4c57b:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c581:      	movq	0x178(%rdi), %rcx
   4c588:      	testq	%rcx, %rcx
   4c58b:      	je	0x4c5ca <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x96a>
   4c58d:      	movq	0x170(%rdi), %rax
   4c594:      	incq	%rax
   4c597:      	movq	%rax, 0x170(%rdi)
   4c59e:      	movq	%rax, %rdx
   4c5a1:      	orq	%rcx, %rdx
   4c5a4:      	shrq	$0x20, %rdx
   4c5a8:      	je	0x4d187 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1527>
   4c5ae:      	xorl	%edx, %edx
   4c5b0:      	divq	%rcx
   4c5b3:      	testq	%rdx, %rdx
   4c5b6:      	jne	0x4c5ca <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x96a>
   4c5b8:      	movq	0x17911(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c5bf:      	movq	%rdi, %rbx
   4c5c2:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c5c7:      	movq	%rbx, %rdi
   4c5ca:      	movq	0x178ff(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c5d1:      	movl	$0x8, %esi
   4c5d6:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c5db:      	testq	%rax, %rax
   4c5de:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c5e4:      	movq	$0x9e, (%rax)
   4c5eb:      	movq	%rax, 0x179ce(%rip)     # 0x63fc0 <g.6>
   4c5f2:      	movb	$0x1, 0x179cf(%rip)     # 0x63fc8 <g.7>
   4c5f9:      	movq	$0x0, 0x80(%rsp)
   4c605:      	movq	0x178bc(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c60c:      	testq	%rdi, %rdi
   4c60f:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c615:      	movq	0x178(%rdi), %rcx
   4c61c:      	testq	%rcx, %rcx
   4c61f:      	je	0x4c65e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x9fe>
   4c621:      	movq	0x170(%rdi), %rax
   4c628:      	incq	%rax
   4c62b:      	movq	%rax, 0x170(%rdi)
   4c632:      	movq	%rax, %rdx
   4c635:      	orq	%rcx, %rdx
   4c638:      	shrq	$0x20, %rdx
   4c63c:      	je	0x4d199 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1539>
   4c642:      	xorl	%edx, %edx
   4c644:      	divq	%rcx
   4c647:      	testq	%rdx, %rdx
   4c64a:      	jne	0x4c65e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x9fe>
   4c64c:      	movq	0x1787d(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c653:      	movq	%rdi, %rbx
   4c656:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c65b:      	movq	%rbx, %rdi
   4c65e:      	movq	0x1786b(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c665:      	movl	$0x8, %esi
   4c66a:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c66f:      	testq	%rax, %rax
   4c672:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c678:      	movq	$0x9e, (%rax)
   4c67f:      	movq	%rax, 0x1794a(%rip)     # 0x63fd0 <g.8>
   4c686:      	movb	$0x1, 0x1794b(%rip)     # 0x63fd8 <g.9>
   4c68d:      	movq	$0x0, 0x80(%rsp)
   4c699:      	movq	0x17828(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c6a0:      	testq	%rdi, %rdi
   4c6a3:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c6a9:      	movq	0x178(%rdi), %rcx
   4c6b0:      	testq	%rcx, %rcx
   4c6b3:      	je	0x4c6f2 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xa92>
   4c6b5:      	movq	0x170(%rdi), %rax
   4c6bc:      	incq	%rax
   4c6bf:      	movq	%rax, 0x170(%rdi)
   4c6c6:      	movq	%rax, %rdx
   4c6c9:      	orq	%rcx, %rdx
   4c6cc:      	shrq	$0x20, %rdx
   4c6d0:      	je	0x4d1ab <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x154b>
   4c6d6:      	xorl	%edx, %edx
   4c6d8:      	divq	%rcx
   4c6db:      	testq	%rdx, %rdx
   4c6de:      	jne	0x4c6f2 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xa92>
   4c6e0:      	movq	0x177e9(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c6e7:      	movq	%rdi, %rbx
   4c6ea:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c6ef:      	movq	%rbx, %rdi
   4c6f2:      	movq	0x177d7(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c6f9:      	movl	$0x8, %esi
   4c6fe:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c703:      	testq	%rax, %rax
   4c706:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c70c:      	movq	$0x9a, (%rax)
   4c713:      	movq	%rax, 0x178c6(%rip)     # 0x63fe0 <g.10>
   4c71a:      	movb	$0x1, 0x178c7(%rip)     # 0x63fe8 <g.11>
   4c721:      	movq	$0x0, 0x80(%rsp)
   4c72d:      	movq	0x17794(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c734:      	testq	%rdi, %rdi
   4c737:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c73d:      	movq	0x178(%rdi), %rcx
   4c744:      	testq	%rcx, %rcx
   4c747:      	je	0x4c786 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xb26>
   4c749:      	movq	0x170(%rdi), %rax
   4c750:      	incq	%rax
   4c753:      	movq	%rax, 0x170(%rdi)
   4c75a:      	movq	%rax, %rdx
   4c75d:      	orq	%rcx, %rdx
   4c760:      	shrq	$0x20, %rdx
   4c764:      	je	0x4d1bd <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x155d>
   4c76a:      	xorl	%edx, %edx
   4c76c:      	divq	%rcx
   4c76f:      	testq	%rdx, %rdx
   4c772:      	jne	0x4c786 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xb26>
   4c774:      	movq	0x17755(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c77b:      	movq	%rdi, %rbx
   4c77e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c783:      	movq	%rbx, %rdi
   4c786:      	movq	0x17743(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c78d:      	movl	$0x8, %esi
   4c792:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c797:      	testq	%rax, %rax
   4c79a:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c7a0:      	movq	$0x9a, (%rax)
   4c7a7:      	movq	%rax, 0x17842(%rip)     # 0x63ff0 <g.12>
   4c7ae:      	movb	$0x1, 0x17843(%rip)     # 0x63ff8 <g.13>
   4c7b5:      	movq	$0x0, 0x80(%rsp)
   4c7c1:      	movq	0x17700(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c7c8:      	testq	%rdi, %rdi
   4c7cb:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c7d1:      	movq	0x178(%rdi), %rcx
   4c7d8:      	testq	%rcx, %rcx
   4c7db:      	je	0x4c81a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xbba>
   4c7dd:      	movq	0x170(%rdi), %rax
   4c7e4:      	incq	%rax
   4c7e7:      	movq	%rax, 0x170(%rdi)
   4c7ee:      	movq	%rax, %rdx
   4c7f1:      	orq	%rcx, %rdx
   4c7f4:      	shrq	$0x20, %rdx
   4c7f8:      	je	0x4d1cf <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x156f>
   4c7fe:      	xorl	%edx, %edx
   4c800:      	divq	%rcx
   4c803:      	testq	%rdx, %rdx
   4c806:      	jne	0x4c81a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xbba>
   4c808:      	movq	0x176c1(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c80f:      	movq	%rdi, %rbx
   4c812:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c817:      	movq	%rbx, %rdi
   4c81a:      	movq	0x176af(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c821:      	movl	$0x10, %esi
   4c826:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c82b:      	testq	%rax, %rax
   4c82e:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c834:      	movq	$0x96, (%rax)
   4c83b:      	movq	$0x0, 0x8(%rax)
   4c843:      	movq	%rax, 0x177b6(%rip)     # 0x64000 <g.14>
   4c84a:      	movb	$0x1, 0x177b7(%rip)     # 0x64008 <g.15>
   4c851:      	movq	$0x0, 0x88(%rsp)
   4c85d:      	leaq	0x154d4(%rip), %r14     # 0x61d38 <ref.9>
   4c864:      	movq	%r14, 0x90(%rsp)
   4c86c:      	movq	$0x2, 0x80(%rsp)
   4c878:      	movq	0x17649(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c87f:      	testq	%rdi, %rdi
   4c882:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c888:      	movq	0x178(%rdi), %rcx
   4c88f:      	testq	%rcx, %rcx
   4c892:      	je	0x4c8d1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xc71>
   4c894:      	movq	0x170(%rdi), %rax
   4c89b:      	incq	%rax
   4c89e:      	movq	%rax, 0x170(%rdi)
   4c8a5:      	movq	%rax, %rdx
   4c8a8:      	orq	%rcx, %rdx
   4c8ab:      	shrq	$0x20, %rdx
   4c8af:      	je	0x4d1e1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1581>
   4c8b5:      	xorl	%edx, %edx
   4c8b7:      	divq	%rcx
   4c8ba:      	testq	%rdx, %rdx
   4c8bd:      	jne	0x4c8d1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xc71>
   4c8bf:      	movq	0x1760a(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c8c6:      	movq	%rdi, %rbx
   4c8c9:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c8ce:      	movq	%rbx, %rdi
   4c8d1:      	movq	0x175f8(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c8d8:      	movl	$0x18, %esi
   4c8dd:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c8e2:      	testq	%rax, %rax
   4c8e5:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c8eb:      	movq	$0x92, (%rax)
   4c8f2:      	movq	%r14, 0x8(%rax)
   4c8f6:      	movq	$0x0, 0x10(%rax)
   4c8fe:      	movq	%rax, 0x1770b(%rip)     # 0x64010 <g.16>
   4c905:      	movb	$0x1, 0x1770c(%rip)     # 0x64018 <g.17>
   4c90c:      	movq	$0x0, 0x80(%rsp)
   4c918:      	movq	0x175a9(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c91f:      	testq	%rdi, %rdi
   4c922:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c928:      	movq	0x178(%rdi), %rcx
   4c92f:      	testq	%rcx, %rcx
   4c932:      	je	0x4c971 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xd11>
   4c934:      	movq	0x170(%rdi), %rax
   4c93b:      	incq	%rax
   4c93e:      	movq	%rax, 0x170(%rdi)
   4c945:      	movq	%rax, %rdx
   4c948:      	orq	%rcx, %rdx
   4c94b:      	shrq	$0x20, %rdx
   4c94f:      	je	0x4d1f3 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1593>
   4c955:      	xorl	%edx, %edx
   4c957:      	divq	%rcx
   4c95a:      	testq	%rdx, %rdx
   4c95d:      	jne	0x4c971 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xd11>
   4c95f:      	movq	0x1756a(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4c966:      	movq	%rdi, %rbx
   4c969:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4c96e:      	movq	%rbx, %rdi
   4c971:      	movq	0x17558(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4c978:      	movl	$0x8, %esi
   4c97d:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4c982:      	testq	%rax, %rax
   4c985:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4c98b:      	movq	$0x8e, (%rax)
   4c992:      	movq	%rax, 0x17687(%rip)     # 0x64020 <g.18>
   4c999:      	movb	$0x1, 0x17688(%rip)     # 0x64028 <g.19>
   4c9a0:      	movq	$0x0, 0x88(%rsp)
   4c9ac:      	leaq	0x15365(%rip), %r14     # 0x61d18 <ref.6>
   4c9b3:      	movq	%r14, 0x90(%rsp)
   4c9bb:      	movq	$0x2, 0x80(%rsp)
   4c9c7:      	movq	0x174fa(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4c9ce:      	testq	%rdi, %rdi
   4c9d1:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4c9d7:      	movq	0x178(%rdi), %rcx
   4c9de:      	testq	%rcx, %rcx
   4c9e1:      	je	0x4ca20 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xdc0>
   4c9e3:      	movq	0x170(%rdi), %rax
   4c9ea:      	incq	%rax
   4c9ed:      	movq	%rax, 0x170(%rdi)
   4c9f4:      	movq	%rax, %rdx
   4c9f7:      	orq	%rcx, %rdx
   4c9fa:      	shrq	$0x20, %rdx
   4c9fe:      	je	0x4d205 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15a5>
   4ca04:      	xorl	%edx, %edx
   4ca06:      	divq	%rcx
   4ca09:      	testq	%rdx, %rdx
   4ca0c:      	jne	0x4ca20 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xdc0>
   4ca0e:      	movq	0x174bb(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4ca15:      	movq	%rdi, %rbx
   4ca18:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ca1d:      	movq	%rbx, %rdi
   4ca20:      	movq	0x174a9(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4ca27:      	movl	$0x18, %esi
   4ca2c:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ca31:      	testq	%rax, %rax
   4ca34:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4ca3a:      	movq	$0x92, (%rax)
   4ca41:      	movq	%r14, 0x8(%rax)
   4ca45:      	movq	$0x0, 0x10(%rax)
   4ca4d:      	movq	%rax, 0x175dc(%rip)     # 0x64030 <g.20>
   4ca54:      	movb	$0x1, 0x175dd(%rip)     # 0x64038 <g.21>
   4ca5b:      	movq	$0x0, 0x80(%rsp)
   4ca67:      	movq	0x1745a(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ca6e:      	testq	%rdi, %rdi
   4ca71:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4ca77:      	movq	0x178(%rdi), %rcx
   4ca7e:      	testq	%rcx, %rcx
   4ca81:      	je	0x4cac0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xe60>
   4ca83:      	movq	0x170(%rdi), %rax
   4ca8a:      	incq	%rax
   4ca8d:      	movq	%rax, 0x170(%rdi)
   4ca94:      	movq	%rax, %rdx
   4ca97:      	orq	%rcx, %rdx
   4ca9a:      	shrq	$0x20, %rdx
   4ca9e:      	je	0x4d217 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15b7>
   4caa4:      	xorl	%edx, %edx
   4caa6:      	divq	%rcx
   4caa9:      	testq	%rdx, %rdx
   4caac:      	jne	0x4cac0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xe60>
   4caae:      	movq	0x1741b(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4cab5:      	movq	%rdi, %rbx
   4cab8:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cabd:      	movq	%rbx, %rdi
   4cac0:      	movq	0x17409(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cac7:      	movl	$0x8, %esi
   4cacc:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cad1:      	testq	%rax, %rax
   4cad4:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4cada:      	movq	$0x8a, (%rax)
   4cae1:      	movq	%rax, 0x17558(%rip)     # 0x64040 <g.22>
   4cae8:      	movb	$0x1, 0x17559(%rip)     # 0x64048 <g.23>
   4caef:      	movq	$0x0, 0x80(%rsp)
   4cafb:      	movq	0x173c6(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cb02:      	testq	%rdi, %rdi
   4cb05:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cb0b:      	movq	0x178(%rdi), %rcx
   4cb12:      	testq	%rcx, %rcx
   4cb15:      	je	0x4cb54 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xef4>
   4cb17:      	movq	0x170(%rdi), %rax
   4cb1e:      	incq	%rax
   4cb21:      	movq	%rax, 0x170(%rdi)
   4cb28:      	movq	%rax, %rdx
   4cb2b:      	orq	%rcx, %rdx
   4cb2e:      	shrq	$0x20, %rdx
   4cb32:      	je	0x4d229 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15c9>
   4cb38:      	xorl	%edx, %edx
   4cb3a:      	divq	%rcx
   4cb3d:      	testq	%rdx, %rdx
   4cb40:      	jne	0x4cb54 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xef4>
   4cb42:      	movq	0x17387(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4cb49:      	movq	%rdi, %rbx
   4cb4c:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cb51:      	movq	%rbx, %rdi
   4cb54:      	movq	0x17375(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cb5b:      	movl	$0x8, %esi
   4cb60:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cb65:      	testq	%rax, %rax
   4cb68:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4cb6e:      	movq	$0x86, (%rax)
   4cb75:      	movq	%rax, 0x174d4(%rip)     # 0x64050 <g.24>
   4cb7c:      	movb	$0x1, 0x174d5(%rip)     # 0x64058 <g.25>
   4cb83:      	movq	$0x0, 0x88(%rsp)
   4cb8f:      	leaq	0x15192(%rip), %r14     # 0x61d28 <ref.7>
   4cb96:      	movq	%r14, 0x90(%rsp)
   4cb9e:      	movq	$0x2, 0x80(%rsp)
   4cbaa:      	movq	0x17317(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cbb1:      	testq	%rdi, %rdi
   4cbb4:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cbba:      	movq	0x178(%rdi), %rcx
   4cbc1:      	testq	%rcx, %rcx
   4cbc4:      	je	0x4cc03 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xfa3>
   4cbc6:      	movq	0x170(%rdi), %rax
   4cbcd:      	incq	%rax
   4cbd0:      	movq	%rax, 0x170(%rdi)
   4cbd7:      	movq	%rax, %rdx
   4cbda:      	orq	%rcx, %rdx
   4cbdd:      	shrq	$0x20, %rdx
   4cbe1:      	je	0x4d23b <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15db>
   4cbe7:      	xorl	%edx, %edx
   4cbe9:      	divq	%rcx
   4cbec:      	testq	%rdx, %rdx
   4cbef:      	jne	0x4cc03 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xfa3>
   4cbf1:      	movq	0x172d8(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4cbf8:      	movq	%rdi, %rbx
   4cbfb:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cc00:      	movq	%rbx, %rdi
   4cc03:      	movq	0x172c6(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cc0a:      	movl	$0x18, %esi
   4cc0f:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cc14:      	testq	%rax, %rax
   4cc17:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4cc1d:      	movq	$0x82, (%rax)
   4cc24:      	movq	%r14, 0x8(%rax)
   4cc28:      	movq	$0x0, 0x10(%rax)
   4cc30:      	movq	%rax, 0x17429(%rip)     # 0x64060 <g.26>
   4cc37:      	movb	$0x1, 0x1742a(%rip)     # 0x64068 <g.27>
   4cc3e:      	movq	$0x0, 0x80(%rsp)
   4cc4a:      	movq	$0x14, 0x218(%rsp)
   4cc56:      	leaq	0x218(%rsp), %rax
   4cc5e:      	movq	0x218(%rsp), %rax
   4cc66:      	movq	%rax, 0x17403(%rip)     # 0x64070 <g.28>
   4cc6d:      	movb	$0x1, 0x17404(%rip)     # 0x64078 <g.29>
   4cc74:      	movq	$0x0, 0x80(%rsp)
   4cc80:      	movq	0x17241(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cc87:      	testq	%rdi, %rdi
   4cc8a:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cc90:      	movq	0x178(%rdi), %rcx
   4cc97:      	testq	%rcx, %rcx
   4cc9a:      	je	0x4ccd9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1079>
   4cc9c:      	movq	0x170(%rdi), %rax
   4cca3:      	incq	%rax
   4cca6:      	movq	%rax, 0x170(%rdi)
   4ccad:      	movq	%rax, %rdx
   4ccb0:      	orq	%rcx, %rdx
   4ccb3:      	shrq	$0x20, %rdx
   4ccb7:      	je	0x4d24d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15ed>
   4ccbd:      	xorl	%edx, %edx
   4ccbf:      	divq	%rcx
   4ccc2:      	testq	%rdx, %rdx
   4ccc5:      	jne	0x4ccd9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1079>
   4ccc7:      	movq	0x17202(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4ccce:      	movq	%rdi, %rbx
   4ccd1:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ccd6:      	movq	%rbx, %rdi
   4ccd9:      	movq	0x171f0(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cce0:      	movl	$0x10, %esi
   4cce5:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ccea:      	testq	%rax, %rax
   4cced:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4ccf3:      	movq	$0x96, (%rax)
   4ccfa:      	movq	$0x0, 0x8(%rax)
   4cd02:      	movq	%rax, 0x17377(%rip)     # 0x64080 <g.30>
   4cd09:      	movl	$0x2, 0x17289(%rip)     # 0x63f9c <g.0>
   4cd13:      	cmpq	$0x0, 0x78(%rsp)
   4cd19:      	je	0x4cd2e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x10ce>
   4cd1b:      	movq	0x70(%rsp), %rax
   4cd20:      	movq	%rax, 0x171a9(%rip)     # 0x63ed0 <native_roots.0>
   4cd27:      	decq	0x17182(%rip)           # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cd2e:      	callq	0x4d690 <<std::sys::pal::unix::time::Timespec>::now>
   4cd33:      	movq	%rax, %rbx
   4cd36:      	movl	%edx, %ebp
   4cd38:      	movq	$0x5, 0x78(%rsp)
   4cd41:      	movq	$0x0, 0x80(%rsp)
   4cd4d:      	movq	0x1717c(%rip), %rax     # 0x63ed0 <native_roots.0>
   4cd54:      	movq	%rax, 0x70(%rsp)
   4cd59:      	leaq	0x70(%rsp), %rcx
   4cd5e:      	movq	%rcx, 0x1716b(%rip)     # 0x63ed0 <native_roots.0>
   4cd65:      	movq	0x17144(%rip), %rax     # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cd6c:      	incq	%rax
   4cd6f:      	movq	%rax, 0x1713a(%rip)     # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4cd76:      	movq	0x1713b(%rip), %rdx     # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4cd7d:      	cmpq	%rdx, %rax
   4cd80:      	cmovbeq	%rdx, %rax
   4cd84:      	movq	%rax, 0x1712d(%rip)     # 0x63eb8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4cd8b:      	xorpd	%xmm0, %xmm0
   4cd8f:      	movupd	%xmm0, 0x88(%rsp)
   4cd98:      	cmpl	$0x2, 0x171fd(%rip)     # 0x63f9c <g.0>
   4cd9f:      	jne	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cda5:      	cmpq	$0x0, 0x172d3(%rip)     # 0x64080 <g.30>
   4cdad:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cdb3:      	movq	$0x2, 0x80(%rsp)
   4cdbf:      	movq	0x17102(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cdc6:      	testq	%rdi, %rdi
   4cdc9:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cdcf:      	movq	0x178(%rdi), %rsi
   4cdd6:      	testq	%rsi, %rsi
   4cdd9:      	je	0x4ce1d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x11bd>
   4cddb:      	movq	0x170(%rdi), %rax
   4cde2:      	incq	%rax
   4cde5:      	movq	%rax, 0x170(%rdi)
   4cdec:      	movq	%rax, %rdx
   4cdef:      	orq	%rsi, %rdx
   4cdf2:      	shrq	$0x20, %rdx
   4cdf6:      	je	0x4d25f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x15ff>
   4cdfc:      	xorl	%edx, %edx
   4cdfe:      	divq	%rsi
   4ce01:      	testq	%rdx, %rdx
   4ce04:      	jne	0x4ce1d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x11bd>
   4ce06:      	leaq	0x70(%rsp), %rsi
   4ce0b:      	movq	%rdi, %r14
   4ce0e:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ce13:      	movq	%r14, %rdi
   4ce16:      	movq	0x170b3(%rip), %rcx     # 0x63ed0 <native_roots.0>
   4ce1d:      	movl	$0x18, %esi
   4ce22:      	movq	%rcx, %rdx
   4ce25:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ce2a:      	testq	%rax, %rax
   4ce2d:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4ce33:      	movq	%rax, %r14
   4ce36:      	movq	$0x5e, (%rax)
   4ce3d:      	movl	$0x0, 0x8(%rax)
   4ce44:      	movq	$0x0, 0x10(%rax)
   4ce4c:      	movq	%rax, 0x88(%rsp)
   4ce54:      	movq	%rax, 0x98(%rsp)
   4ce5c:      	leaq	0x14ea5(%rip), %r13     # 0x61d08 <ref.5>
   4ce63:      	movq	%r13, 0xa0(%rsp)
   4ce6b:      	movq	%rax, 0xa8(%rsp)
   4ce73:      	movq	$0x5, 0x80(%rsp)
   4ce7f:      	movq	0x17042(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ce86:      	testq	%rdi, %rdi
   4ce89:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4ce8f:      	movq	0x178(%rdi), %rcx
   4ce96:      	testq	%rcx, %rcx
   4ce99:      	je	0x4ced8 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1278>
   4ce9b:      	movq	0x170(%rdi), %rax
   4cea2:      	incq	%rax
   4cea5:      	movq	%rax, 0x170(%rdi)
   4ceac:      	movq	%rax, %rdx
   4ceaf:      	orq	%rcx, %rdx
   4ceb2:      	shrq	$0x20, %rdx
   4ceb6:      	je	0x4d271 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1611>
   4cebc:      	xorl	%edx, %edx
   4cebe:      	divq	%rcx
   4cec1:      	testq	%rdx, %rdx
   4cec4:      	jne	0x4ced8 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1278>
   4cec6:      	movq	0x17003(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4cecd:      	movq	%rdi, %r15
   4ced0:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ced5:      	movq	%r15, %rdi
   4ced8:      	movq	0x16ff1(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cedf:      	movl	$0x18, %esi
   4cee4:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cee9:      	testq	%rax, %rax
   4ceec:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4cef2:      	movq	%rax, %r15
   4cef5:      	movq	$0x76, (%rax)
   4cefc:      	movq	$0x1, 0x8(%rax)
   4cf04:      	movq	%r14, 0x10(%rax)
   4cf08:      	movq	%rax, 0x98(%rsp)
   4cf10:      	movq	%r13, 0xa0(%rsp)
   4cf18:      	movq	%r14, 0xa8(%rsp)
   4cf20:      	movq	$0x5, 0x80(%rsp)
   4cf2c:      	movq	0x16f95(%rip), %rdi     # 0x63ec8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4cf33:      	testq	%rdi, %rdi
   4cf36:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cf3c:      	movq	0x178(%rdi), %rcx
   4cf43:      	testq	%rcx, %rcx
   4cf46:      	je	0x4cf85 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1325>
   4cf48:      	movq	0x170(%rdi), %rax
   4cf4f:      	incq	%rax
   4cf52:      	movq	%rax, 0x170(%rdi)
   4cf59:      	movq	%rax, %rdx
   4cf5c:      	orq	%rcx, %rdx
   4cf5f:      	shrq	$0x20, %rdx
   4cf63:      	je	0x4d283 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1623>
   4cf69:      	xorl	%edx, %edx
   4cf6b:      	divq	%rcx
   4cf6e:      	testq	%rdx, %rdx
   4cf71:      	jne	0x4cf85 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1325>
   4cf73:      	movq	0x16f56(%rip), %rsi     # 0x63ed0 <native_roots.0>
   4cf7a:      	movq	%rdi, %r12
   4cf7d:      	callq	0x57010 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4cf82:      	movq	%r12, %rdi
   4cf85:      	movq	0x16f44(%rip), %rdx     # 0x63ed0 <native_roots.0>
   4cf8c:      	movl	$0x18, %esi
   4cf91:      	callq	0x56e60 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4cf96:      	testq	%rax, %rax
   4cf99:      	je	0x4d421 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17c1>
   4cf9f:      	movq	$0x82, (%rax)
   4cfa6:      	movq	%r13, 0x8(%rax)
   4cfaa:      	movq	%r15, 0x10(%rax)
   4cfae:      	movq	%rax, 0x10(%r14)
   4cfb2:      	movq	0x88(%rsp), %rax
   4cfba:      	testq	%rax, %rax
   4cfbd:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cfc3:      	movl	$0x1, 0x8(%rax)
   4cfca:      	movq	0x88(%rsp), %rax
   4cfd2:      	testq	%rax, %rax
   4cfd5:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cfdb:      	cmpl	$0x0, 0x8(%rax)
   4cfdf:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cfe5:      	movq	0x10(%rax), %rax
   4cfe9:      	testq	%rax, %rax
   4cfec:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4cff2:      	movq	%rax, 0x90(%rsp)
   4cffa:      	movq	0x8(%rax), %rcx
   4cffe:      	testq	%rcx, %rcx
   4d001:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4d007:      	movq	0x10(%rax), %rdi
   4d00b:      	movq	0x8(%rcx), %rax
   4d00f:      	movq	%rdi, 0x98(%rsp)
   4d017:      	movq	$0x3, 0x80(%rsp)
   4d023:      	xorl	%esi, %esi
   4d025:      	callq	*%rax
   4d027:      	subq	$0x8, %rsp
   4d02b:      	cmpq	$0x0, 0x78(%rsp)
   4d031:      	je	0x4d046 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x13e6>
   4d033:      	movq	0x70(%rsp), %rax
   4d038:      	movq	%rax, 0x16e91(%rip)     # 0x63ed0 <native_roots.0>
   4d03f:      	decq	0x16e6a(%rip)           # 0x63eb0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4d046:      	movq	$0x1, 0x210(%rsp)
   4d052:      	callq	0x4d690 <<std::sys::pal::unix::time::Timespec>::now>
   4d057:      	movq	%rax, 0x2e8(%rsp)
   4d05f:      	movl	%edx, 0x2f0(%rsp)
   4d066:      	movq	%rbx, 0x218(%rsp)
   4d06e:      	movl	%ebp, 0x220(%rsp)
   4d075:      	leaq	0x70(%rsp), %rdi
   4d07a:      	leaq	0x2e8(%rsp), %rsi
   4d082:      	leaq	0x218(%rsp), %rbx
   4d08a:      	movq	%rbx, %rdx
   4d08d:      	callq	0x4d760 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4d092:      	cmpb	$0x0, 0x70(%rsp)
   4d097:      	xorpd	%xmm0, %xmm0
   4d09b:      	jne	0x4d0d6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1476>
   4d09d:      	movsd	0x78(%rsp), %xmm1
   4d0a3:      	xorps	%xmm0, %xmm0
   4d0a6:      	cvtsi2sdl	0x80(%rsp), %xmm0
   4d0af:      	unpcklps	-0x48d76(%rip), %xmm1   # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x4340 <writev+0x4340>
   4d0b6:      	subpd	-0x48dde(%rip), %xmm1   # 0x42e0 <writev+0x42e0>
   4d0be:      	movapd	%xmm1, %xmm2
   4d0c2:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   4d0c6:      	addsd	%xmm1, %xmm2
   4d0ca:      	divsd	-0x4721a(%rip), %xmm0   # 0x5eb8 <writev+0x5eb8>
   4d0d2:      	addsd	%xmm2, %xmm0
   4d0d6:      	movsd	%xmm0, 0x218(%rsp)
   4d0df:      	leaq	0x210(%rsp), %rax
   4d0e7:      	movq	%rax, 0x70(%rsp)
   4d0ec:      	leaq	0x104d(%rip), %rax      # 0x4e140 <<i64 as core::fmt::Display>::fmt>
   4d0f3:      	movq	%rax, 0x78(%rsp)
   4d0f8:      	movq	%rbx, 0x80(%rsp)
   4d100:      	leaq	0x1159(%rip), %rax      # 0x4e260 <<f64 as core::fmt::Display>::fmt>
   4d107:      	movq	%rax, 0x88(%rsp)
   4d10f:      	leaq	-0x471c6(%rip), %rdi    # 0x5f50 <writev+0x5f50>
   4d116:      	leaq	0x70(%rsp), %rsi
   4d11b:      	callq	0x4e2a0 <std::io::stdio::_print>
   4d120:      	leaq	0x70(%rsp), %rdi
   4d125:      	callq	0x4d830 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4d12a:      	movq	0x70(%rsp), %rbx
   4d12f:      	testq	%rbx, %rbx
   4d132:      	jle	0x4d13f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x14df>
   4d134:      	movq	0x78(%rsp), %rdi
   4d139:      	callq	*0x151f1(%rip)          # 0x62330 <writev+0x62330>
   4d13f:      	xorl	%eax, %eax
   4d141:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4d14b:      	cmpq	%rcx, %rbx
   4d14e:      	setne	%al
   4d151:      	addq	$0x3b8, %rsp            # imm = 0x3B8
   4d158:      	popq	%rbx
   4d159:      	popq	%r12
   4d15b:      	popq	%r13
   4d15d:      	popq	%r14
   4d15f:      	popq	%r15
   4d161:      	popq	%rbp
   4d162:      	retq
   4d163:      	xorl	%edx, %edx
   4d165:      	divl	%ecx
   4d167:      	testq	%rdx, %rdx
   4d16a:      	jne	0x4c4a6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x846>
   4d170:      	jmp	0x4c48f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x82f>
   4d175:      	xorl	%edx, %edx
   4d177:      	divl	%ecx
   4d179:      	testq	%rdx, %rdx
   4d17c:      	jne	0x4c536 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x8d6>
   4d182:      	jmp	0x4c524 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x8c4>
   4d187:      	xorl	%edx, %edx
   4d189:      	divl	%ecx
   4d18b:      	testq	%rdx, %rdx
   4d18e:      	jne	0x4c5ca <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x96a>
   4d194:      	jmp	0x4c5b8 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x958>
   4d199:      	xorl	%edx, %edx
   4d19b:      	divl	%ecx
   4d19d:      	testq	%rdx, %rdx
   4d1a0:      	jne	0x4c65e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x9fe>
   4d1a6:      	jmp	0x4c64c <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x9ec>
   4d1ab:      	xorl	%edx, %edx
   4d1ad:      	divl	%ecx
   4d1af:      	testq	%rdx, %rdx
   4d1b2:      	jne	0x4c6f2 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xa92>
   4d1b8:      	jmp	0x4c6e0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xa80>
   4d1bd:      	xorl	%edx, %edx
   4d1bf:      	divl	%ecx
   4d1c1:      	testq	%rdx, %rdx
   4d1c4:      	jne	0x4c786 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xb26>
   4d1ca:      	jmp	0x4c774 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xb14>
   4d1cf:      	xorl	%edx, %edx
   4d1d1:      	divl	%ecx
   4d1d3:      	testq	%rdx, %rdx
   4d1d6:      	jne	0x4c81a <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xbba>
   4d1dc:      	jmp	0x4c808 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xba8>
   4d1e1:      	xorl	%edx, %edx
   4d1e3:      	divl	%ecx
   4d1e5:      	testq	%rdx, %rdx
   4d1e8:      	jne	0x4c8d1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xc71>
   4d1ee:      	jmp	0x4c8bf <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xc5f>
   4d1f3:      	xorl	%edx, %edx
   4d1f5:      	divl	%ecx
   4d1f7:      	testq	%rdx, %rdx
   4d1fa:      	jne	0x4c971 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xd11>
   4d200:      	jmp	0x4c95f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xcff>
   4d205:      	xorl	%edx, %edx
   4d207:      	divl	%ecx
   4d209:      	testq	%rdx, %rdx
   4d20c:      	jne	0x4ca20 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xdc0>
   4d212:      	jmp	0x4ca0e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xdae>
   4d217:      	xorl	%edx, %edx
   4d219:      	divl	%ecx
   4d21b:      	testq	%rdx, %rdx
   4d21e:      	jne	0x4cac0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xe60>
   4d224:      	jmp	0x4caae <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xe4e>
   4d229:      	xorl	%edx, %edx
   4d22b:      	divl	%ecx
   4d22d:      	testq	%rdx, %rdx
   4d230:      	jne	0x4cb54 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xef4>
   4d236:      	jmp	0x4cb42 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xee2>
   4d23b:      	xorl	%edx, %edx
   4d23d:      	divl	%ecx
   4d23f:      	testq	%rdx, %rdx
   4d242:      	jne	0x4cc03 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xfa3>
   4d248:      	jmp	0x4cbf1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0xf91>
   4d24d:      	xorl	%edx, %edx
   4d24f:      	divl	%ecx
   4d251:      	testq	%rdx, %rdx
   4d254:      	jne	0x4ccd9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1079>
   4d25a:      	jmp	0x4ccc7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1067>
   4d25f:      	xorl	%edx, %edx
   4d261:      	divl	%esi
   4d263:      	testq	%rdx, %rdx
   4d266:      	jne	0x4ce1d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x11bd>
   4d26c:      	jmp	0x4ce06 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x11a6>
   4d271:      	xorl	%edx, %edx
   4d273:      	divl	%ecx
   4d275:      	testq	%rdx, %rdx
   4d278:      	jne	0x4ced8 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1278>
   4d27e:      	jmp	0x4cec6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1266>
   4d283:      	xorl	%edx, %edx
   4d285:      	divl	%ecx
   4d287:      	testq	%rdx, %rdx
   4d28a:      	jne	0x4cf85 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1325>
   4d290:      	jmp	0x4cf73 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1313>
   4d295:      	cmpq	%rcx, %rdx
   4d298:      	jne	0x4d2a6 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1646>
   4d29a:      	xorl	%ebp, %ebp
   4d29c:      	movq	0x8(%rsp), %r13
   4d2a1:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d2a6:      	movq	%rdx, 0x20(%rsp)
   4d2ab:      	movq	0x220(%rsp), %rsi
   4d2b3:      	movq	0x228(%rsp), %r13
   4d2bb:      	leaq	0x70(%rsp), %rdi
   4d2c0:      	movq	%rsi, 0x10(%rsp)
   4d2c5:      	movq	%r13, %rdx
   4d2c8:      	callq	0x1a970 <core::str::converts::from_utf8>
   4d2cd:      	cmpb	$0x0, 0x70(%rsp)
   4d2d2:      	je	0x4d2f1 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1691>
   4d2d4:      	xorl	%ebp, %ebp
   4d2d6:      	cmpq	$0x0, 0x20(%rsp)
   4d2dc:      	movq	0x8(%rsp), %r13
   4d2e1:      	movq	0x10(%rsp), %rdi
   4d2e6:      	jg	0x4d3fa <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x179a>
   4d2ec:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d2f1:      	testq	%r13, %r13
   4d2f4:      	je	0x4d31f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x16bf>
   4d2f6:      	cmpq	$0x1, %r13
   4d2fa:      	movq	0x10(%rsp), %rdi
   4d2ff:      	jne	0x4d33f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x16df>
   4d301:      	movzbl	(%rdi), %eax
   4d304:      	xorl	%ebp, %ebp
   4d306:      	cmpl	$0x2b, %eax
   4d309:      	movq	0x20(%rsp), %r11
   4d30e:      	je	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d314:      	cmpl	$0x2d, %eax
   4d317:      	je	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d31d:      	jmp	0x4d347 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x16e7>
   4d31f:      	movq	%r13, %rbp
   4d322:      	movq	0x10(%rsp), %rdi
   4d327:      	movq	0x20(%rsp), %r11
   4d32c:      	testq	%r11, %r11
   4d32f:      	movq	0x8(%rsp), %r13
   4d334:      	jne	0x4d3fa <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x179a>
   4d33a:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d33f:      	movzbl	(%rdi), %eax
   4d342:      	movq	0x20(%rsp), %r11
   4d347:      	xorl	%ecx, %ecx
   4d349:      	cmpb	$0x2b, %al
   4d34b:      	sete	%cl
   4d34e:      	movq	%rcx, %rax
   4d351:      	negq	%rax
   4d354:      	movq	%r13, %rdx
   4d357:      	subq	%rcx, %rdx
   4d35a:      	addq	%rdi, %rcx
   4d35d:      	cmpq	$0x11, %rdx
   4d361:      	jae	0x4d39c <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x173c>
   4d363:      	testq	%rdx, %rdx
   4d366:      	je	0x4d3d9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1779>
   4d368:      	addq	%rax, %r13
   4d36b:      	negq	%r13
   4d36e:      	xorl	%eax, %eax
   4d370:      	xorl	%ebp, %ebp
   4d372:      	movzbl	(%rcx,%rax), %edx
   4d376:      	addl	$-0x30, %edx
   4d379:      	cmpl	$0x9, %edx
   4d37c:      	ja	0x4d3ea <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178a>
   4d37e:      	leaq	(,%rbp,4), %rsi
   4d386:      	addq	%rbp, %rsi
   4d389:      	movl	%edx, %edx
   4d38b:      	leaq	(%rdx,%rsi,2), %rbp
   4d38f:      	incq	%rax
   4d392:      	movq	%r13, %rdx
   4d395:      	addq	%rax, %rdx
   4d398:      	jne	0x4d372 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1712>
   4d39a:      	jmp	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d39c:      	addq	%rax, %r13
   4d39f:      	negq	%r13
   4d3a2:      	xorl	%ebp, %ebp
   4d3a4:      	movl	$0xa, %esi
   4d3a9:      	xorl	%r9d, %r9d
   4d3ac:      	xorl	%eax, %eax
   4d3ae:      	movq	%r13, %rdx
   4d3b1:      	addq	%r9, %rdx
   4d3b4:      	je	0x4d405 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x17a5>
   4d3b6:      	mulq	%rsi
   4d3b9:      	jo	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d3bb:      	movzbl	(%rcx,%r9), %r8d
   4d3c0:      	addl	$-0x30, %r8d
   4d3c4:      	addq	%r8, %rax
   4d3c7:      	setb	%dl
   4d3ca:      	cmpl	$0x9, %r8d
   4d3ce:      	ja	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d3d0:      	incq	%r9
   4d3d3:      	testb	%dl, %dl
   4d3d5:      	je	0x4d3ae <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x174e>
   4d3d7:      	jmp	0x4d3ec <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x178c>
   4d3d9:      	xorl	%ebp, %ebp
   4d3db:      	testq	%r11, %r11
   4d3de:      	movq	0x8(%rsp), %r13
   4d3e3:      	jne	0x4d3fa <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x179a>
   4d3e5:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d3ea:      	xorl	%ebp, %ebp
   4d3ec:      	testq	%r11, %r11
   4d3ef:      	movq	0x8(%rsp), %r13
   4d3f4:      	je	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d3fa:      	callq	*0x14f30(%rip)          # 0x62330 <writev+0x62330>
   4d400:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d405:      	movq	%rax, %rbp
   4d408:      	testq	%r11, %r11
   4d40b:      	movq	0x8(%rsp), %r13
   4d410:      	jne	0x4d3fa <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x179a>
   4d412:      	jmp	0x4c2c7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x667>
   4d417:      	movl	$0x180, %edi            # imm = 0x180
   4d41c:      	callq	0x13f10 <alloc::alloc::handle_alloc_error>
   4d421:      	leaq	-0x44014(%rip), %rdi    # 0x9414 <core::num::flt2dec::strategy::dragon::POW5TO256+0x7e8>
   4d428:      	movl	$0x2f, %esi
   4d42d:      	callq	0x56920 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   4d432:      	movq	%r15, %rdi
   4d435:      	callq	0x13f10 <alloc::alloc::handle_alloc_error>
   4d43a:      	movl	$0x468, %edi            # imm = 0x468
   4d43f:      	callq	0x13f10 <alloc::alloc::handle_alloc_error>
   4d444:      	movl	$0x70, %edi
   4d449:      	callq	0x13f10 <alloc::alloc::handle_alloc_error>
   4d44e:      	movl	$0x178, %edi            # imm = 0x178
   4d453:      	callq	0x13f10 <alloc::alloc::handle_alloc_error>
   4d458:      	movq	%r13, 0x8(%rsp)
   4d45d:      	movq	%rbx, 0x18(%rsp)
   4d462:      	testq	%r12, %r12
   4d465:      	jne	0x4d48d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x182d>
   4d467:      	cmpq	$0x0, 0x8(%rsp)
   4d46d:      	jne	0x4d4d7 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1877>
   4d46f:      	cmpq	$0x0, 0x58(%rsp)
   4d475:      	jne	0x4d4ea <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x188a>
   4d477:      	cmpq	$0x0, 0x60(%rsp)
   4d47d:      	jne	0x4d4fd <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x189d>
   4d47f:      	testq	%r14, %r14
   4d482:      	je	0x4d50d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18ad>
   4d488:      	jmp	0x4d527 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c7>
   4d48d:      	movq	0x30(%rsp), %rax
   4d492:      	leaq	0x18(%rax), %rbx
   4d496:      	movq	0x14e4b(%rip), %r15     # 0x622e8 <writev+0x622e8>
   4d49d:      	movq	0x14e8c(%rip), %r13     # 0x62330 <writev+0x62330>
   4d4a4:      	jmp	0x4d4b9 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1859>
   4d4a6:      	nopw	%cs:(%rax,%rax)
   4d4b0:      	addq	$0x38, %rbx
   4d4b4:      	decq	%r12
   4d4b7:      	je	0x4d467 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1807>
   4d4b9:      	movq	-0x8(%rbx), %rsi
   4d4bd:      	movq	(%rbx), %rdi
   4d4c0:      	shlq	$0xf, %rsi
   4d4c4:      	callq	*%r15
   4d4c7:      	cmpq	$0x0, -0x18(%rbx)
   4d4cc:      	je	0x4d4b0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1850>
   4d4ce:      	movq	-0x10(%rbx), %rdi
   4d4d2:      	callq	*%r13
   4d4d5:      	jmp	0x4d4b0 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1850>
   4d4d7:      	movq	0x30(%rsp), %rdi
   4d4dc:      	callq	*0x14e4e(%rip)          # 0x62330 <writev+0x62330>
   4d4e2:      	cmpq	$0x0, 0x58(%rsp)
   4d4e8:      	je	0x4d477 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x1817>
   4d4ea:      	movq	0x40(%rsp), %rdi
   4d4ef:      	callq	*0x14e3b(%rip)          # 0x62330 <writev+0x62330>
   4d4f5:      	cmpq	$0x0, 0x60(%rsp)
   4d4fb:      	je	0x4d47f <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x181f>
   4d4fd:      	movq	0x48(%rsp), %rdi
   4d502:      	callq	*0x14e28(%rip)          # 0x62330 <writev+0x62330>
   4d508:      	testq	%r14, %r14
   4d50b:      	jne	0x4d527 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c7>
   4d50d:      	cmpq	$0x0, 0x68(%rsp)
   4d513:      	jne	0x4d558 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18f8>
   4d515:      	cmpq	$0x0, 0x28(%rsp)
   4d51b:      	jne	0x4d56b <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x190b>
   4d51d:      	testq	%rbp, %rbp
   4d520:      	jne	0x4d57b <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x191b>
   4d522:      	callq	0x55920 <native_trap>
   4d527:      	movq	0x38(%rsp), %rax
   4d52c:      	leaq	0x8(%rax), %rbx
   4d530:      	movq	0x14df9(%rip), %r15     # 0x62330 <writev+0x62330>
   4d537:      	jmp	0x4d549 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18e9>
   4d539:      	nopl	(%rax)
   4d540:      	addq	$0x18, %rbx
   4d544:      	decq	%r14
   4d547:      	je	0x4d50d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18ad>
   4d549:      	cmpq	$0x0, -0x8(%rbx)
   4d54e:      	jle	0x4d540 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18e0>
   4d550:      	movq	(%rbx), %rdi
   4d553:      	callq	*%r15
   4d556:      	jmp	0x4d540 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18e0>
   4d558:      	movq	0x38(%rsp), %rdi
   4d55d:      	callq	*0x14dcd(%rip)          # 0x62330 <writev+0x62330>
   4d563:      	cmpq	$0x0, 0x28(%rsp)
   4d569:      	je	0x4d51d <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18bd>
   4d56b:      	movq	0x50(%rsp), %rdi
   4d570:      	callq	*0x14dba(%rip)          # 0x62330 <writev+0x62330>
   4d576:      	testq	%rbp, %rbp
   4d579:      	je	0x4d522 <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x18c2>
   4d57b:      	movq	0x18(%rsp), %rdi
   4d580:      	callq	*0x14daa(%rip)          # 0x62330 <writev+0x62330>
   4d586:      	callq	0x55920 <native_trap>
   4d58b:      	movq	%rax, %r14
   4d58e:      	cmpq	$0x0, 0x8(%rbx)
   4d593:      	je	0x4d59e <wasm_native_22c056c25b6219bd53fa00a27cd004223b08962a1d4968b2ce48f6fa810c4655::run::hd7d9d9a5e0aae80b+0x193e>
   4d595:      	movq	%rbp, %rdi
   4d598:      	callq	*0x14d92(%rip)          # 0x62330 <writev+0x62330>
   4d59e:      	movq	0x10(%rsp), %rdi
   4d5a3:      	callq	*0x14d87(%rip)          # 0x62330 <writev+0x62330>
   4d5a9:      	movq	%r14, %rdi
   4d5ac:      	callq	0x5ed60 <_Unwind_Resume@plt>
   4d5b1:      	int3
   4d5b2:      	int3
   4d5b3:      	int3
   4d5b4:      	int3
   4d5b5:      	int3
   4d5b6:      	int3
   4d5b7:      	int3
   4d5b8:      	int3
   4d5b9:      	int3
   4d5ba:      	int3
   4d5bb:      	int3
   4d5bc:      	int3
   4d5bd:      	int3
   4d5be:      	int3
   4d5bf:      	int3
