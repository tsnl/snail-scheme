000000000004b200 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041>:
   4b200:      	pushq	%rbp
   4b201:      	pushq	%r15
   4b203:      	pushq	%r14
   4b205:      	pushq	%r13
   4b207:      	pushq	%r12
   4b209:      	pushq	%rbx
   4b20a:      	subq	$0x3c8, %rsp            # imm = 0x3C8
   4b211:      	cmpq	$0x0, 0x13227(%rip)     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b219:      	jne	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b21f:      	movl	$0x210, %edi            # imm = 0x210
   4b224:      	callq	*0x1171e(%rip)          # 0x5c948 <writev+0x5c948>
   4b22a:      	testq	%rax, %rax
   4b22d:      	je	0x4c65d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x145d>
   4b233:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b23d:      	movq	%rax, 0x28(%rsp)
   4b242:      	movq	%rax, %r13
   4b245:      	addq	$0x10, %r13
   4b249:      	leaq	0x112b8(%rip), %rbp     # 0x5c508 <native_gc_layouts+0x8>
   4b250:      	xorl	%r14d, %r14d
   4b253:      	movl	$0x3bc681, %eax         # imm = 0x3BC681
   4b258:      	jmp	0x4b286 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x86>
   4b25a:      	nopw	(%rax,%rax)
   4b260:      	movq	%rcx, %r12
   4b263:      	jne	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b269:      	movq	%r12, -0x10(%r13)
   4b26d:      	movq	%rbx, -0x8(%r13)
   4b271:      	movq	%r12, (%r13)
   4b275:      	incq	%r14
   4b278:      	addq	$0x18, %r13
   4b27c:      	addq	$0x10, %rbp
   4b280:      	cmpq	$0x16, %r14
   4b284:      	je	0x4b2ef <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xef>
   4b286:      	cmpl	$0x2, -0x8(%rbp)
   4b28a:      	jae	0x4b260 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x60>
   4b28c:      	btq	%r14, %rax
   4b290:      	jae	0x4b2a0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xa0>
   4b292:      	movl	$0x4, %ebx
   4b297:      	xorl	%r12d, %r12d
   4b29a:      	jmp	0x4b269 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x69>
   4b29c:      	nopl	(%rax)
   4b2a0:      	movl	-0x4(%rbp), %r12d
   4b2a4:      	leaq	(,%r12,4), %r15
   4b2ac:      	movq	(%rbp), %rax
   4b2b0:      	movq	%rax, 0x10(%rsp)
   4b2b5:      	movq	%r15, %rdi
   4b2b8:      	callq	*0x1168a(%rip)          # 0x5c948 <writev+0x5c948>
   4b2be:      	testq	%rax, %rax
   4b2c1:      	je	0x4c644 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1444>
   4b2c7:      	movq	%rax, %rbx
   4b2ca:      	movq	%rax, %rdi
   4b2cd:      	movq	0x10(%rsp), %rsi
   4b2d2:      	movq	%r15, %rdx
   4b2d5:      	callq	*0x11765(%rip)          # 0x5ca40 <writev+0x5ca40>
   4b2db:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b2e5:      	movl	$0x3bc681, %eax         # imm = 0x3BC681
   4b2ea:      	jmp	0x4b269 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x69>
   4b2ef:      	movl	$0x28, %edi
   4b2f4:      	callq	*0x1164e(%rip)          # 0x5c948 <writev+0x5c948>
   4b2fa:      	testq	%rax, %rax
   4b2fd:      	je	0x4c667 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1467>
   4b303:      	movq	%rax, %r15
   4b306:      	movq	0x11373(%rip), %rax     # 0x5c680 <native_gc_globals+0x20>
   4b30d:      	movq	%rax, 0x20(%r15)
   4b311:      	movaps	0x11358(%rip), %xmm0    # 0x5c670 <native_gc_globals+0x10>
   4b318:      	movups	%xmm0, 0x10(%r15)
   4b31d:      	movapd	0x1133b(%rip), %xmm0    # 0x5c660 <native_gc_globals>
   4b325:      	movupd	%xmm0, (%r15)
   4b32a:      	movl	$0x1, %edi
   4b32f:      	movl	$0xb0, %esi
   4b334:      	callq	*0x11566(%rip)          # 0x5c8a0 <writev+0x5c8a0>
   4b33a:      	testq	%rax, %rax
   4b33d:      	je	0x4c671 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1471>
   4b343:      	movq	%rax, %r13
   4b346:      	movabsq	$0x3fffffffffff8000, %rbx # imm = 0x3FFFFFFFFFFF8000
   4b350:      	leaq	-0x4276c(%rip), %rsi    # 0x8beb <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4b357:      	leaq	0x80(%rsp), %rdi
   4b35f:      	movl	$0x13, %edx
   4b364:      	callq	0x54930 <std::env::_var_os>
   4b369:      	movq	0x80(%rsp), %rax
   4b371:      	negq	%rax
   4b374:      	jo	0x4b3b6 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1b6>
   4b376:      	jae	0x4b386 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x186>
   4b378:      	movq	0x88(%rsp), %rdi
   4b380:      	callq	*0x11522(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4b386:      	leaq	-0x427a2(%rip), %rdi    # 0x8beb <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4b38d:      	movl	$0x13, %esi
   4b392:      	xorl	%edx, %edx
   4b394:      	callq	0x54b20 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b399:      	movq	%rax, %rdx
   4b39c:      	addq	$-0x8000, %rax          # imm = 0x8000
   4b3a2:      	cmpq	%rbx, %rax
   4b3a5:      	jae	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b3ab:      	andq	%rbx, %rdx
   4b3ae:      	movq	%rdx, %rbp
   4b3b1:      	movq	%rdx, %r14
   4b3b4:      	jmp	0x4b3c1 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1c1>
   4b3b6:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4b3bb:      	xorl	%r14d, %r14d
   4b3be:      	movq	%rbx, %rbp
   4b3c1:      	leaq	-0x427ca(%rip), %rdi    # 0x8bfe <core::num::flt2dec::strategy::dragon::POW5TO256+0x60a>
   4b3c8:      	movl	$0x16, %esi
   4b3cd:      	callq	0x54b20 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b3d2:      	movq	%rax, %r12
   4b3d5:      	addq	$-0x8000, %rax          # imm = 0x8000
   4b3db:      	cmpq	%rbx, %rax
   4b3de:      	jae	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b3e4:      	movq	%r13, 0x10(%rsp)
   4b3e9:      	andq	%rbx, %r12
   4b3ec:      	cmpq	%rbp, %r12
   4b3ef:      	ja	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b3f5:      	leaq	-0x427e8(%rip), %rdi    # 0x8c14 <core::num::flt2dec::strategy::dragon::POW5TO256+0x620>
   4b3fc:      	movl	$0x12, %esi
   4b401:      	movl	$0x800000, %edx         # imm = 0x800000
   4b406:      	callq	0x54b20 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4b40b:      	movq	%rax, %r13
   4b40e:      	leaq	-0x427ef(%rip), %rsi    # 0x8c26 <core::num::flt2dec::strategy::dragon::POW5TO256+0x632>
   4b415:      	leaq	0x80(%rsp), %rdi
   4b41d:      	movl	$0xe, %edx
   4b422:      	callq	0x54930 <std::env::_var_os>
   4b427:      	movq	0x80(%rsp), %rax
   4b42f:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b439:      	cmpq	%rcx, %rax
   4b43c:      	setne	%bl
   4b43f:      	testq	%rax, %rax
   4b442:      	jle	0x4b452 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x252>
   4b444:      	movq	0x88(%rsp), %rdi
   4b44c:      	callq	*0x11456(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4b452:      	movq	$0x0, 0x80(%rsp)
   4b45e:      	movq	$0x8, 0x88(%rsp)
   4b46a:      	xorpd	%xmm0, %xmm0
   4b46e:      	movupd	%xmm0, 0x90(%rsp)
   4b477:      	movupd	%xmm0, 0x138(%rsp)
   4b480:      	movupd	%xmm0, 0x148(%rsp)
   4b489:      	movupd	%xmm0, 0x158(%rsp)
   4b492:      	movq	%r12, 0x110(%rsp)
   4b49a:      	movq	%rbp, 0x118(%rsp)
   4b4a2:      	movq	%r14, 0x120(%rsp)
   4b4aa:      	movq	%r13, 0x128(%rsp)
   4b4b2:      	movb	%bl, 0x130(%rsp)
   4b4b9:      	movq	%r13, 0x168(%rsp)
   4b4c1:      	movq	$0x8, 0xa0(%rsp)
   4b4cd:      	movupd	%xmm0, 0xa8(%rsp)
   4b4d6:      	movq	$0x8, 0xb8(%rsp)
   4b4e2:      	movq	$0x0, 0xc0(%rsp)
   4b4ee:      	movq	$0x16, 0xc8(%rsp)
   4b4fa:      	movq	0x28(%rsp), %rax
   4b4ff:      	movq	%rax, 0xd0(%rsp)
   4b507:      	movq	$0x16, 0xd8(%rsp)
   4b513:      	movq	$0x5, 0xe0(%rsp)
   4b51f:      	movq	%r15, 0xe8(%rsp)
   4b527:      	movq	$0x5, 0xf0(%rsp)
   4b533:      	movq	$0x0, 0xf8(%rsp)
   4b53f:      	movq	$0x8, 0x100(%rsp)
   4b54b:      	movq	$0x0, 0x108(%rsp)
   4b557:      	movupd	%xmm0, 0x1c0(%rsp)
   4b560:      	movupd	%xmm0, 0x1b0(%rsp)
   4b569:      	movupd	%xmm0, 0x1a0(%rsp)
   4b572:      	movupd	%xmm0, 0x190(%rsp)
   4b57b:      	movupd	%xmm0, 0x180(%rsp)
   4b584:      	movupd	%xmm0, 0x170(%rsp)
   4b58d:      	movq	$0x0, 0x1d0(%rsp)
   4b599:      	leaq	0x80(%rsp), %r14
   4b5a1:      	movq	%r14, %rdi
   4b5a4:      	movq	%r12, %rsi
   4b5a7:      	callq	0x54d70 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4b5ac:      	movq	0x80(%rsp), %r13
   4b5b4:      	movq	0x88(%rsp), %rcx
   4b5bc:      	movq	%rcx, 0x38(%rsp)
   4b5c1:      	movq	0x90(%rsp), %rbx
   4b5c9:      	movq	0x98(%rsp), %rcx
   4b5d1:      	movq	%rcx, 0x60(%rsp)
   4b5d6:      	movq	0xa0(%rsp), %rcx
   4b5de:      	movq	%rcx, 0x48(%rsp)
   4b5e3:      	movq	0xb0(%rsp), %rcx
   4b5eb:      	movq	%rcx, 0x68(%rsp)
   4b5f0:      	movq	0xb8(%rsp), %rcx
   4b5f8:      	movq	%rcx, 0x50(%rsp)
   4b5fd:      	movq	0xc8(%rsp), %rcx
   4b605:      	movq	%rcx, 0x70(%rsp)
   4b60a:      	movq	0xd0(%rsp), %rcx
   4b612:      	movq	%rcx, 0x40(%rsp)
   4b617:      	movq	0xd8(%rsp), %r15
   4b61f:      	movq	0xe0(%rsp), %rcx
   4b627:      	movq	%rcx, 0x78(%rsp)
   4b62c:      	movq	0xe8(%rsp), %rcx
   4b634:      	movq	%rcx, 0x58(%rsp)
   4b639:      	movq	0xf8(%rsp), %rbp
   4b641:      	movq	0x100(%rsp), %r12
   4b649:      	testb	%al, %al
   4b64b:      	movq	%rbp, 0x28(%rsp)
   4b650:      	je	0x4c67b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x147b>
   4b656:      	leaq	0x108(%rsp), %rsi
   4b65e:      	movq	0xf0(%rsp), %rax
   4b666:      	movq	%rax, 0x210(%rsp)
   4b66e:      	movq	0xa8(%rsp), %rax
   4b676:      	movq	%rax, 0x200(%rsp)
   4b67e:      	movq	0xc0(%rsp), %rax
   4b686:      	movq	%rax, 0x208(%rsp)
   4b68e:      	leaq	0x228(%rsp), %rdi
   4b696:      	movl	$0xd0, %edx
   4b69b:      	callq	*0x1139f(%rip)          # 0x5ca40 <writev+0x5ca40>
   4b6a1:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4b6ab:      	cmpq	%rax, %r13
   4b6ae:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b6b4:      	leaq	0x2f8(%rsp), %rdi
   4b6bc:      	leaq	0x228(%rsp), %rsi
   4b6c4:      	movl	$0xd0, %edx
   4b6c9:      	callq	*0x11371(%rip)          # 0x5ca40 <writev+0x5ca40>
   4b6cf:      	movupd	-0x4288c(%rip), %xmm0   # 0x8e4b <core::num::flt2dec::strategy::dragon::POW5TO256+0x857>
   4b6d7:      	movapd	%xmm0, 0x80(%rsp)
   4b6e0:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4b6ea:      	movq	%rax, 0x90(%rsp)
   4b6f2:      	movb	$0x0, 0x98(%rsp)
   4b6fa:      	movb	$0x1, %al
   4b6fc:      	testb	%al, %al
   4b6fe:      	je	0x4b70c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x50c>
   4b700:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4b70a:      	jmp	0x4b727 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x527>
   4b70c:      	xorl	%eax, %eax
   4b70e:      	nop
   4b710:      	cmpb	$0x0, 0x80(%rsp,%rax)
   4b718:      	je	0x4b793 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x593>
   4b71a:      	incq	%rax
   4b71d:      	jne	0x4b710 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x510>
   4b71f:      	movq	0x80(%rsp), %rax
   4b727:      	movq	0x88(%rsp), %rcx
   4b72f:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4b739:      	movq	%rdx, %rsi
   4b73c:      	subq	%rax, %rsi
   4b73f:      	orq	%rax, %rsi
   4b742:      	subq	%rcx, %rdx
   4b745:      	orq	%rcx, %rdx
   4b748:      	andq	%rsi, %rdx
   4b74b:      	notq	%rdx
   4b74e:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4b758:      	xorl	%ecx, %ecx
   4b75a:      	testq	%rax, %rdx
   4b75d:      	sete	%cl
   4b760:      	shll	$0x4, %ecx
   4b763:      	leaq	(%rsp,%rcx), %rdx
   4b767:      	addq	$0x80, %rdx
   4b76e:      	movq	%rcx, %rsi
   4b771:      	xorq	$0x19, %rsi
   4b775:      	xorl	%eax, %eax
   4b777:      	nopw	(%rax,%rax)
   4b780:      	cmpb	$0x0, (%rdx,%rax)
   4b784:      	je	0x4b790 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x590>
   4b786:      	incq	%rax
   4b789:      	cmpq	%rax, %rsi
   4b78c:      	jne	0x4b780 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x580>
   4b78e:      	jmp	0x4b7e1 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x5e1>
   4b790:      	addq	%rcx, %rax
   4b793:      	cmpq	$0x18, %rax
   4b797:      	jne	0x4b7e1 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x5e1>
   4b799:      	movq	%r13, 0x8(%rsp)
   4b79e:      	leaq	0x228(%rsp), %rdi
   4b7a6:      	leaq	0x80(%rsp), %rsi
   4b7ae:      	callq	0x46430 <std::sys::env::unix::getenv::{closure#0}>
   4b7b3:      	movq	0x228(%rsp), %rdx
   4b7bb:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4b7c5:      	leaq	0x1(%rcx), %rax
   4b7c9:      	cmpq	%rax, %rdx
   4b7cc:      	jne	0x4c25c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x105c>
   4b7d2:      	movq	0x230(%rsp), %rax
   4b7da:      	movq	0x8(%rsp), %r13
   4b7df:      	jmp	0x4b7fd <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x5fd>
   4b7e1:      	movabsq	$-0x8000000000000000, %rax # imm = 0x8000000000000000
   4b7eb:      	incq	%rax
   4b7ee:      	movq	%rax, 0x228(%rsp)
   4b7f6:      	leaq	0x10193(%rip), %rax     # 0x5b990 <writev+0x5b990>
   4b7fd:      	movl	%eax, %ecx
   4b7ff:      	andl	$0x3, %ecx
   4b802:      	leal	-0x2(%rcx), %edx
   4b805:      	cmpl	$0x2, %edx
   4b808:      	jb	0x4b857 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x657>
   4b80a:      	testq	%rcx, %rcx
   4b80d:      	je	0x4b857 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x657>
   4b80f:      	movq	%r13, %r14
   4b812:      	leaq	-0x1(%rax), %rcx
   4b816:      	movq	%rcx, 0x8(%rsp)
   4b81b:      	movq	-0x1(%rax), %rbp
   4b81f:      	movq	0x7(%rax), %r13
   4b823:      	movq	(%r13), %rax
   4b827:      	testq	%rax, %rax
   4b82a:      	je	0x4b831 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x631>
   4b82c:      	movq	%rbp, %rdi
   4b82f:      	callq	*%rax
   4b831:      	cmpq	$0x0, 0x8(%r13)
   4b836:      	je	0x4b841 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x641>
   4b838:      	movq	%rbp, %rdi
   4b83b:      	callq	*0x11067(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4b841:      	movq	0x8(%rsp), %rdi
   4b846:      	callq	*0x1105c(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4b84c:      	movq	%r14, %r13
   4b84f:      	leaq	0x80(%rsp), %r14
   4b857:      	xorl	%ebp, %ebp
   4b859:      	movl	$0x180, %edi            # imm = 0x180
   4b85e:      	callq	*0x110e4(%rip)          # 0x5c948 <writev+0x5c948>
   4b864:      	testq	%rax, %rax
   4b867:      	je	0x4c3e4 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11e4>
   4b86d:      	movq	%r13, %rcx
   4b870:      	movq	%rax, %r13
   4b873:      	movq	%rcx, (%rax)
   4b876:      	movq	0x38(%rsp), %rcx
   4b87b:      	movq	%rcx, 0x8(%rax)
   4b87f:      	movq	%rbx, 0x10(%rax)
   4b883:      	movq	0x60(%rsp), %rcx
   4b888:      	movq	%rcx, 0x18(%rax)
   4b88c:      	movq	0x48(%rsp), %rcx
   4b891:      	movq	%rcx, 0x20(%rax)
   4b895:      	movq	0x200(%rsp), %rcx
   4b89d:      	movq	%rcx, 0x28(%rax)
   4b8a1:      	movq	0x68(%rsp), %rcx
   4b8a6:      	movq	%rcx, 0x30(%rax)
   4b8aa:      	movq	0x50(%rsp), %rcx
   4b8af:      	movq	%rcx, 0x38(%rax)
   4b8b3:      	movq	0x208(%rsp), %rcx
   4b8bb:      	movq	%rcx, 0x40(%rax)
   4b8bf:      	movq	0x70(%rsp), %rcx
   4b8c4:      	movq	%rcx, 0x48(%rax)
   4b8c8:      	movq	0x40(%rsp), %rcx
   4b8cd:      	movq	%rcx, 0x50(%rax)
   4b8d1:      	movq	%r15, 0x58(%rax)
   4b8d5:      	movq	0x78(%rsp), %rcx
   4b8da:      	movq	%rcx, 0x60(%rax)
   4b8de:      	movq	0x58(%rsp), %rcx
   4b8e3:      	movq	%rcx, 0x68(%rax)
   4b8e7:      	movq	0x210(%rsp), %rcx
   4b8ef:      	movq	%rcx, 0x70(%rax)
   4b8f3:      	movq	0x28(%rsp), %rcx
   4b8f8:      	movq	%rcx, 0x78(%rax)
   4b8fc:      	movq	%r12, 0x80(%rax)
   4b903:      	addq	$0x88, %rax
   4b909:      	leaq	0x2f8(%rsp), %rsi
   4b911:      	movl	$0xd0, %edx
   4b916:      	movq	%rax, %rdi
   4b919:      	callq	*0x11121(%rip)          # 0x5ca40 <writev+0x5ca40>
   4b91f:      	movq	$0x16, 0x158(%r13)
   4b92a:      	movq	0x10(%rsp), %rax
   4b92f:      	movq	%rax, 0x160(%r13)
   4b936:      	movq	$0x16, 0x168(%r13)
   4b941:      	movq	$0x0, 0x170(%r13)
   4b94c:      	movq	%rbp, 0x178(%r13)
   4b953:      	movq	%r13, 0x12ae6(%rip)     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b95a:      	leaq	0x95ff(%rip), %rdi      # 0x54f60 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4b961:      	callq	0x122a0 <atexit>
   4b966:      	movq	$0x2, 0x88(%rsp)
   4b972:      	movq	$0x0, 0x90(%rsp)
   4b97e:      	movq	0x12ac3(%rip), %rax     # 0x5e448 <native_roots.0>
   4b985:      	movq	%rax, 0x80(%rsp)
   4b98d:      	movq	0x12a94(%rip), %rax     # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b994:      	incq	%rax
   4b997:      	movq	%rax, 0x12a8a(%rip)     # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b99e:      	movq	0x12a8b(%rip), %rcx     # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b9a5:      	cmpq	%rcx, %rax
   4b9a8:      	cmovbeq	%rcx, %rax
   4b9ac:      	movq	%r14, 0x12a95(%rip)     # 0x5e448 <native_roots.0>
   4b9b3:      	movq	%rax, 0x12a76(%rip)     # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b9ba:      	cmpl	$0x0, 0x12b53(%rip)     # 0x5e514 <g.0>
   4b9c1:      	jne	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4b9c7:      	movl	$0x1, 0x12b43(%rip)     # 0x5e514 <g.0>
   4b9d1:      	movq	$0x0, 0x98(%rsp)
   4b9dd:      	leaq	0x10ad4(%rip), %r15     # 0x5c4b8 <ref.3>
   4b9e4:      	movq	%r15, 0xa0(%rsp)
   4b9ec:      	movq	$0x2, 0x90(%rsp)
   4b9f8:      	movq	0x12a41(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b9ff:      	testq	%rdi, %rdi
   4ba02:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4ba08:      	movq	0x178(%rdi), %rcx
   4ba0f:      	testq	%rcx, %rcx
   4ba12:      	je	0x4ba59 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x859>
   4ba14:      	movq	0x170(%rdi), %rax
   4ba1b:      	incq	%rax
   4ba1e:      	movq	%rax, 0x170(%rdi)
   4ba25:      	movq	%rax, %rdx
   4ba28:      	orq	%rcx, %rdx
   4ba2b:      	shrq	$0x20, %rdx
   4ba2f:      	je	0x4c1cc <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xfcc>
   4ba35:      	xorl	%edx, %edx
   4ba37:      	divq	%rcx
   4ba3a:      	testq	%rdx, %rdx
   4ba3d:      	jne	0x4ba59 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x859>
   4ba3f:      	leaq	0x80(%rsp), %rsi
   4ba47:      	movq	%rdi, %rbx
   4ba4a:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4ba4f:      	movq	%rbx, %rdi
   4ba52:      	movq	0x129ef(%rip), %r14     # 0x5e448 <native_roots.0>
   4ba59:      	movl	$0x18, %esi
   4ba5e:      	movq	%r14, %rdx
   4ba61:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4ba66:      	testq	%rax, %rax
   4ba69:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4ba6f:      	movq	$0x4e, (%rax)
   4ba76:      	movq	%r15, 0x8(%rax)
   4ba7a:      	movq	$0x0, 0x10(%rax)
   4ba82:      	movq	%rax, 0x12a8f(%rip)     # 0x5e518 <g.1>
   4ba89:      	movb	$0x1, 0x12a90(%rip)     # 0x5e520 <g.2>
   4ba90:      	movq	$0x0, 0x90(%rsp)
   4ba9c:      	movq	0x1299d(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4baa3:      	testq	%rdi, %rdi
   4baa6:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4baac:      	movq	0x178(%rdi), %rcx
   4bab3:      	testq	%rcx, %rcx
   4bab6:      	je	0x4baf5 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x8f5>
   4bab8:      	movq	0x170(%rdi), %rax
   4babf:      	incq	%rax
   4bac2:      	movq	%rax, 0x170(%rdi)
   4bac9:      	movq	%rax, %rdx
   4bacc:      	orq	%rcx, %rdx
   4bacf:      	shrq	$0x20, %rdx
   4bad3:      	je	0x4c1de <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xfde>
   4bad9:      	xorl	%edx, %edx
   4badb:      	divq	%rcx
   4bade:      	testq	%rdx, %rdx
   4bae1:      	jne	0x4baf5 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x8f5>
   4bae3:      	movq	0x1295e(%rip), %rsi     # 0x5e448 <native_roots.0>
   4baea:      	movq	%rdi, %rbx
   4baed:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4baf2:      	movq	%rbx, %rdi
   4baf5:      	movq	0x1294c(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bafc:      	movl	$0x8, %esi
   4bb01:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bb06:      	testq	%rax, %rax
   4bb09:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bb0f:      	movq	$0x4a, (%rax)
   4bb16:      	movq	%rax, 0x12a0b(%rip)     # 0x5e528 <g.3>
   4bb1d:      	movb	$0x1, 0x12a0c(%rip)     # 0x5e530 <g.4>
   4bb24:      	movq	$0x0, 0x90(%rsp)
   4bb30:      	movq	0x12909(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bb37:      	testq	%rdi, %rdi
   4bb3a:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bb40:      	movq	0x178(%rdi), %rcx
   4bb47:      	testq	%rcx, %rcx
   4bb4a:      	je	0x4bb89 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x989>
   4bb4c:      	movq	0x170(%rdi), %rax
   4bb53:      	incq	%rax
   4bb56:      	movq	%rax, 0x170(%rdi)
   4bb5d:      	movq	%rax, %rdx
   4bb60:      	orq	%rcx, %rdx
   4bb63:      	shrq	$0x20, %rdx
   4bb67:      	je	0x4c1f0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xff0>
   4bb6d:      	xorl	%edx, %edx
   4bb6f:      	divq	%rcx
   4bb72:      	testq	%rdx, %rdx
   4bb75:      	jne	0x4bb89 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x989>
   4bb77:      	movq	0x128ca(%rip), %rsi     # 0x5e448 <native_roots.0>
   4bb7e:      	movq	%rdi, %rbx
   4bb81:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bb86:      	movq	%rbx, %rdi
   4bb89:      	movq	0x128b8(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bb90:      	movl	$0x8, %esi
   4bb95:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bb9a:      	testq	%rax, %rax
   4bb9d:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bba3:      	movq	$0x46, (%rax)
   4bbaa:      	movq	%rax, 0x12987(%rip)     # 0x5e538 <g.5>
   4bbb1:      	movb	$0x1, 0x12988(%rip)     # 0x5e540 <g.6>
   4bbb8:      	movq	$0x0, 0x90(%rsp)
   4bbc4:      	movq	0x12875(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bbcb:      	testq	%rdi, %rdi
   4bbce:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bbd4:      	movq	0x178(%rdi), %rcx
   4bbdb:      	testq	%rcx, %rcx
   4bbde:      	je	0x4bc1d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xa1d>
   4bbe0:      	movq	0x170(%rdi), %rax
   4bbe7:      	incq	%rax
   4bbea:      	movq	%rax, 0x170(%rdi)
   4bbf1:      	movq	%rax, %rdx
   4bbf4:      	orq	%rcx, %rdx
   4bbf7:      	shrq	$0x20, %rdx
   4bbfb:      	je	0x4c202 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1002>
   4bc01:      	xorl	%edx, %edx
   4bc03:      	divq	%rcx
   4bc06:      	testq	%rdx, %rdx
   4bc09:      	jne	0x4bc1d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xa1d>
   4bc0b:      	movq	0x12836(%rip), %rsi     # 0x5e448 <native_roots.0>
   4bc12:      	movq	%rdi, %rbx
   4bc15:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bc1a:      	movq	%rbx, %rdi
   4bc1d:      	movq	0x12824(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bc24:      	movl	$0x8, %esi
   4bc29:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bc2e:      	testq	%rax, %rax
   4bc31:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bc37:      	movq	$0x42, (%rax)
   4bc3e:      	movq	%rax, 0x12903(%rip)     # 0x5e548 <g.7>
   4bc45:      	movb	$0x1, 0x12904(%rip)     # 0x5e550 <g.8>
   4bc4c:      	movq	$0x0, 0x90(%rsp)
   4bc58:      	movq	$0x4b, 0x228(%rsp)
   4bc64:      	leaq	0x228(%rsp), %rax
   4bc6c:      	movq	0x228(%rsp), %rax
   4bc74:      	movq	%rax, 0x128dd(%rip)     # 0x5e558 <g.9>
   4bc7b:      	movb	$0x1, 0x128de(%rip)     # 0x5e560 <g.10>
   4bc82:      	movq	$0x0, 0x90(%rsp)
   4bc8e:      	movq	0x127ab(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bc95:      	testq	%rdi, %rdi
   4bc98:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bc9e:      	movq	0x178(%rdi), %rcx
   4bca5:      	testq	%rcx, %rcx
   4bca8:      	je	0x4bce7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xae7>
   4bcaa:      	movq	0x170(%rdi), %rax
   4bcb1:      	incq	%rax
   4bcb4:      	movq	%rax, 0x170(%rdi)
   4bcbb:      	movq	%rax, %rdx
   4bcbe:      	orq	%rcx, %rdx
   4bcc1:      	shrq	$0x20, %rdx
   4bcc5:      	je	0x4c214 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1014>
   4bccb:      	xorl	%edx, %edx
   4bccd:      	divq	%rcx
   4bcd0:      	testq	%rdx, %rdx
   4bcd3:      	jne	0x4bce7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xae7>
   4bcd5:      	movq	0x1276c(%rip), %rsi     # 0x5e448 <native_roots.0>
   4bcdc:      	movq	%rdi, %rbx
   4bcdf:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bce4:      	movq	%rbx, %rdi
   4bce7:      	movq	0x1275a(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bcee:      	movl	$0x8, %esi
   4bcf3:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bcf8:      	testq	%rax, %rax
   4bcfb:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bd01:      	movq	$0x42, (%rax)
   4bd08:      	movq	%rax, 0x12859(%rip)     # 0x5e568 <g.11>
   4bd0f:      	movl	$0x2, 0x127fb(%rip)     # 0x5e514 <g.0>
   4bd19:      	cmpq	$0x0, 0x88(%rsp)
   4bd22:      	je	0x4bd3a <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xb3a>
   4bd24:      	movq	0x80(%rsp), %rax
   4bd2c:      	movq	%rax, 0x12715(%rip)     # 0x5e448 <native_roots.0>
   4bd33:      	decq	0x126ee(%rip)           # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4bd3a:      	callq	0x4c920 <<std::sys::pal::unix::time::Timespec>::now>
   4bd3f:      	movq	%rax, %rbx
   4bd42:      	movl	%edx, %ebp
   4bd44:      	movq	$0x5, 0x88(%rsp)
   4bd50:      	movq	$0x0, 0x90(%rsp)
   4bd5c:      	movq	0x126e5(%rip), %rax     # 0x5e448 <native_roots.0>
   4bd63:      	movq	%rax, 0x80(%rsp)
   4bd6b:      	leaq	0x80(%rsp), %rcx
   4bd73:      	movq	%rcx, 0x126ce(%rip)     # 0x5e448 <native_roots.0>
   4bd7a:      	movq	0x126a7(%rip), %rax     # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4bd81:      	incq	%rax
   4bd84:      	movq	%rax, 0x1269d(%rip)     # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4bd8b:      	movq	0x1269e(%rip), %rdx     # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4bd92:      	cmpq	%rdx, %rax
   4bd95:      	cmovbeq	%rdx, %rax
   4bd99:      	movq	%rax, 0x12690(%rip)     # 0x5e430 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4bda0:      	xorpd	%xmm0, %xmm0
   4bda4:      	movupd	%xmm0, 0x98(%rsp)
   4bdad:      	cmpl	$0x2, 0x12760(%rip)     # 0x5e514 <g.0>
   4bdb4:      	jne	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bdba:      	cmpq	$0x0, 0x127a6(%rip)     # 0x5e568 <g.11>
   4bdc2:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bdc8:      	movq	$0x2, 0x90(%rsp)
   4bdd4:      	movq	0x12665(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bddb:      	testq	%rdi, %rdi
   4bdde:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bde4:      	movq	0x178(%rdi), %rsi
   4bdeb:      	testq	%rsi, %rsi
   4bdee:      	je	0x4be35 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xc35>
   4bdf0:      	movq	0x170(%rdi), %rax
   4bdf7:      	incq	%rax
   4bdfa:      	movq	%rax, 0x170(%rdi)
   4be01:      	movq	%rax, %rdx
   4be04:      	orq	%rsi, %rdx
   4be07:      	shrq	$0x20, %rdx
   4be0b:      	je	0x4c226 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1026>
   4be11:      	xorl	%edx, %edx
   4be13:      	divq	%rsi
   4be16:      	testq	%rdx, %rdx
   4be19:      	jne	0x4be35 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xc35>
   4be1b:      	leaq	0x80(%rsp), %rsi
   4be23:      	movq	%rdi, %r14
   4be26:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4be2b:      	movq	%r14, %rdi
   4be2e:      	movq	0x12613(%rip), %rcx     # 0x5e448 <native_roots.0>
   4be35:      	movl	$0x18, %esi
   4be3a:      	movq	%rcx, %rdx
   4be3d:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4be42:      	testq	%rax, %rax
   4be45:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4be4b:      	movq	%rax, %r14
   4be4e:      	movq	$0x1a, (%rax)
   4be55:      	movl	$0x0, 0x8(%rax)
   4be5c:      	movq	$0x0, 0x10(%rax)
   4be64:      	movq	%rax, 0x98(%rsp)
   4be6c:      	movq	%rax, 0xa8(%rsp)
   4be74:      	leaq	0x1062d(%rip), %r13     # 0x5c4a8 <ref.2>
   4be7b:      	movq	%r13, 0xb0(%rsp)
   4be83:      	movq	%rax, 0xb8(%rsp)
   4be8b:      	movq	$0x5, 0x90(%rsp)
   4be97:      	movq	0x125a2(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4be9e:      	testq	%rdi, %rdi
   4bea1:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bea7:      	movq	0x178(%rdi), %rcx
   4beae:      	testq	%rcx, %rcx
   4beb1:      	je	0x4bef0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xcf0>
   4beb3:      	movq	0x170(%rdi), %rax
   4beba:      	incq	%rax
   4bebd:      	movq	%rax, 0x170(%rdi)
   4bec4:      	movq	%rax, %rdx
   4bec7:      	orq	%rcx, %rdx
   4beca:      	shrq	$0x20, %rdx
   4bece:      	je	0x4c238 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1038>
   4bed4:      	xorl	%edx, %edx
   4bed6:      	divq	%rcx
   4bed9:      	testq	%rdx, %rdx
   4bedc:      	jne	0x4bef0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xcf0>
   4bede:      	movq	0x12563(%rip), %rsi     # 0x5e448 <native_roots.0>
   4bee5:      	movq	%rdi, %r15
   4bee8:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4beed:      	movq	%r15, %rdi
   4bef0:      	movq	0x12551(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bef7:      	movl	$0x18, %esi
   4befc:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bf01:      	testq	%rax, %rax
   4bf04:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bf0a:      	movq	%rax, %r15
   4bf0d:      	movq	$0x36, (%rax)
   4bf14:      	movq	$0x3e8, 0x8(%rax)       # imm = 0x3E8
   4bf1c:      	movq	%r14, 0x10(%rax)
   4bf20:      	movq	%rax, 0xa8(%rsp)
   4bf28:      	movq	%r13, 0xb0(%rsp)
   4bf30:      	movq	%r14, 0xb8(%rsp)
   4bf38:      	movq	$0x5, 0x90(%rsp)
   4bf44:      	movq	0x124f5(%rip), %rdi     # 0x5e440 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4bf4b:      	testq	%rdi, %rdi
   4bf4e:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bf54:      	movq	0x178(%rdi), %rcx
   4bf5b:      	testq	%rcx, %rcx
   4bf5e:      	je	0x4bf9d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xd9d>
   4bf60:      	movq	0x170(%rdi), %rax
   4bf67:      	incq	%rax
   4bf6a:      	movq	%rax, 0x170(%rdi)
   4bf71:      	movq	%rax, %rdx
   4bf74:      	orq	%rcx, %rdx
   4bf77:      	shrq	$0x20, %rdx
   4bf7b:      	je	0x4c24a <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x104a>
   4bf81:      	xorl	%edx, %edx
   4bf83:      	divq	%rcx
   4bf86:      	testq	%rdx, %rdx
   4bf89:      	jne	0x4bf9d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xd9d>
   4bf8b:      	movq	0x124b6(%rip), %rsi     # 0x5e448 <native_roots.0>
   4bf92:      	movq	%rdi, %r12
   4bf95:      	callq	0x55fe0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   4bf9a:      	movq	%r12, %rdi
   4bf9d:      	movq	0x124a4(%rip), %rdx     # 0x5e448 <native_roots.0>
   4bfa4:      	movl	$0x18, %esi
   4bfa9:      	callq	0x55e30 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   4bfae:      	testq	%rax, %rax
   4bfb1:      	je	0x4c64c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x144c>
   4bfb7:      	movq	$0x4e, (%rax)
   4bfbe:      	movq	%r13, 0x8(%rax)
   4bfc2:      	movq	%r15, 0x10(%rax)
   4bfc6:      	movq	%rax, 0x10(%r14)
   4bfca:      	movq	0x98(%rsp), %rax
   4bfd2:      	testq	%rax, %rax
   4bfd5:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bfdb:      	movl	$0x1, 0x8(%rax)
   4bfe2:      	movq	0x98(%rsp), %rax
   4bfea:      	testq	%rax, %rax
   4bfed:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bff3:      	cmpl	$0x0, 0x8(%rax)
   4bff7:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4bffd:      	movq	0x10(%rax), %rax
   4c001:      	testq	%rax, %rax
   4c004:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4c00a:      	movq	%rax, 0xa0(%rsp)
   4c012:      	movq	0x8(%rax), %rcx
   4c016:      	testq	%rcx, %rcx
   4c019:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4c01f:      	movq	0x10(%rax), %rdi
   4c023:      	movq	0x8(%rcx), %rax
   4c027:      	cmpq	$0x0, 0x88(%rsp)
   4c030:      	je	0x4c048 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xe48>
   4c032:      	movq	0x80(%rsp), %rcx
   4c03a:      	movq	%rcx, 0x12407(%rip)     # 0x5e448 <native_roots.0>
   4c041:      	decq	0x123e0(%rip)           # 0x5e428 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4c048:      	xorl	%esi, %esi
   4c04a:      	xorl	%edx, %edx
   4c04c:      	callq	*%rax
   4c04e:      	subq	$0x8, %rsp
   4c052:      	movq	%rax, %r14
   4c055:      	movq	%rax, 0x218(%rsp)
   4c05d:      	callq	0x4c920 <<std::sys::pal::unix::time::Timespec>::now>
   4c062:      	movq	%rax, 0x2f8(%rsp)
   4c06a:      	movl	%edx, 0x300(%rsp)
   4c071:      	movq	%rbx, 0x228(%rsp)
   4c079:      	movl	%ebp, 0x230(%rsp)
   4c080:      	leaq	0x80(%rsp), %rdi
   4c088:      	leaq	0x2f8(%rsp), %rbx
   4c090:      	leaq	0x228(%rsp), %rdx
   4c098:      	movq	%rbx, %rsi
   4c09b:      	callq	0x4c9f0 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4c0a0:      	cmpb	$0x0, 0x80(%rsp)
   4c0a8:      	xorpd	%xmm0, %xmm0
   4c0ac:      	jne	0x4c0ea <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xeea>
   4c0ae:      	movsd	0x88(%rsp), %xmm1
   4c0b7:      	unpcklps	-0x4823e(%rip), %xmm1   # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x3e80 <writev+0x3e80>
   4c0be:      	subpd	-0x482a6(%rip), %xmm1   # 0x3e20 <writev+0x3e20>
   4c0c6:      	movapd	%xmm1, %xmm2
   4c0ca:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   4c0ce:      	xorps	%xmm0, %xmm0
   4c0d1:      	cvtsi2sdl	0x90(%rsp), %xmm0
   4c0da:      	addsd	%xmm1, %xmm2
   4c0de:      	divsd	-0x466ee(%rip), %xmm0   # 0x59f8 <writev+0x59f8>
   4c0e6:      	addsd	%xmm2, %xmm0
   4c0ea:      	movsd	%xmm0, 0x220(%rsp)
   4c0f3:      	cmpq	$0x5, %r14
   4c0f7:      	jne	0x4c19c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xf9c>
   4c0fd:      	leaq	0x218(%rsp), %rax
   4c105:      	movq	%rax, 0x228(%rsp)
   4c10d:      	leaq	0x12bc(%rip), %rax      # 0x4d3d0 <<i64 as core::fmt::Display>::fmt>
   4c114:      	movq	%rax, 0x230(%rsp)
   4c11c:      	leaq	0x220(%rsp), %rax
   4c124:      	movq	%rax, 0x238(%rsp)
   4c12c:      	leaq	0x13bd(%rip), %rax      # 0x4d4f0 <<f64 as core::fmt::Display>::fmt>
   4c133:      	movq	%rax, 0x240(%rsp)
   4c13b:      	leaq	-0x427fb(%rip), %rax    # 0x9947 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1353>
   4c142:      	movq	%rax, 0x2f8(%rsp)
   4c14a:      	movq	$0x6, 0x300(%rsp)
   4c156:      	movl	0x1195c(%rip), %eax     # 0x5dab8 <std::io::stdio::STDOUT+0x38>
   4c15c:      	testl	%eax, %eax
   4c15e:      	jne	0x4c3ee <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11ee>
   4c164:      	movq	%fs:-0x8, %r14
   4c16d:      	testq	%r14, %r14
   4c170:      	je	0x4c405 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1205>
   4c176:      	movq	0x11903(%rip), %rax     # 0x5da80 <std::io::stdio::STDOUT>
   4c17d:      	cmpq	%rax, %r14
   4c180:      	jne	0x4c442 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1242>
   4c186:      	movl	0x11900(%rip), %ebp     # 0x5da8c <std::io::stdio::STDOUT+0xc>
   4c18c:      	cmpl	$-0x1, %ebp
   4c18f:      	je	0x4c5a9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x13a9>
   4c195:      	incl	%ebp
   4c197:      	jmp	0x4c45e <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x125e>
   4c19c:      	leaq	0x80(%rsp), %rdi
   4c1a4:      	callq	0x4cac0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4c1a9:      	cmpq	$0x0, 0x80(%rsp)
   4c1b2:      	jle	0x4c1c2 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xfc2>
   4c1b4:      	movq	0x88(%rsp), %rdi
   4c1bc:      	callq	*0x106e6(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c1c2:      	movl	$0x1, %eax
   4c1c7:      	jmp	0x4c592 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1392>
   4c1cc:      	xorl	%edx, %edx
   4c1ce:      	divl	%ecx
   4c1d0:      	testq	%rdx, %rdx
   4c1d3:      	jne	0x4ba59 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x859>
   4c1d9:      	jmp	0x4ba3f <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x83f>
   4c1de:      	xorl	%edx, %edx
   4c1e0:      	divl	%ecx
   4c1e2:      	testq	%rdx, %rdx
   4c1e5:      	jne	0x4baf5 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x8f5>
   4c1eb:      	jmp	0x4bae3 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x8e3>
   4c1f0:      	xorl	%edx, %edx
   4c1f2:      	divl	%ecx
   4c1f4:      	testq	%rdx, %rdx
   4c1f7:      	jne	0x4bb89 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x989>
   4c1fd:      	jmp	0x4bb77 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x977>
   4c202:      	xorl	%edx, %edx
   4c204:      	divl	%ecx
   4c206:      	testq	%rdx, %rdx
   4c209:      	jne	0x4bc1d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xa1d>
   4c20f:      	jmp	0x4bc0b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xa0b>
   4c214:      	xorl	%edx, %edx
   4c216:      	divl	%ecx
   4c218:      	testq	%rdx, %rdx
   4c21b:      	jne	0x4bce7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xae7>
   4c221:      	jmp	0x4bcd5 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xad5>
   4c226:      	xorl	%edx, %edx
   4c228:      	divl	%esi
   4c22a:      	testq	%rdx, %rdx
   4c22d:      	jne	0x4be35 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xc35>
   4c233:      	jmp	0x4be1b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xc1b>
   4c238:      	xorl	%edx, %edx
   4c23a:      	divl	%ecx
   4c23c:      	testq	%rdx, %rdx
   4c23f:      	jne	0x4bef0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xcf0>
   4c245:      	jmp	0x4bede <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xcde>
   4c24a:      	xorl	%edx, %edx
   4c24c:      	divl	%ecx
   4c24e:      	testq	%rdx, %rdx
   4c251:      	jne	0x4bf9d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xd9d>
   4c257:      	jmp	0x4bf8b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xd8b>
   4c25c:      	cmpq	%rcx, %rdx
   4c25f:      	jne	0x4c26d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x106d>
   4c261:      	xorl	%ebp, %ebp
   4c263:      	movq	0x8(%rsp), %r13
   4c268:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c26d:      	movq	%rdx, 0x20(%rsp)
   4c272:      	movq	0x230(%rsp), %rsi
   4c27a:      	movq	0x238(%rsp), %r13
   4c282:      	leaq	0x80(%rsp), %rdi
   4c28a:      	movq	%rsi, 0x30(%rsp)
   4c28f:      	movq	%r13, %rdx
   4c292:      	callq	0x19f10 <core::str::converts::from_utf8>
   4c297:      	cmpb	$0x0, 0x80(%rsp)
   4c29f:      	je	0x4c2be <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x10be>
   4c2a1:      	xorl	%ebp, %ebp
   4c2a3:      	cmpq	$0x0, 0x20(%rsp)
   4c2a9:      	movq	0x8(%rsp), %r13
   4c2ae:      	movq	0x30(%rsp), %rdi
   4c2b3:      	jg	0x4c3c7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11c7>
   4c2b9:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c2be:      	testq	%r13, %r13
   4c2c1:      	je	0x4c2ec <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x10ec>
   4c2c3:      	cmpq	$0x1, %r13
   4c2c7:      	movq	0x30(%rsp), %rdi
   4c2cc:      	jne	0x4c30c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x110c>
   4c2ce:      	movzbl	(%rdi), %eax
   4c2d1:      	xorl	%ebp, %ebp
   4c2d3:      	cmpl	$0x2b, %eax
   4c2d6:      	movq	0x20(%rsp), %r11
   4c2db:      	je	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c2e1:      	cmpl	$0x2d, %eax
   4c2e4:      	je	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c2ea:      	jmp	0x4c314 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1114>
   4c2ec:      	movq	%r13, %rbp
   4c2ef:      	movq	0x30(%rsp), %rdi
   4c2f4:      	movq	0x20(%rsp), %r11
   4c2f9:      	testq	%r11, %r11
   4c2fc:      	movq	0x8(%rsp), %r13
   4c301:      	jne	0x4c3c7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11c7>
   4c307:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c30c:      	movzbl	(%rdi), %eax
   4c30f:      	movq	0x20(%rsp), %r11
   4c314:      	xorl	%ecx, %ecx
   4c316:      	cmpb	$0x2b, %al
   4c318:      	sete	%cl
   4c31b:      	movq	%rcx, %rax
   4c31e:      	negq	%rax
   4c321:      	movq	%r13, %rdx
   4c324:      	subq	%rcx, %rdx
   4c327:      	addq	%rdi, %rcx
   4c32a:      	cmpq	$0x11, %rdx
   4c32e:      	jae	0x4c369 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1169>
   4c330:      	testq	%rdx, %rdx
   4c333:      	je	0x4c3a6 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11a6>
   4c335:      	addq	%rax, %r13
   4c338:      	negq	%r13
   4c33b:      	xorl	%eax, %eax
   4c33d:      	xorl	%ebp, %ebp
   4c33f:      	movzbl	(%rcx,%rax), %edx
   4c343:      	addl	$-0x30, %edx
   4c346:      	cmpl	$0x9, %edx
   4c349:      	ja	0x4c3b7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b7>
   4c34b:      	leaq	(,%rbp,4), %rsi
   4c353:      	addq	%rbp, %rsi
   4c356:      	movl	%edx, %edx
   4c358:      	leaq	(%rdx,%rsi,2), %rbp
   4c35c:      	incq	%rax
   4c35f:      	movq	%r13, %rdx
   4c362:      	addq	%rax, %rdx
   4c365:      	jne	0x4c33f <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x113f>
   4c367:      	jmp	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c369:      	addq	%rax, %r13
   4c36c:      	negq	%r13
   4c36f:      	xorl	%ebp, %ebp
   4c371:      	movl	$0xa, %esi
   4c376:      	xorl	%r9d, %r9d
   4c379:      	xorl	%eax, %eax
   4c37b:      	movq	%r13, %rdx
   4c37e:      	addq	%r9, %rdx
   4c381:      	je	0x4c3d2 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11d2>
   4c383:      	mulq	%rsi
   4c386:      	jo	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c388:      	movzbl	(%rcx,%r9), %r8d
   4c38d:      	addl	$-0x30, %r8d
   4c391:      	addq	%r8, %rax
   4c394:      	setb	%dl
   4c397:      	cmpl	$0x9, %r8d
   4c39b:      	ja	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c39d:      	incq	%r9
   4c3a0:      	testb	%dl, %dl
   4c3a2:      	je	0x4c37b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x117b>
   4c3a4:      	jmp	0x4c3b9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11b9>
   4c3a6:      	xorl	%ebp, %ebp
   4c3a8:      	testq	%r11, %r11
   4c3ab:      	movq	0x8(%rsp), %r13
   4c3b0:      	jne	0x4c3c7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11c7>
   4c3b2:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c3b7:      	xorl	%ebp, %ebp
   4c3b9:      	testq	%r11, %r11
   4c3bc:      	movq	0x8(%rsp), %r13
   4c3c1:      	je	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c3c7:      	callq	*0x104db(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c3cd:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c3d2:      	movq	%rax, %rbp
   4c3d5:      	testq	%r11, %r11
   4c3d8:      	movq	0x8(%rsp), %r13
   4c3dd:      	jne	0x4c3c7 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x11c7>
   4c3df:      	jmp	0x4b859 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x659>
   4c3e4:      	movl	$0x180, %edi            # imm = 0x180
   4c3e9:      	callq	0x134b0 <alloc::alloc::handle_alloc_error>
   4c3ee:      	callq	0x4d522 <<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::get_or_init<std::io::stdio::stdout::{closure#0}>::{closure#0}, !>>
   4c3f3:      	movq	%fs:-0x8, %r14
   4c3fc:      	testq	%r14, %r14
   4c3ff:      	jne	0x4c176 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xf76>
   4c405:      	movq	0x120cc(%rip), %rax     # 0x5e4d8 <<std::thread::id::ThreadId>::new::COUNTER>
   4c40c:      	nopl	(%rax)
   4c410:      	cmpq	$-0x1, %rax
   4c414:      	je	0x4c5a4 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x13a4>
   4c41a:      	leaq	0x1(%rax), %r14
   4c41e:      	lock
   4c41f:      	cmpxchgq	%r14, 0x120b1(%rip)     # 0x5e4d8 <<std::thread::id::ThreadId>::new::COUNTER>
   4c427:      	jne	0x4c410 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1210>
   4c429:      	movq	%r14, %fs:-0x8
   4c432:      	movq	0x11647(%rip), %rax     # 0x5da80 <std::io::stdio::STDOUT>
   4c439:      	cmpq	%rax, %r14
   4c43c:      	je	0x4c186 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0xf86>
   4c442:      	movl	$0x1, %ebp
   4c447:      	xorl	%eax, %eax
   4c449:      	lock
   4c44a:      	cmpxchgl	%ebp, 0x11637(%rip)     # 0x5da88 <std::io::stdio::STDOUT+0x8>
   4c451:      	jne	0x4c5c1 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x13c1>
   4c457:      	movq	%r14, 0x11622(%rip)     # 0x5da80 <std::io::stdio::STDOUT>
   4c45e:      	movl	%ebp, 0x11628(%rip)     # 0x5da8c <std::io::stdio::STDOUT+0xc>
   4c464:      	leaq	0x11615(%rip), %rax     # 0x5da80 <std::io::stdio::STDOUT>
   4c46b:      	movq	%rax, 0x18(%rsp)
   4c470:      	leaq	0x18(%rsp), %r12
   4c475:      	movq	%r12, 0x80(%rsp)
   4c47d:      	leaq	0x88(%rsp), %r14
   4c485:      	movq	$0x0, 0x88(%rsp)
   4c491:      	leaq	0xf450(%rip), %rsi      # 0x5b8e8 <writev+0x5b8e8>
   4c498:      	leaq	-0x469f7(%rip), %rdx    # 0x5aa8 <writev+0x5aa8>
   4c49f:      	leaq	0x80(%rsp), %rdi
   4c4a7:      	leaq	0x228(%rsp), %rcx
   4c4af:      	callq	0x12fb0 <core::fmt::write>
   4c4b4:      	movq	0x88(%rsp), %rcx
   4c4bc:      	testb	%al, %al
   4c4be:      	je	0x4c4e0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x12e0>
   4c4c0:      	movq	%rcx, %r15
   4c4c3:      	testq	%rcx, %rcx
   4c4c6:      	jne	0x4c530 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1330>
   4c4c8:      	leaq	-0x43563(%rip), %rdi    # 0x8f6c <core::num::flt2dec::strategy::dragon::POW5TO256+0x978>
   4c4cf:      	leaq	0xf3ca(%rip), %rdx      # 0x5b8a0 <writev+0x5b8a0>
   4c4d6:      	movl	$0xad, %esi
   4c4db:      	callq	0x134e0 <core::panicking::panic_fmt>
   4c4e0:      	testq	%rcx, %rcx
   4c4e3:      	je	0x4c52d <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x132d>
   4c4e5:      	movl	%ecx, %eax
   4c4e7:      	andl	$0x3, %eax
   4c4ea:      	xorl	%r15d, %r15d
   4c4ed:      	leal	-0x2(%rax), %edx
   4c4f0:      	cmpl	$0x2, %edx
   4c4f3:      	jb	0x4c530 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1330>
   4c4f5:      	testq	%rax, %rax
   4c4f8:      	je	0x4c530 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1330>
   4c4fa:      	leaq	-0x1(%rcx), %r14
   4c4fe:      	movq	-0x1(%rcx), %r15
   4c502:      	movq	0x7(%rcx), %r13
   4c506:      	movq	(%r13), %rax
   4c50a:      	testq	%rax, %rax
   4c50d:      	je	0x4c514 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1314>
   4c50f:      	movq	%r15, %rdi
   4c512:      	callq	*%rax
   4c514:      	cmpq	$0x0, 0x8(%r13)
   4c519:      	je	0x4c524 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1324>
   4c51b:      	movq	%r15, %rdi
   4c51e:      	callq	*0x10384(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c524:      	movq	%r14, %rdi
   4c527:      	callq	*0x1037b(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c52d:      	xorl	%r15d, %r15d
   4c530:      	movq	0x18(%rsp), %rsi
   4c535:      	decl	0xc(%rsi)
   4c538:      	jne	0x4c54f <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x134f>
   4c53a:      	movq	$0x0, (%rsi)
   4c541:      	xorl	%eax, %eax
   4c543:      	xchgl	%eax, 0x8(%rsi)
   4c546:      	cmpl	$0x2, %eax
   4c549:      	je	0x4c5d2 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x13d2>
   4c54f:      	testq	%r15, %r15
   4c552:      	jne	0x4c5f6 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x13f6>
   4c558:      	leaq	0x80(%rsp), %rdi
   4c560:      	callq	0x4cac0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4c565:      	movq	0x80(%rsp), %rbx
   4c56d:      	testq	%rbx, %rbx
   4c570:      	jle	0x4c580 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1380>
   4c572:      	movq	0x88(%rsp), %rdi
   4c57a:      	callq	*0x10328(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c580:      	xorl	%eax, %eax
   4c582:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4c58c:      	cmpq	%rcx, %rbx
   4c58f:      	setne	%al
   4c592:      	addq	$0x3c8, %rsp            # imm = 0x3C8
   4c599:      	popq	%rbx
   4c59a:      	popq	%r12
   4c59c:      	popq	%r13
   4c59e:      	popq	%r14
   4c5a0:      	popq	%r15
   4c5a2:      	popq	%rbp
   4c5a3:      	retq
   4c5a4:      	callq	0x47b50 <<std::thread::id::ThreadId>::new::exhausted>
   4c5a9:      	leaq	-0x42e4c(%rip), %rdi    # 0x9764 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1170>
   4c5b0:      	leaq	0xf7a1(%rip), %rdx      # 0x5bd58 <writev+0x5bd58>
   4c5b7:      	movl	$0x26, %esi
   4c5bc:      	callq	0x4d580 <core::option::expect_failed>
   4c5c1:      	leaq	0x114c0(%rip), %rdi     # 0x5da88 <std::io::stdio::STDOUT+0x8>
   4c5c8:      	callq	0x467e0 <<std::sys::sync::mutex::futex::Mutex>::lock_contended>
   4c5cd:      	jmp	0x4c457 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1257>
   4c5d2:      	addq	$0x8, %rsi
   4c5d6:      	movl	$0xca, %edi
   4c5db:      	movl	$0x81, %edx
   4c5e0:      	movl	$0x1, %ecx
   4c5e5:      	xorl	%eax, %eax
   4c5e7:      	callq	*0x102c3(%rip)          # 0x5c8b0 <writev+0x5c8b0>
   4c5ed:      	testq	%r15, %r15
   4c5f0:      	je	0x4c558 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1358>
   4c5f6:      	movq	%r15, 0x18(%rsp)
   4c5fb:      	movq	%rbx, 0x80(%rsp)
   4c603:      	leaq	-0x3387a(%rip), %rax    # 0x18d90 <<&str as core::fmt::Display>::fmt>
   4c60a:      	movq	%rax, 0x88(%rsp)
   4c612:      	movq	%r12, 0x90(%rsp)
   4c61a:      	leaq	0x153f(%rip), %rax      # 0x4db60 <<std::io::error::Error as core::fmt::Display>::fmt>
   4c621:      	movq	%rax, 0x98(%rsp)
   4c629:      	leaq	-0x45e3d(%rip), %rdi    # 0x67f3 <writev+0x67f3>
   4c630:      	leaq	0xf341(%rip), %rdx      # 0x5b978 <writev+0x5b978>
   4c637:      	leaq	0x80(%rsp), %rsi
   4c63f:      	callq	0x134e0 <core::panicking::panic_fmt>
   4c644:      	movq	%r15, %rdi
   4c647:      	callq	0x134b0 <alloc::alloc::handle_alloc_error>
   4c64c:      	leaq	-0x43837(%rip), %rdi    # 0x8e1c <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   4c653:      	movl	$0x2f, %esi
   4c658:      	callq	0x55910 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   4c65d:      	movl	$0x210, %edi            # imm = 0x210
   4c662:      	callq	0x134b0 <alloc::alloc::handle_alloc_error>
   4c667:      	movl	$0x28, %edi
   4c66c:      	callq	0x134b0 <alloc::alloc::handle_alloc_error>
   4c671:      	movl	$0xb0, %edi
   4c676:      	callq	0x134b0 <alloc::alloc::handle_alloc_error>
   4c67b:      	movq	%r13, 0x8(%rsp)
   4c680:      	movq	%r12, 0x10(%rsp)
   4c685:      	testq	%rbx, %rbx
   4c688:      	jne	0x4c6b0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14b0>
   4c68a:      	cmpq	$0x0, 0x8(%rsp)
   4c690:      	jne	0x4c6f6 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14f6>
   4c692:      	cmpq	$0x0, 0x60(%rsp)
   4c698:      	jne	0x4c709 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1509>
   4c69a:      	cmpq	$0x0, 0x68(%rsp)
   4c6a0:      	jne	0x4c71c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x151c>
   4c6a2:      	testq	%r15, %r15
   4c6a5:      	je	0x4c72c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x152c>
   4c6ab:      	jmp	0x4c749 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1549>
   4c6b0:      	movq	0x38(%rsp), %rax
   4c6b5:      	leaq	0x18(%rax), %r14
   4c6b9:      	movq	0x101a0(%rip), %r13     # 0x5c860 <writev+0x5c860>
   4c6c0:      	movq	0x101e1(%rip), %rbp     # 0x5c8a8 <writev+0x5c8a8>
   4c6c7:      	jmp	0x4c6d9 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14d9>
   4c6c9:      	nopl	(%rax)
   4c6d0:      	addq	$0x38, %r14
   4c6d4:      	decq	%rbx
   4c6d7:      	je	0x4c68a <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x148a>
   4c6d9:      	movq	-0x8(%r14), %rsi
   4c6dd:      	movq	(%r14), %rdi
   4c6e0:      	shlq	$0xf, %rsi
   4c6e4:      	callq	*%r13
   4c6e7:      	cmpq	$0x0, -0x18(%r14)
   4c6ec:      	je	0x4c6d0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14d0>
   4c6ee:      	movq	-0x10(%r14), %rdi
   4c6f2:      	callq	*%rbp
   4c6f4:      	jmp	0x4c6d0 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14d0>
   4c6f6:      	movq	0x38(%rsp), %rdi
   4c6fb:      	callq	*0x101a7(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c701:      	cmpq	$0x0, 0x60(%rsp)
   4c707:      	je	0x4c69a <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x149a>
   4c709:      	movq	0x48(%rsp), %rdi
   4c70e:      	callq	*0x10194(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c714:      	cmpq	$0x0, 0x68(%rsp)
   4c71a:      	je	0x4c6a2 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x14a2>
   4c71c:      	movq	0x50(%rsp), %rdi
   4c721:      	callq	*0x10181(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c727:      	testq	%r15, %r15
   4c72a:      	jne	0x4c749 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1549>
   4c72c:      	cmpq	$0x0, 0x70(%rsp)
   4c732:      	jne	0x4c778 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1578>
   4c734:      	cmpq	$0x0, 0x78(%rsp)
   4c73a:      	jne	0x4c78b <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x158b>
   4c73c:      	cmpq	$0x0, 0x28(%rsp)
   4c742:      	jne	0x4c79e <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x159e>
   4c744:      	callq	0x54910 <native_trap>
   4c749:      	movq	0x40(%rsp), %rax
   4c74e:      	leaq	0x8(%rax), %rbx
   4c752:      	movq	0x1014f(%rip), %r14     # 0x5c8a8 <writev+0x5c8a8>
   4c759:      	jmp	0x4c769 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1569>
   4c75b:      	nopl	(%rax,%rax)
   4c760:      	addq	$0x18, %rbx
   4c764:      	decq	%r15
   4c767:      	je	0x4c72c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x152c>
   4c769:      	cmpq	$0x0, -0x8(%rbx)
   4c76e:      	jle	0x4c760 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1560>
   4c770:      	movq	(%rbx), %rdi
   4c773:      	callq	*%r14
   4c776:      	jmp	0x4c760 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1560>
   4c778:      	movq	0x40(%rsp), %rdi
   4c77d:      	callq	*0x10125(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c783:      	cmpq	$0x0, 0x78(%rsp)
   4c789:      	je	0x4c73c <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x153c>
   4c78b:      	movq	0x58(%rsp), %rdi
   4c790:      	callq	*0x10112(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c796:      	cmpq	$0x0, 0x28(%rsp)
   4c79c:      	je	0x4c744 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1544>
   4c79e:      	movq	0x10(%rsp), %rdi
   4c7a3:      	callq	*0x100ff(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c7a9:      	callq	0x54910 <native_trap>
   4c7ae:      	movq	%rax, %rbx
   4c7b1:      	cmpq	$0x0, 0x8(%r13)
   4c7b6:      	je	0x4c7c1 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x15c1>
   4c7b8:      	movq	%r15, %rdi
   4c7bb:      	callq	*0x100e7(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c7c1:      	movq	%r14, %rdi
   4c7c4:      	callq	*0x100de(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c7ca:      	movq	0x18(%rsp), %rdi
   4c7cf:      	callq	0x4db20 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4c7d4:      	movq	%rbx, %rdi
   4c7d7:      	callq	0x595e0 <_Unwind_Resume@plt>
   4c7dc:      	movq	%rax, %rbx
   4c7df:      	cmpq	$0x0, 0x8(%r13)
   4c7e4:      	je	0x4c7ef <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x15ef>
   4c7e6:      	movq	%rbp, %rdi
   4c7e9:      	callq	*0x100b9(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c7ef:      	movq	0x8(%rsp), %rdi
   4c7f4:      	callq	*0x100ae(%rip)          # 0x5c8a8 <writev+0x5c8a8>
   4c7fa:      	movq	%rbx, %rdi
   4c7fd:      	callq	0x595e0 <_Unwind_Resume@plt>
   4c802:      	movq	%rax, %rbx
   4c805:      	cmpq	$0x0, 0x88(%rsp)
   4c80e:      	je	0x4c818 <wasm_native_e0dae0dbd6b08e415560279f5e60b9be1c28b3ab51bc636ffe5edb7b6cbfc2e8::run::hacb8e65932eaf041+0x1618>
   4c810:      	movq	%r14, %rdi
   4c813:      	callq	0x20f10 <core::ptr::drop_in_place::<std::io::error::Error>>
   4c818:      	movq	0x18(%rsp), %rdi
   4c81d:      	callq	0x4db20 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4c822:      	movq	%rbx, %rdi
   4c825:      	callq	0x595e0 <_Unwind_Resume@plt>
   4c82a:      	callq	0x13f2c <core::panicking::panic_in_cleanup>
   4c82f:      	movq	%rax, %rbx
   4c832:      	leaq	0x18(%rsp), %rdi
   4c837:      	callq	0x20f10 <core::ptr::drop_in_place::<std::io::error::Error>>
   4c83c:      	movq	%rbx, %rdi
   4c83f:      	callq	0x595e0 <_Unwind_Resume@plt>
   4c844:      	callq	0x13f2c <core::panicking::panic_in_cleanup>
   4c849:      	int3
   4c84a:      	int3
   4c84b:      	int3
   4c84c:      	int3
   4c84d:      	int3
   4c84e:      	int3
   4c84f:      	int3
