0000000000012f70 <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff>:
   12f70:      	pushq	%rbp
   12f71:      	pushq	%r14
   12f73:      	pushq	%rbx
   12f74:      	subq	$0x50, %rsp
   12f78:      	callq	*0x60d72(%rip)          # 0x73cf0 <writev+0x73cf0>
   12f7e:      	callq	*0x60d74(%rip)          # 0x73cf8 <writev+0x73cf8>
   12f84:      	callq	*0x60d76(%rip)          # 0x73d00 <writev+0x73d00>
   12f8a:      	callq	0x52a60 <<std::sys::pal::unix::time::Timespec>::now>
   12f8f:      	movq	%rax, %r14
   12f92:      	movl	%edx, %ebp
   12f94:      	movl	$0x5, %edi
   12f99:      	callq	*0x60d69(%rip)          # 0x73d08 <writev+0x73d08>
   12f9f:      	movq	%rax, %rbx
   12fa2:      	movq	%rax, 0x28(%rsp)
   12fa7:      	callq	0x52a60 <<std::sys::pal::unix::time::Timespec>::now>
   12fac:      	movq	%rax, 0x40(%rsp)
   12fb1:      	movl	%edx, 0x48(%rsp)
   12fb5:      	movq	%r14, 0x30(%rsp)
   12fba:      	movl	%ebp, 0x38(%rsp)
   12fbe:      	leaq	0x8(%rsp), %rdi
   12fc3:      	leaq	0x40(%rsp), %rsi
   12fc8:      	leaq	0x30(%rsp), %r14
   12fcd:      	movq	%r14, %rdx
   12fd0:      	callq	0x52990 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   12fd5:      	cmpb	$0x0, 0x8(%rsp)
   12fda:      	xorpd	%xmm0, %xmm0
   12fde:      	jne	0x13016 <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff+0xa6>
   12fe0:      	movsd	0x10(%rsp), %xmm1
   12fe6:      	unpcklps	-0xf0cd(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x3f20 <writev+0x3f20>
   12fed:      	subpd	-0xf125(%rip), %xmm1    # 0x3ed0 <writev+0x3ed0>
   12ff5:      	movapd	%xmm1, %xmm2
   12ff9:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   12ffd:      	xorps	%xmm0, %xmm0
   13000:      	cvtsi2sdl	0x18(%rsp), %xmm0
   13006:      	addsd	%xmm1, %xmm2
   1300a:      	divsd	-0xeec2(%rip), %xmm0    # 0x4150 <writev+0x4150>
   13012:      	addsd	%xmm2, %xmm0
   13016:      	movsd	%xmm0, 0x30(%rsp)
   1301c:      	cmpq	$0x6197ecb, %rbx        # imm = 0x6197ECB
   13023:      	jne	0x13086 <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff+0x116>
   13025:      	leaq	0x28(%rsp), %rax
   1302a:      	movq	%rax, 0x8(%rsp)
   1302f:      	leaq	0x6a4a(%rip), %rax      # 0x19a80 <<i64 as core::fmt::Display>::fmt>
   13036:      	movq	%rax, 0x10(%rsp)
   1303b:      	movq	%r14, 0x18(%rsp)
   13040:      	leaq	0x8919(%rip), %rax      # 0x1b960 <<f64 as core::fmt::Display>::fmt>
   13047:      	movq	%rax, 0x20(%rsp)
   1304c:      	leaq	-0xd437(%rip), %rdi     # 0x5c1c <writev+0x5c1c>
   13053:      	leaq	0x8(%rsp), %rsi
   13058:      	callq	0x578e0 <std::io::stdio::_print>
   1305d:      	leaq	0x8(%rsp), %rdi
   13062:      	callq	0x263a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13067:      	movq	0x8(%rsp), %rbx
   1306c:      	testq	%rbx, %rbx
   1306f:      	jle	0x1307c <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff+0x10c>
   13071:      	movq	0x10(%rsp), %rdi
   13076:      	callq	*0x60c94(%rip)          # 0x73d10 <writev+0x73d10>
   1307c:      	xorl	%eax, %eax
   1307e:      	negq	%rbx
   13081:      	setno	%al
   13084:      	jmp	0x130a8 <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff+0x138>
   13086:      	leaq	0x8(%rsp), %rdi
   1308b:      	callq	0x263a0 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13090:      	cmpq	$0x0, 0x8(%rsp)
   13096:      	jle	0x130a3 <wasm_native_41cdf36bc69fb938b93c98a26f44a9535fb76d440a849cd0b90f158bb0e21639::run::h6d8472516b0238ff+0x133>
   13098:      	movq	0x10(%rsp), %rdi
   1309d:      	callq	*0x60c6d(%rip)          # 0x73d10 <writev+0x73d10>
   130a3:      	movl	$0x1, %eax
   130a8:      	addq	$0x50, %rsp
   130ac:      	popq	%rbx
   130ad:      	popq	%r14
   130af:      	popq	%rbp
   130b0:      	retq
   130b1:      	int3
   130b2:      	int3
   130b3:      	int3
   130b4:      	int3
   130b5:      	int3
   130b6:      	int3
   130b7:      	int3
   130b8:      	int3
   130b9:      	int3
   130ba:      	int3
   130bb:      	int3
   130bc:      	int3
   130bd:      	int3
   130be:      	int3
   130bf:      	int3
