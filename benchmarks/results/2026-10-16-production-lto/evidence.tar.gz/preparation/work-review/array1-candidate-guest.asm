0000000000057ee0 <f.2>:
   57ee0:      	pushq	%rbp
   57ee1:      	pushq	%r15
   57ee3:      	pushq	%r14
   57ee5:      	pushq	%r13
   57ee7:      	pushq	%r12
   57ee9:      	pushq	%rbx
   57eea:      	subq	$0x68, %rsp
   57eee:      	movq	%rdx, %rax
   57ef1:      	movq	%rsi, %rbx
   57ef4:      	movq	$0x7, 0x20(%rsp)
   57efd:      	movq	$0x0, 0x28(%rsp)
   57f06:      	movq	0x6bd3(%rip), %rcx      # 0x5eae0 <native_roots.0>
   57f0d:      	movq	%rcx, 0x18(%rsp)
   57f12:      	leaq	0x18(%rsp), %r9
   57f17:      	movq	0x6ba2(%rip), %rdx      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57f1e:      	leaq	0x1(%rdx), %rsi
   57f22:      	movq	0x6b9f(%rip), %r8       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   57f29:      	cmpq	%r8, %rsi
   57f2c:      	cmovaq	%rsi, %r8
   57f30:      	movq	%r9, 0x6ba9(%rip)       # 0x5eae0 <native_roots.0>
   57f37:      	movq	%rsi, 0x6b82(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   57f3e:      	movq	%r8, 0x6b83(%rip)       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   57f45:      	movq	%rdi, 0x30(%rsp)
   57f4a:      	xorps	%xmm0, %xmm0
   57f4d:      	movups	%xmm0, 0x38(%rsp)
   57f52:      	movq	$0x0, 0x48(%rsp)
   57f5b:      	testq	%rdi, %rdi
   57f5e:      	je	0x58611 <f.2+0x731>
   57f64:      	movl	%edi, %esi
   57f66:      	andl	$0x1, %esi
   57f69:      	jne	0x58611 <f.2+0x731>
   57f6f:      	movq	0x6b62(%rip), %r9       # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   57f76:      	testq	%r9, %r9
   57f79:      	je	0x58611 <f.2+0x731>
   57f7f:      	movq	(%rdi), %rsi
   57f82:      	testq	%rsi, %rsi
   57f85:      	je	0x57fe1 <f.2+0x101>
   57f87:      	cmpq	$0x22, %rsi
   57f8b:      	je	0x57fe1 <f.2+0x101>
   57f8d:      	movq	0x168(%r9), %r8
   57f94:      	shrq	$0x2, %rsi
   57f98:      	leaq	-0x1(%rsi), %r10
   57f9c:      	cmpq	%r8, %r10
   57f9f:      	jae	0x58611 <f.2+0x731>
   57fa5:      	movq	0x160(%r9), %r9
   57fac:      	movq	-0x8(%r9,%rsi,8), %rsi
   57fb1:      	testq	%rsi, %rsi
   57fb4:      	je	0x57fe1 <f.2+0x101>
   57fb6:      	cmpq	$0x22, %rsi
   57fba:      	je	0x57fe1 <f.2+0x101>
   57fbc:      	nopl	(%rax)
   57fc0:      	shrq	$0x2, %rsi
   57fc4:      	leaq	-0x1(%rsi), %r10
   57fc8:      	cmpq	%r8, %r10
   57fcb:      	jae	0x58611 <f.2+0x731>
   57fd1:      	movq	-0x8(%r9,%rsi,8), %rsi
   57fd6:      	cmpq	$0x22, %rsi
   57fda:      	je	0x57fe1 <f.2+0x101>
   57fdc:      	testq	%rsi, %rsi
   57fdf:      	jne	0x57fc0 <f.2+0xe0>
   57fe1:      	cmpq	$0x22, %rsi
   57fe5:      	jne	0x58611 <f.2+0x731>
   57feb:      	leaq	0x4b96(%rip), %rbp      # 0x5cb88 <ref.4>
   57ff2:      	jmp	0x58010 <f.2+0x130>
   57ff4:      	nopw	%cs:(%rax,%rax)
   58000:      	incq	%rbx
   58003:      	subq	%r8, %rdx
   58006:      	cmpq	$0x22, %r9
   5800a:      	jne	0x58611 <f.2+0x731>
   58010:      	cmpq	%rbx, 0x8(%rdi)
   58014:      	jle	0x585f2 <f.2+0x712>
   5801a:      	cmpb	$0x0, 0x6be7(%rip)      # 0x5ec08 <g.12>
   58021:      	je	0x58611 <f.2+0x731>
   58027:      	cmpb	$0x0, 0x6b8a(%rip)      # 0x5ebb8 <g.2>
   5802e:      	je	0x58611 <f.2+0x731>
   58034:      	cmpq	$0x0, 0x6b74(%rip)      # 0x5ebb0 <g.1>
   5803c:      	je	0x58611 <f.2+0x731>
   58042:      	movq	0x6bb7(%rip), %rax      # 0x5ec00 <g.11>
   58049:      	movq	$0x4, 0x28(%rsp)
   58052:      	movq	%rax, 0x10(%rsp)
   58057:      	leaq	0x10(%rsp), %rax
   5805c:      	cmpb	$0x0, 0x6ba5(%rip)      # 0x5ec08 <g.12>
   58063:      	je	0x58611 <f.2+0x731>
   58069:      	cmpb	$0x0, 0x6ba8(%rip)      # 0x5ec18 <g.14>
   58070:      	je	0x58611 <f.2+0x731>
   58076:      	cmpb	$0x0, 0x6b3b(%rip)      # 0x5ebb8 <g.2>
   5807d:      	je	0x58611 <f.2+0x731>
   58083:      	cmpq	$0x0, 0x6b25(%rip)      # 0x5ebb0 <g.1>
   5808b:      	je	0x58611 <f.2+0x731>
   58091:      	movq	0x10(%rsp), %r14
   58096:      	movq	0x6b73(%rip), %rax      # 0x5ec10 <g.13>
   5809d:      	movq	$0x4, 0x28(%rsp)
   580a6:      	movq	%rax, 0x10(%rsp)
   580ab:      	leaq	0x10(%rsp), %rax
   580b0:      	cmpb	$0x0, 0x6b41(%rip)      # 0x5ebf8 <g.10>
   580b7:      	je	0x58611 <f.2+0x731>
   580bd:      	cmpq	$0x0, 0x6b2b(%rip)      # 0x5ebf0 <g.9>
   580c5:      	je	0x58611 <f.2+0x731>
   580cb:      	movq	0x10(%rsp), %r13
   580d0:      	movq	$0x4, 0x28(%rsp)
   580d9:      	movq	0x69f8(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   580e0:      	testq	%rdi, %rdi
   580e3:      	je	0x58611 <f.2+0x731>
   580e9:      	movq	0x178(%rdi), %rcx
   580f0:      	testq	%rcx, %rcx
   580f3:      	je	0x58132 <f.2+0x252>
   580f5:      	movq	0x170(%rdi), %rax
   580fc:      	incq	%rax
   580ff:      	movq	%rax, 0x170(%rdi)
   58106:      	movq	%rax, %rdx
   58109:      	orq	%rcx, %rdx
   5810c:      	shrq	$0x20, %rdx
   58110:      	je	0x585a0 <f.2+0x6c0>
   58116:      	xorl	%edx, %edx
   58118:      	divq	%rcx
   5811b:      	testq	%rdx, %rdx
   5811e:      	jne	0x58132 <f.2+0x252>
   58120:      	movq	0x69b9(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58127:      	movq	%rdi, %r15
   5812a:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   5812f:      	movq	%r15, %rdi
   58132:      	movq	0x69a7(%rip), %rdx      # 0x5eae0 <native_roots.0>
   58139:      	movl	$0x18, %esi
   5813e:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58143:      	testq	%rax, %rax
   58146:      	je	0x58616 <f.2+0x736>
   5814c:      	movq	%rax, %r15
   5814f:      	movq	$0x26, (%rax)
   58156:      	movl	$0x0, 0x8(%rax)
   5815d:      	movq	$0x0, 0x10(%rax)
   58165:      	movq	%rax, 0x38(%rsp)
   5816a:      	movq	%rax, 0x50(%rsp)
   5816f:      	movq	%rbp, 0x58(%rsp)
   58174:      	movq	%rax, 0x60(%rsp)
   58179:      	movq	$0x7, 0x28(%rsp)
   58182:      	movq	0x694f(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58189:      	testq	%rdi, %rdi
   5818c:      	je	0x58611 <f.2+0x731>
   58192:      	movq	0x178(%rdi), %rcx
   58199:      	testq	%rcx, %rcx
   5819c:      	je	0x581db <f.2+0x2fb>
   5819e:      	movq	0x170(%rdi), %rax
   581a5:      	incq	%rax
   581a8:      	movq	%rax, 0x170(%rdi)
   581af:      	movq	%rax, %rdx
   581b2:      	orq	%rcx, %rdx
   581b5:      	shrq	$0x20, %rdx
   581b9:      	je	0x585c0 <f.2+0x6e0>
   581bf:      	xorl	%edx, %edx
   581c1:      	divq	%rcx
   581c4:      	testq	%rdx, %rdx
   581c7:      	jne	0x581db <f.2+0x2fb>
   581c9:      	movq	0x6910(%rip), %rsi      # 0x5eae0 <native_roots.0>
   581d0:      	movq	%rdi, %r12
   581d3:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   581d8:      	movq	%r12, %rdi
   581db:      	movq	0x68fe(%rip), %rdx      # 0x5eae0 <native_roots.0>
   581e2:      	movl	$0x18, %esi
   581e7:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   581ec:      	testq	%rax, %rax
   581ef:      	je	0x58616 <f.2+0x736>
   581f5:      	movq	%rax, %r12
   581f8:      	movq	$0x1e, (%rax)
   581ff:      	movq	%r13, 0x8(%rax)
   58203:      	movq	%r15, 0x10(%rax)
   58207:      	movq	%rax, 0x50(%rsp)
   5820c:      	movq	%rbp, 0x58(%rsp)
   58211:      	movq	%r15, 0x60(%rsp)
   58216:      	movq	$0x7, 0x28(%rsp)
   5821f:      	movq	0x68b2(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58226:      	testq	%rdi, %rdi
   58229:      	je	0x58611 <f.2+0x731>
   5822f:      	movq	0x178(%rdi), %rcx
   58236:      	testq	%rcx, %rcx
   58239:      	je	0x58278 <f.2+0x398>
   5823b:      	movq	0x170(%rdi), %rax
   58242:      	incq	%rax
   58245:      	movq	%rax, 0x170(%rdi)
   5824c:      	movq	%rax, %rdx
   5824f:      	orq	%rcx, %rdx
   58252:      	shrq	$0x20, %rdx
   58256:      	je	0x585e0 <f.2+0x700>
   5825c:      	xorl	%edx, %edx
   5825e:      	divq	%rcx
   58261:      	testq	%rdx, %rdx
   58264:      	jne	0x58278 <f.2+0x398>
   58266:      	movq	0x6873(%rip), %rsi      # 0x5eae0 <native_roots.0>
   5826d:      	movq	%rdi, %r13
   58270:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58275:      	movq	%r13, %rdi
   58278:      	movq	0x6861(%rip), %rdx      # 0x5eae0 <native_roots.0>
   5827f:      	movl	$0x18, %esi
   58284:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58289:      	testq	%rax, %rax
   5828c:      	je	0x58616 <f.2+0x736>
   58292:      	movq	$0x3a, (%rax)
   58299:      	movq	%rbp, 0x8(%rax)
   5829d:      	movq	%r12, 0x10(%rax)
   582a1:      	movq	%rax, 0x10(%r15)
   582a5:      	movq	0x38(%rsp), %rax
   582aa:      	testq	%rax, %rax
   582ad:      	je	0x58611 <f.2+0x731>
   582b3:      	movl	$0x1, 0x8(%rax)
   582ba:      	movq	0x38(%rsp), %rax
   582bf:      	testq	%rax, %rax
   582c2:      	je	0x58611 <f.2+0x731>
   582c8:      	cmpl	$0x0, 0x8(%rax)
   582cc:      	je	0x58611 <f.2+0x731>
   582d2:      	movq	0x10(%rax), %rax
   582d6:      	testq	%rax, %rax
   582d9:      	je	0x58611 <f.2+0x731>
   582df:      	movq	%rax, 0x40(%rsp)
   582e4:      	movq	0x8(%rax), %rcx
   582e8:      	testq	%rcx, %rcx
   582eb:      	je	0x58611 <f.2+0x731>
   582f1:      	movq	0x10(%rax), %rdi
   582f5:      	movq	0x8(%rcx), %rax
   582f9:      	movq	%rdi, 0x50(%rsp)
   582fe:      	movq	$0x5, 0x28(%rsp)
   58307:      	movq	%r14, %rsi
   5830a:      	xorl	%edx, %edx
   5830c:      	callq	*%rax
   5830e:      	subq	$0x8, %rsp
   58312:      	movq	0x30(%rsp), %rdi
   58317:      	testq	%rdi, %rdi
   5831a:      	je	0x58611 <f.2+0x731>
   58320:      	movl	%edi, %ecx
   58322:      	andl	$0x1, %ecx
   58325:      	jne	0x58611 <f.2+0x731>
   5832b:      	movq	0x67a6(%rip), %rsi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58332:      	testq	%rsi, %rsi
   58335:      	je	0x58611 <f.2+0x731>
   5833b:      	movq	(%rdi), %rdx
   5833e:      	cmpq	$0x22, %rdx
   58342:      	sete	%cl
   58345:      	movl	%ecx, %r11d
   58348:      	testq	%rdx, %rdx
   5834b:      	je	0x583a0 <f.2+0x4c0>
   5834d:      	movl	%ecx, %r11d
   58350:      	cmpq	$0x22, %rdx
   58354:      	je	0x583a0 <f.2+0x4c0>
   58356:      	movq	0x168(%rsi), %r8
   5835d:      	movq	%rdx, %r9
   58360:      	shrq	$0x2, %r9
   58364:      	leaq	-0x1(%r9), %r10
   58368:      	cmpq	%r8, %r10
   5836b:      	jae	0x58611 <f.2+0x731>
   58371:      	movq	0x160(%rsi), %r10
   58378:      	movq	-0x8(%r10,%r9,8), %r9
   5837d:      	cmpq	$0x22, %r9
   58381:      	sete	%r11b
   58385:      	testq	%r9, %r9
   58388:      	je	0x583a0 <f.2+0x4c0>
   5838a:      	cmpq	$0x22, %r9
   5838e:      	jne	0x58540 <f.2+0x660>
   58394:      	nopw	%cs:(%rax,%rax)
   583a0:      	testb	%r11b, %r11b
   583a3:      	je	0x58611 <f.2+0x731>
   583a9:      	movq	0x10(%rdi), %r8
   583ad:      	testq	%r8, %r8
   583b0:      	je	0x58611 <f.2+0x731>
   583b6:      	cmpl	$0x0, 0x8(%r8)
   583bb:      	je	0x58611 <f.2+0x731>
   583c1:      	testq	%rdx, %rdx
   583c4:      	je	0x58410 <f.2+0x530>
   583c6:      	cmpq	$0x22, %rdx
   583ca:      	je	0x58410 <f.2+0x530>
   583cc:      	movq	0x168(%rsi), %r8
   583d3:      	shrq	$0x2, %rdx
   583d7:      	leaq	-0x1(%rdx), %rcx
   583db:      	cmpq	%r8, %rcx
   583de:      	jae	0x58611 <f.2+0x731>
   583e4:      	movq	0x160(%rsi), %r9
   583eb:      	movq	-0x8(%r9,%rdx,8), %rdx
   583f0:      	cmpq	$0x22, %rdx
   583f4:      	sete	%cl
   583f7:      	testq	%rdx, %rdx
   583fa:      	je	0x58410 <f.2+0x530>
   583fc:      	cmpq	$0x22, %rdx
   58400:      	jne	0x58570 <f.2+0x690>
   58406:      	nopw	%cs:(%rax,%rax)
   58410:      	testb	%cl, %cl
   58412:      	je	0x58611 <f.2+0x731>
   58418:      	movq	%rdi, 0x48(%rsp)
   5841d:      	movq	0x10(%rdi), %rcx
   58421:      	testq	%rcx, %rcx
   58424:      	je	0x58611 <f.2+0x731>
   5842a:      	cmpq	$0x0, 0x10(%rcx)
   5842f:      	je	0x58611 <f.2+0x731>
   58435:      	xorl	%r8d, %r8d
   58438:      	cmpq	$0x0, 0x20(%rsp)
   5843e:      	setne	%r8b
   58442:      	leaq	0x6697(%rip), %rcx      # 0x5eae0 <native_roots.0>
   58449:      	leaq	0x18(%rsp), %r9
   5844e:      	cmovneq	%r9, %rcx
   58452:      	movq	0x6667(%rip), %rdx      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58459:      	movq	(%rcx), %rcx
   5845c:      	movq	$0x7, 0x20(%rsp)
   58465:      	movq	$0x0, 0x28(%rsp)
   5846e:      	movq	%rcx, 0x18(%rsp)
   58473:      	movq	%r9, 0x6666(%rip)       # 0x5eae0 <native_roots.0>
   5847a:      	movq	%r8, %r9
   5847d:      	negq	%r9
   58480:      	addq	%rdx, %r9
   58483:      	incq	%r9
   58486:      	movq	%r9, 0x6633(%rip)       # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5848d:      	movq	0x6634(%rip), %r10      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58494:      	cmpq	%r10, %r9
   58497:      	cmovaq	%r9, %r10
   5849b:      	movq	%r10, 0x6626(%rip)      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   584a2:      	leaq	0x38(%rsp), %r9
   584a7:      	xorps	%xmm0, %xmm0
   584aa:      	movups	%xmm0, (%r9)
   584ae:      	movq	$0x0, 0x10(%r9)
   584b6:      	movq	(%rdi), %r9
   584b9:      	testq	%r9, %r9
   584bc:      	je	0x58000 <f.2+0x120>
   584c2:      	cmpq	$0x22, %r9
   584c6:      	je	0x58000 <f.2+0x120>
   584cc:      	movq	0x168(%rsi), %r10
   584d3:      	shrq	$0x2, %r9
   584d7:      	leaq	-0x1(%r9), %r11
   584db:      	cmpq	%r10, %r11
   584de:      	jae	0x58611 <f.2+0x731>
   584e4:      	movq	0x160(%rsi), %rsi
   584eb:      	movq	-0x8(%rsi,%r9,8), %r9
   584f0:      	testq	%r9, %r9
   584f3:      	je	0x58000 <f.2+0x120>
   584f9:      	cmpq	$0x22, %r9
   584fd:      	je	0x58000 <f.2+0x120>
   58503:      	nopw	%cs:(%rax,%rax)
   58510:      	shrq	$0x2, %r9
   58514:      	leaq	-0x1(%r9), %r11
   58518:      	cmpq	%r10, %r11
   5851b:      	jae	0x58611 <f.2+0x731>
   58521:      	movq	-0x8(%rsi,%r9,8), %r9
   58526:      	cmpq	$0x22, %r9
   5852a:      	je	0x58000 <f.2+0x120>
   58530:      	testq	%r9, %r9
   58533:      	jne	0x58510 <f.2+0x630>
   58535:      	jmp	0x58000 <f.2+0x120>
   5853a:      	nopw	(%rax,%rax)
   58540:      	shrq	$0x2, %r9
   58544:      	leaq	-0x1(%r9), %r11
   58548:      	cmpq	%r8, %r11
   5854b:      	jae	0x58611 <f.2+0x731>
   58551:      	movq	-0x8(%r10,%r9,8), %r9
   58556:      	cmpq	$0x22, %r9
   5855a:      	je	0x58561 <f.2+0x681>
   5855c:      	testq	%r9, %r9
   5855f:      	jne	0x58540 <f.2+0x660>
   58561:      	cmpq	$0x22, %r9
   58565:      	je	0x583a9 <f.2+0x4c9>
   5856b:      	jmp	0x58611 <f.2+0x731>
   58570:      	shrq	$0x2, %rdx
   58574:      	leaq	-0x1(%rdx), %rcx
   58578:      	cmpq	%r8, %rcx
   5857b:      	jae	0x58611 <f.2+0x731>
   58581:      	movq	-0x8(%r9,%rdx,8), %rdx
   58586:      	cmpq	$0x22, %rdx
   5858a:      	je	0x58591 <f.2+0x6b1>
   5858c:      	testq	%rdx, %rdx
   5858f:      	jne	0x58570 <f.2+0x690>
   58591:      	cmpq	$0x22, %rdx
   58595:      	je	0x58418 <f.2+0x538>
   5859b:      	jmp	0x58611 <f.2+0x731>
   5859d:      	nopl	(%rax)
   585a0:      	xorl	%edx, %edx
   585a2:      	divl	%ecx
   585a4:      	testq	%rdx, %rdx
   585a7:      	jne	0x58132 <f.2+0x252>
   585ad:      	jmp	0x58120 <f.2+0x240>
   585b2:      	nopw	%cs:(%rax,%rax)
   585c0:      	xorl	%edx, %edx
   585c2:      	divl	%ecx
   585c4:      	testq	%rdx, %rdx
   585c7:      	jne	0x581db <f.2+0x2fb>
   585cd:      	jmp	0x581c9 <f.2+0x2e9>
   585d2:      	nopw	%cs:(%rax,%rax)
   585e0:      	xorl	%edx, %edx
   585e2:      	divl	%ecx
   585e4:      	testq	%rdx, %rdx
   585e7:      	jne	0x58278 <f.2+0x398>
   585ed:      	jmp	0x58266 <f.2+0x386>
   585f2:      	movq	%rcx, 0x64e7(%rip)      # 0x5eae0 <native_roots.0>
   585f9:      	movq	%rdx, 0x64c0(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58600:      	addq	$0x68, %rsp
   58604:      	popq	%rbx
   58605:      	popq	%r12
   58607:      	popq	%r13
   58609:      	popq	%r14
   5860b:      	popq	%r15
   5860d:      	popq	%rbp
   5860e:      	retq	$0x8
   58611:      	callq	0x54a00 <native_trap>
   58616:      	leaq	-0x4f851(%rip), %rdi    # 0x8dcc <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   5861d:      	movl	$0x2f, %esi
   58622:      	callq	0x55a00 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   58627:      	int3
   58628:      	int3
   58629:      	int3
   5862a:      	int3
   5862b:      	int3
   5862c:      	int3
   5862d:      	int3
   5862e:      	int3
   5862f:      	int3

0000000000058630 <f.4>:
   58630:      	pushq	%rbp
   58631:      	pushq	%r15
   58633:      	pushq	%r14
   58635:      	pushq	%r13
   58637:      	pushq	%r12
   58639:      	pushq	%rbx
   5863a:      	subq	$0x78, %rsp
   5863e:      	movq	%rsi, %r14
   58641:      	movq	$0xa, 0x10(%rsp)
   5864a:      	movq	$0x0, 0x18(%rsp)
   58653:      	movq	0x6486(%rip), %rsi      # 0x5eae0 <native_roots.0>
   5865a:      	movq	%rsi, 0x8(%rsp)
   5865f:      	leaq	0x8(%rsp), %rbx
   58664:      	movq	0x6455(%rip), %rax      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5866b:      	leaq	0x1(%rax), %rcx
   5866f:      	movq	0x6452(%rip), %r8       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58676:      	cmpq	%r8, %rcx
   58679:      	cmovaq	%rcx, %r8
   5867d:      	movq	%rbx, 0x645c(%rip)      # 0x5eae0 <native_roots.0>
   58684:      	movq	%rcx, 0x6435(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5868b:      	movq	%r8, 0x6436(%rip)       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58692:      	movq	%rdi, 0x20(%rsp)
   58697:      	xorps	%xmm0, %xmm0
   5869a:      	movups	%xmm0, 0x28(%rsp)
   5869f:      	movups	%xmm0, 0x38(%rsp)
   586a4:      	testq	%r14, %r14
   586a7:      	jle	0x59070 <f.4+0xa40>
   586ad:      	testq	%rdi, %rdi
   586b0:      	sete	%al
   586b3:      	movl	%edi, %ecx
   586b5:      	orb	%al, %cl
   586b7:      	testb	$0x1, %cl
   586ba:      	jne	0x58722 <f.4+0xf2>
   586bc:      	movq	0x6415(%rip), %rdx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   586c3:      	testq	%rdx, %rdx
   586c6:      	je	0x58fe5 <f.4+0x9b5>
   586cc:      	movq	(%rdi), %rax
   586cf:      	testq	%rax, %rax
   586d2:      	je	0x58726 <f.4+0xf6>
   586d4:      	cmpq	$0x1e, %rax
   586d8:      	je	0x58726 <f.4+0xf6>
   586da:      	movq	0x168(%rdx), %rcx
   586e1:      	shrq	$0x2, %rax
   586e5:      	leaq	-0x1(%rax), %rsi
   586e9:      	cmpq	%rcx, %rsi
   586ec:      	jae	0x58fe5 <f.4+0x9b5>
   586f2:      	movq	0x160(%rdx), %rdx
   586f9:      	nopl	(%rax)
   58700:      	movq	-0x8(%rdx,%rax,8), %rax
   58705:      	testq	%rax, %rax
   58708:      	je	0x58726 <f.4+0xf6>
   5870a:      	cmpq	$0x1e, %rax
   5870e:      	je	0x58726 <f.4+0xf6>
   58710:      	shrq	$0x2, %rax
   58714:      	leaq	-0x1(%rax), %rsi
   58718:      	cmpq	%rcx, %rsi
   5871b:      	jb	0x58700 <f.4+0xd0>
   5871d:      	jmp	0x58fe5 <f.4+0x9b5>
   58722:      	xorl	%eax, %eax
   58724:      	jmp	0x5872d <f.4+0xfd>
   58726:      	cmpq	$0x1e, %rax
   5872a:      	sete	%al
   5872d:      	testb	$0x1, %al
   5872f:      	je	0x58fe5 <f.4+0x9b5>
   58735:      	testq	%rdi, %rdi
   58738:      	je	0x58fe5 <f.4+0x9b5>
   5873e:      	cmpb	$0x0, 0x64a3(%rip)      # 0x5ebe8 <g.8>
   58745:      	je	0x58fe5 <f.4+0x9b5>
   5874b:      	cmpq	$0x0, 0x648d(%rip)      # 0x5ebe0 <g.7>
   58753:      	je	0x58fe5 <f.4+0x9b5>
   58759:      	cmpb	$0x0, 0x6468(%rip)      # 0x5ebc8 <g.4>
   58760:      	je	0x58fe5 <f.4+0x9b5>
   58766:      	cmpq	$0x0, 0x6452(%rip)      # 0x5ebc0 <g.3>
   5876e:      	je	0x58fe5 <f.4+0x9b5>
   58774:      	movq	0x8(%rdi), %r12
   58778:      	movq	%r12, %rax
   5877b:      	shrq	$0x20, %rax
   5877f:      	jne	0x58fe5 <f.4+0x9b5>
   58785:      	movq	$0x5, 0x18(%rsp)
   5878e:      	movq	0x6343(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58795:      	testq	%rdi, %rdi
   58798:      	je	0x58fe5 <f.4+0x9b5>
   5879e:      	movq	0x178(%rdi), %rcx
   587a5:      	movq	%rbx, %rdx
   587a8:      	testq	%rcx, %rcx
   587ab:      	je	0x587f3 <f.4+0x1c3>
   587ad:      	movq	0x170(%rdi), %rax
   587b4:      	incq	%rax
   587b7:      	movq	%rax, 0x170(%rdi)
   587be:      	movq	%rax, %rdx
   587c1:      	orq	%rcx, %rdx
   587c4:      	shrq	$0x20, %rdx
   587c8:      	je	0x58fea <f.4+0x9ba>
   587ce:      	xorl	%edx, %edx
   587d0:      	divq	%rcx
   587d3:      	movq	%rdx, %rax
   587d6:      	movq	%rbx, %rdx
   587d9:      	testq	%rax, %rax
   587dc:      	jne	0x587f3 <f.4+0x1c3>
   587de:      	movq	%rdi, %r15
   587e1:      	movq	%rbx, %rsi
   587e4:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   587e9:      	movq	%r15, %rdi
   587ec:      	movq	0x62ed(%rip), %rdx      # 0x5eae0 <native_roots.0>
   587f3:      	movl	$0x18, %esi
   587f8:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   587fd:      	testq	%rax, %rax
   58800:      	je	0x59092 <f.4+0xa62>
   58806:      	movq	%rax, %r15
   58809:      	movq	$0x1a, (%rax)
   58810:      	movl	$0x0, 0x8(%rax)
   58817:      	movq	$0x0, 0x10(%rax)
   5881f:      	movq	%rax, 0x28(%rsp)
   58824:      	leaq	0x439d(%rip), %rbx      # 0x5cbc8 <ref.8>
   5882b:      	movq	%rbx, 0x48(%rsp)
   58830:      	movq	%rax, 0x50(%rsp)
   58835:      	movq	$0x7, 0x18(%rsp)
   5883e:      	movl	%r12d, %edi
   58841:      	callq	0x57e20 <native_array_new>
   58846:      	movq	%rax, 0x48(%rsp)
   5884b:      	movq	%rbx, 0x50(%rsp)
   58850:      	movq	%r15, 0x58(%rsp)
   58855:      	movq	$0x8, 0x18(%rsp)
   5885e:      	movq	0x6273(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58865:      	testq	%rdi, %rdi
   58868:      	je	0x58fe5 <f.4+0x9b5>
   5886e:      	movq	%rax, %rbp
   58871:      	movq	0x178(%rdi), %rcx
   58878:      	testq	%rcx, %rcx
   5887b:      	je	0x588ba <f.4+0x28a>
   5887d:      	movq	0x170(%rdi), %rax
   58884:      	incq	%rax
   58887:      	movq	%rax, 0x170(%rdi)
   5888e:      	movq	%rax, %rdx
   58891:      	orq	%rcx, %rdx
   58894:      	shrq	$0x20, %rdx
   58898:      	je	0x59001 <f.4+0x9d1>
   5889e:      	xorl	%edx, %edx
   588a0:      	divq	%rcx
   588a3:      	testq	%rdx, %rdx
   588a6:      	jne	0x588ba <f.4+0x28a>
   588a8:      	movq	0x6231(%rip), %rsi      # 0x5eae0 <native_roots.0>
   588af:      	movq	%rdi, %r13
   588b2:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   588b7:      	movq	%r13, %rdi
   588ba:      	movq	0x621f(%rip), %rdx      # 0x5eae0 <native_roots.0>
   588c1:      	movl	$0x10, %esi
   588c6:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   588cb:      	testq	%rax, %rax
   588ce:      	je	0x59092 <f.4+0xa62>
   588d4:      	movq	%rax, %r13
   588d7:      	movq	$0x12, (%rax)
   588de:      	movq	%rbp, 0x8(%rax)
   588e2:      	movq	0x28(%rsp), %rbx
   588e7:      	movq	%rbx, 0x48(%rsp)
   588ec:      	movq	%rax, 0x50(%rsp)
   588f1:      	leaq	0x42d0(%rip), %rax      # 0x5cbc8 <ref.8>
   588f8:      	movq	%rax, 0x58(%rsp)
   588fd:      	movq	%r15, 0x60(%rsp)
   58902:      	movq	$0x9, 0x18(%rsp)
   5890b:      	movq	0x61c6(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58912:      	testq	%rdi, %rdi
   58915:      	je	0x58fe5 <f.4+0x9b5>
   5891b:      	movq	0x178(%rdi), %rcx
   58922:      	testq	%rcx, %rcx
   58925:      	je	0x58964 <f.4+0x334>
   58927:      	movq	0x170(%rdi), %rax
   5892e:      	incq	%rax
   58931:      	movq	%rax, 0x170(%rdi)
   58938:      	movq	%rax, %rdx
   5893b:      	orq	%rcx, %rdx
   5893e:      	shrq	$0x20, %rdx
   58942:      	je	0x59013 <f.4+0x9e3>
   58948:      	xorl	%edx, %edx
   5894a:      	divq	%rcx
   5894d:      	testq	%rdx, %rdx
   58950:      	jne	0x58964 <f.4+0x334>
   58952:      	movq	0x6187(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58959:      	movq	%rdi, %rbp
   5895c:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58961:      	movq	%rbp, %rdi
   58964:      	movq	0x6175(%rip), %rdx      # 0x5eae0 <native_roots.0>
   5896b:      	movl	$0x20, %esi
   58970:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58975:      	testq	%rax, %rax
   58978:      	je	0x59092 <f.4+0xa62>
   5897e:      	movq	%rax, %rbp
   58981:      	movq	$0xe, (%rax)
   58988:      	movq	%r12, 0x8(%rax)
   5898c:      	movq	%r13, 0x10(%rax)
   58990:      	movq	%rbx, 0x18(%rax)
   58994:      	movq	%rax, 0x48(%rsp)
   58999:      	leaq	0x4228(%rip), %rax      # 0x5cbc8 <ref.8>
   589a0:      	movq	%rax, 0x50(%rsp)
   589a5:      	movq	%r15, 0x58(%rsp)
   589aa:      	movq	$0x8, 0x18(%rsp)
   589b3:      	movq	0x611e(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   589ba:      	testq	%rdi, %rdi
   589bd:      	je	0x58fe5 <f.4+0x9b5>
   589c3:      	movq	0x178(%rdi), %rcx
   589ca:      	testq	%rcx, %rcx
   589cd:      	je	0x58a0c <f.4+0x3dc>
   589cf:      	movq	0x170(%rdi), %rax
   589d6:      	incq	%rax
   589d9:      	movq	%rax, 0x170(%rdi)
   589e0:      	movq	%rax, %rdx
   589e3:      	orq	%rcx, %rdx
   589e6:      	shrq	$0x20, %rdx
   589ea:      	je	0x59025 <f.4+0x9f5>
   589f0:      	xorl	%edx, %edx
   589f2:      	divq	%rcx
   589f5:      	testq	%rdx, %rdx
   589f8:      	jne	0x58a0c <f.4+0x3dc>
   589fa:      	movq	0x60df(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58a01:      	movq	%rdi, %r12
   58a04:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58a09:      	movq	%r12, %rdi
   58a0c:      	movq	0x60cd(%rip), %rdx      # 0x5eae0 <native_roots.0>
   58a13:      	movl	$0x18, %esi
   58a18:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58a1d:      	testq	%rax, %rax
   58a20:      	je	0x59092 <f.4+0xa62>
   58a26:      	movq	$0x36, (%rax)
   58a2d:      	leaq	0x4194(%rip), %rcx      # 0x5cbc8 <ref.8>
   58a34:      	movq	%rcx, 0x8(%rax)
   58a38:      	movq	%rbp, 0x10(%rax)
   58a3c:      	movq	%rax, 0x10(%r15)
   58a40:      	movq	0x28(%rsp), %rax
   58a45:      	testq	%rax, %rax
   58a48:      	je	0x58fe5 <f.4+0x9b5>
   58a4e:      	movl	$0x1, 0x8(%rax)
   58a55:      	movq	0x28(%rsp), %rax
   58a5a:      	testq	%rax, %rax
   58a5d:      	je	0x58fe5 <f.4+0x9b5>
   58a63:      	cmpl	$0x0, 0x8(%rax)
   58a67:      	je	0x58fe5 <f.4+0x9b5>
   58a6d:      	movq	0x10(%rax), %rax
   58a71:      	testq	%rax, %rax
   58a74:      	je	0x58fe5 <f.4+0x9b5>
   58a7a:      	movq	%rax, 0x30(%rsp)
   58a7f:      	movq	0x8(%rax), %rcx
   58a83:      	testq	%rcx, %rcx
   58a86:      	je	0x58fe5 <f.4+0x9b5>
   58a8c:      	movq	0x10(%rax), %rdi
   58a90:      	movq	0x8(%rcx), %rax
   58a94:      	movq	%rdi, 0x48(%rsp)
   58a99:      	movq	$0x6, 0x18(%rsp)
   58aa2:      	xorl	%esi, %esi
   58aa4:      	callq	*%rax
   58aa6:      	subq	$0x8, %rsp
   58aaa:      	movq	%rax, 0x38(%rsp)
   58aaf:      	cmpb	$0x0, 0x6122(%rip)      # 0x5ebd8 <g.6>
   58ab6:      	je	0x58fe5 <f.4+0x9b5>
   58abc:      	cmpq	$0x0, 0x610c(%rip)      # 0x5ebd0 <g.5>
   58ac4:      	je	0x58fe5 <f.4+0x9b5>
   58aca:      	testq	%rax, %rax
   58acd:      	je	0x58fe5 <f.4+0x9b5>
   58ad3:      	testb	$0x1, %al
   58ad5:      	jne	0x58fe5 <f.4+0x9b5>
   58adb:      	movl	0x8(%rax), %ebx
   58ade:      	movq	$0x5, 0x18(%rsp)
   58ae7:      	movq	0x5fea(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58aee:      	testq	%rdi, %rdi
   58af1:      	je	0x58fe5 <f.4+0x9b5>
   58af7:      	movq	0x178(%rdi), %rcx
   58afe:      	testq	%rcx, %rcx
   58b01:      	je	0x58b40 <f.4+0x510>
   58b03:      	movq	0x170(%rdi), %rax
   58b0a:      	incq	%rax
   58b0d:      	movq	%rax, 0x170(%rdi)
   58b14:      	movq	%rax, %rdx
   58b17:      	orq	%rcx, %rdx
   58b1a:      	shrq	$0x20, %rdx
   58b1e:      	je	0x59037 <f.4+0xa07>
   58b24:      	xorl	%edx, %edx
   58b26:      	divq	%rcx
   58b29:      	testq	%rdx, %rdx
   58b2c:      	jne	0x58b40 <f.4+0x510>
   58b2e:      	movq	0x5fab(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58b35:      	movq	%rdi, %r12
   58b38:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58b3d:      	movq	%r12, %rdi
   58b40:      	movq	%r14, %r15
   58b43:      	movq	0x5f96(%rip), %rdx      # 0x5eae0 <native_roots.0>
   58b4a:      	movl	$0x18, %esi
   58b4f:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58b54:      	testq	%rax, %rax
   58b57:      	je	0x59092 <f.4+0xa62>
   58b5d:      	movq	%rax, %r12
   58b60:      	movq	$0x1a, (%rax)
   58b67:      	movl	$0x0, 0x8(%rax)
   58b6e:      	movq	$0x0, 0x10(%rax)
   58b76:      	movq	%rax, 0x28(%rsp)
   58b7b:      	movq	0x38(%rsp), %r14
   58b80:      	movq	%r14, 0x48(%rsp)
   58b85:      	leaq	0x401c(%rip), %r13      # 0x5cba8 <ref.6>
   58b8c:      	movq	%r13, 0x50(%rsp)
   58b91:      	movq	%rax, 0x58(%rsp)
   58b96:      	movq	$0x8, 0x18(%rsp)
   58b9f:      	movq	%rbx, 0x70(%rsp)
   58ba4:      	movl	%ebx, %edi
   58ba6:      	callq	0x57e20 <native_array_new>
   58bab:      	movq	0x28(%rsp), %rbx
   58bb0:      	movq	%rbx, 0x48(%rsp)
   58bb5:      	movq	%rax, 0x50(%rsp)
   58bba:      	movq	%r14, 0x58(%rsp)
   58bbf:      	movq	%r13, 0x60(%rsp)
   58bc4:      	movq	%r12, 0x68(%rsp)
   58bc9:      	movq	$0xa, 0x18(%rsp)
   58bd2:      	movq	0x5eff(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58bd9:      	testq	%rdi, %rdi
   58bdc:      	je	0x58fe5 <f.4+0x9b5>
   58be2:      	movq	%rax, %rbp
   58be5:      	movq	0x178(%rdi), %rcx
   58bec:      	testq	%rcx, %rcx
   58bef:      	je	0x58c2e <f.4+0x5fe>
   58bf1:      	movq	0x170(%rdi), %rax
   58bf8:      	incq	%rax
   58bfb:      	movq	%rax, 0x170(%rdi)
   58c02:      	movq	%rax, %rdx
   58c05:      	orq	%rcx, %rdx
   58c08:      	shrq	$0x20, %rdx
   58c0c:      	je	0x59049 <f.4+0xa19>
   58c12:      	xorl	%edx, %edx
   58c14:      	divq	%rcx
   58c17:      	testq	%rdx, %rdx
   58c1a:      	jne	0x58c2e <f.4+0x5fe>
   58c1c:      	movq	0x5ebd(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58c23:      	movq	%rdi, %r13
   58c26:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58c2b:      	movq	%r13, %rdi
   58c2e:      	movq	0x5eab(%rip), %rdx      # 0x5eae0 <native_roots.0>
   58c35:      	movl	$0x20, %esi
   58c3a:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58c3f:      	testq	%rax, %rax
   58c42:      	je	0x59092 <f.4+0xa62>
   58c48:      	movq	%rax, %r13
   58c4b:      	movq	$0x6, (%rax)
   58c52:      	movq	%r14, 0x8(%rax)
   58c56:      	movq	%rbp, 0x10(%rax)
   58c5a:      	movq	%rbx, 0x18(%rax)
   58c5e:      	movq	%rax, 0x48(%rsp)
   58c63:      	leaq	0x3f3e(%rip), %rax      # 0x5cba8 <ref.6>
   58c6a:      	movq	%rax, 0x50(%rsp)
   58c6f:      	movq	%r12, 0x58(%rsp)
   58c74:      	movq	$0x8, 0x18(%rsp)
   58c7d:      	movq	0x5e54(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58c84:      	testq	%rdi, %rdi
   58c87:      	je	0x58fe5 <f.4+0x9b5>
   58c8d:      	movq	0x178(%rdi), %rcx
   58c94:      	testq	%rcx, %rcx
   58c97:      	movq	%r15, %r14
   58c9a:      	leaq	0x8(%rsp), %rbx
   58c9f:      	je	0x58cde <f.4+0x6ae>
   58ca1:      	movq	0x170(%rdi), %rax
   58ca8:      	incq	%rax
   58cab:      	movq	%rax, 0x170(%rdi)
   58cb2:      	movq	%rax, %rdx
   58cb5:      	orq	%rcx, %rdx
   58cb8:      	shrq	$0x20, %rdx
   58cbc:      	je	0x5905b <f.4+0xa2b>
   58cc2:      	xorl	%edx, %edx
   58cc4:      	divq	%rcx
   58cc7:      	testq	%rdx, %rdx
   58cca:      	jne	0x58cde <f.4+0x6ae>
   58ccc:      	movq	0x5e0d(%rip), %rsi      # 0x5eae0 <native_roots.0>
   58cd3:      	movq	%rdi, %rbp
   58cd6:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   58cdb:      	movq	%rbp, %rdi
   58cde:      	movq	0x5dfb(%rip), %rdx      # 0x5eae0 <native_roots.0>
   58ce5:      	movl	$0x18, %esi
   58cea:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   58cef:      	testq	%rax, %rax
   58cf2:      	je	0x59092 <f.4+0xa62>
   58cf8:      	movq	$0x36, (%rax)
   58cff:      	leaq	0x3ea2(%rip), %rcx      # 0x5cba8 <ref.6>
   58d06:      	movq	%rcx, 0x8(%rax)
   58d0a:      	movq	%r13, 0x10(%rax)
   58d0e:      	movq	%rax, 0x10(%r12)
   58d13:      	movq	0x28(%rsp), %rax
   58d18:      	testq	%rax, %rax
   58d1b:      	je	0x58fe5 <f.4+0x9b5>
   58d21:      	movl	$0x1, 0x8(%rax)
   58d28:      	movq	0x28(%rsp), %rax
   58d2d:      	testq	%rax, %rax
   58d30:      	je	0x58fe5 <f.4+0x9b5>
   58d36:      	cmpl	$0x0, 0x8(%rax)
   58d3a:      	je	0x58fe5 <f.4+0x9b5>
   58d40:      	movq	0x10(%rax), %rax
   58d44:      	testq	%rax, %rax
   58d47:      	je	0x58fe5 <f.4+0x9b5>
   58d4d:      	movq	%rax, 0x30(%rsp)
   58d52:      	movq	0x8(%rax), %rcx
   58d56:      	testq	%rcx, %rcx
   58d59:      	je	0x58fe5 <f.4+0x9b5>
   58d5f:      	movq	0x70(%rsp), %rsi
   58d64:      	decq	%rsi
   58d67:      	movq	0x10(%rax), %rdi
   58d6b:      	movq	0x8(%rcx), %rax
   58d6f:      	movq	%rdi, 0x48(%rsp)
   58d74:      	movq	$0x6, 0x18(%rsp)
   58d7d:      	callq	*%rax
   58d7f:      	subq	$0x8, %rsp
   58d83:      	testq	%rax, %rax
   58d86:      	je	0x58fe5 <f.4+0x9b5>
   58d8c:      	testb	$0x1, %al
   58d8e:      	jne	0x58fe5 <f.4+0x9b5>
   58d94:      	movq	0x20(%rsp), %rdi
   58d99:      	testq	%rdi, %rdi
   58d9c:      	je	0x58fe5 <f.4+0x9b5>
   58da2:      	movl	%edi, %ecx
   58da4:      	andl	$0x1, %ecx
   58da7:      	jne	0x58fe5 <f.4+0x9b5>
   58dad:      	movq	0x5d24(%rip), %rcx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   58db4:      	testq	%rcx, %rcx
   58db7:      	je	0x58fe5 <f.4+0x9b5>
   58dbd:      	movl	0x8(%rax), %edx
   58dc0:      	movq	(%rdi), %rsi
   58dc3:      	cmpq	$0x1e, %rsi
   58dc7:      	sete	%al
   58dca:      	movl	%eax, %r11d
   58dcd:      	testq	%rsi, %rsi
   58dd0:      	je	0x58e19 <f.4+0x7e9>
   58dd2:      	movl	%eax, %r11d
   58dd5:      	cmpq	$0x1e, %rsi
   58dd9:      	je	0x58e19 <f.4+0x7e9>
   58ddb:      	movq	0x168(%rcx), %r8
   58de2:      	movq	%rsi, %r9
   58de5:      	shrq	$0x2, %r9
   58de9:      	leaq	-0x1(%r9), %r10
   58ded:      	cmpq	%r8, %r10
   58df0:      	jae	0x58fe5 <f.4+0x9b5>
   58df6:      	movq	0x160(%rcx), %r10
   58dfd:      	movq	-0x8(%r10,%r9,8), %r9
   58e02:      	cmpq	$0x1e, %r9
   58e06:      	sete	%r11b
   58e0a:      	testq	%r9, %r9
   58e0d:      	je	0x58e19 <f.4+0x7e9>
   58e0f:      	cmpq	$0x1e, %r9
   58e13:      	jne	0x58f40 <f.4+0x910>
   58e19:      	testb	%r11b, %r11b
   58e1c:      	je	0x58fe5 <f.4+0x9b5>
   58e22:      	movq	0x10(%rdi), %r8
   58e26:      	testq	%r8, %r8
   58e29:      	je	0x58fe5 <f.4+0x9b5>
   58e2f:      	cmpl	$0x0, 0x8(%r8)
   58e34:      	je	0x58fe5 <f.4+0x9b5>
   58e3a:      	testq	%rsi, %rsi
   58e3d:      	je	0x58e7f <f.4+0x84f>
   58e3f:      	cmpq	$0x1e, %rsi
   58e43:      	je	0x58e7f <f.4+0x84f>
   58e45:      	movq	0x168(%rcx), %r8
   58e4c:      	shrq	$0x2, %rsi
   58e50:      	leaq	-0x1(%rsi), %rax
   58e54:      	cmpq	%r8, %rax
   58e57:      	jae	0x58fe5 <f.4+0x9b5>
   58e5d:      	movq	0x160(%rcx), %r9
   58e64:      	movq	-0x8(%r9,%rsi,8), %rsi
   58e69:      	cmpq	$0x1e, %rsi
   58e6d:      	sete	%al
   58e70:      	testq	%rsi, %rsi
   58e73:      	je	0x58e7f <f.4+0x84f>
   58e75:      	cmpq	$0x1e, %rsi
   58e79:      	jne	0x58f70 <f.4+0x940>
   58e7f:      	testb	%al, %al
   58e81:      	je	0x58fe5 <f.4+0x9b5>
   58e87:      	movq	%rdi, 0x40(%rsp)
   58e8c:      	movq	0x10(%rdi), %rax
   58e90:      	testq	%rax, %rax
   58e93:      	je	0x58fe5 <f.4+0x9b5>
   58e99:      	cmpq	$0x0, 0x10(%rax)
   58e9e:      	je	0x58fe5 <f.4+0x9b5>
   58ea4:      	xorl	%eax, %eax
   58ea6:      	cmpq	$0x0, 0x10(%rsp)
   58eac:      	sete	%al
   58eaf:      	movq	%rbx, %rsi
   58eb2:      	leaq	0x5c27(%rip), %r8       # 0x5eae0 <native_roots.0>
   58eb9:      	cmoveq	%r8, %rsi
   58ebd:      	addq	0x5bfc(%rip), %rax      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58ec4:      	movq	(%rsi), %rsi
   58ec7:      	movq	$0xa, 0x10(%rsp)
   58ed0:      	movq	$0x0, 0x18(%rsp)
   58ed9:      	movq	%rsi, 0x8(%rsp)
   58ede:      	movq	%rbx, 0x5bfb(%rip)      # 0x5eae0 <native_roots.0>
   58ee5:      	movq	%rax, 0x5bd4(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   58eec:      	movq	0x5bd5(%rip), %r8       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58ef3:      	cmpq	%r8, %rax
   58ef6:      	cmovaq	%rax, %r8
   58efa:      	movq	%r8, 0x5bc7(%rip)       # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   58f01:      	leaq	0x28(%rsp), %r8
   58f06:      	xorps	%xmm0, %xmm0
   58f09:      	movups	%xmm0, 0x10(%r8)
   58f0e:      	movups	%xmm0, (%r8)
   58f12:      	cmpq	$0x2, %r14
   58f16:      	jl	0x5906d <f.4+0xa3d>
   58f1c:      	movq	(%rdi), %rax
   58f1f:      	testq	%rax, %rax
   58f22:      	je	0x58f2a <f.4+0x8fa>
   58f24:      	cmpq	$0x1e, %rax
   58f28:      	jne	0x58f99 <f.4+0x969>
   58f2a:      	decq	%r14
   58f2d:      	jmp	0x58726 <f.4+0xf6>
   58f32:      	nopw	%cs:(%rax,%rax)
   58f40:      	shrq	$0x2, %r9
   58f44:      	leaq	-0x1(%r9), %r11
   58f48:      	cmpq	%r8, %r11
   58f4b:      	jae	0x58fe5 <f.4+0x9b5>
   58f51:      	movq	-0x8(%r10,%r9,8), %r9
   58f56:      	cmpq	$0x1e, %r9
   58f5a:      	je	0x58f61 <f.4+0x931>
   58f5c:      	testq	%r9, %r9
   58f5f:      	jne	0x58f40 <f.4+0x910>
   58f61:      	cmpq	$0x1e, %r9
   58f65:      	je	0x58e22 <f.4+0x7f2>
   58f6b:      	jmp	0x58fe5 <f.4+0x9b5>
   58f6d:      	nopl	(%rax)
   58f70:      	shrq	$0x2, %rsi
   58f74:      	leaq	-0x1(%rsi), %rax
   58f78:      	cmpq	%r8, %rax
   58f7b:      	jae	0x58fe5 <f.4+0x9b5>
   58f7d:      	movq	-0x8(%r9,%rsi,8), %rsi
   58f82:      	cmpq	$0x1e, %rsi
   58f86:      	je	0x58f8d <f.4+0x95d>
   58f88:      	testq	%rsi, %rsi
   58f8b:      	jne	0x58f70 <f.4+0x940>
   58f8d:      	cmpq	$0x1e, %rsi
   58f91:      	je	0x58e87 <f.4+0x857>
   58f97:      	jmp	0x58fe5 <f.4+0x9b5>
   58f99:      	movq	0x168(%rcx), %rdx
   58fa0:      	shrq	$0x2, %rax
   58fa4:      	leaq	-0x1(%rax), %rsi
   58fa8:      	cmpq	%rdx, %rsi
   58fab:      	jae	0x58fe5 <f.4+0x9b5>
   58fad:      	movq	0x160(%rcx), %rcx
   58fb4:      	nopw	%cs:(%rax,%rax)
   58fc0:      	movq	-0x8(%rcx,%rax,8), %rax
   58fc5:      	testq	%rax, %rax
   58fc8:      	je	0x58f2a <f.4+0x8fa>
   58fce:      	cmpq	$0x1e, %rax
   58fd2:      	je	0x58f2a <f.4+0x8fa>
   58fd8:      	shrq	$0x2, %rax
   58fdc:      	leaq	-0x1(%rax), %rsi
   58fe0:      	cmpq	%rdx, %rsi
   58fe3:      	jb	0x58fc0 <f.4+0x990>
   58fe5:      	callq	0x54a00 <native_trap>
   58fea:      	xorl	%edx, %edx
   58fec:      	divl	%ecx
   58fee:      	movl	%edx, %eax
   58ff0:      	movq	%rbx, %rdx
   58ff3:      	testq	%rax, %rax
   58ff6:      	jne	0x587f3 <f.4+0x1c3>
   58ffc:      	jmp	0x587de <f.4+0x1ae>
   59001:      	xorl	%edx, %edx
   59003:      	divl	%ecx
   59005:      	testq	%rdx, %rdx
   59008:      	jne	0x588ba <f.4+0x28a>
   5900e:      	jmp	0x588a8 <f.4+0x278>
   59013:      	xorl	%edx, %edx
   59015:      	divl	%ecx
   59017:      	testq	%rdx, %rdx
   5901a:      	jne	0x58964 <f.4+0x334>
   59020:      	jmp	0x58952 <f.4+0x322>
   59025:      	xorl	%edx, %edx
   59027:      	divl	%ecx
   59029:      	testq	%rdx, %rdx
   5902c:      	jne	0x58a0c <f.4+0x3dc>
   59032:      	jmp	0x589fa <f.4+0x3ca>
   59037:      	xorl	%edx, %edx
   59039:      	divl	%ecx
   5903b:      	testq	%rdx, %rdx
   5903e:      	jne	0x58b40 <f.4+0x510>
   59044:      	jmp	0x58b2e <f.4+0x4fe>
   59049:      	xorl	%edx, %edx
   5904b:      	divl	%ecx
   5904d:      	testq	%rdx, %rdx
   59050:      	jne	0x58c2e <f.4+0x5fe>
   59056:      	jmp	0x58c1c <f.4+0x5ec>
   5905b:      	xorl	%edx, %edx
   5905d:      	divl	%ecx
   5905f:      	testq	%rdx, %rdx
   59062:      	jne	0x58cde <f.4+0x6ae>
   59068:      	jmp	0x58ccc <f.4+0x69c>
   5906d:      	decq	%rax
   59070:      	movq	%rsi, 0x5a69(%rip)      # 0x5eae0 <native_roots.0>
   59077:      	movq	%rax, 0x5a42(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5907e:      	movq	%rdx, %rax
   59081:      	addq	$0x78, %rsp
   59085:      	popq	%rbx
   59086:      	popq	%r12
   59088:      	popq	%r13
   5908a:      	popq	%r14
   5908c:      	popq	%r15
   5908e:      	popq	%rbp
   5908f:      	retq	$0x8
   59092:      	leaq	-0x502cd(%rip), %rdi    # 0x8dcc <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   59099:      	movl	$0x2f, %esi
   5909e:      	callq	0x55a00 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   590a3:      	int3
   590a4:      	int3
   590a5:      	int3
   590a6:      	int3
   590a7:      	int3
   590a8:      	int3
   590a9:      	int3
   590aa:      	int3
   590ab:      	int3
   590ac:      	int3
   590ad:      	int3
   590ae:      	int3
   590af:      	int3

00000000000590b0 <f.6>:
   590b0:      	pushq	%rax
   590b1:      	testq	%rsi, %rsi
   590b4:      	js	0x590fb <f.6+0x4b>
   590b6:      	movb	$0x1, %r8b
   590b9:      	testq	%rdi, %rdi
   590bc:      	je	0x590f2 <f.6+0x42>
   590be:      	testb	$0x1, %dil
   590c2:      	jne	0x5919c <f.6+0xec>
   590c8:      	movq	0x5a09(%rip), %rdx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   590cf:      	testq	%rdx, %rdx
   590d2:      	je	0x592c5 <f.6+0x215>
   590d8:      	movq	(%rdi), %rax
   590db:      	testq	%rax, %rax
   590de:      	je	0x590ea <f.6+0x3a>
   590e0:      	cmpq	$0x6, %rax
   590e4:      	jne	0x592ca <f.6+0x21a>
   590ea:      	cmpq	$0x6, %rax
   590ee:      	setne	%r8b
   590f2:      	xorl	%eax, %eax
   590f4:      	movb	$0x1, %cl
   590f6:      	jmp	0x591a3 <f.6+0xf3>
   590fb:      	testq	%rdi, %rdi
   590fe:      	je	0x592c5 <f.6+0x215>
   59104:      	movl	%edi, %eax
   59106:      	andl	$0x1, %eax
   59109:      	testq	%rax, %rax
   5910c:      	jne	0x592c5 <f.6+0x215>
   59112:      	movq	0x59bf(%rip), %rdx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59119:      	testq	%rdx, %rdx
   5911c:      	je	0x592c5 <f.6+0x215>
   59122:      	movq	(%rdi), %rax
   59125:      	testq	%rax, %rax
   59128:      	je	0x59181 <f.6+0xd1>
   5912a:      	cmpq	$0x6, %rax
   5912e:      	je	0x59181 <f.6+0xd1>
   59130:      	movq	0x168(%rdx), %rcx
   59137:      	shrq	$0x2, %rax
   5913b:      	leaq	-0x1(%rax), %rsi
   5913f:      	cmpq	%rcx, %rsi
   59142:      	jae	0x592c5 <f.6+0x215>
   59148:      	movq	0x160(%rdx), %rdx
   5914f:      	movq	-0x8(%rdx,%rax,8), %rax
   59154:      	testq	%rax, %rax
   59157:      	je	0x59181 <f.6+0xd1>
   59159:      	cmpq	$0x6, %rax
   5915d:      	je	0x59181 <f.6+0xd1>
   5915f:      	nop
   59160:      	shrq	$0x2, %rax
   59164:      	leaq	-0x1(%rax), %rsi
   59168:      	cmpq	%rcx, %rsi
   5916b:      	jae	0x592c5 <f.6+0x215>
   59171:      	movq	-0x8(%rdx,%rax,8), %rax
   59176:      	cmpq	$0x6, %rax
   5917a:      	je	0x59181 <f.6+0xd1>
   5917c:      	testq	%rax, %rax
   5917f:      	jne	0x59160 <f.6+0xb0>
   59181:      	cmpq	$0x6, %rax
   59185:      	jne	0x592c5 <f.6+0x215>
   5918b:      	testq	%rdi, %rdi
   5918e:      	je	0x592c5 <f.6+0x215>
   59194:      	movq	0x10(%rdi), %rax
   59198:      	popq	%rcx
   59199:      	retq	$0x8
   5919c:      	movl	$0x1, %eax
   591a1:      	xorl	%ecx, %ecx
   591a3:      	movq	%rsi, %rdx
   591a6:      	shrq	$0x20, %rdx
   591aa:      	jmp	0x591b8 <f.6+0x108>
   591ac:      	nopl	(%rax)
   591b0:      	cmpq	$0x6, %r8
   591b4:      	setne	%r8b
   591b8:      	testb	$0x1, %r8b
   591bc:      	jne	0x592c5 <f.6+0x215>
   591c2:      	testq	%rdi, %rdi
   591c5:      	je	0x592c5 <f.6+0x215>
   591cb:      	testq	%rdx, %rdx
   591ce:      	jne	0x592c5 <f.6+0x215>
   591d4:      	movq	0x8(%rdi), %r8
   591d8:      	testq	%r8, %r8
   591db:      	je	0x592c5 <f.6+0x215>
   591e1:      	testb	$0x1, %r8b
   591e5:      	jne	0x592c5 <f.6+0x215>
   591eb:      	cmpq	0x8(%r8), %rsi
   591ef:      	jae	0x592c5 <f.6+0x215>
   591f5:      	movq	0x10(%rdi), %r9
   591f9:      	testq	%r9, %r9
   591fc:      	je	0x592c5 <f.6+0x215>
   59202:      	testb	$0x1, %r9b
   59206:      	jne	0x592c5 <f.6+0x215>
   5920c:      	cmpq	0x8(%r9), %rsi
   59210:      	jae	0x592c5 <f.6+0x215>
   59216:      	movq	0x10(%r8,%rsi,8), %r8
   5921b:      	movq	%r8, 0x10(%r9,%rsi,8)
   59220:      	movq	0x18(%rdi), %r8
   59224:      	testq	%r8, %r8
   59227:      	je	0x592c5 <f.6+0x215>
   5922d:      	cmpl	$0x0, 0x8(%r8)
   59232:      	je	0x592c5 <f.6+0x215>
   59238:      	cmpq	$0x0, 0x10(%r8)
   5923d:      	je	0x592c5 <f.6+0x215>
   59243:      	testq	%rsi, %rsi
   59246:      	je	0x59109 <f.6+0x59>
   5924c:      	decq	%rsi
   5924f:      	movb	$0x1, %r8b
   59252:      	testb	%cl, %cl
   59254:      	je	0x591b8 <f.6+0x108>
   5925a:      	movq	0x5877(%rip), %r10      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59261:      	testq	%r10, %r10
   59264:      	je	0x592c5 <f.6+0x215>
   59266:      	movq	(%rdi), %r8
   59269:      	testq	%r8, %r8
   5926c:      	je	0x591b0 <f.6+0x100>
   59272:      	cmpq	$0x6, %r8
   59276:      	je	0x591b0 <f.6+0x100>
   5927c:      	movq	0x168(%r10), %r9
   59283:      	shrq	$0x2, %r8
   59287:      	leaq	-0x1(%r8), %r11
   5928b:      	cmpq	%r9, %r11
   5928e:      	jae	0x592c5 <f.6+0x215>
   59290:      	movq	0x160(%r10), %r10
   59297:      	nopw	(%rax,%rax)
   592a0:      	movq	-0x8(%r10,%r8,8), %r8
   592a5:      	testq	%r8, %r8
   592a8:      	je	0x591b0 <f.6+0x100>
   592ae:      	cmpq	$0x6, %r8
   592b2:      	je	0x591b0 <f.6+0x100>
   592b8:      	shrq	$0x2, %r8
   592bc:      	leaq	-0x1(%r8), %r11
   592c0:      	cmpq	%r9, %r11
   592c3:      	jb	0x592a0 <f.6+0x1f0>
   592c5:      	callq	0x54a00 <native_trap>
   592ca:      	movq	0x168(%rdx), %rcx
   592d1:      	shrq	$0x2, %rax
   592d5:      	leaq	-0x1(%rax), %r8
   592d9:      	cmpq	%rcx, %r8
   592dc:      	jae	0x592c5 <f.6+0x215>
   592de:      	movq	0x160(%rdx), %rdx
   592e5:      	nopw	%cs:(%rax,%rax)
   592f0:      	movq	-0x8(%rdx,%rax,8), %rax
   592f5:      	testq	%rax, %rax
   592f8:      	je	0x590ea <f.6+0x3a>
   592fe:      	cmpq	$0x6, %rax
   59302:      	je	0x590ea <f.6+0x3a>
   59308:      	shrq	$0x2, %rax
   5930c:      	leaq	-0x1(%rax), %r8
   59310:      	cmpq	%rcx, %r8
   59313:      	jb	0x592f0 <f.6+0x240>
   59315:      	jmp	0x592c5 <f.6+0x215>
   59317:      	int3
   59318:      	int3
   59319:      	int3
   5931a:      	int3
   5931b:      	int3
   5931c:      	int3
   5931d:      	int3
   5931e:      	int3
   5931f:      	int3

0000000000059320 <f.8>:
   59320:      	pushq	%rax
   59321:      	testq	%rdi, %rdi
   59324:      	je	0x594c7 <f.8+0x1a7>
   5932a:      	movl	%edi, %eax
   5932c:      	andl	$0x1, %eax
   5932f:      	jne	0x594c7 <f.8+0x1a7>
   59335:      	movq	0x579c(%rip), %rdx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5933c:      	testq	%rdx, %rdx
   5933f:      	je	0x594c7 <f.8+0x1a7>
   59345:      	movq	(%rdi), %rax
   59348:      	testq	%rax, %rax
   5934b:      	je	0x593c3 <f.8+0xa3>
   5934d:      	cmpq	$0xe, %rax
   59351:      	je	0x593c3 <f.8+0xa3>
   59353:      	movq	0x168(%rdx), %rcx
   5935a:      	shrq	$0x2, %rax
   5935e:      	leaq	-0x1(%rax), %r8
   59362:      	cmpq	%rcx, %r8
   59365:      	jae	0x594c7 <f.8+0x1a7>
   5936b:      	movq	0x160(%rdx), %rdx
   59372:      	movq	-0x8(%rdx,%rax,8), %rax
   59377:      	testq	%rax, %rax
   5937a:      	je	0x593c3 <f.8+0xa3>
   5937c:      	cmpq	$0xe, %rax
   59380:      	je	0x593c3 <f.8+0xa3>
   59382:      	nopw	%cs:(%rax,%rax)
   59390:      	shrq	$0x2, %rax
   59394:      	leaq	-0x1(%rax), %r8
   59398:      	cmpq	%rcx, %r8
   5939b:      	jae	0x594c7 <f.8+0x1a7>
   593a1:      	movq	-0x8(%rdx,%rax,8), %rax
   593a6:      	cmpq	$0xe, %rax
   593aa:      	je	0x593c3 <f.8+0xa3>
   593ac:      	testq	%rax, %rax
   593af:      	jne	0x59390 <f.8+0x70>
   593b1:      	jmp	0x593c3 <f.8+0xa3>
   593b3:      	nopw	%cs:(%rax,%rax)
   593c0:      	incq	%rsi
   593c3:      	cmpq	$0xe, %rax
   593c7:      	jne	0x594c7 <f.8+0x1a7>
   593cd:      	cmpq	%rsi, 0x8(%rdi)
   593d1:      	jle	0x594b6 <f.8+0x196>
   593d7:      	movq	%rsi, %rax
   593da:      	shrq	$0x20, %rax
   593de:      	jne	0x594c7 <f.8+0x1a7>
   593e4:      	movq	0x10(%rdi), %rax
   593e8:      	testq	%rax, %rax
   593eb:      	je	0x594c7 <f.8+0x1a7>
   593f1:      	movq	0x8(%rax), %rax
   593f5:      	testq	%rax, %rax
   593f8:      	je	0x594c7 <f.8+0x1a7>
   593fe:      	testb	$0x1, %al
   59400:      	jne	0x594c7 <f.8+0x1a7>
   59406:      	cmpq	0x8(%rax), %rsi
   5940a:      	jae	0x594c7 <f.8+0x1a7>
   59410:      	movq	%rsi, 0x10(%rax,%rsi,8)
   59415:      	movq	0x18(%rdi), %rax
   59419:      	testq	%rax, %rax
   5941c:      	je	0x594c7 <f.8+0x1a7>
   59422:      	cmpl	$0x0, 0x8(%rax)
   59426:      	je	0x594c7 <f.8+0x1a7>
   5942c:      	cmpq	$0x0, 0x10(%rax)
   59431:      	je	0x594c7 <f.8+0x1a7>
   59437:      	movq	0x569a(%rip), %rdx      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   5943e:      	testq	%rdx, %rdx
   59441:      	je	0x594c7 <f.8+0x1a7>
   59447:      	movq	(%rdi), %rax
   5944a:      	testq	%rax, %rax
   5944d:      	je	0x593c0 <f.8+0xa0>
   59453:      	cmpq	$0xe, %rax
   59457:      	je	0x593c0 <f.8+0xa0>
   5945d:      	movq	0x168(%rdx), %rcx
   59464:      	shrq	$0x2, %rax
   59468:      	leaq	-0x1(%rax), %r8
   5946c:      	cmpq	%rcx, %r8
   5946f:      	jae	0x594c7 <f.8+0x1a7>
   59471:      	movq	0x160(%rdx), %rdx
   59478:      	movq	-0x8(%rdx,%rax,8), %rax
   5947d:      	testq	%rax, %rax
   59480:      	je	0x593c0 <f.8+0xa0>
   59486:      	cmpq	$0xe, %rax
   5948a:      	je	0x593c0 <f.8+0xa0>
   59490:      	shrq	$0x2, %rax
   59494:      	leaq	-0x1(%rax), %r8
   59498:      	cmpq	%rcx, %r8
   5949b:      	jae	0x594c7 <f.8+0x1a7>
   5949d:      	movq	-0x8(%rdx,%rax,8), %rax
   594a2:      	cmpq	$0xe, %rax
   594a6:      	je	0x593c0 <f.8+0xa0>
   594ac:      	testq	%rax, %rax
   594af:      	jne	0x59490 <f.8+0x170>
   594b1:      	jmp	0x593c0 <f.8+0xa0>
   594b6:      	movq	0x10(%rdi), %rax
   594ba:      	testq	%rax, %rax
   594bd:      	je	0x594c7 <f.8+0x1a7>
   594bf:      	movq	0x8(%rax), %rax
   594c3:      	popq	%rcx
   594c4:      	retq	$0x8
   594c7:      	callq	0x54a00 <native_trap>
   594cc:      	int3
   594cd:      	int3
   594ce:      	int3
   594cf:      	int3

00000000000594d0 <f.3>:
   594d0:      	pushq	%r15
   594d2:      	pushq	%r14
   594d4:      	pushq	%r13
   594d6:      	pushq	%r12
   594d8:      	pushq	%rbx
   594d9:      	subq	$0x50, %rsp
   594dd:      	movq	%rdx, %r14
   594e0:      	movq	$0x6, 0x10(%rsp)
   594e9:      	movq	0x55f0(%rip), %rax      # 0x5eae0 <native_roots.0>
   594f0:      	movq	%rax, 0x8(%rsp)
   594f5:      	leaq	0x8(%rsp), %rcx
   594fa:      	movq	0x55bf(%rip), %rax      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59501:      	incq	%rax
   59504:      	movq	%rax, 0x55b5(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5950b:      	movq	0x55b6(%rip), %rdx      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59512:      	cmpq	%rdx, %rax
   59515:      	cmovbeq	%rdx, %rax
   59519:      	movq	%rcx, 0x55c0(%rip)      # 0x5eae0 <native_roots.0>
   59520:      	movq	%rax, 0x55a1(%rip)      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59527:      	movq	%rdi, 0x20(%rsp)
   5952c:      	xorps	%xmm0, %xmm0
   5952f:      	movups	%xmm0, 0x28(%rsp)
   59534:      	movq	$0x3, 0x18(%rsp)
   5953d:      	movq	0x5594(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59544:      	testq	%rdi, %rdi
   59547:      	je	0x597c5 <f.3+0x2f5>
   5954d:      	movq	%rsi, %rbx
   59550:      	movq	0x178(%rdi), %rsi
   59557:      	testq	%rsi, %rsi
   5955a:      	je	0x5959e <f.3+0xce>
   5955c:      	movq	0x170(%rdi), %rax
   59563:      	incq	%rax
   59566:      	movq	%rax, 0x170(%rdi)
   5956d:      	movq	%rax, %rdx
   59570:      	orq	%rsi, %rdx
   59573:      	shrq	$0x20, %rdx
   59577:      	je	0x5978f <f.3+0x2bf>
   5957d:      	xorl	%edx, %edx
   5957f:      	divq	%rsi
   59582:      	testq	%rdx, %rdx
   59585:      	jne	0x5959e <f.3+0xce>
   59587:      	leaq	0x8(%rsp), %rsi
   5958c:      	movq	%rdi, %r15
   5958f:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59594:      	movq	%r15, %rdi
   59597:      	movq	0x5542(%rip), %rcx      # 0x5eae0 <native_roots.0>
   5959e:      	movl	$0x18, %esi
   595a3:      	movq	%rcx, %rdx
   595a6:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   595ab:      	testq	%rax, %rax
   595ae:      	je	0x597ca <f.3+0x2fa>
   595b4:      	movq	%rax, %r15
   595b7:      	movq	$0x26, (%rax)
   595be:      	movl	$0x0, 0x8(%rax)
   595c5:      	movq	$0x0, 0x10(%rax)
   595cd:      	movq	%rax, 0x28(%rsp)
   595d2:      	movq	%rax, 0x38(%rsp)
   595d7:      	leaq	0x35aa(%rip), %r13      # 0x5cb88 <ref.4>
   595de:      	movq	%r13, 0x40(%rsp)
   595e3:      	movq	%rax, 0x48(%rsp)
   595e8:      	movq	$0x6, 0x18(%rsp)
   595f1:      	movq	0x54e0(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   595f8:      	testq	%rdi, %rdi
   595fb:      	je	0x597c5 <f.3+0x2f5>
   59601:      	movq	0x178(%rdi), %rcx
   59608:      	testq	%rcx, %rcx
   5960b:      	je	0x5964a <f.3+0x17a>
   5960d:      	movq	0x170(%rdi), %rax
   59614:      	incq	%rax
   59617:      	movq	%rax, 0x170(%rdi)
   5961e:      	movq	%rax, %rdx
   59621:      	orq	%rcx, %rdx
   59624:      	shrq	$0x20, %rdx
   59628:      	je	0x597a1 <f.3+0x2d1>
   5962e:      	xorl	%edx, %edx
   59630:      	divq	%rcx
   59633:      	testq	%rdx, %rdx
   59636:      	jne	0x5964a <f.3+0x17a>
   59638:      	movq	0x54a1(%rip), %rsi      # 0x5eae0 <native_roots.0>
   5963f:      	movq	%rdi, %r12
   59642:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59647:      	movq	%r12, %rdi
   5964a:      	movq	0x548f(%rip), %rdx      # 0x5eae0 <native_roots.0>
   59651:      	movl	$0x18, %esi
   59656:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5965b:      	testq	%rax, %rax
   5965e:      	je	0x597ca <f.3+0x2fa>
   59664:      	movq	%rax, %r12
   59667:      	movq	$0x1e, (%rax)
   5966e:      	movq	%r14, 0x8(%rax)
   59672:      	movq	%r15, 0x10(%rax)
   59676:      	movq	%rax, 0x38(%rsp)
   5967b:      	movq	%r13, 0x40(%rsp)
   59680:      	movq	%r15, 0x48(%rsp)
   59685:      	movq	$0x6, 0x18(%rsp)
   5968e:      	movq	0x5443(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59695:      	testq	%rdi, %rdi
   59698:      	je	0x597c5 <f.3+0x2f5>
   5969e:      	movq	0x178(%rdi), %rcx
   596a5:      	testq	%rcx, %rcx
   596a8:      	je	0x596e7 <f.3+0x217>
   596aa:      	movq	0x170(%rdi), %rax
   596b1:      	incq	%rax
   596b4:      	movq	%rax, 0x170(%rdi)
   596bb:      	movq	%rax, %rdx
   596be:      	orq	%rcx, %rdx
   596c1:      	shrq	$0x20, %rdx
   596c5:      	je	0x597b3 <f.3+0x2e3>
   596cb:      	xorl	%edx, %edx
   596cd:      	divq	%rcx
   596d0:      	testq	%rdx, %rdx
   596d3:      	jne	0x596e7 <f.3+0x217>
   596d5:      	movq	0x5404(%rip), %rsi      # 0x5eae0 <native_roots.0>
   596dc:      	movq	%rdi, %r14
   596df:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   596e4:      	movq	%r14, %rdi
   596e7:      	movq	0x53f2(%rip), %rdx      # 0x5eae0 <native_roots.0>
   596ee:      	movl	$0x18, %esi
   596f3:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   596f8:      	testq	%rax, %rax
   596fb:      	je	0x597ca <f.3+0x2fa>
   59701:      	movq	$0x3a, (%rax)
   59708:      	movq	%r13, 0x8(%rax)
   5970c:      	movq	%r12, 0x10(%rax)
   59710:      	movq	%rax, 0x10(%r15)
   59714:      	movq	0x28(%rsp), %rax
   59719:      	testq	%rax, %rax
   5971c:      	je	0x597c5 <f.3+0x2f5>
   59722:      	movl	$0x1, 0x8(%rax)
   59729:      	movq	0x28(%rsp), %rax
   5972e:      	testq	%rax, %rax
   59731:      	je	0x597c5 <f.3+0x2f5>
   59737:      	cmpl	$0x0, 0x8(%rax)
   5973b:      	je	0x597c5 <f.3+0x2f5>
   59741:      	movq	0x10(%rax), %rax
   59745:      	testq	%rax, %rax
   59748:      	je	0x597c5 <f.3+0x2f5>
   5974a:      	movq	%rax, 0x30(%rsp)
   5974f:      	movq	0x8(%rax), %rcx
   59753:      	testq	%rcx, %rcx
   59756:      	je	0x597c5 <f.3+0x2f5>
   59758:      	movq	0x10(%rax), %rdi
   5975c:      	movq	0x8(%rcx), %rax
   59760:      	cmpq	$0x0, 0x10(%rsp)
   59766:      	je	0x5977b <f.3+0x2ab>
   59768:      	movq	0x8(%rsp), %rcx
   5976d:      	movq	%rcx, 0x536c(%rip)      # 0x5eae0 <native_roots.0>
   59774:      	decq	0x5345(%rip)            # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5977b:      	movq	%rbx, %rsi
   5977e:      	xorl	%edx, %edx
   59780:      	addq	$0x50, %rsp
   59784:      	popq	%rbx
   59785:      	popq	%r12
   59787:      	popq	%r13
   59789:      	popq	%r14
   5978b:      	popq	%r15
   5978d:      	jmpq	*%rax
   5978f:      	xorl	%edx, %edx
   59791:      	divl	%esi
   59793:      	testq	%rdx, %rdx
   59796:      	jne	0x5959e <f.3+0xce>
   5979c:      	jmp	0x59587 <f.3+0xb7>
   597a1:      	xorl	%edx, %edx
   597a3:      	divl	%ecx
   597a5:      	testq	%rdx, %rdx
   597a8:      	jne	0x5964a <f.3+0x17a>
   597ae:      	jmp	0x59638 <f.3+0x168>
   597b3:      	xorl	%edx, %edx
   597b5:      	divl	%ecx
   597b7:      	testq	%rdx, %rdx
   597ba:      	jne	0x596e7 <f.3+0x217>
   597c0:      	jmp	0x596d5 <f.3+0x205>
   597c5:      	callq	0x54a00 <native_trap>
   597ca:      	leaq	-0x50a05(%rip), %rdi    # 0x8dcc <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   597d1:      	movl	$0x2f, %esi
   597d6:      	callq	0x55a00 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   597db:      	int3
   597dc:      	int3
   597dd:      	int3
   597de:      	int3
   597df:      	int3

00000000000597e0 <f.7>:
   597e0:      	pushq	%rbp
   597e1:      	pushq	%r15
   597e3:      	pushq	%r14
   597e5:      	pushq	%r13
   597e7:      	pushq	%r12
   597e9:      	pushq	%rbx
   597ea:      	subq	$0x58, %rsp
   597ee:      	movq	$0x7, 0x10(%rsp)
   597f7:      	movq	$0x0, 0x18(%rsp)
   59800:      	movq	0x52d9(%rip), %rax      # 0x5eae0 <native_roots.0>
   59807:      	movq	%rax, 0x8(%rsp)
   5980c:      	movq	0x52ad(%rip), %rax      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59813:      	incq	%rax
   59816:      	movq	%rax, 0x52a3(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   5981d:      	movq	0x52a4(%rip), %rcx      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59824:      	cmpq	%rcx, %rax
   59827:      	cmovbeq	%rcx, %rax
   5982b:      	leaq	0x8(%rsp), %rcx
   59830:      	movq	%rcx, 0x52a9(%rip)      # 0x5eae0 <native_roots.0>
   59837:      	movq	%rax, 0x528a(%rip)      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   5983e:      	movq	%rdi, 0x20(%rsp)
   59843:      	movq	%rsi, %rax
   59846:      	shrq	$0x20, %rax
   5984a:      	xorps	%xmm0, %xmm0
   5984d:      	movups	%xmm0, 0x28(%rsp)
   59852:      	jne	0x59bc1 <f.7+0x3e1>
   59858:      	movq	$0x3, 0x18(%rsp)
   59861:      	movq	0x5270(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59868:      	testq	%rdi, %rdi
   5986b:      	je	0x59bc1 <f.7+0x3e1>
   59871:      	movq	%rsi, %rbx
   59874:      	movq	0x178(%rdi), %rsi
   5987b:      	testq	%rsi, %rsi
   5987e:      	je	0x598c2 <f.7+0xe2>
   59880:      	movq	0x170(%rdi), %rax
   59887:      	incq	%rax
   5988a:      	movq	%rax, 0x170(%rdi)
   59891:      	movq	%rax, %rdx
   59894:      	orq	%rsi, %rdx
   59897:      	shrq	$0x20, %rdx
   5989b:      	je	0x59b79 <f.7+0x399>
   598a1:      	xorl	%edx, %edx
   598a3:      	divq	%rsi
   598a6:      	testq	%rdx, %rdx
   598a9:      	jne	0x598c2 <f.7+0xe2>
   598ab:      	leaq	0x8(%rsp), %rsi
   598b0:      	movq	%rdi, %r14
   598b3:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   598b8:      	movq	%r14, %rdi
   598bb:      	movq	0x521e(%rip), %rcx      # 0x5eae0 <native_roots.0>
   598c2:      	movl	$0x18, %esi
   598c7:      	movq	%rcx, %rdx
   598ca:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   598cf:      	testq	%rax, %rax
   598d2:      	je	0x59bc6 <f.7+0x3e6>
   598d8:      	movq	%rax, %r14
   598db:      	movq	$0x1a, (%rax)
   598e2:      	movl	$0x0, 0x8(%rax)
   598e9:      	movq	$0x0, 0x10(%rax)
   598f1:      	movq	%rax, 0x28(%rsp)
   598f6:      	leaq	0x32cb(%rip), %r13      # 0x5cbc8 <ref.8>
   598fd:      	movq	%r13, 0x38(%rsp)
   59902:      	movq	%rax, 0x40(%rsp)
   59907:      	movq	$0x5, 0x18(%rsp)
   59910:      	movl	%ebx, %edi
   59912:      	callq	0x57e20 <native_array_new>
   59917:      	movq	%rax, 0x38(%rsp)
   5991c:      	movq	%r13, 0x40(%rsp)
   59921:      	movq	%r14, 0x48(%rsp)
   59926:      	movq	$0x6, 0x18(%rsp)
   5992f:      	movq	0x51a2(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59936:      	testq	%rdi, %rdi
   59939:      	je	0x59bc1 <f.7+0x3e1>
   5993f:      	movq	%rax, %r12
   59942:      	movq	0x178(%rdi), %rcx
   59949:      	testq	%rcx, %rcx
   5994c:      	je	0x5998b <f.7+0x1ab>
   5994e:      	movq	0x170(%rdi), %rax
   59955:      	incq	%rax
   59958:      	movq	%rax, 0x170(%rdi)
   5995f:      	movq	%rax, %rdx
   59962:      	orq	%rcx, %rdx
   59965:      	shrq	$0x20, %rdx
   59969:      	je	0x59b8b <f.7+0x3ab>
   5996f:      	xorl	%edx, %edx
   59971:      	divq	%rcx
   59974:      	testq	%rdx, %rdx
   59977:      	jne	0x5998b <f.7+0x1ab>
   59979:      	movq	0x5160(%rip), %rsi      # 0x5eae0 <native_roots.0>
   59980:      	movq	%rdi, %r15
   59983:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59988:      	movq	%r15, %rdi
   5998b:      	movq	0x514e(%rip), %rdx      # 0x5eae0 <native_roots.0>
   59992:      	movl	$0x10, %esi
   59997:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   5999c:      	testq	%rax, %rax
   5999f:      	je	0x59bc6 <f.7+0x3e6>
   599a5:      	movq	%rax, %r15
   599a8:      	movq	$0x12, (%rax)
   599af:      	movq	%r12, 0x8(%rax)
   599b3:      	movq	0x28(%rsp), %rbp
   599b8:      	movq	%rbp, 0x38(%rsp)
   599bd:      	movq	%rax, 0x40(%rsp)
   599c2:      	movq	%r13, 0x48(%rsp)
   599c7:      	movq	%r14, 0x50(%rsp)
   599cc:      	movq	$0x7, 0x18(%rsp)
   599d5:      	movq	0x50fc(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   599dc:      	testq	%rdi, %rdi
   599df:      	je	0x59bc1 <f.7+0x3e1>
   599e5:      	movq	0x178(%rdi), %rcx
   599ec:      	testq	%rcx, %rcx
   599ef:      	je	0x59a2e <f.7+0x24e>
   599f1:      	movq	0x170(%rdi), %rax
   599f8:      	incq	%rax
   599fb:      	movq	%rax, 0x170(%rdi)
   59a02:      	movq	%rax, %rdx
   59a05:      	orq	%rcx, %rdx
   59a08:      	shrq	$0x20, %rdx
   59a0c:      	je	0x59b9d <f.7+0x3bd>
   59a12:      	xorl	%edx, %edx
   59a14:      	divq	%rcx
   59a17:      	testq	%rdx, %rdx
   59a1a:      	jne	0x59a2e <f.7+0x24e>
   59a1c:      	movq	0x50bd(%rip), %rsi      # 0x5eae0 <native_roots.0>
   59a23:      	movq	%rdi, %r12
   59a26:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59a2b:      	movq	%r12, %rdi
   59a2e:      	movq	0x50ab(%rip), %rdx      # 0x5eae0 <native_roots.0>
   59a35:      	movl	$0x20, %esi
   59a3a:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59a3f:      	testq	%rax, %rax
   59a42:      	je	0x59bc6 <f.7+0x3e6>
   59a48:      	movq	%rax, %r12
   59a4b:      	movq	$0xe, (%rax)
   59a52:      	movq	%rbx, 0x8(%rax)
   59a56:      	movq	%r15, 0x10(%rax)
   59a5a:      	movq	%rbp, 0x18(%rax)
   59a5e:      	movq	%rax, 0x38(%rsp)
   59a63:      	movq	%r13, 0x40(%rsp)
   59a68:      	movq	%r14, 0x48(%rsp)
   59a6d:      	movq	$0x6, 0x18(%rsp)
   59a76:      	movq	0x505b(%rip), %rdi      # 0x5ead8 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   59a7d:      	testq	%rdi, %rdi
   59a80:      	je	0x59bc1 <f.7+0x3e1>
   59a86:      	movq	0x178(%rdi), %rcx
   59a8d:      	testq	%rcx, %rcx
   59a90:      	je	0x59acf <f.7+0x2ef>
   59a92:      	movq	0x170(%rdi), %rax
   59a99:      	incq	%rax
   59a9c:      	movq	%rax, 0x170(%rdi)
   59aa3:      	movq	%rax, %rdx
   59aa6:      	orq	%rcx, %rdx
   59aa9:      	shrq	$0x20, %rdx
   59aad:      	je	0x59baf <f.7+0x3cf>
   59ab3:      	xorl	%edx, %edx
   59ab5:      	divq	%rcx
   59ab8:      	testq	%rdx, %rdx
   59abb:      	jne	0x59acf <f.7+0x2ef>
   59abd:      	movq	0x501c(%rip), %rsi      # 0x5eae0 <native_roots.0>
   59ac4:      	movq	%rdi, %rbx
   59ac7:      	callq	0x560d0 <snail_runtime::native_gc::Collector::collect::hcb9de1c121707028>
   59acc:      	movq	%rbx, %rdi
   59acf:      	movq	0x500a(%rip), %rdx      # 0x5eae0 <native_roots.0>
   59ad6:      	movl	$0x18, %esi
   59adb:      	callq	0x55f20 <snail_runtime::native_gc::Collector::allocate::h8a0b5949764e62ef>
   59ae0:      	testq	%rax, %rax
   59ae3:      	je	0x59bc6 <f.7+0x3e6>
   59ae9:      	movq	$0x36, (%rax)
   59af0:      	movq	%r13, 0x8(%rax)
   59af4:      	movq	%r12, 0x10(%rax)
   59af8:      	movq	%rax, 0x10(%r14)
   59afc:      	movq	0x28(%rsp), %rax
   59b01:      	testq	%rax, %rax
   59b04:      	je	0x59bc1 <f.7+0x3e1>
   59b0a:      	movl	$0x1, 0x8(%rax)
   59b11:      	movq	0x28(%rsp), %rax
   59b16:      	testq	%rax, %rax
   59b19:      	je	0x59bc1 <f.7+0x3e1>
   59b1f:      	cmpl	$0x0, 0x8(%rax)
   59b23:      	je	0x59bc1 <f.7+0x3e1>
   59b29:      	movq	0x10(%rax), %rax
   59b2d:      	testq	%rax, %rax
   59b30:      	je	0x59bc1 <f.7+0x3e1>
   59b36:      	movq	%rax, 0x30(%rsp)
   59b3b:      	movq	0x8(%rax), %rcx
   59b3f:      	testq	%rcx, %rcx
   59b42:      	je	0x59bc1 <f.7+0x3e1>
   59b44:      	movq	0x10(%rax), %rdi
   59b48:      	movq	0x8(%rcx), %rax
   59b4c:      	cmpq	$0x0, 0x10(%rsp)
   59b52:      	je	0x59b67 <f.7+0x387>
   59b54:      	movq	0x8(%rsp), %rcx
   59b59:      	movq	%rcx, 0x4f80(%rip)      # 0x5eae0 <native_roots.0>
   59b60:      	decq	0x4f59(%rip)            # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59b67:      	xorl	%esi, %esi
   59b69:      	addq	$0x58, %rsp
   59b6d:      	popq	%rbx
   59b6e:      	popq	%r12
   59b70:      	popq	%r13
   59b72:      	popq	%r14
   59b74:      	popq	%r15
   59b76:      	popq	%rbp
   59b77:      	jmpq	*%rax
   59b79:      	xorl	%edx, %edx
   59b7b:      	divl	%esi
   59b7d:      	testq	%rdx, %rdx
   59b80:      	jne	0x598c2 <f.7+0xe2>
   59b86:      	jmp	0x598ab <f.7+0xcb>
   59b8b:      	xorl	%edx, %edx
   59b8d:      	divl	%ecx
   59b8f:      	testq	%rdx, %rdx
   59b92:      	jne	0x5998b <f.7+0x1ab>
   59b98:      	jmp	0x59979 <f.7+0x199>
   59b9d:      	xorl	%edx, %edx
   59b9f:      	divl	%ecx
   59ba1:      	testq	%rdx, %rdx
   59ba4:      	jne	0x59a2e <f.7+0x24e>
   59baa:      	jmp	0x59a1c <f.7+0x23c>
   59baf:      	xorl	%edx, %edx
   59bb1:      	divl	%ecx
   59bb3:      	testq	%rdx, %rdx
   59bb6:      	jne	0x59acf <f.7+0x2ef>
   59bbc:      	jmp	0x59abd <f.7+0x2dd>
   59bc1:      	callq	0x54a00 <native_trap>
   59bc6:      	leaq	-0x50e01(%rip), %rdi    # 0x8dcc <core::num::flt2dec::strategy::dragon::POW5TO256+0x828>
   59bcd:      	movl	$0x2f, %esi
   59bd2:      	callq	0x55a00 <snail_runtime::native::fail_bytes::hc850c6cf7f4053c2>
   59bd7:      	int3
   59bd8:      	int3
   59bd9:      	int3
   59bda:      	int3
   59bdb:      	int3
   59bdc:      	int3
   59bdd:      	int3
   59bde:      	int3
   59bdf:      	int3

0000000000059be0 <f.5>:
   59be0:      	movq	$0x1, -0x18(%rsp)
   59be9:      	movq	0x4ef0(%rip), %rax      # 0x5eae0 <native_roots.0>
   59bf0:      	movq	%rax, -0x20(%rsp)
   59bf5:      	leaq	-0x20(%rsp), %rax
   59bfa:      	movq	%rax, 0x4edf(%rip)      # 0x5eae0 <native_roots.0>
   59c01:      	movq	0x4eb8(%rip), %rax      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59c08:      	incq	%rax
   59c0b:      	movq	%rax, 0x4eae(%rip)      # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59c12:      	movq	0x4eaf(%rip), %rcx      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59c19:      	cmpq	%rcx, %rax
   59c1c:      	cmovbeq	%rcx, %rax
   59c20:      	movq	%rax, 0x4ea1(%rip)      # 0x5eac8 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   59c27:      	movq	%rdi, -0x8(%rsp)
   59c2c:      	movq	$0x1, -0x10(%rsp)
   59c35:      	movq	%rdx, -0x28(%rsp)
   59c3a:      	leaq	-0x28(%rsp), %rax
   59c3f:      	movq	-0x28(%rsp), %rax
   59c44:      	cmpq	$0x0, -0x18(%rsp)
   59c4a:      	je	0x59c5f <f.5+0x7f>
   59c4c:      	movq	-0x20(%rsp), %rcx
   59c51:      	movq	%rcx, 0x4e88(%rip)      # 0x5eae0 <native_roots.0>
   59c58:      	decq	0x4e61(%rip)            # 0x5eac0 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   59c5f:      	retq	$0x8

Disassembly of section .init:
