0000000000013e10 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0>:
   13e10:      	pushq	%rbp
   13e11:      	pushq	%r14
   13e13:      	pushq	%rbx
   13e14:      	subq	$0x50, %rsp
   13e18:      	callq	*0x4c5fa(%rip)          # 0x60418 <writev+0x60418>
   13e1e:      	callq	*0x4c5fc(%rip)          # 0x60420 <writev+0x60420>
   13e24:      	callq	*0x4c5fe(%rip)          # 0x60428 <writev+0x60428>
   13e2a:      	callq	0x53e50 <<std::sys::pal::unix::time::Timespec>::now>
   13e2f:      	movq	%rax, %r14
   13e32:      	movl	%edx, %ebp
   13e34:      	movl	$0x1, %edi
   13e39:      	callq	*0x4c5f1(%rip)          # 0x60430 <writev+0x60430>
   13e3f:      	movq	%rax, %rbx
   13e42:      	movq	%rax, 0x28(%rsp)
   13e47:      	callq	0x53e50 <<std::sys::pal::unix::time::Timespec>::now>
   13e4c:      	movq	%rax, 0x40(%rsp)
   13e51:      	movl	%edx, 0x48(%rsp)
   13e55:      	movq	%r14, 0x30(%rsp)
   13e5a:      	movl	%ebp, 0x38(%rsp)
   13e5e:      	leaq	0x8(%rsp), %rdi
   13e63:      	leaq	0x40(%rsp), %rsi
   13e68:      	leaq	0x30(%rsp), %r14
   13e6d:      	movq	%r14, %rdx
   13e70:      	callq	0x53d80 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   13e75:      	cmpb	$0x0, 0x8(%rsp)
   13e7a:      	xorpd	%xmm0, %xmm0
   13e7e:      	jne	0x13eb6 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0+0xa6>
   13e80:      	movsd	0x10(%rsp), %xmm1
   13e86:      	unpcklps	-0xf8cd(%rip), %xmm1    # xmm1 = xmm1[0],mem[0],xmm1[1],mem[1]
                                                # 0x45c0 <writev+0x45c0>
   13e8d:      	subpd	-0xf925(%rip), %xmm1    # 0x4570 <writev+0x4570>
   13e95:      	movapd	%xmm1, %xmm2
   13e99:      	unpckhpd	%xmm1, %xmm2            # xmm2 = xmm2[1],xmm1[1]
   13e9d:      	xorps	%xmm0, %xmm0
   13ea0:      	cvtsi2sdl	0x18(%rsp), %xmm0
   13ea6:      	addsd	%xmm1, %xmm2
   13eaa:      	divsd	-0xf6c2(%rip), %xmm0    # 0x47f0 <writev+0x47f0>
   13eb2:      	addsd	%xmm2, %xmm0
   13eb6:      	movsd	%xmm0, 0x30(%rsp)
   13ebc:      	cmpq	$0x1, %rbx
   13ec0:      	jne	0x13f23 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0+0x113>
   13ec2:      	leaq	0x28(%rsp), %rax
   13ec7:      	movq	%rax, 0x8(%rsp)
   13ecc:      	leaq	0x6b7d(%rip), %rax      # 0x1aa50 <<i64 as core::fmt::Display>::fmt>
   13ed3:      	movq	%rax, 0x10(%rsp)
   13ed8:      	movq	%r14, 0x18(%rsp)
   13edd:      	leaq	0x8a4c(%rip), %rax      # 0x1c930 <<f64 as core::fmt::Display>::fmt>
   13ee4:      	movq	%rax, 0x20(%rsp)
   13ee9:      	leaq	-0xdc1c(%rip), %rdi     # 0x62d4 <writev+0x62d4>
   13ef0:      	leaq	0x8(%rsp), %rsi
   13ef5:      	callq	0x58cd0 <std::io::stdio::_print>
   13efa:      	leaq	0x8(%rsp), %rdi
   13eff:      	callq	0x27370 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13f04:      	movq	0x8(%rsp), %rbx
   13f09:      	testq	%rbx, %rbx
   13f0c:      	jle	0x13f19 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0+0x109>
   13f0e:      	movq	0x10(%rsp), %rdi
   13f13:      	callq	*0x4c51f(%rip)          # 0x60438 <writev+0x60438>
   13f19:      	xorl	%eax, %eax
   13f1b:      	negq	%rbx
   13f1e:      	setno	%al
   13f21:      	jmp	0x13f45 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0+0x135>
   13f23:      	leaq	0x8(%rsp), %rdi
   13f28:      	callq	0x27370 <snail_runtime::strict_io::release_all::h2af89b8c3a0cb731>
   13f2d:      	cmpq	$0x0, 0x8(%rsp)
   13f33:      	jle	0x13f40 <wasm_native_77022da04e6143b264cdfa2f5f210793dab3e32afd087db8136c526f776cc4a6::run::h2052e280fcd522a0+0x130>
   13f35:      	movq	0x10(%rsp), %rdi
   13f3a:      	callq	*0x4c4f8(%rip)          # 0x60438 <writev+0x60438>
   13f40:      	movl	$0x1, %eax
   13f45:      	addq	$0x50, %rsp
   13f49:      	popq	%rbx
   13f4a:      	popq	%r14
   13f4c:      	popq	%rbp
   13f4d:      	retq
   13f4e:      	int3
   13f4f:      	int3
