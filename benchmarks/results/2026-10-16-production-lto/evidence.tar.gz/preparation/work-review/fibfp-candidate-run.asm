000000000004acd0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30>:
   4acd0:      	pushq	%rbp
   4acd1:      	pushq	%r15
   4acd3:      	pushq	%r14
   4acd5:      	pushq	%r13
   4acd7:      	pushq	%r12
   4acd9:      	pushq	%rbx
   4acda:      	subq	$0x3c8, %rsp            # imm = 0x3C8
   4ace1:      	cmpq	$0x0, 0x37067(%rip)     # 0x81d50 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4ace9:      	jne	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4acef:      	movl	$0x108, %edi            # imm = 0x108
   4acf4:      	callq	*0x3555e(%rip)          # 0x80258 <writev+0x80258>
   4acfa:      	testq	%rax, %rax
   4acfd:      	je	0x4bd5c <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x108c>
   4ad03:      	movq	%rax, %r14
   4ad06:      	movq	$0x0, (%rax)
   4ad0d:      	movq	$0x4, 0x8(%rax)
   4ad15:      	movq	$0x0, 0x10(%rax)
   4ad1d:      	movl	$0x4, %ebx
   4ad22:      	movl	$0x4, %edi
   4ad27:      	callq	*0x3552b(%rip)          # 0x80258 <writev+0x80258>
   4ad2d:      	testq	%rax, %rax
   4ad30:      	je	0x4bd54 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1084>
   4ad36:      	movl	$0x2, (%rax)
   4ad3c:      	movq	$0x1, 0x18(%r14)
   4ad44:      	movq	%rax, 0x20(%r14)
   4ad48:      	movq	$0x1, 0x28(%r14)
   4ad50:      	movl	$0x4, %ebx
   4ad55:      	movl	$0x4, %edi
   4ad5a:      	callq	*0x354f8(%rip)          # 0x80258 <writev+0x80258>
   4ad60:      	testq	%rax, %rax
   4ad63:      	je	0x4bd54 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1084>
   4ad69:      	movl	$0x2, (%rax)
   4ad6f:      	movq	$0x1, 0x30(%r14)
   4ad77:      	movq	%rax, 0x38(%r14)
   4ad7b:      	movq	$0x1, 0x40(%r14)
   4ad83:      	movq	$0x0, 0x48(%r14)
   4ad8b:      	movq	$0x4, 0x50(%r14)
   4ad93:      	xorps	%xmm0, %xmm0
   4ad96:      	movups	%xmm0, 0x58(%r14)
   4ad9b:      	movq	$0x4, 0x68(%r14)
   4ada3:      	movups	%xmm0, 0x70(%r14)
   4ada8:      	movq	$0x4, 0x80(%r14)
   4adb3:      	movq	$0x0, 0x88(%r14)
   4adbe:      	movl	$0x8, %ebx
   4adc3:      	movl	$0x8, %edi
   4adc8:      	callq	*0x3548a(%rip)          # 0x80258 <writev+0x80258>
   4adce:      	testq	%rax, %rax
   4add1:      	je	0x4bd54 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1084>
   4add7:      	movabsq	$0x200000001, %rcx      # imm = 0x200000001
   4ade1:      	movq	%rcx, (%rax)
   4ade4:      	movq	$0x2, 0x90(%r14)
   4adef:      	movq	%rax, 0x98(%r14)
   4adf6:      	movq	$0x2, 0xa0(%r14)
   4ae01:      	movq	$0x0, 0xa8(%r14)
   4ae0c:      	movq	$0x4, 0xb0(%r14)
   4ae17:      	xorps	%xmm0, %xmm0
   4ae1a:      	movups	%xmm0, 0xb8(%r14)
   4ae22:      	movq	$0x4, 0xc8(%r14)
   4ae2d:      	movups	%xmm0, 0xd0(%r14)
   4ae35:      	movq	$0x4, 0xe0(%r14)
   4ae40:      	movups	%xmm0, 0xe8(%r14)
   4ae48:      	movq	$0x4, 0xf8(%r14)
   4ae53:      	movq	$0x0, 0x100(%r14)
   4ae5e:      	movl	$0x18, %edi
   4ae63:      	callq	*0x353ef(%rip)          # 0x80258 <writev+0x80258>
   4ae69:      	testq	%rax, %rax
   4ae6c:      	je	0x4bd66 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1096>
   4ae72:      	movq	%rax, %r15
   4ae75:      	movq	0x35114(%rip), %rax     # 0x7ff90 <native_gc_globals+0x10>
   4ae7c:      	movq	%rax, 0x10(%r15)
   4ae80:      	movapd	0x350f8(%rip), %xmm0    # 0x7ff80 <native_gc_globals>
   4ae88:      	movupd	%xmm0, (%r15)
   4ae8d:      	movl	$0x1, %edi
   4ae92:      	movl	$0x58, %esi
   4ae97:      	callq	*0x35313(%rip)          # 0x801b0 <writev+0x801b0>
   4ae9d:      	testq	%rax, %rax
   4aea0:      	je	0x4bd70 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10a0>
   4aea6:      	movq	%rax, %rbp
   4aea9:      	movabsq	$0x3fffffffffff8000, %r13 # imm = 0x3FFFFFFFFFFF8000
   4aeb3:      	leaq	-0x425ef(%rip), %rsi    # 0x88cb <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4aeba:      	leaq	0x80(%rsp), %rdi
   4aec2:      	movl	$0x13, %edx
   4aec7:      	callq	0x53f30 <std::env::_var_os>
   4aecc:      	movq	0x80(%rsp), %rax
   4aed4:      	negq	%rax
   4aed7:      	jo	0x4af1b <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x24b>
   4aed9:      	jae	0x4aee9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x219>
   4aedb:      	movq	0x88(%rsp), %rdi
   4aee3:      	callq	*0x352cf(%rip)          # 0x801b8 <writev+0x801b8>
   4aee9:      	leaq	-0x42625(%rip), %rdi    # 0x88cb <core::num::flt2dec::strategy::dragon::POW5TO256+0x5f7>
   4aef0:      	movl	$0x13, %esi
   4aef5:      	xorl	%edx, %edx
   4aef7:      	callq	0x54120 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4aefc:      	movq	%rax, %rdx
   4aeff:      	addq	$-0x8000, %rax          # imm = 0x8000
   4af05:      	cmpq	%r13, %rax
   4af08:      	jae	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4af0e:      	andq	%r13, %rdx
   4af11:      	movq	%rdx, %rbx
   4af14:      	movq	%rdx, 0x18(%rsp)
   4af19:      	jmp	0x4af2c <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x25c>
   4af1b:      	movl	$0x10000000, %edx       # imm = 0x10000000
   4af20:      	movq	$0x0, 0x18(%rsp)
   4af29:      	movq	%r13, %rbx
   4af2c:      	leaq	-0x42655(%rip), %rdi    # 0x88de <core::num::flt2dec::strategy::dragon::POW5TO256+0x60a>
   4af33:      	movl	$0x16, %esi
   4af38:      	callq	0x54120 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4af3d:      	movq	%rax, %r12
   4af40:      	addq	$-0x8000, %rax          # imm = 0x8000
   4af46:      	cmpq	%r13, %rax
   4af49:      	jae	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4af4f:      	movq	%rbp, 0x38(%rsp)
   4af54:      	andq	%r13, %r12
   4af57:      	cmpq	%rbx, %r12
   4af5a:      	ja	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4af60:      	leaq	-0x42673(%rip), %rdi    # 0x88f4 <core::num::flt2dec::strategy::dragon::POW5TO256+0x620>
   4af67:      	movl	$0x12, %esi
   4af6c:      	movl	$0x800000, %edx         # imm = 0x800000
   4af71:      	callq	0x54120 <snail_runtime::native_gc::configured_bytes::h91a7e7f596420922>
   4af76:      	movq	%rax, %r13
   4af79:      	leaq	-0x4267a(%rip), %rsi    # 0x8906 <core::num::flt2dec::strategy::dragon::POW5TO256+0x632>
   4af80:      	leaq	0x80(%rsp), %rdi
   4af88:      	movl	$0xe, %edx
   4af8d:      	callq	0x53f30 <std::env::_var_os>
   4af92:      	movq	0x80(%rsp), %rax
   4af9a:      	movq	%rax, %rcx
   4af9d:      	negq	%rcx
   4afa0:      	setno	%bpl
   4afa4:      	testq	%rax, %rax
   4afa7:      	jle	0x4afb7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x2e7>
   4afa9:      	movq	0x88(%rsp), %rdi
   4afb1:      	callq	*0x35201(%rip)          # 0x801b8 <writev+0x801b8>
   4afb7:      	movq	$0x0, 0x80(%rsp)
   4afc3:      	movq	$0x8, 0x88(%rsp)
   4afcf:      	xorpd	%xmm0, %xmm0
   4afd3:      	movupd	%xmm0, 0x90(%rsp)
   4afdc:      	movupd	%xmm0, 0x138(%rsp)
   4afe5:      	movupd	%xmm0, 0x148(%rsp)
   4afee:      	movupd	%xmm0, 0x158(%rsp)
   4aff7:      	movq	%r12, 0x110(%rsp)
   4afff:      	movq	%rbx, 0x118(%rsp)
   4b007:      	movq	0x18(%rsp), %rax
   4b00c:      	movq	%rax, 0x120(%rsp)
   4b014:      	movq	%r13, 0x128(%rsp)
   4b01c:      	movb	%bpl, 0x130(%rsp)
   4b024:      	movq	%r13, 0x168(%rsp)
   4b02c:      	movq	$0x8, 0xa0(%rsp)
   4b038:      	movupd	%xmm0, 0xa8(%rsp)
   4b041:      	movq	$0x8, 0xb8(%rsp)
   4b04d:      	movq	$0x0, 0xc0(%rsp)
   4b059:      	movq	$0xb, 0xc8(%rsp)
   4b065:      	movq	%r14, 0xd0(%rsp)
   4b06d:      	movq	$0xb, 0xd8(%rsp)
   4b079:      	movq	$0x3, 0xe0(%rsp)
   4b085:      	movq	%r15, 0xe8(%rsp)
   4b08d:      	movq	$0x3, 0xf0(%rsp)
   4b099:      	movq	$0x0, 0xf8(%rsp)
   4b0a5:      	movq	$0x8, 0x100(%rsp)
   4b0b1:      	movq	$0x0, 0x108(%rsp)
   4b0bd:      	movupd	%xmm0, 0x1c0(%rsp)
   4b0c6:      	movupd	%xmm0, 0x1b0(%rsp)
   4b0cf:      	movupd	%xmm0, 0x1a0(%rsp)
   4b0d8:      	movupd	%xmm0, 0x190(%rsp)
   4b0e1:      	movupd	%xmm0, 0x180(%rsp)
   4b0ea:      	movupd	%xmm0, 0x170(%rsp)
   4b0f3:      	movq	$0x0, 0x1d0(%rsp)
   4b0ff:      	leaq	0x80(%rsp), %rdi
   4b107:      	movq	%r12, %rsi
   4b10a:      	callq	0x54370 <snail_runtime::native_gc::Collector::add_region::h9dcdb0f5d1e85429>
   4b10f:      	movq	0x80(%rsp), %rbp
   4b117:      	movq	0x88(%rsp), %rcx
   4b11f:      	movq	%rcx, 0x28(%rsp)
   4b124:      	movq	0x90(%rsp), %r15
   4b12c:      	movq	0x98(%rsp), %rcx
   4b134:      	movq	%rcx, 0x68(%rsp)
   4b139:      	movq	0xa0(%rsp), %rcx
   4b141:      	movq	%rcx, 0x40(%rsp)
   4b146:      	movq	0xb0(%rsp), %rcx
   4b14e:      	movq	%rcx, 0x70(%rsp)
   4b153:      	movq	0xb8(%rsp), %rcx
   4b15b:      	movq	%rcx, 0x48(%rsp)
   4b160:      	movq	0xc8(%rsp), %rcx
   4b168:      	movq	%rcx, 0x78(%rsp)
   4b16d:      	movq	0xd0(%rsp), %rcx
   4b175:      	movq	%rcx, 0x30(%rsp)
   4b17a:      	movq	0xd8(%rsp), %rcx
   4b182:      	movq	%rcx, 0x58(%rsp)
   4b187:      	movq	0xe0(%rsp), %rcx
   4b18f:      	movq	%rcx, 0x18(%rsp)
   4b194:      	movq	0xe8(%rsp), %r13
   4b19c:      	movq	0xf8(%rsp), %r14
   4b1a4:      	movq	0x100(%rsp), %r12
   4b1ac:      	testb	%al, %al
   4b1ae:      	movq	%r13, 0x50(%rsp)
   4b1b3:      	movq	%rbp, 0x60(%rsp)
   4b1b8:      	je	0x4bd7a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10aa>
   4b1be:      	movabsq	$-0x8000000000000000, %rbx # imm = 0x8000000000000000
   4b1c8:      	leaq	0x108(%rsp), %rsi
   4b1d0:      	movq	0xf0(%rsp), %rax
   4b1d8:      	movq	%rax, 0x210(%rsp)
   4b1e0:      	movq	0xa8(%rsp), %rax
   4b1e8:      	movq	%rax, 0x200(%rsp)
   4b1f0:      	movq	0xc0(%rsp), %rax
   4b1f8:      	movq	%rax, 0x208(%rsp)
   4b200:      	leaq	0x228(%rsp), %rdi
   4b208:      	movl	$0xd0, %edx
   4b20d:      	callq	*0x3513d(%rip)          # 0x80350 <writev+0x80350>
   4b213:      	cmpq	%rbx, %rbp
   4b216:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b21c:      	leaq	0x2f8(%rsp), %rdi
   4b224:      	leaq	0x228(%rsp), %rsi
   4b22c:      	movl	$0xd0, %edx
   4b231:      	callq	*0x35119(%rip)          # 0x80350 <writev+0x80350>
   4b237:      	movupd	-0x42714(%rip), %xmm0   # 0x8b2b <core::num::flt2dec::strategy::dragon::POW5TO256+0x857>
   4b23f:      	movapd	%xmm0, 0x80(%rsp)
   4b248:      	movabsq	$0x4c41565245544e49, %rax # imm = 0x4C41565245544E49
   4b252:      	movq	%rax, 0x90(%rsp)
   4b25a:      	movb	$0x0, 0x98(%rsp)
   4b262:      	movb	$0x1, %al
   4b264:      	testb	%al, %al
   4b266:      	je	0x4b274 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x5a4>
   4b268:      	movabsq	$0x414e5f4c49414e53, %rax # imm = 0x414E5F4C49414E53
   4b272:      	jmp	0x4b297 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x5c7>
   4b274:      	xorl	%eax, %eax
   4b276:      	nopw	%cs:(%rax,%rax)
   4b280:      	cmpb	$0x0, 0x80(%rsp,%rax)
   4b288:      	je	0x4b303 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x633>
   4b28a:      	incq	%rax
   4b28d:      	jne	0x4b280 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x5b0>
   4b28f:      	movq	0x80(%rsp), %rax
   4b297:      	movq	0x88(%rsp), %rcx
   4b29f:      	movabsq	$0x101010101010100, %rdx # imm = 0x101010101010100
   4b2a9:      	movq	%rdx, %rsi
   4b2ac:      	subq	%rax, %rsi
   4b2af:      	orq	%rax, %rsi
   4b2b2:      	subq	%rcx, %rdx
   4b2b5:      	orq	%rcx, %rdx
   4b2b8:      	andq	%rsi, %rdx
   4b2bb:      	notq	%rdx
   4b2be:      	movabsq	$-0x7f7f7f7f7f7f7f80, %rax # imm = 0x8080808080808080
   4b2c8:      	xorl	%ecx, %ecx
   4b2ca:      	testq	%rax, %rdx
   4b2cd:      	sete	%cl
   4b2d0:      	shll	$0x4, %ecx
   4b2d3:      	leaq	(%rsp,%rcx), %rdx
   4b2d7:      	addq	$0x80, %rdx
   4b2de:      	movq	%rcx, %rsi
   4b2e1:      	xorq	$0x19, %rsi
   4b2e5:      	xorl	%eax, %eax
   4b2e7:      	nopw	(%rax,%rax)
   4b2f0:      	cmpb	$0x0, (%rdx,%rax)
   4b2f4:      	je	0x4b300 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x630>
   4b2f6:      	incq	%rax
   4b2f9:      	cmpq	%rax, %rsi
   4b2fc:      	jne	0x4b2f0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x620>
   4b2fe:      	jmp	0x4b347 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x677>
   4b300:      	addq	%rcx, %rax
   4b303:      	cmpq	$0x18, %rax
   4b307:      	jne	0x4b347 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x677>
   4b309:      	movq	%r12, 0x10(%rsp)
   4b30e:      	leaq	0x228(%rsp), %rdi
   4b316:      	leaq	0x80(%rsp), %rsi
   4b31e:      	callq	0x45f00 <std::sys::env::unix::getenv::{closure#0}>
   4b323:      	movq	0x228(%rsp), %r12
   4b32b:      	leaq	0x1(%rbx), %rax
   4b32f:      	cmpq	%rax, %r12
   4b332:      	jne	0x4b98e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xcbe>
   4b338:      	movq	0x230(%rsp), %rax
   4b340:      	movq	0x10(%rsp), %r12
   4b345:      	jmp	0x4b35a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x68a>
   4b347:      	leaq	0x1(%rbx), %rax
   4b34b:      	movq	%rax, 0x228(%rsp)
   4b353:      	leaq	0x340e6(%rip), %rax     # 0x7f440 <writev+0x7f440>
   4b35a:      	movl	%eax, %ecx
   4b35c:      	andl	$0x3, %ecx
   4b35f:      	leal	-0x2(%rcx), %edx
   4b362:      	cmpl	$0x2, %edx
   4b365:      	jb	0x4b3a5 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d5>
   4b367:      	testq	%rcx, %rcx
   4b36a:      	je	0x4b3a5 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d5>
   4b36c:      	leaq	-0x1(%rax), %rcx
   4b370:      	movq	%rcx, 0x10(%rsp)
   4b375:      	movq	-0x1(%rax), %r13
   4b379:      	movq	0x7(%rax), %rbx
   4b37d:      	movq	(%rbx), %rax
   4b380:      	testq	%rax, %rax
   4b383:      	je	0x4b38a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6ba>
   4b385:      	movq	%r13, %rdi
   4b388:      	callq	*%rax
   4b38a:      	cmpq	$0x0, 0x8(%rbx)
   4b38f:      	je	0x4b39a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6ca>
   4b391:      	movq	%r13, %rdi
   4b394:      	callq	*0x34e1e(%rip)          # 0x801b8 <writev+0x801b8>
   4b39a:      	movq	0x10(%rsp), %rdi
   4b39f:      	callq	*0x34e13(%rip)          # 0x801b8 <writev+0x801b8>
   4b3a5:      	xorl	%r13d, %r13d
   4b3a8:      	movl	$0x180, %edi            # imm = 0x180
   4b3ad:      	callq	*0x34ea5(%rip)          # 0x80258 <writev+0x80258>
   4b3b3:      	testq	%rax, %rax
   4b3b6:      	je	0x4baf7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe27>
   4b3bc:      	movq	%rax, %rbx
   4b3bf:      	movq	0x60(%rsp), %rcx
   4b3c4:      	movq	%rcx, (%rax)
   4b3c7:      	movq	0x28(%rsp), %rcx
   4b3cc:      	movq	%rcx, 0x8(%rax)
   4b3d0:      	movq	%r15, 0x10(%rax)
   4b3d4:      	movq	0x68(%rsp), %rcx
   4b3d9:      	movq	%rcx, 0x18(%rax)
   4b3dd:      	movq	0x40(%rsp), %rcx
   4b3e2:      	movq	%rcx, 0x20(%rax)
   4b3e6:      	movq	0x200(%rsp), %rcx
   4b3ee:      	movq	%rcx, 0x28(%rax)
   4b3f2:      	movq	0x70(%rsp), %rcx
   4b3f7:      	movq	%rcx, 0x30(%rax)
   4b3fb:      	movq	0x48(%rsp), %rcx
   4b400:      	movq	%rcx, 0x38(%rax)
   4b404:      	movq	0x208(%rsp), %rcx
   4b40c:      	movq	%rcx, 0x40(%rax)
   4b410:      	movq	0x78(%rsp), %rcx
   4b415:      	movq	%rcx, 0x48(%rax)
   4b419:      	movq	0x30(%rsp), %rcx
   4b41e:      	movq	%rcx, 0x50(%rax)
   4b422:      	movq	0x58(%rsp), %rcx
   4b427:      	movq	%rcx, 0x58(%rax)
   4b42b:      	movq	0x18(%rsp), %rcx
   4b430:      	movq	%rcx, 0x60(%rax)
   4b434:      	movq	0x50(%rsp), %rcx
   4b439:      	movq	%rcx, 0x68(%rax)
   4b43d:      	movq	0x210(%rsp), %rcx
   4b445:      	movq	%rcx, 0x70(%rax)
   4b449:      	movq	%r14, 0x78(%rax)
   4b44d:      	movq	%r12, 0x80(%rax)
   4b454:      	addq	$0x88, %rax
   4b45a:      	leaq	0x2f8(%rsp), %rsi
   4b462:      	movl	$0xd0, %edx
   4b467:      	movq	%rax, %rdi
   4b46a:      	callq	*0x34ee0(%rip)          # 0x80350 <writev+0x80350>
   4b470:      	movq	$0xb, 0x158(%rbx)
   4b47b:      	movq	0x38(%rsp), %rax
   4b480:      	movq	%rax, 0x160(%rbx)
   4b487:      	movq	$0xb, 0x168(%rbx)
   4b492:      	movq	$0x0, 0x170(%rbx)
   4b49d:      	movq	%r13, 0x178(%rbx)
   4b4a4:      	movq	%rbx, 0x368a5(%rip)     # 0x81d50 <snail_runtime::native::RUNTIME::h50270cf9a4c3f47c (.0)>
   4b4ab:      	leaq	0x90ae(%rip), %rdi      # 0x54560 <snail_runtime::native::report_statistics::hf13e5e332de61a4a>
   4b4b2:      	callq	0x11d70 <atexit>
   4b4b7:      	movq	$0x2, 0x88(%rsp)
   4b4c3:      	movq	$0x0, 0x90(%rsp)
   4b4cf:      	movq	0x36882(%rip), %rax     # 0x81d58 <native_roots.0>
   4b4d6:      	movq	%rax, 0x80(%rsp)
   4b4de:      	movq	0x36853(%rip), %rax     # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b4e5:      	incq	%rax
   4b4e8:      	movq	%rax, 0x36849(%rip)     # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b4ef:      	movq	0x3684a(%rip), %rcx     # 0x81d40 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b4f6:      	cmpq	%rcx, %rax
   4b4f9:      	cmovbeq	%rcx, %rax
   4b4fd:      	leaq	0x80(%rsp), %r14
   4b505:      	movq	%r14, 0x3684c(%rip)     # 0x81d58 <native_roots.0>
   4b50c:      	movq	%rax, 0x3682d(%rip)     # 0x81d40 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b513:      	cmpl	$0x0, 0x3690a(%rip)     # 0x81e24 <g.0>
   4b51a:      	jne	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b520:      	movl	$0x1, 0x368fa(%rip)     # 0x81e24 <g.0>
   4b52a:      	movq	$0x0, 0x98(%rsp)
   4b536:      	leaq	0x34a2b(%rip), %rbx     # 0x7ff68 <ref.3>
   4b53d:      	movq	%rbx, 0xa0(%rsp)
   4b545:      	movq	$0x2, 0x90(%rsp)
   4b551:      	movl	$0x18, %edi
   4b556:      	callq	0x55430 <native_alloc>
   4b55b:      	movq	$0x1e, (%rax)
   4b562:      	movq	%rbx, 0x8(%rax)
   4b566:      	movq	$0x0, 0x10(%rax)
   4b56e:      	movq	%rax, 0x368b3(%rip)     # 0x81e28 <g.1>
   4b575:      	movb	$0x1, 0x368b4(%rip)     # 0x81e30 <g.2>
   4b57c:      	movq	$0x0, 0x90(%rsp)
   4b588:      	movl	$0x8, %edi
   4b58d:      	callq	0x55430 <native_alloc>
   4b592:      	movq	$0x1a, (%rax)
   4b599:      	movq	%rax, 0x36898(%rip)     # 0x81e38 <g.3>
   4b5a0:      	movb	$0x1, 0x36899(%rip)     # 0x81e40 <g.4>
   4b5a7:      	movq	$0x0, 0x90(%rsp)
   4b5b3:      	movabsq	$0x4041800000000000, %rax # imm = 0x4041800000000000
   4b5bd:      	movq	%rax, 0x228(%rsp)
   4b5c5:      	leaq	0x228(%rsp), %rax
   4b5cd:      	movsd	0x228(%rsp), %xmm0
   4b5d6:      	movsd	%xmm0, 0x3686a(%rip)    # 0x81e48 <g.5>
   4b5de:      	movb	$0x1, 0x3686b(%rip)     # 0x81e50 <g.6>
   4b5e5:      	movq	$0x0, 0x90(%rsp)
   4b5f1:      	movl	$0x8, %edi
   4b5f6:      	callq	0x55430 <native_alloc>
   4b5fb:      	movq	$0x16, (%rax)
   4b602:      	movq	%rax, 0x3684f(%rip)     # 0x81e58 <g.7>
   4b609:      	movl	$0x2, 0x36811(%rip)     # 0x81e24 <g.0>
   4b613:      	cmpq	$0x0, 0x88(%rsp)
   4b61c:      	je	0x4b634 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x964>
   4b61e:      	movq	0x80(%rsp), %rax
   4b626:      	movq	%rax, 0x3672b(%rip)     # 0x81d58 <native_roots.0>
   4b62d:      	decq	0x36704(%rip)           # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b634:      	callq	0x4c040 <<std::sys::pal::unix::time::Timespec>::now>
   4b639:      	movq	%rax, %rbx
   4b63c:      	movq	$0x5, 0x88(%rsp)
   4b648:      	movq	$0x0, 0x90(%rsp)
   4b654:      	movq	0x366fd(%rip), %rax     # 0x81d58 <native_roots.0>
   4b65b:      	movq	%rax, 0x80(%rsp)
   4b663:      	movq	%r14, 0x366ee(%rip)     # 0x81d58 <native_roots.0>
   4b66a:      	movq	0x366c7(%rip), %rax     # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b671:      	incq	%rax
   4b674:      	movq	%rax, 0x366bd(%rip)     # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b67b:      	movq	0x366be(%rip), %rcx     # 0x81d40 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b682:      	cmpq	%rcx, %rax
   4b685:      	cmovbeq	%rcx, %rax
   4b689:      	movq	%rax, 0x366b0(%rip)     # 0x81d40 <snail_runtime::native::PEAK_ROOT_DEPTH::h5c0c732147fd4058 (.0)>
   4b690:      	xorpd	%xmm0, %xmm0
   4b694:      	movupd	%xmm0, 0x98(%rsp)
   4b69d:      	cmpl	$0x2, 0x36780(%rip)     # 0x81e24 <g.0>
   4b6a4:      	jne	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b6aa:      	cmpq	$0x0, 0x367a6(%rip)     # 0x81e58 <g.7>
   4b6b2:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b6b8:      	movl	%edx, %ebp
   4b6ba:      	movq	$0x2, 0x90(%rsp)
   4b6c6:      	movl	$0x18, %edi
   4b6cb:      	callq	0x55430 <native_alloc>
   4b6d0:      	movq	%rax, %r14
   4b6d3:      	movq	$0xa, (%rax)
   4b6da:      	movl	$0x0, 0x8(%rax)
   4b6e1:      	movq	$0x0, 0x10(%rax)
   4b6e9:      	movq	%rax, 0x98(%rsp)
   4b6f1:      	movq	%rax, 0xa8(%rsp)
   4b6f9:      	leaq	0x34858(%rip), %r12     # 0x7ff58 <ref.2>
   4b700:      	movq	%r12, 0xb0(%rsp)
   4b708:      	movq	%rax, 0xb8(%rsp)
   4b710:      	movq	$0x5, 0x90(%rsp)
   4b71c:      	movl	$0x18, %edi
   4b721:      	callq	0x55430 <native_alloc>
   4b726:      	movq	%rax, %r15
   4b729:      	movq	$0xe, (%rax)
   4b730:      	movq	$0xa, 0x8(%rax)
   4b738:      	movq	%r14, 0x10(%rax)
   4b73c:      	movq	%rax, 0xa8(%rsp)
   4b744:      	movq	%r12, 0xb0(%rsp)
   4b74c:      	movq	%r14, 0xb8(%rsp)
   4b754:      	movq	$0x5, 0x90(%rsp)
   4b760:      	movl	$0x18, %edi
   4b765:      	callq	0x55430 <native_alloc>
   4b76a:      	movq	$0x1e, (%rax)
   4b771:      	movq	%r12, 0x8(%rax)
   4b775:      	movq	%r15, 0x10(%rax)
   4b779:      	movq	%rax, 0x10(%r14)
   4b77d:      	movq	0x98(%rsp), %rax
   4b785:      	testq	%rax, %rax
   4b788:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b78e:      	movl	$0x1, 0x8(%rax)
   4b795:      	movq	0x98(%rsp), %rax
   4b79d:      	testq	%rax, %rax
   4b7a0:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b7a6:      	cmpl	$0x0, 0x8(%rax)
   4b7aa:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b7b0:      	movq	0x10(%rax), %rax
   4b7b4:      	testq	%rax, %rax
   4b7b7:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b7bd:      	movq	%rax, 0xa0(%rsp)
   4b7c5:      	movq	0x8(%rax), %rcx
   4b7c9:      	testq	%rcx, %rcx
   4b7cc:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4b7d2:      	movq	0x10(%rax), %rdi
   4b7d6:      	movq	0x8(%rcx), %rax
   4b7da:      	cmpq	$0x0, 0x88(%rsp)
   4b7e3:      	je	0x4b7fb <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xb2b>
   4b7e5:      	movq	0x80(%rsp), %rcx
   4b7ed:      	movq	%rcx, 0x36564(%rip)     # 0x81d58 <native_roots.0>
   4b7f4:      	decq	0x3653d(%rip)           # 0x81d38 <snail_runtime::native::ROOT_DEPTH::h41871087dd265bba (.0)>
   4b7fb:      	xorpd	%xmm0, %xmm0
   4b7ff:      	xorl	%esi, %esi
   4b801:      	callq	*%rax
   4b803:      	subq	$0x8, %rsp
   4b807:      	movsd	%xmm0, 0x18(%rsp)
   4b80d:      	movsd	%xmm0, 0x218(%rsp)
   4b816:      	callq	0x4c040 <<std::sys::pal::unix::time::Timespec>::now>
   4b81b:      	movq	%rax, 0x2f8(%rsp)
   4b823:      	movl	%edx, 0x300(%rsp)
   4b82a:      	movq	%rbx, 0x228(%rsp)
   4b832:      	movl	%ebp, 0x230(%rsp)
   4b839:      	leaq	0x80(%rsp), %rdi
   4b841:      	leaq	0x2f8(%rsp), %rbx
   4b849:      	leaq	0x228(%rsp), %rdx
   4b851:      	movq	%rbx, %rsi
   4b854:      	callq	0x4c110 <<std::sys::pal::unix::time::Timespec>::sub_timespec>
   4b859:      	xorpd	%xmm2, %xmm2
   4b85d:      	cmpb	$0x0, 0x80(%rsp)
   4b865:      	jne	0x4b8a3 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xbd3>
   4b867:      	movsd	0x88(%rsp), %xmm0
   4b870:      	unpcklps	-0x47d17(%rip), %xmm0   # xmm0 = xmm0[0],mem[0],xmm0[1],mem[1]
                                                # 0x3b60 <writev+0x3b60>
   4b877:      	subpd	-0x47d7f(%rip), %xmm0   # 0x3b00 <writev+0x3b00>
   4b87f:      	movapd	%xmm0, %xmm1
   4b883:      	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
   4b887:      	xorps	%xmm2, %xmm2
   4b88a:      	cvtsi2sdl	0x90(%rsp), %xmm2
   4b893:      	addsd	%xmm0, %xmm1
   4b897:      	divsd	-0x461c7(%rip), %xmm2   # 0x56d8 <writev+0x56d8>
   4b89f:      	addsd	%xmm1, %xmm2
   4b8a3:      	movsd	0x18(%rsp), %xmm0
   4b8a9:      	ucomisd	-0x461a1(%rip), %xmm0   # 0x5710 <writev+0x5710>
   4b8b1:      	movsd	%xmm2, 0x220(%rsp)
   4b8ba:      	jne	0x4b95e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xc8e>
   4b8c0:      	jp	0x4b95e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xc8e>
   4b8c6:      	leaq	0x218(%rsp), %rax
   4b8ce:      	movq	%rax, 0x228(%rsp)
   4b8d6:      	leaq	0x1213(%rip), %rax      # 0x4caf0 <<f64 as core::fmt::Display>::fmt>
   4b8dd:      	movq	%rax, 0x230(%rsp)
   4b8e5:      	leaq	0x220(%rsp), %rcx
   4b8ed:      	movq	%rcx, 0x238(%rsp)
   4b8f5:      	movq	%rax, 0x240(%rsp)
   4b8fd:      	leaq	-0x422dd(%rip), %rax    # 0x9627 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1353>
   4b904:      	movq	%rax, 0x2f8(%rsp)
   4b90c:      	movq	$0x6, 0x300(%rsp)
   4b918:      	movl	0x35aaa(%rip), %eax     # 0x813c8 <std::io::stdio::STDOUT+0x38>
   4b91e:      	testl	%eax, %eax
   4b920:      	jne	0x4bb01 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe31>
   4b926:      	movq	%fs:-0x8, %r14
   4b92f:      	testq	%r14, %r14
   4b932:      	je	0x4bb18 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe48>
   4b938:      	movq	0x35a51(%rip), %rax     # 0x81390 <std::io::stdio::STDOUT>
   4b93f:      	cmpq	%rax, %r14
   4b942:      	jne	0x4bb52 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe82>
   4b948:      	movl	0x35a4e(%rip), %ebp     # 0x8139c <std::io::stdio::STDOUT+0xc>
   4b94e:      	cmpl	$-0x1, %ebp
   4b951:      	je	0x4bcb9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xfe9>
   4b957:      	incl	%ebp
   4b959:      	jmp	0x4bb6e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe9e>
   4b95e:      	leaq	0x80(%rsp), %rdi
   4b966:      	callq	0x4c1e0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4b96b:      	cmpq	$0x0, 0x80(%rsp)
   4b974:      	jle	0x4b984 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xcb4>
   4b976:      	movq	0x88(%rsp), %rdi
   4b97e:      	callq	*0x34834(%rip)          # 0x801b8 <writev+0x801b8>
   4b984:      	movl	$0x1, %eax
   4b989:      	jmp	0x4bca2 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xfd2>
   4b98e:      	cmpq	%rbx, %r12
   4b991:      	jne	0x4b9a0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xcd0>
   4b993:      	xorl	%r13d, %r13d
   4b996:      	movq	0x10(%rsp), %r12
   4b99b:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4b9a0:      	movq	0x230(%rsp), %rbx
   4b9a8:      	movq	0x238(%rsp), %rbp
   4b9b0:      	leaq	0x80(%rsp), %rdi
   4b9b8:      	movq	%rbx, %rsi
   4b9bb:      	movq	%rbp, %rdx
   4b9be:      	callq	0x199e0 <core::str::converts::from_utf8>
   4b9c3:      	cmpb	$0x0, 0x80(%rsp)
   4b9cb:      	je	0x4b9e3 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xd13>
   4b9cd:      	xorl	%r13d, %r13d
   4b9d0:      	testq	%r12, %r12
   4b9d3:      	movq	0x10(%rsp), %r12
   4b9d8:      	jg	0x4bad7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe07>
   4b9de:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4b9e3:      	testq	%rbp, %rbp
   4b9e6:      	je	0x4ba08 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xd38>
   4b9e8:      	cmpq	$0x1, %rbp
   4b9ec:      	jne	0x4ba1e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xd4e>
   4b9ee:      	movzbl	(%rbx), %eax
   4b9f1:      	xorl	%r13d, %r13d
   4b9f4:      	cmpl	$0x2b, %eax
   4b9f7:      	je	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4b9fd:      	cmpl	$0x2d, %eax
   4ba00:      	je	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4ba06:      	jmp	0x4ba21 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xd51>
   4ba08:      	movq	%rbp, %r13
   4ba0b:      	testq	%r12, %r12
   4ba0e:      	movq	0x10(%rsp), %r12
   4ba13:      	jne	0x4bad7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe07>
   4ba19:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4ba1e:      	movzbl	(%rbx), %eax
   4ba21:      	xorl	%ecx, %ecx
   4ba23:      	cmpb	$0x2b, %al
   4ba25:      	sete	%cl
   4ba28:      	movq	%rcx, %rax
   4ba2b:      	negq	%rax
   4ba2e:      	movq	%rbp, %rdx
   4ba31:      	subq	%rcx, %rdx
   4ba34:      	addq	%rbx, %rcx
   4ba37:      	cmpq	$0x11, %rdx
   4ba3b:      	jae	0x4ba77 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xda7>
   4ba3d:      	testq	%rdx, %rdx
   4ba40:      	je	0x4bab4 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xde4>
   4ba42:      	addq	%rax, %rbp
   4ba45:      	negq	%rbp
   4ba48:      	xorl	%eax, %eax
   4ba4a:      	xorl	%r13d, %r13d
   4ba4d:      	movzbl	(%rcx,%rax), %edx
   4ba51:      	addl	$-0x30, %edx
   4ba54:      	cmpl	$0x9, %edx
   4ba57:      	ja	0x4bac6 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf6>
   4ba59:      	leaq	(,%r13,4), %rsi
   4ba61:      	addq	%r13, %rsi
   4ba64:      	movl	%edx, %edx
   4ba66:      	leaq	(%rdx,%rsi,2), %r13
   4ba6a:      	incq	%rax
   4ba6d:      	movq	%rbp, %rdx
   4ba70:      	addq	%rax, %rdx
   4ba73:      	jne	0x4ba4d <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xd7d>
   4ba75:      	jmp	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4ba77:      	addq	%rax, %rbp
   4ba7a:      	negq	%rbp
   4ba7d:      	xorl	%r13d, %r13d
   4ba80:      	movl	$0xa, %esi
   4ba85:      	xorl	%edi, %edi
   4ba87:      	xorl	%eax, %eax
   4ba89:      	movq	%rbp, %rdx
   4ba8c:      	addq	%rdi, %rdx
   4ba8f:      	je	0x4bae5 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe15>
   4ba91:      	mulq	%rsi
   4ba94:      	jo	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4ba96:      	movzbl	(%rcx,%rdi), %r8d
   4ba9b:      	addl	$-0x30, %r8d
   4ba9f:      	addq	%r8, %rax
   4baa2:      	setb	%dl
   4baa5:      	cmpl	$0x9, %r8d
   4baa9:      	ja	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4baab:      	incq	%rdi
   4baae:      	testb	%dl, %dl
   4bab0:      	je	0x4ba89 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdb9>
   4bab2:      	jmp	0x4bac9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xdf9>
   4bab4:      	xorl	%r13d, %r13d
   4bab7:      	testq	%r12, %r12
   4baba:      	movq	0x10(%rsp), %r12
   4babf:      	jne	0x4bad7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe07>
   4bac1:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4bac6:      	xorl	%r13d, %r13d
   4bac9:      	testq	%r12, %r12
   4bacc:      	movq	0x10(%rsp), %r12
   4bad1:      	je	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4bad7:      	movq	%rbx, %rdi
   4bada:      	callq	*0x346d8(%rip)          # 0x801b8 <writev+0x801b8>
   4bae0:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4bae5:      	movq	%rax, %r13
   4bae8:      	testq	%r12, %r12
   4baeb:      	movq	0x10(%rsp), %r12
   4baf0:      	jne	0x4bad7 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe07>
   4baf2:      	jmp	0x4b3a8 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x6d8>
   4baf7:      	movl	$0x180, %edi            # imm = 0x180
   4bafc:      	callq	0x12f80 <alloc::alloc::handle_alloc_error>
   4bb01:      	callq	0x4cb22 <<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::reentrant_lock::ReentrantLock<core::cell::RefCell<std::io::buffered::linewriter::LineWriter<std::io::stdio::StdoutRaw>>>>>::get_or_init<std::io::stdio::stdout::{closure#0}>::{closure#0}, !>>
   4bb06:      	movq	%fs:-0x8, %r14
   4bb0f:      	testq	%r14, %r14
   4bb12:      	jne	0x4b938 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xc68>
   4bb18:      	movq	0x362c9(%rip), %rax     # 0x81de8 <<std::thread::id::ThreadId>::new::COUNTER>
   4bb1f:      	nop
   4bb20:      	cmpq	$-0x1, %rax
   4bb24:      	je	0x4bcb4 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xfe4>
   4bb2a:      	leaq	0x1(%rax), %r14
   4bb2e:      	lock
   4bb2f:      	cmpxchgq	%r14, 0x362b1(%rip)     # 0x81de8 <<std::thread::id::ThreadId>::new::COUNTER>
   4bb37:      	jne	0x4bb20 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe50>
   4bb39:      	movq	%r14, %fs:-0x8
   4bb42:      	movq	0x35847(%rip), %rax     # 0x81390 <std::io::stdio::STDOUT>
   4bb49:      	cmpq	%rax, %r14
   4bb4c:      	je	0x4b948 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xc78>
   4bb52:      	movl	$0x1, %ebp
   4bb57:      	xorl	%eax, %eax
   4bb59:      	lock
   4bb5a:      	cmpxchgl	%ebp, 0x35837(%rip)     # 0x81398 <std::io::stdio::STDOUT+0x8>
   4bb61:      	jne	0x4bcd1 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1001>
   4bb67:      	movq	%r14, 0x35822(%rip)     # 0x81390 <std::io::stdio::STDOUT>
   4bb6e:      	movl	%ebp, 0x35828(%rip)     # 0x8139c <std::io::stdio::STDOUT+0xc>
   4bb74:      	leaq	0x35815(%rip), %rax     # 0x81390 <std::io::stdio::STDOUT>
   4bb7b:      	movq	%rax, 0x20(%rsp)
   4bb80:      	leaq	0x20(%rsp), %r12
   4bb85:      	movq	%r12, 0x80(%rsp)
   4bb8d:      	leaq	0x88(%rsp), %r14
   4bb95:      	movq	$0x0, 0x88(%rsp)
   4bba1:      	leaq	0x337f0(%rip), %rsi     # 0x7f398 <writev+0x7f398>
   4bba8:      	leaq	-0x46427(%rip), %rdx    # 0x5788 <writev+0x5788>
   4bbaf:      	leaq	0x80(%rsp), %rdi
   4bbb7:      	leaq	0x228(%rsp), %rcx
   4bbbf:      	callq	0x12a80 <core::fmt::write>
   4bbc4:      	movq	0x88(%rsp), %rcx
   4bbcc:      	testb	%al, %al
   4bbce:      	je	0x4bbf0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf20>
   4bbd0:      	movq	%rcx, %r15
   4bbd3:      	testq	%rcx, %rcx
   4bbd6:      	jne	0x4bc40 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf70>
   4bbd8:      	leaq	-0x42f93(%rip), %rdi    # 0x8c4c <core::num::flt2dec::strategy::dragon::POW5TO256+0x978>
   4bbdf:      	leaq	0x3376a(%rip), %rdx     # 0x7f350 <writev+0x7f350>
   4bbe6:      	movl	$0xad, %esi
   4bbeb:      	callq	0x12fb0 <core::panicking::panic_fmt>
   4bbf0:      	testq	%rcx, %rcx
   4bbf3:      	je	0x4bc3d <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf6d>
   4bbf5:      	movl	%ecx, %eax
   4bbf7:      	andl	$0x3, %eax
   4bbfa:      	xorl	%r15d, %r15d
   4bbfd:      	leal	-0x2(%rax), %edx
   4bc00:      	cmpl	$0x2, %edx
   4bc03:      	jb	0x4bc40 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf70>
   4bc05:      	testq	%rax, %rax
   4bc08:      	je	0x4bc40 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf70>
   4bc0a:      	leaq	-0x1(%rcx), %r14
   4bc0e:      	movq	-0x1(%rcx), %r15
   4bc12:      	movq	0x7(%rcx), %r13
   4bc16:      	movq	(%r13), %rax
   4bc1a:      	testq	%rax, %rax
   4bc1d:      	je	0x4bc24 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf54>
   4bc1f:      	movq	%r15, %rdi
   4bc22:      	callq	*%rax
   4bc24:      	cmpq	$0x0, 0x8(%r13)
   4bc29:      	je	0x4bc34 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf64>
   4bc2b:      	movq	%r15, %rdi
   4bc2e:      	callq	*0x34584(%rip)          # 0x801b8 <writev+0x801b8>
   4bc34:      	movq	%r14, %rdi
   4bc37:      	callq	*0x3457b(%rip)          # 0x801b8 <writev+0x801b8>
   4bc3d:      	xorl	%r15d, %r15d
   4bc40:      	movq	0x20(%rsp), %rsi
   4bc45:      	decl	0xc(%rsi)
   4bc48:      	jne	0x4bc5f <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf8f>
   4bc4a:      	movq	$0x0, (%rsi)
   4bc51:      	xorl	%eax, %eax
   4bc53:      	xchgl	%eax, 0x8(%rsi)
   4bc56:      	cmpl	$0x2, %eax
   4bc59:      	je	0x4bce2 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1012>
   4bc5f:      	testq	%r15, %r15
   4bc62:      	jne	0x4bd06 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1036>
   4bc68:      	leaq	0x80(%rsp), %rdi
   4bc70:      	callq	0x4c1e0 <snail_runtime::strict_io::release_all::h0f623ae639fa35f1>
   4bc75:      	movq	0x80(%rsp), %rbx
   4bc7d:      	testq	%rbx, %rbx
   4bc80:      	jle	0x4bc90 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xfc0>
   4bc82:      	movq	0x88(%rsp), %rdi
   4bc8a:      	callq	*0x34528(%rip)          # 0x801b8 <writev+0x801b8>
   4bc90:      	xorl	%eax, %eax
   4bc92:      	movabsq	$-0x8000000000000000, %rcx # imm = 0x8000000000000000
   4bc9c:      	cmpq	%rcx, %rbx
   4bc9f:      	setne	%al
   4bca2:      	addq	$0x3c8, %rsp            # imm = 0x3C8
   4bca9:      	popq	%rbx
   4bcaa:      	popq	%r12
   4bcac:      	popq	%r13
   4bcae:      	popq	%r14
   4bcb0:      	popq	%r15
   4bcb2:      	popq	%rbp
   4bcb3:      	retq
   4bcb4:      	callq	0x47620 <<std::thread::id::ThreadId>::new::exhausted>
   4bcb9:      	leaq	-0x4287c(%rip), %rdi    # 0x9444 <core::num::flt2dec::strategy::dragon::POW5TO256+0x1170>
   4bcc0:      	leaq	0x33b41(%rip), %rdx     # 0x7f808 <writev+0x7f808>
   4bcc7:      	movl	$0x26, %esi
   4bccc:      	callq	0x4cb80 <core::option::expect_failed>
   4bcd1:      	leaq	0x356c0(%rip), %rdi     # 0x81398 <std::io::stdio::STDOUT+0x8>
   4bcd8:      	callq	0x462b0 <<std::sys::sync::mutex::futex::Mutex>::lock_contended>
   4bcdd:      	jmp	0x4bb67 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xe97>
   4bce2:      	addq	$0x8, %rsi
   4bce6:      	movl	$0xca, %edi
   4bceb:      	movl	$0x81, %edx
   4bcf0:      	movl	$0x1, %ecx
   4bcf5:      	xorl	%eax, %eax
   4bcf7:      	callq	*0x344c3(%rip)          # 0x801c0 <writev+0x801c0>
   4bcfd:      	testq	%r15, %r15
   4bd00:      	je	0x4bc68 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0xf98>
   4bd06:      	movq	%r15, 0x20(%rsp)
   4bd0b:      	movq	%rbx, 0x80(%rsp)
   4bd13:      	leaq	-0x334ba(%rip), %rax    # 0x18860 <<&str as core::fmt::Display>::fmt>
   4bd1a:      	movq	%rax, 0x88(%rsp)
   4bd22:      	movq	%r12, 0x90(%rsp)
   4bd2a:      	leaq	0x142f(%rip), %rax      # 0x4d160 <<std::io::error::Error as core::fmt::Display>::fmt>
   4bd31:      	movq	%rax, 0x98(%rsp)
   4bd39:      	leaq	-0x4586d(%rip), %rdi    # 0x64d3 <writev+0x64d3>
   4bd40:      	leaq	0x336e1(%rip), %rdx     # 0x7f428 <writev+0x7f428>
   4bd47:      	leaq	0x80(%rsp), %rsi
   4bd4f:      	callq	0x12fb0 <core::panicking::panic_fmt>
   4bd54:      	movq	%rbx, %rdi
   4bd57:      	callq	0x12f80 <alloc::alloc::handle_alloc_error>
   4bd5c:      	movl	$0x108, %edi            # imm = 0x108
   4bd61:      	callq	0x12f80 <alloc::alloc::handle_alloc_error>
   4bd66:      	movl	$0x18, %edi
   4bd6b:      	callq	0x12f80 <alloc::alloc::handle_alloc_error>
   4bd70:      	movl	$0x58, %edi
   4bd75:      	callq	0x12f80 <alloc::alloc::handle_alloc_error>
   4bd7a:      	movq	%r14, 0x38(%rsp)
   4bd7f:      	movq	%r12, 0x10(%rsp)
   4bd84:      	testq	%r15, %r15
   4bd87:      	jne	0x4bdbc <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10ec>
   4bd89:      	cmpq	$0x0, 0x60(%rsp)
   4bd8f:      	jne	0x4be07 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1137>
   4bd91:      	cmpq	$0x0, 0x68(%rsp)
   4bd97:      	jne	0x4be1e <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x114e>
   4bd9d:      	cmpq	$0x0, 0x70(%rsp)
   4bda3:      	jne	0x4be35 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1165>
   4bda9:      	movq	0x58(%rsp), %r15
   4bdae:      	testq	%r15, %r15
   4bdb1:      	je	0x4be4a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x117a>
   4bdb7:      	jmp	0x4be67 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1197>
   4bdbc:      	movq	0x28(%rsp), %rax
   4bdc1:      	leaq	0x18(%rax), %rbx
   4bdc5:      	movq	0x343a4(%rip), %r12     # 0x80170 <writev+0x80170>
   4bdcc:      	movq	0x343e5(%rip), %r13     # 0x801b8 <writev+0x801b8>
   4bdd3:      	jmp	0x4bde9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1119>
   4bdd5:      	nopw	%cs:(%rax,%rax)
   4bde0:      	addq	$0x38, %rbx
   4bde4:      	decq	%r15
   4bde7:      	je	0x4bd89 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10b9>
   4bde9:      	movq	-0x8(%rbx), %rsi
   4bded:      	movq	(%rbx), %rdi
   4bdf0:      	shlq	$0xf, %rsi
   4bdf4:      	callq	*%r12
   4bdf7:      	cmpq	$0x0, -0x18(%rbx)
   4bdfc:      	je	0x4bde0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1110>
   4bdfe:      	movq	-0x10(%rbx), %rdi
   4be02:      	callq	*%r13
   4be05:      	jmp	0x4bde0 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1110>
   4be07:      	movq	0x28(%rsp), %rdi
   4be0c:      	callq	*0x343a6(%rip)          # 0x801b8 <writev+0x801b8>
   4be12:      	cmpq	$0x0, 0x68(%rsp)
   4be18:      	je	0x4bd9d <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10cd>
   4be1e:      	movq	0x40(%rsp), %rdi
   4be23:      	callq	*0x3438f(%rip)          # 0x801b8 <writev+0x801b8>
   4be29:      	cmpq	$0x0, 0x70(%rsp)
   4be2f:      	je	0x4bda9 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x10d9>
   4be35:      	movq	0x48(%rsp), %rdi
   4be3a:      	callq	*0x34378(%rip)          # 0x801b8 <writev+0x801b8>
   4be40:      	movq	0x58(%rsp), %r15
   4be45:      	testq	%r15, %r15
   4be48:      	jne	0x4be67 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1197>
   4be4a:      	cmpq	$0x0, 0x78(%rsp)
   4be50:      	jne	0x4be98 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11c8>
   4be52:      	cmpq	$0x0, 0x18(%rsp)
   4be58:      	jne	0x4beab <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11db>
   4be5a:      	cmpq	$0x0, 0x38(%rsp)
   4be60:      	jne	0x4bebe <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11ee>
   4be62:      	callq	0x53f10 <native_trap>
   4be67:      	movq	0x30(%rsp), %rax
   4be6c:      	leaq	0x8(%rax), %rbx
   4be70:      	movq	0x34341(%rip), %r14     # 0x801b8 <writev+0x801b8>
   4be77:      	jmp	0x4be89 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11b9>
   4be79:      	nopl	(%rax)
   4be80:      	addq	$0x18, %rbx
   4be84:      	decq	%r15
   4be87:      	je	0x4be4a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x117a>
   4be89:      	cmpq	$0x0, -0x8(%rbx)
   4be8e:      	jle	0x4be80 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11b0>
   4be90:      	movq	(%rbx), %rdi
   4be93:      	callq	*%r14
   4be96:      	jmp	0x4be80 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x11b0>
   4be98:      	movq	0x30(%rsp), %rdi
   4be9d:      	callq	*0x34315(%rip)          # 0x801b8 <writev+0x801b8>
   4bea3:      	cmpq	$0x0, 0x18(%rsp)
   4bea9:      	je	0x4be5a <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x118a>
   4beab:      	movq	0x50(%rsp), %rdi
   4beb0:      	callq	*0x34302(%rip)          # 0x801b8 <writev+0x801b8>
   4beb6:      	cmpq	$0x0, 0x38(%rsp)
   4bebc:      	je	0x4be62 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1192>
   4bebe:      	movq	0x10(%rsp), %rdi
   4bec3:      	callq	*0x342ef(%rip)          # 0x801b8 <writev+0x801b8>
   4bec9:      	callq	0x53f10 <native_trap>
   4bece:      	movq	%rax, %rbp
   4bed1:      	cmpq	$0x0, 0x8(%r13)
   4bed6:      	je	0x4bee1 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1211>
   4bed8:      	movq	%r15, %rdi
   4bedb:      	callq	*0x342d7(%rip)          # 0x801b8 <writev+0x801b8>
   4bee1:      	movq	%r14, %rdi
   4bee4:      	callq	*0x342ce(%rip)          # 0x801b8 <writev+0x801b8>
   4beea:      	movq	0x20(%rsp), %rdi
   4beef:      	callq	0x4d120 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4bef4:      	movq	%rbp, %rdi
   4bef7:      	callq	0x7d120 <_Unwind_Resume@plt>
   4befc:      	movq	%rax, %rbp
   4beff:      	cmpq	$0x0, 0x8(%rbx)
   4bf04:      	je	0x4bf0f <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x123f>
   4bf06:      	movq	%r13, %rdi
   4bf09:      	callq	*0x342a9(%rip)          # 0x801b8 <writev+0x801b8>
   4bf0f:      	movq	0x10(%rsp), %rdi
   4bf14:      	callq	*0x3429e(%rip)          # 0x801b8 <writev+0x801b8>
   4bf1a:      	movq	%rbp, %rdi
   4bf1d:      	callq	0x7d120 <_Unwind_Resume@plt>
   4bf22:      	movq	%rax, %rbp
   4bf25:      	cmpq	$0x0, 0x88(%rsp)
   4bf2e:      	je	0x4bf38 <wasm_native_47164efcb07c8c5089334b59546e0afa1a53f0c53765d2aa55fe1d84d8873d06::run::h6d0716b88c0aaa30+0x1268>
   4bf30:      	movq	%r14, %rdi
   4bf33:      	callq	0x209e0 <core::ptr::drop_in_place::<std::io::error::Error>>
   4bf38:      	movq	0x20(%rsp), %rdi
   4bf3d:      	callq	0x4d120 <core::ptr::drop_in_place::<std::io::stdio::StderrLock>>
   4bf42:      	movq	%rbp, %rdi
   4bf45:      	callq	0x7d120 <_Unwind_Resume@plt>
   4bf4a:      	callq	0x139fc <core::panicking::panic_in_cleanup>
   4bf4f:      	movq	%rax, %rbp
   4bf52:      	leaq	0x20(%rsp), %rdi
   4bf57:      	callq	0x209e0 <core::ptr::drop_in_place::<std::io::error::Error>>
   4bf5c:      	movq	%rbp, %rdi
   4bf5f:      	callq	0x7d120 <_Unwind_Resume@plt>
   4bf64:      	callq	0x139fc <core::panicking::panic_in_cleanup>
   4bf69:      	int3
   4bf6a:      	int3
   4bf6b:      	int3
   4bf6c:      	int3
   4bf6d:      	int3
   4bf6e:      	int3
   4bf6f:      	int3
