import assert from 'node:assert/strict';
import fs from 'node:fs';

const directory = new URL('.', import.meta.url);
const metadata = JSON.parse(fs.readFileSync(new URL('effects-observed.json', directory))).counters;
const modules = ['effects.wasm', 'effects-observed.wasm'].map(name =>
  new WebAssembly.Module(fs.readFileSync(new URL(name, directory))));
const reports = [];
for (const method of ['constructed', 'operand-trap', 'cast-trap', 'indirect-trap', 'readiness-trap']) {
  const outcomes = modules.map(module => {
    const {exports} = new WebAssembly.Instance(module);
    let result;
    try { result = {kind: typeof exports[method]()}; }
    catch (error) { result = {error: error.constructor.name, message: error.message}; }
    const counters = Object.fromEntries(metadata.map(site =>
      [site.id, exports['counter' + site.id]?.value.toString()]));
    return {result, effects: exports.effects.value, counters};
  });
  assert.deepEqual(outcomes[0].result, outcomes[1].result);
  assert.equal(outcomes[0].effects, outcomes[1].effects);
  const sites = metadata.filter(site => site.function === '$' + method);
  if (method === 'operand-trap')
    assert.equal(outcomes[1].counters[sites.find(site => site.category === 'constructor completed').id], '0');
  if (method === 'cast-trap')
    assert.equal(outcomes[1].counters[sites.find(site => site.opcode === 'ref.cast').id], '0');
  if (method === 'indirect-trap')
    assert.equal(outcomes[1].counters[sites.find(site => site.opcode === 'call_ref').id], '1');
  reports.push({method, result: outcomes[1].result, effects: outcomes[1].effects, passed: true});
}
fs.writeFileSync(new URL('results.json', directory), JSON.stringify(reports, null, 2) + '\n');
console.log(JSON.stringify(reports));
