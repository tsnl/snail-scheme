(module
 (rec
  (type $call92 (func (param (ref $environment87) (ref null $type24) i64) (result i64)))
  (type $type92 (struct (field (ref $environment87))))
  (type $type93 (struct (field (mut i32)) (field (mut (ref null $type92)))))
  (type $environment87 (struct (field (ref $type93))))
  (type $call29 (func (param (ref null $environment84) i64 i64) (result i64)))
  (type $environment84 (struct (field i64) (field (ref $type91))))
  (type $type91 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $type83 (struct (field (ref $environment73))))
  (type $type84 (struct (field (mut i32)) (field (mut (ref null $type83)))))
  (type $call85 (func (param (ref $environment82) i64 i64 (ref null $type24)) (result (ref null $type24))))
  (type $call89 (func (param (ref $environment78) (ref null $type16)) (result i32)))
  (type $type89 (struct (field (ref $environment78))))
  (type $type39 (struct (field (ref $environment76))))
  (type $environment76 (struct (field i64)))
  (type $type90 (struct (field (mut i32)) (field (mut (ref null $type89)))))
  (type $environment78 (struct (field (ref $type39)) (field (ref $type90))))
  (type $environment81 (struct (field (ref $type55))))
  (type $type8 (struct (field (ref $environment71))))
  (type $type82 (struct (field (ref $type8))))
  (type $environment80 (struct (field i64) (field (ref $type25)) (field (ref $type80))))
  (type $environment75 (struct (field (ref null $type16))))
  (type $type16 (struct (field (ref $type17)) (field (ref null $type16))))
  (type $environment71 (struct (field (ref $type69)) (field (ref $type74)) (field (ref $type79)) (field (ref $type81))))
  (type $call87 (func (param (ref $environment74) i64 i64 (ref null $type13) (ref null $type16) (ref null $type24)) (result (ref null $type24))))
  (type $type24 (struct (field (ref null $type24))))
  (type $type85 (struct (field (ref $environment82))))
  (type $environment82 (struct (field (ref $type74)) (field (ref $type55)) (field (ref $type56)) (field (ref $type84)) (field i64) (field (ref $type63)) (field (ref $type86))))
  (type $type87 (struct (field (ref $environment74))))
  (type $environment74 (struct (field i64) (field (ref $type69)) (field (ref $type55)) (field (ref $type82)) (field (ref $type74)) (field (ref $type63)) (field (ref $type88))))
  (type $type80 (struct (field (mut i32)) (field (mut (ref null $type25)))))
  (type $environment73 (struct (field i64) (field (ref $type69)) (field (ref $type74)) (field (ref $type55)) (field (ref $type56)) (field (ref $type80)) (field (ref $type82)) (field (ref $type84))))
  (type $type86 (struct (field (mut i32)) (field (mut (ref null $type85)))))
  (type $type88 (struct (field (mut i32)) (field (mut (ref null $type87)))))
  (type $call83 (func (param (ref $environment73) i64 (ref null $type24)) (result (ref null $type24))))
  (type $environment72 (struct (field (ref $type69)) (field (ref $type74))))
  (type $type81 (struct (field (ref $type47))))
  (type $type46 (struct (field (ref $environment37))))
  (type $type79 (struct (field (ref $type46))))
  (type $environment69 (struct (field (ref $type74)) (field (ref $type79)) (field (ref $type81))))
  (type $environment68 (struct (field i64)))
  (type $environment63 (struct (field (ref $type63)) (field (ref $type63))))
  (type $environment65 (struct (field i64) (field (ref $type28)) (field (ref $type58))))
  (type $environment62 (struct (field i64) (field (ref $type74)) (field i64) (field (ref $type63))))
  (type $environment61 (struct (field i64) (field (ref $type74))))
  (type $environment60 (struct (field i64) (field (ref $type35)) (field (ref $type74)) (field (ref $type58))))
  (type $type35 (struct (field (ref $call35)) (field (ref struct))))
  (type $type74 (struct (field (ref $type18))))
  (type $47 (func (param i64 (ref $type35)) (result (ref $type18))))
  (type $call27 (func (param (ref $type28) (ref null $type13)) (result i32)))
  (type $environment52 (struct (field (ref $type63))))
  (type $environment51 (struct (field i64) (field (ref $type14))))
  (type $call35 (func (param (ref struct) i64) (result (ref $type17))))
  (type $call72 (func (param (ref $environment49) (ref null $type13) (ref null $type13)) (result (ref null $type13))))
  (type $environment46 (struct (field (ref $type68)) (field (ref null $type13)) (field (ref $type69)) (field (ref $type70))))
  (type $type69 (struct (field i32) (field i64)))
  (type $call67 (func (param (ref $environment45) (ref null $type13) (ref null $type13) i32) (result i32)))
  (type $type67 (struct (field (ref $environment45))))
  (type $environment45 (struct (field (ref $type41)) (field (ref $type66)) (field i64) (field (ref $type43)) (field (ref $type68))))
  (type $call47 (func (param (ref null $environment72) (ref $type48) (ref $type43)) (result i32)))
  (type $type47 (struct (field (ref $call47)) (field (ref null $environment72))))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type67)))))
  (type $call65 (func (param (ref $environment44) (ref null $type13) i64 i32 (ref $type43)) (result i32)))
  (type $type17 (array (mut i32)))
  (type $call54 (func (param (ref null $environment40) i64) (result i64)))
  (type $environment40 (struct (field (ref $type18)) (field (ref $type48)) (field i64) (field i64) (field (ref $type63)) (field (ref $type63)) (field (ref $type64))))
  (type $type18 (array (mut (ref $type17))))
  (type $type63 (struct (field (mut i32)) (field (ref $type17))))
  (type $type64 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $call49 (func (param (ref $type18) (ref $type48) i64 i64) (result i64)))
  (type $call43 (func (param (ref null $environment46) i32) (result i32)))
  (type $type71 (struct (field i32) (field (ref $type43))))
  (type $type72 (struct (field (ref $environment49))))
  (type $type70 (struct (field i32) (field (ref null $type13))))
  (type $type42 (struct (field (ref $environment47))))
  (type $type48 (array (mut i64)))
  (type $type73 (struct (field (mut i32)) (field (mut (ref null $type72)))))
  (type $environment47 (struct (field (ref $type66)) (field (ref null $type13)) (field (ref $type70)) (field (ref $type71))))
  (type $environment49 (struct (field (ref $type31)) (field (ref $type73))))
  (type $call41 (func (param (ref $environment38) i64 i64 i32 (ref $type42) (ref $type43)) (result i32)))
  (type $type43 (struct (field (ref $call43)) (field (ref null $environment46))))
  (type $type65 (struct (field (ref $environment44))))
  (type $environment44 (struct (field (ref $type41)) (field (ref $type44)) (field (ref $type66))))
  (type $type44 (struct (field (ref $environment41))))
  (type $environment41 (struct (field (ref $type56)) (field (ref $type47))))
  (type $type41 (struct (field (ref $environment38))))
  (type $environment38 (struct (field (ref $type56)) (field (ref $type18))))
  (type $environment37 (struct (field (ref $type55)) (field (ref $type56))))
  (type $type56 (struct (field (ref $type48))))
  (type $type66 (struct (field (mut i32)) (field (mut (ref null $type65)))))
  (type $call46 (func (param (ref $environment37) i64 (ref $type18) (ref $type47)) (result i32)))
  (type $call28 (func (param (ref struct) i64) (result i32)))
  (type $environment36 (struct (field i64) (field (ref $type33)) (field (ref $type55)) (field (ref $type58))))
  (type $type14 (array (mut (ref null $type13))))
  (type $type28 (struct (field (ref $call28)) (field (ref struct))))
  (type $type55 (struct (field (ref $type14))))
  (type $type58 (struct (field (mut i32)) (field (mut (ref null $type28)))))
  (type $96 (func (param i64 (ref $type33)) (result (ref $type14))))
  (type $call25 (func (param structref i64) (result i32)))
  (type $type13 (struct (field i64) (field (ref null $type13))))
  (type $call31 (func (param (ref null $environment28) i64 (ref null $type13)) (result (ref null $type13))))
  (type $environment28 (struct (field (ref $type57))))
  (type $type31 (struct (field (ref $call31)) (field (ref null $environment28))))
  (type $type57 (struct (field (mut i32)) (field (mut (ref null $type31)))))
  (type $call33 (func (param (ref null $environment81) i64) (result (ref null $type13))))
  (type $type54 (struct (field (ref $call54)) (field (ref null $environment40))))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type45 (struct))
  (type $type40 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type33 (struct (field (ref $call33)) (field (ref null $environment81))))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field (ref $call29)) (field (ref null $environment84))))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (ref $call25)) (field structref)))
  (type $type23 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $127 (func (param i64) (result i64)))
 (type $128 (func (param i32) (result i64)))
 (type $129 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type11)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type15)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global80 (mut (ref null $type19)) (ref.null none))
 (global $ready80 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type20)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global264 (mut (ref null $type23)) (ref.null none))
 (global $ready264 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type25)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type26)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type27)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type29)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type30)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type32)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type34)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type33)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type36)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type37)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type38)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type40)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global64 (mut (ref null $type45)) (ref.null none))
 (global $ready64 (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type49)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type50)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type52)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type53)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global255 (mut i64) (i64.const 0))
 (global $ready255 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type54)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function27 (type $call33) (param $0 (ref null $environment81)) (param $1 i64) (result (ref null $type13))
  (local $2 (ref $type57))
  (local $3 (ref $type31))
  (struct.set $type57 1
   (local.tee $2
    (struct.new_default $type57)
   )
   (struct.new $type31
    (ref.func $function28)
    (struct.new $environment28
     (local.get $2)
    )
   )
  )
  (struct.set $type57 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type57 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call31
   (struct.get $type31 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type57 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $1)
   (ref.null none)
   (struct.get $type31 0
    (local.get $3)
   )
  )
 )
 (func $function28 (type $call31) (param $0 (ref null $environment28)) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref null $type13))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type57 0
       (struct.get $environment28 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function28
     (struct.get $type31 1
      (struct.get $type57 1
       (struct.get $environment28 0
        (local.get $0)
       )
      )
     )
     (local.tee $1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
     (struct.new $type13
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function29 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function30 (type $96) (param $0 i64) (param $1 (ref $type33)) (result (ref $type14))
  (local $2 (ref $type58))
  (local $3 (ref $type55))
  (local $4 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global78)
     )
    )
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (array.new_fixed $type14 0)
   )
   (else
    (struct.set $type58 1
     (local.tee $2
      (struct.new_default $type58)
     )
     (struct.new $type28
      (ref.func $function36)
      (struct.new $environment36
       (local.get $0)
       (local.get $1)
       (local.tee $3
        (struct.new $type55
         (array.new $type14
          (call_ref $call33
           (struct.get $type33 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type33 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type58 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type58 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type28 0
       (local.get $4)
      )
     )
    )
    (struct.get $type55 0
     (local.get $3)
    )
   )
  )
 )
 (func $function36 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment36))
  (local $3 (ref $type33))
  (local $4 (ref null $type13))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment36 0
     (local.tee $2
      (ref.cast (ref $environment36)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call33
      (struct.get $type33 1
       (local.tee $3
        (struct.get $environment36 1
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type33 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $type55 0
      (struct.get $environment36 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment36 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (struct.get $type28 1
      (struct.get $type58 1
       (struct.get $environment36 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function37 (type $call46) (param $0 (ref $environment37)) (param $1 i64) (param $2 (ref $type18)) (param $3 (ref $type47)) (result i32)
  (local $4 (ref $type66))
  (local $5 (ref null $type13))
  (local $6 (ref $type56))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (array.get $type14
    (struct.get $type55 0
     (struct.get $environment37 0
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (struct.set $type66 1
   (local.tee $4
    (struct.new_default $type66)
   )
   (struct.new $type65
    (struct.new $environment44
     (struct.new $type41
      (struct.new $environment38
       (local.tee $6
        (struct.get $environment37 1
         (local.get $0)
        )
       )
       (local.get $2)
      )
     )
     (struct.new $type44
      (struct.new $environment41
       (local.get $6)
       (local.get $3)
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type66 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type66 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function44
   (struct.get $type65 0
    (struct.get $type66 1
     (local.get $4)
    )
   )
   (local.get $5)
   (i64.const 0)
   (i32.const 1)
   (struct.new $type43
    (ref.func $function43)
    (ref.null none)
   )
  )
 )
 (func $function38 (type $call41) (param $0 (ref $environment38)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type42)) (param $5 (ref $type43)) (result i32)
  (local $6 (ref $environment49))
  (local $7 (ref null $type13))
  (local $8 (ref null $type13))
  (local $9 (ref null $type13))
  (local $10 (ref $type31))
  (local $11 (ref $environment47))
  (local $12 (ref $type73))
  (local $13 i64)
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $13
     (call $function39
      (struct.get $environment38 1
       (local.get $0)
      )
      (struct.get $type56 0
       (struct.get $environment38 0
        (local.get $0)
       )
      )
      (local.get $2)
      (local.get $1)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eq
      (local.get $13)
      (i64.const 1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (struct.get $type56 0
        (struct.get $environment38 0
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (if
       (i32.eqz
        (global.get $ready142)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global142)
       )
      )
      (local.set $8
       (struct.get $type70 1
        (struct.get $environment47 2
         (local.tee $11
          (struct.get $type42 0
           (local.get $4)
          )
         )
        )
       )
      )
      (struct.set $type73 1
       (local.tee $12
        (struct.new_default $type73)
       )
       (struct.new $type72
        (struct.new $environment49
         (struct.new $type31
          (ref.func $primitive0)
          (ref.null none)
         )
         (local.get $12)
        )
       )
      )
      (struct.set $type73 0
       (local.get $12)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type73 0
         (local.get $12)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.get $type72 0
        (struct.get $type73 1
         (local.get $12)
        )
       )
      )
      (if
       (i32.eqz
        (ref.is_null
         (local.tee $7
          (struct.get $environment47 1
           (local.get $11)
          )
         )
        )
       )
       (then
        (local.set $9
         (struct.get $type13 1
          (local.get $7)
         )
        )
        (local.set $8
         (call_ref $call31
          (struct.get $type31 1
           (local.tee $10
            (struct.get $environment49 0
             (local.get $6)
            )
           )
          )
          (struct.get $type13 0
           (local.get $7)
          )
          (local.get $8)
          (struct.get $type31 0
           (local.get $10)
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type73 0
           (struct.get $environment49 1
            (local.get $6)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.get $type72 0
          (struct.get $type73 1
           (struct.get $environment49 1
            (local.get $6)
           )
          )
         )
        )
        (local.set $8
         (if (result (ref null $type13))
          (ref.is_null
           (local.get $9)
          )
          (then
           (local.get $8)
          )
          (else
           (local.set $7
            (struct.get $type13 1
             (local.get $9)
            )
           )
           (local.set $9
            (call_ref $call31
             (struct.get $type31 1
              (local.tee $10
               (struct.get $environment49 0
                (local.get $6)
               )
              )
             )
             (struct.get $type13 0
              (local.get $9)
             )
             (local.get $8)
             (struct.get $type31 0
              (local.get $10)
             )
            )
           )
           (if
            (i32.eqz
             (struct.get $type73 0
              (struct.get $environment49 1
               (local.get $6)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (struct.get $type72 0
             (struct.get $type73 1
              (struct.get $environment49 1
               (local.get $6)
              )
             )
            )
           )
           (if (result (ref null $type13))
            (ref.is_null
             (local.get $7)
            )
            (then
             (local.get $9)
            )
            (else
             (local.set $8
              (struct.get $type13 1
               (local.get $7)
              )
             )
             (local.set $7
              (call_ref $call31
               (struct.get $type31 1
                (local.tee $10
                 (struct.get $environment49 0
                  (local.get $6)
                 )
                )
               )
               (struct.get $type13 0
                (local.get $7)
               )
               (local.get $9)
               (struct.get $type31 0
                (local.get $10)
               )
              )
             )
             (if
              (i32.eqz
               (struct.get $type73 0
                (struct.get $environment49 1
                 (local.get $6)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $6
              (struct.get $type72 0
               (struct.get $type73 1
                (struct.get $environment49 1
                 (local.get $6)
                )
               )
              )
             )
             (if (result (ref null $type13))
              (ref.is_null
               (local.get $8)
              )
              (then
               (local.get $7)
              )
              (else
               (local.set $9
                (struct.get $type13 1
                 (local.get $8)
                )
               )
               (local.set $7
                (call_ref $call31
                 (struct.get $type31 1
                  (local.tee $10
                   (struct.get $environment49 0
                    (local.get $6)
                   )
                  )
                 )
                 (struct.get $type13 0
                  (local.get $8)
                 )
                 (local.get $7)
                 (struct.get $type31 0
                  (local.get $10)
                 )
                )
               )
               (if
                (i32.eqz
                 (struct.get $type73 0
                  (struct.get $environment49 1
                   (local.get $6)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $6
                (struct.get $type72 0
                 (struct.get $type73 1
                  (struct.get $environment49 1
                   (local.get $6)
                  )
                 )
                )
               )
               (if (result (ref null $type13))
                (ref.is_null
                 (local.get $9)
                )
                (then
                 (local.get $7)
                )
                (else
                 (local.set $8
                  (struct.get $type13 1
                   (local.get $9)
                  )
                 )
                 (local.set $7
                  (call_ref $call31
                   (struct.get $type31 1
                    (local.tee $10
                     (struct.get $environment49 0
                      (local.get $6)
                     )
                    )
                   )
                   (struct.get $type13 0
                    (local.get $9)
                   )
                   (local.get $7)
                   (struct.get $type31 0
                    (local.get $10)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type73 0
                    (struct.get $environment49 1
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $6
                  (struct.get $type72 0
                   (struct.get $type73 1
                    (struct.get $environment49 1
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (if (result (ref null $type13))
                  (ref.is_null
                   (local.get $8)
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $9
                    (struct.get $type13 1
                     (local.get $8)
                    )
                   )
                   (local.set $7
                    (call_ref $call31
                     (struct.get $type31 1
                      (local.tee $10
                       (struct.get $environment49 0
                        (local.get $6)
                       )
                      )
                     )
                     (struct.get $type13 0
                      (local.get $8)
                     )
                     (local.get $7)
                     (struct.get $type31 0
                      (local.get $10)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type73 0
                      (struct.get $environment49 1
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $6
                    (struct.get $type72 0
                     (struct.get $type73 1
                      (struct.get $environment49 1
                       (local.get $6)
                      )
                     )
                    )
                   )
                   (if (result (ref null $type13))
                    (ref.is_null
                     (local.get $9)
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (local.set $8
                      (struct.get $type13 1
                       (local.get $9)
                      )
                     )
                     (local.set $7
                      (call_ref $call31
                       (struct.get $type31 1
                        (local.tee $10
                         (struct.get $environment49 0
                          (local.get $6)
                         )
                        )
                       )
                       (struct.get $type13 0
                        (local.get $9)
                       )
                       (local.get $7)
                       (struct.get $type31 0
                        (local.get $10)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type73 0
                        (struct.get $environment49 1
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $6
                      (struct.get $type72 0
                       (struct.get $type73 1
                        (struct.get $environment49 1
                         (local.get $6)
                        )
                       )
                      )
                     )
                     (if (result (ref null $type13))
                      (ref.is_null
                       (local.get $8)
                      )
                      (then
                       (local.get $7)
                      )
                      (else
                       (local.set $9
                        (struct.get $type13 1
                         (local.get $8)
                        )
                       )
                       (local.set $7
                        (call_ref $call31
                         (struct.get $type31 1
                          (local.tee $10
                           (struct.get $environment49 0
                            (local.get $6)
                           )
                          )
                         )
                         (struct.get $type13 0
                          (local.get $8)
                         )
                         (local.get $7)
                         (struct.get $type31 0
                          (local.get $10)
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type73 0
                          (struct.get $environment49 1
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $6
                        (struct.get $type72 0
                         (struct.get $type73 1
                          (struct.get $environment49 1
                           (local.get $6)
                          )
                         )
                        )
                       )
                       (if (result (ref null $type13))
                        (ref.is_null
                         (local.get $9)
                        )
                        (then
                         (local.get $7)
                        )
                        (else
                         (local.set $8
                          (struct.get $type13 1
                           (local.get $9)
                          )
                         )
                         (local.set $7
                          (call_ref $call31
                           (struct.get $type31 1
                            (local.tee $10
                             (struct.get $environment49 0
                              (local.get $6)
                             )
                            )
                           )
                           (struct.get $type13 0
                            (local.get $9)
                           )
                           (local.get $7)
                           (struct.get $type31 0
                            (local.get $10)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type73 0
                            (struct.get $environment49 1
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (struct.get $type72 0
                           (struct.get $type73 1
                            (struct.get $environment49 1
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (if (result (ref null $type13))
                          (ref.is_null
                           (local.get $8)
                          )
                          (then
                           (local.get $7)
                          )
                          (else
                           (local.set $9
                            (struct.get $type13 1
                             (local.get $8)
                            )
                           )
                           (local.set $7
                            (call_ref $call31
                             (struct.get $type31 1
                              (local.tee $10
                               (struct.get $environment49 0
                                (local.get $6)
                               )
                              )
                             )
                             (struct.get $type13 0
                              (local.get $8)
                             )
                             (local.get $7)
                             (struct.get $type31 0
                              (local.get $10)
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type73 0
                              (struct.get $environment49 1
                               (local.get $6)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $6
                            (struct.get $type72 0
                             (struct.get $type73 1
                              (struct.get $environment49 1
                               (local.get $6)
                              )
                             )
                            )
                           )
                           (if (result (ref null $type13))
                            (ref.is_null
                             (local.get $9)
                            )
                            (then
                             (local.get $7)
                            )
                            (else
                             (local.set $8
                              (struct.get $type13 1
                               (local.get $9)
                              )
                             )
                             (local.set $7
                              (call_ref $call31
                               (struct.get $type31 1
                                (local.tee $10
                                 (struct.get $environment49 0
                                  (local.get $6)
                                 )
                                )
                               )
                               (struct.get $type13 0
                                (local.get $9)
                               )
                               (local.get $7)
                               (struct.get $type31 0
                                (local.get $10)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type73 0
                                (struct.get $environment49 1
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $6
                              (struct.get $type72 0
                               (struct.get $type73 1
                                (struct.get $environment49 1
                                 (local.get $6)
                                )
                               )
                              )
                             )
                             (if (result (ref null $type13))
                              (ref.is_null
                               (local.get $8)
                              )
                              (then
                               (local.get $7)
                              )
                              (else
                               (local.set $9
                                (struct.get $type13 1
                                 (local.get $8)
                                )
                               )
                               (local.set $8
                                (call_ref $call31
                                 (struct.get $type31 1
                                  (local.tee $10
                                   (struct.get $environment49 0
                                    (local.get $6)
                                   )
                                  )
                                 )
                                 (struct.get $type13 0
                                  (local.get $8)
                                 )
                                 (local.get $7)
                                 (struct.get $type31 0
                                  (local.get $10)
                                 )
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type73 0
                                  (struct.get $environment49 1
                                   (local.get $6)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $6
                                (struct.get $type72 0
                                 (struct.get $type73 1
                                  (struct.get $environment49 1
                                   (local.get $6)
                                  )
                                 )
                                )
                               )
                               (if (result (ref null $type13))
                                (ref.is_null
                                 (local.get $9)
                                )
                                (then
                                 (local.get $8)
                                )
                                (else
                                 (local.set $7
                                  (struct.get $type13 1
                                   (local.get $9)
                                  )
                                 )
                                 (local.set $8
                                  (call_ref $call31
                                   (struct.get $type31 1
                                    (local.tee $10
                                     (struct.get $environment49 0
                                      (local.get $6)
                                     )
                                    )
                                   )
                                   (struct.get $type13 0
                                    (local.get $9)
                                   )
                                   (local.get $8)
                                   (struct.get $type31 0
                                    (local.get $10)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type73 0
                                    (struct.get $environment49 1
                                     (local.get $6)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function49
                                  (struct.get $type72 0
                                   (struct.get $type73 1
                                    (struct.get $environment49 1
                                     (local.get $6)
                                    )
                                   )
                                  )
                                  (local.get $7)
                                  (local.get $8)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type66 0
         (struct.get $environment47 0
          (local.get $11)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function44
       (struct.get $type65 0
        (struct.get $type66 1
         (struct.get $environment47 0
          (local.get $11)
         )
        )
       )
       (local.get $8)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
       (local.get $3)
       (struct.get $type71 1
        (struct.get $environment47 3
         (local.get $11)
        )
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $13)
        (i64.const 2)
       )
       (then
        (return_call_ref $call43
         (struct.get $type43 1
          (local.get $5)
         )
         (local.get $3)
         (struct.get $type43 0
          (local.get $5)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function39 (type $call49) (param $0 (ref $type18)) (param $1 (ref $type48)) (param $2 i64) (param $3 i64) (result i64)
  (local $4 (ref $type64))
  (local $5 (ref $type63))
  (local $6 (ref $type63))
  (local $7 (ref $type54))
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.new $type63
    (i32.const 1)
    (array.get $type18
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.new $type63
    (i32.const 1)
    (array.get $type18
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
    )
   )
  )
  (struct.set $type64 1
   (local.tee $4
    (struct.new_default $type64)
   )
   (struct.new $type54
    (ref.func $function40)
    (struct.new $environment40
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $5)
     (local.get $6)
     (local.get $4)
    )
   )
  )
  (struct.set $type64 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type64 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call54
   (struct.get $type54 1
    (local.tee $7
     (ref.as_non_null
      (struct.get $type64 1
       (local.get $4)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type54 0
    (local.get $7)
   )
  )
 )
 (func $function40 (type $call54) (param $0 (ref null $environment40)) (param $1 i64) (result i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (struct.get $environment40 2
     (local.get $0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment40 4
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (array.get $type17
      (struct.get $type63 1
       (struct.get $environment40 4
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (array.get $type48
      (struct.get $environment40 1
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment40 5
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type17
      (struct.get $type63 1
       (struct.get $environment40 5
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if (result i64)
     (select
      (local.get $3)
      (i32.eqz
       (local.get $3)
      )
      (local.get $2)
     )
     (then
      (local.set $4
       (struct.get $environment40 2
        (local.get $0)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type17
        (array.get $type18
         (struct.get $environment40 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (local.set $4
       (struct.get $environment40 3
        (local.get $0)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (array.get $type17
        (array.get $type18
         (struct.get $environment40 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if (result i64)
       (select
        (local.get $3)
        (i32.eqz
         (local.get $3)
        )
        (local.get $2)
       )
       (then
        (if
         (i32.eqz
          (struct.get $type64 0
           (struct.get $environment40 6
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function40
         (struct.get $type54 1
          (struct.get $type64 1
           (struct.get $environment40 6
            (local.get $0)
           )
          )
         )
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (else
        (select
         (i64.const 0)
         (i64.const 2)
         (local.get $2)
        )
       )
      )
     )
     (else
      (select
       (i64.const 0)
       (i64.const 2)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function43 (type $call43) (param $0 (ref null $environment46)) (param $1 i32) (result i32)
  (local.get $1)
 )
 (func $function44 (type $call65) (param $0 (ref $environment44)) (param $1 (ref null $type13)) (param $2 i64) (param $3 i32) (param $4 (ref $type43)) (result i32)
  (local $5 (ref $type68))
  (local $6 (ref $environment41))
  (local $7 (ref $type47))
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (return_call_ref $call47
     (struct.get $type47 1
      (local.tee $7
       (struct.get $environment41 1
        (local.tee $6
         (struct.get $type44 0
          (struct.get $environment44 1
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (struct.get $type56 0
      (struct.get $environment41 0
       (local.get $6)
      )
     )
     (local.get $4)
     (struct.get $type47 0
      (local.get $7)
     )
    )
   )
   (else
    (struct.set $type68 1
     (local.tee $5
      (struct.new_default $type68)
     )
     (struct.new $type67
      (struct.new $environment45
       (struct.get $environment44 0
        (local.get $0)
       )
       (struct.get $environment44 2
        (local.get $0)
       )
       (local.get $2)
       (local.get $4)
       (local.get $5)
      )
     )
    )
    (struct.set $type68 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type67 0
      (struct.get $type68 1
       (local.get $5)
      )
     )
     (local.get $1)
     (ref.null none)
     (local.get $3)
    )
   )
  )
  (unreachable)
 )
 (func $function45 (type $call67) (param $0 (ref $environment45)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (param $3 i32) (result i32)
  (local $4 (ref $type69))
  (local $5 (ref $type70))
  (local $6 (ref $type71))
  (local.set $4
   (struct.new $type69
    (i32.const 1)
    (struct.get $type13 0
     (local.get $1)
    )
   )
  )
  (local.set $6
   (struct.new $type71
    (i32.const 1)
    (if (result (ref $type43))
     (ref.is_null
      (struct.get $type70 1
       (local.tee $5
        (struct.new $type70
         (i32.const 1)
         (struct.get $type13 1
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (struct.get $environment45 3
       (local.get $0)
      )
     )
     (else
      (struct.new $type43
       (ref.func $function46)
       (struct.new $environment46
        (struct.get $environment45 4
         (local.get $0)
        )
        (local.get $2)
        (local.get $4)
        (local.get $5)
       )
      )
     )
    )
   )
  )
  (return_call $function38
   (struct.get $type41 0
    (struct.get $environment45 0
     (local.get $0)
    )
   )
   (struct.get $type69 1
    (local.get $4)
   )
   (struct.get $environment45 2
    (local.get $0)
   )
   (local.get $3)
   (struct.new $type42
    (struct.new $environment47
     (struct.get $environment45 1
      (local.get $0)
     )
     (local.get $2)
     (local.get $5)
     (local.get $6)
    )
   )
   (struct.get $type71 1
    (local.get $6)
   )
  )
 )
 (func $function46 (type $call43) (param $0 (ref null $environment46)) (param $1 i32) (result i32)
  (local $2 (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 i64)
  (drop
   (struct.get $environment46 3
    (local.get $0)
   )
  )
  (local.set $2
   (struct.get $type70 1
    (struct.get $environment46 3
     (local.get $0)
    )
   )
  )
  (drop
   (struct.get $environment46 2
    (local.get $0)
   )
  )
  (local.set $4
   (struct.get $type69 1
    (struct.get $environment46 2
     (local.get $0)
    )
   )
  )
  (local.set $3
   (struct.get $environment46 1
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment46 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function45
   (struct.get $type67 0
    (struct.get $type68 1
     (struct.get $environment46 0
      (local.get $0)
     )
    )
   )
   (local.get $2)
   (struct.new $type13
    (local.get $4)
    (local.get $3)
   )
   (local.get $1)
  )
 )
 (func $function49 (type $call72) (param $0 (ref $environment49)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type31))
  (if (result (ref null $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (local.set $1
     (call_ref $call31
      (struct.get $type31 1
       (local.tee $4
        (struct.get $environment49 0
         (local.get $0)
        )
       )
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (local.get $2)
      (struct.get $type31 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type73 0
       (struct.get $environment49 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type72 0
      (struct.get $type73 1
       (struct.get $environment49 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
 )
 (func $function51 (type $call35) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (local $2 (ref null $type13))
  (local $3 (ref $type28))
  (local $4 (ref $type63))
  (local $5 i64)
  (if
   (i64.gt_u
    (local.tee $5
     (struct.get $environment51 0
      (ref.cast (ref $environment51)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type63 0
     (local.tee $4
      (struct.new $type63
       (i32.const 1)
       (array.new_default $type17
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $type63 1
    (local.get $4)
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.get $type14
    (struct.get $environment51 1
     (ref.cast (ref $environment51)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $2)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $3
         (struct.new $type28
          (ref.func $function52)
          (struct.new $environment52
           (local.get $4)
          )
         )
        )
       )
       (struct.get $type13 0
        (local.get $2)
       )
       (struct.get $type28 0
        (local.get $3)
       )
      )
     )
     (local.set $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready156)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global156)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $2)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call28
         (struct.get $type28 1
          (local.get $3)
         )
         (struct.get $type13 0
          (local.get $2)
         )
         (struct.get $type28 0
          (local.get $3)
         )
        )
       )
       (local.set $2
        (struct.get $type13 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready156)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global156)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call28
           (struct.get $type28 1
            (local.get $3)
           )
           (struct.get $type13 0
            (local.get $2)
           )
           (struct.get $type28 0
            (local.get $3)
           )
          )
         )
         (local.set $2
          (struct.get $type13 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready156)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global156)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call28
             (struct.get $type28 1
              (local.get $3)
             )
             (struct.get $type13 0
              (local.get $2)
             )
             (struct.get $type28 0
              (local.get $3)
             )
            )
           )
           (local.set $2
            (struct.get $type13 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready156)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global156)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call28
               (struct.get $type28 1
                (local.get $3)
               )
               (struct.get $type13 0
                (local.get $2)
               )
               (struct.get $type28 0
                (local.get $3)
               )
              )
             )
             (local.set $2
              (struct.get $type13 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready156)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global156)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call28
                 (struct.get $type28 1
                  (local.get $3)
                 )
                 (struct.get $type13 0
                  (local.get $2)
                 )
                 (struct.get $type28 0
                  (local.get $3)
                 )
                )
               )
               (local.set $2
                (struct.get $type13 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready156)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global156)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call28
                   (struct.get $type28 1
                    (local.get $3)
                   )
                   (struct.get $type13 0
                    (local.get $2)
                   )
                   (struct.get $type28 0
                    (local.get $3)
                   )
                  )
                 )
                 (local.set $2
                  (struct.get $type13 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready156)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global156)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call28
                     (struct.get $type28 1
                      (local.get $3)
                     )
                     (struct.get $type13 0
                      (local.get $2)
                     )
                     (struct.get $type28 0
                      (local.get $3)
                     )
                    )
                   )
                   (local.set $2
                    (struct.get $type13 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready156)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global156)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call28
                       (struct.get $type28 1
                        (local.get $3)
                       )
                       (struct.get $type13 0
                        (local.get $2)
                       )
                       (struct.get $type28 0
                        (local.get $3)
                       )
                      )
                     )
                     (local.set $2
                      (struct.get $type13 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready156)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global156)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call_ref $call28
                         (struct.get $type28 1
                          (local.get $3)
                         )
                         (struct.get $type13 0
                          (local.get $2)
                         )
                         (struct.get $type28 0
                          (local.get $3)
                         )
                        )
                       )
                       (local.set $2
                        (struct.get $type13 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready156)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global156)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (call_ref $call28
                           (struct.get $type28 1
                            (local.get $3)
                           )
                           (struct.get $type13 0
                            (local.get $2)
                           )
                           (struct.get $type28 0
                            (local.get $3)
                           )
                          )
                         )
                         (local.set $2
                          (struct.get $type13 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready156)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global156)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (call_ref $call28
                             (struct.get $type28 1
                              (local.get $3)
                             )
                             (struct.get $type13 0
                              (local.get $2)
                             )
                             (struct.get $type28 0
                              (local.get $3)
                             )
                            )
                           )
                           (local.set $2
                            (struct.get $type13 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready156)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global156)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (call_ref $call28
                               (struct.get $type28 1
                                (local.get $3)
                               )
                               (struct.get $type13 0
                                (local.get $2)
                               )
                               (struct.get $type28 0
                                (local.get $3)
                               )
                              )
                             )
                             (local.set $2
                              (struct.get $type13 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready156)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global156)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (call_ref $call28
                                 (struct.get $type28 1
                                  (local.get $3)
                                 )
                                 (struct.get $type13 0
                                  (local.get $2)
                                 )
                                 (struct.get $type28 0
                                  (local.get $3)
                                 )
                                )
                               )
                               (local.set $2
                                (struct.get $type13 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready156)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global156)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (drop
                                  (call_ref $call28
                                   (struct.get $type28 1
                                    (local.get $3)
                                   )
                                   (struct.get $type13 0
                                    (local.get $2)
                                   )
                                   (struct.get $type28 0
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type13 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready156)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global156)
                                  )
                                 )
                                 (call $function53
                                  (local.get $3)
                                  (local.get $2)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type63 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type63 1
   (local.get $4)
  )
 )
 (func $function52 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i32.eqz
    (struct.get $type63 0
     (struct.get $environment52 0
      (ref.cast (ref $environment52)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $type63 1
    (struct.get $environment52 0
     (ref.cast (ref $environment52)
      (local.get $0)
     )
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (i32.const 0)
 )
 (func $function53 (type $call27) (param $0 (ref $type28)) (param $1 (ref null $type13)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.get $0)
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready156)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global156)
     )
    )
    (return_call $function53
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function54 (type $47) (param $0 i64) (param $1 (ref $type35)) (result (ref $type18))
  (local $2 (ref $type58))
  (local $3 (ref $type74))
  (local $4 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (i32.eqz
      (global.get $ready164)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (array.new_fixed $type18 0)
   )
   (else
    (struct.set $type58 1
     (local.tee $2
      (struct.new_default $type58)
     )
     (struct.new $type28
      (ref.func $function60)
      (struct.new $environment60
       (local.get $0)
       (local.get $1)
       (local.tee $3
        (struct.new $type74
         (array.new $type18
          (call_ref $call35
           (struct.get $type35 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type35 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type58 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type58 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type28 0
       (local.get $4)
      )
     )
    )
    (struct.get $type74 0
     (local.get $3)
    )
   )
  )
 )
 (func $function60 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment60))
  (local $3 (ref $type35))
  (local $4 (ref $type17))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment60 0
     (local.tee $2
      (ref.cast (ref $environment60)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call35
      (struct.get $type35 1
       (local.tee $3
        (struct.get $environment60 1
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type35 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (struct.get $type74 0
      (struct.get $environment60 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment60 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (struct.get $type28 1
      (struct.get $type58 1
       (struct.get $environment60 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function61 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type58))
  (local $3 (ref $environment61))
  (local $4 (ref $type63))
  (local $5 (ref $type28))
  (local $6 i64)
  (drop
   (ref.cast (ref $environment61)
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.new $type63
    (i32.const 1)
    (array.get $type18
     (struct.get $type74 0
      (struct.get $environment61 1
       (local.tee $3
        (ref.cast (ref $environment61)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (struct.set $type58 1
   (local.tee $2
    (struct.new_default $type58)
   )
   (struct.new $type28
    (ref.func $function65)
    (struct.new $environment65
     (local.tee $6
      (struct.get $environment61 0
       (local.get $3)
      )
     )
     (struct.new $type28
      (ref.func $function62)
      (struct.new $environment62
       (local.get $6)
       (struct.get $environment61 1
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type58 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type58 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call28
   (struct.get $type28 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type58 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type28 0
    (local.get $5)
   )
  )
 )
 (func $function62 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type58))
  (local $3 (ref $type63))
  (local $4 (ref $environment62))
  (local $5 (ref $type28))
  (drop
   (ref.cast (ref $environment62)
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type63 0
     (local.tee $3
      (struct.new $type63
       (i32.const 1)
       (array.get $type18
        (struct.get $type74 0
         (struct.get $environment62 1
          (ref.cast (ref $environment62)
           (local.get $0)
          )
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment62 2
      (ref.cast (ref $environment62)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (array.get $type17
    (struct.get $type63 1
     (local.get $3)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (local.set $1
     (struct.get $environment62 0
      (local.tee $4
       (ref.cast (ref $environment62)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (struct.set $type58 1
     (local.tee $2
      (struct.new_default $type58)
     )
     (struct.new $type28
      (ref.func $function65)
      (struct.new $environment65
       (local.get $1)
       (struct.new $type28
        (ref.func $function63)
        (struct.new $environment63
         (struct.get $environment62 3
          (local.get $4)
         )
         (local.get $3)
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type58 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call28
     (struct.get $type28 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type58 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type28 0
      (local.get $5)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function63 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment63))
  (if
   (i32.eqz
    (struct.get $type63 0
     (struct.get $environment63 0
      (ref.cast (ref $environment63)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $type17
    (struct.get $type63 1
     (struct.get $environment63 0
      (local.tee $2
       (ref.cast (ref $environment63)
        (local.get $0)
       )
      )
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment63 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type63 1
      (struct.get $environment63 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function65 (type $call28) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment65))
  (local $3 (ref $type28))
  (if (result i32)
   (i64.eq
    (struct.get $environment65 0
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $3
        (struct.get $environment65 1
         (local.tee $2
          (ref.cast (ref $environment65)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type28 0
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (struct.get $type28 1
      (struct.get $type58 1
       (struct.get $environment65 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function68 (type $call35) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment68 0
      (ref.cast (ref $environment68)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.new_default $type17
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function69 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment69))
  (local $3 (ref $type18))
  (local.set $3
   (struct.get $type74 0
    (struct.get $environment69 0
     (local.tee $2
      (ref.cast (ref $environment69)
       (local.get $0)
      )
     )
    )
   )
  )
  (return_call $function37
   (struct.get $type46 0
    (struct.get $type79 0
     (struct.get $environment69 1
      (local.get $2)
     )
    )
   )
   (local.get $1)
   (local.get $3)
   (struct.get $type81 0
    (struct.get $environment69 2
     (local.get $2)
    )
   )
  )
 )
 (func $function70 (type $call47) (param $0 (ref null $environment72)) (param $1 (ref $type48)) (param $2 (ref $type43)) (result i32)
  (return_call_ref $call43
   (struct.get $type43 1
    (local.get $2)
   )
   (i32.const 1)
   (struct.get $type43 0
    (local.get $2)
   )
  )
 )
 (func $function72 (type $call47) (param $0 (ref null $environment72)) (param $1 (ref $type48)) (param $2 (ref $type43)) (result i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (call $function39
      (struct.get $type74 0
       (struct.get $environment72 1
        (local.get $0)
       )
      )
      (block (result (ref $type48))
       (drop
        (struct.get $environment72 0
         (local.get $0)
        )
       )
       (local.set $3
        (struct.get $type69 1
         (struct.get $environment72 0
          (local.get $0)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready105)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global105)
        )
       )
       (local.get $1)
      )
      (local.get $3)
      (local.get $3)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (if (result i32)
      (local.tee $4
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (return_call_ref $call43
       (struct.get $type43 1
        (local.get $2)
       )
       (i32.const 1)
       (struct.get $type43 0
        (local.get $2)
       )
      )
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function73 (type $call83) (param $0 (ref $environment73)) (param $1 i64) (param $2 (ref null $type24)) (result (ref null $type24))
  (local $3 (ref $type58))
  (local $4 (ref $type88))
  (local $5 (ref $type86))
  (local $6 (ref $type74))
  (local $7 (ref $type74))
  (local $8 (ref $type25))
  (local $9 (ref $type28))
  (local $10 (ref $type63))
  (if
   (i32.eqz
    (struct.get $type80 0
     (struct.get $environment73 5
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref null $type24))
   (call_ref $call25
    (struct.get $type25 1
     (local.tee $8
      (ref.as_non_null
       (struct.get $type80 1
        (struct.get $environment73 5
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type25 0
     (local.get $8)
    )
   )
   (then
    (if
     (i64.eq
      (struct.get $type69 1
       (struct.get $environment73 1
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready149)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global149)
       )
      )
      (if
       (i32.eqz
        (global.get $ready159)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global159)
       )
      )
      (local.set $6
       (struct.new $type74
        (call $function54
         (local.tee $1
          (struct.get $type69 1
           (struct.get $environment73 1
            (local.get $0)
           )
          )
         )
         (struct.new $type35
          (ref.func $function51)
          (struct.new $environment51
           (local.get $1)
           (struct.get $type55 0
            (struct.get $environment73 3
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global183)
       )
      )
      (struct.set $type58 1
       (local.tee $3
        (struct.new_default $type58)
       )
       (struct.new $type28
        (ref.func $function65)
        (struct.new $environment65
         (local.get $1)
         (struct.new $type28
          (ref.func $function61)
          (struct.new $environment61
           (local.get $1)
           (local.get $6)
          )
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type58 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type58 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call28
        (struct.get $type28 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type58 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type28 0
         (local.get $9)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type69 1
          (struct.get $environment73 1
           (local.get $0)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type88 1
       (local.tee $4
        (struct.new_default $type88)
       )
       (struct.new $type87
        (struct.new $environment74
         (struct.get $environment73 0
          (local.get $0)
         )
         (struct.get $environment73 1
          (local.get $0)
         )
         (struct.get $environment73 3
          (local.get $0)
         )
         (struct.get $environment73 6
          (local.get $0)
         )
         (struct.new $type74
          (struct.get $type74 0
           (local.get $6)
          )
         )
         (struct.new $type63
          (i32.const 1)
          (array.get $type18
           (struct.get $type74 0
            (struct.get $environment73 2
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $4)
        )
       )
      )
      (struct.set $type88 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type88 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (struct.get $type87 0
        (struct.get $type88 1
         (local.get $4)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (ref.null none)
       (ref.null none)
       (local.get $2)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $10
       (struct.new $type63
        (i32.const 1)
        (array.get $type18
         (struct.get $type74 0
          (local.tee $7
           (struct.get $environment73 2
            (local.get $0)
           )
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (struct.set $type86 1
       (local.tee $5
        (struct.new_default $type86)
       )
       (struct.new $type85
        (struct.new $environment82
         (local.get $7)
         (struct.get $environment73 3
          (local.get $0)
         )
         (struct.get $environment73 4
          (local.get $0)
         )
         (struct.get $environment73 7
          (local.get $0)
         )
         (local.get $1)
         (local.get $10)
         (local.get $5)
        )
       )
      )
      (struct.set $type86 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type86 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (struct.get $type85 0
        (struct.get $type86 1
         (local.get $5)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function74 (type $call87) (param $0 (ref $environment74)) (param $1 i64) (param $2 i64) (param $3 (ref null $type13)) (param $4 (ref null $type16)) (param $5 (ref null $type24)) (result (ref null $type24))
  (local $6 (ref $type80))
  (local $7 (ref $environment71))
  (local $8 (ref $type25))
  (local $9 (ref $type16))
  (local $10 i32)
  (if (result (ref null $type24))
   (if (result i32)
    (local.tee $10
     (i64.eq
      (struct.get $type69 1
       (struct.get $environment74 1
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (then
     (local.get $10)
    )
    (else
     (i64.eq
      (local.get $2)
      (i64.const 2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready235)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (struct.set $type80 1
     (local.tee $6
      (struct.new_default $type80)
     )
     (struct.new $type25
      (ref.func $function80)
      (struct.new $environment80
       (struct.get $type69 1
        (struct.get $environment74 1
         (local.get $0)
        )
       )
       (struct.new $type25
        (ref.func $function75)
        (struct.new $environment75
         (local.get $4)
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type80 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref null $type24))
     (if (result i32)
      (call_ref $call25
       (struct.get $type25 1
        (local.tee $8
         (ref.as_non_null
          (struct.get $type80 1
           (local.get $6)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type25 0
        (local.get $8)
       )
      )
      (then
       (local.set $7
        (struct.get $type8 0
         (struct.get $type82 0
          (struct.get $environment74 3
           (local.get $0)
          )
         )
        )
       )
       (call $function37
        (struct.get $type46 0
         (struct.get $type79 0
          (struct.get $environment71 2
           (local.get $7)
          )
         )
        )
        (struct.get $type69 1
         (struct.get $environment71 0
          (local.get $7)
         )
        )
        (struct.get $type74 0
         (struct.get $environment71 1
          (local.get $7)
         )
        )
        (struct.get $type81 0
         (struct.get $environment71 3
          (local.get $7)
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type69 1
          (struct.get $environment74 1
           (local.get $0)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $type55 0
        (struct.get $environment74 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $3)
      )
      (if
       (i32.eqz
        (global.get $ready75)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global75)
       )
      )
      (drop
       (call $function30
        (struct.get $environment74 0
         (local.get $0)
        )
        (struct.new $type33
         (ref.func $function81)
         (struct.new $environment81
          (struct.get $environment74 2
           (local.get $0)
          )
         )
        )
       )
      )
      (struct.new $type24
       (local.get $5)
      )
     )
     (else
      (local.get $5)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment74 5
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type63 1
      (struct.get $environment74 5
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.new $type16
      (array.get $type18
       (struct.get $type74 0
        (struct.get $environment74 4
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type88 0
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call $function74
      (struct.get $type87 0
       (struct.get $type88 1
        (struct.get $environment74 6
         (local.get $0)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (i64.add
       (local.get $2)
       (i64.const 1)
      )
      (struct.new $type13
       (local.get $1)
       (local.get $3)
      )
      (local.get $9)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment74 5
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type63 1
      (struct.get $environment74 5
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type88 0
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (struct.get $type87 0
      (struct.get $type88 1
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function75 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref null $type16))
  (local $3 (ref $environment78))
  (local $4 (ref $type17))
  (local $5 (ref $type90))
  (local $6 i32)
  (local.set $2
   (struct.get $environment75 0
    (ref.cast (ref $environment75)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready229)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global229)
   )
  )
  (struct.set $type90 1
   (local.tee $5
    (struct.new_default $type90)
   )
   (struct.new $type89
    (struct.new $environment78
     (struct.new $type39
      (struct.new $environment76
       (local.get $1)
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type90 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type90 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type89 0
    (struct.get $type90 1
     (local.get $5)
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $6
      (array.get $type17
       (struct.get $type16 0
        (local.get $2)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment76 0
            (struct.get $type39 0
             (struct.get $environment78 0
              (local.get $3)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (local.set $2
       (struct.get $type16 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (struct.get $environment78 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type89 0
        (struct.get $type90 1
         (struct.get $environment78 1
          (local.get $3)
         )
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $6
          (array.get $type17
           (struct.get $type16 0
            (local.get $2)
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.tee $1
               (struct.get $environment76 0
                (struct.get $type39 0
                 (struct.get $environment78 0
                  (local.get $3)
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (local.get $6)
         )
         (else
          (local.set $2
           (struct.get $type16 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type90 0
             (struct.get $environment78 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type89 0
            (struct.get $type90 1
             (struct.get $environment78 1
              (local.get $3)
             )
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $6
              (array.get $type17
               (struct.get $type16 0
                (local.get $2)
               )
               (block (result i32)
                (if
                 (i64.gt_u
                  (local.tee $1
                   (struct.get $environment76 0
                    (struct.get $type39 0
                     (struct.get $environment78 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
             (then
              (local.get $6)
             )
             (else
              (local.set $2
               (struct.get $type16 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type90 0
                 (struct.get $environment78 1
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type89 0
                (struct.get $type90 1
                 (struct.get $environment78 1
                  (local.get $3)
                 )
                )
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $6
                  (array.get $type17
                   (struct.get $type16 0
                    (local.get $2)
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (struct.get $environment76 0
                        (struct.get $type39 0
                         (struct.get $environment78 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (local.set $2
                   (struct.get $type16 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type90 0
                     (struct.get $environment78 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type89 0
                    (struct.get $type90 1
                     (struct.get $environment78 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $6
                      (array.get $type17
                       (struct.get $type16 0
                        (local.get $2)
                       )
                       (block (result i32)
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (struct.get $environment76 0
                            (struct.get $type39 0
                             (struct.get $environment78 0
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i32.wrap_i64
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (local.set $2
                       (struct.get $type16 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type90 0
                         (struct.get $environment78 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type89 0
                        (struct.get $type90 1
                         (struct.get $environment78 1
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $6
                          (array.get $type17
                           (struct.get $type16 0
                            (local.get $2)
                           )
                           (block (result i32)
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (struct.get $environment76 0
                                (struct.get $type39 0
                                 (struct.get $environment78 0
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (local.set $2
                           (struct.get $type16 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type90 0
                             (struct.get $environment78 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $3
                           (struct.get $type89 0
                            (struct.get $type90 1
                             (struct.get $environment78 1
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $6
                              (array.get $type17
                               (struct.get $type16 0
                                (local.get $2)
                               )
                               (block (result i32)
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (struct.get $environment76 0
                                    (struct.get $type39 0
                                     (struct.get $environment78 0
                                      (local.get $3)
                                     )
                                    )
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i32.wrap_i64
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $6)
                             )
                             (else
                              (local.set $2
                               (struct.get $type16 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type90 0
                                 (struct.get $environment78 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $3
                               (struct.get $type89 0
                                (struct.get $type90 1
                                 (struct.get $environment78 1
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $6
                                  (array.get $type17
                                   (struct.get $type16 0
                                    (local.get $2)
                                   )
                                   (block (result i32)
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (struct.get $environment76 0
                                        (struct.get $type39 0
                                         (struct.get $environment78 0
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i32.wrap_i64
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $6)
                                 )
                                 (else
                                  (local.set $2
                                   (struct.get $type16 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (struct.get $type90 0
                                     (struct.get $environment78 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $3
                                   (struct.get $type89 0
                                    (struct.get $type90 1
                                     (struct.get $environment78 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $6
                                      (array.get $type17
                                       (struct.get $type16 0
                                        (local.get $2)
                                       )
                                       (block (result i32)
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (struct.get $environment76 0
                                            (struct.get $type39 0
                                             (struct.get $environment78 0
                                              (local.get $3)
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i32.wrap_i64
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $6)
                                     )
                                     (else
                                      (local.set $2
                                       (struct.get $type16 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type90 0
                                         (struct.get $environment78 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $3
                                       (struct.get $type89 0
                                        (struct.get $type90 1
                                         (struct.get $environment78 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if (result i32)
                                         (local.tee $6
                                          (array.get $type17
                                           (struct.get $type16 0
                                            (local.get $2)
                                           )
                                           (block (result i32)
                                            (if
                                             (i64.gt_u
                                              (local.tee $1
                                               (struct.get $environment76 0
                                                (struct.get $type39 0
                                                 (struct.get $environment78 0
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                              )
                                              (i64.const 4294967295)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (i32.wrap_i64
                                             (local.get $1)
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $6)
                                         )
                                         (else
                                          (local.set $2
                                           (struct.get $type16 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (struct.get $type90 0
                                             (struct.get $environment78 1
                                              (local.get $3)
                                             )
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type89 0
                                            (struct.get $type90 1
                                             (struct.get $environment78 1
                                              (local.get $3)
                                             )
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (local.tee $6
                                              (array.get $type17
                                               (struct.get $type16 0
                                                (local.get $2)
                                               )
                                               (block (result i32)
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (struct.get $environment76 0
                                                    (struct.get $type39 0
                                                     (struct.get $environment78 0
                                                      (local.get $3)
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (i64.const 4294967295)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (local.get $6)
                                             )
                                             (else
                                              (local.set $2
                                               (struct.get $type16 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (struct.get $type90 0
                                                 (struct.get $environment78 1
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (local.set $3
                                               (struct.get $type89 0
                                                (struct.get $type90 1
                                                 (struct.get $environment78 1
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (local.tee $6
                                                  (array.get $type17
                                                   (struct.get $type16 0
                                                    (local.get $2)
                                                   )
                                                   (block (result i32)
                                                    (if
                                                     (i64.gt_u
                                                      (local.tee $1
                                                       (struct.get $environment76 0
                                                        (struct.get $type39 0
                                                         (struct.get $environment78 0
                                                          (local.get $3)
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (i64.const 4294967295)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (i32.wrap_i64
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (local.get $6)
                                                 )
                                                 (else
                                                  (local.set $2
                                                   (struct.get $type16 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (struct.get $type90 0
                                                     (struct.get $environment78 1
                                                      (local.get $3)
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (local.set $3
                                                   (struct.get $type89 0
                                                    (struct.get $type90 1
                                                     (struct.get $environment78 1
                                                      (local.get $3)
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (local.tee $6
                                                      (array.get $type17
                                                       (struct.get $type16 0
                                                        (local.get $2)
                                                       )
                                                       (block (result i32)
                                                        (if
                                                         (i64.gt_u
                                                          (local.tee $1
                                                           (struct.get $environment76 0
                                                            (struct.get $type39 0
                                                             (struct.get $environment78 0
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (i64.const 4294967295)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (i32.wrap_i64
                                                         (local.get $1)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (local.get $6)
                                                     )
                                                     (else
                                                      (local.set $2
                                                       (struct.get $type16 1
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (struct.get $type90 0
                                                         (struct.get $environment78 1
                                                          (local.get $3)
                                                         )
                                                        )
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (local.set $3
                                                       (struct.get $type89 0
                                                        (struct.get $type90 1
                                                         (struct.get $environment78 1
                                                          (local.get $3)
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $2)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (local.tee $6
                                                          (array.get $type17
                                                           (struct.get $type16 0
                                                            (local.get $2)
                                                           )
                                                           (block (result i32)
                                                            (if
                                                             (i64.gt_u
                                                              (local.tee $1
                                                               (struct.get $environment76 0
                                                                (struct.get $type39 0
                                                                 (struct.get $environment78 0
                                                                  (local.get $3)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                              (i64.const 4294967295)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (i32.wrap_i64
                                                             (local.get $1)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (then
                                                          (local.get $6)
                                                         )
                                                         (else
                                                          (local.set $2
                                                           (struct.get $type16 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (struct.get $type90 0
                                                             (struct.get $environment78 1
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (return_call $function78
                                                           (struct.get $type89 0
                                                            (struct.get $type90 1
                                                             (struct.get $environment78 1
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                           (local.get $2)
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function78 (type $call89) (param $0 (ref $environment78)) (param $1 (ref null $type16)) (result i32)
  (local $2 (ref $type17))
  (local $3 i64)
  (local $4 i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $4
      (array.get $type17
       (struct.get $type16 0
        (local.get $1)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $3
           (struct.get $environment76 0
            (struct.get $type39 0
             (struct.get $environment78 0
              (local.get $0)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (struct.get $environment78 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function78
       (struct.get $type89 0
        (struct.get $type90 1
         (struct.get $environment78 1
          (local.get $0)
         )
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function80 (type $call25) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment80))
  (local $3 (ref $type25))
  (local $4 i32)
  (if (result i32)
   (local.tee $4
    (i64.eq
     (struct.get $environment80 0
      (ref.cast (ref $environment80)
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $4)
   )
   (else
    (if (result i32)
     (call_ref $call25
      (struct.get $type25 1
       (local.tee $3
        (struct.get $environment80 1
         (local.tee $2
          (ref.cast (ref $environment80)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type25 0
       (local.get $3)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type80 0
         (struct.get $environment80 2
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function80
       (struct.get $type25 1
        (struct.get $type80 1
         (struct.get $environment80 2
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function81 (type $call33) (param $0 (ref null $environment81)) (param $1 i64) (result (ref null $type13))
  (drop
   (struct.get $environment81 0
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (struct.get $type55 0
    (struct.get $environment81 0
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function82 (type $call85) (param $0 (ref $environment82)) (param $1 i64) (param $2 i64) (param $3 (ref null $type24)) (result (ref null $type24))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $type14))
  (local $8 (ref null $type13))
  (local $9 (ref $type17))
  (if (result (ref null $type24))
   (i64.eq
    (local.tee $4
     (struct.get $environment82 4
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type48
     (struct.get $type56 0
      (struct.get $environment82 2
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $2)
    )
    (if
     (i32.eqz
      (struct.get $type84 0
       (struct.get $environment82 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (struct.get $type83 0
      (struct.get $type84 1
       (struct.get $environment82 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (struct.get $environment82 4
       (local.get $0)
      )
      (i64.const 1)
     )
     (local.get $3)
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type86 0
       (struct.get $environment82 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function82
      (struct.get $type85 0
       (struct.get $type86 1
        (struct.get $environment82 6
         (local.get $0)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type18
      (struct.get $type74 0
       (struct.get $environment82 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.tee $5
       (array.get $type48
        (struct.get $type56 0
         (struct.get $environment82 2
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (i64.const 2)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.tee $7
        (struct.get $type55 0
         (struct.get $environment82 1
          (local.get $0)
         )
        )
       )
       (local.tee $6
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (struct.new $type13
        (local.tee $4
         (struct.get $environment82 4
          (local.get $0)
         )
        )
        (array.get $type14
         (local.get $7)
         (local.get $6)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $9)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 1)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (struct.get $type56 0
        (struct.get $environment82 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type86 0
         (struct.get $environment82 6
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function82
        (struct.get $type85 0
         (struct.get $type86 1
          (struct.get $environment82 6
           (local.get $0)
          )
         )
        )
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
        (local.get $2)
        (local.get $3)
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 2)
       )
       (then
        (if
         (i32.eqz
          (struct.get $type63 0
           (struct.get $environment82 5
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (struct.get $type63 1
          (struct.get $environment82 5
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 1)
        )
        (if
         (i64.gt_u
          (local.tee $4
           (struct.get $environment82 4
            (local.get $0)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.tee $7
          (struct.get $type55 0
           (struct.get $environment82 1
            (local.get $0)
           )
          )
         )
         (local.tee $6
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (struct.new $type13
          (local.get $1)
          (array.get $type14
           (local.get $7)
           (local.get $6)
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type86 0
           (struct.get $environment82 6
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (call $function82
          (struct.get $type85 0
           (struct.get $type86 1
            (struct.get $environment82 6
             (local.get $0)
            )
           )
          )
          (i64.add
           (local.get $1)
           (i64.const 1)
          )
          (i64.add
           (local.get $2)
           (i64.const 1)
          )
          (local.get $3)
         )
        )
        (if
         (i64.gt_u
          (local.tee $4
           (struct.get $environment82 4
            (local.get $0)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (struct.get $type13 1
          (array.get $type14
           (struct.get $type55 0
            (struct.get $environment82 1
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (struct.get $type55 0
          (struct.get $environment82 1
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $4)
         )
         (local.get $8)
        )
        (if
         (i32.eqz
          (struct.get $type63 0
           (struct.get $environment82 5
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (struct.get $type63 1
          (struct.get $environment82 5
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 0)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type48
       (struct.get $type56 0
        (struct.get $environment82 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $5)
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment82 4
          (local.get $0)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $9)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $type13 1
        (array.get $type14
         (struct.get $type55 0
          (struct.get $environment82 1
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $type55 0
        (struct.get $environment82 1
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $8)
      )
     )
    )
    (if
     (i64.ne
      (local.get $2)
      (i64.const 2)
     )
     (then
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment82 4
          (local.get $0)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.tee $7
        (struct.get $type55 0
         (struct.get $environment82 1
          (local.get $0)
         )
        )
       )
       (local.tee $6
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (struct.new $type13
        (local.get $1)
        (array.get $type14
         (local.get $7)
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type63 0
         (struct.get $environment82 5
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (struct.get $type63 1
        (struct.get $environment82 5
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type86 0
         (struct.get $environment82 6
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function82
        (struct.get $type85 0
         (struct.get $type86 1
          (struct.get $environment82 6
           (local.get $0)
          )
         )
        )
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (struct.get $type63 0
         (struct.get $environment82 5
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (struct.get $type63 1
        (struct.get $environment82 5
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $environment82 4
          (local.get $0)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $type13 1
        (array.get $type14
         (struct.get $type55 0
          (struct.get $environment82 1
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $type55 0
        (struct.get $environment82 1
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $8)
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function83 (type $call54) (param $0 (ref null $environment40)) (param $1 i64) (result i64)
  (local $2 (ref $type91))
  (local $3 (ref $type29))
  (struct.set $type91 1
   (local.tee $2
    (struct.new_default $type91)
   )
   (struct.new $type29
    (ref.func $function84)
    (struct.new $environment84
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type91 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type91 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type91 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type29 0
    (local.get $3)
   )
  )
 )
 (func $function84 (type $call29) (param $0 (ref null $environment84)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type24))
  (local $4 (ref $environment87))
  (local $5 (ref $type74))
  (local $6 (ref $type84))
  (local $7 (ref $type93))
  (local $8 (ref $type69))
  (local $9 (ref $type33))
  (local $10 (ref $type55))
  (local $11 (ref $type79))
  (local $12 i32)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment84 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready255)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global261)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global255)
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (local.set $5
     (struct.new $type74
      (call $function54
       (local.get $2)
       (struct.new $type35
        (ref.func $function68)
        (struct.new $environment68
         (local.get $2)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready64)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global64)
     )
    )
    (struct.set $type84 1
     (local.tee $6
      (struct.new_default $type84)
     )
     (struct.new $type83
      (struct.new $environment73
       (local.get $2)
       (local.tee $8
        (struct.new $type69
         (i32.const 1)
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (local.get $5)
       (struct.new $type55
        (array.new_default $type14
         (local.tee $12
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
       )
       (struct.new $type56
        (array.new_default $type48
         (local.get $12)
        )
       )
       (block (result (ref (exact $type80)))
        (if
         (i32.eqz
          (global.get $ready67)
         )
         (then
          (unreachable)
         )
        )
        (local.set $9
         (ref.as_non_null
          (global.get $global67)
         )
        )
        (if
         (i32.eqz
          (global.get $ready75)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global75)
         )
        )
        (local.set $10
         (struct.new $type55
          (call $function30
           (i64.add
            (local.tee $2
             (struct.get $type69 1
              (local.get $8)
             )
            )
            (i64.const 1)
           )
           (local.get $9)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $2)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type80
         (i32.const 1)
         (struct.new $type25
          (ref.func $function69)
          (struct.new $environment69
           (local.get $5)
           (local.tee $11
            (struct.new $type79
             (struct.new $type46
              (struct.new $environment37
               (local.get $10)
               (struct.new $type56
                (array.new_default $type48
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
           )
           (struct.new $type81
            (struct.new $type47
             (ref.func $function70)
             (ref.null none)
            )
           )
          )
         )
        )
       )
       (struct.new $type82
        (struct.new $type8
         (struct.new $environment71
          (local.get $8)
          (local.get $5)
          (local.get $11)
          (struct.new $type81
           (struct.new $type47
            (ref.func $function72)
            (struct.new $environment72
             (local.get $8)
             (local.get $5)
            )
           )
          )
         )
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type84 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type84 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function73
      (struct.get $type83 0
       (struct.get $type84 1
        (local.get $6)
       )
      )
      (i64.const 0)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready264)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global264)
     )
    )
    (struct.set $type93 1
     (local.tee $7
      (struct.new_default $type93)
     )
     (struct.new $type92
      (struct.new $environment87
       (local.get $7)
      )
     )
    )
    (struct.set $type93 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type92 0
      (struct.get $type93 1
       (local.get $7)
      )
     )
    )
    (local.set $2
     (if (result i64)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $3
        (struct.get $type24 0
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (struct.get $type93 0
          (struct.get $environment87 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type92 0
         (struct.get $type93 1
          (struct.get $environment87 0
           (local.get $4)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $3
          (struct.get $type24 0
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type93 0
            (struct.get $environment87 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type92 0
           (struct.get $type93 1
            (struct.get $environment87 0
             (local.get $4)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $3
            (struct.get $type24 0
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type93 0
              (struct.get $environment87 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type92 0
             (struct.get $type93 1
              (struct.get $environment87 0
               (local.get $4)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $3
              (struct.get $type24 0
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type93 0
                (struct.get $environment87 0
                 (local.get $4)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.get $type92 0
               (struct.get $type93 1
                (struct.get $environment87 0
                 (local.get $4)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $3
                (struct.get $type24 0
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type93 0
                  (struct.get $environment87 0
                   (local.get $4)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.get $type92 0
                 (struct.get $type93 1
                  (struct.get $environment87 0
                   (local.get $4)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $3
                  (struct.get $type24 0
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type93 0
                    (struct.get $environment87 0
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type92 0
                   (struct.get $type93 1
                    (struct.get $environment87 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type24 0
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type93 0
                      (struct.get $environment87 0
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.get $type92 0
                     (struct.get $type93 1
                      (struct.get $environment87 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $3
                      (struct.get $type24 0
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type93 0
                        (struct.get $environment87 0
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (struct.get $type92 0
                       (struct.get $type93 1
                        (struct.get $environment87 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $3
                        (struct.get $type24 0
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type93 0
                          (struct.get $environment87 0
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type92 0
                         (struct.get $type93 1
                          (struct.get $environment87 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $3
                          (struct.get $type24 0
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type93 0
                            (struct.get $environment87 0
                             (local.get $4)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $4
                          (struct.get $type92 0
                           (struct.get $type93 1
                            (struct.get $environment87 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $3
                            (struct.get $type24 0
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type93 0
                              (struct.get $environment87 0
                               (local.get $4)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $4
                            (struct.get $type92 0
                             (struct.get $type93 1
                              (struct.get $environment87 0
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $3
                              (struct.get $type24 0
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type93 0
                                (struct.get $environment87 0
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type92 0
                               (struct.get $type93 1
                                (struct.get $environment87 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $3
                                (struct.get $type24 0
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type93 0
                                  (struct.get $environment87 0
                                   (local.get $4)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $4
                                (struct.get $type92 0
                                 (struct.get $type93 1
                                  (struct.get $environment87 0
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type24 0
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type93 0
                                    (struct.get $environment87 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function87
                                  (struct.get $type92 0
                                   (struct.get $type93 1
                                    (struct.get $environment87 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type91 0
       (struct.get $environment84 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (struct.get $type29 1
      (struct.get $type91 1
       (struct.get $environment84 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function85 (type $call29) (param $0 (ref null $environment84)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function87 (type $call92) (param $0 (ref $environment87)) (param $1 (ref null $type24)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type24 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (struct.get $environment87 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (struct.get $type92 0
      (struct.get $type93 1
       (struct.get $environment87 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $primitive0 (type $call31) (param $0 (ref null $environment28)) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (struct.new $type13
   (local.get $1)
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type91))
  (local $2 (ref $type29))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready256)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type54 1
    (global.get $global256)
   )
  )
  (struct.set $type91 1
   (local.tee $1
    (struct.new_default $type91)
   )
   (struct.new $type29
    (ref.func $function84)
    (struct.new $environment84
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type91 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type91 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type91 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type29 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type11)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type15)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global80
   (struct.new_default $type19)
  )
  (global.set $ready80
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type20)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global264
   (struct.new_default $type23)
  )
  (global.set $ready264
   (i32.const 1)
  )
  (global.set $global72
   (struct.new $type25
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type26)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type27)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global261
   (struct.new $type29
    (ref.func $function85)
    (ref.null none)
   )
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type30)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global75
   (struct.new_default $type32)
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type34)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global67
   (struct.new $type33
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type36)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type37)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global229
   (struct.new_default $type38)
  )
  (global.set $ready229
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type40)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global64
   (struct.new_default $type45)
  )
  (global.set $ready64
   (i32.const 1)
  )
  (global.set $global105
   (struct.new_default $type49)
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type50)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type52)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global188
   (struct.new_default $type53)
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global255
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready255
   (i32.const 1)
  )
  (global.set $global256
   (struct.new $type54
    (ref.func $function83)
    (ref.null none)
   )
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

