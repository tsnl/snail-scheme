(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-strict-enumeration-profile-20261013/build/diagnostics/graphs/chez-adapted/program.scm" "/tmp/snail-strict-enumeration-profile-20261013/build/diagnostics/graphs/chez-adapted/program.so"))
