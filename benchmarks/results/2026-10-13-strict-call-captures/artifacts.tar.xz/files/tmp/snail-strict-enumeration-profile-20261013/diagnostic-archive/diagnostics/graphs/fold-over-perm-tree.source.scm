(define fold-over-perm-tree
  (lambda (universe b-folder b-state t-folder t-state)
    ;;        (assert (list? universe)
    ;;            universe)
    ;;        (assert (procedure? b-folder)
    ;;            b-folder)
    ;;        (assert (procedure? t-folder)
    ;;            t-folder)
    (let _-*-
        ((universe
          universe)
         (b-state
          b-state)
         (t-state
          t-state)
         (accross
          (lambda (final-t-state)
            final-t-state)))
      (if (null? universe)
          (t-folder b-state t-state accross)
          (let _-**-
              ((in
                universe)
               (out
                '())
               (t-state
                t-state))
            (let* ((first
                    (car in))
                   (rest
                    (cdr in))
                   (accross
                    (if (null? rest)
                        accross
                        (lambda (new-t-state)
                          (_-**- rest
                                 (cons first out)
                                 new-t-state)))))
              (b-folder first
                        b-state
                        t-state
                        (lambda (new-b-state new-t-state)
                          (_-*- (fold out cons rest)
                                new-b-state
                                new-t-state
                                accross))
                        accross)))))))
