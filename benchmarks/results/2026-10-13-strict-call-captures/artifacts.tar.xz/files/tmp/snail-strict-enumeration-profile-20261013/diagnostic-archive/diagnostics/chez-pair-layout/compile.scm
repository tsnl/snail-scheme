(import (chezscheme))
(parameterize ((optimize-level 2))
 (compile-program "build/diagnostics/chez-pair-layout/probe.scm" "build/diagnostics/chez-pair-layout/probe.so"))
