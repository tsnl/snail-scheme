(import (chezscheme))

;; ---- Allocation accounting probe; no performance measurement ----

(define held #f)
(define (pairs count)
  (let loop ((i count) (result '()))
    (if (= i 0) result (loop (- i 1) (cons i result)))))
(define (probe count)
  (let ((before (statistics)))
    (set! held (pairs count))
    (let ((delta (sstats-difference (statistics) before)))
      (unless (= (length held) count) (error 'probe "lost pair payload"))
      (write (list count (sstats-bytes delta) (sstats-gc-count delta)))
      (newline))))
(for-each probe '(0 1000 10000 100000))
