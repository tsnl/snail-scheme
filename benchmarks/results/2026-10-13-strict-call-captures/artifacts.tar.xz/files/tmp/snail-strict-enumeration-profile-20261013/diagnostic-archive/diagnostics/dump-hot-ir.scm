;; Read-only, located monomorphic IR from the frozen compiler snapshot.
(import (scheme base) (scheme process-context) (scheme write) (scheme cxr)
        (snail-scheme strict-compiler) (snail-scheme strict-specialize)
        (snail-scheme chromium-trace) (snail-scheme source)
        (prefix (snail-scheme ir) ir:))

;; ---- Finite descriptions of lexical identities ----

(define (location loc)
  (and loc (list (loc-filename loc) (loc-line loc) (loc-column loc))))
(define (value-view value)
  (list 'value (value-index value) (ir:value-definition-name (value-source value))
        (value-type value) (if (value-parameter? value) 'parameter 'binding)))
(define (site-view site)
  (list 'site (ir:value-definition-name (site-source site))
        (map (lambda (value) (list (value-view value) (view (value-initializer value))))
             (site-values (list site)))
        (and (site-check site) (view (site-check site)))))

;; ---- Located expressions with explicit closure identities ----

(define (view data)
  (cond ((ir:node? data) (node-view data))
        ((value-binding? data) (value-view data))
        ((ir:value-definition? data) (list 'definition (ir:value-definition-name data)))
        ((pair? data) (cons (view (car data)) (view (cdr data))))
        (else data)))
(define (node-view node)
  (let* ((kind (ir:node-kind node)) (data (ir:node-data node))
         (payload
          (case kind
            ((closure) (list 'function (function-index (car data)) 'direct? (function-direct? (car data))))
            ((bind) (map site-view data))
            ((block) (list (map site-view (car data)) (view (cadr data))))
            ((let) (list (map site-view (car data)) (view (cadr data))))
            (else (view data)))))
    (list kind (ir:node-type node) (location (ir:node-loc node)) payload)))
(define (function-view function)
  (list 'function (function-index function) 'direct? (function-direct? function)
        'source (location (ir:node-loc (function-source function)))
        'parameters (map value-view (function-parameters function))
        'captures (map value-view (function-captures function))
        'body (view (function-body function))))

;; ---- Selected hot functions and their enclosing creation sites ----

(define arguments (cdr (command-line)))
(define program
  (with-chromium-trace-to (caddr arguments)
    (lambda () (monomorphize (strict-source-file->core (car arguments) (cadr arguments)) 'bench))))
(define requested (map string->number (cdddr arguments)))
(for-each
 (lambda (function)
   (when (memv (function-index function) requested)
     (write (function-view function)) (newline)))
 (mono-program-functions program))
