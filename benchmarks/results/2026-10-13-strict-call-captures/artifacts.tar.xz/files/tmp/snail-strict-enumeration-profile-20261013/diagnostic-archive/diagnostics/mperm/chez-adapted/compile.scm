(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-strict-enumeration-profile-20261013/build/diagnostics/mperm/chez-adapted/program.scm" "/tmp/snail-strict-enumeration-profile-20261013/build/diagnostics/mperm/chez-adapted/program.so"))
