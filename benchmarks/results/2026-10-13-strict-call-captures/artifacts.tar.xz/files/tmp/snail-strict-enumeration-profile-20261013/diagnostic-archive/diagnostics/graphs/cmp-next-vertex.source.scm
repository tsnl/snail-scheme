(define cmp-next-vertex
  (lambda (graph perm x perm-x)
    (let ((from-x
           (vector-ref graph x))
          (from-perm-x
           (vector-ref graph perm-x)))
      (let _-*-
          ((y
            0))
        (if (= x y)
            1
            (let ((x->y?
                   (vector-ref from-x y))
                  (perm-y
                   (vector-ref perm y)))
              (cond ((bool-equal? x->y?
                          (vector-ref from-perm-x perm-y))
                     (let ((y->x?
                            (vector-ref (vector-ref graph y)
                                        x)))
                       (cond ((bool-equal? y->x?
                                   (vector-ref (vector-ref graph perm-y)
                                               perm-x))
                              (_-*- (+ y 1)))
                             (y->x?
                              0)
                             (else
                              2))))
                    (x->y?
                     0)
                    (else
                     2))))))))
