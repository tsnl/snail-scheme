(import (snail strict))
(define-class (Marker T) (: mark (-> I64)))
(define-instance (Marker I32) (mark (lambda () 20)))
(define-instance (Marker F64) (mark (lambda () 22)))
;; The two methods have identical arrow shapes; their class arguments still
;; select distinct implementations.
(define mark-integer (inst mark I32))
(define mark-float (inst mark F64))
(+ (mark-integer) (mark-float))
