(import (snail strict))
(define-overload wrong (-> I64 I64) (lambda (value) #t))
0
