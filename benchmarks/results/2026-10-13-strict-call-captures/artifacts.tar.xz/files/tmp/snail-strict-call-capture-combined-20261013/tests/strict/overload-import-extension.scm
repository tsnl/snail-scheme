(import (rename (snail strict) (+ sum)))
(define-overload sum (-> I32 I64 I64)
  (lambda (left right) (sum (i32->i64 left) right)))
(sum (ann 20 I32) 22)
