(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-vector-control-20261013/build/strict-array1-control/same-source-chez/program.scm" "/tmp/snail-strict-vector-control-20261013/build/strict-array1-control/same-source-chez/program.so"))
