(import (chezscheme))
(parameterize ((optimize-level 2) (#%$assembly-output (current-output-port)))
  (compile-program "/tmp/snail-strict-vector-benchmarks-20261013/build/strict-array1/array1/program.scm" "/tmp/snail-strict-vector-benchmarks-20261013/build/strict-array1/diagnostics/program.assembly.so"))
