(module
 (rec
  (type $environment8 (struct (field i64) (field (ref $type7))))
  (type $environment6 (struct (field (ref $type7)) (field i64)))
  (type $type7 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $call0 (func (param structref i64 i64) (result i64)))
  (type $environment3 (struct (field (ref $type5)) (field (ref $type2)) (field (ref $type6))))
  (type $environment1 (struct (field i64) (field (ref $type5)) (field (ref $type6))))
  (type $type2 (array (mut i64)))
  (type $type5 (struct (field (mut i32)) (field (ref $type2))))
  (type $type6 (struct (field (mut i32)) (field (mut (ref null $type1)))))
  (type $call1 (func (param structref i64) (result (ref $type2))))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type1 (struct (field (ref $call1)) (field structref)))
  (type $type0 (struct (field (ref $call0)) (field structref)))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global26 (mut (ref null $type0)) (ref.null none))
 (global $ready26 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global5 (mut (ref null $type3)) (ref.null none))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global11 (mut (ref null $type4)) (ref.null none))
 (global $ready11 (mut i32) (i32.const 0))
 (global $global13 (mut (ref null $type0)) (ref.null none))
 (global $ready13 (mut i32) (i32.const 0))
 (global $global19 (mut i64) (i64.const 0))
 (global $ready19 (mut i32) (i32.const 0))
 (global $global20 (mut i64) (i64.const 0))
 (global $ready20 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type4)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call1) (param $0 structref) (param $1 i64) (result (ref $type2))
  (local $2 (ref $type6))
  (local $3 (ref $type5))
  (local $4 (ref $type1))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.new $type5
    (i32.const 1)
    (array.new_default $type2
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
  (struct.set $type6 1
   (local.tee $2
    (struct.new_default $type6)
   )
   (struct.new $type1
    (ref.func $function1)
    (struct.new $environment1
     (local.get $1)
     (local.get $3)
     (local.get $2)
    )
   )
  )
  (struct.set $type6 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type6 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call1
   (struct.get $type1 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type6 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type1 0
    (local.get $4)
   )
  )
 )
 (func $function1 (type $call1) (param $0 structref) (param $1 i64) (result (ref $type2))
  (local $2 (ref $environment1))
  (if (result (ref $type2))
   (i64.le_s
    (struct.get $environment1 0
     (local.tee $2
      (ref.cast (ref $environment1)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment1 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type5 1
     (struct.get $environment1 1
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment1 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type2
     (struct.get $type5 1
      (struct.get $environment1 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (struct.get $type6 0
       (struct.get $environment1 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type1 1
      (struct.get $type6 1
       (struct.get $environment1 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function3 (type $call1) (param $0 structref) (param $1 i64) (result (ref $type2))
  (local $2 (ref $environment3))
  (local $3 (ref $type2))
  (local $4 i64)
  (if (result (ref $type2))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment3 0
        (ref.cast (ref $environment3)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type5 1
     (struct.get $environment3 0
      (ref.cast (ref $environment3)
       (local.get $0)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment3 0
        (ref.cast (ref $environment3)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type2
     (struct.get $type5 1
      (struct.get $environment3 0
       (local.tee $2
        (ref.cast (ref $environment3)
         (local.get $0)
        )
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type2
        (struct.get $environment3 1
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type6 0
       (struct.get $environment3 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function3
     (struct.get $type1 1
      (struct.get $type6 1
       (struct.get $environment3 2
        (local.get $2)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function5 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type7))
  (local $4 (ref $type0))
  (struct.set $type7 1
   (local.tee $3
    (struct.new_default $type7)
   )
   (struct.new $type0
    (ref.func $function6)
    (struct.new $environment6
     (local.get $3)
     (local.get $2)
    )
   )
  )
  (struct.set $type7 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type7 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type7 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $4)
   )
  )
 )
 (func $function6 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type6))
  (local $4 (ref $type1))
  (local $5 (ref $type2))
  (if (result i64)
   (i64.gt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $2
     (struct.get $environment6 1
      (ref.cast (ref $environment6)
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready11)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global11)
     )
    )
    (if
     (i32.eqz
      (global.get $ready0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type1 1
      (global.get $global0)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type6 1
     (local.tee $3
      (struct.new_default $type6)
     )
     (struct.new $type1
      (ref.func $function1)
      (struct.new $environment1
       (local.get $2)
       (struct.new $type5
        (i32.const 1)
        (array.new_default $type2
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type6 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type6 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call1
      (struct.get $type1 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type6 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type1 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global5)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.extend_i32_u
        (array.len
         (local.get $5)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type6 1
     (local.tee $3
      (struct.new_default $type6)
     )
     (struct.new $type1
      (ref.func $function3)
      (struct.new $environment3
       (struct.new $type5
        (i32.const 1)
        (array.new_default $type2
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type6 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type6 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.extend_i32_u
      (array.len
       (call_ref $call1
        (struct.get $type1 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type6 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
        (struct.get $type1 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment6 0
        (ref.cast (ref $environment6)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function6
     (struct.get $type0 1
      (struct.get $type7 1
       (struct.get $environment6 0
        (ref.cast (ref $environment6)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function8 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type7))
  (local $4 (ref $type0))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment8 0
     (ref.cast (ref $environment8)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready19)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready19)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready26)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global26)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global19)
     )
    )
    (if
     (i32.eqz
      (global.get $ready19)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready20)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready26)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global26)
     )
    )
    (local.set $5
     (call $foreign0
      (global.get $global20)
     )
    )
    (if
     (i32.eqz
      (global.get $ready13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global13)
     )
    )
    (struct.set $type7 1
     (local.tee $3
      (struct.new_default $type7)
     )
     (struct.new $type0
      (ref.func $function6)
      (struct.new $environment6
       (local.get $3)
       (local.get $5)
      )
     )
    )
    (struct.set $type7 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call0
      (struct.get $type0 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type7 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
      (i64.const 0)
      (struct.get $type0 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment8 1
        (ref.cast (ref $environment8)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function8
     (struct.get $type0 1
      (struct.get $type7 1
       (struct.get $environment8 1
        (ref.cast (ref $environment8)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function9 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type7))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready21)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global21)
   )
  )
  (struct.set $type7 1
   (local.tee $1
    (struct.new_default $type7)
   )
   (struct.new $type0
    (ref.func $function8)
    (struct.new $environment8
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type7 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type7 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type7 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global26
   (struct.new $type0
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready26
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type1
    (ref.func $function0)
    (ref.null none)
   )
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global5
   (struct.new_default $type3)
  )
  (global.set $ready5
   (i32.const 1)
  )
  (global.set $global11
   (struct.new_default $type4)
  )
  (global.set $ready11
   (i32.const 1)
  )
  (global.set $global13
   (struct.new $type0
    (ref.func $function5)
    (ref.null none)
   )
  )
  (global.set $ready13
   (i32.const 1)
  )
  (global.set $global19
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready19
   (i32.const 1)
  )
  (global.set $global20
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $ready20
   (i32.const 1)
  )
  (global.set $global21
   (struct.new_default $type4)
  )
  (global.set $ready21
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

