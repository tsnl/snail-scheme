// Execute the native Rust exports in the same instance as the existing port API.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { WASI } from 'node:wasi';
import { createFinalizers, createIdentityHasher } from '../../src/runtime/host.mjs';
import { createBuildEffects } from '../../src/runtime/build.mjs';

// ---- One linked instance and its owned roots ----

const [filename, mode = 'success', mismatch] = process.argv.slice(2);
const wasi = new WASI({ version: 'preview1', args: [filename],
  env: process.env, preopens: { '/': '/' } });
let instance;
const finalizers = createFinalizers((kind, id) => instance.exports['ports/drop-resource'](kind, id));
const node = { cwd: process.cwd(), exports: null };
const build = createBuildEffects(node);
instance = await WebAssembly.instantiate(await WebAssembly.compile(await readFile(filename)),
  { ...wasi.getImportObject(), 'snail.node': build.imports, 'snail.host': {
    'register-finalizer': finalizers.register, 'unregister-finalizer': finalizers.unregister,
    'hash-identity': createIdentityHasher(),
  } });
node.exports = instance.exports;
wasi.initialize(instance);
const abi = instance.exports;
abi['test/initialize']();
abi.main();

function stringRoot(text) {
  const characters = [...text], root = abi.string_new(characters.length);
  characters.forEach((character, index) => abi.string_set(root, index, character.codePointAt(0)));
  return root;
}

function portCall(name, roots) {
  const arguments_ = abi.vector_new(roots.length);
  roots.forEach((root, index) => abi.vector_set(arguments_, index, root));
  try { return abi[name](arguments_); }
  finally { abi.release(arguments_); }
}

function openInput(text) {
  const source = stringRoot(text);
  try { return portCall('ports/open-input-string', [source]); }
  finally { abi.release(source); }
}

function outputText(port) {
  const text = portCall('ports/get-output-string', [port]);
  try { return String.fromCodePoint(...Array.from({ length: abi.length(text) }, (_, i) => abi.char_at(text, i))); }
  finally { abi.release(text); }
}

function scalar(name, port, ...arguments_) {
  const live = abi.abi_live_roots.value;
  const result = abi[`snail:io/${name}`](abi.extension_id(port), ...arguments_);
  assert.equal(abi.abi_live_roots.value, live, `${name} allocated an ABI root`);
  return result;
}

function closeAndRelease(port) {
  assert.equal(scalar('close', port), 0);
  abi.release(port);
}

// ---- Unicode, EOF and existing-port interoperability ----

function checkInput() {
  const port = openInput('\0λ😀\u{10ffff}');
  assert.equal(scalar('peek-code', port), 0);
  assert.equal(scalar('peek-code', port), 0);
  assert.equal(scalar('read-code', port), 0);
  const boxed = portCall('ports/read-char', [port]);
  assert.equal(abi.atom_value(boxed) - 256, 955);
  abi.release(boxed);
  for (const code of [128512, 1114111, -1, -1]) assert.equal(scalar('read-code', port), code);
  closeAndRelease(port);
}

function checkOutput() {
  const port = portCall('ports/open-output-string', []);
  for (const code of [0, 955, 128512, 1114111]) assert.equal(scalar('write-code', port, code), 0);
  for (const code of [0xd800, 0xdfff, 0x110000, 0xffffffff]) assert.equal(scalar('write-code', port, code), -2);
  assert.equal(scalar('read-code', port), -2);
  assert.equal(outputText(port), '\0λ😀\u{10ffff}');
  assert.equal(scalar('close', port), 0);
  assert.equal(scalar('write-code', port, 65), -2);
  assert.equal(outputText(port), '\0λ😀\u{10ffff}');
  closeAndRelease(port);
}

function checkCatLoop() {
  const input = openInput('\0λ😀\u{10ffff}'), output = portCall('ports/open-output-string', []);
  const live = abi.abi_live_roots.value;
  abi.release(abi['test/catport'](input, output));
  assert.equal(abi.abi_live_roots.value, live, 'catport retained temporary roots');
  assert.equal(outputText(output), '\0λ😀\u{10ffff}');
  closeAndRelease(input); closeAndRelease(output);
  const empty = openInput(''), invalidOutput = abi.integer(7n);
  abi.release(abi['test/catport'](empty, invalidOutput)); // EOF must precede output validation.
  closeAndRelease(empty); abi.release(invalidOutput);
}

async function checkMalformedInput(bytes, path) {
  await writeFile(path, bytes);
  const name = stringRoot(path);
  const port = portCall('filesystem/open-input-file', [name]);
  abi.release(name);
  assert.equal(scalar('read-code', port), 65);
  assert.equal(scalar('read-code', port), -2);
  closeAndRelease(port);
}

async function checkOwnerLiveness() {
  const port = openInput('λ'), id = abi.extension_id(port);
  for (let i = 0; i < 10000; i++) abi.release(abi.string_new(32));
  if (globalThis.gc) globalThis.gc();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(scalar('read-code', port), 955, 'the owned wrapper must survive collection');
  closeAndRelease(port);
  const fresh = openInput('😀');
  assert.ok(abi.extension_id(fresh) > id, 'resource IDs must never be reused');
  abi['ports/drop-resource'](1, id); // A late notice cannot close the new resource.
  assert.equal(scalar('read-code', fresh), 128512);
  closeAndRelease(fresh);
}

// ---- Fatal diagnostics and native signature rejection ----

if (mode === 'closed') {
  const port = openInput('A');
  scalar('close', port);
  assert.equal(scalar('read-code', port), -2);
  try { abi['snail:io/raise-error'](); }
  catch (error) {
    // Node's reactor throws an internal WASI exit token outside wasi.start.
    if (error instanceof Error) throw error;
    process.exit(1);
  }
  throw new Error('raise-error returned');
}
if (mode === 'success') {
  checkInput(); checkOutput(); checkCatLoop();
  await checkOwnerLiveness();
  assert.equal(abi['snail:io/read-code'](0xffffffff), -2);
  await mkdir('build/typed-extern-tests', { recursive: true });
  await checkMalformedInput(new Uint8Array([65, 255]), `${process.cwd()}/build/typed-extern-tests/invalid.txt`);
  await checkMalformedInput(new Uint8Array([65, 240, 159]), `${process.cwd()}/build/typed-extern-tests/truncated.txt`);
  if (mismatch) {
    const module = await WebAssembly.compile(await readFile(mismatch));
    await assert.rejects(WebAssembly.instantiate(module,
      { io: { read: abi['snail:io/read-code'] } }), WebAssembly.LinkError);
  }
  assert.equal(abi.abi_live_roots.value, 3, 'only current ports may retain roots');
  console.log('Native scalar I/O checks passed');
}

if (mode === 'cat-closed-input' || mode === 'cat-closed-output') {
  const input = openInput('A'), output = portCall('ports/open-output-string', []);
  scalar('close', mode === 'cat-closed-input' ? input : output);
  try { abi['test/catport'](input, output); }
  catch (error) {
    if (error instanceof Error) throw error;
    process.exit(1);
  }
  throw new Error('fatal cat error returned');
}
