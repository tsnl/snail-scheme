(module
 (type $0 (func (result i32)))
 (rec
  (type $call0 (func (param i32) (result i32)))
  (type $type0 (struct))
 )
 (type $3 (func (param i32) (result i32)))
 (type $4 (func))
 (type $5 (func (param i32 i32) (result i32)))
 (type $6 (func (param i32)))
 (import "snail.library" "snail:io/read-code" (func $foreign0 (param i32) (result i32)))
 (import "snail.library" "snail:io/raise-error" (func $foreign1))
 (import "snail.abi" "probe:output-id" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/write-code" (func $foreign3 (param i32 i32) (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (export "copy-code" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call0) (param $0 i32) (result i32)
  (local $1 i32)
  (if (result i32)
   (i32.eq
    (local.tee $1
     (call $foreign0
      (local.get $0)
     )
    )
    (i32.const -1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eq
      (local.get $1)
      (i32.const -2)
     )
     (then
      (call $foreign1)
      (unreachable)
     )
    )
    (if
     (i32.eq
      (call $foreign3
       (call $foreign2)
       (local.get $1)
      )
      (i32.const -2)
     )
     (then
      (call $foreign1)
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global0)
     )
    )
    (return_call $function0
     (local.get $0)
    )
   )
  )
 )
 (func $export0 (param $0 i32)
  (local $1 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (block $block
   (drop
    (if (result i32)
     (i32.eq
      (local.tee $1
       (call $foreign0
        (local.get $0)
       )
      )
      (i32.const -1)
     )
     (then
      (i32.const 0)
     )
     (else
      (br_if $block
       (i32.eq
        (local.get $1)
        (i32.const -2)
       )
      )
      (br_if $block
       (i32.eq
        (call $foreign3
         (call $foreign2)
         (local.get $1)
        )
        (i32.const -2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global0)
       )
      )
      (if (result i32)
       (i32.eq
        (local.tee $1
         (call $foreign0
          (local.get $0)
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 0)
       )
       (else
        (br_if $block
         (i32.eq
          (local.get $1)
          (i32.const -2)
         )
        )
        (br_if $block
         (i32.eq
          (call $foreign3
           (call $foreign2)
           (local.get $1)
          )
          (i32.const -2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready0)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global0)
         )
        )
        (if (result i32)
         (i32.eq
          (local.tee $1
           (call $foreign0
            (local.get $0)
           )
          )
          (i32.const -1)
         )
         (then
          (i32.const 0)
         )
         (else
          (br_if $block
           (i32.eq
            (local.get $1)
            (i32.const -2)
           )
          )
          (br_if $block
           (i32.eq
            (call $foreign3
             (call $foreign2)
             (local.get $1)
            )
            (i32.const -2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready0)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global0)
           )
          )
          (if (result i32)
           (i32.eq
            (local.tee $1
             (call $foreign0
              (local.get $0)
             )
            )
            (i32.const -1)
           )
           (then
            (i32.const 0)
           )
           (else
            (br_if $block
             (i32.eq
              (local.get $1)
              (i32.const -2)
             )
            )
            (br_if $block
             (i32.eq
              (call $foreign3
               (call $foreign2)
               (local.get $1)
              )
              (i32.const -2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready0)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global0)
             )
            )
            (if (result i32)
             (i32.eq
              (local.tee $1
               (call $foreign0
                (local.get $0)
               )
              )
              (i32.const -1)
             )
             (then
              (i32.const 0)
             )
             (else
              (br_if $block
               (i32.eq
                (local.get $1)
                (i32.const -2)
               )
              )
              (br_if $block
               (i32.eq
                (call $foreign3
                 (call $foreign2)
                 (local.get $1)
                )
                (i32.const -2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready0)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global0)
               )
              )
              (if (result i32)
               (i32.eq
                (local.tee $1
                 (call $foreign0
                  (local.get $0)
                 )
                )
                (i32.const -1)
               )
               (then
                (i32.const 0)
               )
               (else
                (br_if $block
                 (i32.eq
                  (local.get $1)
                  (i32.const -2)
                 )
                )
                (br_if $block
                 (i32.eq
                  (call $foreign3
                   (call $foreign2)
                   (local.get $1)
                  )
                  (i32.const -2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global0)
                 )
                )
                (if (result i32)
                 (i32.eq
                  (local.tee $1
                   (call $foreign0
                    (local.get $0)
                   )
                  )
                  (i32.const -1)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (br_if $block
                   (i32.eq
                    (local.get $1)
                    (i32.const -2)
                   )
                  )
                  (br_if $block
                   (i32.eq
                    (call $foreign3
                     (call $foreign2)
                     (local.get $1)
                    )
                    (i32.const -2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global0)
                   )
                  )
                  (if (result i32)
                   (i32.eq
                    (local.tee $1
                     (call $foreign0
                      (local.get $0)
                     )
                    )
                    (i32.const -1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (br_if $block
                     (i32.eq
                      (local.get $1)
                      (i32.const -2)
                     )
                    )
                    (br_if $block
                     (i32.eq
                      (call $foreign3
                       (call $foreign2)
                       (local.get $1)
                      )
                      (i32.const -2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global0)
                     )
                    )
                    (if (result i32)
                     (i32.eq
                      (local.tee $1
                       (call $foreign0
                        (local.get $0)
                       )
                      )
                      (i32.const -1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (br_if $block
                       (i32.eq
                        (local.get $1)
                        (i32.const -2)
                       )
                      )
                      (br_if $block
                       (i32.eq
                        (call $foreign3
                         (call $foreign2)
                         (local.get $1)
                        )
                        (i32.const -2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global0)
                       )
                      )
                      (if (result i32)
                       (i32.eq
                        (local.tee $1
                         (call $foreign0
                          (local.get $0)
                         )
                        )
                        (i32.const -1)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i32.eq
                          (local.get $1)
                          (i32.const -2)
                         )
                         (then
                          (call $foreign1)
                          (unreachable)
                         )
                        )
                        (if
                         (i32.eq
                          (call $foreign3
                           (call $foreign2)
                           (local.get $1)
                          )
                          (i32.const -2)
                         )
                         (then
                          (call $foreign1)
                          (unreachable)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready0)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global0)
                         )
                        )
                        (call $function0
                         (local.get $0)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (return)
  )
  (call $foreign1)
  (unreachable)
 )
 (func $main (result i32)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type0)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i32.const 0)
 )
)

