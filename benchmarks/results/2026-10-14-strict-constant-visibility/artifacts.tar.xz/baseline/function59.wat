 (func $function59 (type $21) (param $0 (ref $type28)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready177)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (i64.gt_s
      (local.tee $6
       (if (result i64)
        (i64.lt_u
         (local.get $6)
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $6)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $6)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $6)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $6)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $6)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $6)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $1)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready184)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (drop
     (call $function64
      (local.get $0)
      (local.get $4)
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $7)
       (if (result i64)
        (i64.eq
         (local.get $6)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $6)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $6)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (local.get $6)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
