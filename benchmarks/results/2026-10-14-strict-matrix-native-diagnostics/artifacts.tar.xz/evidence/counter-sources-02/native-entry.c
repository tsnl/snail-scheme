#include "native-provider.h"
void matrix_diag_reset(void);
void matrix_diag_report(void);
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
void load_inputs(const char *);
uint64_t barrier_count(void);
extern int64_t bench(int64_t) __asm__("wasm.bench");
int main(int argc, char **argv) {
    native_host_init(argc, argv); native_module_init();
    assert(argc == 3); load_inputs(argv[2]);
    guest_main();
    int64_t count = strtoll(argv[1], NULL, 10);
    struct timespec before, after;
    matrix_diag_reset();
    assert(clock_gettime(CLOCK_MONOTONIC, &before) == 0);
    int64_t result = bench(count);
    assert(clock_gettime(CLOCK_MONOTONIC, &after) == 0);
    matrix_diag_report();
    double seconds = (double)(after.tv_sec - before.tv_sec) + (double)(after.tv_nsec - before.tv_nsec) / 1e9;
    printf("{\"result\":%" PRId64 ",\"barriers\":%" PRIu64 ",\"seconds\":%.9f}\n", result, barrier_count(), seconds);
    return native_finish(0);
}
