(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/rust-compiler-current-full/cases/compiler/program.scm" "/tmp/snail-rust-full-reference-20261013/build/rust-compiler-current-full/cases/compiler/program.so"))
