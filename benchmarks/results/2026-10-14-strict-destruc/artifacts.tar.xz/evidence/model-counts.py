"""Derive operation counts from the independent logical graph transition."""

import collections
import json
from pathlib import Path
import sys

sys.path.insert(0, sys.argv[1])
import destruc_port


class CountGraph(destruc_port.Graph):
    def __init__(self):
        super().__init__(False)
        self.counts = collections.Counter()

    def record(self, *event):
        self.counts[event[0]] += 1


model = CountGraph()
model.destructive(600, 50)
counts = model.counts
expected = {'allocation:$type36': counts[0], 'allocation:$type31': counts[1],
            'allocation:$type32': counts[1], 'allocation:$type33': counts[0] + counts[1],
            'allocation:$type37': counts[0], 'allocation:$type27': counts[3],
            'store:$type32:0': counts[3], 'store:$type33:0': counts[2] + counts[4]}
names = ('outer_allocations', 'inner_allocations', 'outer_head_stores', 'inner_head_stores', 'inner_tail_stores')
result = dict(n=600, m=50, logical_events=dict(zip(names, [counts[i] for i in range(5)])),
              expected_wasm_counts_per_call=expected)
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
