"""Freeze the committed Destruc preparation and isolated correctness diagnostics."""

import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path('/tmp/snail-strict-destruc-20261014')
prepared = Path('/tmp/snail-strict-destruc-preparation-20261014-r3')
evidence = Path('/tmp/snail-strict-destruc-evidence-20261014')
report = root / 'benchmarks/results/2026-10-14-strict-destruc'
sys.path.insert(0, str(prepared))
import destruc_port

load = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n')
metadata = load(prepared / 'prepared.json')
case = metadata['cases'][0]
assert case['name'] == 'destruc' and case['status'] == 'ready'
assert metadata['driver_commit'] == '92a491a4aaec7bc1a880d86204b81ed2cab1ffcb'
for name, expected in case['hashes'].items():
    assert digest(prepared / 'destruc' / name) == expected, name
for name, expected in metadata['compiler_files'].items():
    assert digest(root / name) == expected, name
    assert digest(prepared / 'compiler-source' / name) == expected, name
canonical = load(prepared / 'destruc/validation.json') + load(prepared / 'destruc/chez-validation.json')
assert len(canonical) == 12 and all(row['returncode'] == 0 and not row['stderr'] for row in canonical)
observations = {}
for values in destruc_port.fixtures():
    label = '-'.join(map(str, values))
    oracle = load(prepared / f'destruc/probe-oracle-{label}.json')
    assert all(value == oracle['expected'] for value in oracle['observations'])
    observations[label] = len(oracle['expected'])
for label, data, accepted in destruc_port.harness_fixtures():
    checks = load(prepared / f'destruc/validation-{label}.json')
    assert len(checks) == 2 and all((row['returncode'] == 0) == accepted for row in checks)
    for control in ('', 'same-source-chez'):
        row = load(prepared / 'destruc' / control / f'chez-validation-{label}.json')
        assert row['returncode'] == 0 and not row['stderr'] and row['accepted'] == accepted
summary = dict(source_commit=metadata['driver_commit'], compiler_commit=metadata['compiler_commit'],
               compiler_files=len(metadata['compiler_files']), frozen_case_files=len(case['hashes']),
               canonical_executions=12, graph_and_full_output_executions=44,
               full_predicate_executions=56, total_behavior_executions=112,
               observations_per_form=observations, original_input=case['spec'],
               make_test='passed', make_check='passed', previous_unchanged_ports=29,
               clean_measurements=0)
save(report / 'correctness-summary.json', summary)
proof = load(evidence / 'diagnostics/source-proof.json')
assert proof['original_wasm_sha256'] == digest(prepared / 'destruc/strict.wasm')
assert proof['original_wat_sha256'] == digest(prepared / 'destruc/strict.optimized.wat')
runs = [load(evidence / f'observed-{count}.json') for count in (1, 2, 4000)]
assert all(row['returncode'] == 0 and not row['stderr'] for row in runs)
runs = [json.loads(row['stdout']) for row in runs]
model = load(evidence / 'independent-operation-counts.json')
for row in runs:
    for key, value in model['expected_wasm_counts_per_call'].items():
        assert int(row['observed'][key]) == int(row['count']) * value, key
    for key, value in row['observed'].items():
        scale = 1 if key in ('function:$function43', 'function:$function47', 'function:$export0') else int(row['count'])
        assert int(value) == scale * int(runs[0]['observed'][key]), key
extra = {label: json.loads(load(evidence / f'observed-{label}.json')['stdout'])
         for label in ('positive-false', 'zero-false')}
assert extra['positive-false']['observed']['function:$function51'] == '1'
assert extra['positive-false']['observed']['function:$function43'] == '0'
assert all(int(value) == int(key == 'function:$export0')
           for key, value in extra['zero-false']['observed'].items())
roles = {'$function43': 'Complete inner-row equality', '$function47': 'Complete outer-row equality',
         '$function51': 'Complete destructive invocation and ten fresh outer nodes',
         '$function54': 'Descending n-iteration loop', '$function55': 'Refill outer-row traversal',
         '$function58': 'Fresh m-node inner-list construction remainder after optimizer unrolling',
         '$function60': 'Append traversal and final tail store', '$function62': 'Consecutive-row splice traversal',
         '$function64': 'Inner-row length traversal', '$function65': 'Left split and prefix marking',
         '$function67': 'Right target and prefix marking', '$function75': 'Runtime repetition and final predicate'}
save(report / 'retention-audit.json', dict(**proof, optimized_bytes=(prepared / 'destruc/strict.wasm').stat().st_size,
     canonical_exports=['bench', 'main'], function_roles=roles, independent_model=model,
     observations=runs, false_expectation_observations=extra, initialization_excluded=True,
     limitations='Executed optimized Wasm function/constructor/store sites, not V8 physical allocation, machine instructions, or clean timing. Observer additions erase to the exact original optimized text; no reoptimization.'))
items = {str(path.relative_to(prepared)): path for path in prepared.rglob('*')
         if path.is_file() and '__pycache__' not in path.parts}
items.update({'evidence/' + str(path.relative_to(evidence)): path for path in evidence.rglob('*')
              if path.is_file() and '__pycache__' not in path.parts})
manifest = {name: digest(path) for name, path in sorted(items.items())}
archive = report / 'artifacts.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for name, path in sorted(items.items()):
        info = output.gettarinfo(str(path), arcname=name)
        info.mtime, info.uid, info.gid, info.uname, info.gname = 0, 0, 0, '', ''
        with path.open('rb') as stream:
            output.addfile(info, stream)
save(report / 'manifest.json', dict(archive_sha256=digest(archive), files=manifest,
     source_commit=metadata['driver_commit'], compiler_commit=metadata['compiler_commit'],
     upstream_commit=metadata['upstream_commit'], preparation_directory=str(prepared), clean_measurements=0))
print('Archived', len(items), 'files;', archive.stat().st_size, 'bytes')
