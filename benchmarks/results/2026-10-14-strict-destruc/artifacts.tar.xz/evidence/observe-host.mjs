import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, specification, countText, expected = '1'] = process.argv.slice(2);
const spec = JSON.parse(fs.readFileSync(specification, 'utf8'));
const count = BigInt(countText);
let hides = 0;
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), {benchmark: {
  input_i64: index => BigInt(spec.inputs[index]),
  expected_i64: index => BigInt(spec.expected[Number(index)]),
  hide_i64: value => { hides++; return value; },
}});
const entries = Object.entries(instance.exports).filter(([key]) => key.startsWith('observed:'));
instance.exports.main();
const before = Object.fromEntries(entries.map(([name, counter]) => [name, counter.value]));
assert.equal(hides, 0);
assert.equal(instance.exports.bench(count), BigInt(expected));
assert.equal(hides, 2 * Number(count));
const observed = Object.fromEntries(entries.map(([name, counter]) =>
  [name.slice('observed:'.length), (counter.value - before[name]).toString()]));
assert.equal(observed['function:$function51'], count.toString());
assert.equal(observed['function:$export0'], '1');
console.log(JSON.stringify({count: countText, hides, result: expected, observed}, null, 2));
