(module
 (rec
  (type $type29 (struct (field i32)))
  (type $1 (func (param i64 (ref $type19) i32 i32 i64 (ref $type20)) (result (ref $type20))))
  (type $type21 (struct (field (ref $environment46))))
  (type $type19 (struct (field (ref $environment45))))
  (type $call28 (func (param i64) (result i64)))
  (type $call17 (func (param (ref null $type12) (ref null $type12)) (result i32)))
  (type $6 (func (param i32 i32 i64) (result i64)))
  (type $environment46 (struct (field i64) (field i64) (field i64)))
  (type $call21 (func (param (ref $environment46) (ref $type20)) (result i32)))
  (type $environment45 (struct (field i64) (field i64) (field i64) (field (ref $type20)) (field (ref $type29)) (field (ref $type29))))
  (type $call19 (func (param (ref $environment45)) (result (ref $type20))))
  (type $11 (func (param i32 i32 (ref null $type12) i64 (ref $type12)) (result (ref null $type12))))
  (type $12 (func (param i32 i32 (ref null $type12) i64) (result (ref null $type12))))
  (type $13 (func (param (ref $type30) (ref $type31) i32 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i64) (result i32)))
  (type $14 (func (param i32 i32 i64 (ref $type12)) (result (ref null $type12))))
  (type $type30 (struct (field (mut (ref null $type12)))))
  (type $type31 (struct (field (mut (ref $type16)))))
  (type $17 (func (param i64 (ref $type20) (ref $type29) i64 i64) (result i32)))
  (type $type20 (array (mut (ref null $type16))))
  (type $19 (func (param i64 i64 (ref $type20) i32 i32 i64) (result i32)))
  (type $20 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $21 (func (param i32 i32 (ref null $type16) i64) (result i64)))
  (type $type16 (struct (field (ref null $type12)) (field (ref null $type16))))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $call24 (func (param (ref null $type16)) (result i64)))
  (type $type28 (struct))
  (type $type22 (struct (field (ref $type19)) (field (ref $type21))))
  (type $type27 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type15 (struct))
  (type $type14 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $37 (func (param i64) (result i64)))
 (type $38 (func (param i32) (result i64)))
 (type $39 (func (result i64)))
 (type $40 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (import "benchmark" "count" (func $foreign2 (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type11)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global92 (mut (ref null $type13)) (ref.null none))
 (global $ready92 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type13)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type14)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type15)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type17)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type18)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type14)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global94 (mut (ref null $type23)) (ref.null none))
 (global $ready94 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type24)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type25)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type27)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global137 (mut i64) (i64.const 0))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global138 (mut i64) (i64.const 0))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global142 (mut i64) (i64.const 0))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global143 (mut i64) (i64.const 0))
 (global $ready143 (mut i32) (i32.const 0))
 (global $global144 (mut i64) (i64.const 0))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type22)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type28)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function25 (type $call24) (param $0 (ref null $type16)) (result i64)
  (local $1 i64)
  (local $2 (ref null $type12))
  (local $3 (ref null $type16))
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $3
     (struct.get $type16 1
      (local.get $0)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.is_null
       (local.tee $2
        (struct.get $type16 0
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $1
        (struct.get $type12 0
         (local.get $2)
        )
       )
       (if (result i64)
        (ref.is_null
         (local.tee $2
          (struct.get $type12 1
           (local.get $2)
          )
         )
        )
        (then
         (local.get $1)
        )
        (else
         (local.set $1
          (i64.add
           (struct.get $type12 0
            (local.get $2)
           )
           (local.get $1)
          )
         )
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type12 1
             (local.get $2)
            )
           )
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $1
            (i64.add
             (struct.get $type12 0
              (local.get $2)
             )
             (local.get $1)
            )
           )
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $1)
            )
            (else
             (local.set $1
              (i64.add
               (struct.get $type12 0
                (local.get $2)
               )
               (local.get $1)
              )
             )
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (i64.add
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (local.get $1)
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (i64.add
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (local.get $1)
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $3)
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $0
       (struct.get $type16 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (ref.is_null
         (local.tee $2
          (struct.get $type16 0
           (local.get $3)
          )
         )
        )
       )
       (then
        (local.set $1
         (i64.add
          (struct.get $type12 0
           (local.get $2)
          )
          (local.get $1)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type12 1
             (local.get $2)
            )
           )
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $1
            (i64.add
             (struct.get $type12 0
              (local.get $2)
             )
             (local.get $1)
            )
           )
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $1)
            )
            (else
             (local.set $1
              (i64.add
               (struct.get $type12 0
                (local.get $2)
               )
               (local.get $1)
              )
             )
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (i64.add
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (local.get $1)
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (i64.add
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (local.get $1)
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $3
         (struct.get $type16 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (ref.is_null
           (local.tee $2
            (struct.get $type16 0
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.set $1
           (i64.add
            (struct.get $type12 0
             (local.get $2)
            )
            (local.get $1)
           )
          )
          (local.set $1
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $1)
            )
            (else
             (local.set $1
              (i64.add
               (struct.get $type12 0
                (local.get $2)
               )
               (local.get $1)
              )
             )
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (i64.add
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (local.get $1)
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (i64.add
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (local.get $1)
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $3)
         )
         (then
          (local.get $1)
         )
         (else
          (local.set $0
           (struct.get $type16 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (ref.is_null
             (local.tee $2
              (struct.get $type16 0
               (local.get $3)
              )
             )
            )
           )
           (then
            (local.set $1
             (i64.add
              (struct.get $type12 0
               (local.get $2)
              )
              (local.get $1)
             )
            )
            (local.set $1
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (i64.add
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (local.get $1)
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (i64.add
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (local.get $1)
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $3
             (struct.get $type16 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (ref.is_null
               (local.tee $2
                (struct.get $type16 0
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.set $1
               (i64.add
                (struct.get $type12 0
                 (local.get $2)
                )
                (local.get $1)
               )
              )
              (local.set $1
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (i64.add
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (local.get $1)
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $3)
             )
             (then
              (local.get $1)
             )
             (else
              (local.set $0
               (struct.get $type16 1
                (local.get $3)
               )
              )
              (if
               (i32.eqz
                (ref.is_null
                 (local.tee $2
                  (struct.get $type16 0
                   (local.get $3)
                  )
                 )
                )
               )
               (then
                (local.set $1
                 (i64.add
                  (struct.get $type12 0
                   (local.get $2)
                  )
                  (local.get $1)
                 )
                )
                (local.set $1
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (i64.add
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $3
                 (struct.get $type16 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type16 0
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (then
                  (local.set $1
                   (i64.add
                    (struct.get $type12 0
                     (local.get $2)
                    )
                    (local.get $1)
                   )
                  )
                  (local.set $1
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (local.set $1
                      (i64.add
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (local.get $1)
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $3)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (local.set $0
                   (struct.get $type16 1
                    (local.get $3)
                   )
                  )
                  (if
                   (i32.eqz
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type16 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (then
                    (local.set $1
                     (i64.add
                      (struct.get $type12 0
                       (local.get $2)
                      )
                      (local.get $1)
                     )
                    )
                    (local.set $1
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $3
                     (struct.get $type16 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type16 0
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (then
                      (local.set $1
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.add
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $1)
                        )
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (return_call $function26
                       (i32.const 0)
                       (i32.const 1)
                       (struct.get $type16 1
                        (local.get $3)
                       )
                       (call $function27
                        (i32.const 0)
                        (i32.const 1)
                        (struct.get $type16 0
                         (local.get $3)
                        )
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function26 (type $21) (param $0 i32) (param $1 i32) (param $2 (ref null $type16)) (param $3 i64) (result i64)
  (local $4 (ref null $type16))
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type16 1
      (local.get $2)
     )
    )
    (local.set $3
     (call $function27
      (i32.const 0)
      (i32.const 1)
      (struct.get $type16 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function26
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function27 (type $20) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 (ref null $type12))
  (local $5 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $5
     (struct.get $type12 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function27
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (i64.add
      (local.get $3)
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function32 (type $19) (param $0 i64) (param $1 i64) (param $2 (ref $type20)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 (ref null $type16))
  (if (result i32)
   (i64.gt_s
    (local.get $0)
    (local.get $5)
   )
   (then
    (local.set $7
     (if (result (ref null $type16))
      (i64.gt_s
       (local.get $0)
       (local.tee $6
        (i64.add
         (local.get $1)
         (local.get $5)
        )
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $6)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type20
        (local.get $2)
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (local.get $2)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function32
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function33 (type $17) (param $0 i64) (param $1 (ref $type20)) (param $2 (ref $type29)) (param $3 i64) (param $4 i64) (result i32)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $type12))
  (local $8 (ref null $type12))
  (local $9 (ref null $type12))
  (local $10 (ref $type31))
  (local $11 (ref $type30))
  (if (result i32)
   (i64.lt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (local.set $8
     (if (result (ref null $type12))
      (i64.eqz
       (local.get $0)
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready92)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global92)
        )
       )
       (local.set $7
        (struct.new $type12
         (local.get $0)
         (ref.null none)
        )
       )
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $5
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (local.set $7
          (struct.new $type12
           (local.get $5)
           (local.get $7)
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $5
            (i64.sub
             (local.get $5)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $7)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $7
            (struct.new $type12
             (local.get $5)
             (local.get $7)
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $5
              (i64.sub
               (local.get $5)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $7)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $7
              (struct.new $type12
               (local.get $5)
               (local.get $7)
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $5
                (i64.sub
                 (local.get $5)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $7)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $7
                (struct.new $type12
                 (local.get $5)
                 (local.get $7)
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $5
                  (i64.sub
                   (local.get $5)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $7)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $7
                  (struct.new $type12
                   (local.get $5)
                   (local.get $7)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $5
                    (i64.sub
                     (local.get $5)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $7
                    (struct.new $type12
                     (local.get $5)
                     (local.get $7)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $6
                      (i64.sub
                       (local.get $5)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (local.set $5
                      (i64.sub
                       (local.get $6)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $7
                      (struct.new $type12
                       (local.get $6)
                       (local.get $7)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $5)
                      )
                      (then
                       (local.get $7)
                      )
                      (else
                       (call $function35
                        (i32.const 0)
                        (i32.const 1)
                        (i64.sub
                         (local.get $5)
                         (i64.const 1)
                        )
                        (struct.new $type12
                         (local.get $5)
                         (local.get $7)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready94)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global94)
     )
    )
    (local.set $9
     (struct.get $type30 0
      (local.tee $11
       (struct.new $type30
        (local.get $8)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (local.set $10
     (struct.new $type31
      (struct.new $type16
       (local.get $8)
       (ref.null none)
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $5
        (if (result i64)
         (ref.is_null
          (local.get $9)
         )
         (then
          (i64.const 0)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $8
             (struct.get $type12 1
              (local.get $9)
             )
            )
           )
           (then
            (i64.const 1)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $8
               (struct.get $type12 1
                (local.get $8)
               )
              )
             )
             (then
              (i64.const 2)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $8
                 (struct.get $type12 1
                  (local.get $8)
                 )
                )
               )
               (then
                (i64.const 3)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $8
                   (struct.get $type12 1
                    (local.get $8)
                   )
                  )
                 )
                 (then
                  (i64.const 4)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $8
                     (struct.get $type12 1
                      (local.get $8)
                     )
                    )
                   )
                   (then
                    (i64.const 5)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $8
                       (struct.get $type12 1
                        (local.get $8)
                       )
                      )
                     )
                     (then
                      (i64.const 6)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $8
                         (struct.get $type12 1
                          (local.get $8)
                         )
                        )
                       )
                       (then
                        (i64.const 7)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $8
                           (struct.get $type12 1
                            (local.get $8)
                           )
                          )
                         )
                         (then
                          (i64.const 8)
                         )
                         (else
                          (call $function39
                           (i32.const 0)
                           (i32.const 1)
                           (struct.get $type12 1
                            (local.get $8)
                           )
                           (i64.const 9)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.const 1)
      )
      (then
       (call $function41
        (local.get $11)
        (local.get $10)
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (i32.const 0)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.sub
         (local.get $5)
         (i64.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (local.get $1)
     (i32.wrap_i64
      (local.get $3)
     )
     (struct.get $type31 0
      (local.get $10)
     )
    )
    (return_call $function33
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function35 (type $14) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref $type12)) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (local.get $0)
     (local.get $1)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (struct.new $type12
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function39 (type $20) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function39
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function41 (type $13) (param $0 (ref $type30)) (param $1 (ref $type31)) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i32) (param $10 i32) (param $11 i32) (param $12 i32) (param $13 i64) (result i32)
  (local $14 (ref null $type12))
  (local $15 (ref null $type12))
  (local $16 (ref null $type12))
  (local $17 (ref $type12))
  (local $18 i64)
  (local $19 i64)
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $13)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.gt_s
      (local.tee $4
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 1)
     )
     (then
      (return_call $function41
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i32.const 0)
       (i32.const 1)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (local.get $12)
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $18
        (i64.sub
         (local.get $4)
         (i64.const 1)
        )
       )
       (i64.const 1)
      )
      (then
       (call $function41
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $18)
        (i32.const 0)
        (i32.const 1)
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (local.get $12)
        (i64.sub
         (local.get $18)
         (i64.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (local.set $15
     (struct.get $type30 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (local.set $14
     (if (result (ref null $type12))
      (i64.eqz
       (local.get $4)
      )
      (then
       (local.get $15)
      )
      (else
       (local.set $14
        (struct.get $type12 1
         (local.get $15)
        )
       )
       (if
        (i32.eqz
         (local.get $10)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready92)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global92)
        )
       )
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $18
          (i64.sub
           (local.get $4)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $14)
        )
        (else
         (local.set $14
          (struct.get $type12 1
           (local.get $14)
          )
         )
         (if
          (i32.eqz
           (local.get $10)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $18
            (i64.sub
             (local.get $18)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $14)
          )
          (else
           (local.set $14
            (struct.get $type12 1
             (local.get $14)
            )
           )
           (if
            (i32.eqz
             (local.get $10)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $18
              (i64.sub
               (local.get $18)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $14)
            )
            (else
             (local.set $14
              (struct.get $type12 1
               (local.get $14)
              )
             )
             (if
              (i32.eqz
               (local.get $10)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $18
                (i64.sub
                 (local.get $18)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $14)
              )
              (else
               (local.set $14
                (struct.get $type12 1
                 (local.get $14)
                )
               )
               (if
                (i32.eqz
                 (local.get $10)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $18
                  (i64.sub
                   (local.get $18)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $14)
                )
                (else
                 (local.set $14
                  (struct.get $type12 1
                   (local.get $14)
                  )
                 )
                 (if
                  (i32.eqz
                   (local.get $10)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $18
                    (i64.sub
                     (local.get $18)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $14)
                  )
                  (else
                   (local.set $14
                    (struct.get $type12 1
                     (local.get $14)
                    )
                   )
                   (if
                    (i32.eqz
                     (local.get $10)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $18
                      (i64.sub
                       (local.get $18)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $14)
                    )
                    (else
                     (local.set $14
                      (struct.get $type12 1
                       (local.get $14)
                      )
                     )
                     (if
                      (i32.eqz
                       (local.get $10)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $18
                      (i64.sub
                       (local.get $18)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $18)
                      )
                      (then
                       (local.get $14)
                      )
                      (else
                       (local.set $14
                        (struct.get $type12 1
                         (local.get $14)
                        )
                       )
                       (if
                        (i32.eqz
                         (local.get $10)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function43
                        (local.get $9)
                        (local.get $10)
                        (local.get $14)
                        (i64.sub
                         (local.get $18)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $12)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (struct.set $type30 0
     (local.get $0)
     (if (result (ref null $type12))
      (i64.eqz
       (local.get $4)
      )
      (then
       (local.get $14)
      )
      (else
       (local.set $16
        (struct.get $type12 1
         (local.get $15)
        )
       )
       (local.set $17
        (struct.new $type12
         (struct.get $type12 0
          (local.get $15)
         )
         (block (result (ref null $type12))
          (if
           (i32.eqz
            (local.get $12)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready92)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global92)
           )
          )
          (local.get $14)
         )
        )
       )
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $18
          (i64.sub
           (local.get $4)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $17)
        )
        (else
         (local.set $15
          (struct.get $type12 1
           (local.get $16)
          )
         )
         (local.set $17
          (struct.new $type12
           (struct.get $type12 0
            (local.get $16)
           )
           (block (result (ref $type12))
            (if
             (i32.eqz
              (local.get $12)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready92)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global92)
             )
            )
            (local.get $17)
           )
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $18
            (i64.sub
             (local.get $18)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $17)
          )
          (else
           (local.set $14
            (struct.get $type12 1
             (local.get $15)
            )
           )
           (local.set $17
            (struct.new $type12
             (struct.get $type12 0
              (local.get $15)
             )
             (block (result (ref $type12))
              (if
               (i32.eqz
                (local.get $12)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready92)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global92)
               )
              )
              (local.get $17)
             )
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $18
              (i64.sub
               (local.get $18)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $17)
            )
            (else
             (local.set $15
              (struct.get $type12 1
               (local.get $14)
              )
             )
             (local.set $17
              (struct.new $type12
               (struct.get $type12 0
                (local.get $14)
               )
               (block (result (ref $type12))
                (if
                 (i32.eqz
                  (local.get $12)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready92)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global92)
                 )
                )
                (local.get $17)
               )
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $18
                (i64.sub
                 (local.get $18)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $17)
              )
              (else
               (local.set $14
                (struct.get $type12 1
                 (local.get $15)
                )
               )
               (local.set $17
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $15)
                 )
                 (block (result (ref $type12))
                  (if
                   (i32.eqz
                    (local.get $12)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready92)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global92)
                   )
                  )
                  (local.get $17)
                 )
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $18
                  (i64.sub
                   (local.get $18)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $17)
                )
                (else
                 (local.set $15
                  (struct.get $type12 1
                   (local.get $14)
                  )
                 )
                 (local.set $17
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $14)
                   )
                   (block (result (ref $type12))
                    (if
                     (i32.eqz
                      (local.get $12)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready92)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global92)
                     )
                    )
                    (local.get $17)
                   )
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $18
                    (i64.sub
                     (local.get $18)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $17)
                  )
                  (else
                   (local.set $14
                    (struct.get $type12 1
                     (local.get $15)
                    )
                   )
                   (local.set $17
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $15)
                     )
                     (block (result (ref $type12))
                      (if
                       (i32.eqz
                        (local.get $12)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready92)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global92)
                       )
                      )
                      (local.get $17)
                     )
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $18
                      (i64.sub
                       (local.get $18)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $17)
                    )
                    (else
                     (local.set $15
                      (struct.get $type12 1
                       (local.get $14)
                      )
                     )
                     (local.set $17
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $14)
                       )
                       (block (result (ref $type12))
                        (if
                         (i32.eqz
                          (local.get $12)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $18
                         (i64.sub
                          (local.get $18)
                          (i64.const 1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready92)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global92)
                         )
                        )
                        (local.get $17)
                       )
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $18)
                      )
                      (then
                       (local.get $17)
                      )
                      (else
                       (local.set $14
                        (struct.get $type12 1
                         (local.get $15)
                        )
                       )
                       (local.set $19
                        (struct.get $type12 0
                         (local.get $15)
                        )
                       )
                       (if
                        (i32.eqz
                         (local.get $12)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function44
                        (local.get $11)
                        (local.get $12)
                        (local.get $14)
                        (i64.sub
                         (local.get $18)
                         (i64.const 1)
                        )
                        (struct.new $type12
                         (local.get $19)
                         (local.get $17)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (struct.set $type31 0
     (local.get $1)
     (struct.new $type16
      (struct.get $type30 0
       (local.get $0)
      )
      (struct.get $type31 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function41
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (local.get $11)
     (local.get $12)
     (i64.sub
      (local.get $13)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $12) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function44 (type $11) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (param $4 (ref $type12)) (result (ref null $type12))
  (local $5 (ref null $type12))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $5
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $6
     (struct.get $type12 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (local.get $0)
     (local.get $1)
     (local.get $5)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (struct.new $type12
      (local.get $6)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function45 (type $call19) (param $0 (ref $environment45)) (result (ref $type20))
  (local $1 (ref $type20))
  (local $2 i64)
  (local $3 i64)
  (drop
   (call $function33
    (struct.get $environment45 0
     (local.get $0)
    )
    (local.tee $1
     (struct.get $environment45 3
      (local.get $0)
     )
    )
    (struct.get $environment45 5
     (local.get $0)
    )
    (i64.sub
     (local.tee $2
      (struct.get $environment45 1
       (local.get $0)
      )
     )
     (local.tee $3
      (struct.get $environment45 2
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
  )
  (drop
   (call $function32
    (local.get $2)
    (local.get $3)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (local.get $1)
 )
 (func $function46 (type $call21) (param $0 (ref $environment46)) (param $1 (ref $type20)) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref null $type16))
  (local $5 (ref null $type16))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i32)
  (local $scratch (ref null $type12))
  (local.set $4
   (array.get $type20
    (local.get $1)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (select
      (local.tee $6
       (i64.sub
        (i64.sub
         (struct.get $environment46 1
          (local.get $0)
         )
         (struct.get $environment46 2
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 0)
      (i64.ge_s
       (local.get $6)
       (i64.const 0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $16
     (i32.and
      (ref.is_null
       (local.tee $5
        (array.get $type20
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (ref.is_null
       (local.get $4)
      )
     )
    )
    (then
     (local.get $16)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready125)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global125)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready125)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global125)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $5)
        )
        (then
         (i32.const 0)
        )
        (else
         (local.set $3
          (struct.get $type16 0
           (local.get $4)
          )
         )
         (local.set $2
          (struct.get $type16 0
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready127)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global127)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.is_null
            (local.get $2)
           )
          )
          (else
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i64.eq
               (struct.get $type12 0
                (local.get $3)
               )
               (struct.get $type12 0
                (local.get $2)
               )
              )
              (then
               (local.set $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (local.set $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready127)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global127)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (ref.is_null
                  (local.get $2)
                 )
                )
                (else
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i64.eq
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (struct.get $type12 0
                      (local.get $2)
                     )
                    )
                    (then
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready127)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global127)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.is_null
                        (local.get $2)
                       )
                      )
                      (else
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i64.eq
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (struct.get $type12 0
                            (local.get $2)
                           )
                          )
                          (then
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (local.set $2
                            (struct.get $type12 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready127)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global127)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (ref.is_null
                              (local.get $2)
                             )
                            )
                            (else
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if (result i32)
                                (i64.eq
                                 (struct.get $type12 0
                                  (local.get $3)
                                 )
                                 (struct.get $type12 0
                                  (local.get $2)
                                 )
                                )
                                (then
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type12 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready127)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global127)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                  )
                                  (else
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (i64.eq
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                       (struct.get $type12 0
                                        (local.get $2)
                                       )
                                      )
                                      (then
                                       (local.set $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $2
                                        (struct.get $type12 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready127)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global127)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $3)
                                        )
                                        (then
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                        )
                                        (else
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (if (result i32)
                                            (i64.eq
                                             (struct.get $type12 0
                                              (local.get $3)
                                             )
                                             (struct.get $type12 0
                                              (local.get $2)
                                             )
                                            )
                                            (then
                                             (local.set $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                             (local.set $2
                                              (struct.get $type12 1
                                               (local.get $2)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready127)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global127)
                                              )
                                             )
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $3)
                                              )
                                              (then
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                              )
                                              (else
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (i32.const 0)
                                                )
                                                (else
                                                 (if (result i32)
                                                  (i64.eq
                                                   (struct.get $type12 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type12 0
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (then
                                                   (local.set $3
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (local.set $2
                                                    (struct.get $type12 1
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready127)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global127)
                                                    )
                                                   )
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $3)
                                                    )
                                                    (then
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (i32.const 0)
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (i64.eq
                                                         (struct.get $type12 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type12 0
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (then
                                                         (local.set $3
                                                          (struct.get $type12 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.get $type12 1
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready127)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global127)
                                                          )
                                                         )
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $3)
                                                          )
                                                          (then
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                            (then
                                                             (i32.const 0)
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (i64.eq
                                                               (struct.get $type12 0
                                                                (local.get $3)
                                                               )
                                                               (struct.get $type12 0
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (then
                                                               (local.set $3
                                                                (struct.get $type12 1
                                                                 (local.get $3)
                                                                )
                                                               )
                                                               (local.set $2
                                                                (struct.get $type12 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if
                                                                (i32.eqz
                                                                 (global.get $ready127)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global127)
                                                                )
                                                               )
                                                               (if (result i32)
                                                                (ref.is_null
                                                                 (local.get $3)
                                                                )
                                                                (then
                                                                 (ref.is_null
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (else
                                                                 (if (result i32)
                                                                  (ref.is_null
                                                                   (local.get $2)
                                                                  )
                                                                  (then
                                                                   (i32.const 0)
                                                                  )
                                                                  (else
                                                                   (if (result i32)
                                                                    (i64.eq
                                                                     (struct.get $type12 0
                                                                      (local.get $3)
                                                                     )
                                                                     (struct.get $type12 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                    (then
                                                                     (call $function50
                                                                      (struct.get $type12 1
                                                                       (local.get $3)
                                                                      )
                                                                      (block (result (ref null $type12))
                                                                       (local.set $scratch
                                                                        (struct.get $type12 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if
                                                                        (i32.eqz
                                                                         (global.get $ready127)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                       )
                                                                       (drop
                                                                        (ref.as_non_null
                                                                         (global.get $global127)
                                                                        )
                                                                       )
                                                                       (local.get $scratch)
                                                                      )
                                                                     )
                                                                    )
                                                                    (else
                                                                     (i32.const 0)
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (else
                                             (i32.const 0)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (else
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (else
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (else
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (i64.eq
     (call $function25
      (local.get $4)
     )
     (i64.div_s
      (i64.mul
       (i64.mul
        (local.tee $6
         (struct.get $environment46 0
          (local.get $0)
         )
        )
        (i64.add
         (local.get $6)
         (i64.const 1)
        )
       )
       (if (result i64)
        (i64.eqz
         (local.get $6)
        )
        (then
         (i64.const 1)
        )
        (else
         (i64.mul
          (if (result i64)
           (i64.eqz
            (local.tee $7
             (i64.sub
              (local.get $6)
              (i64.const 1)
             )
            )
           )
           (then
            (i64.const 1)
           )
           (else
            (i64.mul
             (if (result i64)
              (i64.eqz
               (local.tee $8
                (i64.sub
                 (local.get $7)
                 (i64.const 1)
                )
               )
              )
              (then
               (i64.const 1)
              )
              (else
               (i64.mul
                (if (result i64)
                 (i64.eqz
                  (local.tee $9
                   (i64.sub
                    (local.get $8)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (i64.const 1)
                 )
                 (else
                  (i64.mul
                   (if (result i64)
                    (i64.eqz
                     (local.tee $10
                      (i64.sub
                       (local.get $9)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (i64.const 1)
                    )
                    (else
                     (i64.mul
                      (if (result i64)
                       (i64.eqz
                        (local.tee $11
                         (i64.sub
                          (local.get $10)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (i64.const 1)
                       )
                       (else
                        (i64.mul
                         (if (result i64)
                          (i64.eqz
                           (local.tee $12
                            (i64.sub
                             (local.get $11)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (i64.const 1)
                          )
                          (else
                           (i64.mul
                            (if (result i64)
                             (i64.eqz
                              (local.tee $13
                               (i64.sub
                                (local.get $12)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (i64.const 1)
                             )
                             (else
                              (i64.mul
                               (if (result i64)
                                (i64.eqz
                                 (local.tee $14
                                  (i64.sub
                                   (local.get $13)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 1)
                                )
                                (else
                                 (i64.mul
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $15
                                     (i64.sub
                                      (local.get $14)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 1)
                                   )
                                   (else
                                    (i64.mul
                                     (call $function47
                                      (i32.const 0)
                                      (i32.const 1)
                                      (i64.sub
                                       (local.get $15)
                                       (i64.const 1)
                                      )
                                     )
                                     (local.get $15)
                                    )
                                   )
                                  )
                                  (local.get $14)
                                 )
                                )
                               )
                               (local.get $13)
                              )
                             )
                            )
                            (local.get $12)
                           )
                          )
                         )
                         (local.get $11)
                        )
                       )
                      )
                      (local.get $10)
                     )
                    )
                   )
                   (local.get $9)
                  )
                 )
                )
                (local.get $8)
               )
              )
             )
             (local.get $7)
            )
           )
          )
          (local.get $6)
         )
        )
       )
      )
      (i64.const 2)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function47 (type $6) (param $0 i32) (param $1 i32) (param $2 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (i64.mul
     (call $function47
      (local.get $0)
      (local.get $1)
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function50 (type $call17) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result i32)
  (local $scratch (ref null $type12))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (then
        (return_call $function50
         (struct.get $type12 1
          (local.get $0)
         )
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready127)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global127)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function53 (type $call28) (param $0 i64) (result i64)
  (local $1 (ref $type20))
  (local $2 (ref $type29))
  (local $3 (ref $environment45))
  (local $4 (ref $type19))
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type22 0
    (global.get $global145)
   )
  )
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function46
     (struct.get $type21 0
      (struct.get $type22 1
       (global.get $global145)
      )
     )
     (if (result (ref $type20))
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (drop
        (call $function33
         (struct.get $environment45 0
          (local.tee $3
           (struct.get $type19 0
            (local.get $4)
           )
          )
         )
         (local.tee $1
          (struct.get $environment45 3
           (local.get $3)
          )
         )
         (local.tee $2
          (struct.get $environment45 5
           (local.get $3)
          )
         )
         (i64.sub
          (local.tee $5
           (struct.get $environment45 1
            (local.get $3)
           )
          )
          (local.tee $6
           (struct.get $environment45 2
            (local.get $3)
           )
          )
         )
         (local.get $5)
        )
       )
       (drop
        (call $function32
         (local.get $5)
         (local.get $6)
         (local.get $1)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (if (result (ref $type20))
        (i64.gt_s
         (local.get $0)
         (i64.const 1)
        )
        (then
         (drop
          (call $function33
           (local.tee $7
            (struct.get $environment45 0
             (local.get $3)
            )
           )
           (local.get $1)
           (local.get $2)
           (local.tee $8
            (i64.sub
             (local.get $5)
             (local.get $6)
            )
           )
           (local.get $5)
          )
         )
         (drop
          (call $function32
           (local.get $5)
           (local.get $6)
           (local.get $1)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (if (result (ref $type20))
          (i64.gt_s
           (local.get $0)
           (i64.const 2)
          )
          (then
           (drop
            (call $function33
             (local.get $7)
             (local.get $1)
             (local.get $2)
             (local.get $8)
             (local.get $5)
            )
           )
           (drop
            (call $function32
             (local.get $5)
             (local.get $6)
             (local.get $1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (if (result (ref $type20))
            (i64.gt_s
             (local.get $0)
             (i64.const 3)
            )
            (then
             (drop
              (call $function33
               (local.get $7)
               (local.get $1)
               (local.get $2)
               (local.get $8)
               (local.get $5)
              )
             )
             (drop
              (call $function32
               (local.get $5)
               (local.get $6)
               (local.get $1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (if (result (ref $type20))
              (i64.gt_s
               (local.get $0)
               (i64.const 4)
              )
              (then
               (drop
                (call $function33
                 (local.get $7)
                 (local.get $1)
                 (local.get $2)
                 (local.get $8)
                 (local.get $5)
                )
               )
               (drop
                (call $function32
                 (local.get $5)
                 (local.get $6)
                 (local.get $1)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
               )
               (if (result (ref $type20))
                (i64.gt_s
                 (local.get $0)
                 (i64.const 5)
                )
                (then
                 (drop
                  (call $function33
                   (local.get $7)
                   (local.get $1)
                   (local.get $2)
                   (local.get $8)
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $function32
                   (local.get $5)
                   (local.get $6)
                   (local.get $1)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.const 0)
                  )
                 )
                 (if (result (ref $type20))
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 6)
                  )
                  (then
                   (drop
                    (call $function33
                     (local.get $7)
                     (local.get $1)
                     (local.get $2)
                     (local.get $8)
                     (local.get $5)
                    )
                   )
                   (drop
                    (call $function32
                     (local.get $5)
                     (local.get $6)
                     (local.get $1)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.const 0)
                    )
                   )
                   (if (result (ref $type20))
                    (i64.gt_s
                     (local.get $0)
                     (i64.const 7)
                    )
                    (then
                     (drop
                      (call $function33
                       (local.get $7)
                       (local.get $1)
                       (local.get $2)
                       (local.get $8)
                       (local.get $5)
                      )
                     )
                     (drop
                      (call $function32
                       (local.get $5)
                       (local.get $6)
                       (local.get $1)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (if (result (ref $type20))
                      (i64.gt_s
                       (local.get $0)
                       (i64.const 8)
                      )
                      (then
                       (drop
                        (call $function33
                         (local.get $7)
                         (local.get $1)
                         (local.get $2)
                         (i64.sub
                          (local.get $5)
                          (local.get $6)
                         )
                         (local.get $5)
                        )
                       )
                       (drop
                        (call $function32
                         (local.get $5)
                         (local.get $6)
                         (local.get $1)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.const 0)
                        )
                       )
                       (if (result (ref $type20))
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 9)
                        )
                        (then
                         (call $function54
                          (local.get $0)
                          (local.get $4)
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 10)
                          (call $function45
                           (local.get $3)
                          )
                         )
                        )
                        (else
                         (local.get $1)
                        )
                       )
                      )
                      (else
                       (local.get $1)
                      )
                     )
                    )
                    (else
                     (local.get $1)
                    )
                   )
                  )
                  (else
                   (local.get $1)
                  )
                 )
                )
                (else
                 (local.get $1)
                )
               )
              )
              (else
               (local.get $1)
              )
             )
            )
            (else
             (local.get $1)
            )
           )
          )
          (else
           (local.get $1)
          )
         )
        )
        (else
         (local.get $1)
        )
       )
      )
      (else
       (array.new_fixed $type20 0)
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function54 (type $1) (param $0 i64) (param $1 (ref $type19)) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 (ref $type20)) (result (ref $type20))
  (if (result (ref $type20))
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (local.set $5
     (call $function45
      (struct.get $type19 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
     (local.get $5)
    )
   )
   (else
    (local.get $5)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global146)
   )
  )
  (return_call $function53
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type29))
  (local $4 (ref $type20))
  (local $scratch i64)
  (local $scratch_6 i64)
  (local $scratch_7 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type11)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global92
   (struct.new_default $type13)
  )
  (global.set $ready92
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type13)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type14)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type15)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type17)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type18)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type14)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global94
   (struct.new_default $type23)
  )
  (global.set $ready94
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type24)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type25)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global72
   (struct.new_default $type27)
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global137
   (call $foreign2)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready139)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (global.set $global138
   (call $foreign0
    (global.get $global137)
   )
  )
  (global.set $ready138
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global142
   (call $foreign0
    (block (result i64)
     (local.set $scratch
      (call $foreign1
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready139)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global139)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (global.set $ready142
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global143
   (call $foreign0
    (block (result i64)
     (local.set $scratch_6
      (call $foreign1
       (i32.const 1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready139)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global139)
      )
     )
     (local.get $scratch_6)
    )
   )
  )
  (global.set $ready143
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global144
   (call $foreign0
    (block (result i64)
     (local.set $scratch_7
      (call $foreign1
       (i32.const 2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready139)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global139)
      )
     )
     (local.get $scratch_7)
    )
   )
  )
  (global.set $ready144
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready143)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready144)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global72)
   )
  )
  (local.set $2
   (global.get $global142)
  )
  (local.set $0
   (global.get $global143)
  )
  (local.set $1
   (global.get $global144)
  )
  (global.set $global145
   (if (result (ref $type22))
    (if (result i32)
     (i64.ge_s
      (global.get $global138)
      (i64.const 0)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready77)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global77)
       )
      )
      (if (result i32)
       (i64.gt_s
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready77)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global77)
         )
        )
        (i32.and
         (i32.and
          (i64.ge_s
           (local.get $0)
           (local.get $1)
          )
          (i64.ge_s
           (local.get $1)
           (i64.const 0)
          )
         )
         (i64.gt_s
          (local.get $0)
          (i64.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.gt_u
       (local.get $0)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $3
      (struct.new $type29
       (i32.const 1)
      )
     )
     (drop
      (call $function33
       (local.get $2)
       (local.tee $4
        (array.new_default $type20
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (local.get $3)
       (i64.const 0)
       (i64.sub
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready130)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (struct.new $type22
      (struct.new $type19
       (struct.new $environment45
        (local.get $2)
        (local.get $0)
        (local.get $1)
        (local.get $4)
        (struct.new $type29
         (i32.const 1)
        )
        (local.get $3)
       )
      )
      (struct.new $type21
       (struct.new $environment46
        (local.get $2)
        (local.get $0)
        (local.get $1)
       )
      )
     )
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type28)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

