(import
  (only (chezscheme) vector-copy)
  (only (chezscheme)
    current-time
    machine-type
    scheme-version-number
    time-nanosecond
    time-second)
  (except
    (rename (rnrs) (define-record-type r6rs:define-record-type))
    bitwise-and
    bitwise-not
    div
    mod
    partition)
  (rnrs mutable-pairs)
  (rnrs mutable-strings)
  (rnrs r5rs))

(define-syntax define-record-type
  ;; Simplistic R7RS to R6RS define-record-type transformation.
  (syntax-rules ()
    ((define-record-type name
      (make-name param ...)
      name?
      (field-name field-ref field-set!)
      ...)
     (r6rs:define-record-type (name make-name name?)
       (protocol
         (lambda (new)
           (lambda (param ...)
             (new param ...))))
       (fields
         (mutable field-name field-ref field-set!)
         ...)))))

(define (exact-integer? z)
  (and (exact? z) (integer? z)))

 (define read-line
   get-line)

(define (square x)
  (* x x))

(define write-string
  (case-lambda
    ((string)
      (put-string (current-output-port) string))
    ((string port)
      (put-string port string))
    ((string port start)
      (put-string port string start))
    ((string port start end)
      (put-string port string start (fx+ (fx- end start) 1)))))
;; R7RS benchmark timing for compiled Chez programs. The upstream Petite-Chez
;; prelude supplies language compatibility; the benchmark body is unchanged.
;; Use Chez's monotonic clock and integer nanoseconds, not two wall-clock reads.

(define (current-jiffy)
  (let ((now (current-time 'time-monotonic)))
    (+ (* (time-second now) 1000000000) (time-nanosecond now))))

(define (jiffies-per-second) 1000000000)

(define (current-second)
  (/ (current-jiffy) 1000000000.0))

(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define-syntax define-overload (syntax-rules () ((_ . declaration) (begin))))
(define-syntax define-data
  (lambda (form)
    (syntax-case form ()
      ((context name variant ...)
       (datum->syntax #'context
         (cons 'begin
           (apply append
             (map (lambda (variant)
                    (let ((tag (car variant)) (fields (cdr variant)))
                      (cons `(define (,tag ,@(map car fields)) (vector ',tag ,@(map car fields)))
                        (let loop ((fields fields) (index 1))
                          (if (null? fields) '()
                              (append
                                (if (= (length (car fields)) 3)
                                    `((define (,(caddar fields) value)
                                        (unless (eq? (vector-ref value 0) ',tag)
                                          (error ',tag "wrong typed variant" value))
                                        (vector-ref value ,index))) '())
                                (loop (cdr fields) (+ index 1))))))))
                  (syntax->datum #'(variant ...))))))))))
(define-syntax match
  (lambda (form)
    (syntax-case form ()
      ((context value arm ...)
       (let ((temporary (syntax->datum (car (generate-temporaries #'(value))))))
         (datum->syntax #'context
           `(let ((,temporary ,(syntax->datum #'value)))
              (cond
                ,@(map (lambda (arm)
                         (let ((pattern (car arm)))
                           `((eq? (vector-ref ,temporary 0) ',(car pattern))
                             (let ,(let loop ((names (cdr pattern)) (index 1))
                                     (if (null? names) '()
                                         (cons `(,(car names) (vector-ref ,temporary ,index))
                                           (loop (cdr names) (+ index 1)))))
                               ,@(cdr arm)))))
                       (syntax->datum #'(arm ...)))
                (else (error 'match "invalid typed variant" ,temporary))))))))))
(define (unit) (if #f #f))
(define (unreachable) (error 'reader "unreachable typed branch"))
(define (ref value) (vector value))
(define (ref-get value) (vector-ref value 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define ref-eq? eq?)
(define vector-eq? eq?)
(define string-eq? eq?)
(define bytevector-eq? eq?)
(define i32-eq eqv?)
(define i32->i64 values)
(define i64->i32 values)
(define i64->f64 inexact)
(define (f64->i64 value)
  (unless (and (finite? value) (<= -9223372036854775808.0 value) (< value 9223372036854775808.0))
    (error 'f64->i64 "out of range" value))
  (exact (truncate value)))
(define (empty-vector) (vector))
;; The identical Datum body hashes complete wrapping I64 words. Chez's generic
;; integers do not wrap, so these scalar adapters make that boundary explicit.
(define (i64-word value)
  (let ((bits (bitwise-bit-field value 0 64)))
    (if (< bits 9223372036854775808) bits (- bits 18446744073709551616))))
(define (i64-add a b) (i64-word (+ a b)))
(define (i64-mul a b) (i64-word (* a b)))
(define (i64-bitwise-and a b) (bitwise-if a b 0))
(define i64-bitwise-xor bitwise-xor)
(define (i64-shift-right/logical value count)
  (i64-word (bitwise-arithmetic-shift-right (bitwise-bit-field value 0 64)
                                          (bitwise-bit-field count 0 6))))
(define (string-copy! target at source start end)
  (do ((index start (+ index 1))) ((= index end))
    (string-set! target (+ at (- index start)) (string-ref source index))))
(define (vector-copy! target at source start end)
  (let ((count (- end start)))
    (if (and (eq? target source) (> at start))
        (do ((index (- count 1) (- index 1))) ((< index 0))
          (vector-set! target (+ at index) (vector-ref source (+ start index))))
        (do ((index 0 (+ index 1))) ((= index count))
          (vector-set! target (+ at index) (vector-ref source (+ start index)))))))
(define reader-interface
(let ((host-read-char read-char) (host-peek-char peek-char) (host-string->number string->number) (host-number->string number->string) (host-string->symbol string->symbol) (host-symbol->string symbol->string))
(define scalar-interface (let ()
;; Chez implements only the scalar token ABI here. Integer, Rational, Number,
;; Datum and reader operations use their unchanged strict-library bodies.

;; ---- Validated lexical fields retain exactness until Scheme conversion ----

(define-data TokenScalar
  (token-integer (value I64)) (token-real (value F64))
  (token-fraction (numerator String) (denominator String)
                  (radix I64) (scale I64) (inexact Bool)))
(define-data TokenNumber
  (token-scalar (value TokenScalar))
  (token-rectangular (real TokenScalar) (imaginary TokenScalar))
  (token-polar (radius TokenScalar) (angle TokenScalar) (exact Bool)))
(define-data TokenFailure (token-failure (message String token-failure-message)))
(define (token-failure? value)
  (and (vector? value) (eq? (vector-ref value 0) 'token-failure)))
(define (text-index text predicate)
  (let loop ((at 0))
    (and (< at (string-length text))
         (if (predicate (string-ref text at)) at (loop (+ at 1))))))
(define (text-starts? text character)
  (and (> (string-length text) 0) (char=? (string-ref text 0) character)))
(define (without-sign text)
  (if (or (text-starts? text #\+) (text-starts? text #\-))
      (substring text 1 (string-length text)) text))
(define (digit-value character)
  (cond ((char<=? #\0 character #\9) (- (char->integer character) 48))
        ((char<=? #\a character #\f) (- (char->integer character) 87))
        ((char<=? #\A character #\F) (- (char->integer character) 55))
        (else 16)))
(define (unsigned-digits? text radix)
  (and (> (string-length text) 0)
       (let loop ((at 0))
         (or (= at (string-length text))
             (and (< (digit-value (string-ref text at)) radix) (loop (+ at 1)))))))
(define (signed-digits? text radix) (unsigned-digits? (without-sign text) radix))
(define (zero-digits? text)
  (let loop ((at 0))
    (or (= at (string-length text))
        (and (char=? (string-ref text at) #\0) (loop (+ at 1))))))

;; A bounded scan distinguishes the I64 case without first constructing a host
;; bignum. Larger tokens retain their digits for the identical Integer body.
(define (bounded-magnitude digits radix limit)
  (let loop ((at 0) (value 0))
    (if (= at (string-length digits)) value
        (let ((digit (digit-value (string-ref digits at))))
          (and (<= digit limit) (<= value (quotient (- limit digit) radix))
               (loop (+ at 1) (+ (* value radix) digit)))))))
(define (bounded-integer text radix)
  (let* ((negative (text-starts? text #\-))
         (value (bounded-magnitude (without-sign text) radix
                                   (if negative 9223372036854775808 9223372036854775807))))
    (and value (if negative (- value) value))))
(define (integer-token text radix inexact?)
  (let ((value (bounded-integer text radix)))
    (if value
        (if inexact? (token-real (if (and (= value 0) (text-starts? text #\-))
                                     -0.0 (inexact value))) (token-integer value))
        (token-fraction text "1" radix 0 inexact?))))
(define (ratio-token text slash radix inexact?)
  (let ((numerator (substring text 0 slash))
        (denominator (substring text (+ slash 1) (string-length text))))
    (and (signed-digits? numerator radix) (unsigned-digits? denominator radix)
         (if (zero-digits? denominator) (token-failure "zero denominator in numeric token")
             (token-fraction numerator denominator radix 0 inexact?)))))

;; ---- Binary64 parsing accepts the Rust scalar grammar, not Chez extensions ----

(define (exponent-character? character) (or (char=? character #\e) (char=? character #\E)))
(define (decimal-mantissa? text)
  (let ((dot (text-index text (lambda (character) (char=? character #\.)))))
    (if dot
        (let ((digits (string-append (substring text 0 dot)
                                     (substring text (+ dot 1) (string-length text)))))
          (unsigned-digits? digits 10))
        (unsigned-digits? text 10))))
(define (decimal-text? text)
  (let* ((text (without-sign text)) (exponent (text-index text exponent-character?)))
    (if exponent
        (and (decimal-mantissa? (substring text 0 exponent))
             (signed-digits? (substring text (+ exponent 1) (string-length text)) 10))
        (and (text-index text (lambda (character) (char=? character #\.)))
             (decimal-mantissa? text)))))
(define (nonfinite-token text)
  (cond ((string-ci=? text "+inf.0") +inf.0) ((string-ci=? text "-inf.0") -inf.0)
        ((or (string-ci=? text "+nan.0") (string-ci=? text "-nan.0")) +nan.0)
        (else #f)))
(define (parse-binary64 text)
  (or (nonfinite-token text) (and (decimal-text? text) (host-string->number text))))
(define (decimal-scale exponent places)
  ;; Bound the exponent by the final scale before scanning. An exponent just
  ;; above I64_MAX can still fit after fractional places are subtracted. These
  ;; bounded host index intermediates never become Scheme numeric values.
  (let* ((negative (text-starts? exponent #\-))
         (limit (if negative (- 9223372036854775807 places) (+ 9223372036854775807 places)))
         (value (and (>= limit 0) (bounded-magnitude (without-sign exponent) 10 limit))))
    (if value (- (if negative (- value) value) places)
        (token-failure "exact decimal exponent exceeds supported allocation index range"))))
(define (exact-decimal-parts text mantissa exponent)
  (let* ((dot (text-index mantissa (lambda (character) (char=? character #\.))))
         (digits (if dot (string-append (substring mantissa 0 dot)
                                        (substring mantissa (+ dot 1) (string-length mantissa))) mantissa))
         (places (if dot (- (string-length mantissa) dot 1) 0)))
    (cond ((not (unsigned-digits? digits 10)) (token-failure "nonfinite number has no exact value"))
          ((zero-digits? digits) (token-integer 0))
          (else (let ((scale (decimal-scale exponent places)))
                  (if (token-failure? scale) scale
                      (token-fraction (if (text-starts? text #\-) (string-append "-" digits) digits)
                                      "1" 10 scale #f)))))))
(define (exact-decimal-token text)
  (let* ((unsigned (without-sign text)) (at (text-index unsigned exponent-character?)))
    (exact-decimal-parts text (if at (substring unsigned 0 at) unsigned)
                         (if at (substring unsigned (+ at 1) (string-length unsigned)) "0"))))
(define (decimal-token text exactness)
  (if (eq? exactness 'exact)
      (cond ((nonfinite-token text) (token-failure "nonfinite number has no exact value"))
            ((decimal-text? text) (exact-decimal-token text)) (else #f))
      (let ((value (parse-binary64 text))) (and value (token-real value)))))
(define (real-token text radix exactness)
  (let ((slash (text-index text (lambda (character) (char=? character #\/)))))
    (cond (slash (ratio-token text slash radix (eq? exactness 'inexact)))
          ((signed-digits? text radix) (integer-token text radix (eq? exactness 'inexact)))
          ((= radix 10) (decimal-token text exactness))
          (else #f))))

;; ---- Prefixes and complete components are interpreted before shortcuts ----

(define (numeric-prefixes text radix)
  (let loop ((at 0) (radix radix) (seen-radix #f) (exactness 'automatic))
    (if (and (< (+ at 1) (string-length text)) (char=? (string-ref text at) #\#))
        (let ((prefix (char-downcase (string-ref text (+ at 1)))))
          (cond ((and (memv prefix '(#\e #\i)) (eq? exactness 'automatic))
                 (loop (+ at 2) radix seen-radix (if (char=? prefix #\e) 'exact 'inexact)))
                ((and (memv prefix '(#\b #\o #\d #\x)) (not seen-radix))
                 (loop (+ at 2) (case prefix ((#\b) 2) ((#\o) 8) ((#\x) 16) (else 10)) #t exactness))
                (else #f)))
        (vector (substring text at (string-length text)) radix exactness))))
(define (token-components first second radix exactness kind)
  (let ((left (real-token first radix exactness)))
    (if (token-failure? left) left
        (let ((right (real-token second radix exactness)))
          (cond ((token-failure? right) right) ((not (and left right)) #f)
                ((eq? kind 'rectangular) (token-rectangular left right))
                (else (token-polar left right (eq? exactness 'exact))))))))
(define (rectangular-split body radix)
  (let loop ((at (- (string-length body) 1)))
    (and (> at 0)
         (if (and (memv (string-ref body at) '(#\+ #\-))
                  (not (and (= radix 10) (exponent-character? (string-ref body (- at 1))))))
             at (loop (- at 1))))))
(define (rectangular-token body radix exactness)
  (let* ((split (rectangular-split body radix))
         (real (if split (substring body 0 split) "0"))
         (imaginary (if split (substring body split (string-length body)) body)))
    (and (or (text-starts? imaginary #\+) (text-starts? imaginary #\-))
         (token-components real (if (= (string-length imaginary) 1)
                                    (string-append imaginary "1") imaginary)
                           radix exactness 'rectangular))))
(define (prefixed-number-token fields)
  (let* ((text (vector-ref fields 0)) (radix (vector-ref fields 1)) (exactness (vector-ref fields 2))
         (size (string-length text)) (polar (text-index text (lambda (character) (char=? character #\@)))))
    (cond (polar (token-components (substring text 0 polar) (substring text (+ polar 1) size)
                                   radix exactness 'polar))
          ((and (> size 0) (char-ci=? (string-ref text (- size 1)) #\i))
           (rectangular-token (substring text 0 (- size 1)) radix exactness))
          (else (let ((value (real-token text radix exactness)))
                  (if (or (not value) (token-failure? value)) value (token-scalar value)))))))
(define (number-token text radix)
  (and (memv radix '(2 8 10 16))
       (let ((prefixes (numeric-prefixes text radix)))
         (and prefixes (prefixed-number-token prefixes)))))

;; ---- Typed ABI projections expose only the requested scalar field ----

(define (token-scalar-kind scalar)
  (match scalar ((token-integer value) 1) ((token-real value) 2)
         ((token-fraction numerator denominator radix scale inexact) (if inexact 6 5))))
(define (token-number-kind number)
  (match number ((token-scalar value) (token-scalar-kind value))
         ((token-rectangular real imaginary) 3) ((token-polar radius angle exact) (if exact 8 7))))
(define (token-component number part)
  (match number
    ((token-scalar value) (if (= part 0) value (error 'token "numeric component index out of range")))
    ((token-rectangular real imaginary)
     (case part ((0) real) ((1) imaginary) (else (error 'token "numeric component index out of range"))))
    ((token-polar radius angle exact)
     (case part ((0) radius) ((1) angle) (else (error 'token "numeric component index out of range"))))))
(define (token-scalar-integer scalar)
  (unless (eq? (vector-ref scalar 0) 'token-integer)
    (error 'token "numeric component is not a machine integer"))
  (vector-ref scalar 1))
(define (token-scalar-real scalar)
  (unless (eq? (vector-ref scalar 0) 'token-real)
    (error 'token "numeric component is not inexact"))
  (vector-ref scalar 1))
(define (token-scalar-fraction scalar)
  (unless (eq? (vector-ref scalar 0) 'token-fraction)
    (error 'token "numeric component has no exact digit fields"))
  scalar)
(define (token-scalar-text scalar term)
  (match (token-scalar-fraction scalar)
    ((token-fraction numerator denominator radix scale inexact)
     (case term ((0) numerator) ((1) denominator) (else (error 'token "exact numeric term index out of range"))))))
(define (token-scalar-radix scalar)
  (match (token-scalar-fraction scalar) ((token-fraction numerator denominator radix scale inexact) radix)))
(define (token-scalar-scale scalar)
  (match (token-scalar-fraction scalar) ((token-fraction numerator denominator radix scale inexact) scale)))

;; ---- Binary64 text uses a shortest decimal with Rust's display layout ----

;; The layout follows Rust Debug: exponent notation below 10^-4 and from 10^16,
;; with a decimal point for finite values rendered without an exponent. Chez's
;; choice of shortest digits must be compared byte for byte with the target,
;; including tie-sensitive values; round-trip equality alone is insufficient.
(define (without-precision text)
  ;; Chez appends an R6RS precision suffix to subnormals, for example 5e-324|1.
  ;; It describes the binary64 value, not part of the decimal exponent.
  (let ((at (text-index text (lambda (character) (char=? character #\|)))))
    (if at (substring text 0 at) text)))
(define (decimal-layout text)
  (let* ((negative (text-starts? text #\-)) (unsigned (without-sign text))
         (at (text-index unsigned exponent-character?))
         (mantissa (if at (substring unsigned 0 at) unsigned))
         (exponent (if at (host-string->number (substring unsigned (+ at 1) (string-length unsigned))) 0))
         (dot (text-index mantissa (lambda (character) (char=? character #\.))))
         (digits (if dot (string-append (substring mantissa 0 dot)
                                        (substring mantissa (+ dot 1) (string-length mantissa))) mantissa)))
    (vector negative digits (+ exponent (if dot dot (string-length mantissa))))))
(define (trim-decimal-layout layout)
  (let* ((digits (vector-ref layout 1)) (count (string-length digits)))
    (let start ((first 0))
      (if (and (< first (- count 1)) (char=? (string-ref digits first) #\0)) (start (+ first 1))
          (let end ((last count))
            (if (and (> last (+ first 1)) (char=? (string-ref digits (- last 1)) #\0)) (end (- last 1))
                (vector (vector-ref layout 0) (substring digits first last) (- (vector-ref layout 2) first))))))))
(define (scientific-decimal digits point)
  (let ((exponent (- point 1)))
    (string-append (substring digits 0 1)
                   (if (= (string-length digits) 1) "" (string-append "." (substring digits 1 (string-length digits))))
                   "e" (if (>= exponent 0) "+" "") (host-number->string exponent))))
(define (fixed-decimal digits point)
  (let ((count (string-length digits)))
    (cond ((<= point 0) (string-append "0." (make-string (- point) #\0) digits))
          ((>= point count) (string-append digits (make-string (- point count) #\0) ".0"))
          (else (string-append (substring digits 0 point) "." (substring digits point count))))))
(define (binary64-text value)
  (cond ((nan? value) "+nan.0") ((= value +inf.0) "+inf.0") ((= value -inf.0) "-inf.0")
        ((= value 0.0) (if (eqv? value -0.0) "-0.0" "0.0"))
        (else (let* ((layout (trim-decimal-layout (decimal-layout (without-precision (host-number->string value)))))
                     (digits (vector-ref layout 1)) (point (vector-ref layout 2)))
                (string-append (if (vector-ref layout 0) "-" "")
                               (if (or (<= point -4) (> point 16)) (scientific-decimal digits point)
                                   (fixed-decimal digits point)))))))

(define-data CharacterResult (character-end) (character-value (value Char)))
(define (read-char port)
  (let ((value (host-read-char port)))
    (if (eof-object? value) (character-end) (character-value value))))
(define (peek-char port)
  (let ((value (host-peek-char port)))
    (if (eof-object? value) (character-end) (character-value value))))
(define (has-character? text character)
  (let loop ((index 0))
    (and (< index (string-length text))
         (or (char=? (string-ref text index) character) (loop (+ index 1))))))
(define (initial? character)
  (or (char-alphabetic? character) (has-character? "!$%&*/:<=>?^_~@" character)))
(define (sign-next? character) (or (initial? character) (has-character? "+-" character)))
(define (dot-next? character) (or (sign-next? character) (char=? character #\.)))
(define (identifier-text? text)
  (let ((size (string-length text)))
    (define (at index predicate) (and (< index size) (predicate (string-ref text index))))
    (define (tail index)
      (or (= index size)
          (and (let ((c (string-ref text index)))
                 (or (initial? c) (char<=? #\0 c #\9) (has-character? "+-." c)))
               (tail (+ index 1)))))
    (and (> size 0)
         (let ((first (string-ref text 0)))
           (cond ((has-character? "+-" first)
                  (or (= size 1) (if (char=? (string-ref text 1) #\.)
                                    (and (at 2 dot-next?) (tail 3))
                                    (and (at 1 sign-next?) (tail 2)))))
                 ((char=? first #\.) (and (at 1 dot-next?) (tail 2)))
                 (else (and (initial? first) (tail 1))))))))
(define (temporary-open) (vector 'text '() #f))
(define (temporary-state handle)
  (let ((state (vector-ref handle 0)))
    (when (eq? state 'closed) (error 'token "invalid or closed token handle"))
    state))
(define (temporary-text handle)
  (case (temporary-state handle)
    ((text) (list->string (reverse (vector-ref handle 1))))
    ((parsed error) (vector-ref handle 2))
    (else (error 'token "invalid or closed token handle"))))
(define (temporary-character handle character)
  (unless (eq? (temporary-state handle) 'text) (error 'token "token has already been parsed"))
  (vector-set! handle 1 (cons character (vector-ref handle 1))))
(define (temporary-close handle)
  (temporary-state handle)
  (vector-set! handle 0 'closed) (vector-set! handle 1 #f) (vector-set! handle 2 #f))
(define (temporary-parse-radix handle radix)
  (unless (eq? (temporary-state handle) 'text)
    (temporary-close handle) (error 'token "token has already been parsed"))
  (let* ((text (temporary-text handle)) (value (number-token text radix)))
    (vector-set! handle 2 text)
    (vector-set! handle 0 (if (token-failure? value) 'error 'parsed))
    (vector-set! handle 1 value)
    (cond ((token-failure? value) 4) (value (token-number-kind value)) (else 0))))
(define (temporary-parse handle) (temporary-parse-radix handle 10))
(define (numeric-component handle index)
  (unless (and (eq? (temporary-state handle) 'parsed) (vector-ref handle 1))
    (error 'token "token has no successful numeric result"))
  (token-component (vector-ref handle 1) index))
(define (temporary-error handle)
  (unless (eq? (temporary-state handle) 'error) (error 'token "token has no numeric error"))
  (token-failure-message (vector-ref handle 1)))
(define (temporary-intern handle)
  (let ((allowed (or (eq? (temporary-state handle) 'text)
                     (and (eq? (temporary-state handle) 'parsed) (not (vector-ref handle 1)))))
        (text (temporary-text handle)))
    (temporary-close handle)
    (unless allowed (error 'token "symbol interning requires an unparsed text handle"))
    (host-string->symbol text)))
(define (temporary-fail handle)
  (let ((text (temporary-text handle))) (temporary-close handle) (error 'reader text)))
(define (scalar-service name)
  (cond
    ((string=? name "snail:datum/token-open") temporary-open)
    ((string=? name "snail:datum/token-character") temporary-character)
    ((string=? name "snail:datum/token-close") temporary-close)
    ((string=? name "snail:datum/token-parse") temporary-parse)
    ((string=? name "snail:datum/token-parse-radix") temporary-parse-radix)
    ((string=? name "snail:datum/token-text-length") (lambda (handle) (string-length (temporary-text handle))))
    ((string=? name "snail:datum/token-text-character") (lambda (handle index) (string-ref (temporary-text handle) index)))
    ((string=? name "snail:datum/token-identifier")
     (lambda (handle) (if (identifier-text? (temporary-text handle)) 1 0)))
    ((string=? name "snail:datum/token-intern") temporary-intern)
    ((string=? name "snail:datum/number-kind")
     (lambda (handle index) (token-scalar-kind (numeric-component handle index))))
    ((string=? name "snail:datum/number-integer")
     (lambda (handle index) (token-scalar-integer (numeric-component handle index))))
    ((string=? name "snail:datum/number-real")
     (lambda (handle index) (token-scalar-real (numeric-component handle index))))
    ((string=? name "snail:datum/number-radix")
     (lambda (handle index) (token-scalar-radix (numeric-component handle index))))
    ((string=? name "snail:datum/number-scale")
     (lambda (handle index) (token-scalar-scale (numeric-component handle index))))
    ((string=? name "snail:datum/number-text-length")
     (lambda (handle index term) (string-length (token-scalar-text (numeric-component handle index) term))))
    ((string=? name "snail:datum/number-text-character")
     (lambda (handle index term at) (string-ref (token-scalar-text (numeric-component handle index) term) at)))
    ((string=? name "snail:datum/error-length") (lambda (handle) (string-length (temporary-error handle))))
    ((string=? name "snail:datum/error-character") (lambda (handle index) (string-ref (temporary-error handle) index)))
    ((string=? name "snail:datum/fail") temporary-fail)
    ((string=? name "snail:datum/symbol-length") (lambda (name) (string-length (host-symbol->string name))))
    ((string=? name "snail:datum/symbol-character") (lambda (name index) (string-ref (host-symbol->string name) index)))
    ((string=? name "snail:datum/real-equivalent")
     (lambda (left right) (if (or (eqv? left right) (and (nan? left) (nan? right))) 1 0)))
    ((string=? name "snail:datum/real-text")
     (lambda (value) (vector 'text (reverse (string->list (binary64-text value))) #f)))
    ((string=? name "snail:datum/whitespace") (lambda (character) (if (char-whitespace? character) 1 0)))
    (else (error 'scalar-service "unknown scalar export" name))))
(vector scalar-service read-char peek-char)))
(define scalar-service (vector-ref scalar-interface 0))
(define read-char (vector-ref scalar-interface 1))
(define peek-char (vector-ref scalar-interface 2))
(define-syntax define-extern
  (syntax-rules () ((_ name module foreign signature) (define name (scalar-service foreign)))))
(let ((library-interface (let ()

    ;; ---- Canonical magnitude and private ownership ----

    ;; A limb is in [0, 2^30). I32 stores it without a sign bit; I64 holds
    ;; products, sums and carries. Zero alone has no limbs and no negative sign.
    ;; No constructor or limb accessor is exported. Sharing in abs/negate is
    ;; safe because every published array is readonly to all library operations.
    (define radix 1073741824)
    (define limb-bits 30)
    (define-data Integer
      (integer (negative Bool integer-negative?) (limbs (Vector I32) integer-limbs)))
    (define-data IntegerDivision
      (division (quotient Integer division-quotient) (remainder Integer division-remainder)))
    (define-data IntegerRoot
      (root (value Integer root-value) (remainder Integer root-remainder)))
    (define zero (integer #f (ann (empty-vector) (Vector I32))))
    (: limb (-> (Vector I32) I64 I64))
    (define (limb digits index) (i32->i64 (vector-ref digits index)))
    (: put-limb! (-> (Vector I32) I64 I64 Unit))
    (define (put-limb! digits index value) (vector-set! digits index (i64->i32 value)))
    (: fresh-limbs (-> I64 (Vector I32)))
    (define (fresh-limbs count) (make-vector count (ann 0 I32)))
    (: significant-length (-> (Vector I32) I64))
    (define (significant-length digits)
      (let loop ((count (vector-length digits)))
        (if (or (= count 0) (not (= (limb digits (- count 1)) 0))) count
            (loop (- count 1)))))
    (: trimmed-limbs (-> (Vector I32) (Vector I32)))
    (define (trimmed-limbs digits)
      (let ((count (significant-length digits)))
        (if (= count (vector-length digits)) digits
            (let ((result (fresh-limbs count)))
              (vector-copy! result 0 digits 0 count) result))))
    (: publish (-> Bool (Vector I32) Integer))
    (define (publish negative digits)
      (let ((digits (trimmed-limbs digits)))
        (if (= (vector-length digits) 0) zero (integer negative digits))))
    (: integer-zero? (-> Integer Bool))
    (define (integer-zero? value) (= (vector-length (integer-limbs value)) 0))
    (: integer-abs (-> Integer Integer))
    (define (integer-abs value)
      (if (integer-negative? value) (integer #f (integer-limbs value)) value))
    (: integer-negate (-> Integer Integer))
    (define (integer-negate value)
      (if (integer-zero? value) value
          (integer (not (integer-negative? value)) (integer-limbs value))))

    ;; ---- Exact signed machine-integer conversion ----

    ;; Keeping the source nonpositive avoids negating I64_MIN. Each remainder
    ;; lies in (-radix, 0], so negating one limb is always representable.
    (: machine-limb-count (-> I64 I64))
    (define (machine-limb-count value)
      (let loop ((value value) (count 0))
        (if (= value 0) count (loop (quotient value radix) (+ count 1)))))
    (: integer-from-i64 (-> I64 Integer))
    (define (integer-from-i64 value)
      (let* ((negative (< value 0)) (value (if (> value 0) (- 0 value) value))
             (digits (fresh-limbs (machine-limb-count value))))
        (let loop ((value value) (index 0))
          (if (= value 0) (publish negative digits)
              (begin (put-limb! digits index (- 0 (remainder value radix)))
                     (loop (quotient value radix) (+ index 1)))))))
    (: integer->i64 (-> Integer I64))
    (define (integer->i64 value)
      (let* ((digits (integer-limbs value)) (negative (integer-negative? value))
             (limit (if negative -9223372036854775808 -9223372036854775807)))
        (let loop ((count (vector-length digits)) (result 0))
          (if (= count 0) (if negative result (- 0 result))
              (let ((digit (limb digits (- count 1))))
                ;; quotient on this negative numerator is its mathematical ceiling.
                (if (< result (quotient (+ limit digit) radix)) (unreachable)
                    (loop (- count 1) (- (* result radix) digit))))))))

    ;; ---- Magnitude order and signed comparison ----

    (: magnitude-compare (-> (Vector I32) (Vector I32) I64))
    (define (magnitude-compare left right)
      (let ((a (vector-length left)) (b (vector-length right)))
        (if (< a b) -1 (if (> a b) 1
                           (let loop ((count a))
                             (if (= count 0) 0
                                 (let ((a (limb left (- count 1))) (b (limb right (- count 1))))
                                   (if (< a b) -1 (if (> a b) 1 (loop (- count 1)))))))))))
    (: integer-compare (-> Integer Integer I64))
    (define (integer-compare left right)
      (if (not (= (if (integer-negative? left) 1 0) (if (integer-negative? right) 1 0)))
          (if (integer-negative? left) -1 1)
          (let ((order (magnitude-compare (integer-limbs left) (integer-limbs right))))
            (if (integer-negative? left) (- 0 order) order))))
    (: integer=? (-> Integer Integer Bool))
    (define (integer=? left right) (= (integer-compare left right) 0))
    (: integer<? (-> Integer Integer Bool))
    (define (integer<? left right) (< (integer-compare left right) 0))
    (: integer<=? (-> Integer Integer Bool))
    (define (integer<=? left right) (<= (integer-compare left right) 0))
    (: integer>? (-> Integer Integer Bool))
    (define (integer>? left right) (> (integer-compare left right) 0))
    (: integer>=? (-> Integer Integer Bool))
    (define (integer>=? left right) (>= (integer-compare left right) 0))

    ;; ---- Addition and subtraction expose carry and borrow ----

    (: limb-or-zero (-> (Vector I32) I64 I64))
    (define (limb-or-zero digits index)
      (if (< index (vector-length digits)) (limb digits index) 0))
    (: magnitude-add (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-add left right)
      (let* ((count (if (> (vector-length left) (vector-length right))
                        (vector-length left) (vector-length right)))
             (result (fresh-limbs (+ count 1))))
        (let loop ((index 0) (carry 0))
          (if (= index count) (begin (put-limb! result count carry) result)
              (let ((sum (+ (+ (limb-or-zero left index) (limb-or-zero right index)) carry)))
                (put-limb! result index (remainder sum radix))
                (loop (+ index 1) (quotient sum radix)))))))
    ;; left >= right is established by the signed operation before entry.
    (: magnitude-subtract (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-subtract left right)
      (let* ((count (vector-length left)) (result (fresh-limbs count)))
        (let loop ((index 0) (borrow 0))
          (if (= index count) result
              (let ((difference (- (- (limb left index) (limb-or-zero right index)) borrow)))
                (put-limb! result index (if (< difference 0) (+ difference radix) difference))
                (loop (+ index 1) (if (< difference 0) 1 0)))))))
    (: signed-difference (-> Bool (Vector I32) (Vector I32) Integer))
    (define (signed-difference negative left right)
      (if (< (magnitude-compare left right) 0)
          (publish (not negative) (magnitude-subtract right left))
          (publish negative (magnitude-subtract left right))))
    (: integer-add (-> Integer Integer Integer))
    (define (integer-add left right)
      (let ((a (integer-limbs left)) (b (integer-limbs right)))
        (if (if (integer-negative? left) (integer-negative? right) (not (integer-negative? right)))
            (publish (integer-negative? left) (magnitude-add a b))
            (signed-difference (integer-negative? left) a b))))
    (: integer-subtract (-> Integer Integer Integer))
    (define (integer-subtract left right) (integer-add left (integer-negate right)))

    ;; ---- Schoolbook products with bounded I64 accumulation ----

    ;; (B-1)^2 + (B-1) + (B-1) = B^2-1 < 2^60. Therefore each
    ;; multiply/add/carry transition is exact before division by B. A row's
    ;; final carry goes into a previously untouched output position.
    (: multiply-row! (-> (Vector I32) (Vector I32) I64 I64 Unit))
    (define (multiply-row! result right offset factor)
      (let ((count (vector-length right)))
        (let loop ((index 0) (carry 0))
          (if (= index count) (put-limb! result (+ offset count) carry)
              (let* ((at (+ offset index))
                     (product (+ (+ (* factor (limb right index)) (limb result at)) carry)))
                (put-limb! result at (remainder product radix))
                (loop (+ index 1) (quotient product radix)))))))
    (: magnitude-multiply (-> (Vector I32) (Vector I32) (Vector I32)))
    (define (magnitude-multiply left right)
      (let ((result (fresh-limbs (+ (vector-length left) (vector-length right)))))
        (let loop ((index 0))
          (if (= index (vector-length left)) result
              (begin (multiply-row! result right index (limb left index))
                     (loop (+ index 1)))))))
    (: integer-multiply (-> Integer Integer Integer))
    (define (integer-multiply left right)
      (if (or (integer-zero? left) (integer-zero? right)) zero
          (publish (if (integer-negative? left) (not (integer-negative? right))
                       (integer-negative? right))
                   (magnitude-multiply (integer-limbs left) (integer-limbs right)))))
    ;; factor is positive and below B. Keeping one extra limb is sufficient.
    (: magnitude-scale (-> (Vector I32) I64 (Vector I32)))
    (define (magnitude-scale digits factor)
      (let* ((count (vector-length digits)) (result (fresh-limbs (+ count 1))))
        (let loop ((index 0) (carry 0))
          (if (= index count) (begin (put-limb! result count carry) result)
              (let ((product (+ (* (limb digits index) factor) carry)))
                (put-limb! result index (remainder product radix))
                (loop (+ index 1) (quotient product radix)))))))

    ;; ---- Single-limb division ----

    ;; A private quotient buffer may alias its source: traversal is high to low,
    ;; and each old limb is consumed before its slot is overwritten. The caller
    ;; never passes a published limb array as target. Return the scalar remainder.
    (: divide-small! (-> (Vector I32) (Vector I32) I64 I64))
    (define (divide-small! target source divisor)
      (let loop ((count (vector-length source)) (carry 0))
        (if (= count 0) carry
            (let ((value (+ (* carry radix) (limb source (- count 1)))))
              (put-limb! target (- count 1) (quotient value divisor))
              (loop (- count 1) (remainder value divisor))))))

    ;; ---- Normalized long division ----

    ;; Knuth's normalization makes the highest divisor limb >= B/2.
    ;; The two-high-limb estimate is never low and at most two high. Checking
    ;; the next limb reduces that error to at most one; full subtraction decides
    ;; the last correction. Every numerator/product is below B^2 = 2^60.
    (: estimate-digit (-> (Vector I32) (Vector I32) I64 I64))
    (define (estimate-digit dividend divisor offset)
      (let* ((count (vector-length divisor)) (high (limb divisor (- count 1)))
             (numerator (+ (* (limb dividend (+ offset count)) radix)
                           (limb dividend (- (+ offset count) 1))))
             (trial (quotient numerator high)) (trial (if (>= trial radix) (- radix 1) trial)))
        (let correct ((trial trial) (residue (- numerator (* trial high))))
          (if (and (< residue radix)
                   (> (* trial (limb divisor (- count 2)))
                      (+ (* residue radix) (limb dividend (- (+ offset count) 2)))))
              (correct (- trial 1) (+ residue high)) trial))))
    ;; Trial, divisor digit and incoming carry are in [0, B-1]. Thus
    ;; product <= B*(B-1) < 2^60: masking and logical shifting split it exactly.
    ;; If its high word is B-1, product must be B*(B-1), so its low word is
    ;; zero and subtraction cannot borrow. Otherwise high+borrow <= B-1 too.
    ;; The low difference lies in (-B, B); adding B restores one limb.
    (: subtract-product! (-> (Vector I32) (Vector I32) I64 I64 Bool))
    (define (subtract-product! dividend divisor offset trial)
      (let ((count (vector-length divisor)))
        (let loop ((index 0) (carry 0))
          (if (= index count)
              (let ((high (- (limb dividend (+ offset count)) carry)))
                (when (or (< high -1) (> high 0)) (unreachable))
                (put-limb! dividend (+ offset count) (if (< high 0) (+ high radix) high))
                (< high 0))
              (let* ((product (+ (* trial (limb divisor index)) carry))
                     (difference (- (limb dividend (+ offset index))
                                    (i64-bitwise-and product (- radix 1)))))
                (put-limb! dividend (+ offset index) (if (< difference 0) (+ difference radix) difference))
                (loop (+ index 1) (+ (i64-shift-right/logical product limb-bits)
                                     (if (< difference 0) 1 0))))))))
    (: add-back! (-> (Vector I32) (Vector I32) I64 Unit))
    (define (add-back! dividend divisor offset)
      (let ((count (vector-length divisor)))
        (let loop ((index 0) (carry 0))
          (if (= index count)
              (put-limb! dividend (+ offset count)
                         (remainder (+ (limb dividend (+ offset count)) carry) radix))
              (let ((sum (+ (+ (limb dividend (+ offset index)) (limb divisor index)) carry)))
                (put-limb! dividend (+ offset index) (remainder sum radix))
                (loop (+ index 1) (quotient sum radix)))))))
    (: divide-position! (-> (Vector I32) (Vector I32) I64 I64))
    (define (divide-position! dividend divisor offset)
      (let ((trial (estimate-digit dividend divisor offset)))
        (if (subtract-product! dividend divisor offset trial)
            (begin (add-back! dividend divisor offset) (- trial 1)) trial)))
    (: divide-normalized! (-> (Vector I32) (Vector I32) (Vector I32) Unit))
    (define (divide-normalized! quotient-digits dividend divisor)
      (let loop ((count (vector-length quotient-digits)))
        (unless (= count 0)
          (put-limb! quotient-digits (- count 1) (divide-position! dividend divisor (- count 1)))
          (loop (- count 1)))))
    (: long-division (-> (Vector I32) (Vector I32) IntegerDivision))
    (define (long-division left right)
      (let* ((count (vector-length right))
             (scale (quotient radix (+ (limb right (- count 1)) 1)))
             (dividend (magnitude-scale left scale))
             (divisor (trimmed-limbs (magnitude-scale right scale)))
             (answer (fresh-limbs (+ (- (vector-length left) count) 1)))
             (residue (fresh-limbs count)))
        (divide-normalized! answer dividend divisor)
        (vector-copy! residue 0 dividend 0 count)
        (unless (= (divide-small! residue residue scale) 0) (unreachable))
        (division (publish #f answer) (publish #f residue))))
    (: divide-magnitudes (-> Integer Integer IntegerDivision))
    (define (divide-magnitudes left right)
      (let ((a (integer-limbs left)) (b (integer-limbs right)))
        (if (< (magnitude-compare a b) 0) (division zero (integer-abs left))
            (if (= (vector-length b) 1)
                (let* ((answer (fresh-limbs (vector-length a)))
                       (residue (divide-small! answer a (limb b 0))))
                  (division (publish #f answer) (integer-from-i64 residue)))
                (long-division a b)))))
    (: integer-divide (-> Integer Integer IntegerDivision))
    (define (integer-divide left right)
      (if (integer-zero? right) (unreachable)
          (let* ((result (divide-magnitudes left right))
                 (q (division-quotient result)) (r (division-remainder result)))
            (division (if (if (integer-negative? left) (not (integer-negative? right))
                              (integer-negative? right)) (integer-negate q) q)
                      (if (integer-negative? left) (integer-negate r) r)))))
    (: integer-quotient (-> Integer Integer Integer))
    (define (integer-quotient left right) (division-quotient (integer-divide left right)))
    (: integer-remainder (-> Integer Integer Integer))
    (define (integer-remainder left right) (division-remainder (integer-divide left right)))

    ;; ---- Decimal text with independent mutable strings ----

    ;; Nine decimal digits fit in a limb. Grouped conversion does one linear
    ;; magnitude pass per chunk, rather than one per character. ASCII signs and
    ;; digits only are accepted; empty input, whitespace and prefixes trap.
    (: decimal-chunk (-> String I64 I64 I64))
    (define (decimal-chunk text start end)
      (let loop ((index start) (value 0))
        (if (= index end) value
            (let ((digit (- (char->integer (string-ref text index)) 48)))
              (if (or (< digit 0) (> digit 9)) (unreachable)
                  (loop (+ index 1) (+ (* value 10) digit)))))))
    (: machine-power (-> I64 I64 I64))
    (define (machine-power base exponent)
      (let loop ((left exponent) (value 1))
        (if (= left 0) value (loop (- left 1) (* value base)))))
    (: parse-decimal (-> String I64 Bool Integer))
    (define (parse-decimal text start negative)
      (let ((count (string-length text)))
        (if (= start count) (unreachable)
            (let loop ((at start) (value zero))
              (if (= at count) (if negative (integer-negate value) value)
                  (let* ((width (if (> (- count at) 9) 9 (- count at)))
                         (scaled (publish #f (magnitude-scale (integer-limbs value) (machine-power 10 width))))
                         (chunk (integer-from-i64 (decimal-chunk text at (+ at width)))))
                    (loop (+ at width) (integer-add scaled chunk))))))))
    (: integer-from-string (-> String Integer))
    (define (integer-from-string text)
      (if (= (string-length text) 0) (unreachable)
          (let* ((first (string-ref text 0)) (negative (char=? first #\-))
                 (signed (or negative (char=? first #\+))))
            (parse-decimal text (if signed 1 0) negative))))
    (: radix-digit (-> Char I64 I64))
    (define (radix-digit character base)
      (let* ((code (char->integer character))
             (digit (if (and (>= code 48) (<= code 57)) (- code 48)
                        (if (and (>= code 65) (<= code 90)) (- code 55)
                            (if (and (>= code 97) (<= code 122)) (- code 87) -1)))))
        (if (or (< digit 0) (>= digit base)) (unreachable) digit)))
    (: parse-radix-digits (-> String I64 Bool I64 Integer))
    (define (parse-radix-digits text start negative base)
      (if (= start (string-length text)) (unreachable)
          (let loop ((at start) (value zero))
            (if (= at (string-length text)) (if negative (integer-negate value) value)
                (loop (+ at 1) (integer-add (publish #f (magnitude-scale (integer-limbs value) base))
                                            (integer-from-i64 (radix-digit (string-ref text at) base))))))))
    (: integer-from-string/radix (-> String I64 Integer))
    (define (integer-from-string/radix text base)
      (if (or (< base 2) (> base 36) (= (string-length text) 0)) (unreachable)
          (if (= base 10) (integer-from-string text)
              (let* ((first (string-ref text 0)) (negative (char=? first #\-))
                     (start (if (or negative (char=? first #\+)) 1 0)))
                (parse-radix-digits text start negative base)))))
    (: decimal-chunks (-> (Vector I32) (List I64)))
    (define (decimal-chunks digits)
      (let loop ((digits (vector-copy digits)) (chunks '()))
        (if (= (vector-length digits) 0) chunks
            (let ((chunk (divide-small! digits digits 1000000000)))
              (loop (trimmed-limbs digits) (cons chunk chunks))))))
    (: decimal-width (-> I64 I64))
    (define (decimal-width value)
      (let loop ((value value) (count 1))
        (if (< value 10) count (loop (quotient value 10) (+ count 1)))))
    (: chunk-count (-> (List I64) I64))
    (define (chunk-count chunks)
      (let loop ((tail chunks) (count 0))
        (if (null? tail) count (loop (cdr tail) (+ count 1)))))
    (: write-chunk! (-> String I64 I64 I64 Unit))
    (define (write-chunk! text end value width)
      (let loop ((at end) (left width) (value value))
        (unless (= left 0)
          (string-set! text (- at 1) (integer->char (+ 48 (remainder value 10))))
          (loop (- at 1) (- left 1) (quotient value 10)))))
    (: write-chunks! (-> String I64 (List I64) I64 Unit))
    (define (write-chunks! text at chunks width)
      (unless (null? chunks)
        (write-chunk! text (+ at width) (car chunks) width)
        (write-chunks! text (+ at width) (cdr chunks) 9)))
    (: integer->string (-> Integer String))
    (define (integer->string value)
      (if (integer-zero? value) (string #\0)
          (let* ((chunks (decimal-chunks (integer-limbs value)))
                 (width (decimal-width (car chunks))) (sign (if (integer-negative? value) 1 0))
                 (text (make-string (+ (+ sign width) (* 9 (- (chunk-count chunks) 1))))))
            (when (integer-negative? value) (string-set! text 0 #\-))
            (write-chunks! text sign chunks width) text)))

    ;; ---- Nonnegative exponentiation and floor square root ----

    (: half (-> Integer Integer))
    (define (half value)
      (let* ((digits (integer-limbs value)) (result (fresh-limbs (vector-length digits))))
        (divide-small! result digits 2) (publish #f result)))
    (: integer-expt (-> Integer Integer Integer))
    (define (integer-expt base exponent)
      (if (integer-negative? exponent) (unreachable)
          (let loop ((power base) (left exponent) (result (integer-from-i64 1)))
            (if (integer-zero? left) result
                (let ((result (if (= (remainder (limb (integer-limbs left) 0) 2) 0) result
                                  (integer-multiply result power)))
                      (left (half left)))
                  (if (integer-zero? left) result
                      (loop (integer-multiply power power) left result)))))))
    (: integer-power (-> Integer I64 Integer))
    (define (integer-power base exponent) (integer-expt base (integer-from-i64 exponent)))
    (: leading-bits (-> I64 I64))
    (define (leading-bits value)
      (let loop ((value value) (count 0))
        (if (= value 0) count (loop (quotient value 2) (+ count 1)))))
    (: sqrt-upper-bound (-> Integer Integer))
    (define (sqrt-upper-bound value)
      (let* ((digits (integer-limbs value)) (count (vector-length digits))
             (bits (+ (* (- count 1) limb-bits) (leading-bits (limb digits (- count 1)))))
             (exponent (quotient (+ bits 1) 2)) (at (quotient exponent limb-bits))
             (result (fresh-limbs (+ at 1))))
        (put-limb! result at (machine-power 2 (remainder exponent limb-bits)))
        (publish #f result)))
    (: integer-sqrt (-> Integer Integer))
    (define (integer-sqrt value)
      (if (integer-negative? value) (unreachable)
          (if (integer-zero? value) value
              (let loop ((estimate (sqrt-upper-bound value)))
                (let ((next (half (integer-add estimate (integer-quotient value estimate)))))
                  ;; Starting above the root makes every accepted estimate decrease.
                  ;; At floor(sqrt(n)), the next estimate can be larger (n=3).
                  (if (integer>=? next estimate) estimate (loop next)))))))
    (: integer-sqrt/remainder (-> Integer IntegerRoot))
    (define (integer-sqrt/remainder value)
      (let ((root-value (integer-sqrt value)))
        (root root-value (integer-subtract value (integer-multiply root-value root-value)))))

    ;; ---- Exact conversion from finite binary64 integers ----

    ;; Division by the power-of-two limb radix is exact. Once the quotient is
    ;; truncated, cancellation recovers an integer digit smaller than the radix.
    ;; Negative zero maps to the unique exact zero. Fractional/nonfinite inputs
    ;; are rejected; the separately named truncating conversion is explicit.
    (: finite-f64? (-> F64 Bool))
    (define (finite-f64? value)
      (and (= value value) (< value (/ 1.0 0.0)) (> value (/ -1.0 0.0))))
    (: float-limb-count (-> F64 I64))
    (define (float-limb-count value)
      (let loop ((value value) (count 0))
        (if (= value 0.0) count
            (loop (truncate (/ value (i64->f64 radix))) (+ count 1)))))
    (: integer-from-f64 (-> F64 Integer))
    (define (integer-from-f64 value)
      (if (not (and (finite-f64? value) (= value (truncate value)))) (unreachable)
          (let* ((negative (< value 0.0)) (value (if negative (- 0.0 value) value))
                 (digits (fresh-limbs (float-limb-count value))) (base (i64->f64 radix)))
            (let loop ((value value) (at 0))
              (if (= value 0.0) (publish negative digits)
                  (let ((next (truncate (/ value base))))
                    (put-limb! digits at (f64->i64 (- value (* next base))))
                    (loop next (+ at 1))))))))
    (: integer-truncate-f64 (-> F64 Integer))
    (define (integer-truncate-f64 value) (integer-from-f64 (truncate value)))

    ;; ---- One nearest-even rounding from an exact ratio to binary64 ----

    ;; Choose the final binary64 spacing before dividing. The quotient retains
    ;; at most 53 bits; its exact remainder decides rounding once, including
    ;; halfway cases, subnormals, signed underflow and overflow to infinity.
    (: integer-bit-length (-> Integer I64))
    (define (integer-bit-length value)
      (let* ((digits (integer-limbs value)) (count (vector-length digits)))
        (if (= count 0) 0
            (+ (* (- count 1) limb-bits) (leading-bits (limb digits (- count 1)))))))
    (: binary-power (-> I64 Integer))
    (define (binary-power exponent) (integer-power (integer-from-i64 2) exponent))
    (: binary64-power (-> I64 F64))
    (define (binary64-power exponent)
      (let ((factor (if (< exponent 0) 0.5 2.0))
            (count (if (< exponent 0) (- 0 exponent) exponent)))
        (let loop ((left count) (value 1.0))
          (if (= left 0) value (loop (- left 1) (* value factor))))))
    (: ratio-below-power? (-> Integer Integer I64 Bool))
    (define (ratio-below-power? numerator denominator exponent)
      (if (< exponent 0)
          (integer<? (integer-multiply numerator (binary-power (- 0 exponent))) denominator)
          (integer<? numerator (integer-multiply denominator (binary-power exponent)))))
    (: rounded-ratio (-> Integer Integer I64))
    (define (rounded-ratio numerator denominator)
      (let* ((answer (integer-divide numerator denominator))
             (whole (integer->i64 (division-quotient answer)))
             (twice (integer-add (division-remainder answer) (division-remainder answer)))
             (order (integer-compare twice denominator)))
        (if (or (> order 0) (and (= order 0) (= (remainder whole 2) 1))) (+ whole 1) whole)))
    (: scaled-ratio (-> Integer Integer I64 F64))
    (define (scaled-ratio numerator denominator spacing)
      (let ((whole (if (< spacing 0)
                       (rounded-ratio (integer-multiply numerator (binary-power (- 0 spacing))) denominator)
                       (rounded-ratio numerator (integer-multiply denominator (binary-power spacing))))))
        (* (i64->f64 whole) (binary64-power spacing))))
    (: positive-ratio->f64 (-> Integer Integer F64))
    (define (positive-ratio->f64 numerator denominator)
      (let ((estimate (- (integer-bit-length numerator) (integer-bit-length denominator))))
        (if (> estimate 1024) (/ 1.0 0.0)
            (if (< estimate -1075) 0.0
                (let ((exponent (if (ratio-below-power? numerator denominator estimate) (- estimate 1) estimate)))
                  (if (> exponent 1023) (/ 1.0 0.0)
                      (scaled-ratio numerator denominator
                                    (if (< exponent -1022) -1074 (- exponent 52)))))))))
    (: integer-ratio->f64 (-> Integer Integer F64))
    (define (integer-ratio->f64 numerator denominator)
      (if (integer-zero? denominator) (unreachable)
          (if (integer-zero? numerator) 0.0
              (let ((value (positive-ratio->f64 (integer-abs numerator) (integer-abs denominator))))
                (if (if (integer-negative? numerator) (not (integer-negative? denominator))
                        (integer-negative? denominator)) (* -1.0 value) value)))))
    (: integer->f64 (-> Integer F64))
    (define (integer->f64 value) (integer-ratio->f64 value (integer-from-i64 1)))
    (: integer-fits-i64? (-> Integer Bool))
    (define (integer-fits-i64? value)
      (and (integer>=? value (integer-from-i64 -9223372036854775808))
           (integer<=? value (integer-from-i64 9223372036854775807))))

    ;; ---- Euclidean reduction and floor division ----

    (: integer-gcd (-> Integer Integer Integer))
    (define (integer-gcd left right)
      (let loop ((left (integer-abs left)) (right (integer-abs right)))
        (if (integer-zero? right) left (loop right (integer-remainder left right)))))
    (: integer-floor-quotient (-> Integer Integer Integer))
    (define (integer-floor-quotient left right)
      (let ((answer (integer-divide left right)))
        (if (and (not (integer-zero? (division-remainder answer)))
                 (if (integer-negative? left) (not (integer-negative? right)) (integer-negative? right)))
            (integer-subtract (division-quotient answer) (integer-from-i64 1))
            (division-quotient answer))))
    (: integer-modulo (-> Integer Integer Integer))
    (define (integer-modulo left right)
      (integer-subtract left (integer-multiply right (integer-floor-quotient left right))))

    ;; ---- Ordinary static numeric methods ----

    (define-overload + (-> Integer Integer Integer) integer-add)
    (define-overload - (-> Integer Integer Integer) integer-subtract)
    (define-overload - (-> Integer Integer) integer-negate)
    (define-overload * (-> Integer Integer Integer) integer-multiply)
    (define-overload = (-> Integer Integer Bool) integer=?)
    (define-overload < (-> Integer Integer Bool) integer<?)
    (define-overload <= (-> Integer Integer Bool) integer<=?)
    (define-overload > (-> Integer Integer Bool) integer>?)
    (define-overload >= (-> Integer Integer Bool) integer>=?)
    (define-overload quotient (-> Integer Integer Integer) integer-quotient)
    (define-overload remainder (-> Integer Integer Integer) integer-remainder)

(vector integer-from-i64 integer->i64 integer-from-string integer->string integer-from-string/radix integer-fits-i64? integer-from-f64 integer-truncate-f64 integer->f64 integer-ratio->f64 integer-bit-length integer-gcd integer-floor-quotient integer-modulo integer-zero? integer-negative? integer-abs integer-negate integer-compare integer=? integer<? integer<=? integer>? integer>=? integer-add integer-subtract integer-multiply integer-divide division-quotient division-remainder integer-quotient integer-remainder integer-expt integer-power integer-sqrt integer-sqrt/remainder root-value root-remainder))))
  (let ((integer-from-i64 (vector-ref library-interface 0)) (integer->i64 (vector-ref library-interface 1)) (integer-from-string (vector-ref library-interface 2)) (integer->string (vector-ref library-interface 3)) (integer-from-string/radix (vector-ref library-interface 4)) (integer-fits-i64? (vector-ref library-interface 5)) (integer-from-f64 (vector-ref library-interface 6)) (integer-truncate-f64 (vector-ref library-interface 7)) (integer->f64 (vector-ref library-interface 8)) (integer-ratio->f64 (vector-ref library-interface 9)) (integer-bit-length (vector-ref library-interface 10)) (integer-gcd (vector-ref library-interface 11)) (integer-floor-quotient (vector-ref library-interface 12)) (integer-modulo (vector-ref library-interface 13)) (integer-zero? (vector-ref library-interface 14)) (integer-negative? (vector-ref library-interface 15)) (integer-abs (vector-ref library-interface 16)) (integer-negate (vector-ref library-interface 17)) (integer-compare (vector-ref library-interface 18)) (integer=? (vector-ref library-interface 19)) (integer<? (vector-ref library-interface 20)) (integer<=? (vector-ref library-interface 21)) (integer>? (vector-ref library-interface 22)) (integer>=? (vector-ref library-interface 23)) (integer-add (vector-ref library-interface 24)) (integer-subtract (vector-ref library-interface 25)) (integer-multiply (vector-ref library-interface 26)) (integer-divide (vector-ref library-interface 27)) (division-quotient (vector-ref library-interface 28)) (division-remainder (vector-ref library-interface 29)) (integer-quotient (vector-ref library-interface 30)) (integer-remainder (vector-ref library-interface 31)) (integer-expt (vector-ref library-interface 32)) (integer-power (vector-ref library-interface 33)) (integer-sqrt (vector-ref library-interface 34)) (integer-sqrt/remainder (vector-ref library-interface 35)) (root-value (vector-ref library-interface 36)) (root-remainder (vector-ref library-interface 37)))
(let ((library-interface (let ()

    ;; ---- Normalization establishes the representation contract ----

    (define-data Rational
      (rational (numerator Integer rational-numerator) (denominator Integer rational-denominator)))
    (define one (integer-from-i64 1))
    (: make-rational (-> Integer Integer Rational))
    (define (make-rational numerator denominator)
      (if (integer-zero? denominator) (unreachable)
          (let* ((negative (integer-negative? denominator))
                 (numerator (if negative (integer-negate numerator) numerator))
                 (denominator (integer-abs denominator))
                 (factor (integer-gcd numerator denominator)))
            (rational (integer-quotient numerator factor) (integer-quotient denominator factor)))))
    (: rational-from-integer (-> Integer Rational))
    (define (rational-from-integer value) (rational value one))
    (: rational-integer? (-> Rational Bool))
    (define (rational-integer? value) (integer=? (rational-denominator value) one))
    (: rational-zero? (-> Rational Bool))
    (define (rational-zero? value) (integer-zero? (rational-numerator value)))
    (: rational-negative? (-> Rational Bool))
    (define (rational-negative? value) (integer-negative? (rational-numerator value)))
    (: rational-negate (-> Rational Rational))
    (define (rational-negate value)
      (rational (integer-negate (rational-numerator value)) (rational-denominator value)))
    (: rational-abs (-> Rational Rational))
    (define (rational-abs value) (if (rational-negative? value) (rational-negate value) value))

    ;; ---- Arithmetic remains exact before reducing the result ----

    (: rational-add (-> Rational Rational Rational))
    (define (rational-add left right)
      (make-rational
       (integer-add (integer-multiply (rational-numerator left) (rational-denominator right))
                    (integer-multiply (rational-numerator right) (rational-denominator left)))
       (integer-multiply (rational-denominator left) (rational-denominator right))))
    (: rational-subtract (-> Rational Rational Rational))
    (define (rational-subtract left right) (rational-add left (rational-negate right)))
    (: rational-multiply (-> Rational Rational Rational))
    (define (rational-multiply left right)
      (make-rational (integer-multiply (rational-numerator left) (rational-numerator right))
                     (integer-multiply (rational-denominator left) (rational-denominator right))))
    (: rational-divide (-> Rational Rational Rational))
    (define (rational-divide left right)
      (make-rational (integer-multiply (rational-numerator left) (rational-denominator right))
                     (integer-multiply (rational-denominator left) (rational-numerator right))))
    (: rational-truncate (-> Rational Integer))
    (define (rational-truncate value)
      (integer-quotient (rational-numerator value) (rational-denominator value)))
    (: rational-floor (-> Rational Integer))
    (define (rational-floor value)
      (integer-floor-quotient (rational-numerator value) (rational-denominator value)))

    ;; ---- Ordering uses positive denominators and exact cross products ----

    (: rational-compare (-> Rational Rational I64))
    (define (rational-compare left right)
      (integer-compare (integer-multiply (rational-numerator left) (rational-denominator right))
                       (integer-multiply (rational-numerator right) (rational-denominator left))))
    (: rational=? (-> Rational Rational Bool))
    (define (rational=? left right)
      (and (integer=? (rational-numerator left) (rational-numerator right))
           (integer=? (rational-denominator left) (rational-denominator right))))
    (: rational<? (-> Rational Rational Bool))
    (define (rational<? left right) (< (rational-compare left right) 0))
    (: rational<=? (-> Rational Rational Bool))
    (define (rational<=? left right) (<= (rational-compare left right) 0))
    (: rational>? (-> Rational Rational Bool))
    (define (rational>? left right) (> (rational-compare left right) 0))
    (: rational>=? (-> Rational Rational Bool))
    (define (rational>=? left right) (>= (rational-compare left right) 0))

    ;; ---- Binary64 exactness and decimal presentation ----

    ;; A finite fractional binary64 is smaller than 2^52. Scaling it by 2^30
    ;; is exact and cannot overflow. At most 36 steps make every finite binary64
    ;; integral, including the smallest subnormal. Normalization removes powers
    ;; of two shared by the scaled integer and denominator; -0.0 becomes 0/1.
    (: rational-from-f64 (-> F64 Rational))
    (define (rational-from-f64 value)
      (if (not (and (= value value) (< value (/ 1.0 0.0)) (> value (/ -1.0 0.0)))) (unreachable)
          (let loop ((value value) (exponent 0))
            (if (= value (truncate value))
                (make-rational (integer-from-f64 value) (integer-power (integer-from-i64 2) exponent))
                (loop (* value 1073741824.0) (+ exponent 30))))))
    (: rational->f64 (-> Rational F64))
    (define (rational->f64 value)
      (integer-ratio->f64 (rational-numerator value) (rational-denominator value)))
    (: rational->string (-> Rational String))
    (define (rational->string value)
      (let ((numerator (integer->string (rational-numerator value))))
        (if (rational-integer? value) numerator
            (string-append numerator "/" (integer->string (rational-denominator value))))))

    ;; ---- Existing static operator families retain concrete operands ----

    (define-overload + (-> Rational Rational Rational) rational-add)
    (define-overload - (-> Rational Rational Rational) rational-subtract)
    (define-overload - (-> Rational Rational) rational-negate)
    (define-overload * (-> Rational Rational Rational) rational-multiply)
    (define-overload / (-> Rational Rational Rational) rational-divide)
    (define-overload / (-> Integer Integer Rational) make-rational)
    (define-overload = (-> Rational Rational Bool) rational=?)
    (define-overload < (-> Rational Rational Bool) rational<?)
    (define-overload <= (-> Rational Rational Bool) rational<=?)
    (define-overload > (-> Rational Rational Bool) rational>?)
    (define-overload >= (-> Rational Rational Bool) rational>=?)
    (define-overload truncate (-> Rational Integer) rational-truncate)

(vector make-rational rational-numerator rational-denominator rational-from-integer rational-from-f64 rational->f64 rational->string rational-integer? rational-zero? rational-negative? rational-negate rational-abs rational-add rational-subtract rational-multiply rational-divide rational-compare rational=? rational<? rational<=? rational>? rational>=? rational-truncate rational-floor))))
  (let ((make-rational (vector-ref library-interface 0)) (rational-numerator (vector-ref library-interface 1)) (rational-denominator (vector-ref library-interface 2)) (rational-from-integer (vector-ref library-interface 3)) (rational-from-f64 (vector-ref library-interface 4)) (rational->f64 (vector-ref library-interface 5)) (rational->string (vector-ref library-interface 6)) (rational-integer? (vector-ref library-interface 7)) (rational-zero? (vector-ref library-interface 8)) (rational-negative? (vector-ref library-interface 9)) (rational-negate (vector-ref library-interface 10)) (rational-abs (vector-ref library-interface 11)) (rational-add (vector-ref library-interface 12)) (rational-subtract (vector-ref library-interface 13)) (rational-multiply (vector-ref library-interface 14)) (rational-divide (vector-ref library-interface 15)) (rational-compare (vector-ref library-interface 16)) (rational=? (vector-ref library-interface 17)) (rational<? (vector-ref library-interface 18)) (rational<=? (vector-ref library-interface 19)) (rational>? (vector-ref library-interface 20)) (rational>=? (vector-ref library-interface 21)) (rational-truncate (vector-ref library-interface 22)) (rational-floor (vector-ref library-interface 23)))
(let ((library-interface (let ()

    ;; ---- Concrete numeric values and canonical exact packing ----

    (define-data Scalar
      (exact-scalar (value I64)) (rational-scalar (value Rational)) (inexact-scalar (value F64)))
    (define-data Number
      (exact-number (value I64)) (rational-number (value Rational)) (inexact-number (value F64))
      (complex-number (real Scalar) (imaginary Scalar)))
    (: scalar-from-rational (-> Rational Scalar))
    (define (scalar-from-rational value)
      (if (and (rational-integer? value) (integer-fits-i64? (rational-numerator value)))
          (exact-scalar (integer->i64 (rational-numerator value))) (rational-scalar value)))
    (: number-from-scalar (-> Scalar Number))
    (define (number-from-scalar value)
      (match value ((exact-scalar value) (exact-number value))
             ((rational-scalar value) (rational-number value)) ((inexact-scalar value) (inexact-number value))))
    (: number-from-rational (-> Rational Number))
    (define (number-from-rational value) (number-from-scalar (scalar-from-rational value)))
    (: number-from-integer (-> Integer Number))
    (define (number-from-integer value) (number-from-rational (rational-from-integer value)))
    (: scalar-exact? (-> Scalar Bool))
    (define (scalar-exact? value)
      (match value ((exact-scalar value) #t) ((rational-scalar value) #t) ((inexact-scalar value) #f)))
    (: scalar-zero? (-> Scalar Bool))
    (define (scalar-zero? value)
      (match value ((exact-scalar value) (= value 0))
             ((rational-scalar value) (rational-zero? value)) ((inexact-scalar value) (= value 0.0))))
    (: scalar->f64 (-> Scalar F64))
    (define (scalar->f64 value)
      (match value ((exact-scalar value) (i64->f64 value))
             ((rational-scalar value) (rational->f64 value)) ((inexact-scalar value) value)))
    (: scalar->rational (-> Scalar Rational))
    (define (scalar->rational value)
      (match value ((exact-scalar value) (rational-from-integer (integer-from-i64 value)))
             ((rational-scalar value) value) ((inexact-scalar value) (rational-from-f64 value))))

    ;; Collapse an exact imaginary zero before promoting a surviving mixed
    ;; pair. An inexact imaginary zero preserves complex shape and its sign.
    (: number-rectangular (-> Scalar Scalar Number))
    (define (number-rectangular real imaginary)
      (if (and (scalar-exact? imaginary) (scalar-zero? imaginary)) (number-from-scalar real)
          (if (and (scalar-exact? real) (scalar-exact? imaginary)) (complex-number real imaginary)
              (complex-number (inexact-scalar (scalar->f64 real)) (inexact-scalar (scalar->f64 imaginary))))))
    (: number-polar (-> Scalar Scalar Number))
    (define (number-polar radius angle)
      (if (and (scalar-exact? radius) (scalar-zero? radius)) (exact-number 0)
          (if (and (scalar-exact? angle) (scalar-zero? angle)) (number-from-scalar radius)
              (let ((radius (scalar->f64 radius)) (angle (scalar->f64 angle)))
                (complex-number (inexact-scalar (* radius (cos angle)))
                                (inexact-scalar (* radius (sin angle))))))))

    ;; ---- Real/imaginary projections keep exact zero for scalar input ----

    (: real-component (-> Number Scalar))
    (define (real-component value)
      (match value ((exact-number value) (exact-scalar value))
             ((rational-number value) (rational-scalar value)) ((inexact-number value) (inexact-scalar value))
             ((complex-number real imaginary) real)))
    (: imaginary-component (-> Number Scalar))
    (define (imaginary-component value)
      (match value ((exact-number value) (exact-scalar 0)) ((rational-number value) (exact-scalar 0))
             ((inexact-number value) (exact-scalar 0)) ((complex-number real imaginary) imaginary)))
    (: complex-representation? (-> Number Bool))
    (define (complex-representation? value)
      (match value ((exact-number value) #f) ((rational-number value) #f)
             ((inexact-number value) #f) ((complex-number real imaginary) #t)))
    (: real-value (-> Number Scalar))
    (define (real-value value)
      (if (scalar-zero? (imaginary-component value)) (real-component value) (unreachable)))
    (: number-real-part (-> Number Number))
    (define (number-real-part value) (number-from-scalar (real-component value)))
    (: number-imag-part (-> Number Number))
    (define (number-imag-part value) (number-from-scalar (imaginary-component value)))
    (: number->f64 (-> Number F64))
    (define (number->f64 value) (scalar->f64 (real-value value)))
    (: number->rational (-> Number Rational))
    (define (number->rational value) (scalar->rational (real-value value)))
    (: number->integer (-> Number Integer))
    (define (number->integer value)
      (let ((value (real-value value)))
        (if (not (scalar-exact? value)) (unreachable)
            (let ((value (scalar->rational value)))
              (if (rational-integer? value) (rational-numerator value) (unreachable))))))

    ;; ---- Exactness, numeric domains and explicit conversions ----

    (: finite-real? (-> F64 Bool))
    (define (finite-real? value)
      (and (= value value) (< value (/ 1.0 0.0)) (> value (/ -1.0 0.0))))
    (: scalar-finite? (-> Scalar Bool))
    (define (scalar-finite? value)
      (match value ((exact-scalar value) #t) ((rational-scalar value) #t)
             ((inexact-scalar value) (finite-real? value))))
    (: scalar-integer? (-> Scalar Bool))
    (define (scalar-integer? value)
      (match value ((exact-scalar value) #t) ((rational-scalar value) (rational-integer? value))
             ((inexact-scalar value) (and (finite-real? value) (= value (truncate value))))))
    (: number-real? (-> Number Bool))
    (define (number-real? value) (scalar-zero? (imaginary-component value)))
    (: number-exact? (-> Number Bool))
    (define (number-exact? value)
      (and (scalar-exact? (real-component value)) (scalar-exact? (imaginary-component value))))
    (: number-rational? (-> Number Bool))
    (define (number-rational? value) (and (number-real? value) (scalar-finite? (real-component value))))
    (: number-integer? (-> Number Bool))
    (define (number-integer? value) (and (number-real? value) (scalar-integer? (real-component value))))
    (: number-exact-integer? (-> Number Bool))
    (define (number-exact-integer? value) (and (number-exact? value) (number-integer? value)))
    (: number-zero? (-> Number Bool))
    (define (number-zero? value)
      (and (scalar-zero? (real-component value)) (scalar-zero? (imaginary-component value))))
    (: number-exact (-> Number Number))
    (define (number-exact value)
      (number-rectangular (scalar-from-rational (scalar->rational (real-component value)))
                          (scalar-from-rational (scalar->rational (imaginary-component value)))))
    (: number-inexact (-> Number Number))
    (define (number-inexact value)
      (if (complex-representation? value)
          (complex-number (inexact-scalar (scalar->f64 (real-component value)))
                          (inexact-scalar (scalar->f64 (imaginary-component value))))
          (inexact-number (number->f64 value))))
    (: number-truncate (-> Number Number))
    (define (number-truncate value)
      (match (real-value value) ((exact-scalar value) (exact-number value))
             ((rational-scalar value) (number-from-integer (rational-truncate value)))
             ((inexact-scalar value) (inexact-number (truncate value)))))
    (: number-numerator (-> Number Number))
    (define (number-numerator value)
      (let ((scalar (real-value value)))
        (if (and (not (scalar-exact? scalar)) (scalar-zero? scalar)) (number-from-scalar scalar)
            (let ((numerator (rational-numerator (scalar->rational scalar))))
              (if (scalar-exact? scalar) (number-from-integer numerator) (inexact-number (integer->f64 numerator)))))))
    (: number-denominator (-> Number Number))
    (define (number-denominator value)
      (let* ((scalar (real-value value)) (denominator (rational-denominator (scalar->rational scalar))))
        (if (scalar-exact? scalar) (number-from-integer denominator) (inexact-number (integer->f64 denominator)))))

    ;; ---- Scalar arithmetic promotes only at an inexact boundary ----

    (: scalar-add (-> Scalar Scalar Scalar))
    (define (scalar-add left right)
      (if (and (scalar-exact? left) (scalar-exact? right))
          (scalar-from-rational (rational-add (scalar->rational left) (scalar->rational right)))
          (inexact-scalar (+ (scalar->f64 left) (scalar->f64 right)))))
    (: scalar-negate (-> Scalar Scalar))
    (define (scalar-negate value)
      (match value ((exact-scalar value) (scalar-from-rational (rational-negate (scalar->rational (exact-scalar value)))))
             ((rational-scalar value) (scalar-from-rational (rational-negate value)))
             ((inexact-scalar value) (inexact-scalar (* -1.0 value)))))
    (: scalar-subtract (-> Scalar Scalar Scalar))
    (define (scalar-subtract left right)
      (if (and (scalar-exact? left) (scalar-exact? right))
          (scalar-from-rational (rational-subtract (scalar->rational left) (scalar->rational right)))
          (inexact-scalar (- (scalar->f64 left) (scalar->f64 right)))))
    (: scalar-multiply (-> Scalar Scalar Scalar))
    (define (scalar-multiply left right)
      (if (and (scalar-exact? left) (scalar-exact? right))
          (scalar-from-rational (rational-multiply (scalar->rational left) (scalar->rational right)))
          (inexact-scalar (* (scalar->f64 left) (scalar->f64 right)))))
    (: scalar-divide (-> Scalar Scalar Scalar))
    (define (scalar-divide left right)
      (if (and (scalar-exact? left) (scalar-exact? right))
          (scalar-from-rational (rational-divide (scalar->rational left) (scalar->rational right)))
          (inexact-scalar (/ (scalar->f64 left) (scalar->f64 right)))))
    (: number-add (-> Number Number Number))
    (define (number-add left right)
      (number-rectangular (scalar-add (real-component left) (real-component right))
                          (scalar-add (imaginary-component left) (imaginary-component right))))
    (: number-negate (-> Number Number))
    (define (number-negate value)
      (number-rectangular (scalar-negate (real-component value)) (scalar-negate (imaginary-component value))))
    (: number-subtract (-> Number Number Number))
    (define (number-subtract left right)
      (number-rectangular (scalar-subtract (real-component left) (real-component right))
                          (scalar-subtract (imaginary-component left) (imaginary-component right))))
    (: number-multiply (-> Number Number Number))
    (define (number-multiply left right)
      (let ((a (real-component left)) (b (imaginary-component left))
            (c (real-component right)) (d (imaginary-component right)))
        (if (not (or (complex-representation? left) (complex-representation? right)))
            (number-from-scalar (scalar-multiply a c))
            (number-rectangular (scalar-subtract (scalar-multiply a c) (scalar-multiply b d))
                                (scalar-add (scalar-multiply a d) (scalar-multiply b c))))))
    (: number-divide (-> Number Number Number))
    (define (number-divide left right)
      (let ((a (real-component left)) (b (imaginary-component left))
            (c (real-component right)) (d (imaginary-component right)))
        (if (not (or (complex-representation? left) (complex-representation? right)))
            (number-from-scalar (scalar-divide a c))
            (let ((divisor (scalar-add (scalar-multiply c c) (scalar-multiply d d))))
              (number-rectangular
               (scalar-divide (scalar-add (scalar-multiply a c) (scalar-multiply b d)) divisor)
               (scalar-divide (scalar-subtract (scalar-multiply b c) (scalar-multiply a d)) divisor))))))

    ;; ---- Exact comparisons never round an operand to make it equal ----

    ;; Order is -1, 0, 1, or 2 for unordered NaN. Finite mixed comparisons
    ;; compare the exact dyadic float value against the exact rational operand.
    (: scalar-nan? (-> Scalar Bool))
    (define (scalar-nan? value)
      (match value ((exact-scalar value) #f) ((rational-scalar value) #f)
             ((inexact-scalar value) (not (= value value)))))
    (: scalar-order (-> Scalar Scalar I64))
    (define (scalar-order left right)
      (if (or (scalar-nan? left) (scalar-nan? right)) 2
          (if (and (scalar-finite? left) (scalar-finite? right))
              (rational-compare (scalar->rational left) (scalar->rational right))
              (let ((a (scalar->f64 left)) (b (scalar->f64 right)))
                (if (< a b) -1 (if (> a b) 1
                                   (if (scalar-finite? left) (if (< b 0.0) 1 -1)
                                       (if (scalar-finite? right) (if (< a 0.0) -1 1) 0))))))))
    (: number=? (-> Number Number Bool))
    (define (number=? left right)
      (and (= (scalar-order (real-component left) (real-component right)) 0)
           (= (scalar-order (imaginary-component left) (imaginary-component right)) 0)))
    (: number<? (-> Number Number Bool))
    (define (number<? left right) (= (scalar-order (real-value left) (real-value right)) -1))
    (: number>? (-> Number Number Bool))
    (define (number>? left right) (= (scalar-order (real-value left) (real-value right)) 1))
    (: number<=? (-> Number Number Bool))
    (define (number<=? left right)
      (let ((order (scalar-order (real-value left) (real-value right)))) (or (= order -1) (= order 0))))
    (: number>=? (-> Number Number Bool))
    (define (number>=? left right)
      (let ((order (scalar-order (real-value left) (real-value right)))) (or (= order 1) (= order 0))))
    (: number-negative? (-> Number Bool))
    (define (number-negative? value) (number<? value (exact-number 0)))
    (: number-abs (-> Number Number))
    (define (number-abs value)
      (number-from-scalar
       (match (real-value value) ((exact-scalar value) (scalar-from-rational (rational-abs (scalar->rational (exact-scalar value)))))
              ((rational-scalar value) (scalar-from-rational (rational-abs value)))
              ((inexact-scalar value) (inexact-scalar (if (<= value 0.0) (- 0.0 value) value))))))

    ;; Equivalence retains exactness, complex shape and binary64 zero signs.
    (define-extern real-equivalent "snail.library" "snail:datum/real-equivalent" (-> F64 F64 I32))
    (: scalar-equivalent? (-> Scalar Scalar Bool))
    (define (scalar-equivalent? left right)
      (match left
        ((exact-scalar value)
         (match right ((exact-scalar other) (= value other)) ((inexact-scalar other) #f)
                ((rational-scalar other) (rational=? (scalar->rational left) other))))
        ((rational-scalar value) (and (scalar-exact? right) (rational=? value (scalar->rational right))))
        ((inexact-scalar value)
         (match right ((exact-scalar other) #f) ((rational-scalar other) #f)
                ((inexact-scalar other) (i32-eq (real-equivalent value other) (ann 1 I32)))))))
    (: number-equivalent? (-> Number Number Bool))
    (define (number-equivalent? left right)
      ;; Existing I64/F64 leaves compare directly. Arbitrary exact components
      ;; use normalized fractions; no numeric projection allocates a wrapper.
      (match left
        ((exact-number value)
         (match right ((exact-number other) (= value other)) ((inexact-number other) #f)
                ((complex-number real imaginary) #f)
                ((rational-number other) (rational=? (rational-from-integer (integer-from-i64 value)) other))))
        ((rational-number value)
         (and (not (complex-representation? right)) (number-exact? right) (rational=? value (number->rational right))))
        ((inexact-number value)
         (match right ((exact-number other) #f) ((rational-number other) #f) ((complex-number real imaginary) #f)
                ((inexact-number other) (i32-eq (real-equivalent value other) (ann 1 I32)))))
        ((complex-number real imaginary)
         (match right ((exact-number other) #f) ((rational-number other) #f) ((inexact-number other) #f)
                ((complex-number other-real other-imaginary)
                 (and (scalar-equivalent? real other-real) (scalar-equivalent? imaginary other-imaginary)))))))

    ;; ---- Canonical decimal formatting and scalar-only Rust text handles ----

    ;; Work with a nonpositive magnitude so the minimum I64 needs no positive
    ;; counterpart. Each remainder lies in [-9,0]; negating that digit is safe.
    (: decimal-digits (-> I64 I64))
    (define (decimal-digits value)
      (let loop ((value value) (count 1))
        (if (> value -10) count (loop (quotient value 10) (+ count 1)))))
    (: i64->string (-> I64 String))
    (define (i64->string value)
      (let* ((negative (< value 0)) (magnitude (if negative value (- 0 value)))
             (count (+ (decimal-digits magnitude) (if negative 1 0)))
             (text (make-string count)))
        (when negative (string-set! text 0 #\-))
        (let loop ((remaining magnitude) (index (- count 1)))
          (string-set! text index (integer->char (- 48 (remainder remaining 10))))
          (if (> remaining -10) text (loop (quotient remaining 10) (- index 1))))))

    (define-extern real-text "snail.library" "snail:datum/real-text" (-> F64 I32))
    (define-extern text-length "snail.library" "snail:datum/token-text-length" (-> I32 I32))
    (define-extern text-character "snail.library" "snail:datum/token-text-character" (-> I32 I32 Char))
    (define-extern text-close "snail.library" "snail:datum/token-close" (-> I32 Unit))
    (: f64->string (-> F64 String))
    (define (f64->string value)
      (let* ((handle (real-text value)) (count (i32->i64 (text-length handle))) (result (make-string count)))
        ;; No callback runs while the Rust text handle is owned. Trap cleanup
        ;; releases it; the ordinary path copies every scalar then closes once.
        (let loop ((at 0))
          (if (= at count) (begin (text-close handle) result)
              (begin (string-set! result at (text-character handle (i64->i32 at))) (loop (+ at 1)))))))
    (: scalar->string (-> Scalar String))
    (define (scalar->string value)
      (match value ((exact-scalar value) (i64->string value))
             ((rational-scalar value) (rational->string value)) ((inexact-scalar value) (f64->string value))))
    (: number->string (-> Number String))
    (define (number->string value)
      (let ((real (scalar->string (real-component value))))
        (if (not (complex-representation? value)) real
            (let* ((imaginary (scalar->string (imaginary-component value))) (first (string-ref imaginary 0)))
              (string-append real (if (or (char=? first #\+) (char=? first #\-)) "" "+") imaginary "i")))))

    ;; ---- Static operator families ----

    (define-overload + (-> Number Number Number) number-add)
    (define-overload - (-> Number Number Number) number-subtract)
    (define-overload - (-> Number Number) number-negate)
    (define-overload * (-> Number Number Number) number-multiply)
    (define-overload / (-> Number Number Number) number-divide)
    (define-overload = (-> Number Number Bool) number=?)
    (define-overload < (-> Number Number Bool) number<?)
    (define-overload <= (-> Number Number Bool) number<=?)
    (define-overload > (-> Number Number Bool) number>?)
    (define-overload >= (-> Number Number Bool) number>=?)
    (define-overload truncate (-> Number Number) number-truncate)

(vector exact-scalar rational-scalar inexact-scalar scalar-from-rational scalar->rational scalar->f64 scalar-exact? scalar-zero? scalar-equivalent? exact-number rational-number inexact-number complex-number number-from-integer number-from-rational number-from-scalar number-rectangular number-polar number->integer number->rational number->f64 number->string i64->string f64->string number-exact number-inexact number-truncate number-real-part number-imag-part number-numerator number-denominator number-exact? number-real? number-rational? number-integer? number-exact-integer? number-zero? number-negative? number-abs number-negate number-add number-subtract number-multiply number-divide number=? number<? number<=? number>? number>=? number-equivalent?))))
  (let ((exact-scalar (vector-ref library-interface 0)) (rational-scalar (vector-ref library-interface 1)) (inexact-scalar (vector-ref library-interface 2)) (scalar-from-rational (vector-ref library-interface 3)) (scalar->rational (vector-ref library-interface 4)) (scalar->f64 (vector-ref library-interface 5)) (scalar-exact? (vector-ref library-interface 6)) (scalar-zero? (vector-ref library-interface 7)) (scalar-equivalent? (vector-ref library-interface 8)) (exact-number (vector-ref library-interface 9)) (rational-number (vector-ref library-interface 10)) (inexact-number (vector-ref library-interface 11)) (complex-number (vector-ref library-interface 12)) (number-from-integer (vector-ref library-interface 13)) (number-from-rational (vector-ref library-interface 14)) (number-from-scalar (vector-ref library-interface 15)) (number-rectangular (vector-ref library-interface 16)) (number-polar (vector-ref library-interface 17)) (number->integer (vector-ref library-interface 18)) (number->rational (vector-ref library-interface 19)) (number->f64 (vector-ref library-interface 20)) (number->string (vector-ref library-interface 21)) (i64->string (vector-ref library-interface 22)) (f64->string (vector-ref library-interface 23)) (number-exact (vector-ref library-interface 24)) (number-inexact (vector-ref library-interface 25)) (number-truncate (vector-ref library-interface 26)) (number-real-part (vector-ref library-interface 27)) (number-imag-part (vector-ref library-interface 28)) (number-numerator (vector-ref library-interface 29)) (number-denominator (vector-ref library-interface 30)) (number-exact? (vector-ref library-interface 31)) (number-real? (vector-ref library-interface 32)) (number-rational? (vector-ref library-interface 33)) (number-integer? (vector-ref library-interface 34)) (number-exact-integer? (vector-ref library-interface 35)) (number-zero? (vector-ref library-interface 36)) (number-negative? (vector-ref library-interface 37)) (number-abs (vector-ref library-interface 38)) (number-negate (vector-ref library-interface 39)) (number-add (vector-ref library-interface 40)) (number-subtract (vector-ref library-interface 41)) (number-multiply (vector-ref library-interface 42)) (number-divide (vector-ref library-interface 43)) (number=? (vector-ref library-interface 44)) (number<? (vector-ref library-interface 45)) (number<=? (vector-ref library-interface 46)) (number>? (vector-ref library-interface 47)) (number>=? (vector-ref library-interface 48)) (number-equivalent? (vector-ref library-interface 49)))
(let ((library-interface (let ()

    ;; ---- Explicit scalar service ownership ----

    (define-extern token-open "snail.library" "snail:datum/token-open" (-> I32))
    (define-extern token-character "snail.library" "snail:datum/token-character" (-> I32 Char Unit))
    (define-extern token-close "snail.library" "snail:datum/token-close" (-> I32 Unit))
    (define-extern token-parse "snail.library" "snail:datum/token-parse" (-> I32 I32))
    (define-extern token-parse-radix "snail.library" "snail:datum/token-parse-radix" (-> I32 I32 I32))
    (define-extern token-identifier "snail.library" "snail:datum/token-identifier" (-> I32 I32))
    (define-extern token-intern "snail.library" "snail:datum/token-intern" (-> I32 I32))
    (define-extern raw-number-kind "snail.library" "snail:datum/number-kind" (-> I32 I32 I32))
    (define-extern raw-number-integer "snail.library" "snail:datum/number-integer" (-> I32 I32 I64))
    (define-extern raw-number-real "snail.library" "snail:datum/number-real" (-> I32 I32 F64))
    (define-extern raw-number-radix "snail.library" "snail:datum/number-radix" (-> I32 I32 I32))
    (define-extern raw-number-scale "snail.library" "snail:datum/number-scale" (-> I32 I32 I64))
    (define-extern raw-number-text-length "snail.library" "snail:datum/number-text-length" (-> I32 I32 I32 I32))
    (define-extern raw-number-text-character "snail.library" "snail:datum/number-text-character" (-> I32 I32 I32 I32 Char))
    (define-extern error-length "snail.library" "snail:datum/error-length" (-> I32 I32))
    (define-extern error-character "snail.library" "snail:datum/error-character" (-> I32 I32 Char))
    (define-extern raw-fail "snail.library" "snail:datum/fail" (-> I32 Unit))
    (define-extern symbol-length "snail.library" "snail:datum/symbol-length" (-> I32 I64))
    (define-extern symbol-character "snail.library" "snail:datum/symbol-character" (-> I32 I32 Char))

    ;; The caller owns this ID until close or intern consumes it. These loops
    ;; invoke no user callbacks. Rust trap cleanup releases outstanding tokens.
    (: stage-text (-> String I32))
    (define (stage-text text)
      (let ((handle (token-open)) (count (string-length text)))
        (let loop ((index 0))
          (if (= index count) handle
              (begin (token-character handle (string-ref text index))
                     (loop (+ index 1)))))))
    (: datum-fail (-> String Never))
    (define (datum-fail message) (raw-fail (stage-text message)) (unreachable))
    (: identifier? (-> String Bool))
    (define (identifier? text)
      (let* ((handle (stage-text text)) (valid (token-identifier handle)))
        (token-close handle) (i32-eq valid (ann 1 I32))))

    ;; ---- Interned symbols, independent of the legacy literal domain ----

    (define-data Symbol (symbol (id I32 symbol-id)))
    (: string->symbol (-> String Symbol))
    (define (string->symbol text) (symbol (token-intern (stage-text text))))
    (: symbol=? (-> Symbol Symbol Bool))
    (define (symbol=? left right) (i32-eq (symbol-id left) (symbol-id right)))
    (: symbol->string (-> Symbol String))
    (define (symbol->string value)
      (let* ((id (symbol-id value)) (count (symbol-length id))
             (result (make-string count)))
        (let loop ((index 0))
          (if (= index count) result
              (begin (string-set! result index (symbol-character id (i64->i32 index)))
                     (loop (+ index 1)))))))

    ;; ---- Exact lexical fields become Scheme-owned numeric values ----

    (define-data NumberResult (not-a-number)
      (parsed-number (value Number parsed-number-value))
      (number-error (message String number-error-text)))
    (: token-exact-text (-> I32 I32 I32 String))
    (define (token-exact-text handle part term)
      (let* ((count (i32->i64 (raw-number-text-length handle part term))) (text (make-string count)))
        (let loop ((at 0))
          (if (= at count) text
              (begin (string-set! text at (raw-number-text-character handle part term (i64->i32 at)))
                     (loop (+ at 1)))))))
    (: token-rational (-> I32 I32 String Rational))
    (define (token-rational handle part numerator-text)
      (let* ((radix (i32->i64 (raw-number-radix handle part))) (scale (raw-number-scale handle part))
             (numerator (integer-from-string/radix numerator-text radix))
             (denominator (integer-from-string/radix (token-exact-text handle part (ann 1 I32)) radix))
             (factor (integer-power (integer-from-i64 10) (if (< scale 0) (- 0 scale) scale))))
        (if (< scale 0) (make-rational numerator (integer-multiply denominator factor))
            (make-rational (integer-multiply numerator factor) denominator))))
    (: token-exact-scalar (-> I32 I32 I32 Scalar))
    (define (token-exact-scalar handle part kind)
      (let* ((text (token-exact-text handle part (ann 0 I32))) (value (token-rational handle part text)))
        (if (i32-eq kind (ann 5 I32)) (scalar-from-rational value)
            ;; Exact zero has no sign, so retain the lexical sign until #i has
            ;; produced its binary64 zero. Nonzero underflow keeps its own sign.
            (inexact-scalar (if (and (rational-zero? value) (char=? (string-ref text 0) #\-))
                                (* -1.0 0.0) (rational->f64 value))))))
    (: token-scalar (-> I32 I32 Scalar))
    (define (token-scalar handle part)
      (let ((kind (raw-number-kind handle part)))
        (if (i32-eq kind (ann 1 I32)) (exact-scalar (raw-number-integer handle part))
            (if (i32-eq kind (ann 2 I32)) (inexact-scalar (raw-number-real handle part))
                (token-exact-scalar handle part kind)))))
    (: token-error-text (-> I32 String))
    (define (token-error-text handle)
      (let* ((count (i32->i64 (error-length handle))) (result (make-string count)))
        (let loop ((index 0))
          (if (= index count) result
              (begin (string-set! result index (error-character handle (i64->i32 index)))
                     (loop (+ index 1)))))))
    (: token-polar-result (-> I32 I32 NumberResult))
    (define (token-polar-result handle kind)
      (let ((radius (token-scalar handle (ann 0 I32))) (angle (token-scalar handle (ann 1 I32))))
        (if (and (i32-eq kind (ann 8 I32))
                 (not (or (and (scalar-exact? radius) (scalar-zero? radius))
                          (and (scalar-exact? angle) (scalar-zero? angle)))))
            (number-error "exact nonaxis polar number is not supported")
            (parsed-number (number-polar radius angle)))))
    (: token-number-result (-> I32 I32 NumberResult))
    (define (token-number-result handle kind)
      (if (i32-eq kind (ann 0 I32)) (not-a-number)
          (if (i32-eq kind (ann 4 I32)) (number-error (token-error-text handle))
              (if (i32-eq kind (ann 3 I32))
                  (parsed-number (number-rectangular (token-scalar handle (ann 0 I32)) (token-scalar handle (ann 1 I32))))
                  (if (or (i32-eq kind (ann 7 I32)) (i32-eq kind (ann 8 I32))) (token-polar-result handle kind)
                      (parsed-number (number-from-scalar (token-scalar handle (ann 0 I32)))))))))
    (: string->number/radix (-> String I64 NumberResult))
    (define (string->number/radix text radix)
      (if (not (or (= radix 2) (= radix 8) (= radix 10) (= radix 16)))
          (number-error "string->number: radix must be 2, 8, 10 or 16")
          (let* ((handle (stage-text text)) (kind (token-parse-radix handle (i64->i32 radix)))
                 (result (token-number-result handle kind)))
            (token-close handle) result)))
    (define-overload string->number (-> String NumberResult)
      (lambda (text) (string->number/radix text 10)))
    (define-overload string->number (-> String I64 NumberResult) string->number/radix)

    ;; ---- Recursive datums and explicit mutable pair fields ----

    (define-data Datum
      (datum-null) (datum-boolean (value Bool datum-boolean-value))
      (datum-character (value Char datum-character-value))
      (datum-string (value String datum-string-value))
      (datum-symbol (value Symbol datum-symbol-value))
      (datum-number (value Number datum-number-value))
      (pair-datum (first (Ref Datum) datum-first) (rest (Ref Datum) datum-rest)
                  (identity I64 pair-datum-identity))
      (vector-datum (values (Vector Datum) datum-vector-values) (identity I64 vector-datum-identity))
      (datum-bytevector (values Bytevector datum-bytevector-values)))

    ;; ---- A shared result for atom interpretation and incremental input ----

    (define-data ReadResult (read-end)
      (read-value (datum Datum read-value-datum))
      (read-error (message String read-error-message)))
    (: token-number-datum (-> I32 I32 ReadResult))
    (define (token-number-datum handle kind)
      (let ((result (token-number-result handle kind)))
        (token-close handle)
        (match result
          ((parsed-number number) (read-value (datum-number number)))
          ((number-error message) (read-error message)) ((not-a-number) (unreachable)))))
    ;; No callback runs while this ID is owned. Numeric results and invalid
    ;; identifiers close once; symbol interning consumes the same parsed text.
    ;; EOF belongs to input, so string->atom never constructs read-end.
    (: string->atom (-> String ReadResult))
    (define (string->atom text)
      (let* ((handle (stage-text text)) (kind (token-parse handle)))
        (if (i32-eq kind (ann 0 I32))
            (if (i32-eq (token-identifier handle) (ann 1 I32))
                (read-value (datum-symbol (symbol (token-intern handle))))
                (begin (token-close handle)
                       (read-error "invalid numeric token or identifier")))
            (token-number-datum handle kind))))

    ;; ---- Explicit mutable pair fields ----

    ;; These private constructors attach IDs to immutable views, not to storage.
    ;; Two views of the same Refs/array may have different IDs; datum-eq? below
    ;; still reports their shared storage. Child reads return the stored view.
    ;; Never recycling an ID lets a comparison remember it without rooting the
    ;; object. The only global state is a scalar; it retains no Scheme graph.
    (define next-datum-identity (ref 1))
    (: fresh-datum-identity (-> I64))
    (define (fresh-datum-identity)
      (let ((identity (ref-get next-datum-identity)))
        (if (= identity 9223372036854775807)
            (datum-fail "datum: recursive view identity exhausted")
            (begin (ref-set! next-datum-identity (+ identity 1)) identity))))
    (: datum-pair (-> (Ref Datum) (Ref Datum) Datum))
    (define (datum-pair first rest) (pair-datum first rest (fresh-datum-identity)))
    (: datum-vector (-> (Vector Datum) Datum))
    (define (datum-vector values) (vector-datum values (fresh-datum-identity)))
    (: datum-cons (-> Datum Datum Datum))
    (define (datum-cons first rest) (datum-pair (ref first) (ref rest)))
    (: datum-car (-> Datum Datum))
    (define (datum-car pair) (ref-get (datum-first pair)))
    (: datum-cdr (-> Datum Datum))
    (define (datum-cdr pair) (ref-get (datum-rest pair)))
    (: datum-set-car! (-> Datum Datum Unit))
    (define (datum-set-car! pair value) (ref-set! (datum-first pair) value))
    (: datum-set-cdr! (-> Datum Datum Unit))
    (define (datum-set-cdr! pair value) (ref-set! (datum-rest pair) value))
    (: datum-kind (-> Datum I64))
    (define (datum-kind value)
      (match value
        ((datum-null) 0) ((datum-boolean value) 1) ((datum-character value) 2)
        ((datum-string value) 3) ((datum-symbol value) 4) ((datum-number value) 5)
        ((pair-datum first rest identity) 6) ((vector-datum values identity) 7) ((datum-bytevector values) 8)))
    (: datum-number? (-> Datum Bool))
    (define (datum-number? value) (= (datum-kind value) 5))
    (: datum-null? (-> Datum Bool))
    (define (datum-null? value) (= (datum-kind value) 0))
    (: datum-pair? (-> Datum Bool))
    (define (datum-pair? value) (= (datum-kind value) 6))
    (: datum-truth? (-> Datum Bool))
    (define (datum-truth? value)
      (if (= (datum-kind value) 1) (datum-boolean-value value) #t))

    ;; ---- Atomic equivalence and mutable storage identity ----

    ;; Scalars compare by value, including the Number equivalence above.
    ;; Mutable values compare their underlying storage. A datum-pair wrapper is
    ;; a view of its two Ref fields: two wrappers sharing both fields identify
    ;; the same logical pair. Sharing just one field does not identify a pair.
    ;; datum-cons always creates fresh fields, matching ordinary cons identity.
    (: datum-eq? (-> Datum Datum Bool))
    (define (datum-eq? left right)
      (and (= (datum-kind left) (datum-kind right))
           (match left
             ((datum-null) #t)
             ((datum-boolean left) (if left (datum-boolean-value right) (not (datum-boolean-value right))))
             ((datum-character left) (char=? left (datum-character-value right)))
             ((datum-string left) (string-eq? left (datum-string-value right)))
             ((datum-symbol left) (symbol=? left (datum-symbol-value right)))
             ((datum-number left) (number-equivalent? left (datum-number-value right)))
             ((pair-datum first rest identity)
              (and (ref-eq? first (datum-first right)) (ref-eq? rest (datum-rest right))))
             ((vector-datum left identity) (vector-eq? left (datum-vector-values right)))
             ((datum-bytevector left) (bytevector-eq? left (datum-bytevector-values right))))))

    ;; ---- Proper list operations preserve elements and shared suffixes ----

    (: datum-list (-> (Rest Datum) Datum))
    (define (datum-list . values)
      (let loop ((values values))
        (if (null? values) (datum-null) (datum-cons (car values) (loop (cdr values))))))
    (: datum-length (-> Datum I64))
    (define (datum-length values)
      (let loop ((values values) (count 0))
        (if (datum-null? values) count (loop (datum-cdr values) (+ count 1)))))
    (: datum-append (-> Datum Datum Datum))
    (define (datum-append first rest)
      (if (datum-null? first) rest
          (datum-cons (datum-car first) (datum-append (datum-cdr first) rest))))
    (: datum-assq (-> Datum Datum Datum))
    (define (datum-assq key entries)
      (if (datum-null? entries) (datum-boolean #f)
          (let ((entry (datum-car entries)))
            (if (datum-eq? key (datum-car entry)) entry (datum-assq key (datum-cdr entries))))))
    (: datum-map (-> (-> Datum Datum) Datum Datum))
    (define (datum-map procedure values)
      (if (datum-null? values) (datum-null)
          (let ((head (procedure (datum-car values))))
            (datum-cons head (datum-map procedure (datum-cdr values))))))

    ;; ---- Query-local comparison history ----

    ;; Remember ordered pairs of recursive view IDs before following children.
    ;; Reaching that comparison again closes a cycle or skips an already shared
    ;; subgraph. It does not assert a one-to-one mapping between the two graphs:
    ;; one-node and two-node cycles with the same unfolding compare equal.
    ;;
    ;; Zero is the empty key. At most half the slots are occupied, so every
    ;; probe terminates. The arrays contain only scalar IDs and are discarded
    ;; after this call. Neither comparison history nor pending work escapes.
    ;; Work is proportional to the visited comparison pairs with well-distributed
    ;; hashes, not necessarily to input nodes: coprime cycle lengths can visit
    ;; their product. Hash collisions can add linear probing work.
    (define-data EqualityHistory
      (equality-history (left (Ref (Vector I64)) history-left)
                        (right (Ref (Vector I64)) history-right)
                        (size (Ref I64) history-size)))
    (: make-equality-history (-> EqualityHistory))
    (define (make-equality-history)
      (equality-history (ref (make-vector 32 0)) (ref (make-vector 32 0)) (ref 0)))
    ;; Mix complete I64 bit patterns with wrapping arithmetic and logical shifts.
    ;; Odd multiplication and xor-with-shift are each invertible. Mixing the
    ;; right ID before combining it with the left avoids diagonal cancellation.
    ;; These constants are signed spellings of 64-bit words; negative results
    ;; are expected. Exact keys, never hashes, decide membership. This is not
    ;; an adversarial collision guarantee.
    (: equality-mix-word (-> I64 I64))
    (define (equality-mix-word word)
      (let* ((first (i64-mul (i64-bitwise-xor word (i64-shift-right/logical word 30)) -4658895280553007687))
             (second (i64-mul (i64-bitwise-xor first (i64-shift-right/logical first 27)) -7723592293110705685)))
        (i64-bitwise-xor second (i64-shift-right/logical second 31))))
    (: equality-pair-hash (-> I64 I64 I64))
    (define (equality-pair-hash left right)
      (equality-mix-word (i64-bitwise-xor left (equality-mix-word (i64-add right -7046029254386353131)))))
    ;; Capacity starts at 32 and only doubles, through at most 2^31. Its mask
    ;; selects a nonnegative bucket even when the full hash has its high bit set.
    (: equality-bucket (-> I64 I64 I64 I64))
    (define (equality-bucket left right capacity)
      (i64-bitwise-and (equality-pair-hash left right) (- capacity 1)))
    (: equality-slot (-> I64 I64 (Vector I64) (Vector I64) I64))
    (define (equality-slot left right keys partners)
      (let ((capacity (vector-length keys)))
        (let loop ((index (equality-bucket left right capacity)))
          (if (or (= (vector-ref keys index) 0)
                  (and (= (vector-ref keys index) left) (= (vector-ref partners index) right)))
              index (loop (if (= (+ index 1) capacity) 0 (+ index 1)))))))
    (: place-equality-key! (-> I64 I64 (Vector I64) (Vector I64) Unit))
    (define (place-equality-key! left right keys partners)
      (let ((slot (equality-slot left right keys partners)))
        (vector-set! keys slot left) (vector-set! partners slot right)))
    (: rehash-equality-keys! (-> (Vector I64) (Vector I64) (Vector I64) (Vector I64) Unit))
    (define (rehash-equality-keys! old-left old-right keys partners)
      (let loop ((index 0))
        (if (= index (vector-length old-left)) (unit)
            (begin
              (unless (= (vector-ref old-left index) 0)
                (place-equality-key! (vector-ref old-left index) (vector-ref old-right index) keys partners))
              (loop (+ index 1))))))
    (: grow-equality-history! (-> EqualityHistory Unit))
    (define (grow-equality-history! history)
      (let* ((old-left (ref-get (history-left history))) (old-right (ref-get (history-right history)))
             (capacity (vector-length old-left))
             (grown (if (> capacity 1073741824) (datum-fail "datum=?: comparison history exhausted") (* capacity 2)))
             (keys (make-vector grown 0)) (partners (make-vector grown 0)))
        (rehash-equality-keys! old-left old-right keys partners)
        (ref-set! (history-left history) keys) (ref-set! (history-right history) partners)))
    (: equality-seen? (-> I64 I64 EqualityHistory Bool))
    (define (equality-seen? left right history)
      (when (= (* (ref-get (history-size history)) 2) (vector-length (ref-get (history-left history))))
        (grow-equality-history! history))
      (let* ((keys (ref-get (history-left history))) (partners (ref-get (history-right history)))
             (slot (equality-slot left right keys partners)))
        (if (= (vector-ref keys slot) left) #t
            (begin (vector-set! keys slot left) (vector-set! partners slot right)
                   (ref-set! (history-size history) (+ (ref-get (history-size history)) 1)) #f))))

    ;; ---- Stack-safe equality of finite graphs ----

    ;; Pending continuations live in traced Scheme data. Every recursive call
    ;; below is a tail call, including descent through car and vector elements.
    ;; Scalar comparison retains the existing exactness, NaN and zero rules.
    ;; No input is mutated, no user procedure is called, and every call starts
    ;; with fresh history, so later pair/vector mutation is visible immediately.
    (define-data EqualityWork
      (equality-done)
      (equality-values (left Datum) (right Datum) (pending EqualityWork))
      (equality-elements (left (Vector Datum)) (right (Vector Datum))
                         (index I64) (pending EqualityWork)))
    (: datum=? (-> Datum Datum Bool))
    (define (datum=? left right)
      (or (datum-eq? left right)
          (equality-compare left right (equality-done) (make-equality-history))))
    (: equality-continue (-> EqualityWork EqualityHistory Bool))
    (define (equality-continue work history)
      (match work
        ((equality-done) #t)
        ((equality-values left right pending) (equality-compare left right pending history))
        ((equality-elements left right index pending) (equality-vector left right index pending history))))
    (: equality-pair (-> Datum Datum EqualityWork EqualityHistory Bool))
    (define (equality-pair left right pending history)
      (if (equality-seen? (pair-datum-identity left) (pair-datum-identity right) history)
          (equality-continue pending history)
          (equality-compare (datum-car left) (datum-car right)
                            (equality-values (datum-cdr left) (datum-cdr right) pending) history)))
    (: equality-vector (-> (Vector Datum) (Vector Datum) I64 EqualityWork EqualityHistory Bool))
    (define (equality-vector left right index pending history)
      (if (= index (vector-length left)) (equality-continue pending history)
          (equality-compare (vector-ref left index) (vector-ref right index)
                            (equality-elements left right (+ index 1) pending) history)))
    (: equality-vector-datum (-> Datum Datum EqualityWork EqualityHistory Bool))
    (define (equality-vector-datum left right pending history)
      (let ((values (datum-vector-values left)) (others (datum-vector-values right)))
        (and (= (vector-length values) (vector-length others))
             (if (equality-seen? (vector-datum-identity left) (vector-datum-identity right) history)
                 (equality-continue pending history)
                 (equality-vector values others 0 pending history)))))
    (: equality-compare (-> Datum Datum EqualityWork EqualityHistory Bool))
    (define (equality-compare left right pending history)
      (if (datum-eq? left right) (equality-continue pending history)
          (and (= (datum-kind left) (datum-kind right))
               (match left
                 ;; Atomic equivalence already failed. Only distinct mutable
                 ;; storage can still contain structurally equal values.
                 ((datum-null) #f) ((datum-boolean value) #f) ((datum-character value) #f)
                 ((datum-symbol value) #f) ((datum-number value) #f)
                 ((datum-string text)
                  (and (string=? text (datum-string-value right)) (equality-continue pending history)))
                 ((datum-bytevector bytes)
                  (and (datum-bytes=? bytes (datum-bytevector-values right)) (equality-continue pending history)))
                 ((pair-datum first rest identity) (equality-pair left right pending history))
                 ((vector-datum values identity) (equality-vector-datum left right pending history))))))
    (: datum-bytes=? (-> Bytevector Bytevector Bool))
    (define (datum-bytes=? left right)
      (let ((count (bytevector-length left)))
        (and (= count (bytevector-length right))
             (let loop ((index 0))
               (or (= index count)
                   (and (= (bytevector-u8-ref left index) (bytevector-u8-ref right index))
                        (loop (+ index 1))))))))
(define string->number (case-lambda
  ((text) (string->number/radix text 10))
  ((text radix) (string->number/radix text radix))))

(vector string->symbol symbol->string symbol=? i64->string exact-scalar rational-scalar inexact-scalar scalar->f64 scalar-equivalent? exact-number rational-number inexact-number complex-number number->f64 number-equivalent? not-a-number parsed-number number-error parsed-number-value number-error-text string->number string->number/radix string->atom identifier? datum-fail read-end read-value read-error read-value-datum read-error-message datum-null datum-boolean datum-character datum-string datum-symbol datum-number datum-pair datum-vector datum-bytevector datum=? datum-cons datum-car datum-cdr datum-set-car! datum-set-cdr! datum-number? datum-number-value datum-string-value datum-symbol-value datum-null? datum-pair? datum-truth? datum-eq? datum-kind datum-boolean-value datum-character-value datum-vector-values datum-bytevector-values datum-list datum-length datum-append datum-assq datum-map))))
  (let ((string->symbol (vector-ref library-interface 0)) (symbol->string (vector-ref library-interface 1)) (symbol=? (vector-ref library-interface 2)) (i64->string (vector-ref library-interface 3)) (exact-scalar (vector-ref library-interface 4)) (rational-scalar (vector-ref library-interface 5)) (inexact-scalar (vector-ref library-interface 6)) (scalar->f64 (vector-ref library-interface 7)) (scalar-equivalent? (vector-ref library-interface 8)) (exact-number (vector-ref library-interface 9)) (rational-number (vector-ref library-interface 10)) (inexact-number (vector-ref library-interface 11)) (complex-number (vector-ref library-interface 12)) (number->f64 (vector-ref library-interface 13)) (number-equivalent? (vector-ref library-interface 14)) (not-a-number (vector-ref library-interface 15)) (parsed-number (vector-ref library-interface 16)) (number-error (vector-ref library-interface 17)) (parsed-number-value (vector-ref library-interface 18)) (number-error-text (vector-ref library-interface 19)) (string->number (vector-ref library-interface 20)) (string->number/radix (vector-ref library-interface 21)) (string->atom (vector-ref library-interface 22)) (identifier? (vector-ref library-interface 23)) (datum-fail (vector-ref library-interface 24)) (read-end (vector-ref library-interface 25)) (read-value (vector-ref library-interface 26)) (read-error (vector-ref library-interface 27)) (read-value-datum (vector-ref library-interface 28)) (read-error-message (vector-ref library-interface 29)) (datum-null (vector-ref library-interface 30)) (datum-boolean (vector-ref library-interface 31)) (datum-character (vector-ref library-interface 32)) (datum-string (vector-ref library-interface 33)) (datum-symbol (vector-ref library-interface 34)) (datum-number (vector-ref library-interface 35)) (datum-pair (vector-ref library-interface 36)) (datum-vector (vector-ref library-interface 37)) (datum-bytevector (vector-ref library-interface 38)) (datum=? (vector-ref library-interface 39)) (datum-cons (vector-ref library-interface 40)) (datum-car (vector-ref library-interface 41)) (datum-cdr (vector-ref library-interface 42)) (datum-set-car! (vector-ref library-interface 43)) (datum-set-cdr! (vector-ref library-interface 44)) (datum-number? (vector-ref library-interface 45)) (datum-number-value (vector-ref library-interface 46)) (datum-string-value (vector-ref library-interface 47)) (datum-symbol-value (vector-ref library-interface 48)) (datum-null? (vector-ref library-interface 49)) (datum-pair? (vector-ref library-interface 50)) (datum-truth? (vector-ref library-interface 51)) (datum-eq? (vector-ref library-interface 52)) (datum-kind (vector-ref library-interface 53)) (datum-boolean-value (vector-ref library-interface 54)) (datum-character-value (vector-ref library-interface 55)) (datum-vector-values (vector-ref library-interface 56)) (datum-bytevector-values (vector-ref library-interface 57)) (datum-list (vector-ref library-interface 58)) (datum-length (vector-ref library-interface 59)) (datum-append (vector-ref library-interface 60)) (datum-assq (vector-ref library-interface 61)) (datum-map (vector-ref library-interface 62)))
(let ((library-interface (let ()

    ;; Exhaustive source dispatch uses a private Boolean conditional macro.
    (define-syntax cond
      (syntax-rules (else)
        ((_ (else body ...)) (begin body ...))
        ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))

    ;; ---- A datum, normal EOF and malformed input are distinct results ----

    (define-data Token (value-token (datum Datum)) (end-token) (close-token) (dot-token)
      (open-token (kind I64)) (prefix-token (name String)) (error-token (message String)))
    (define-data TextResult (text-value (text String)) (text-error (message String)))
    (define-data Escape (escaped-character (value Char)) (escaped-gap) (escape-error (message String)))
    (: read-end? (-> ReadResult Bool))
    (define (read-end? result)
      (match result ((read-end) #t) ((read-value value) #f) ((read-error message) #f)))
    (: read-value! (-> ReadResult Datum))
    (define (read-value! result)
      (match result ((read-value value) value)
             ((read-end) (datum-fail "read: expected a datum, received end of file"))
             ((read-error message) (datum-fail (string-append "read: " message)))))
    (: read (-> InputPort ReadResult))
    (define (read port) (token-datum port (next-token port)))

    ;; ---- Port lookahead survives every reader invocation ----

    (define-extern raw-whitespace "snail.library" "snail:datum/whitespace" (-> Char I32))
    (: character-code (-> CharacterResult I64))
    (define (character-code result)
      (match result ((character-end) -1) ((character-value value) (char->integer value))))
    (: peek-code (-> InputPort I64))
    (define (peek-code port) (character-code (peek-char port)))
    (: take-code (-> InputPort I64))
    (define (take-code port) (character-code (read-char port)))
    (: code=? (-> I64 Char Bool))
    (define (code=? code character) (= code (char->integer character)))
    (: take-if (-> InputPort Char Bool))
    (define (take-if port character)
      (if (code=? (peek-code port) character) (begin (read-char port) #t) #f))
    (: whitespace? (-> I64 Bool))
    (define (whitespace? code)
      (and (>= code 0) (i32-eq (raw-whitespace (integer->char code)) (ann 1 I32))))
    (: delimiter? (-> I64 Bool))
    (define (delimiter? code)
      (or (< code 0) (whitespace? code)
          (code=? code #\() (code=? code #\)) (code=? code #\")
          (code=? code #\;) (code=? code #\|) (code=? code #\')
          (code=? code #\`) (code=? code #\,) (code=? code #\[)
          (code=? code #\]) (code=? code #\{) (code=? code #\})))

    ;; ---- A geometrically growing Unicode token buffer ----

    (define-data Buffer (buffer (text (Ref String) buffer-text) (count (Ref I64) buffer-count)))
    (: new-buffer (-> Buffer))
    (define (new-buffer) (buffer (ref (make-string 32)) (ref 0)))
    (: append-character! (-> Buffer Char Unit))
    (define (append-character! buffer character)
      (let ((count (ref-get (buffer-count buffer))))
        (when (= count (string-length (ref-get (buffer-text buffer)))) (grow-buffer! buffer count))
        (string-set! (ref-get (buffer-text buffer)) count character)
        (ref-set! (buffer-count buffer) (+ count 1))))
    (: grow-buffer! (-> Buffer I64 Unit))
    (define (grow-buffer! buffer count)
      (if (>= count 4294967294) (datum-fail "read: token exceeds String capacity")
          (let* ((size (if (> count 2147483647) 4294967294 (* count 2)))
                 (grown (make-string size)))
            (string-copy! grown 0 (ref-get (buffer-text buffer)) 0 count)
            (ref-set! (buffer-text buffer) grown))))
    (: buffer-string (-> Buffer String))
    (define (buffer-string buffer)
      (substring (ref-get (buffer-text buffer)) 0 (ref-get (buffer-count buffer))))
    (: read-word (-> InputPort I64 String))
    (define (read-word port first)
      (let ((buffer (new-buffer)))
        (append-character! buffer (integer->char first))
        (let loop ()
          (if (delimiter? (peek-code port)) (buffer-string buffer)
              (begin (append-character! buffer (integer->char (take-code port))) (loop))))))
    (: ascii-lower (-> String String))
    (define (ascii-lower text)
      (let ((result (string-copy text)))
        (let loop ((index 0))
          (if (= index (string-length result)) result
              (let ((code (char->integer (string-ref result index))))
                (when (and (>= code 65) (<= code 90))
                  (string-set! result index (integer->char (+ code 32))))
                (loop (+ index 1)))))))

    ;; ---- Layout includes complete, recursively parsed datum comments ----

    (: skip-line (-> InputPort Unit))
    (define (skip-line port)
      (let ((code (take-code port)))
        (unless (or (< code 0) (code=? code #\newline) (code=? code #\return)) (skip-line port))))
    (: skip-block (-> InputPort I64 Bool))
    (define (skip-block port depth)
      (let ((code (take-code port)))
        (if (< code 0) #f
            (if (and (code=? code #\#) (take-if port #\|)) (skip-block port (+ depth 1))
                (if (and (code=? code #\|) (take-if port #\#))
                    (or (= depth 1) (skip-block port (- depth 1)))
                    (skip-block port depth))))))
    (: discard-datum (-> InputPort Token))
    (define (discard-datum port)
      (match (read port)
        ((read-value value) (next-token port))
        ((read-end) (error-token "datum comment requires a datum"))
        ((read-error message) (error-token message))))
    (: next-token (-> InputPort Token))
    (define (next-token port)
      (let ((code (take-code port)))
        (if (< code 0) (end-token)
            (if (whitespace? code) (next-token port)
                (if (code=? code #\;) (begin (skip-line port) (next-token port))
                    (ordinary-token port code))))))

    ;; ---- Token dispatch exposes all supported syntax in one place ----

    (: ordinary-token (-> InputPort I64 Token))
    (define (ordinary-token port code)
      (cond
       ((code=? code #\() (open-token 0))
       ((code=? code #\)) (close-token))
       ((code=? code #\') (prefix-token "quote"))
       ((code=? code #\`) (prefix-token "quasiquote"))
       ((code=? code #\,) (prefix-token (if (take-if port #\@) "unquote-splicing" "unquote")))
       ((code=? code #\") (quoted-token port #\" #f))
       ((code=? code #\|) (quoted-token port #\| #t))
       ((code=? code #\#) (sharp-token port))
       ((or (code=? code #\[) (code=? code #\]) (code=? code #\{) (code=? code #\}))
        (error-token "unsupported datum delimiter"))
       (else (atom-token (read-word port code)))))
    (: sharp-token (-> InputPort Token))
    (define (sharp-token port)
      (let ((code (take-code port)))
        (cond
         ((< code 0) (error-token "incomplete # syntax"))
         ((code=? code #\() (open-token 1))
         ((code=? code #\;) (discard-datum port))
         ((code=? code #\|)
          (if (skip-block port 1) (next-token port) (error-token "unterminated block comment")))
         ((code=? code #\\) (character-token port))
         ((or (code=? code #\u) (code=? code #\U)) (bytevector-token port))
         ((code=? code #\!) (error-token "reader case directives are not supported"))
         ((and (>= code 48) (<= code 57)) (error-token "datum labels are not supported"))
         (else (sharp-word (string-append "#" (read-word port code)))))))
    (: bytevector-token (-> InputPort Token))
    (define (bytevector-token port)
      (if (and (take-if port #\8) (take-if port #\()) (open-token 2)
          (error-token "expected #u8( bytevector syntax")))
    (: sharp-word (-> String Token))
    (define (sharp-word text)
      (let ((folded (ascii-lower text)))
        (if (or (string=? folded "#t") (string=? folded "#true")) (value-token (datum-boolean #t))
            (if (or (string=? folded "#f") (string=? folded "#false")) (value-token (datum-boolean #f))
                (match (string->number text)
                  ((parsed-number number) (value-token (datum-number number)))
                  ((number-error message) (error-token message))
                  ((not-a-number) (error-token "invalid or unsupported # numeric syntax")))))))
    (: atom-token (-> String Token))
    (define (atom-token text)
      (if (string=? text ".") (dot-token)
          (match (string->atom text)
            ((read-value value) (value-token value))
            ((read-error message) (error-token message)) ((read-end) (unreachable)))))

    ;; ---- Strings and escaped symbols share scalar escapes ----

    (: quoted-token (-> InputPort Char Bool Token))
    (define (quoted-token port end symbol?)
      (match (read-text port end)
        ((text-value text) (value-token (if symbol? (datum-symbol (string->symbol text)) (datum-string text))))
        ((text-error message) (error-token message))))
    (: read-text (-> InputPort Char TextResult))
    (define (read-text port end) (text-loop port end (new-buffer)))
    (: text-loop (-> InputPort Char Buffer TextResult))
    (define (text-loop port end buffer)
      (let ((code (take-code port)))
        (if (< code 0) (text-error "unterminated string or escaped symbol")
            (if (code=? code end) (text-value (buffer-string buffer))
                (if (code=? code #\\) (continue-escape port end buffer (read-escape port end))
                    (begin
                      (append-character! buffer (text-character port end code))
                      (text-loop port end buffer)))))))
    (: text-character (-> InputPort Char I64 Char))
    (define (text-character port end code)
      (if (and (char=? end #\") (code=? code #\return))
          (begin (take-if port #\newline) #\newline) (integer->char code)))
    (: continue-escape (-> InputPort Char Buffer Escape TextResult))
    (define (continue-escape port end buffer escape)
      (match escape
        ((escaped-character value) (append-character! buffer value) (text-loop port end buffer))
        ((escaped-gap) (text-loop port end buffer)) ((escape-error message) (text-error message))))
    (: read-escape (-> InputPort Char Escape))
    (define (read-escape port end)
      (let ((code (take-code port)))
        (cond
         ((code=? code #\a) (escaped-character (integer->char 7)))
         ((code=? code #\b) (escaped-character (integer->char 8)))
         ((code=? code #\t) (escaped-character #\tab))
         ((code=? code #\n) (escaped-character #\newline))
         ((code=? code #\r) (escaped-character #\return))
         ((or (code=? code #\") (code=? code #\|) (code=? code #\\))
          (escaped-character (integer->char code)))
         ((code=? code #\x) (hex-escape port 0 0))
         ((and (char=? end #\") (continuation-space? code)) (line-continuation port code))
         (else (escape-error "unknown or incomplete escape")))))
    (: continuation-space? (-> I64 Bool))
    (define (continuation-space? code)
      (or (code=? code #\space) (code=? code #\tab) (code=? code #\newline) (code=? code #\return)))
    (: skip-horizontal (-> InputPort Unit))
    (define (skip-horizontal port)
      (when (or (code=? (peek-code port) #\space) (code=? (peek-code port) #\tab))
        (read-char port) (skip-horizontal port)))
    (: line-continuation (-> InputPort I64 Escape))
    (define (line-continuation port code)
      (if (or (code=? code #\space) (code=? code #\tab)) (line-continuation port (take-code port))
          (if (or (code=? code #\newline) (code=? code #\return))
              (begin (when (code=? code #\return) (take-if port #\newline) (unit))
                     (skip-horizontal port) (escaped-gap))
              (escape-error "expected newline in string continuation"))))

    ;; ---- Hexadecimal escapes validate Unicode before constructing Char ----

    (: hex-digit (-> I64 I64))
    (define (hex-digit code)
      (if (and (>= code 48) (<= code 57)) (- code 48)
          (if (and (>= code 65) (<= code 70)) (- code 55)
              (if (and (>= code 97) (<= code 102)) (- code 87) -1))))
    (: unicode-scalar? (-> I64 Bool))
    (define (unicode-scalar? value)
      (and (>= value 0) (<= value 1114111) (or (< value 55296) (> value 57343))))
    (: finish-hex (-> I64 I64 Escape))
    (define (finish-hex value count)
      (if (and (> count 0) (unicode-scalar? value)) (escaped-character (integer->char value))
          (escape-error "invalid Unicode scalar escape")))
    (: hex-escape (-> InputPort I64 I64 Escape))
    (define (hex-escape port value count)
      (let ((code (take-code port)))
        (if (code=? code #\;) (finish-hex value count)
            (let ((digit (hex-digit code)))
              (if (or (< digit 0) (> value 69631)) (escape-error "invalid hexadecimal escape")
                  (hex-escape port (+ (* value 16) digit) (+ count 1)))))))
    (: hex-character (-> String Escape))
    (define (hex-character text)
      (let loop ((index 1) (value 0))
        (if (= index (string-length text)) (finish-hex value (- index 1))
            (let ((digit (hex-digit (char->integer (string-ref text index)))))
              (if (or (< digit 0) (> value 69631)) (escape-error "invalid character code")
                  (loop (+ index 1) (+ (* value 16) digit)))))))

    ;; ---- Character literals can contain a delimiter as their one scalar ----

    (: character-token (-> InputPort Token))
    (define (character-token port)
      (let ((code (take-code port)))
        (if (< code 0) (error-token "incomplete character literal")
            (if (delimiter? code) (value-token (datum-character (integer->char code)))
                (named-character-token (read-word port code))))))
    (: named-character-token (-> String Token))
    (define (named-character-token text)
      (if (= (string-length text) 1) (value-token (datum-character (string-ref text 0)))
          (match (named-character (ascii-lower text))
            ((escaped-character value) (value-token (datum-character value)))
            ((escape-error message) (error-token message)) ((escaped-gap) (unreachable)))))
    (: named-character (-> String Escape))
    (define (named-character text)
      (cond
       ((string=? text "alarm") (escaped-character (integer->char 7)))
       ((string=? text "backspace") (escaped-character (integer->char 8)))
       ((string=? text "delete") (escaped-character (integer->char 127)))
       ((string=? text "escape") (escaped-character (integer->char 27)))
       ((string=? text "newline") (escaped-character #\newline))
       ((string=? text "null") (escaped-character (integer->char 0)))
       ((string=? text "return") (escaped-character #\return))
       ((string=? text "space") (escaped-character #\space))
       ((string=? text "tab") (escaped-character #\tab))
       ((char=? (string-ref text 0) #\x) (hex-character text))
       (else (escape-error "unknown character literal"))))

    ;; ---- Containers preserve source order and dotted-tail structure ----

    (: token-datum (-> InputPort Token ReadResult))
    (define (token-datum port token)
      (match token
        ((value-token value) (read-value value)) ((end-token) (read-end))
        ((error-token message) (read-error message))
        ((open-token kind) (container-loop port kind '()))
        ((prefix-token name) (prefix-datum port name))
        ((close-token) (read-error "unexpected closing parenthesis"))
        ((dot-token) (read-error "unexpected dot"))))
    (: prefix-datum (-> InputPort String ReadResult))
    (define (prefix-datum port name)
      (match (read port)
        ((read-value value) (read-value (datum-cons (datum-symbol (string->symbol name))
                                                    (datum-cons value (datum-null)))))
        ((read-end) (read-error "quote abbreviation requires a datum"))
        ((read-error message) (read-error message))))
    (: container-loop (-> InputPort I64 (List Datum) ReadResult))
    (define (container-loop port kind reversed)
      (let ((token (next-token port)))
        (match token
          ((close-token) (finish-container kind reversed))
          ((end-token) (read-error "unexpected end of input inside container"))
          ((dot-token) (if (and (= kind 0) (not (null? reversed))) (dotted-tail port reversed)
                           (read-error "dot requires a preceding list element")))
          ((error-token message) (read-error message))
          ((value-token value) (container-loop port kind (cons value reversed)))
          ((open-token nested-kind) (container-element port kind reversed (token-datum port token)))
          ((prefix-token name) (container-element port kind reversed (token-datum port token))))))
    (: container-element (-> InputPort I64 (List Datum) ReadResult ReadResult))
    (define (container-element port kind reversed result)
      (match result
        ((read-value value) (container-loop port kind (cons value reversed)))
        ((read-error message) (read-error message)) ((read-end) (unreachable))))
    (: dotted-tail (-> InputPort (List Datum) ReadResult))
    (define (dotted-tail port reversed)
      (match (read port)
        ((read-value tail) (match (next-token port)
                             ((close-token) (read-value (attach-reversed reversed tail)))
                             ((error-token message) (read-error message))
                             ((value-token value) (read-error "extra datum after dotted tail"))
                             ((end-token) (read-error "unclosed dotted list"))
                             ((dot-token) (read-error "extra dot after dotted tail"))
                             ((open-token kind) (read-error "extra container after dotted tail"))
                             ((prefix-token name) (read-error "extra abbreviation after dotted tail"))))
        ((read-end) (read-error "missing dotted tail"))
        ((read-error message) (read-error message))))
    (: attach-reversed (-> (List Datum) Datum Datum))
    (define (attach-reversed reversed tail)
      (if (null? reversed) tail
          (attach-reversed (cdr reversed) (datum-cons (car reversed) tail))))
    (: reverse-elements (-> (List Datum) (List Datum)))
    (define (reverse-elements elements)
      (let loop ((elements elements) (result '()))
        (if (null? elements) result (loop (cdr elements) (cons (car elements) result)))))
    (: finish-container (-> I64 (List Datum) ReadResult))
    (define (finish-container kind reversed)
      (if (= kind 0) (read-value (attach-reversed reversed (datum-null)))
          (if (= kind 1) (read-value (datum-vector (list->vector (reverse-elements reversed))))
              (finish-bytes reversed))))
    (: finish-bytes (-> (List Datum) ReadResult))
    (define (finish-bytes reversed)
      (let ((count (let loop ((tail reversed) (count 0))
                     (if (null? tail) count (loop (cdr tail) (+ count 1))))))
        (fill-bytes reversed (make-bytevector count) count)))
    (: byte-value (-> Datum I64))
    (define (byte-value value)
      (if (datum-number? value)
          (match (datum-number-value value) ((exact-number value) value)
                 ((rational-number value) -1) ((inexact-number value) -1) ((complex-number real imaginary) -1)) -1))
    (: fill-bytes (-> (List Datum) Bytevector I64 ReadResult))
    (define (fill-bytes reversed result index)
      (if (null? reversed) (read-value (datum-bytevector result))
          (let ((value (byte-value (car reversed))))
            (if (or (< value 0) (> value 255)) (read-error "bytevector requires exact bytes in [0,255]")
                (begin (bytevector-u8-set! result (- index 1) value)
                       (fill-bytes (cdr reversed) result (- index 1)))))))

(vector read read-end read-value read-error read-end? read-value-datum read-error-message read-value!))))
  (let ((read (vector-ref library-interface 0)) (read-end (vector-ref library-interface 1)) (read-value (vector-ref library-interface 2)) (read-error (vector-ref library-interface 3)) (read-end? (vector-ref library-interface 4)) (read-value-datum (vector-ref library-interface 5)) (read-error-message (vector-ref library-interface 6)) (read-value! (vector-ref library-interface 7)))
(let ()
(: workload-read (-> InputPort ReadResult))
(define (workload-read port)
  (let ((result (read port)))
    (match result
      ((read-error message) (datum-fail (string-append "read: " message)))
      ((read-value value) result) ((read-end) result))))
(: real-datum (-> Datum F64))
(define (real-datum value)
  (if (datum-number? value) (number->f64 (datum-number-value value))
      (datum-fail "sum1: expected a real number")))
(: exact-datum (-> Datum I64))
(define (exact-datum value)
  (match (datum-number-value value)
    ((exact-number value) value)
    ((rational-number value) (datum-fail "benchmark count must fit an exact I64"))
    ((inexact-number value) (datum-fail "benchmark count must be exact"))
    ((complex-number real imaginary) (datum-fail "benchmark count must be exact"))))
(vector datum-fail datum-null datum-cons datum-car datum-cdr datum-list datum-null? datum-pair? datum-length datum-vector datum-vector-values datum-symbol datum-number datum-string datum-boolean datum-character datum-number-value datum-string-value datum-symbol-value datum=? datum-eq? datum-kind datum-boolean-value datum-character-value datum-bytevector-values datum-set-car! datum-set-cdr! exact-number i64->string read-value! workload-read string->symbol symbol->string symbol=? string->number read-char))
))
))
))
))
))
)
)
(define datum-fail (vector-ref reader-interface 0))
(define datum-null (vector-ref reader-interface 1))
(define datum-cons (vector-ref reader-interface 2))
(define datum-car (vector-ref reader-interface 3))
(define datum-cdr (vector-ref reader-interface 4))
(define datum-list (vector-ref reader-interface 5))
(define datum-null? (vector-ref reader-interface 6))
(define datum-pair? (vector-ref reader-interface 7))
(define datum-length (vector-ref reader-interface 8))
(define datum-vector (vector-ref reader-interface 9))
(define datum-vector-values (vector-ref reader-interface 10))
(define datum-symbol (vector-ref reader-interface 11))
(define datum-number (vector-ref reader-interface 12))
(define datum-string (vector-ref reader-interface 13))
(define datum-boolean (vector-ref reader-interface 14))
(define datum-character (vector-ref reader-interface 15))
(define datum-number-value (vector-ref reader-interface 16))
(define datum-string-value (vector-ref reader-interface 17))
(define datum-symbol-value (vector-ref reader-interface 18))
(define datum=? (vector-ref reader-interface 19))
(define datum-eq? (vector-ref reader-interface 20))
(define datum-kind (vector-ref reader-interface 21))
(define datum-boolean-value (vector-ref reader-interface 22))
(define datum-character-value (vector-ref reader-interface 23))
(define datum-bytevector-values (vector-ref reader-interface 24))
(define datum-set-car! (vector-ref reader-interface 25))
(define datum-set-cdr! (vector-ref reader-interface 26))
(define exact-number (vector-ref reader-interface 27))
(define i64->string (vector-ref reader-interface 28))
(define read-value! (vector-ref reader-interface 29))
(define workload-read (vector-ref reader-interface 30))
(define typed-string->symbol (vector-ref reader-interface 31))
(define typed-symbol->string (vector-ref reader-interface 32))
(define typed-symbol=? (vector-ref reader-interface 33))
(define typed-string->number (vector-ref reader-interface 34))
(define parsing-read-char (vector-ref reader-interface 35))
(define (parsing-case=? left right)
  (if (char? left) (char=? left right) (typed-symbol=? left right)))
(define parsing-whitespace? char-whitespace?)
(define parsing-write-character write-char)
(: parsing-list (All (T) (-> (Rest T) (List T))))
(define (parsing-list . values) values)
(: parsing-cadr (All (T) (-> (List T) T)))
(define (parsing-cadr values) (car (cdr values)))
(: parsing-reverse (All (T) (-> (List T) (List T))))
(define (parsing-reverse values)
  (let loop ((values values) (result '()))
    (if (null? values) result (loop (cdr values) (cons (car values) result)))))
(: parsing-member? (-> Symbol (List Symbol) Bool))
(define (parsing-member? value values)
  (and (not (null? values))
       (or (typed-symbol=? value (car values)) (parsing-member? value (cdr values)))))
(: parsing-char? (-> Char Bool))
(define (parsing-char? value) #t)
(: parsing-character-end? (-> CharacterResult Bool))
(define (parsing-character-end? value)
  (match value ((character-end) #t) ((character-value value) #f)))
(: parsing-character-text (-> CharacterResult Char))
(define (parsing-character-text value)
  (match value ((character-end) (datum-fail "parsing: unexpected physical EOF"))
               ((character-value value) value)))
(: parsing-integer (-> I64 Datum))
(define (parsing-integer value) (datum-number (exact-number value)))
(: parsing-exact (-> Datum I64))
(define (parsing-exact value)
  (match (datum-number-value value)
    ((exact-number value) value)
    ((rational-number value) (datum-fail "parsing: expected an exact count"))
    ((inexact-number value) (datum-fail "parsing: expected an exact count"))
    ((complex-number real imaginary) (datum-fail "parsing: expected an exact count"))))
(: parsing-number (-> String Datum))
(define (parsing-number text)
  (match (typed-string->number text)
    ((not-a-number) (datum-boolean #f))
    ((parsed-number value) (datum-number value))
    ((number-error message) (datum-fail message))))
(: parsing-vector (-> Datum Datum))
(define (parsing-vector values)
  (let ((result (make-vector (datum-length values) (datum-null))))
    (let loop ((values values) (index 0))
      (if (datum-null? values) (datum-vector result)
          (begin (vector-set! result index (datum-car values))
                 (loop (datum-cdr values) (+ index 1)))))))
(: parsing-display-string (-> String Unit))
(define (parsing-display-string text)
  (let loop ((index 0))
    (when (< index (string-length text))
      (parsing-write-character (string-ref text index)) (loop (+ index 1)))))
(: parsing-display-symbol (-> Symbol Unit))
(define (parsing-display-symbol value) (parsing-display-string (typed-symbol->string value)))
(: parsing-display-symbols (-> (List Symbol) Unit))
(define (parsing-display-symbols values)
  ;; Every diagnostic name is a bare printable symbol in the pinned grammar.
  (parsing-write-character #\()
  (let loop ((values values) (first #t))
    (unless (null? values)
      (unless first (parsing-write-character #\space))
      (parsing-display-symbol (car values)) (loop (cdr values) #f)))
  (parsing-write-character #\)))
(define (parsing-newline) (parsing-write-character #\newline))
(define parsing-symbol-<abbrev-prefix>-value (typed-string->symbol "<abbrev-prefix>"))
(define parsing-symbol-<abbreviation>-value (typed-string->symbol "<abbreviation>"))
(define parsing-symbol-<compound-datum>-value (typed-string->symbol "<compound-datum>"))
(define parsing-symbol-<data>-value (typed-string->symbol "<data>"))
(define parsing-symbol-<datum>-value (typed-string->symbol "<datum>"))
(define parsing-symbol-<list2>-value (typed-string->symbol "<list2>"))
(define parsing-symbol-<list3>-value (typed-string->symbol "<list3>"))
(define parsing-symbol-<list4>-value (typed-string->symbol "<list4>"))
(define parsing-symbol-<list>-value (typed-string->symbol "<list>"))
(define parsing-symbol-<simple-datum>-value (typed-string->symbol "<simple-datum>"))
(define parsing-symbol-<symbol>-value (typed-string->symbol "<symbol>"))
(define parsing-symbol-<vector>-value (typed-string->symbol "<vector>"))
(define parsing-symbol-backquote-value (typed-string->symbol "backquote"))
(define parsing-symbol-boolean-value (typed-string->symbol "boolean"))
(define parsing-symbol-character-value (typed-string->symbol "character"))
(define parsing-symbol-comma-value (typed-string->symbol "comma"))
(define parsing-symbol-eof-value (typed-string->symbol "eof"))
(define parsing-symbol-id-value (typed-string->symbol "id"))
(define parsing-symbol-lparen-value (typed-string->symbol "lparen"))
(define parsing-symbol-number-value (typed-string->symbol "number"))
(define parsing-symbol-period-value (typed-string->symbol "period"))
(define parsing-symbol-quasiquote-value (typed-string->symbol "quasiquote"))
(define parsing-symbol-quote-value (typed-string->symbol "quote"))
(define parsing-symbol-rparen-value (typed-string->symbol "rparen"))
(define parsing-symbol-splicing-value (typed-string->symbol "splicing"))
(define parsing-symbol-string-value (typed-string->symbol "string"))
(define parsing-symbol-unquote-value (typed-string->symbol "unquote"))
(define parsing-symbol-unquote-splicing-value (typed-string->symbol "unquote-splicing"))
(define parsing-symbol-vecstart-value (typed-string->symbol "vecstart"))
(define parsing-symbol-z1-value (typed-string->symbol "z1"))
(define parsing-literal-0 (parsing-list ))
(define parsing-literal-1 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-quote-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-2 (parsing-list parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-id-value parsing-symbol-number-value parsing-symbol-string-value))
(define parsing-literal-3 (parsing-list parsing-symbol-id-value))
(define parsing-literal-4 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-lparen-value parsing-symbol-quote-value parsing-symbol-splicing-value parsing-symbol-vecstart-value))
(define parsing-literal-5 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-lparen-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-6 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-7 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-period-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-8 (parsing-list parsing-symbol-rparen-value))
(define parsing-literal-9 (parsing-list parsing-symbol-period-value parsing-symbol-rparen-value))
(define parsing-literal-10 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-11 (parsing-list parsing-symbol-backquote-value parsing-symbol-comma-value parsing-symbol-quote-value parsing-symbol-splicing-value))
(define parsing-literal-12 (parsing-list parsing-symbol-rparen-value))
(define parsing-literal-13 (parsing-list parsing-symbol-vecstart-value))
(define parsing-literal-14 (parsing-list parsing-symbol-backquote-value parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-comma-value parsing-symbol-id-value parsing-symbol-lparen-value parsing-symbol-number-value parsing-symbol-period-value parsing-symbol-quote-value parsing-symbol-rparen-value parsing-symbol-splicing-value parsing-symbol-string-value parsing-symbol-vecstart-value))
(define parsing-literal-15 (parsing-list parsing-symbol-boolean-value parsing-symbol-character-value parsing-symbol-id-value parsing-symbol-number-value parsing-symbol-string-value))
(define-syntax parsing-case-value
  (syntax-rules (<abbrev-prefix> <abbreviation> <compound-datum> <data> <datum> <list2> <list3> <list4> <list> <simple-datum> <symbol> <vector> backquote boolean character comma eof id lparen number period quasiquote quote rparen splicing string unquote unquote-splicing vecstart z1)
    ((_ <abbrev-prefix>) parsing-symbol-<abbrev-prefix>-value)
    ((_ <abbreviation>) parsing-symbol-<abbreviation>-value)
    ((_ <compound-datum>) parsing-symbol-<compound-datum>-value)
    ((_ <data>) parsing-symbol-<data>-value)
    ((_ <datum>) parsing-symbol-<datum>-value)
    ((_ <list2>) parsing-symbol-<list2>-value)
    ((_ <list3>) parsing-symbol-<list3>-value)
    ((_ <list4>) parsing-symbol-<list4>-value)
    ((_ <list>) parsing-symbol-<list>-value)
    ((_ <simple-datum>) parsing-symbol-<simple-datum>-value)
    ((_ <symbol>) parsing-symbol-<symbol>-value)
    ((_ <vector>) parsing-symbol-<vector>-value)
    ((_ backquote) parsing-symbol-backquote-value)
    ((_ boolean) parsing-symbol-boolean-value)
    ((_ character) parsing-symbol-character-value)
    ((_ comma) parsing-symbol-comma-value)
    ((_ eof) parsing-symbol-eof-value)
    ((_ id) parsing-symbol-id-value)
    ((_ lparen) parsing-symbol-lparen-value)
    ((_ number) parsing-symbol-number-value)
    ((_ period) parsing-symbol-period-value)
    ((_ quasiquote) parsing-symbol-quasiquote-value)
    ((_ quote) parsing-symbol-quote-value)
    ((_ rparen) parsing-symbol-rparen-value)
    ((_ splicing) parsing-symbol-splicing-value)
    ((_ string) parsing-symbol-string-value)
    ((_ unquote) parsing-symbol-unquote-value)
    ((_ unquote-splicing) parsing-symbol-unquote-splicing-value)
    ((_ vecstart) parsing-symbol-vecstart-value)
    ((_ z1) parsing-symbol-z1-value)
    ((_ other) other)))
(define-syntax parsing-cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (parsing-cond rest ...)))))
(define-syntax do-step
  (syntax-rules () ((_ variable) variable) ((_ variable step) step)))
(define-syntax parsing-do
  (syntax-rules ()
    ((_ ((variable initial step ...) ...) (test result ...) body ...)
     (let loop ((variable initial) ...)
       (if test (begin (unit) result ...)
           (begin body ... (loop (do-step variable step ...) ...)))))))

(define-syntax parsing-case
  (syntax-rules (else)
    ((_ key (else body ...)) (begin body ...))
    ((_ key ((value ...) body ...) rest ...)
     (let ((saved key))
       (if (or (parsing-case=? saved (parsing-case-value value)) ...)
           (begin body ...) (parsing-case saved rest ...))))))
(: parsing-benchmark (-> (Rest Datum) Datum))
(: read-file-as-string (-> String String))
(: parse-string (-> String Datum))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Copyright 2006 William D Clinger.
;;
;; Permission to copy this software, in whole or in part, to use this
;; software for any lawful purpose, and to redistribute this software
;; is granted subject to the restriction that all copies made of this
;; software must include this copyright notice in full.
;;
;; I also request that you send me a copy of any improvements that you
;; make to this software so that they may be incorporated within it to
;; the benefit of the Scheme community.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Parsing benchmark.
;;
;; Reads nboyer.sch into a string before timing begins.
;;
;; The timed portion of the benchmark parses the string
;; representation of nboyer.sch 1000 times.
;;
;; The output of that parse is checked by comparing it
;; the the value returned by the read procedure.
;;
;; Usage:
;;     (parsing-benchmark n input)
;;
;; n defaults to 1000, and input defaults to "nboyer.sch".
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(define (parsing-benchmark . rest)
  (let* ((n (parsing-exact (if (null? rest) (parsing-integer 1000) (car rest))))
         (input (datum-string-value (if (or (null? rest) (null? (cdr rest)))
                    (datum-string "nboyer.sch")
                    (parsing-cadr rest))))
         (input-string (read-file-as-string input)))
    (let loop ((i 0) (result (datum-boolean #f)))
      (if (= i n)
          result
          (loop (+ i 1) (parse-string input-string))))))

(define (read-file-as-string name)
  (call-with-input-file
      name
    (lambda (in)
      (parsing-do ((x (parsing-read-char in) (parsing-read-char in))
           (chars parsing-literal-0 (cons (parsing-character-text x) chars)))
          ((parsing-character-end? x)
           (list->string (parsing-reverse chars)))))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; The parser used for benchmarking.
;;
;; Given a string containing Scheme code, parses the entire
;; string and returns the last <datum> read from the string.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (parse-string input-string)

  ;; Constants and local variables.

  (let* (; Constants.

         ;; Any character that doesn't appear within nboyer.sch
         ;; (or the input file, if different) can be used to
         ;; represent end-of-file.

         (eof #\~)

         ;; length of longest token allowed
         ;; (this allows static allocation in C)

         (max_token_size 1024)

         ;; Encodings of error messages.

         (errLongToken 1);; extremely long token
         (errincompletetoken 2);; any lexical error, really
         (errLexGenBug 3);; can't happen

         ;; State for one-token buffering in lexical analyzer.

         (kindOfNextToken (ref parsing-symbol-z1-value));; valid iff nextTokenIsReady
         (nextTokenIsReady (ref #f))

         (tokenValue (ref ""));; string associated with current token

         (totalErrors 0);; errors so far
         (lineNumber (ref 1));; rudimentary source code location
         (lineNumberOfLastError 0);; ditto

         ;; A string buffer for the characters of the current token.

         (string_accumulator (make-string max_token_size))

         ;; Number of characters in string_accumulator.

         (string_accumulator_length (ref 0))

         ;; A single character of buffering.
         ;; nextCharacter is valid iff nextCharacterIsReady

         (nextCharacter (ref #\space))
         (nextCharacterIsReady (ref #f))

         ;; Index of next character to be read from input-string.

         (input-index (ref 0))

         (input-length (string-length input-string))
         )

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; LexGen generated the code for the state machine.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (: scanner0 (->  Symbol))
    (: next-token (->  Symbol))
    (: accept (-> Symbol Symbol))
    (: consume-token! (->  Unit))
    (: scannererror (-> I64 Symbol))
    (: scanchar (->  Char))
    (: consumechar (->  Unit))
    (: pseudoAppend (-> Datum Datum Datum))
    (: parse-error (-> Symbol (List Symbol) Datum))
    (: state0 (-> Char Symbol))
    (: state1 (-> Char Symbol))
    (: state2 (-> Char Symbol))
    (: state3 (-> Char Symbol))
    (: state4 (-> Char Symbol))
    (: state5 (-> Char Symbol))
    (: state6 (-> Char Symbol))
    (: state7 (-> Char Symbol))
    (: state8 (-> Char Symbol))
    (: state9 (-> Char Symbol))
    (: state10 (-> Char Symbol))
    (: state11 (-> Char Symbol))
    (: state12 (-> Char Symbol))
    (: state13 (-> Char Symbol))
    (: state14 (-> Char Symbol))
    (: state15 (-> Char Symbol))
    (: state16 (-> Char Symbol))
    (: state17 (-> Char Symbol))
    (: state18 (-> Char Symbol))
    (: state19 (-> Char Symbol))
    (: state20 (-> Char Symbol))
    (: state21 (-> Char Symbol))
    (: state22 (-> Char Symbol))
    (: state23 (-> Char Symbol))
    (: state24 (-> Char Symbol))
    (: state25 (-> Char Symbol))
    (: state26 (-> Char Symbol))
    (: state27 (-> Char Symbol))
    (: state28 (-> Char Symbol))
    (: state29 (-> Char Symbol))
    (: state30 (-> Char Symbol))
    (: state31 (-> Char Symbol))
    (: state32 (-> Char Symbol))
    (: state33 (-> Char Symbol))
    (: state34 (-> Char Symbol))
    (: state35 (-> Char Symbol))
    (: state36 (-> Char Symbol))
    (: state37 (-> Char Symbol))
    (: state38 (-> Char Symbol))
    (: state39 (-> Char Symbol))
    (: state40 (-> Char Symbol))
    (: state41 (-> Char Symbol))
    (: parse-datum (->  Datum))
    (: parse-simple-datum (->  Datum))
    (: parse-symbol (->  Datum))
    (: parse-compound-datum (->  Datum))
    (: parse-list (->  Datum))
    (: parse-list2 (->  Datum))
    (: parse-list3 (->  Datum))
    (: parse-list4 (->  Datum))
    (: parse-abbreviation (->  Datum))
    (: parse-abbrev-prefix (->  Datum))
    (: parse-vector (->  Datum))
    (: parse-data (->  Datum))
    (: emptyList (->  Datum))
    (: makeBool (->  Datum))
    (: makeChar (->  Datum))
    (: makeNum (->  Datum))
    (: makeString (->  Datum))
    (: makeSym (->  Datum))
    (: symBackquote (->  Datum))
    (: symQuote (->  Datum))
    (: symSplicing (->  Datum))
    (: symUnquote (->  Datum))

    (define (scanner0)
      (let loop ((c (scanchar)))
        (when (parsing-whitespace? c)
          (consumechar)
          (ref-set! string_accumulator_length 0)
          (loop (scanchar))))
      (let ((c (scanchar)))
        (if (char=? c eof) (accept parsing-symbol-eof-value) (state0 c))))

    (define (state0 c)
      (parsing-case c
        ((#\`) (consumechar) (accept parsing-symbol-backquote-value))
        ((#\') (consumechar) (accept parsing-symbol-quote-value))
        ((#\)) (consumechar) (accept parsing-symbol-rparen-value))
        ((#\() (consumechar) (accept parsing-symbol-lparen-value))
        ((#\;) (consumechar) (state29 (scanchar)))
        ((#\+ #\-) (consumechar) (state28 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\.) (consumechar) (state16 (scanchar)))
        ((#\a
          #\b
          #\c
          #\d
          #\e
          #\f
          #\g
          #\h
          #\i
          #\j
          #\k
          #\l
          #\m
          #\n
          #\o
          #\p
          #\q
          #\r
          #\s
          #\t
          #\u
          #\v
          #\w
          #\x
          #\y
          #\z
          #\A
          #\B
          #\C
          #\D
          #\E
          #\F
          #\G
          #\H
          #\I
          #\J
          #\K
          #\L
          #\M
          #\N
          #\O
          #\P
          #\Q
          #\R
          #\S
          #\T
          #\U
          #\V
          #\W
          #\X
          #\Y
          #\Z
          #\!
          #\$
          #\%
          #\&
          #\*
          #\/
          #\:
          #\<
          #\=
          #\>
          #\?
          #\^
          #\_
          #\~)
         (consumechar)
         (state14 (scanchar)))
        ((#\#) (consumechar) (state13 (scanchar)))
        ((#\") (consumechar) (state2 (scanchar)))
        ((#\,) (consumechar) (state1 (scanchar)))
        (else
         (if (parsing-whitespace? c)
             (begin (consumechar) (state30 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state1 c)
      (parsing-case c
        ((#\@) (consumechar) (accept parsing-symbol-splicing-value))
        (else (accept parsing-symbol-comma-value))))
    (define (state2 c)
      (parsing-case c
        ((#\") (consumechar) (accept parsing-symbol-string-value))
        (else
         (if (isnotdoublequote? c)
             (begin (consumechar) (state2 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state3 c)
      (parsing-case c
        ((#\n) (consumechar) (state8 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state4 c)
      (parsing-case c
        ((#\i) (consumechar) (state3 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state5 c)
      (parsing-case c
        ((#\l) (consumechar) (state4 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state6 c)
      (parsing-case c
        ((#\w) (consumechar) (state5 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state7 c)
      (parsing-case c
        ((#\e) (consumechar) (state6 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state8 c)
      (parsing-case c
        ((#\e) (consumechar) (accept parsing-symbol-character-value))
        (else (scannererror errincompletetoken))))
    (define (state9 c)
      (parsing-case c
        ((#\c) (consumechar) (state8 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state10 c)
      (parsing-case c
        ((#\a) (consumechar) (state9 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state11 c)
      (parsing-case c
        ((#\p) (consumechar) (state10 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state12 c)
      (parsing-case c
        ((#\s) (consumechar) (state11 (scanchar)))
        ((#\n) (consumechar) (state7 (scanchar)))
        (else
         (if (parsing-char? c)
             (begin (consumechar) (accept parsing-symbol-character-value))
             (scannererror errincompletetoken)))))
    (define (state13 c)
      (parsing-case c
        ((#\() (consumechar) (accept parsing-symbol-vecstart-value))
        ((#\t #\f) (consumechar) (accept parsing-symbol-boolean-value))
        ((#\\) (consumechar) (state12 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state14 c)
      (parsing-case c
        ((#\a
          #\b
          #\c
          #\d
          #\e
          #\f
          #\g
          #\h
          #\i
          #\j
          #\k
          #\l
          #\m
          #\n
          #\o
          #\p
          #\q
          #\r
          #\s
          #\t
          #\u
          #\v
          #\w
          #\x
          #\y
          #\z
          #\A
          #\B
          #\C
          #\D
          #\E
          #\F
          #\G
          #\H
          #\I
          #\J
          #\K
          #\L
          #\M
          #\N
          #\O
          #\P
          #\Q
          #\R
          #\S
          #\T
          #\U
          #\V
          #\W
          #\X
          #\Y
          #\Z
          #\!
          #\$
          #\%
          #\&
          #\*
          #\/
          #\:
          #\<
          #\=
          #\>
          #\?
          #\^
          #\_
          #\~
          #\0
          #\1
          #\2
          #\3
          #\4
          #\5
          #\6
          #\7
          #\8
          #\9
          #\+
          #\-
          #\.
          #\@)
         (consumechar)
         (state14 (scanchar)))
        (else (accept parsing-symbol-id-value))))
    (define (state15 c)
      (parsing-case c
        ((#\.) (consumechar) (accept parsing-symbol-id-value))
        (else (scannererror errincompletetoken))))
    (define (state16 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        ((#\.) (consumechar) (state15 (scanchar)))
        (else (accept parsing-symbol-period-value))))
    (define (state17 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state18 c)
      (parsing-case c
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\#) (consumechar) (state19 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state18 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state19 c)
      (parsing-case c
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\#) (consumechar) (state19 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state20 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state21 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state22 c)
      (parsing-case c
        ((#\+ #\-) (consumechar) (state21 (scanchar)))
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state20 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state23 c)
      (parsing-case c
        ((#\#) (consumechar) (state23 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state24 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state24 (scanchar)))
        ((#\#) (consumechar) (state23 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state25 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state24 (scanchar)))
        (else (scannererror errincompletetoken))))
    (define (state26 c)
      (parsing-case c
        ((#\#) (consumechar) (state26 (scanchar)))
        ((#\/) (consumechar) (state25 (scanchar)))
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\.) (consumechar) (state19 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state27 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\#) (consumechar) (state26 (scanchar)))
        ((#\/) (consumechar) (state25 (scanchar)))
        ((#\e #\s #\f #\d #\l)
         (consumechar)
         (state22 (scanchar)))
        ((#\.) (consumechar) (state18 (scanchar)))
        (else (accept parsing-symbol-number-value))))
    (define (state28 c)
      (parsing-case c
        ((#\0 #\1 #\2 #\3 #\4 #\5 #\6 #\7 #\8 #\9)
         (consumechar)
         (state27 (scanchar)))
        ((#\.) (consumechar) (state17 (scanchar)))
        (else (accept parsing-symbol-id-value))))
    (define (state29 c)
      (parsing-case c
        ((#\newline)
         (consumechar)
         (begin
           (ref-set! string_accumulator_length 0)
           (state0 (scanchar))))
        (else
         (if (isnotnewline? c)
             (begin (consumechar) (state29 (scanchar)))
             (scannererror errincompletetoken)))))
    (define (state30 c)
      (parsing-case c
        (else
         (if (parsing-whitespace? c)
             (begin (consumechar) (state30 (scanchar)))
             (begin
               (ref-set! string_accumulator_length 0)
               (state0 (scanchar)))))))
    (define (state31 c)
      (parsing-case c
        (else
         (begin
           (ref-set! string_accumulator_length 0)
           (state0 (scanchar))))))
    (define (state32 c) (parsing-case c (else (accept parsing-symbol-id-value))))
    (define (state33 c)
      (parsing-case c (else (accept parsing-symbol-boolean-value))))
    (define (state34 c)
      (parsing-case c (else (accept parsing-symbol-character-value))))
    (define (state35 c)
      (parsing-case c (else (accept parsing-symbol-vecstart-value))))
    (define (state36 c)
      (parsing-case c (else (accept parsing-symbol-string-value))))
    (define (state37 c)
      (parsing-case c (else (accept parsing-symbol-lparen-value))))
    (define (state38 c)
      (parsing-case c (else (accept parsing-symbol-rparen-value))))
    (define (state39 c)
      (parsing-case c (else (accept parsing-symbol-quote-value))))
    (define (state40 c)
      (parsing-case c (else (accept parsing-symbol-backquote-value))))
    (define (state41 c)
      (parsing-case c (else (accept parsing-symbol-splicing-value))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; End of state machine generated by LexGen.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; ParseGen generated the code for the strong LL(1) parser.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (parse-datum)
      (parsing-case (next-token)
        ((splicing comma backquote quote lparen vecstart)
         (let ((ast1 (parse-compound-datum)))
           (identity ast1)))
        ((boolean number character string id)
         (let ((ast1 (parse-simple-datum)))
           (identity ast1)))
        (else
         (parse-error
          parsing-symbol-<datum>-value
          parsing-literal-1))))

    (define (parse-simple-datum)
      (parsing-case (next-token)
        ((id)
         (let ((ast1 (parse-symbol))) (identity ast1)))
        ((string) (begin (consume-token!) (makeString)))
        ((character) (begin (consume-token!) (makeChar)))
        ((number) (begin (consume-token!) (makeNum)))
        ((boolean) (begin (consume-token!) (makeBool)))
        (else
         (parse-error
          parsing-symbol-<simple-datum>-value
          parsing-literal-15))))

    (define (parse-symbol)
      (parsing-case (next-token)
        ((id) (begin (consume-token!) (makeSym)))
        (else (parse-error parsing-symbol-<symbol>-value parsing-literal-3))))

    (define (parse-compound-datum)
      (parsing-case (next-token)
        ((vecstart)
         (let ((ast1 (parse-vector))) (identity ast1)))
        ((lparen quote backquote comma splicing)
         (let ((ast1 (parse-list))) (identity ast1)))
        (else
         (parse-error
          parsing-symbol-<compound-datum>-value
          parsing-literal-4))))

    (define (parse-list)
      (parsing-case (next-token)
        ((splicing comma backquote quote)
         (let ((ast1 (parse-abbreviation)))
           (identity ast1)))
        ((lparen)
         (begin
           (consume-token!)
           (let ((ast1 (parse-list2))) (identity ast1))))
        (else
         (parse-error
          parsing-symbol-<list>-value
          parsing-literal-5))))

    (define (parse-list2)
      (parsing-case (next-token)
        ((id string
             character
             number
             boolean
             vecstart
             lparen
             quote
             backquote
             comma
             splicing)
         (let ((ast1 (parse-datum)))
           (let ((ast2 (parse-list3))) (datum-cons ast1 ast2))))
        ((rparen) (begin (consume-token!) (emptyList)))
        (else
         (parse-error
          parsing-symbol-<list2>-value
          parsing-literal-6))))

    (define (parse-list3)
      (parsing-case (next-token)
        ((rparen
          period
          splicing
          comma
          backquote
          quote
          lparen
          vecstart
          boolean
          number
          character
          string
          id)
         (let ((ast1 (parse-data)))
           (let ((ast2 (parse-list4)))
             (pseudoAppend ast1 ast2))))
        (else
         (parse-error
          parsing-symbol-<list3>-value
          parsing-literal-14))))

    (define (parse-list4)
      (parsing-case (next-token)
        ((period)
         (begin
           (consume-token!)
           (let ((ast1 (parse-datum)))
             (if (typed-symbol=? (next-token) parsing-symbol-rparen-value)
                 (begin (consume-token!) (identity ast1))
                 (parse-error parsing-symbol-<list4>-value parsing-literal-12)))))
        ((rparen) (begin (consume-token!) (emptyList)))
        (else (parse-error parsing-symbol-<list4>-value parsing-literal-9))))

    (define (parse-abbreviation)
      (parsing-case (next-token)
        ((quote backquote comma splicing)
         (let ((ast1 (parse-abbrev-prefix)))
           (let ((ast2 (parse-datum))) (datum-list ast1 ast2))))
        (else
         (parse-error
          parsing-symbol-<abbreviation>-value
          parsing-literal-11))))

    (define (parse-abbrev-prefix)
      (parsing-case (next-token)
        ((splicing)
         (begin (consume-token!) (symSplicing)))
        ((comma) (begin (consume-token!) (symUnquote)))
        ((backquote)
         (begin (consume-token!) (symBackquote)))
        ((quote) (begin (consume-token!) (symQuote)))
        (else
         (parse-error
          parsing-symbol-<abbrev-prefix>-value
          parsing-literal-11))))

    (define (parse-vector)
      (parsing-case (next-token)
        ((vecstart)
         (begin
           (consume-token!)
           (let ((ast1 (parse-data)))
             (if (typed-symbol=? (next-token) parsing-symbol-rparen-value)
                 (begin (consume-token!) (list2vector ast1))
                 (parse-error parsing-symbol-<vector>-value parsing-literal-12)))))
        (else (parse-error parsing-symbol-<vector>-value parsing-literal-13))))

    (define (parse-data)
      (parsing-case (next-token)
        ((id string
             character
             number
             boolean
             vecstart
             lparen
             quote
             backquote
             comma
             splicing)
         (let ((ast1 (parse-datum)))
           (let ((ast2 (parse-data))) (datum-cons ast1 ast2))))
        ((rparen period) (emptyList))
        (else
         (parse-error
          parsing-symbol-<data>-value
          parsing-literal-14))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; End of LL(1) parser generated by ParseGen.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Help predicates used by the lexical analyzer's state machine.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (isnotdoublequote? c) (not (char=? c #\")))
    (define (isnotnewline? c) (not (char=? c #\newline)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Lexical analyzer.
    ;;
    ;; This code is adapted from the quirk23 lexical analyzer written
    ;; by Will Clinger for a compiler course.
    ;;
    ;; The scanner and parser were generated automatically and then
    ;; printed using an R5RS Scheme pretty-printer, so they do not
    ;; preserve case.  In preparation for the case-sensitivity of
    ;; R6RS Scheme, several identifiers and constants have been
    ;; lower-cased in the hand-written code to match the generated
    ;; code.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; next-token and consume-token! are called by the parser.

    ;; Returns the current token.

    (define (next-token)
      (if (ref-get nextTokenIsReady)
          (ref-get kindOfNextToken)
          (begin (ref-set! string_accumulator_length 0)
                 (scanner0))))

    ;; Consumes the current token.

    (define (consume-token!)
      (ref-set! nextTokenIsReady #f))

    ;; Called by the lexical analyzer's state machine,
    ;; hence the unfortunate lower case.

    (define (scannererror msg)
      (define msgtxt
        (parsing-cond ((= msg errLongToken)
               "Amazingly long token")
              ((= msg errincompletetoken)
               "in line ")
              ((= msg errLexGenBug)
               "Bug in lexical analyzer (generated)")
              (else "Bug in lexical analyzer")))
      (datum-fail (string-append "Lexical Error: " msgtxt " " (i64->string (ref-get lineNumber))))
      (ref-set! nextTokenIsReady #f)
      (ref-set! nextCharacterIsReady #f)
      (next-token))

    ;; Accepts a token of the given kind, returning that kind.
    ;;
    ;; For some kinds of tokens, a value for the token must also be
    ;; recorded in tokenValue.

    (define (accept t)
      (when (parsing-member? t parsing-literal-15)
        (ref-set! tokenValue
              (substring string_accumulator 0 (ref-get string_accumulator_length))))
      (ref-set! kindOfNextToken t)
      (ref-set! nextTokenIsReady #t)
      t)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Character i/o, so to speak.
    ;; Uses the input-string as input.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; Returns the current character from the input.

    (define (scanchar)
      (if (ref-get nextCharacterIsReady)
          (ref-get nextCharacter)
          (begin (if (< (ref-get input-index) input-length)
                     (begin (ref-set! nextCharacter
                                  (string-ref input-string (ref-get input-index)))
                            (ref-set! input-index (+ (ref-get input-index) 1)))
                     (ref-set! nextCharacter eof))
                 (ref-set! nextCharacterIsReady #t)
                 ;; For debugging, change #f to #t below.
                 (when #f
                   (parsing-write-character (ref-get nextCharacter)))
                 (scanchar))))

    ;; Consumes the current character, and returns the next.

    (define (consumechar)
      (unless (ref-get nextCharacterIsReady)
        (scanchar))
      (if (< (ref-get string_accumulator_length) max_token_size)
          (begin (ref-set! nextCharacterIsReady #f)
                 (when (char=? (ref-get nextCharacter) #\newline)
                   (ref-set! lineNumber (+ (ref-get lineNumber) 1)))
                 (string-set! string_accumulator
                              (ref-get string_accumulator_length)
                              (ref-get nextCharacter))
                 (ref-set! string_accumulator_length
                       (+ (ref-get string_accumulator_length) 1)))
          (begin (scannererror errLongToken) (unit))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Action procedures called by the parser.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (emptyList) (datum-null))

    (define (identity x) x)

    (define (list2vector vals) (parsing-vector vals))

    (define (makeBool)
      (datum-boolean (string=? (ref-get tokenValue) "#t")))

    (define (makeChar)
      (datum-character (string-ref (ref-get tokenValue) 0)))

    (define (makeNum)
      (parsing-number (ref-get tokenValue)))

    (define (makeString)
      ;; Must strip off outer double quotes.
      ;; Ought to process escape characters also, but we won't.
      (datum-string (substring (ref-get tokenValue) 1 (- (string-length (ref-get tokenValue)) 1))))

    (define (makeSym)
      (datum-symbol (typed-string->symbol (ref-get tokenValue))))

    ;; Like append, but allows the last argument to be a non-list.

    (define (pseudoAppend vals terminus)
      (if (datum-null? vals)
          terminus
          (datum-cons (datum-car vals)
                (pseudoAppend (datum-cdr vals) terminus))))

    (define (symBackquote) (datum-symbol parsing-symbol-quasiquote-value))
    (define (symQuote) (datum-symbol parsing-symbol-quote-value))
    (define (symSplicing) (datum-symbol parsing-symbol-unquote-splicing-value))
    (define (symUnquote) (datum-symbol parsing-symbol-unquote-value))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Error procedure called by the parser.
    ;; As a hack, this error procedure recovers from end-of-file.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (parse-error nonterminal expected-terminals)
      (if (typed-symbol=? parsing-symbol-eof-value (next-token))
          (datum-symbol parsing-symbol-eof-value)
          (begin
            (parsing-display-string "Syntax error in line ")
            (parsing-display-string (i64->string (ref-get lineNumber)))
            (parsing-display-string " while parsing a ")
            (parsing-display-symbol nonterminal)
            (parsing-newline)
            (parsing-display-string "  Encountered a ")
            (parsing-display-symbol (next-token))
            (parsing-display-string " while expecting something in")
            (parsing-newline)
            (parsing-display-string "  ")
            (parsing-display-symbols expected-terminals)
            (parsing-newline)
            (datum-fail "Syntax error"))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;;
    ;; Parses repeatedly, returning the last <datum> parsed.
    ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (parsing-do ((x (parse-datum) (parse-datum))
         (y (datum-symbol parsing-symbol-eof-value) x))
        ((datum-eq? x (datum-symbol parsing-symbol-eof-value))
         y))))

(define (run-benchmark)
  (let* ((count (read))
         (input1 (read))
         (output (read-value! (workload-read (current-input-port))))
         (s2 (number->string count))
         (s1 input1)
         (name "parsing"))
    (run-r7rs-benchmark
     (string-append name ":" s2)
     1
     (lambda () (parsing-benchmark (parsing-integer (hide count count)) (datum-string (hide count input1))))
     (lambda (result) (datum=? result output)))))
(define (this-scheme-implementation-name) "chez")

;;; The following code is appended to all benchmarks.

;;; Given an integer and an object, returns the object
;;; without making it too easy for compilers to tell
;;; the object will be returned.

(define (hide r x)
  (call-with-values
   (lambda ()
     (values (vector values (lambda (x) x))
             (if (< r 100) 0 1)))
   (lambda (v i)
     ((vector-ref v i) x))))

;;; Given the name of a benchmark,
;;; the number of times it should be executed,
;;; a thunk that runs the benchmark once,
;;; and a unary predicate that is true of the
;;; correct results the thunk may return,
;;; runs the benchmark for the number of specified iterations.

(define (run-r7rs-benchmark name count thunk ok?)

  ;; Rounds to thousandths.
  (define (rounded x)
    (/ (round (* 1000 x)) 1000))

  (display "Running ")
  (display name)
  (newline)
  (flush-output-port (current-output-port))
  (let* ((j/s (jiffies-per-second))
         (t0 (current-second))
         (j0 (current-jiffy)))
    (let loop ((i 0)
               (result #f))
      (cond ((< i count)
             (loop (+ i 1) (thunk)))
            ((ok? result)
             (let* ((t1 (current-second))
                    (j1 (current-jiffy))
                    (jifs (- j1 j0))
                    (secs (inexact (/ jifs j/s)))
                    (secs2 (rounded (- t1 t0))))
               (display "Elapsed time: ")
               (write secs)
               (display " seconds (")
               (write secs2)
               (display ") for ")
               (display name)
               (newline)
               (display "+!CSVLINE!+")
               (display (this-scheme-implementation-name))
               (display ",")
               (display name)
               (display ",")
               (display secs)
               (newline)
               (flush-output-port (current-output-port)))
             0)
            (else
             (display "ERROR: returned incorrect result: ")
             (write result)
             (newline)
             (display "+!CSVLINE!+")
             (display (this-scheme-implementation-name))
             (display ",")
             (display name)
             (display ",")
             (display "INCORRECT")
             (newline)
             (flush-output-port (current-output-port))
             0)))))

(run-benchmark)
