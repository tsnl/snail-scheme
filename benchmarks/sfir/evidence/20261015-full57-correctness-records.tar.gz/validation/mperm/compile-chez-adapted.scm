(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-checked-full57-20261015-v1/source/benchmarks/sfir/mperm/chez-adapted.scm" "/tmp/sfir-checked-full57-20261015-v1/validation/mperm/chez-adapted.so"))
