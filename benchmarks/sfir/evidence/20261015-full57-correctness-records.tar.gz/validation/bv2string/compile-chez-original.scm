(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-checked-full57-20261015-v1/source/benchmarks/sfir/bv2string/chez-original.scm" "/tmp/sfir-checked-full57-20261015-v1/validation/bv2string/chez-original.so"))
