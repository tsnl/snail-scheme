(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-checked-full57-20261015-v1/source/benchmarks/sfir/fibc/chez-original.scm" "/tmp/sfir-checked-full57-20261015-v1/validation/fibc/chez-original.so"))
