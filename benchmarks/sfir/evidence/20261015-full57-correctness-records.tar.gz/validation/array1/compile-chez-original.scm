(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-checked-full57-20261015-v1/source/benchmarks/sfir/array1/chez-original.scm" "/tmp/sfir-checked-full57-20261015-v1/validation/array1/chez-original.so"))
