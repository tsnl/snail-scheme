Terminal first-phase correctness evidence; no performance result.

Original campaign-relative paths retain exact bytes. The campaign was read only.
The full preparation manifest is a capture and may later gain timing_plan_sha256.
Source, artifact and original validation identities are independently retained.
Historical status fields inside corpus/manifest cases are not live route outcomes.
Use validation.json and the corresponding validation/<case>/status.json instead.

Included: 797 terminal validation command records and raw stdout/stderr, 11
tool/preparation records and captures, 57 status/spec/native-parity/native-build
records and build configurations, provider/output checks, selected static SFIR
and original/adapted Chez and Rust source, source-fidelity metadata, predicates,
canonical data and frozen runner/timing helpers. No recorded command was rerun.
Validation clocks remain original bytes and are not clean timing samples.

Omitted: executable/provider binaries, Wasm/WAT, LLVM IR, Rust sysroot and vendored
crates, generated workload output trees, and all still-pending clean timing work.
Their existing hashes remain in manifest/parity/build/provider/artifact records.
Tool/sysroot and large artifact hashes were not recomputed for this capture.
All 647 frozen source files and 64 frozen data files were rehashed; each case's
source/input/control provenance was checked with the existing runner helpers.
All raw output bytes match their command-record hashes and decoded diagnostics.
All native parity hashes agree with the existing native build manifests; this
report rechecks metadata, not large binary/LLVM contents or target execution.

To inspect, extract into a fresh directory. To check all indexed bytes without
extracting or executing any campaign command, run:
    python3 audit/verify.py /path/to/20261015-full57-correctness-records.tar.gz
The report JSON provides the archive's outer SHA-256. Every other member is
listed in index.json. Recorded argv retain their original absolute paths.
