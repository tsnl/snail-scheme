#!/usr/bin/env python3
"""Verify indexed bytes only; never execute a retained campaign command."""
import hashlib
import json
from pathlib import PurePosixPath
import sys
import tarfile

with tarfile.open(sys.argv[1], 'r:gz') as archive:
    entries = archive.getmembers()
    names = [entry.name for entry in entries]
    assert len(names) == len(set(names)), 'duplicate archive member'
    assert all(entry.isfile() and not PurePosixPath(entry.name).is_absolute()
               and '..' not in PurePosixPath(entry.name).parts for entry in entries)
    index = json.load(archive.extractfile('index.json'))
    assert set(names) == {'index.json', *index['members']}, 'unindexed member'
    for name, expected in index['members'].items():
        data = archive.extractfile(name).read()
        assert len(data) == expected['bytes'], name
        assert hashlib.sha256(data).hexdigest() == expected['sha256'], name
    print(f"PASS: {len(index['members'])} indexed members; no workloads executed")
