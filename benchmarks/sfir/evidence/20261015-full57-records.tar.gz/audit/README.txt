Final full57 and separately corrected Mperm evidence; original bytes retained.
primary/ compiler is 8e547bfb, 326 ready routes and 1956 successful attempts.
mperm-correction/ compiler is 5cd5b6b4, six routes and 36 successful attempts.
The primary Mperm Chez timer-name rejections and both Ack Wasm failures remain
in the primary plan. Corrected Mperm statistics are never merged into its table
or aggregates. Terminal measurement.json controls timing status; manifest/corpus
historical status fields remain verbatim. Manifest hashes may differ from earlier
captures because preparation added timing_plan_sha256; independent identities
of sources/artifacts/original validation remain authoritative.

Every original measurement and clean-validation command record, raw stdout and
stderr is retained, along with native build/parity/configuration records, output
checks, final manifests/plans, machine/tool records, predicate sources and outer
terminal command records. Initial correctness records are separately retained in
20261015-full57-correctness-records.tar.gz (SHA-256 in the final report JSON).
Generated output trees, binaries, LLVM IR and toolchain/vendor copies are omitted;
their identities remain in manifests and native build/parity/provider records.

Archive preparation rehashed source/data, stream and optimized-guest bytes and
cross-checked saved output/parity metadata; it did not rerun workloads or all
toolchain/large-artifact hashes. Original final verification belongs to the
completed frozen driver. Validation/build process clocks are not clean samples.
index.json hashes and sizes every other member. Archive outer SHA-256 is in the
report JSON. Inspect records without executing their absolute-path command argv.
