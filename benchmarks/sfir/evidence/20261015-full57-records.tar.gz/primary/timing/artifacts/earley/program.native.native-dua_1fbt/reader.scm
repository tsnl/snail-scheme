(module
 (rec
  (type $type51 (sub (struct)))
  (type $type124 (sub (struct)))
  (type $type61 (sub (struct)))
  (type $type82 (sub (struct)))
  (type $type67 (sub (struct)))
  (type $type57 (sub (struct)))
  (type $type13 (sub (struct)))
  (type $7 (func (param (ref $type23) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
  (type $type283 (struct (field (ref $environment354))))
  (type $type285 (struct (field (mut i32)) (field (mut (ref null $type283)))))
  (type $environment354 (struct (field i64) (field (ref $type285))))
  (type $call283 (func (param (ref $environment354) i64 (ref $type57)) (result i64)))
  (type $call280 (func (param (ref $environment351) (ref null $type49) i64) (result i64)))
  (type $13 (func (param (ref $type109) (ref null $type12)) (result (ref null $type107))))
  (type $call109 (func (param (ref $type13)) (result (ref $type106))))
  (type $type280 (struct (field (ref $environment351))))
  (type $environment347 (struct (field (ref $type163))))
  (type $environment85 (struct (field (ref $type156))))
  (type $type282 (struct (field (mut i32)) (field (mut (ref null $type280)))))
  (type $environment351 (struct (field (ref $type282))))
  (type $20 (func (param (ref null $type12)) (result i64)))
  (type $environment298 (struct (field (ref $type243))))
  (type $environment296 (struct (field (ref $type243))))
  (type $environment292 (struct (field (ref $type246))))
  (type $call98 (func (param structref (ref null $type50) (ref null $type50)) (result (ref null $type50))))
  (type $environment290 (struct (field (ref $type246))))
  (type $type246 (struct (field (mut i32)) (field (mut (ref null $type98)))))
  (type $environment286 (struct (field (ref $type243)) (field (ref null $type49)) (field (ref $type50)) (field (ref $type243))))
  (type $type55 (sub $type51 (struct)))
  (type $call99 (func (param structref (ref null $type49) (ref null $type49)) (result (ref null $type49))))
  (type $environment282 (struct (field (ref $type61)) (field (ref $type241)) (field i64) (field (ref null $type49)) (field (ref $type243))))
  (type $type243 (struct (field (mut i32)) (field (mut (ref null $type99)))))
  (type $call239 (func (param (ref $environment279) i64 (ref null $type49)) (result (ref null $type49))))
  (type $type239 (struct (field (ref $environment279))))
  (type $environment279 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field i64) (field i64) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field (ref $type28)) (field (ref $type81)) (field i64) (field i64) (field (ref $type236)) (field (ref null $type27)) (field i64) (field (ref $type61)) (field (ref $type241))))
  (type $type241 (struct (field (mut i32)) (field (mut (ref null $type239)))))
  (type $call234 (func (param (ref $environment274) (ref null $type27) (ref null $type49)) (result (ref null $type49))))
  (type $type234 (struct (field (ref $environment274))))
  (type $environment274 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field i64) (field i64) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field (ref $type28)) (field (ref $type81)) (field i64) (field i64) (field (ref $type236))))
  (type $type50 (struct (field (ref $type51)) (field (ref null $type50))))
  (type $type54 (sub $type51 (struct)))
  (type $type52 (sub $type51 (struct)))
  (type $type236 (struct (field (mut i32)) (field (mut (ref null $type234)))))
  (type $43 (func (param (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) i64 i64 i64 (ref $type119) (ref $type120) (ref $type121) (ref $type28) (ref $type81) i64) (result (ref null $type49))))
  (type $type229 (struct (field (ref $environment265))))
  (type $environment265 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field i64) (field i64) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field (ref $type28)) (field (ref $type81)) (field i64) (field (ref $type231)) (field (ref $type134))))
  (type $type126 (sub $type124 (struct (field (ref null $type49)))))
  (type $type49 (struct (field (ref null $type50)) (field (ref null $type49))))
  (type $type231 (struct (field (mut i32)) (field (mut (ref null $type229)))))
  (type $call229 (func (param (ref $environment265) (ref null $type27) (ref null $type49)) (result (ref $type124))))
  (type $environment260 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field i64) (field i64) (field (ref $type81)) (field (ref $type81)) (field i64) (field (ref $type208)) (field (ref null $type27)) (field i64) (field (ref $type61)) (field (ref $type175))))
  (type $environment255 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field i64) (field i64) (field (ref $type81)) (field (ref $type81)) (field i64) (field (ref $type208))))
  (type $environment251 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field (ref $type81)) (field i64) (field (ref $type119)) (field (ref $type120)) (field i64) (field (ref $type226)) (field i64) (field (ref $type64)) (field (ref $type175))))
  (type $environment245 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field (ref $type81)) (field i64) (field (ref $type119)) (field (ref $type120)) (field i64) (field (ref $type76)) (field (ref $type226)) (field (ref $type134))))
  (type $environment213 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field (ref $type76)) (field i64) (field (ref $type64)) (field (ref $type208)) (field (ref null $type27)) (field i64) (field (ref $type175))))
  (type $environment210 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field (ref $type76)) (field i64) (field (ref $type64)) (field i64) (field (ref $type208))))
  (type $environment203 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type76)) (field i64) (field (ref $type64)) (field i64) (field (ref $type208))))
  (type $environment198 (struct (field (ref $type134)) (field (ref $type76)) (field i64) (field (ref $type208))))
  (type $call10 (func (param (ref struct)) (result i32)))
  (type $environment220 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field i64) (field (ref $type119)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field (ref $type76)) (field i64) (field (ref $type226))))
  (type $type10 (struct (field (ref $call10)) (field (ref struct))))
  (type $type226 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $62 (func (param (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type81) i64 (ref $type119) (ref $type119) (ref $type119) (ref $type120) (ref $type23)) (result i32)))
  (type $63 (func (param (ref null $type28) i32 i32 i32 (ref null $type25) i64) (result (ref $type28))))
  (type $64 (func (param i32 i32 (ref null $type25) i64) (result i64)))
  (type $65 (func (param (ref $environment182) (ref $type26)) (result (ref $type25))))
  (type $environment165 (struct (field (ref $type76)) (field (ref $type64)) (field i64) (field (ref $type64)) (field (ref $type175))))
  (type $67 (func (param (ref $type134) (ref $type134) (ref $type76) (ref $type64) i64 (ref $type64)) (result i32)))
  (type $68 (func (param (ref $type81) (ref $type81) i64 i64 i64) (result i32)))
  (type $environment153 (struct (field (ref $type134)) (field i64) (field i64) (field (ref $type76)) (field (ref $type208))))
  (type $70 (func (param (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type81) i64 (ref null $type27) i64) (result i32)))
  (type $71 (func (param (ref $type76) (ref $type64) i64 i64)))
  (type $72 (func (param (ref $type76) i64 i64) (result (ref $type57))))
  (type $73 (func (param (ref $type64))))
  (type $type63 (sub $type61 (struct (field (ref $type64)))))
  (type $type64 (struct (field (ref $type65))))
  (type $type65 (array (mut (ref $type57))))
  (type $77 (func (param (ref $type76) i64 i64) (result (ref $type64))))
  (type $type84 (sub $type82 (struct (field (ref $type76)))))
  (type $type78 (array (mut (ref $type61))))
  (type $type77 (struct (field (mut i64))))
  (type $type76 (struct (field (ref $type77)) (field (ref $type78))))
  (type $call198 (func (param (ref $environment135) i64) (result (ref $type81))))
  (type $type198 (struct (field (ref $environment135))))
  (type $environment135 (struct (field i64) (field (ref $type81)) (field (ref $type200))))
  (type $type200 (struct (field (mut i32)) (field (mut (ref null $type198)))))
  (type $86 (func (param i64 i64) (result (ref $type81))))
  (type $call194 (func (param (ref $environment131) (ref null $type27) (ref $type27)) (result (ref null $type27))))
  (type $type194 (struct (field (ref $environment131))))
  (type $type196 (struct (field (mut i32)) (field (mut (ref null $type194)))))
  (type $environment131 (struct (field (ref $type196))))
  (type $call101 (func (param (ref null $type27)) (result (ref null $type27))))
  (type $92 (func (param (ref $environment127) (ref $type57)) (result (ref $type26))))
  (type $environment127 (struct (field (ref $type192)) (field (ref null $type12)) (field (ref null $type27))))
  (type $type190 (struct (field (ref $environment126))))
  (type $environment126 (struct (field (ref $type23)) (field (ref $type192))))
  (type $type192 (struct (field (mut i32)) (field (mut (ref null $type190)))))
  (type $97 (func (param (ref $type134) (ref $type106) (ref $type23)) (result (ref $type26))))
  (type $environment123 (struct (field (ref $type13)) (field (ref $type23)) (field (ref $type153))))
  (type $type118 (struct (field (ref $type23)) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field (ref $type28)) (field (ref $type81)) (field (ref $type123))))
  (type $environment241 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field (ref $type119)) (field (ref $type120)) (field (ref $type28)) (field i64) (field (ref $type81)) (field (ref $type175)) (field (ref $type134))))
  (type $call206 (func (param (ref struct) (ref null $type27)) (result i32)))
  (type $environment238 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type81)) (field i64) (field (ref $type81)) (field (ref $type208))))
  (type $environment228 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type119)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field (ref $type23)) (field (ref $type28)) (field i64) (field (ref $type81)) (field (ref $type175))))
  (type $environment182 (struct (field (ref $type105)) (field (ref null $type107))))
  (type $environment261 (struct (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134)) (field (ref $type134))))
  (type $environment120 (struct (field (ref $type169))))
  (type $type206 (struct (field (ref $call206)) (field (ref struct))))
  (type $type123 (struct (field (ref $environment261))))
  (type $type109 (struct))
  (type $type106 (struct (field (ref $type12))))
  (type $type208 (struct (field (mut i32)) (field (mut (ref null $type206)))))
  (type $type81 (array (mut (ref $type82))))
  (type $type28 (array (mut (ref $type26))))
  (type $type169 (struct (field (ref $type23)) (field (ref $type119)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field (ref $type121))))
  (type $type105 (struct (field (ref $environment180))))
  (type $type25 (struct (field (ref $type26)) (field (ref null $type25))))
  (type $type26 (struct (field (ref null $type27))))
  (type $environment180 (struct (field (ref $type134)) (field (ref $type23))))
  (type $type107 (struct (field (ref $type106)) (field (ref null $type107))))
  (type $call117 (func (param (ref $environment120) (ref null $type12)) (result (ref $type118))))
  (type $call183 (func (param (ref $environment117) (ref null $type12) i64) (result i32)))
  (type $type183 (struct (field (ref $environment117))))
  (type $environment117 (struct (field (ref $type23)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field i64) (field (ref $type14)) (field (ref $type181)) (field (ref null $type91)) (field i64) (field (ref $type185))))
  (type $type172 (struct (field (ref $environment107))))
  (type $type176 (struct (field (mut i32)) (field (mut (ref null $type172)))))
  (type $type134 (struct))
  (type $type185 (struct (field (mut i32)) (field (mut (ref null $type183)))))
  (type $call179 (func (param (ref $environment112) (ref null $type91) i64 i64) (result i32)))
  (type $type179 (struct (field (ref $environment112))))
  (type $environment112 (struct (field (ref $type134)) (field (ref $type23)) (field (ref $type119)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field i64) (field (ref $type176)) (field (ref null $type93)) (field (ref $type181)) (field (ref $type134))))
  (type $environment107 (struct (field (ref $type134)) (field (ref $type23)) (field (ref $type119)) (field (ref $type119)) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field i64) (field (ref $type176)) (field (ref $type134))))
  (type $type181 (struct (field (mut i32)) (field (mut (ref null $type179)))))
  (type $133 (func (param (ref $environment107) (ref null $type93) i64) (result i32)))
  (type $type171 (struct (field (ref $call171)) (field (ref struct))))
  (type $type175 (struct (field (mut i32)) (field (mut (ref null $type171)))))
  (type $type119 (array (mut (ref null $type27))))
  (type $type27 (struct (field i64) (field (ref null $type27))))
  (type $type121 (array (mut (ref $type67))))
  (type $type69 (sub $type67 (struct)))
  (type $type120 (array (mut i64)))
  (type $environment104 (struct (field (ref $type23)) (field (ref $type119)) (field (ref $type120)) (field (ref $type121)) (field i64) (field (ref $type175))))
  (type $call171 (func (param (ref struct) i64) (result i32)))
  (type $type154 (struct (field (ref $environment85))))
  (type $type156 (struct (field (mut i32)) (field (mut (ref null $type154)))))
  (type $type158 (struct (field (ref $environment88))))
  (type $type160 (struct (field (mut i32)) (field (mut (ref null $type158)))))
  (type $environment91 (struct (field (ref $type160)) (field (ref null $type91)) (field (ref $type163))))
  (type $type161 (struct (field (ref $call161)) (field (ref struct))))
  (type $type163 (struct (field (mut i32)) (field (mut (ref null $type161)))))
  (type $environment88 (struct (field (ref $type156)) (field (ref null $type93)) (field (ref $type160))))
  (type $call161 (func (param (ref struct) (ref null $type12) i64) (result i64)))
  (type $type151 (struct (field (ref $call151)) (field (ref struct))))
  (type $type153 (struct (field (mut i32)) (field (mut (ref null $type151)))))
  (type $type59 (sub $type57 (struct (field i64))))
  (type $environment82 (struct (field (ref $type13)) (field (ref $type23)) (field (ref $type153))))
  (type $call151 (func (param (ref struct) i64) (result (ref $type57))))
  (type $157 (func (param (ref null $type23) i32 i32 i32 (ref null $type12) i64) (result (ref $type23))))
  (type $158 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $call148 (func (param (ref $environment75) (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call145 (func (param (ref $environment70) (ref null $type12) (ref null $type12)) (result (ref $type23))))
  (type $type145 (struct (field (ref $environment70))))
  (type $environment70 (struct (field (ref $type144)) (field (ref null $type91)) (field (ref $type147))))
  (type $type91 (struct (field (ref $type12)) (field (ref null $type91))))
  (type $type136 (struct (field (ref $environment60))))
  (type $type138 (struct (field (mut i32)) (field (mut (ref null $type136)))))
  (type $type147 (struct (field (mut i32)) (field (mut (ref null $type145)))))
  (type $call142 (func (param (ref $environment66) (ref null $type91) (ref null $type12)) (result (ref $type23))))
  (type $type142 (struct (field (ref $environment66))))
  (type $environment66 (struct (field (ref $type134)) (field (ref $type138)) (field (ref null $type93)) (field (ref $type144))))
  (type $environment60 (struct (field (ref $type134)) (field (ref $type138))))
  (type $type23 (array (mut (ref $type13))))
  (type $type148 (struct (field (ref $environment75))))
  (type $type94 (struct (field (ref $type91))))
  (type $type144 (struct (field (mut i32)) (field (mut (ref null $type142)))))
  (type $type150 (struct (field (mut i32)) (field (mut (ref null $type148)))))
  (type $environment75 (struct (field (ref $type150))))
  (type $177 (func (param (ref $environment60) (ref null $type93) (ref null $type12)) (result (ref $type23))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $call88 (func (param (ref $type13) (ref null $type12)) (result i32)))
  (type $type132 (struct))
  (type $type131 (struct))
  (type $type129 (struct))
  (type $type115 (struct))
  (type $type114 (struct))
  (type $type113 (struct))
  (type $type112 (struct))
  (type $type111 (struct))
  (type $type110 (struct))
  (type $type93 (struct (field (ref $type94))))
  (type $type108 (struct))
  (type $type104 (struct))
  (type $type103 (struct))
  (type $type102 (struct))
  (type $type101 (struct))
  (type $type100 (struct))
  (type $type99 (struct (field (ref $call99)) (field structref)))
  (type $type98 (struct (field (ref $call98)) (field structref)))
  (type $type97 (struct))
  (type $type96 (struct))
  (type $type95 (struct))
  (type $type92 (struct))
  (type $type90 (struct))
  (type $type89 (struct))
  (type $type88 (struct))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type80 (struct))
  (type $type79 (struct))
  (type $type75 (struct))
  (type $type74 (struct))
  (type $type73 (struct))
  (type $type72 (struct))
  (type $type71 (struct))
  (type $type66 (struct))
  (type $type60 (struct))
  (type $type56 (struct))
  (type $type48 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type24 (struct))
  (type $type11 (struct))
  (type $type125 (sub $type124 (struct)))
  (type $type83 (sub $type82 (struct)))
  (type $type68 (sub $type67 (struct)))
  (type $type62 (sub $type61 (struct)))
  (type $type58 (sub $type57 (struct)))
  (type $type15 (sub $type13 (struct)))
  (type $type14 (sub $type13 (struct)))
 )
 (type $231 (func (result i32)))
 (type $232 (func (param i32) (result i64)))
 (type $233 (func (param (ref $type106) (ref $type23)) (result (ref $type26))))
 (type $234 (func (param (ref $type134) (ref $type81) i64 (ref null $type27) i64) (result i32)))
 (type $235 (func (param (ref $type76) (ref $type64) i64 (ref $type64)) (result i32)))
 (type $236 (func (param (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type134) (ref $type81) i64 (ref $type119) (ref $type119) (ref $type119) (ref $type120) (ref $type23)) (result i32)))
 (type $237 (func (param i64) (result i64)))
 (type $238 (func))
 (import "benchmark" "barrier" (func $foreign0 (result i32)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty14 (ref $type14) (struct.new_default $type14))
 (global $empty15 (ref $type15) (struct.new_default $type15))
 (global $empty58 (ref $type58) (struct.new_default $type58))
 (global $empty62 (ref $type62) (struct.new_default $type62))
 (global $empty68 (ref $type68) (struct.new_default $type68))
 (global $empty83 (ref $type83) (struct.new_default $type83))
 (global $empty125 (ref $type125) (struct.new_default $type125))
 (global $global183 (mut (ref null $type11)) (ref.null none))
 (global $global373 (mut (ref null $type24)) (ref.null none))
 (global $global186 (mut (ref null $type31)) (ref.null none))
 (global $ready186 (mut i32) (i32.const 0))
 (global $global376 (mut (ref null $type32)) (ref.null none))
 (global $ready376 (mut i32) (i32.const 0))
 (global $global669 (mut (ref null $type33)) (ref.null none))
 (global $global649 (mut (ref null $type31)) (ref.null none))
 (global $global656 (mut (ref null $type48)) (ref.null none))
 (global $global267 (mut (ref null $type56)) (ref.null none))
 (global $global291 (mut (ref null $type60)) (ref.null none))
 (global $global522 (mut (ref null $type66)) (ref.null none))
 (global $global112 (mut (ref null $type71)) (ref.null none))
 (global $global115 (mut (ref null $type72)) (ref.null none))
 (global $global118 (mut (ref null $type73)) (ref.null none))
 (global $global121 (mut (ref null $type74)) (ref.null none))
 (global $global125 (mut (ref null $type75)) (ref.null none))
 (global $global128 (mut (ref null $type79)) (ref.null none))
 (global $global319 (mut (ref null $type80)) (ref.null none))
 (global $global132 (mut (ref null $type85)) (ref.null none))
 (global $global134 (mut (ref null $type86)) (ref.null none))
 (global $global137 (mut (ref null $type87)) (ref.null none))
 (global $global140 (mut (ref null $type88)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type89)) (ref.null none))
 (global $global147 (mut (ref null $type90)) (ref.null none))
 (global $global149 (mut (ref null $type92)) (ref.null none))
 (global $global231 (mut (ref null $type95)) (ref.null none))
 (global $global526 (mut (ref null $type96)) (ref.null none))
 (global $global528 (mut (ref null $type97)) (ref.null none))
 (global $global550 (mut (ref null $type98)) (ref.null none))
 (global $global561 (mut (ref null $type99)) (ref.null none))
 (global $global178 (mut (ref null $type100)) (ref.null none))
 (global $global271 (mut (ref null $type101)) (ref.null none))
 (global $global553 (mut (ref null $type102)) (ref.null none))
 (global $ready553 (mut i32) (i32.const 0))
 (global $global564 (mut (ref null $type103)) (ref.null none))
 (global $ready564 (mut i32) (i32.const 0))
 (global $global369 (mut (ref null $type104)) (ref.null none))
 (global $ready369 (mut i32) (i32.const 0))
 (global $global644 (mut (ref null $type108)) (ref.null none))
 (global $ready644 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type93)) (ref.null none))
 (global $global162 (mut (ref null $type110)) (ref.null none))
 (global $global169 (mut (ref null $type111)) (ref.null none))
 (global $global175 (mut (ref null $type112)) (ref.null none))
 (global $global325 (mut (ref null $type113)) (ref.null none))
 (global $global544 (mut (ref null $type114)) (ref.null none))
 (global $global151 (mut (ref null $type115)) (ref.null none))
 (global $global617 (mut (ref null $type129)) (ref.null none))
 (global $global640 (mut (ref null $type31)) (ref.null none))
 (global $global661 (mut i64) (i64.const 0))
 (global $global662 (mut i64) (i64.const 0))
 (global $global663 (mut i64) (i64.const 0))
 (global $global674 (mut (ref null $type131)) (ref.null none))
 (global $global664 (mut (ref null $type132)) (ref.null none))
 (global $ready664 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function51 (type $call88) (param $0 (ref $type13)) (param $1 (ref null $type12)) (result i32)
  (local $2 (ref $type13))
  (local $3 i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (local.set $2
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if (result i32)
     (local.tee $3
      (i64.eq
       (if (result i64)
        (ref.test (ref $type14)
         (local.get $0)
        )
        (then
         (i64.const 0)
        )
        (else
         (select
          (i64.const 8)
          (i64.const 1)
          (ref.test (ref $type14)
           (local.get $0)
          )
         )
        )
       )
       (if (result i64)
        (ref.test (ref $type14)
         (local.get $2)
        )
        (then
         (i64.const 0)
        )
        (else
         (select
          (i64.const 8)
          (i64.const 1)
          (ref.test (ref $type14)
           (local.get $2)
          )
         )
        )
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready140)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global140)
       )
      )
      (return_call $function51
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function60 (type $177) (param $0 (ref $environment60)) (param $1 (ref null $type93)) (param $2 (ref null $type12)) (result (ref $type23))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $environment75))
  (local $6 (ref $type12))
  (local $7 (ref $type150))
  (local $8 (ref $type144))
  (local $9 (ref $type94))
  (local $10 (ref $type14))
  (local $11 i64)
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (if (result (ref $type23))
   (ref.is_null
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (struct.set $type150 1
     (local.tee $7
      (struct.new_default $type150)
     )
     (struct.new $type148
      (struct.new $environment75
       (local.get $7)
      )
     )
    )
    (struct.set $type150 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type150 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type148 0
      (struct.get $type150 1
       (local.get $7)
      )
     )
    )
    (local.set $2
     (if (result (ref null $type12))
      (ref.is_null
       (local.get $2)
      )
      (then
       (ref.null none)
      )
      (else
       (local.set $3
        (struct.get $type12 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (struct.get $type150 0
          (struct.get $environment75 0
           (local.get $5)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (struct.get $type148 0
         (struct.get $type150 1
          (struct.get $environment75 0
           (local.get $5)
          )
         )
        )
       )
       (local.set $6
        (struct.new $type12
         (struct.get $type12 0
          (local.get $2)
         )
         (ref.null none)
        )
       )
       (if (result (ref null $type12))
        (ref.is_null
         (local.get $3)
        )
        (then
         (local.get $6)
        )
        (else
         (local.set $2
          (struct.get $type12 1
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type150 0
            (struct.get $environment75 0
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $5
          (struct.get $type148 0
           (struct.get $type150 1
            (struct.get $environment75 0
             (local.get $5)
            )
           )
          )
         )
         (local.set $6
          (struct.new $type12
           (struct.get $type12 0
            (local.get $3)
           )
           (local.get $6)
          )
         )
         (if (result (ref null $type12))
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $3
            (struct.get $type12 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type150 0
              (struct.get $environment75 0
               (local.get $5)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type148 0
             (struct.get $type150 1
              (struct.get $environment75 0
               (local.get $5)
              )
             )
            )
           )
           (local.set $6
            (struct.new $type12
             (struct.get $type12 0
              (local.get $2)
             )
             (local.get $6)
            )
           )
           (if (result (ref null $type12))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $6)
            )
            (else
             (local.set $2
              (struct.get $type12 1
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type150 0
                (struct.get $environment75 0
                 (local.get $5)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $5
              (struct.get $type148 0
               (struct.get $type150 1
                (struct.get $environment75 0
                 (local.get $5)
                )
               )
              )
             )
             (local.set $6
              (struct.new $type12
               (struct.get $type12 0
                (local.get $3)
               )
               (local.get $6)
              )
             )
             (if (result (ref null $type12))
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type150 0
                  (struct.get $environment75 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $5
                (struct.get $type148 0
                 (struct.get $type150 1
                  (struct.get $environment75 0
                   (local.get $5)
                  )
                 )
                )
               )
               (local.set $6
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $2
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type150 0
                    (struct.get $environment75 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $5
                  (struct.get $type148 0
                   (struct.get $type150 1
                    (struct.get $environment75 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.set $6
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type150 0
                      (struct.get $environment75 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $5
                    (struct.get $type148 0
                     (struct.get $type150 1
                      (struct.get $environment75 0
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (local.set $6
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type150 0
                        (struct.get $environment75 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $5
                      (struct.get $type148 0
                       (struct.get $type150 1
                        (struct.get $environment75 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (local.set $6
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type150 0
                          (struct.get $environment75 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $5
                        (struct.get $type148 0
                         (struct.get $type150 1
                          (struct.get $environment75 0
                           (local.get $5)
                          )
                         )
                        )
                       )
                       (local.set $6
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $6)
                        )
                       )
                       (if (result (ref null $type12))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $6)
                        )
                        (else
                         (local.set $2
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type150 0
                            (struct.get $environment75 0
                             (local.get $5)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $5
                          (struct.get $type148 0
                           (struct.get $type150 1
                            (struct.get $environment75 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.set $6
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $6)
                          )
                         )
                         (if (result (ref null $type12))
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type150 0
                              (struct.get $environment75 0
                               (local.get $5)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $5
                            (struct.get $type148 0
                             (struct.get $type150 1
                              (struct.get $environment75 0
                               (local.get $5)
                              )
                             )
                            )
                           )
                           (local.set $6
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $2)
                             )
                             (local.get $6)
                            )
                           )
                           (if (result (ref null $type12))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $6)
                            )
                            (else
                             (local.set $4
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type150 0
                                (struct.get $environment75 0
                                 (local.get $5)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $5
                              (struct.get $type148 0
                               (struct.get $type150 1
                                (struct.get $environment75 0
                                 (local.get $5)
                                )
                               )
                              )
                             )
                             (local.set $6
                              (struct.new $type12
                               (struct.get $type12 0
                                (local.get $3)
                               )
                               (local.get $6)
                              )
                             )
                             (if (result (ref null $type12))
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $2
                                (struct.get $type12 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type150 0
                                  (struct.get $environment75 0
                                   (local.get $5)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $5
                                (struct.get $type148 0
                                 (struct.get $type150 1
                                  (struct.get $environment75 0
                                   (local.get $5)
                                  )
                                 )
                                )
                               )
                               (local.set $6
                                (struct.new $type12
                                 (struct.get $type12 0
                                  (local.get $4)
                                 )
                                 (local.get $6)
                                )
                               )
                               (if (result (ref null $type12))
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (local.get $6)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type150 0
                                    (struct.get $environment75 0
                                     (local.get $5)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function75
                                  (struct.get $type148 0
                                   (struct.get $type150 1
                                    (struct.get $environment75 0
                                     (local.get $5)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (struct.new $type12
                                   (struct.get $type12 0
                                    (local.get $2)
                                   )
                                   (local.get $6)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (if (result (ref $type23))
     (ref.is_null
      (local.get $2)
     )
     (then
      (array.new_fixed $type23 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready186)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global186)
       )
      )
      (if
       (i64.gt_u
        (local.tee $11
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 9)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 10)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 11)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 12)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 13)
                                    )
                                    (else
                                     (call $function78
                                      (i32.const 0)
                                      (i32.const 1)
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                      (i64.const 14)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function79
       (array.new $type23
        (struct.get $type12 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
   (else
    (local.set $9
     (struct.get $type93 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (if
     (i32.eqz
      (call $function51
       (local.tee $10
        (global.get $empty14)
       )
       (local.get $2)
      )
     )
     (then
      (local.set $2
       (struct.new $type12
        (local.get $10)
        (local.get $2)
       )
      )
     )
    )
    (struct.set $type144 1
     (local.tee $8
      (struct.new_default $type144)
     )
     (struct.new $type142
      (struct.new $environment66
       (struct.get $environment60 0
        (local.get $0)
       )
       (struct.get $environment60 1
        (local.get $0)
       )
       (local.get $1)
       (local.get $8)
      )
     )
    )
    (struct.set $type144 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type144 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (struct.get $type142 0
      (struct.get $type144 1
       (local.get $8)
      )
     )
     (struct.get $type94 0
      (local.get $9)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function66 (type $call142) (param $0 (ref $environment66)) (param $1 (ref null $type91)) (param $2 (ref null $type12)) (result (ref $type23))
  (local $3 (ref $type147))
  (local $4 (ref $type12))
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (struct.get $environment66 2
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type138 0
       (struct.get $environment66 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function60
     (struct.get $type136 0
      (struct.get $type138 1
       (struct.get $environment66 1
        (local.get $0)
       )
      )
     )
     (ref.null none)
     (local.get $2)
    )
   )
   (else
    (local.set $4
     (struct.get $type91 0
      (local.get $1)
     )
    )
    (struct.set $type147 1
     (local.tee $3
      (struct.new_default $type147)
     )
     (struct.new $type145
      (struct.new $environment70
       (struct.get $environment66 3
        (local.get $0)
       )
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type147 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type147 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type145 0
      (struct.get $type147 1
       (local.get $3)
      )
     )
     (local.get $4)
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function70 (type $call145) (param $0 (ref $environment70)) (param $1 (ref null $type12)) (param $2 (ref null $type12)) (result (ref $type23))
  (local $3 (ref null $type91))
  (local $4 (ref null $type12))
  (local $5 (ref $type13))
  (local $6 (ref $type147))
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.set $3
     (struct.get $type91 1
      (struct.get $environment70 1
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type144 0
       (struct.get $environment70 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (struct.get $type142 0
      (struct.get $type144 1
       (struct.get $environment70 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (if
     (i32.eqz
      (call $function51
       (local.tee $5
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
     (then
      (local.set $2
       (struct.new $type12
        (local.get $5)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type147 0
       (local.tee $6
        (struct.get $environment70 2
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type145 0
      (struct.get $type147 1
       (local.get $6)
      )
     )
     (local.get $4)
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function75 (type $call148) (param $0 (ref $environment75)) (param $1 (ref null $type12)) (param $2 (ref $type12)) (result (ref null $type12))
  (local $3 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (local.set $2
     (struct.new $type12
      (struct.get $type12 0
       (local.get $1)
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (struct.get $type150 0
       (struct.get $environment75 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type148 0
      (struct.get $type150 1
       (struct.get $environment75 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function78 (type $158) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function78
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function79 (type $157) (param $0 (ref null $type23)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type23))
  (local $6 i64)
  (local $7 (ref $type13))
  (if (result (ref $type23))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function82 (type $call151) (param $0 (ref struct)) (param $1 i64) (result (ref $type57))
  (local $2 (ref $environment82))
  (local $3 (ref $type13))
  (local $4 (ref $type13))
  (local $5 i64)
  (if (result (ref $type57))
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $environment82 0
      (local.tee $2
       (ref.cast (ref $environment82)
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if (result (ref $type59))
     (i64.eq
      (if (result i64)
       (ref.test (ref $type14)
        (local.tee $4
         (array.get $type23
          (struct.get $environment82 1
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (select
         (i64.const 8)
         (i64.const 1)
         (ref.test (ref $type14)
          (local.get $4)
         )
        )
       )
      )
      (if (result i64)
       (ref.test (ref $type14)
        (local.get $3)
       )
       (then
        (i64.const 0)
       )
       (else
        (select
         (i64.const 8)
         (i64.const 1)
         (ref.test (ref $type14)
          (local.get $3)
         )
        )
       )
      )
     )
     (then
      (struct.new $type59
       (local.get $1)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type153 0
         (struct.get $environment82 2
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (struct.get $type151 1
        (struct.get $type153 1
         (struct.get $environment82 2
          (local.get $2)
         )
        )
       )
       (local.get $5)
      )
     )
    )
   )
   (else
    (global.get $empty58)
   )
  )
 )
 (func $function91 (type $call161) (param $0 (ref struct)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 (ref $environment88))
  (local $5 (ref $type163))
  (local $6 (ref null $type91))
  (local $7 (ref $type12))
  (local $8 (ref $type161))
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.set $6
     (struct.get $type91 1
      (struct.get $environment91 1
       (ref.cast (ref $environment91)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type160 0
       (struct.get $environment91 0
        (ref.cast (ref $environment91)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type158 0
      (struct.get $type160 1
       (struct.get $environment91 0
        (ref.cast (ref $environment91)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global169)
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $6)
     )
     (then
      (drop
       (ref.as_non_null
        (struct.get $environment88 1
         (local.get $4)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type156 0
         (struct.get $environment88 0
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type154 0
        (struct.get $type156 1
         (struct.get $environment88 0
          (local.get $4)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (local.get $3)
     )
     (else
      (local.set $7
       (struct.get $type91 0
        (local.get $6)
       )
      )
      (struct.set $type163 1
       (local.tee $5
        (struct.new_default $type163)
       )
       (struct.new $type161
        (ref.func $function91)
        (struct.new $environment91
         (struct.get $environment88 2
          (local.get $4)
         )
         (local.get $6)
         (local.get $5)
        )
       )
      )
      (struct.set $type163 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type163 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call161
       (struct.get $type161 1
        (local.tee $8
         (ref.as_non_null
          (struct.get $type163 1
           (local.get $5)
          )
         )
        )
       )
       (local.get $7)
       (local.get $3)
       (struct.get $type161 0
        (local.get $8)
       )
      )
     )
    )
   )
   (else
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type163 0
       (struct.get $environment91 2
        (ref.cast (ref $environment91)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function91
     (struct.get $type161 1
      (struct.get $type163 1
       (struct.get $environment91 2
        (ref.cast (ref $environment91)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function104 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment104))
  (local $3 (ref $type120))
  (local $4 i64)
  (local $5 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (array.set $type120
     (struct.get $environment104 2
      (local.tee $2
       (ref.cast (ref $environment104)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.sub
            (local.get $1)
            (local.tee $4
             (struct.get $environment104 4
              (local.get $2)
             )
            )
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $5)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (array.get $type23
      (struct.get $environment104 0
       (local.get $2)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type121
     (struct.get $environment104 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (struct.new_default $type69)
    )
    (drop
     (ref.as_non_null
      (global.get $global231)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type119
     (struct.get $environment104 1
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (struct.new $type27
      (local.get $1)
      (ref.null none)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (struct.get $environment104 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function104
     (struct.get $type171 1
      (struct.get $type175 1
       (struct.get $environment104 5
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function107 (type $133) (param $0 (ref $environment107)) (param $1 (ref null $type93)) (param $2 i64) (result i32)
  (local $3 (ref $type181))
  (local $4 (ref $type94))
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (struct.get $type93 0
      (local.get $1)
     )
    )
    (struct.set $type181 1
     (local.tee $3
      (struct.new_default $type181)
     )
     (struct.new $type179
      (struct.new $environment112
       (struct.get $environment107 0
        (local.get $0)
       )
       (struct.get $environment107 1
        (local.get $0)
       )
       (struct.get $environment107 2
        (local.get $0)
       )
       (struct.get $environment107 3
        (local.get $0)
       )
       (struct.get $environment107 4
        (local.get $0)
       )
       (struct.get $environment107 5
        (local.get $0)
       )
       (struct.get $environment107 6
        (local.get $0)
       )
       (struct.get $environment107 7
        (local.get $0)
       )
       (struct.get $environment107 8
        (local.get $0)
       )
       (local.get $1)
       (local.get $3)
       (struct.get $environment107 9
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type181 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type181 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function112
     (struct.get $type179 0
      (struct.get $type181 1
       (local.get $3)
      )
     )
     (struct.get $type94 0
      (local.get $4)
     )
     (local.get $2)
     (i64.const 1)
    )
   )
  )
 )
 (func $function112 (type $call179) (param $0 (ref $environment112)) (param $1 (ref null $type91)) (param $2 i64) (param $3 i64) (result i32)
  (local $4 (ref $type153))
  (local $5 (ref $type185))
  (local $6 (ref $type23))
  (local $7 (ref $type12))
  (local $8 (ref $type14))
  (local $9 (ref $type151))
  (local $10 (ref $type57))
  (local $11 (ref $type119))
  (local $12 i64)
  (local $13 i32)
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (struct.get $environment112 9
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type176 0
       (struct.get $environment112 8
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function107
     (struct.get $type172 0
      (struct.get $type176 1
       (struct.get $environment112 8
        (local.get $0)
       )
      )
     )
     (ref.null none)
     (local.get $2)
    )
   )
   (else
    (local.set $7
     (struct.get $type91 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type121
     (struct.get $environment112 6
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (struct.new_default $type69)
    )
    (struct.set $type153 1
     (local.tee $4
      (struct.new_default $type153)
     )
     (struct.new $type151
      (ref.func $function82)
      (struct.new $environment82
       (local.tee $8
        (global.get $empty14)
       )
       (local.tee $6
        (struct.get $environment112 1
         (local.get $0)
        )
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type153 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type153 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $10
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $4)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $6)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $12
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $10)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type119
     (local.tee $11
      (struct.get $environment112 2
       (local.get $0)
      )
     )
     (local.tee $13
      (i32.wrap_i64
       (local.get $12)
      )
     )
     (struct.new $type27
      (local.get $2)
      (array.get $type119
       (local.get $11)
       (local.get $13)
      )
     )
    )
    (struct.set $type185 1
     (local.tee $5
      (struct.new_default $type185)
     )
     (struct.new $type183
      (struct.new $environment117
       (local.get $6)
       (struct.get $environment112 3
        (local.get $0)
       )
       (struct.get $environment112 4
        (local.get $0)
       )
       (struct.get $environment112 5
        (local.get $0)
       )
       (struct.get $environment112 7
        (local.get $0)
       )
       (local.get $8)
       (struct.get $environment112 10
        (local.get $0)
       )
       (local.get $1)
       (local.get $3)
       (local.get $5)
      )
     )
    )
    (struct.set $type185 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type185 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function117
     (struct.get $type183 0
      (struct.get $type185 1
       (local.get $5)
      )
     )
     (local.get $7)
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function117 (type $call183) (param $0 (ref $environment117)) (param $1 (ref null $type12)) (param $2 i64) (result i32)
  (local $3 (ref $type153))
  (local $4 (ref $type23))
  (local $5 (ref $type151))
  (local $6 (ref $type57))
  (local $7 (ref $type119))
  (local $8 (ref null $type91))
  (local $9 (ref $type13))
  (local $10 (ref $type185))
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i32)
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.set $type153 1
     (local.tee $3
      (struct.new_default $type153)
     )
     (struct.new $type151
      (ref.func $function82)
      (struct.new $environment82
       (struct.get $environment117 5
        (local.get $0)
       )
       (local.tee $4
        (struct.get $environment117 0
         (local.get $0)
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type153 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type153 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $6
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (i64.sub
      (local.tee $11
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $6)
        )
       )
      )
      (local.tee $13
       (struct.get $environment117 4
        (local.get $0)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.get $12)
       )
       (i64.xor
        (local.get $11)
        (local.get $13)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type120
     (struct.get $environment117 3
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $12)
    )
    (struct.set $type153 1
     (local.tee $3
      (struct.new_default $type153)
     )
     (struct.new $type151
      (ref.func $function82)
      (struct.new $environment82
       (struct.get $environment117 5
        (local.get $0)
       )
       (local.tee $4
        (struct.get $environment117 0
         (local.get $0)
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type153 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type153 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $6
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $6)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type119
     (local.tee $7
      (struct.get $environment117 1
       (local.get $0)
      )
     )
     (local.tee $14
      (i32.wrap_i64
       (local.get $11)
      )
     )
     (struct.new $type27
      (local.get $2)
      (array.get $type119
       (local.get $7)
       (local.get $14)
      )
     )
    )
    (local.set $8
     (struct.get $type91 1
      (struct.get $environment117 7
       (local.get $0)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $11)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.add
      (local.tee $12
       (struct.get $environment117 8
        (local.get $0)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $12)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type181 0
       (struct.get $environment117 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function112
     (struct.get $type179 0
      (struct.get $type181 1
       (struct.get $environment117 6
        (local.get $0)
       )
      )
     )
     (local.get $8)
     (local.get $11)
     (local.get $2)
    )
   )
   (else
    (struct.set $type153 1
     (local.tee $3
      (struct.new_default $type153)
     )
     (struct.new $type151
      (ref.func $function82)
      (struct.new $environment82
       (local.tee $9
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (local.tee $4
        (struct.get $environment117 0
         (local.get $0)
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type153 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type153 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $6
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $6)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type120
     (struct.get $environment117 3
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $11)
    )
    (struct.set $type153 1
     (local.tee $3
      (struct.new_default $type153)
     )
     (struct.new $type151
      (ref.func $function82)
      (struct.new $environment82
       (local.get $9)
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type153 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type153 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $6
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $6)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type119
     (local.tee $7
      (struct.get $environment117 2
       (local.get $0)
      )
     )
     (local.tee $14
      (i32.wrap_i64
       (local.get $11)
      )
     )
     (struct.new $type27
      (local.get $2)
      (array.get $type119
       (local.get $7)
       (local.get $14)
      )
     )
    )
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $11
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $11)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type185 0
       (local.tee $10
        (struct.get $environment117 9
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function117
     (struct.get $type183 0
      (struct.get $type185 1
       (local.get $10)
      )
     )
     (local.get $1)
     (local.get $11)
    )
   )
  )
  (unreachable)
 )
 (func $function120 (type $call117) (param $0 (ref $environment120)) (param $1 (ref null $type12)) (result (ref $type118))
  (local $2 (ref null $type107))
  (local $3 (ref null $type107))
  (local $4 (ref null $type12))
  (local $5 (ref $type26))
  (local $6 (ref null $type25))
  (local $7 (ref null $type25))
  (local $8 (ref $type105))
  (local $9 (ref $type175))
  (local $10 (ref $type134))
  (local $11 (ref $type134))
  (local $12 (ref $type134))
  (local $13 (ref $type134))
  (local $14 (ref $type134))
  (local $15 (ref $type134))
  (local $16 (ref $type134))
  (local $17 (ref $type134))
  (local $18 (ref $type169))
  (local $19 (ref $type23))
  (local $20 (ref $type120))
  (local $21 (ref $type28))
  (local $22 (ref $type81))
  (local $23 (ref $type81))
  (local $24 (ref $type119))
  (local $25 (ref $type119))
  (local $26 (ref $type119))
  (local $27 (ref $type208))
  (local $28 (ref $type106))
  (local $29 (ref $type171))
  (local $30 (ref $type109))
  (local $31 (ref $type123))
  (local $32 (ref null $type27))
  (local $33 (ref $type206))
  (local $34 i64)
  (local.set $19
   (struct.get $type169 0
    (local.tee $18
     (struct.get $environment120 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global644)
   )
  )
  (local.set $3
   (if (result (ref null $type107))
    (ref.is_null
     (local.get $1)
    )
    (then
     (ref.null none)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global145)
      )
     )
     (local.set $4
      (struct.get $type12 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready644)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global644)
      )
     )
     (local.set $30
      (struct.new_default $type109)
     )
     (struct.new $type107
      (struct.new $type106
       (struct.new $type12
        (struct.get $type12 0
         (local.get $1)
        )
        (ref.null none)
       )
      )
      (if (result (ref null $type107))
       (ref.is_null
        (local.get $4)
       )
       (then
        (ref.null none)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global145)
         )
        )
        (local.set $1
         (struct.get $type12 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (global.get $ready644)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global644)
         )
        )
        (struct.new $type107
         (struct.new $type106
          (struct.new $type12
           (struct.get $type12 0
            (local.get $4)
           )
           (ref.null none)
          )
         )
         (if (result (ref null $type107))
          (ref.is_null
           (local.get $1)
          )
          (then
           (ref.null none)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global145)
            )
           )
           (local.set $4
            (struct.get $type12 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready644)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global644)
            )
           )
           (struct.new $type107
            (struct.new $type106
             (struct.new $type12
              (struct.get $type12 0
               (local.get $1)
              )
              (ref.null none)
             )
            )
            (if (result (ref null $type107))
             (ref.is_null
              (local.get $4)
             )
             (then
              (ref.null none)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global145)
               )
              )
              (local.set $1
               (struct.get $type12 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (global.get $ready644)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global644)
               )
              )
              (struct.new $type107
               (struct.new $type106
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $4)
                 )
                 (ref.null none)
                )
               )
               (if (result (ref null $type107))
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (ref.null none)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global145)
                  )
                 )
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready644)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global644)
                  )
                 )
                 (struct.new $type107
                  (struct.new $type106
                   (struct.new $type12
                    (struct.get $type12 0
                     (local.get $1)
                    )
                    (ref.null none)
                   )
                  )
                  (if (result (ref null $type107))
                   (ref.is_null
                    (local.get $4)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global145)
                     )
                    )
                    (local.set $1
                     (struct.get $type12 1
                      (local.get $4)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready644)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global644)
                     )
                    )
                    (struct.new $type107
                     (struct.new $type106
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $4)
                       )
                       (ref.null none)
                      )
                     )
                     (if (result (ref null $type107))
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global145)
                        )
                       )
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready644)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global644)
                        )
                       )
                       (struct.new $type107
                        (struct.new $type106
                         (struct.new $type12
                          (struct.get $type12 0
                           (local.get $1)
                          )
                          (ref.null none)
                         )
                        )
                        (if (result (ref null $type107))
                         (ref.is_null
                          (local.get $4)
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global145)
                           )
                          )
                          (local.set $1
                           (struct.get $type12 1
                            (local.get $4)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready644)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global644)
                           )
                          )
                          (struct.new $type107
                           (struct.new $type106
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $4)
                             )
                             (ref.null none)
                            )
                           )
                           (if (result (ref null $type107))
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global145)
                              )
                             )
                             (local.set $4
                              (struct.get $type12 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready644)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global644)
                              )
                             )
                             (struct.new $type107
                              (struct.new $type106
                               (struct.new $type12
                                (struct.get $type12 0
                                 (local.get $1)
                                )
                                (ref.null none)
                               )
                              )
                              (if (result (ref null $type107))
                               (ref.is_null
                                (local.get $4)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global145)
                                 )
                                )
                                (local.set $1
                                 (struct.get $type12 1
                                  (local.get $4)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready644)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global644)
                                 )
                                )
                                (struct.new $type107
                                 (struct.new $type106
                                  (struct.new $type12
                                   (struct.get $type12 0
                                    (local.get $4)
                                   )
                                   (ref.null none)
                                  )
                                 )
                                 (if (result (ref null $type107))
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global145)
                                    )
                                   )
                                   (local.set $4
                                    (struct.get $type12 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready644)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global644)
                                    )
                                   )
                                   (struct.new $type107
                                    (struct.new $type106
                                     (struct.new $type12
                                      (struct.get $type12 0
                                       (local.get $1)
                                      )
                                      (ref.null none)
                                     )
                                    )
                                    (if (result (ref null $type107))
                                     (ref.is_null
                                      (local.get $4)
                                     )
                                     (then
                                      (ref.null none)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global145)
                                       )
                                      )
                                      (local.set $1
                                       (struct.get $type12 1
                                        (local.get $4)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready644)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global644)
                                       )
                                      )
                                      (struct.new $type107
                                       (struct.new $type106
                                        (struct.new $type12
                                         (struct.get $type12 0
                                          (local.get $4)
                                         )
                                         (ref.null none)
                                        )
                                       )
                                       (if (result (ref null $type107))
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type107
                                          (call $function341
                                           (struct.get $type12 0
                                            (local.get $1)
                                           )
                                          )
                                          (block (result (ref null $type107))
                                           (local.set $1
                                            (struct.get $type12 1
                                             (local.get $1)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready644)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global644)
                                            )
                                           )
                                           (call $function342
                                            (local.get $30)
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global369)
   )
  )
  (local.set $10
   (struct.new_default $type134)
  )
  (local.set $7
   (if (result (ref null $type25))
    (ref.is_null
     (local.get $3)
    )
    (then
     (ref.null none)
    )
    (else
     (struct.new $type25
      (call $function124
       (struct.get $type107 0
        (local.get $3)
       )
       (struct.get $environment180 1
        (struct.get $type105 0
         (local.tee $8
          (struct.new $type105
           (struct.new $environment180
            (local.get $10)
            (local.get $19)
           )
          )
         )
        )
       )
      )
      (block (result (ref null $type25))
       (local.set $2
        (struct.get $type107 1
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (global.get $ready369)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global369)
        )
       )
       (if (result (ref null $type25))
        (ref.is_null
         (local.get $2)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type25
          (call $function124
           (struct.get $type107 0
            (local.get $2)
           )
           (struct.get $environment180 1
            (struct.get $type105 0
             (local.get $8)
            )
           )
          )
          (block (result (ref null $type25))
           (local.set $2
            (struct.get $type107 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready369)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global369)
            )
           )
           (if (result (ref null $type25))
            (ref.is_null
             (local.get $2)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type25
              (call $function124
               (struct.get $type107 0
                (local.get $2)
               )
               (struct.get $environment180 1
                (struct.get $type105 0
                 (local.get $8)
                )
               )
              )
              (block (result (ref null $type25))
               (local.set $2
                (struct.get $type107 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready369)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global369)
                )
               )
               (if (result (ref null $type25))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type25
                  (call $function124
                   (struct.get $type107 0
                    (local.get $2)
                   )
                   (struct.get $environment180 1
                    (struct.get $type105 0
                     (local.get $8)
                    )
                   )
                  )
                  (block (result (ref null $type25))
                   (local.set $2
                    (struct.get $type107 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready369)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global369)
                    )
                   )
                   (if (result (ref null $type25))
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type25
                      (call $function124
                       (struct.get $type107 0
                        (local.get $2)
                       )
                       (struct.get $environment180 1
                        (struct.get $type105 0
                         (local.get $8)
                        )
                       )
                      )
                      (block (result (ref null $type25))
                       (local.set $2
                        (struct.get $type107 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready369)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global369)
                        )
                       )
                       (if (result (ref null $type25))
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type25
                          (call $function124
                           (struct.get $type107 0
                            (local.get $2)
                           )
                           (struct.get $environment180 1
                            (struct.get $type105 0
                             (local.get $8)
                            )
                           )
                          )
                          (block (result (ref null $type25))
                           (local.set $2
                            (struct.get $type107 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready369)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global369)
                            )
                           )
                           (if (result (ref null $type25))
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type25
                              (call $function124
                               (struct.get $type107 0
                                (local.get $2)
                               )
                               (struct.get $environment180 1
                                (struct.get $type105 0
                                 (local.get $8)
                                )
                               )
                              )
                              (block (result (ref null $type25))
                               (local.set $2
                                (struct.get $type107 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready369)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global369)
                                )
                               )
                               (if (result (ref null $type25))
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type25
                                  (call $function124
                                   (struct.get $type107 0
                                    (local.get $2)
                                   )
                                   (struct.get $environment180 1
                                    (struct.get $type105 0
                                     (local.get $8)
                                    )
                                   )
                                  )
                                  (block (result (ref null $type25))
                                   (local.set $2
                                    (struct.get $type107 1
                                     (local.get $2)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready369)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global369)
                                    )
                                   )
                                   (if (result (ref null $type25))
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type25
                                      (call $function124
                                       (struct.get $type107 0
                                        (local.get $2)
                                       )
                                       (struct.get $environment180 1
                                        (struct.get $type105 0
                                         (local.get $8)
                                        )
                                       )
                                      )
                                      (block (result (ref null $type25))
                                       (local.set $2
                                        (struct.get $type107 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready369)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global369)
                                        )
                                       )
                                       (if (result (ref null $type25))
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type25
                                          (call $function124
                                           (struct.get $type107 0
                                            (local.get $2)
                                           )
                                           (struct.get $environment180 1
                                            (struct.get $type105 0
                                             (local.get $8)
                                            )
                                           )
                                          )
                                          (block (result (ref null $type25))
                                           (local.set $2
                                            (struct.get $type107 1
                                             (local.get $2)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready369)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global369)
                                            )
                                           )
                                           (if (result (ref null $type25))
                                            (ref.is_null
                                             (local.get $2)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type25
                                              (call $function124
                                               (struct.get $type107 0
                                                (local.get $2)
                                               )
                                               (struct.get $environment180 1
                                                (struct.get $type105 0
                                                 (local.get $8)
                                                )
                                               )
                                              )
                                              (block (result (ref null $type25))
                                               (local.set $2
                                                (struct.get $type107 1
                                                 (local.get $2)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready369)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global369)
                                                )
                                               )
                                               (if (result (ref null $type25))
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (struct.new $type25
                                                  (call $function124
                                                   (struct.get $type107 0
                                                    (local.get $2)
                                                   )
                                                   (struct.get $environment180 1
                                                    (struct.get $type105 0
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                  (block (result (ref null $type25))
                                                   (local.set $2
                                                    (struct.get $type107 1
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready369)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global369)
                                                    )
                                                   )
                                                   (if (result (ref null $type25))
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                    (then
                                                     (ref.null none)
                                                    )
                                                    (else
                                                     (call $function182
                                                      (struct.new $environment182
                                                       (local.get $8)
                                                       (local.get $2)
                                                      )
                                                      (call $function124
                                                       (struct.get $type107 0
                                                        (local.get $2)
                                                       )
                                                       (struct.get $environment180 1
                                                        (struct.get $type105 0
                                                         (local.get $8)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global373)
   )
  )
  (local.set $31
   (struct.new $type123
    (struct.new $environment261
     (local.tee $10
      (struct.new_default $type134)
     )
     (local.tee $13
      (struct.new_default $type134)
     )
     (local.tee $11
      (struct.new_default $type134)
     )
     (local.tee $12
      (struct.new_default $type134)
     )
     (struct.new_default $type134)
    )
   )
  )
  (drop
   (call $function149
    (local.get $10)
    (local.tee $22
     (call $function132
      (local.tee $34
       (i64.extend_i32_u
        (array.len
         (local.tee $21
          (if (result (ref $type28))
           (ref.is_null
            (local.get $7)
           )
           (then
            (array.new_fixed $type28 0)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready376)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global376)
             )
            )
            (if
             (i64.gt_u
              (local.tee $34
               (if (result i64)
                (ref.is_null
                 (local.get $7)
                )
                (then
                 (i64.const 0)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $6
                    (struct.get $type25 1
                     (local.get $7)
                    )
                   )
                  )
                  (then
                   (i64.const 1)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $6
                      (struct.get $type25 1
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (i64.const 2)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $6
                        (struct.get $type25 1
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (i64.const 3)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $6
                          (struct.get $type25 1
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (i64.const 4)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $6
                            (struct.get $type25 1
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (i64.const 5)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $6
                              (struct.get $type25 1
                               (local.get $6)
                              )
                             )
                            )
                            (then
                             (i64.const 6)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $6
                                (struct.get $type25 1
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (i64.const 7)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $6
                                  (struct.get $type25 1
                                   (local.get $6)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 8)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $6
                                    (struct.get $type25 1
                                     (local.get $6)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 9)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $6
                                      (struct.get $type25 1
                                       (local.get $6)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 10)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.tee $6
                                        (struct.get $type25 1
                                         (local.get $6)
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 11)
                                      )
                                      (else
                                       (if (result i64)
                                        (ref.is_null
                                         (local.tee $6
                                          (struct.get $type25 1
                                           (local.get $6)
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const 12)
                                        )
                                        (else
                                         (call $function185
                                          (i32.const 0)
                                          (i32.const 1)
                                          (struct.get $type25 1
                                           (local.get $6)
                                          )
                                          (i64.const 13)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (call $function186
             (array.new $type28
              (struct.get $type25 0
               (local.get $7)
              )
              (i32.wrap_i64
               (local.get $34)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (local.get $7)
             (i64.const 0)
            )
           )
          )
         )
        )
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.tee $20
         (struct.get $type169 4
          (local.get $18)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
    (array.get $type119
     (local.tee $25
      (struct.get $type169 1
       (local.get $18)
      )
     )
     (i32.const 0)
    )
    (i64.const 0)
   )
  )
  (drop
   (call $function195
    (local.get $10)
    (local.tee $14
     (struct.new_default $type134)
    )
    (local.get $13)
    (local.get $11)
    (local.get $12)
    (local.tee $15
     (struct.new_default $type134)
    )
    (local.tee $16
     (struct.new_default $type134)
    )
    (local.get $22)
    (i64.const 0)
    (local.get $25)
    (local.tee $24
     (struct.get $type169 2
      (local.get $18)
     )
    )
    (local.tee $26
     (struct.get $type169 3
      (local.get $18)
     )
    )
    (local.get $20)
    (local.get $19)
   )
  )
  (struct.set $type175 1
   (local.tee $9
    (struct.new_default $type175)
   )
   (struct.new $type171
    (ref.func $function228)
    (struct.new $environment228
     (local.get $10)
     (local.get $14)
     (local.tee $17
      (struct.new_default $type134)
     )
     (local.get $13)
     (local.get $11)
     (local.get $12)
     (local.get $15)
     (local.get $16)
     (local.get $25)
     (local.get $24)
     (local.get $26)
     (local.get $20)
     (local.get $19)
     (local.get $21)
     (local.get $34)
     (local.get $22)
     (local.get $9)
    )
   )
  )
  (struct.set $type175 0
   (local.get $9)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type175 0
     (local.get $9)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call171
    (struct.get $type171 1
     (local.tee $29
      (ref.as_non_null
       (struct.get $type175 1
        (local.get $9)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type171 0
     (local.get $29)
    )
   )
  )
  (local.set $23
   (call $function132
    (local.tee $34
     (i64.extend_i32_u
      (array.len
       (local.get $21)
      )
     )
    )
    (i64.extend_i32_u
     (array.len
      (local.get $20)
     )
    )
   )
  )
  (local.set $32
   (array.get $type119
    (local.get $24)
    (i32.const 0)
   )
  )
  (struct.set $type208 1
   (local.tee $27
    (struct.new_default $type208)
   )
   (struct.new $type206
    (ref.func $function238)
    (struct.new $environment238
     (local.get $10)
     (local.get $14)
     (local.get $11)
     (local.get $12)
     (local.get $15)
     (local.get $22)
     (local.get $34)
     (local.get $23)
     (local.get $27)
    )
   )
  )
  (struct.set $type208 0
   (local.get $27)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type208 0
     (local.get $27)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call206
    (struct.get $type206 1
     (local.tee $33
      (ref.as_non_null
       (struct.get $type208 1
        (local.get $27)
       )
      )
     )
    )
    (local.get $32)
    (struct.get $type206 0
     (local.get $33)
    )
   )
  )
  (struct.set $type175 1
   (local.tee $9
    (struct.new_default $type175)
   )
   (struct.new $type171
    (ref.func $function241)
    (struct.new $environment241
     (local.get $10)
     (local.get $14)
     (local.get $17)
     (local.get $13)
     (local.get $11)
     (local.get $12)
     (local.get $15)
     (struct.new_default $type134)
     (local.get $22)
     (local.get $24)
     (local.get $20)
     (local.get $21)
     (i64.extend_i32_u
      (array.len
       (local.get $19)
      )
     )
     (local.get $23)
     (local.get $9)
     (struct.new_default $type134)
    )
   )
  )
  (struct.set $type175 0
   (local.get $9)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type175 0
     (local.get $9)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call171
    (struct.get $type171 1
     (local.tee $29
      (ref.as_non_null
       (struct.get $type175 1
        (local.get $9)
       )
      )
     )
    )
    (local.get $34)
    (struct.get $type171 0
     (local.get $29)
    )
   )
  )
  (struct.new $type118
   (local.get $19)
   (local.get $24)
   (local.get $20)
   (struct.get $type169 5
    (local.get $18)
   )
   (local.get $21)
   (local.get $23)
   (local.get $31)
  )
 )
 (func $function123 (type $call151) (param $0 (ref struct)) (param $1 i64) (result (ref $type57))
  (local $2 (ref $environment123))
  (local $3 (ref $type13))
  (local $4 (ref $type13))
  (local $5 i64)
  (if (result (ref $type57))
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $environment123 0
      (local.tee $2
       (ref.cast (ref $environment123)
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if (result (ref $type59))
     (i64.eq
      (if (result i64)
       (ref.test (ref $type14)
        (local.tee $4
         (array.get $type23
          (struct.get $environment123 1
           (local.get $2)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
       )
       (then
        (i64.const 0)
       )
       (else
        (select
         (i64.const 8)
         (i64.const 1)
         (ref.test (ref $type14)
          (local.get $4)
         )
        )
       )
      )
      (if (result i64)
       (ref.test (ref $type14)
        (local.get $3)
       )
       (then
        (i64.const 0)
       )
       (else
        (select
         (i64.const 8)
         (i64.const 1)
         (ref.test (ref $type14)
          (local.get $3)
         )
        )
       )
      )
     )
     (then
      (struct.new $type59
       (local.get $1)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type153 0
         (struct.get $environment123 2
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function123
       (struct.get $type151 1
        (struct.get $type153 1
         (struct.get $environment123 2
          (local.get $2)
         )
        )
       )
       (local.get $5)
      )
     )
    )
   )
   (else
    (global.get $empty58)
   )
  )
 )
 (func $function124 (param $0 (ref $type106)) (param $1 (ref $type23)) (result (ref $type26))
  (local $2 (ref $type192))
  (local $3 (ref $type153))
  (local $4 (ref $type12))
  (local $5 (ref $environment126))
  (local $6 (ref $type151))
  (struct.set $type192 1
   (local.tee $2
    (struct.new_default $type192)
   )
   (struct.new $type190
    (struct.new $environment126
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type192 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type192 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (struct.set $type153 1
   (local.tee $3
    (struct.new_default $type153)
   )
   (struct.new $type151
    (ref.func $function123)
    (struct.new $environment123
     (struct.get $type12 0
      (local.tee $4
       (struct.get $type106 0
        (local.get $0)
       )
      )
     )
     (local.tee $1
      (struct.get $environment126 0
       (local.tee $5
        (struct.get $type190 0
         (struct.get $type192 1
          (local.get $2)
         )
        )
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type153 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type153 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function127
   (struct.new $environment127
    (struct.get $environment126 1
     (local.get $5)
    )
    (local.get $4)
    (ref.null none)
   )
   (call_ref $call151
    (struct.get $type151 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type153 1
        (local.get $3)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $1)
      )
     )
     (i64.const 1)
    )
    (struct.get $type151 0
     (local.get $6)
    )
   )
  )
 )
 (func $function127 (type $92) (param $0 (ref $environment127)) (param $1 (ref $type57)) (result (ref $type26))
  (local $2 (ref $type153))
  (local $3 (ref null $type12))
  (local $4 (ref $environment126))
  (local $5 (ref $type23))
  (local $6 (ref $type151))
  (local $7 (ref $type27))
  (local $8 (ref null $type27))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type58)
     (local.get $1)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type59)
       (local.get $1)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (local.set $3
     (struct.get $type12 1
      (struct.get $environment127 1
       (local.get $0)
      )
     )
    )
    (if
     (ref.test (ref $type58)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type27
      (struct.get $type59 0
       (ref.cast (ref $type59)
        (local.get $1)
       )
      )
      (block (result (ref null $type27))
       (if
        (i32.eqz
         (struct.get $type192 0
          (struct.get $environment127 0
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type190 0
         (struct.get $type192 1
          (struct.get $environment127 0
           (local.get $0)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global175)
        )
       )
       (struct.get $environment127 2
        (local.get $0)
       )
      )
     )
    )
    (if (result (ref $type26))
     (ref.is_null
      (local.get $3)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global271)
       )
      )
      (struct.new $type26
       (call $function129
        (local.get $7)
       )
      )
     )
     (else
      (struct.set $type153 1
       (local.tee $2
        (struct.new_default $type153)
       )
       (struct.new $type151
        (ref.func $function123)
        (struct.new $environment123
         (struct.get $type12 0
          (local.get $3)
         )
         (local.tee $5
          (struct.get $environment126 0
           (local.get $4)
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type153 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type153 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function127
       (struct.new $environment127
        (struct.get $environment126 1
         (local.get $4)
        )
        (local.get $3)
        (local.get $7)
       )
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $2)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $5)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type12 1
      (struct.get $environment127 1
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type192 0
       (struct.get $environment127 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type190 0
      (struct.get $type192 1
       (struct.get $environment127 0
        (local.get $0)
       )
      )
     )
    )
    (local.set $8
     (struct.get $environment127 2
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global175)
     )
    )
    (if (result (ref $type26))
     (ref.is_null
      (local.get $3)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global271)
       )
      )
      (struct.new $type26
       (call $function129
        (local.get $8)
       )
      )
     )
     (else
      (struct.set $type153 1
       (local.tee $2
        (struct.new_default $type153)
       )
       (struct.new $type151
        (ref.func $function123)
        (struct.new $environment123
         (struct.get $type12 0
          (local.get $3)
         )
         (local.tee $5
          (struct.get $environment126 0
           (local.get $4)
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type153 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type153 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function127
       (struct.new $environment127
        (struct.get $environment126 1
         (local.get $4)
        )
        (local.get $3)
        (local.get $8)
       )
       (call_ref $call151
        (struct.get $type151 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type153 1
            (local.get $2)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $5)
          )
         )
         (i64.const 1)
        )
        (struct.get $type151 0
         (local.get $6)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function129 (type $call101) (param $0 (ref null $type27)) (result (ref null $type27))
  (local $1 (ref $environment131))
  (local $2 (ref $type27))
  (local $3 (ref null $type27))
  (local $4 (ref $type196))
  (local $5 i64)
  (struct.set $type196 1
   (local.tee $4
    (struct.new_default $type196)
   )
   (struct.new $type194
    (struct.new $environment131
     (local.get $4)
    )
   )
  )
  (struct.set $type196 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type196 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type194 0
    (struct.get $type196 1
     (local.get $4)
    )
   )
  )
  (if (result (ref null $type27))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $3
     (struct.get $type27 1
      (local.get $0)
     )
    )
    (local.set $2
     (struct.new $type27
      (struct.get $type27 0
       (local.get $0)
      )
      (block (result nullref)
       (if
        (i32.eqz
         (struct.get $type196 0
          (struct.get $environment131 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type194 0
         (struct.get $type196 1
          (struct.get $environment131 0
           (local.get $1)
          )
         )
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type27))
     (ref.is_null
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $0
       (struct.get $type27 1
        (local.get $3)
       )
      )
      (local.set $2
       (struct.new $type27
        (struct.get $type27 0
         (local.get $3)
        )
        (block (result (ref $type27))
         (if
          (i32.eqz
           (struct.get $type196 0
            (struct.get $environment131 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type194 0
           (struct.get $type196 1
            (struct.get $environment131 0
             (local.get $1)
            )
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (if (result (ref $type27))
       (ref.is_null
        (local.get $0)
       )
       (then
        (local.get $2)
       )
       (else
        (local.set $3
         (struct.get $type27 1
          (local.get $0)
         )
        )
        (local.set $2
         (struct.new $type27
          (struct.get $type27 0
           (local.get $0)
          )
          (block (result (ref $type27))
           (if
            (i32.eqz
             (struct.get $type196 0
              (struct.get $environment131 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type194 0
             (struct.get $type196 1
              (struct.get $environment131 0
               (local.get $1)
              )
             )
            )
           )
           (local.get $2)
          )
         )
        )
        (if (result (ref $type27))
         (ref.is_null
          (local.get $3)
         )
         (then
          (local.get $2)
         )
         (else
          (local.set $0
           (struct.get $type27 1
            (local.get $3)
           )
          )
          (local.set $2
           (struct.new $type27
            (struct.get $type27 0
             (local.get $3)
            )
            (block (result (ref $type27))
             (if
              (i32.eqz
               (struct.get $type196 0
                (struct.get $environment131 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type194 0
               (struct.get $type196 1
                (struct.get $environment131 0
                 (local.get $1)
                )
               )
              )
             )
             (local.get $2)
            )
           )
          )
          (if (result (ref $type27))
           (ref.is_null
            (local.get $0)
           )
           (then
            (local.get $2)
           )
           (else
            (local.set $3
             (struct.get $type27 1
              (local.get $0)
             )
            )
            (local.set $2
             (struct.new $type27
              (struct.get $type27 0
               (local.get $0)
              )
              (block (result (ref $type27))
               (if
                (i32.eqz
                 (struct.get $type196 0
                  (struct.get $environment131 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type194 0
                 (struct.get $type196 1
                  (struct.get $environment131 0
                   (local.get $1)
                  )
                 )
                )
               )
               (local.get $2)
              )
             )
            )
            (if (result (ref $type27))
             (ref.is_null
              (local.get $3)
             )
             (then
              (local.get $2)
             )
             (else
              (local.set $0
               (struct.get $type27 1
                (local.get $3)
               )
              )
              (local.set $2
               (struct.new $type27
                (struct.get $type27 0
                 (local.get $3)
                )
                (block (result (ref $type27))
                 (if
                  (i32.eqz
                   (struct.get $type196 0
                    (struct.get $environment131 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type194 0
                   (struct.get $type196 1
                    (struct.get $environment131 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
              (if (result (ref $type27))
               (ref.is_null
                (local.get $0)
               )
               (then
                (local.get $2)
               )
               (else
                (local.set $3
                 (struct.get $type27 1
                  (local.get $0)
                 )
                )
                (local.set $2
                 (struct.new $type27
                  (struct.get $type27 0
                   (local.get $0)
                  )
                  (block (result (ref $type27))
                   (if
                    (i32.eqz
                     (struct.get $type196 0
                      (struct.get $environment131 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type194 0
                     (struct.get $type196 1
                      (struct.get $environment131 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (local.get $2)
                  )
                 )
                )
                (if (result (ref $type27))
                 (ref.is_null
                  (local.get $3)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (local.set $0
                   (struct.get $type27 1
                    (local.get $3)
                   )
                  )
                  (local.set $2
                   (struct.new $type27
                    (struct.get $type27 0
                     (local.get $3)
                    )
                    (block (result (ref $type27))
                     (if
                      (i32.eqz
                       (struct.get $type196 0
                        (struct.get $environment131 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type194 0
                       (struct.get $type196 1
                        (struct.get $environment131 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (local.get $2)
                    )
                   )
                  )
                  (if (result (ref $type27))
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (local.set $3
                     (struct.get $type27 1
                      (local.get $0)
                     )
                    )
                    (local.set $2
                     (struct.new $type27
                      (struct.get $type27 0
                       (local.get $0)
                      )
                      (block (result (ref $type27))
                       (if
                        (i32.eqz
                         (struct.get $type196 0
                          (struct.get $environment131 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type194 0
                         (struct.get $type196 1
                          (struct.get $environment131 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (local.get $2)
                      )
                     )
                    )
                    (if (result (ref $type27))
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (local.set $0
                       (struct.get $type27 1
                        (local.get $3)
                       )
                      )
                      (local.set $2
                       (struct.new $type27
                        (struct.get $type27 0
                         (local.get $3)
                        )
                        (block (result (ref $type27))
                         (if
                          (i32.eqz
                           (struct.get $type196 0
                            (struct.get $environment131 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type194 0
                           (struct.get $type196 1
                            (struct.get $environment131 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (local.get $2)
                        )
                       )
                      )
                      (if (result (ref $type27))
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (local.set $3
                         (struct.get $type27 1
                          (local.get $0)
                         )
                        )
                        (local.set $2
                         (struct.new $type27
                          (struct.get $type27 0
                           (local.get $0)
                          )
                          (block (result (ref $type27))
                           (if
                            (i32.eqz
                             (struct.get $type196 0
                              (struct.get $environment131 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $1
                            (struct.get $type194 0
                             (struct.get $type196 1
                              (struct.get $environment131 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (local.get $2)
                          )
                         )
                        )
                        (if (result (ref $type27))
                         (ref.is_null
                          (local.get $3)
                         )
                         (then
                          (local.get $2)
                         )
                         (else
                          (local.set $0
                           (struct.get $type27 1
                            (local.get $3)
                           )
                          )
                          (local.set $2
                           (struct.new $type27
                            (struct.get $type27 0
                             (local.get $3)
                            )
                            (block (result (ref $type27))
                             (if
                              (i32.eqz
                               (struct.get $type196 0
                                (struct.get $environment131 0
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $1
                              (struct.get $type194 0
                               (struct.get $type196 1
                                (struct.get $environment131 0
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (local.get $2)
                            )
                           )
                          )
                          (if (result (ref $type27))
                           (ref.is_null
                            (local.get $0)
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (local.set $3
                             (struct.get $type27 1
                              (local.get $0)
                             )
                            )
                            (local.set $2
                             (struct.new $type27
                              (struct.get $type27 0
                               (local.get $0)
                              )
                              (block (result (ref $type27))
                               (if
                                (i32.eqz
                                 (struct.get $type196 0
                                  (struct.get $environment131 0
                                   (local.get $1)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $1
                                (struct.get $type194 0
                                 (struct.get $type196 1
                                  (struct.get $environment131 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (local.get $2)
                              )
                             )
                            )
                            (if (result (ref $type27))
                             (ref.is_null
                              (local.get $3)
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (local.set $0
                               (struct.get $type27 1
                                (local.get $3)
                               )
                              )
                              (local.set $2
                               (struct.new $type27
                                (struct.get $type27 0
                                 (local.get $3)
                                )
                                (block (result (ref $type27))
                                 (if
                                  (i32.eqz
                                   (struct.get $type196 0
                                    (struct.get $environment131 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type194 0
                                   (struct.get $type196 1
                                    (struct.get $environment131 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $2)
                                )
                               )
                              )
                              (if (result (ref $type27))
                               (ref.is_null
                                (local.get $0)
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (local.set $3
                                 (struct.get $type27 1
                                  (local.get $0)
                                 )
                                )
                                (local.set $5
                                 (struct.get $type27 0
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type196 0
                                   (struct.get $environment131 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (return_call $function131
                                 (struct.get $type194 0
                                  (struct.get $type196 1
                                   (struct.get $environment131 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (local.get $3)
                                 (struct.new $type27
                                  (local.get $5)
                                  (local.get $2)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function131 (type $call194) (param $0 (ref $environment131)) (param $1 (ref null $type27)) (param $2 (ref $type27)) (result (ref null $type27))
  (local $3 (ref null $type27))
  (local $4 i64)
  (if (result (ref $type27))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type27 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type27 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type196 0
       (struct.get $environment131 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function131
     (struct.get $type194 0
      (struct.get $type196 1
       (struct.get $environment131 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type27
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function132 (type $86) (param $0 i64) (param $1 i64) (result (ref $type81))
  (local $2 (ref $type200))
  (local $3 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.add
        (local.get $0)
        (i64.const 1)
       )
      )
      (local.get $0)
     )
     (i64.xor
      (local.get $3)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type200 1
   (local.tee $2
    (struct.new_default $type200)
   )
   (struct.new $type198
    (struct.new $environment135
     (local.get $1)
     (array.new $type81
      (global.get $empty83)
      (i32.wrap_i64
       (local.get $3)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type200 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type200 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function135
   (struct.get $type198 0
    (struct.get $type200 1
     (local.get $2)
    )
   )
   (local.get $0)
  )
 )
 (func $function135 (type $call198) (param $0 (ref $environment135)) (param $1 i64) (result (ref $type81))
  (local $2 i64)
  (local $3 (ref $type76))
  (local $4 (ref $type200))
  (if (result (ref $type81))
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $environment135 0
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type77 0
     (struct.get $type76 0
      (local.tee $3
       (struct.new $type76
        (struct.new $type77
         (i64.const -1)
        )
        (array.new $type78
         (global.get $empty62)
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
     )
     (i64.const -1)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type81
     (struct.get $environment135 1
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (struct.new $type84
      (local.get $3)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type200 0
       (local.tee $4
        (struct.get $environment135 2
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function135
     (struct.get $type198 0
      (struct.get $type200 1
       (local.get $4)
      )
     )
     (local.get $2)
    )
   )
   (else
    (struct.get $environment135 1
     (local.get $0)
    )
   )
  )
 )
 (func $function138 (type $77) (param $0 (ref $type76)) (param $1 i64) (param $2 i64) (result (ref $type64))
  (local $3 (ref $type61))
  (local $4 (ref $type65))
  (local $5 (ref $type64))
  (local $6 i64)
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type64))
   (if (result i32)
    (ref.test (ref $type62)
     (local.tee $3
      (array.get $type78
       (struct.get $type76 1
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type63)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type62)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (struct.get $type63 0
     (ref.cast (ref $type63)
      (local.get $3)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 6)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global121)
     )
    )
    (array.set $type65
     (local.tee $4
      (struct.get $type64 0
       (local.tee $5
        (struct.new $type64
         (array.new $type65
          (global.get $empty58)
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (i32.const 1)
     (struct.new $type59
      (i64.const -3)
     )
    )
    (array.set $type65
     (local.get $4)
     (i32.const 2)
     (struct.new $type59
      (i64.const -1)
     )
    )
    (array.set $type65
     (local.get $4)
     (i32.const 3)
     (struct.new $type59
      (i64.const -1)
     )
    )
    (array.set $type65
     (local.get $4)
     (i32.const 4)
     (struct.new $type59
      (i64.const -1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type78
     (struct.get $type76 1
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (struct.new $type63
      (local.get $5)
     )
    )
    (local.get $5)
   )
  )
 )
 (func $function142 (type $73) (param $0 (ref $type64))
  (local $1 (ref $type57))
  (local $2 (ref $type65))
  (local $3 i64)
  (local $4 i64)
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $1
     (array.get $type65
      (struct.get $type64 0
       (local.get $0)
      )
      (i32.const 1)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $4
       (i64.add
        (local.tee $3
         (struct.get $type59 0
          (ref.cast (ref $type59)
           (local.get $1)
          )
         )
        )
        (i64.const 5)
       )
      )
      (local.get $3)
     )
     (i64.xor
      (local.get $4)
      (i64.const 5)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $1
     (array.get $type65
      (struct.get $type64 0
       (local.get $0)
      )
      (i32.const 4)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type59 0
    (ref.cast (ref $type59)
     (local.get $1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type65
   (local.tee $2
    (struct.get $type64 0
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $4)
   )
   (struct.new $type59
    (local.get $3)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $1
     (array.get $type65
      (local.get $2)
      (i32.const 3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type65
   (local.get $2)
   (i32.const 1)
   (struct.new $type59
    (struct.get $type59 0
     (ref.cast (ref $type59)
      (local.get $1)
     )
    )
   )
  )
  (array.set $type65
   (local.get $2)
   (i32.const 3)
   (struct.new $type59
    (i64.const -1)
   )
  )
  (array.set $type65
   (local.get $2)
   (i32.const 4)
   (struct.new $type59
    (i64.const -1)
   )
  )
 )
 (func $function145 (type $72) (param $0 (ref $type76)) (param $1 i64) (param $2 i64) (result (ref $type57))
  (local $3 (ref $type61))
  (local $4 (ref $type64))
  (local $scratch (ref $type64))
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type57))
   (if (result i32)
    (ref.test (ref $type62)
     (local.tee $3
      (array.get $type78
       (struct.get $type76 1
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type63)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (if
     (ref.test (ref $type62)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (array.get $type65
     (struct.get $type64 0
      (block (result (ref $type64))
       (local.set $scratch
        (struct.get $type63 0
         (ref.cast (ref $type63)
          (local.get $3)
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $2)
           (local.tee $1
            (i64.add
             (local.get $2)
             (i64.const 5)
            )
           )
          )
          (i64.xor
           (local.get $1)
           (i64.const 5)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global115)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
   (else
    (global.get $empty58)
   )
  )
 )
 (func $function147 (type $71) (param $0 (ref $type76)) (param $1 (ref $type64)) (param $2 i64) (param $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type65))
  (local $7 (ref $type57))
  (local $8 (ref $type77))
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $7
     (array.get $type65
      (struct.get $type64 0
       (local.get $1)
      )
      (i32.const 3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type59 0
    (ref.cast (ref $type59)
     (local.get $7)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $4
       (i64.add
        (local.get $3)
        (i64.const 5)
       )
      )
      (local.get $3)
     )
     (i64.xor
      (local.get $4)
      (i64.const 5)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type65
   (struct.get $type64 0
    (local.get $1)
   )
   (i32.wrap_i64
    (local.get $4)
   )
   (struct.new $type59
    (i64.const -1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $4
       (i64.add
        (local.get $5)
        (i64.const 5)
       )
      )
      (local.get $5)
     )
     (i64.xor
      (local.get $4)
      (i64.const 5)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type65
   (local.tee $6
    (struct.get $type64 0
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $4)
   )
   (struct.new $type59
    (local.get $3)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (array.set $type65
   (local.get $6)
   (i32.const 3)
   (struct.new $type59
    (local.get $3)
   )
  )
  (if
   (i64.lt_s
    (local.get $5)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (array.set $type65
     (local.get $6)
     (i32.const 0)
     (struct.new $type59
      (struct.get $type77 0
       (local.tee $8
        (struct.get $type76 0
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (struct.set $type77 0
     (local.get $8)
     (local.get $2)
    )
   )
  )
 )
 (func $function149 (param $0 (ref $type134)) (param $1 (ref $type81)) (param $2 i64) (param $3 (ref null $type27)) (param $4 i64) (result i32)
  (local $5 (ref $type208))
  (local $6 (ref $type82))
  (local $7 (ref $type206))
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $type83)
    (local.tee $6
     (array.get $type81
      (local.get $1)
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type208 1
   (local.tee $5
    (struct.new_default $type208)
   )
   (struct.new $type206
    (ref.func $function153)
    (struct.new $environment153
     (local.get $0)
     (local.get $2)
     (local.get $4)
     (struct.get $type84 0
      (ref.cast (ref $type84)
       (local.get $6)
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type208 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type208 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call206
   (struct.get $type206 1
    (local.tee $7
     (ref.as_non_null
      (struct.get $type208 1
       (local.get $5)
      )
     )
    )
   )
   (local.get $3)
   (struct.get $type206 0
    (local.get $7)
   )
  )
 )
 (func $function153 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 (ref $environment153))
  (local $3 (ref $type64))
  (local $4 (ref $type76))
  (local $5 (ref $type57))
  (local $6 (ref $type208))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (call $function138
      (local.tee $4
       (struct.get $environment153 3
        (local.tee $2
         (ref.cast (ref $environment153)
          (local.get $0)
         )
        )
       )
      )
      (struct.get $environment153 1
       (local.get $2)
      )
      (local.tee $9
       (struct.get $type27 0
        (local.get $1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.tee $8
           (struct.get $environment153 2
            (local.get $2)
           )
          )
          (i64.const 5)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (ref.test (ref $type58)
        (local.tee $5
         (array.get $type65
          (struct.get $type64 0
           (local.get $3)
          )
          (i32.wrap_i64
           (local.get $7)
          )
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $5)
         )
        )
        (i32.const 1)
       )
      )
     )
     (then
      (call $function147
       (local.get $4)
       (local.get $3)
       (local.get $9)
       (local.get $8)
      )
     )
    )
    (local.set $1
     (struct.get $type27 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.tee $6
        (struct.get $environment153 4
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function153
     (struct.get $type206 1
      (struct.get $type208 1
       (local.get $6)
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $function158 (type $68) (param $0 (ref $type81)) (param $1 (ref $type81)) (param $2 i64) (param $3 i64) (param $4 i64) (result i32)
  (local $5 (ref $type57))
  (local $6 (ref $type82))
  (local $7 (ref $type64))
  (local $8 (ref $type76))
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $type83)
    (local.tee $6
     (array.get $type81
      (local.get $0)
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $function145
    (struct.get $type84 0
     (ref.cast (ref $type84)
      (local.get $6)
     )
    )
    (local.get $3)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type58)
     (local.get $5)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type59)
       (local.get $5)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.tee $6
       (array.get $type81
        (local.get $1)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function138
      (local.tee $8
       (struct.get $type84 0
        (ref.cast (ref $type84)
         (local.get $6)
        )
       )
      )
      (local.get $2)
      (local.get $3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.tee $2
         (i64.add
          (local.get $4)
          (i64.const 5)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (ref.test (ref $type58)
        (local.tee $5
         (array.get $type65
          (struct.get $type64 0
           (local.get $7)
          )
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $5)
         )
        )
        (i32.const 1)
       )
      )
     )
     (then
      (call $function147
       (local.get $8)
       (local.get $7)
       (local.get $3)
       (local.get $4)
      )
     )
    )
    (i32.const 1)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function163 (param $0 (ref $type76)) (param $1 (ref $type64)) (param $2 i64) (param $3 (ref $type64)) (result i32)
  (local $4 (ref $type175))
  (local $5 (ref $type57))
  (local $6 (ref $type171))
  (local $7 i64)
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (ref.test (ref $type58)
    (local.tee $5
     (array.get $type65
      (struct.get $type64 0
       (local.get $3)
      )
      (i32.const 2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $7
   (struct.get $type59 0
    (ref.cast (ref $type59)
     (local.get $5)
    )
   )
  )
  (struct.set $type175 1
   (local.tee $4
    (struct.new_default $type175)
   )
   (struct.new $type171
    (ref.func $function165)
    (struct.new $environment165
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
  (struct.set $type175 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type175 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call171
   (struct.get $type171 1
    (local.tee $6
     (ref.as_non_null
      (struct.get $type175 1
       (local.get $4)
      )
     )
    )
   )
   (local.get $7)
   (struct.get $type171 0
    (local.get $6)
   )
  )
 )
 (func $function165 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $environment165))
  (local $4 (ref $type57))
  (local $5 (ref $type64))
  (local $scratch (ref $type64))
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (if (result i32)
       (ref.test (ref $type58)
        (local.tee $4
         (array.get $type65
          (struct.get $type64 0
           (block (result (ref $type64))
            (local.set $scratch
             (struct.get $environment165 1
              (local.tee $3
               (ref.cast (ref $environment165)
                (local.get $0)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global267)
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.get $1)
                (local.tee $2
                 (i64.add
                  (local.get $1)
                  (i64.const 5)
                 )
                )
               )
               (i64.xor
                (local.get $2)
                (i64.const 5)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global115)
             )
            )
            (if
             (i64.gt_u
              (local.get $2)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.get $scratch)
           )
          )
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $4)
         )
        )
        (i32.const 1)
       )
      )
     )
     (then
      (call $function147
       (struct.get $environment165 0
        (local.get $3)
       )
       (struct.get $environment165 1
        (local.get $3)
       )
       (struct.get $environment165 2
        (local.get $3)
       )
       (local.get $1)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 5)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $4
       (array.get $type65
        (struct.get $type64 0
         (struct.get $environment165 3
          (local.get $3)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (struct.get $environment165 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function165
     (struct.get $type171 1
      (struct.get $type175 1
       (struct.get $environment165 4
        (local.get $3)
       )
      )
     )
     (local.get $1)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function182 (type $65) (param $0 (ref $environment182)) (param $1 (ref $type26)) (result (ref $type25))
  (local $2 (ref null $type107))
  (local $3 (ref $type105))
  (local $4 (ref $environment180))
  (local $5 (ref $type134))
  (local $6 (ref $type106))
  (local $7 (ref $type23))
  (local.set $2
   (struct.get $type107 1
    (struct.get $environment182 1
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready369)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global369)
   )
  )
  (struct.new $type25
   (local.get $1)
   (if (result (ref null $type25))
    (ref.is_null
     (local.get $2)
    )
    (then
     (ref.null none)
    )
    (else
     (call $function182
      (struct.new $environment182
       (local.tee $3
        (struct.get $environment182 0
         (local.get $0)
        )
       )
       (local.get $2)
      )
      (block (result (ref $type26))
       (local.set $5
        (struct.get $environment180 0
         (local.tee $4
          (struct.get $type105 0
           (local.get $3)
          )
         )
        )
       )
       (call $function124
        (struct.get $type107 0
         (local.get $2)
        )
        (struct.get $environment180 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function185 (type $64) (param $0 i32) (param $1 i32) (param $2 (ref null $type25)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type25 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function185
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function186 (type $63) (param $0 (ref null $type28)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type25)) (param $5 i64) (result (ref $type28))
  (local $6 i64)
  (local $7 (ref $type26))
  (if (result (ref $type28))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type25 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type28
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type25 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function186
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function195 (param $0 (ref $type134)) (param $1 (ref $type134)) (param $2 (ref $type134)) (param $3 (ref $type134)) (param $4 (ref $type134)) (param $5 (ref $type134)) (param $6 (ref $type134)) (param $7 (ref $type81)) (param $8 i64) (param $9 (ref $type119)) (param $10 (ref $type119)) (param $11 (ref $type119)) (param $12 (ref $type120)) (param $13 (ref $type23)) (result i32)
  (local $14 (ref $type226))
  (local $15 (ref $type82))
  (local $16 (ref $type10))
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (if
   (i64.gt_u
    (local.get $8)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $type83)
    (local.tee $15
     (array.get $type81
      (local.get $7)
      (i32.wrap_i64
       (local.get $8)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type226 1
   (local.tee $14
    (struct.new_default $type226)
   )
   (struct.new $type10
    (ref.func $function220)
    (struct.new $environment220
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (local.get $11)
     (local.get $12)
     (struct.get $type84 0
      (ref.cast (ref $type84)
       (local.get $15)
      )
     )
     (i64.extend_i32_u
      (array.len
       (local.get $13)
      )
     )
     (local.get $14)
    )
   )
  )
  (struct.set $type226 0
   (local.get $14)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type226 0
     (local.get $14)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call10
   (struct.get $type10 1
    (local.tee $16
     (ref.as_non_null
      (struct.get $type226 1
       (local.get $14)
      )
     )
    )
   )
   (struct.get $type10 0
    (local.get $16)
   )
  )
 )
 (func $function198 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $environment198))
  (local $6 (ref $type64))
  (local $7 (ref $type76))
  (local $8 (ref $type57))
  (local $9 (ref $type208))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $6
     (call $function138
      (local.tee $7
       (struct.get $environment198 1
        (local.tee $5
         (ref.cast (ref $environment198)
          (local.get $0)
         )
        )
       )
      )
      (local.tee $2
       (struct.get $environment198 2
        (local.get $5)
       )
      )
      (local.tee $4
       (struct.get $type27 0
        (local.get $1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 5)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (ref.test (ref $type58)
        (local.tee $8
         (array.get $type65
          (struct.get $type64 0
           (local.get $6)
          )
          (i32.wrap_i64
           (local.get $3)
          )
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $8)
         )
        )
        (i32.const 1)
       )
      )
     )
     (then
      (call $function147
       (local.get $7)
       (local.get $6)
       (local.get $4)
       (local.get $2)
      )
     )
    )
    (local.set $1
     (struct.get $type27 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.tee $9
        (struct.get $environment198 3
         (local.get $5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function198
     (struct.get $type206 1
      (struct.get $type208 1
       (local.get $9)
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $function203 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 (ref $environment203))
  (local $3 (ref null $type208))
  (local $4 (ref $type76))
  (local $5 (ref $type57))
  (local $6 (ref $type134))
  (local $7 i64)
  (local $8 i64)
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (block $block
   (return
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $3
       (struct.get $environment203 7
        (local.tee $2
         (ref.cast (ref $environment203)
          (local.get $0)
         )
        )
       )
      )
      (local.set $6
       (struct.get $environment203 1
        (local.get $2)
       )
      )
      (local.set $5
       (call $function145
        (local.tee $4
         (struct.get $environment203 3
          (local.get $2)
         )
        )
        (struct.get $type27 0
         (local.get $1)
        )
        (local.tee $8
         (struct.get $environment203 4
          (local.get $2)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global267)
       )
      )
      (br_if $block
       (i32.eqz
        (if (result i32)
         (ref.test (ref $type58)
          (local.get $5)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.cast (ref $type59)
            (local.get $5)
           )
          )
          (i32.const 1)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $7
           (struct.get $environment203 6
            (local.get $2)
           )
          )
          (local.tee $7
           (i64.add
            (local.get $7)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function163
        (local.get $4)
        (call $function138
         (local.get $4)
         (local.get $8)
         (local.get $7)
        )
        (local.get $7)
        (struct.get $environment203 5
         (local.get $2)
        )
       )
      )
      (br $block)
     )
    )
   )
  )
  (local.set $1
   (struct.get $type27 1
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (struct.get $type208 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function203
   (struct.get $type206 1
    (struct.get $type208 1
     (local.get $3)
    )
   )
   (local.get $1)
  )
 )
 (func $function210 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 (ref $environment210))
  (local $3 (ref $type175))
  (local $4 (ref $type171))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type175 1
     (local.tee $3
      (struct.new_default $type175)
     )
     (struct.new $type171
      (ref.func $function213)
      (struct.new $environment213
       (struct.get $environment210 3
        (local.tee $2
         (ref.cast (ref $environment210)
          (local.get $0)
         )
        )
       )
       (struct.get $environment210 4
        (local.get $2)
       )
       (struct.get $environment210 6
        (local.get $2)
       )
       (struct.get $environment210 7
        (local.get $2)
       )
       (struct.get $environment210 8
        (local.get $2)
       )
       (struct.get $environment210 9
        (local.get $2)
       )
       (struct.get $environment210 11
        (local.get $2)
       )
       (local.get $1)
       (struct.get $type27 0
        (local.get $1)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type175 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call171
     (struct.get $type171 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type175 1
         (local.get $3)
        )
       )
      )
     )
     (struct.get $environment210 10
      (local.get $2)
     )
     (struct.get $type171 0
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function213 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment213))
  (local $3 (ref $type76))
  (local $4 (ref $type61))
  (local $5 (ref $type81))
  (local $6 (ref $type82))
  (local $7 (ref $type64))
  (local $8 (ref $type57))
  (local $9 (ref $type175))
  (local $10 (ref null $type27))
  (local $11 i64)
  (local $12 i64)
  (local $scratch (ref $type76))
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.tee $6
       (array.get $type81
        (struct.get $environment213 2
         (local.tee $2
          (ref.cast (ref $environment213)
           (local.get $0)
          )
         )
        )
        (block (result i32)
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type62)
       (local.tee $4
        (array.get $type78
         (struct.get $type76 1
          (block (result (ref $type76))
           (local.set $scratch
            (struct.get $type84 0
             (ref.cast (ref $type84)
              (local.get $6)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global291)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global125)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (struct.get $environment213 8
               (local.get $2)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.get $scratch)
          )
         )
         (i32.wrap_i64
          (local.get $11)
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type63)
         (local.get $4)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $11
           (i64.add
            (local.tee $12
             (struct.get $environment213 8
              (local.get $2)
             )
            )
            (i64.const 1)
           )
          )
          (local.get $12)
         )
         (i64.xor
          (local.get $11)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (call $function138
        (local.tee $3
         (struct.get $environment213 3
          (local.get $2)
         )
        )
        (struct.get $environment213 4
         (local.get $2)
        )
        (local.get $11)
       )
      )
      (if
       (ref.test (ref $type62)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function163
        (local.get $3)
        (local.get $7)
        (local.get $11)
        (struct.get $type63 0
         (ref.cast (ref $type63)
          (local.get $4)
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $11
         (i64.add
          (local.get $1)
          (i64.const 5)
         )
        )
       )
       (i64.xor
        (local.get $11)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $11)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $8
       (array.get $type65
        (struct.get $type64 0
         (struct.get $environment213 5
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $11)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $8)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (local.tee $9
        (struct.get $environment213 9
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function213
     (struct.get $type171 1
      (struct.get $type175 1
       (local.get $9)
      )
     )
     (local.get $1)
    )
   )
   (else
    (local.set $10
     (struct.get $type27 1
      (struct.get $environment213 7
       (local.tee $2
        (ref.cast (ref $environment213)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (struct.get $environment213 6
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function210
     (struct.get $type206 1
      (struct.get $type208 1
       (struct.get $environment213 6
        (local.get $2)
       )
      )
     )
     (local.get $10)
    )
   )
  )
  (unreachable)
 )
 (func $function220 (type $call10) (param $0 (ref struct)) (result i32)
  (local $1 (ref $environment220))
  (local $2 (ref null $type208))
  (local $3 (ref $type76))
  (local $4 (ref $type64))
  (local $5 (ref null $type27))
  (local $6 (ref $type208))
  (local $7 (ref $type57))
  (local $8 (ref $type134))
  (local $9 (ref $type134))
  (local $10 (ref $type134))
  (local $11 (ref $type134))
  (local $12 (ref $type134))
  (local $13 (ref $type134))
  (local $14 (ref $type119))
  (local $15 (ref $type119))
  (local $16 (ref $type206))
  (local $17 (ref $type61))
  (local $18 (ref $type81))
  (local $19 (ref $type226))
  (local $20 i64)
  (local $21 i64)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (i64.ge_s
    (local.tee $20
     (struct.get $type77 0
      (struct.get $type76 0
       (struct.get $environment220 13
        (local.tee $1
         (ref.cast (ref $environment220)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $20)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $21
     (array.get $type120
      (struct.get $environment220 12
       (local.get $1)
      )
      (i32.wrap_i64
       (local.get $20)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i64.gt_u
      (local.get $20)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type62)
      (local.tee $17
       (array.get $type78
        (struct.get $type76 1
         (local.tee $3
          (struct.get $environment220 13
           (local.get $1)
          )
         )
        )
        (i32.wrap_i64
         (local.get $20)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $7
       (array.get $type65
        (struct.get $type64 0
         (local.tee $4
          (struct.get $type63 0
           (ref.cast (ref $type63)
            (local.get $17)
           )
          )
         )
        )
        (i32.const 4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $23
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $7)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $7
       (array.get $type65
        (struct.get $type64 0
         (local.get $4)
        )
        (i32.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type77 0
     (struct.get $type76 0
      (local.get $3)
     )
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $7)
      )
     )
    )
    (local.set $8
     (struct.get $environment220 0
      (local.get $1)
     )
    )
    (local.set $9
     (struct.get $environment220 3
      (local.get $1)
     )
    )
    (local.set $10
     (struct.get $environment220 5
      (local.get $1)
     )
    )
    (local.set $22
     (struct.get $environment220 8
      (local.get $1)
     )
    )
    (call $function142
     (local.get $4)
    )
    (if
     (i64.ge_s
      (local.get $21)
      (i64.const 0)
     )
     (then
      (local.set $5
       (array.get $type119
        (struct.get $environment220 9
         (local.get $1)
        )
        (block (result i32)
         (local.set $15
          (struct.get $environment220 10
           (local.get $1)
          )
         )
         (if
          (i64.gt_u
           (local.get $21)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $21)
         )
        )
       )
      )
      (struct.set $type208 1
       (local.tee $6
        (struct.new_default $type208)
       )
       (struct.new $type206
        (ref.func $function198)
        (struct.new $environment198
         (local.get $8)
         (local.get $3)
         (local.get $22)
         (local.get $6)
        )
       )
      )
      (struct.set $type208 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type208 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call206
        (struct.get $type206 1
         (local.tee $16
          (ref.as_non_null
           (struct.get $type208 1
            (local.get $6)
           )
          )
         )
        )
        (local.get $5)
        (struct.get $type206 0
         (local.get $16)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $21)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (array.get $type119
        (local.get $15)
        (i32.wrap_i64
         (local.get $21)
        )
       )
      )
      (struct.set $type208 1
       (local.tee $2
        (struct.new_default $type208)
       )
       (struct.new $type206
        (ref.func $function203)
        (struct.new $environment203
         (local.get $8)
         (local.get $9)
         (local.get $10)
         (local.get $3)
         (local.get $22)
         (local.get $4)
         (local.get $20)
         (ref.as_non_null
          (local.get $2)
         )
        )
       )
      )
     )
     (else
      (local.set $11
       (struct.get $environment220 2
        (local.get $1)
       )
      )
      (local.set $12
       (struct.get $environment220 6
        (local.get $1)
       )
      )
      (local.set $18
       (struct.get $environment220 7
        (local.get $1)
       )
      )
      (local.set $5
       (array.get $type119
        (struct.get $environment220 11
         (local.get $1)
        )
        (block (result i32)
         (local.set $13
          (struct.get $environment220 1
           (local.get $1)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.get $21)
             (local.tee $20
              (i64.add
               (local.tee $24
                (struct.get $environment220 14
                 (local.get $1)
                )
               )
               (local.get $21)
              )
             )
            )
            (i64.xor
             (local.get $20)
             (local.get $24)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $20)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $20)
         )
        )
       )
      )
      (struct.set $type208 1
       (local.tee $2
        (struct.new_default $type208)
       )
       (struct.new $type206
        (ref.func $function210)
        (struct.new $environment210
         (local.get $8)
         (local.get $13)
         (local.get $11)
         (local.get $9)
         (local.get $10)
         (local.get $12)
         (local.get $18)
         (local.get $3)
         (local.get $22)
         (local.get $4)
         (local.get $23)
         (ref.as_non_null
          (local.get $2)
         )
        )
       )
      )
     )
    )
    (struct.set $type208 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call206
      (struct.get $type206 1
       (local.tee $16
        (ref.as_non_null
         (struct.get $type208 1
          (local.get $2)
         )
        )
       )
      )
      (local.get $5)
      (struct.get $type206 0
       (local.get $16)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type226 0
       (local.tee $19
        (struct.get $environment220 15
         (local.get $1)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function220
     (struct.get $type10 1
      (struct.get $type226 1
       (local.get $19)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function228 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment228))
  (local $3 (ref null $type27))
  (local $4 (ref $type134))
  (local $5 (ref $type134))
  (local $6 (ref $type134))
  (local $7 (ref $type134))
  (local $8 (ref $type134))
  (local $9 (ref $type134))
  (local $10 (ref $type134))
  (local $11 (ref $type134))
  (local $12 (ref $type81))
  (local $13 (ref $type81))
  (local $14 (ref $type175))
  (local $15 i64)
  (if (result i32)
   (i64.gt_s
    (struct.get $environment228 14
     (local.tee $2
      (ref.cast (ref $environment228)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type26 0
      (array.get $type28
       (struct.get $environment228 13
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $15
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $15)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function149
      (local.tee $4
       (struct.get $environment228 0
        (local.get $2)
       )
      )
      (block (result (ref $type81))
       (local.set $9
        (local.tee $5
         (struct.get $environment228 1
          (local.get $2)
         )
        )
       )
       (local.set $10
        (local.tee $6
         (struct.get $environment228 4
          (local.get $2)
         )
        )
       )
       (local.set $11
        (local.tee $7
         (struct.get $environment228 6
          (local.get $2)
         )
        )
       )
       (local.tee $12
        (struct.get $environment228 15
         (local.get $2)
        )
       )
      )
      (local.get $15)
      (local.get $3)
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $15
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $15)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function195
      (local.get $4)
      (local.get $5)
      (struct.get $environment228 3
       (local.get $2)
      )
      (local.get $6)
      (struct.get $environment228 5
       (local.get $2)
      )
      (local.get $7)
      (struct.get $environment228 7
       (local.get $2)
      )
      (local.get $12)
      (local.get $15)
      (struct.get $environment228 8
       (local.get $2)
      )
      (struct.get $environment228 9
       (local.get $2)
      )
      (struct.get $environment228 10
       (local.get $2)
      )
      (struct.get $environment228 11
       (local.get $2)
      )
      (struct.get $environment228 12
       (local.get $2)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $15
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $15)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (local.tee $14
        (struct.get $environment228 16
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function228
     (struct.get $type171 1
      (struct.get $type175 1
       (local.get $14)
      )
     )
     (local.get $15)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function238 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 (ref $environment238))
  (local $3 (ref $type208))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function158
      (struct.get $environment238 5
       (local.tee $2
        (ref.cast (ref $environment238)
         (local.get $0)
        )
       )
      )
      (struct.get $environment238 7
       (local.get $2)
      )
      (struct.get $environment238 6
       (local.get $2)
      )
      (struct.get $type27 0
       (local.get $1)
      )
      (i64.const 0)
     )
    )
    (local.set $1
     (struct.get $type27 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.tee $3
        (struct.get $environment238 8
         (local.get $2)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function238
     (struct.get $type206 1
      (struct.get $type208 1
       (local.get $3)
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $function241 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment241))
  (local $3 (ref $type226))
  (local $4 (ref $type81))
  (local $5 (ref $type134))
  (local $6 (ref $type82))
  (local $7 (ref $type10))
  (local $8 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $4
     (struct.get $environment241 8
      (local.tee $2
       (ref.cast (ref $environment241)
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (local.set $5
     (struct.get $environment241 15
      (local.get $2)
     )
    )
    (struct.set $type226 1
     (local.tee $3
      (struct.new_default $type226)
     )
     (struct.new $type10
      (ref.func $function245)
      (struct.new $environment245
       (struct.get $environment241 0
        (local.get $2)
       )
       (struct.get $environment241 1
        (local.get $2)
       )
       (struct.get $environment241 3
        (local.get $2)
       )
       (struct.get $environment241 4
        (local.get $2)
       )
       (struct.get $environment241 5
        (local.get $2)
       )
       (struct.get $environment241 6
        (local.get $2)
       )
       (struct.get $environment241 7
        (local.get $2)
       )
       (local.get $4)
       (local.tee $4
        (struct.get $environment241 13
         (local.get $2)
        )
       )
       (local.get $1)
       (struct.get $environment241 9
        (local.get $2)
       )
       (struct.get $environment241 10
        (local.get $2)
       )
       (struct.get $environment241 12
        (local.get $2)
       )
       (block (result (ref $type76))
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (ref.test (ref $type83)
          (local.tee $6
           (array.get $type81
            (local.get $4)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (struct.get $type84 0
         (ref.cast (ref $type84)
          (local.get $6)
         )
        )
       )
       (local.get $3)
       (local.get $5)
      )
     )
    )
    (struct.set $type226 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type226 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call10
      (struct.get $type10 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type226 1
          (local.get $3)
         )
        )
       )
      )
      (struct.get $type10 0
       (local.get $7)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (struct.get $environment241 14
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function241
     (struct.get $type171 1
      (struct.get $type175 1
       (struct.get $environment241 14
        (local.get $2)
       )
      )
     )
     (local.get $8)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function245 (type $call10) (param $0 (ref struct)) (result i32)
  (local $1 (ref $environment245))
  (local $2 (ref $type175))
  (local $3 (ref $type64))
  (local $4 (ref $type57))
  (local $5 (ref $type76))
  (local $6 (ref $type61))
  (local $7 (ref $type171))
  (local $8 i64)
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if (result i32)
   (i64.ge_s
    (local.tee $8
     (struct.get $type77 0
      (struct.get $type76 0
       (struct.get $environment245 13
        (local.tee $1
         (ref.cast (ref $environment245)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type62)
      (local.tee $6
       (array.get $type78
        (struct.get $type76 1
         (local.tee $5
          (struct.get $environment245 13
           (local.get $1)
          )
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $4
       (array.get $type65
        (struct.get $type64 0
         (local.tee $3
          (struct.get $type63 0
           (ref.cast (ref $type63)
            (local.get $6)
           )
          )
         )
        )
        (i32.const 4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $4)
      )
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $4
       (array.get $type65
        (struct.get $type64 0
         (local.get $3)
        )
        (i32.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type77 0
     (struct.get $type76 0
      (local.get $5)
     )
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $4)
      )
     )
    )
    (call $function142
     (local.get $3)
    )
    (struct.set $type175 1
     (local.tee $2
      (struct.new_default $type175)
     )
     (struct.new $type171
      (ref.func $function251)
      (struct.new $environment251
       (struct.get $environment245 0
        (local.get $1)
       )
       (struct.get $environment245 1
        (local.get $1)
       )
       (struct.get $environment245 2
        (local.get $1)
       )
       (struct.get $environment245 3
        (local.get $1)
       )
       (struct.get $environment245 4
        (local.get $1)
       )
       (struct.get $environment245 5
        (local.get $1)
       )
       (struct.get $environment245 6
        (local.get $1)
       )
       (struct.get $environment245 7
        (local.get $1)
       )
       (struct.get $environment245 8
        (local.get $1)
       )
       (struct.get $environment245 9
        (local.get $1)
       )
       (struct.get $environment245 10
        (local.get $1)
       )
       (struct.get $environment245 11
        (local.get $1)
       )
       (struct.get $environment245 12
        (local.get $1)
       )
       (struct.get $environment245 14
        (local.get $1)
       )
       (local.get $8)
       (local.get $3)
       (local.get $2)
      )
     )
    )
    (struct.set $type175 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call171
     (struct.get $type171 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type175 1
         (local.get $2)
        )
       )
      )
     )
     (local.get $9)
     (struct.get $type171 0
      (local.get $7)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function251 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment251))
  (local $3 (ref $type208))
  (local $4 (ref $type120))
  (local $5 (ref $type134))
  (local $6 (ref $type134))
  (local $7 (ref $type134))
  (local $8 (ref $type134))
  (local $9 (ref $type134))
  (local $10 (ref $type134))
  (local $11 (ref $type119))
  (local $12 (ref $type81))
  (local $13 (ref $type81))
  (local $14 (ref null $type27))
  (local $15 (ref $type206))
  (local $16 (ref $type57))
  (local $17 i64)
  (local $18 i64)
  (local $19 i64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $18
         (struct.get $environment251 14
          (local.tee $2
           (ref.cast (ref $environment251)
            (local.get $0)
           )
          )
         )
        )
        (local.tee $17
         (i64.sub
          (local.get $18)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $18)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment251 3
      (local.get $2)
     )
    )
    (local.set $6
     (struct.get $environment251 0
      (local.get $2)
     )
    )
    (local.set $7
     (struct.get $environment251 1
      (local.get $2)
     )
    )
    (local.set $8
     (struct.get $environment251 4
      (local.get $2)
     )
    )
    (local.set $9
     (struct.get $environment251 5
      (local.get $2)
     )
    )
    (local.set $10
     (struct.get $environment251 6
      (local.get $2)
     )
    )
    (local.set $19
     (struct.get $environment251 9
      (local.get $2)
     )
    )
    (local.set $11
     (struct.get $environment251 10
      (local.get $2)
     )
    )
    (local.set $4
     (struct.get $environment251 11
      (local.get $2)
     )
    )
    (local.set $12
     (struct.get $environment251 7
      (local.get $2)
     )
    )
    (local.set $13
     (struct.get $environment251 8
      (local.get $2)
     )
    )
    (drop
     (if (result i32)
      (if (result i32)
       (i64.le_s
        (struct.get $environment251 12
         (local.get $2)
        )
        (local.get $18)
       )
       (then
        (if
         (i64.gt_u
          (local.get $17)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i64.ge_s
         (array.get $type120
          (local.get $4)
          (i32.wrap_i64
           (local.get $17)
          )
         )
         (i64.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $17)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $18
          (array.get $type120
           (local.get $4)
           (i32.wrap_i64
            (local.get $17)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $14
        (array.get $type119
         (local.get $11)
         (i32.wrap_i64
          (local.get $18)
         )
        )
       )
       (struct.set $type208 1
        (local.tee $3
         (struct.new_default $type208)
        )
        (struct.new $type206
         (ref.func $function255)
         (struct.new $environment255
          (local.get $6)
          (local.get $7)
          (local.get $5)
          (local.get $8)
          (local.get $9)
          (local.get $10)
          (local.get $1)
          (local.get $19)
          (local.get $12)
          (local.get $13)
          (local.get $17)
          (local.get $3)
         )
        )
       )
       (struct.set $type208 0
        (local.get $3)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type208 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call206
        (struct.get $type206 1
         (local.tee $15
          (ref.as_non_null
           (struct.get $type208 1
            (local.get $3)
           )
          )
         )
        )
        (local.get $14)
        (struct.get $type206 0
         (local.get $15)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $17
         (i64.add
          (local.get $1)
          (i64.const 5)
         )
        )
       )
       (i64.xor
        (local.get $17)
        (i64.const 5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.gt_u
      (local.get $17)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $16
       (array.get $type65
        (struct.get $type64 0
         (struct.get $environment251 15
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $17)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $16)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (struct.get $environment251 16
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function251
     (struct.get $type171 1
      (struct.get $type175 1
       (struct.get $environment251 16
        (local.get $2)
       )
      )
     )
     (local.get $1)
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type226 0
       (struct.get $environment251 13
        (ref.cast (ref $environment251)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function245
     (struct.get $type10 1
      (struct.get $type226 1
       (struct.get $environment251 13
        (ref.cast (ref $environment251)
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (unreachable)
 )
 (func $function255 (type $call206) (param $0 (ref struct)) (param $1 (ref null $type27)) (result i32)
  (local $2 (ref $environment255))
  (local $3 (ref $type61))
  (local $4 (ref $type175))
  (local $5 (ref $type208))
  (local $6 (ref $type134))
  (local $7 (ref $type81))
  (local $8 (ref $type82))
  (local $9 (ref $type76))
  (local $10 (ref $type57))
  (local $11 (ref $type171))
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $scratch (ref $type76))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $12
     (struct.get $type27 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (local.set $6
     (struct.get $environment255 0
      (local.tee $2
       (ref.cast (ref $environment255)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $13
       (struct.get $environment255 7
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.tee $8
       (array.get $type81
        (local.tee $7
         (struct.get $environment255 8
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type62)
       (local.tee $3
        (array.get $type78
         (struct.get $type76 1
          (block (result (ref $type76))
           (local.set $scratch
            (struct.get $type84 0
             (ref.cast (ref $type84)
              (local.get $8)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global291)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global125)
            )
           )
           (if
            (i64.gt_u
             (local.get $12)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $environment255 11
             (local.get $2)
            )
           )
           (local.get $scratch)
          )
         )
         (i32.wrap_i64
          (local.get $12)
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type63)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type62)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type58)
        (local.tee $10
         (array.get $type65
          (struct.get $type64 0
           (struct.get $type63 0
            (ref.cast (ref $type63)
             (local.get $3)
            )
           )
          )
          (i32.const 2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $14
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $10)
        )
       )
      )
      (struct.set $type175 1
       (local.tee $4
        (struct.new_default $type175)
       )
       (struct.new $type171
        (ref.func $function260)
        (struct.new $environment260
         (local.get $6)
         (struct.get $environment255 1
          (local.get $2)
         )
         (struct.get $environment255 2
          (local.get $2)
         )
         (struct.get $environment255 3
          (local.get $2)
         )
         (struct.get $environment255 4
          (local.get $2)
         )
         (struct.get $environment255 6
          (local.get $2)
         )
         (local.get $13)
         (local.get $7)
         (struct.get $environment255 9
          (local.get $2)
         )
         (struct.get $environment255 10
          (local.get $2)
         )
         (local.get $5)
         (local.get $1)
         (local.get $12)
         (local.get $3)
         (local.get $4)
        )
       )
      )
      (struct.set $type175 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type175 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call171
       (struct.get $type171 1
        (local.tee $11
         (ref.as_non_null
          (struct.get $type175 1
           (local.get $4)
          )
         )
        )
       )
       (local.get $14)
       (struct.get $type171 0
        (local.get $11)
       )
      )
     )
     (else
      (local.set $1
       (struct.get $type27 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type208 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function255
       (struct.get $type206 1
        (struct.get $type208 1
         (local.get $5)
        )
       )
       (local.get $1)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function260 (type $call171) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment260))
  (local $3 (ref $type81))
  (local $4 (ref $type81))
  (local $5 (ref $type61))
  (local $6 (ref $type64))
  (local $7 (ref $type57))
  (local $8 (ref null $type27))
  (local $9 i64)
  (local $scratch (ref $type64))
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (drop
     (if (result i32)
      (i64.le_s
       (struct.get $environment260 5
        (local.tee $2
         (ref.cast (ref $environment260)
          (local.get $0)
         )
        )
       )
       (local.get $1)
      )
      (then
       (if (result i32)
        (call $function158
         (local.tee $3
          (struct.get $environment260 7
           (local.get $2)
          )
         )
         (local.tee $4
          (struct.get $environment260 8
           (local.get $2)
          )
         )
         (local.get $1)
         (struct.get $environment260 9
          (local.get $2)
         )
         (struct.get $environment260 5
          (local.get $2)
         )
        )
        (then
         (call $function158
          (local.get $3)
          (local.get $4)
          (struct.get $environment260 6
           (local.get $2)
          )
          (struct.get $environment260 12
           (local.get $2)
          )
          (local.get $1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (ref.test (ref $type62)
      (local.tee $5
       (struct.get $environment260 13
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $7
       (array.get $type65
        (struct.get $type64 0
         (block (result (ref $type64))
          (local.set $scratch
           (struct.get $type63 0
            (ref.cast (ref $type63)
             (local.get $5)
            )
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $1)
              (local.tee $9
               (i64.add
                (local.get $1)
                (i64.const 5)
               )
              )
             )
             (i64.xor
              (local.get $9)
              (i64.const 5)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global115)
           )
          )
          (if
           (i64.gt_u
            (local.get $9)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.get $scratch)
         )
        )
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type175 0
       (struct.get $environment260 14
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function260
     (struct.get $type171 1
      (struct.get $type175 1
       (struct.get $environment260 14
        (local.get $2)
       )
      )
     )
     (local.get $1)
    )
   )
   (else
    (local.set $8
     (struct.get $type27 1
      (struct.get $environment260 11
       (local.tee $2
        (ref.cast (ref $environment260)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (struct.get $environment260 10
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function255
     (struct.get $type206 1
      (struct.get $type208 1
       (struct.get $environment260 10
        (local.get $2)
       )
      )
     )
     (local.get $8)
    )
   )
  )
  (unreachable)
 )
 (func $function265 (type $call229) (param $0 (ref $environment265)) (param $1 (ref null $type27)) (param $2 (ref null $type49)) (result (ref $type124))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type231))
  (local $7 (ref $type57))
  (local $8 (ref $type81))
  (local $9 (ref $type82))
  (local $10 (ref $type134))
  (local $11 (ref $type134))
  (local $12 (ref $type134))
  (local $13 (ref $type134))
  (local $14 (ref $type134))
  (local $15 (ref $type119))
  (local $16 (ref $type120))
  (local $17 (ref $type121))
  (local $18 (ref $type28))
  (local $19 (ref null $type49))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result (ref $type126))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.new $type126
     (local.get $2)
    )
   )
   (else
    (local.set $3
     (struct.get $type27 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment265 5
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.tee $9
       (array.get $type81
        (local.tee $8
         (struct.get $environment265 10
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (struct.get $environment265 3
      (local.get $0)
     )
    )
    (local.set $11
     (struct.get $environment265 0
      (local.get $0)
     )
    )
    (local.set $12
     (struct.get $environment265 1
      (local.get $0)
     )
    )
    (local.set $15
     (struct.get $environment265 6
      (local.get $0)
     )
    )
    (local.set $16
     (struct.get $environment265 7
      (local.get $0)
     )
    )
    (local.set $17
     (struct.get $environment265 8
      (local.get $0)
     )
    )
    (local.set $18
     (struct.get $environment265 9
      (local.get $0)
     )
    )
    (local.set $5
     (struct.get $environment265 11
      (local.get $0)
     )
    )
    (local.set $6
     (struct.get $environment265 12
      (local.get $0)
     )
    )
    (local.set $13
     (struct.get $environment265 13
      (local.get $0)
     )
    )
    (local.set $14
     (struct.get $environment265 2
      (local.get $0)
     )
    )
    (local.set $7
     (call $function145
      (struct.get $type84 0
       (ref.cast (ref $type84)
        (local.get $9)
       )
      )
      (local.get $3)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (local.set $2
     (if (result (ref null $type49))
      (if (result i32)
       (ref.test (ref $type58)
        (local.get $7)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $7)
         )
        )
        (i32.const 1)
       )
      )
      (then
       (local.set $1
        (struct.get $type27 1
         (local.get $1)
        )
       )
       (local.set $19
        (call $function267
         (local.get $11)
         (local.get $12)
         (local.get $14)
         (local.get $10)
         (local.get $13)
         (local.get $3)
         (i64.const 0)
         (local.get $4)
         (local.get $15)
         (local.get $16)
         (local.get $17)
         (local.get $18)
         (local.get $8)
         (local.get $5)
        )
       )
       (call $function293
        (struct.get $type99 1
         (global.get $global561)
        )
        (local.get $19)
        (local.get $2)
       )
      )
      (else
       (local.set $1
        (struct.get $type27 1
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type231 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function265
     (struct.get $type229 0
      (struct.get $type231 1
       (local.get $6)
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function267 (type $43) (param $0 (ref $type134)) (param $1 (ref $type134)) (param $2 (ref $type134)) (param $3 (ref $type134)) (param $4 (ref $type134)) (param $5 i64) (param $6 i64) (param $7 i64) (param $8 (ref $type119)) (param $9 (ref $type120)) (param $10 (ref $type121)) (param $11 (ref $type28)) (param $12 (ref $type81)) (param $13 i64) (result (ref null $type49))
  (local $14 (ref $type67))
  (local $15 (ref $type236))
  (local $16 (ref null $type27))
  (local $17 i64)
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global522)
   )
  )
  (if (result (ref $type49))
   (if (result i32)
    (ref.test (ref $type68)
     (local.tee $14
      (array.get $type121
       (local.get $10)
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type69)
       (local.get $14)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global528)
     )
    )
    (struct.new $type49
     (if (result (ref $type50))
      (i64.lt_s
       (local.get $5)
       (local.get $13)
      )
      (then
       (if
        (ref.test (ref $type68)
         (local.get $14)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global526)
        )
       )
       (drop
        (ref.cast (ref $type69)
         (local.get $14)
        )
       )
       (if
        (i64.gt_u
         (local.get $6)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (array.get $type28
         (local.get $11)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
       (struct.new $type50
        (struct.new_default $type52)
        (struct.new $type50
         (struct.new_default $type54)
         (ref.null none)
        )
       )
      )
      (else
       (if
        (ref.test (ref $type68)
         (local.get $14)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global526)
        )
       )
       (drop
        (ref.cast (ref $type69)
         (local.get $14)
        )
       )
       (struct.new $type50
        (struct.new_default $type52)
        (ref.null none)
       )
      )
     )
     (ref.null none)
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $17
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $17)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (array.get $type120
        (local.get $9)
        (i32.wrap_i64
         (local.get $17)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $16
     (array.get $type119
      (local.get $8)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (struct.set $type236 1
     (local.tee $15
      (struct.new_default $type236)
     )
     (struct.new $type234
      (struct.new $environment274
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $6)
       (local.get $7)
       (local.get $8)
       (local.get $9)
       (local.get $10)
       (local.get $11)
       (local.get $12)
       (local.get $13)
       (local.get $17)
       (local.get $15)
      )
     )
    )
    (struct.set $type236 0
     (local.get $15)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type236 0
       (local.get $15)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function274
     (struct.get $type234 0
      (struct.get $type236 1
       (local.get $15)
      )
     )
     (local.get $16)
     (ref.null none)
    )
   )
  )
 )
 (func $function274 (type $call234) (param $0 (ref $environment274)) (param $1 (ref null $type27)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 (ref $type61))
  (local $4 (ref $type241))
  (local $5 (ref $type236))
  (local $6 (ref $type81))
  (local $7 (ref $type82))
  (local $8 (ref $type76))
  (local $9 (ref $type134))
  (local $10 (ref $type57))
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $scratch (ref $type76))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result (ref null $type49))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $11
     (struct.get $type27 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i64.gt_u
      (local.tee $12
       (struct.get $environment274 6
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.tee $7
       (array.get $type81
        (local.tee $6
         (struct.get $environment274 11
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $12)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type62)
       (local.tee $3
        (array.get $type78
         (struct.get $type76 1
          (block (result (ref $type76))
           (local.set $scratch
            (struct.get $type84 0
             (ref.cast (ref $type84)
              (local.get $7)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global291)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global125)
            )
           )
           (if
            (i64.gt_u
             (local.get $11)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $environment274 14
             (local.get $0)
            )
           )
           (local.get $scratch)
          )
         )
         (i32.wrap_i64
          (local.get $11)
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type63)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (local.set $9
       (struct.get $environment274 0
        (local.get $0)
       )
      )
      (if
       (ref.test (ref $type62)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type58)
        (local.tee $10
         (array.get $type65
          (struct.get $type64 0
           (struct.get $type63 0
            (ref.cast (ref $type63)
             (local.get $3)
            )
           )
          )
          (i32.const 2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $13
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $10)
        )
       )
      )
      (struct.set $type241 1
       (local.tee $4
        (struct.new_default $type241)
       )
       (struct.new $type239
        (struct.new $environment279
         (local.get $9)
         (struct.get $environment274 1
          (local.get $0)
         )
         (struct.get $environment274 2
          (local.get $0)
         )
         (struct.get $environment274 3
          (local.get $0)
         )
         (struct.get $environment274 4
          (local.get $0)
         )
         (struct.get $environment274 5
          (local.get $0)
         )
         (local.get $12)
         (struct.get $environment274 7
          (local.get $0)
         )
         (struct.get $environment274 8
          (local.get $0)
         )
         (struct.get $environment274 9
          (local.get $0)
         )
         (struct.get $environment274 10
          (local.get $0)
         )
         (local.get $6)
         (struct.get $environment274 12
          (local.get $0)
         )
         (struct.get $environment274 13
          (local.get $0)
         )
         (local.get $5)
         (local.get $1)
         (local.get $11)
         (local.get $3)
         (local.get $4)
        )
       )
      )
      (struct.set $type241 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type241 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function279
       (struct.get $type239 0
        (struct.get $type241 1
         (local.get $4)
        )
       )
       (local.get $13)
       (local.get $2)
      )
     )
     (else
      (local.set $1
       (struct.get $type27 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type236 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function274
       (struct.get $type234 0
        (struct.get $type236 1
         (local.get $5)
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function279 (type $call239) (param $0 (ref $environment279)) (param $1 i64) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 i64)
  (local $4 (ref $type57))
  (local $5 (ref $type243))
  (local $6 (ref $type82))
  (local $7 (ref $type134))
  (local $8 (ref $type134))
  (local $9 (ref $type134))
  (local $10 (ref $type134))
  (local $11 (ref $type134))
  (local $12 (ref $type119))
  (local $13 (ref $type120))
  (local $14 (ref $type121))
  (local $15 (ref $type28))
  (local $16 (ref $type81))
  (local $17 (ref null $type49))
  (local $18 (ref null $type49))
  (local $19 (ref $type99))
  (local $20 (ref $type61))
  (local $21 (ref $type64))
  (local $22 (ref null $type27))
  (local $scratch (ref $type64))
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (if (result i32)
      (i64.le_s
       (struct.get $environment279 5
        (local.get $0)
       )
       (local.get $1)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global319)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (ref.test (ref $type83)
         (local.tee $6
          (array.get $type81
           (struct.get $environment279 11
            (local.get $0)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (call $function145
         (struct.get $type84 0
          (ref.cast (ref $type84)
           (local.get $6)
          )
         )
         (struct.get $environment279 13
          (local.get $0)
         )
         (struct.get $environment279 5
          (local.get $0)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global267)
        )
       )
       (if (result i32)
        (ref.test (ref $type58)
         (local.get $4)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.cast (ref $type59)
           (local.get $4)
          )
         )
         (i32.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (local.set $17
       (call $function267
        (local.tee $7
         (struct.get $environment279 0
          (local.get $0)
         )
        )
        (local.tee $8
         (struct.get $environment279 1
          (local.get $0)
         )
        )
        (local.tee $9
         (struct.get $environment279 2
          (local.get $0)
         )
        )
        (local.tee $10
         (struct.get $environment279 3
          (local.get $0)
         )
        )
        (local.tee $11
         (struct.get $environment279 4
          (local.get $0)
         )
        )
        (struct.get $environment279 13
         (local.get $0)
        )
        (struct.get $environment279 5
         (local.get $0)
        )
        (local.get $1)
        (local.tee $12
         (struct.get $environment279 7
          (local.get $0)
         )
        )
        (local.tee $13
         (struct.get $environment279 8
          (local.get $0)
         )
        )
        (local.tee $14
         (struct.get $environment279 9
          (local.get $0)
         )
        )
        (local.tee $15
         (struct.get $environment279 10
          (local.get $0)
         )
        )
        (local.tee $16
         (struct.get $environment279 11
          (local.get $0)
         )
        )
        (local.tee $3
         (struct.get $environment279 12
          (local.get $0)
         )
        )
       )
      )
      (local.set $18
       (call $function267
        (local.get $7)
        (local.get $8)
        (local.get $9)
        (local.get $10)
        (local.get $11)
        (struct.get $environment279 16
         (local.get $0)
        )
        (local.get $1)
        (struct.get $environment279 6
         (local.get $0)
        )
        (local.get $12)
        (local.get $13)
        (local.get $14)
        (local.get $15)
        (local.get $16)
        (local.get $3)
       )
      )
      (struct.set $type243 1
       (local.tee $5
        (struct.new_default $type243)
       )
       (struct.new $type99
        (ref.func $function282)
        (struct.new $environment282
         (struct.get $environment279 17
          (local.get $0)
         )
         (struct.get $environment279 18
          (local.get $0)
         )
         (local.get $1)
         (local.get $17)
         (local.get $5)
        )
       )
      )
      (struct.set $type243 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type243 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call99
       (struct.get $type99 1
        (local.tee $19
         (ref.as_non_null
          (struct.get $type243 1
           (local.get $5)
          )
         )
        )
       )
       (local.get $18)
       (local.get $2)
       (struct.get $type99 0
        (local.get $19)
       )
      )
     )
     (else
      (if
       (ref.test (ref $type62)
        (local.tee $20
         (struct.get $environment279 17
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (ref.test (ref $type58)
        (local.tee $4
         (array.get $type65
          (struct.get $type64 0
           (block (result (ref $type64))
            (local.set $scratch
             (struct.get $type63 0
              (ref.cast (ref $type63)
               (local.get $20)
              )
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.get $1)
                (local.tee $3
                 (i64.add
                  (local.get $1)
                  (i64.const 5)
                 )
                )
               )
               (i64.xor
                (local.get $3)
                (i64.const 5)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global115)
             )
            )
            (if
             (i64.gt_u
              (local.get $3)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.get $scratch)
           )
          )
          (i32.wrap_i64
           (local.get $3)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type59 0
        (ref.cast (ref $type59)
         (local.get $4)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type241 0
         (struct.get $environment279 18
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function279
       (struct.get $type239 0
        (struct.get $type241 1
         (struct.get $environment279 18
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.set $22
     (struct.get $type27 1
      (struct.get $environment279 15
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type236 0
       (struct.get $environment279 14
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function274
     (struct.get $type234 0
      (struct.get $type236 1
       (struct.get $environment279 14
        (local.get $0)
       )
      )
     )
     (local.get $22)
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function282 (type $call99) (param $0 structref) (param $1 (ref null $type49)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $environment282))
  (local $6 (ref $type243))
  (local $7 (ref $type61))
  (local $8 (ref $type64))
  (local $9 (ref $type57))
  (local $10 (ref null $type49))
  (local $11 (ref $type99))
  (local $scratch (ref $type64))
  (drop
   (ref.as_non_null
    (global.get $global544)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (if
     (ref.test (ref $type62)
      (local.tee $7
       (struct.get $environment282 0
        (ref.cast (ref $environment282)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type58)
      (local.tee $9
       (array.get $type65
        (struct.get $type64 0
         (block (result (ref $type64))
          (local.set $scratch
           (struct.get $type63 0
            (ref.cast (ref $type63)
             (local.get $7)
            )
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $3
               (i64.add
                (local.tee $4
                 (struct.get $environment282 2
                  (local.tee $5
                   (ref.cast (ref $environment282)
                    (local.get $0)
                   )
                  )
                 )
                )
                (i64.const 5)
               )
              )
              (local.get $4)
             )
             (i64.xor
              (local.get $3)
              (i64.const 5)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global115)
           )
          )
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.get $scratch)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type59 0
      (ref.cast (ref $type59)
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type241 0
       (struct.get $environment282 1
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function279
     (struct.get $type239 0
      (struct.get $type241 1
       (struct.get $environment282 1
        (local.get $5)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (drop
     (struct.get $type49 0
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global526)
     )
    )
    (local.set $10
     (struct.get $environment282 3
      (local.tee $5
       (ref.cast (ref $environment282)
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type243 1
     (local.tee $6
      (struct.new_default $type243)
     )
     (struct.new $type99
      (ref.func $function286)
      (struct.new $environment286
       (struct.get $environment282 4
        (local.get $5)
       )
       (local.get $1)
       (struct.new $type50
        (struct.new_default $type55)
        (ref.null none)
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type243 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type243 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call99
     (struct.get $type99 1
      (local.tee $11
       (ref.as_non_null
        (struct.get $type243 1
         (local.get $6)
        )
       )
      )
     )
     (local.get $10)
     (local.get $2)
     (struct.get $type99 0
      (local.get $11)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function286 (type $call99) (param $0 structref) (param $1 (ref null $type49)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 (ref $type246))
  (local $4 (ref $environment286))
  (local $5 (ref null $type50))
  (local $6 (ref $type98))
  (local $7 (ref null $type49))
  (local $8 (ref $type50))
  (drop
   (ref.as_non_null
    (global.get $global544)
   )
  )
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.get $type49 1
      (struct.get $environment286 1
       (local.tee $4
        (ref.cast (ref $environment286)
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type243 0
       (struct.get $environment286 0
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function282
     (struct.get $type99 1
      (struct.get $type243 1
       (struct.get $environment286 0
        (local.get $4)
       )
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (local.set $7
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global550)
     )
    )
    (local.set $5
     (struct.get $type49 0
      (local.get $1)
     )
    )
    (local.set $8
     (struct.get $environment286 2
      (local.tee $4
       (ref.cast (ref $environment286)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready553)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global553)
     )
    )
    (struct.set $type246 1
     (local.tee $3
      (struct.new_default $type246)
     )
     (struct.new $type98
      (ref.func $function290)
      (struct.new $environment290
       (local.get $3)
      )
     )
    )
    (struct.set $type246 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type246 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call98
      (struct.get $type98 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type246 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $5)
      (ref.null none)
      (struct.get $type98 0
       (local.get $6)
      )
     )
    )
    (struct.set $type246 1
     (local.tee $3
      (struct.new_default $type246)
     )
     (struct.new $type98
      (ref.func $function292)
      (struct.new $environment292
       (local.get $3)
      )
     )
    )
    (struct.set $type246 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type246 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call98
      (struct.get $type98 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type246 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $5)
      (local.get $8)
      (struct.get $type98 0
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type243 0
       (struct.get $environment286 3
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function286
     (struct.get $type99 1
      (struct.get $type243 1
       (struct.get $environment286 3
        (local.get $4)
       )
      )
     )
     (local.get $7)
     (struct.new $type49
      (local.get $5)
      (local.get $2)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function287 (type $call98) (param $0 structref) (param $1 (ref null $type50)) (param $2 (ref null $type50)) (result (ref null $type50))
  (local $3 (ref $type246))
  (local $4 (ref $type98))
  (if
   (i32.eqz
    (global.get $ready553)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global553)
   )
  )
  (struct.set $type246 1
   (local.tee $3
    (struct.new_default $type246)
   )
   (struct.new $type98
    (ref.func $function290)
    (struct.new $environment290
     (local.get $3)
    )
   )
  )
  (struct.set $type246 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type246 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call98
    (struct.get $type98 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type246 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $1)
    (ref.null none)
    (struct.get $type98 0
     (local.get $4)
    )
   )
  )
  (struct.set $type246 1
   (local.tee $3
    (struct.new_default $type246)
   )
   (struct.new $type98
    (ref.func $function292)
    (struct.new $environment292
     (local.get $3)
    )
   )
  )
  (struct.set $type246 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type246 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call98
   (struct.get $type98 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type246 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type98 0
    (local.get $4)
   )
  )
 )
 (func $function290 (type $call98) (param $0 structref) (param $1 (ref null $type50)) (param $2 (ref null $type50)) (result (ref null $type50))
  (local $3 (ref null $type50))
  (local $4 (ref $type50))
  (if (result (ref null $type50))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type50 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.new $type50
      (struct.get $type50 0
       (local.get $1)
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (struct.get $type246 0
       (struct.get $environment290 0
        (ref.cast (ref $environment290)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function290
     (struct.get $type98 1
      (struct.get $type246 1
       (struct.get $environment290 0
        (ref.cast (ref $environment290)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function292 (type $call98) (param $0 structref) (param $1 (ref null $type50)) (param $2 (ref null $type50)) (result (ref null $type50))
  (local $3 (ref null $type50))
  (local $4 (ref $type50))
  (if (result (ref null $type50))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type50 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.new $type50
      (struct.get $type50 0
       (local.get $1)
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (struct.get $type246 0
       (struct.get $environment292 0
        (ref.cast (ref $environment292)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function292
     (struct.get $type98 1
      (struct.get $type246 1
       (struct.get $environment292 0
        (ref.cast (ref $environment292)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function293 (type $call99) (param $0 structref) (param $1 (ref null $type49)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 (ref $type243))
  (local $4 (ref $type99))
  (if
   (i32.eqz
    (global.get $ready564)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global564)
   )
  )
  (struct.set $type243 1
   (local.tee $3
    (struct.new_default $type243)
   )
   (struct.new $type99
    (ref.func $function296)
    (struct.new $environment296
     (local.get $3)
    )
   )
  )
  (struct.set $type243 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type243 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call99
    (struct.get $type99 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type243 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $1)
    (ref.null none)
    (struct.get $type99 0
     (local.get $4)
    )
   )
  )
  (struct.set $type243 1
   (local.tee $3
    (struct.new_default $type243)
   )
   (struct.new $type99
    (ref.func $function298)
    (struct.new $environment298
     (local.get $3)
    )
   )
  )
  (struct.set $type243 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type243 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call99
   (struct.get $type99 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type243 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type99 0
    (local.get $4)
   )
  )
 )
 (func $function296 (type $call99) (param $0 structref) (param $1 (ref null $type49)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 (ref null $type49))
  (local $4 (ref null $type50))
  (if (result (ref null $type49))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type49 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type243 0
       (struct.get $environment296 0
        (ref.cast (ref $environment296)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function296
     (struct.get $type99 1
      (struct.get $type243 1
       (struct.get $environment296 0
        (ref.cast (ref $environment296)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type49
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function298 (type $call99) (param $0 structref) (param $1 (ref null $type49)) (param $2 (ref null $type49)) (result (ref null $type49))
  (local $3 (ref null $type49))
  (local $4 (ref null $type50))
  (if (result (ref null $type49))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type49 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type243 0
       (struct.get $environment298 0
        (ref.cast (ref $environment298)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function298
     (struct.get $type99 1
      (struct.get $type243 1
       (struct.get $environment298 0
        (ref.cast (ref $environment298)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type49
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function339 (type $20) (param $0 (ref null $type12)) (result i64)
  (local $1 (ref null $type49))
  (local $2 (ref $environment351))
  (local $3 (ref $type163))
  (local $4 (ref $type23))
  (local $5 (ref $type118))
  (local $6 (ref $environment261))
  (local $7 (ref $type138))
  (local $8 (ref null $type93))
  (local $9 (ref $type156))
  (local $10 (ref $type160))
  (local $11 (ref $type175))
  (local $12 (ref $type176))
  (local $13 (ref $type153))
  (local $14 (ref $type57))
  (local $15 (ref $type231))
  (local $16 (ref $type282))
  (local $17 (ref $type161))
  (local $18 (ref $type119))
  (local $19 (ref $type119))
  (local $20 (ref $type119))
  (local $21 (ref $type119))
  (local $22 (ref $type120))
  (local $23 (ref $type120))
  (local $24 (ref $type121))
  (local $25 (ref $type121))
  (local $26 (ref $environment85))
  (local $27 (ref $type94))
  (local $28 (ref $type91))
  (local $29 (ref $type171))
  (local $30 (ref $type28))
  (local $31 (ref $type81))
  (local $32 (ref $type151))
  (local $33 (ref null $type27))
  (local $34 (ref $type124))
  (local $35 i64)
  (local $36 i64)
  (local $37 i64)
  (local $38 i64)
  (local $39 i32)
  (drop
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (struct.set $type138 1
   (local.tee $7
    (struct.new_default $type138)
   )
   (struct.new $type136
    (struct.new $environment60
     (struct.new_default $type134)
     (local.get $7)
    )
   )
  )
  (struct.set $type138 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type138 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $35
   (i64.extend_i32_u
    (array.len
     (local.tee $4
      (call $function60
       (struct.get $type136 0
        (struct.get $type138 1
         (local.get $7)
        )
       )
       (local.tee $8
        (global.get $global144)
       )
       (ref.null none)
      )
     )
    )
   )
  )
  (struct.set $type156 1
   (local.tee $9
    (struct.new_default $type156)
   )
   (struct.new $type154
    (struct.new $environment85
     (local.get $9)
    )
   )
  )
  (struct.set $type156 0
   (local.get $9)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type156 0
     (local.get $9)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $26
   (struct.get $type154 0
    (struct.get $type156 1
     (local.get $9)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $36
       (i64.add
        (local.get $35)
        (local.tee $37
         (if (result i64)
          (ref.is_null
           (local.get $8)
          )
          (then
           (i64.const 0)
          )
          (else
           (local.set $27
            (struct.get $type93 0
             (local.get $8)
            )
           )
           (struct.set $type160 1
            (local.tee $10
             (struct.new_default $type160)
            )
            (struct.new $type158
             (struct.new $environment88
              (struct.get $environment85 0
               (local.get $26)
              )
              (local.get $8)
              (local.get $10)
             )
            )
           )
           (struct.set $type160 0
            (local.get $10)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type160 0
              (local.get $10)
             )
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global169)
            )
           )
           (struct.set $type163 1
            (local.tee $3
             (struct.new_default $type163)
            )
            (struct.new $type161
             (ref.func $function91)
             (struct.new $environment91
              (struct.get $environment88 2
               (struct.get $type158 0
                (struct.get $type160 1
                 (local.get $10)
                )
               )
              )
              (local.tee $28
               (struct.get $type94 0
                (local.get $27)
               )
              )
              (local.get $3)
             )
            )
           )
           (struct.set $type163 0
            (local.get $3)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type163 0
              (local.get $3)
             )
            )
            (then
             (unreachable)
            )
           )
           (call_ref $call161
            (struct.get $type161 1
             (local.tee $17
              (ref.as_non_null
               (struct.get $type163 1
                (local.get $3)
               )
              )
             )
            )
            (struct.get $type91 0
             (local.get $28)
            )
            (i64.const 0)
            (struct.get $type161 0
             (local.get $17)
            )
           )
          )
         )
        )
       )
      )
      (local.get $37)
     )
     (i64.xor
      (local.get $35)
      (local.get $36)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $35)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $35)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $35)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $18
   (array.new_default $type119
    (local.tee $39
     (i32.wrap_i64
      (local.get $35)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $36)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $36)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $38
   (i64.sub
    (local.tee $37
     (i64.extend_i32_u
      (array.len
       (local.get $4)
      )
     )
    )
    (i64.const 1)
   )
  )
  (struct.set $type175 1
   (local.tee $11
    (struct.new_default $type175)
   )
   (struct.new $type171
    (ref.func $function104)
    (struct.new $environment104
     (local.get $4)
     (local.tee $19
      (array.new_default $type119
       (local.get $39)
      )
     )
     (local.tee $22
      (array.new_default $type120
       (local.tee $39
        (i32.wrap_i64
         (local.get $36)
        )
       )
      )
     )
     (local.tee $24
      (array.new $type121
       (global.get $empty68)
       (local.get $39)
      )
     )
     (local.get $37)
     (local.get $11)
    )
   )
  )
  (struct.set $type175 0
   (local.get $11)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type175 0
     (local.get $11)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call171
    (struct.get $type171 1
     (local.tee $29
      (ref.as_non_null
       (struct.get $type175 1
        (local.get $11)
       )
      )
     )
    )
    (local.get $38)
    (struct.get $type171 0
     (local.get $29)
    )
   )
  )
  (struct.set $type176 1
   (local.tee $12
    (struct.new_default $type176)
   )
   (struct.new $type172
    (struct.new $environment107
     (struct.new_default $type134)
     (local.get $4)
     (local.tee $21
      (array.new_default $type119
       (i32.wrap_i64
        (local.get $35)
       )
      )
     )
     (local.get $19)
     (local.get $18)
     (local.get $22)
     (local.get $24)
     (local.get $37)
     (local.get $12)
     (struct.new_default $type134)
    )
   )
  )
  (struct.set $type176 0
   (local.get $12)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type176 0
     (local.get $12)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function107
    (struct.get $type172 0
     (struct.get $type176 1
      (local.get $12)
     )
    )
    (local.get $8)
    (i64.extend_i32_u
     (array.len
      (local.get $4)
     )
    )
   )
  )
  (local.set $5
   (call $function120
    (struct.new $environment120
     (struct.new $type169
      (local.get $4)
      (local.get $21)
      (local.get $19)
      (local.get $18)
      (local.get $22)
      (local.get $24)
     )
    )
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global649)
   )
  )
  (struct.set $type163 1
   (local.tee $3
    (struct.new_default $type163)
   )
   (struct.new $type161
    (ref.func $function347)
    (struct.new $environment347
     (local.get $3)
    )
   )
  )
  (struct.set $type163 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type163 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $35
   (call_ref $call161
    (struct.get $type161 1
     (local.tee $17
      (ref.as_non_null
       (struct.get $type163 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $0)
    (i64.const 0)
    (struct.get $type161 0
     (local.get $17)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global617)
   )
  )
  (struct.set $type153 1
   (local.tee $13
    (struct.new_default $type153)
   )
   (struct.new $type151
    (ref.func $function123)
    (struct.new $environment123
     (global.get $empty14)
     (local.tee $4
      (struct.get $type118 0
       (local.get $5)
      )
     )
     (local.get $13)
    )
   )
  )
  (struct.set $type153 0
   (local.get $13)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type153 0
     (local.get $13)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type123 0
    (struct.get $type118 6
     (local.get $5)
    )
   )
  )
  (local.set $20
   (struct.get $type118 1
    (local.get $5)
   )
  )
  (local.set $23
   (struct.get $type118 2
    (local.get $5)
   )
  )
  (local.set $25
   (struct.get $type118 3
    (local.get $5)
   )
  )
  (local.set $30
   (struct.get $type118 4
    (local.get $5)
   )
  )
  (local.set $31
   (struct.get $type118 5
    (local.get $5)
   )
  )
  (local.set $14
   (call_ref $call151
    (struct.get $type151 1
     (local.tee $32
      (ref.as_non_null
       (struct.get $type153 1
        (local.get $13)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $4)
      )
     )
     (i64.const 1)
    )
    (struct.get $type151 0
     (local.get $32)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global267)
   )
  )
  (if
   (ref.test (ref $type125)
    (local.tee $34
     (if (result (ref $type124))
      (if (result i32)
       (ref.test (ref $type58)
        (local.get $14)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type59)
          (local.get $14)
         )
        )
        (i32.const 1)
       )
      )
      (then
       (if
        (ref.test (ref $type58)
         (local.get $14)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $36
          (struct.get $type59 0
           (ref.cast (ref $type59)
            (local.get $14)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $33
        (array.get $type119
         (local.get $20)
         (i32.wrap_i64
          (local.get $36)
         )
        )
       )
       (struct.set $type231 1
        (local.tee $15
         (struct.new_default $type231)
        )
        (struct.new $type229
         (struct.new $environment265
          (struct.get $environment261 0
           (local.get $6)
          )
          (struct.get $environment261 1
           (local.get $6)
          )
          (struct.get $environment261 2
           (local.get $6)
          )
          (struct.get $environment261 3
           (local.get $6)
          )
          (i64.const 0)
          (local.get $35)
          (local.get $20)
          (local.get $23)
          (local.get $25)
          (local.get $30)
          (local.get $31)
          (i64.extend_i32_u
           (array.len
            (local.get $4)
           )
          )
          (local.get $15)
          (struct.get $environment261 4
           (local.get $6)
          )
         )
        )
       )
       (struct.set $type231 0
        (local.get $15)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type231 0
          (local.get $15)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function265
        (struct.get $type229 0
         (struct.get $type231 1
          (local.get $15)
         )
        )
        (local.get $33)
        (ref.null none)
       )
      )
      (else
       (global.get $empty125)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global656)
   )
  )
  (local.set $1
   (struct.get $type126 0
    (ref.cast (ref $type126)
     (local.get $34)
    )
   )
  )
  (struct.set $type282 1
   (local.tee $16
    (struct.new_default $type282)
   )
   (struct.new $type280
    (struct.new $environment351
     (local.get $16)
    )
   )
  )
  (struct.set $type282 0
   (local.get $16)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type282 0
     (local.get $16)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type280 0
    (struct.get $type282 1
     (local.get $16)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type282 0
       (struct.get $environment351 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type280 0
      (struct.get $type282 1
       (struct.get $environment351 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type49 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type282 0
         (struct.get $environment351 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type280 0
        (struct.get $type282 1
         (struct.get $environment351 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type49 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type282 0
           (struct.get $environment351 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type280 0
          (struct.get $type282 1
           (struct.get $environment351 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type49 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type282 0
             (struct.get $environment351 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type280 0
            (struct.get $type282 1
             (struct.get $environment351 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type49 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type282 0
               (struct.get $environment351 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type280 0
              (struct.get $type282 1
               (struct.get $environment351 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type49 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type282 0
                 (struct.get $environment351 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type280 0
                (struct.get $type282 1
                 (struct.get $environment351 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type49 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type282 0
                   (struct.get $environment351 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type280 0
                  (struct.get $type282 1
                   (struct.get $environment351 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type49 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type282 0
                     (struct.get $environment351 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type280 0
                    (struct.get $type282 1
                     (struct.get $environment351 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type49 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type282 0
                       (struct.get $environment351 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $2
                     (struct.get $type280 0
                      (struct.get $type282 1
                       (struct.get $environment351 0
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $1)
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (local.set $1
                       (struct.get $type49 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type282 0
                         (struct.get $environment351 0
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (struct.get $type280 0
                        (struct.get $type282 1
                         (struct.get $environment351 0
                          (local.get $2)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (local.set $1
                         (struct.get $type49 1
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type282 0
                           (struct.get $environment351 0
                            (local.get $2)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $2
                         (struct.get $type280 0
                          (struct.get $type282 1
                           (struct.get $environment351 0
                            (local.get $2)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (local.set $1
                           (struct.get $type49 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type282 0
                             (struct.get $environment351 0
                              (local.get $2)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $2
                           (struct.get $type280 0
                            (struct.get $type282 1
                             (struct.get $environment351 0
                              (local.get $2)
                             )
                            )
                           )
                          )
                          (if (result i64)
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (local.set $1
                             (struct.get $type49 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type282 0
                               (struct.get $environment351 0
                                (local.get $2)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (return_call $function351
                             (struct.get $type280 0
                              (struct.get $type282 1
                               (struct.get $environment351 0
                                (local.get $2)
                               )
                              )
                             )
                             (local.get $1)
                             (i64.const 13)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function341 (type $call109) (param $0 (ref $type13)) (result (ref $type106))
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (struct.new $type106
   (struct.new $type12
    (local.get $0)
    (ref.null none)
   )
  )
 )
 (func $function342 (type $13) (param $0 (ref $type109)) (param $1 (ref null $type12)) (result (ref null $type107))
  (local $2 (ref $type106))
  (if (result (ref null $type107))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type107
     (call $function341
      (struct.get $type12 0
       (local.get $1)
      )
     )
     (block (result (ref null $type107))
      (local.set $1
       (struct.get $type12 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready644)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global644)
       )
      )
      (call $function342
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function347 (type $call161) (param $0 (ref struct)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type163 0
       (struct.get $environment347 0
        (ref.cast (ref $environment347)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function347
     (struct.get $type161 1
      (struct.get $type163 1
       (struct.get $environment347 0
        (ref.cast (ref $environment347)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function351 (type $call280) (param $0 (ref $environment351)) (param $1 (ref null $type49)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type49 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type282 0
       (struct.get $environment351 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function351
     (struct.get $type280 0
      (struct.get $type282 1
       (struct.get $environment351 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function354 (type $call283) (param $0 (ref $environment354)) (param $1 i64) (param $2 (ref $type57)) (result i64)
  (local $3 i64)
  (local $4 (ref $type23))
  (local $5 (ref null $type12))
  (local $scratch (ref null $type12))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment354 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global669)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (global.get $global661)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $function339
      (block (result (ref null $type12))
       (local.set $scratch
        (call $function356
         (local.tee $4
          (array.new $type23
           (global.get $empty15)
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (i32.const 0)
         (i32.const 1)
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (ref.null none)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global674)
        )
       )
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global640)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type285 0
       (struct.get $environment354 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function354
     (struct.get $type283 0
      (struct.get $type285 1
       (struct.get $environment354 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type59
      (local.get $1)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global267)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (if (result i32)
        (ref.test (ref $type58)
         (local.get $2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.cast (ref $type59)
           (local.get $2)
          )
         )
         (i32.const 1)
        )
       )
       (then
        (if (result i32)
         (i64.eq
          (global.get $global662)
          (i64.const 1)
         )
         (then
          (if
           (ref.test (ref $type58)
            (local.get $2)
           )
           (then
            (unreachable)
           )
          )
          (i64.eq
           (global.get $global663)
           (struct.get $type59 0
            (ref.cast (ref $type59)
             (local.get $2)
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i64.eqz
         (global.get $global662)
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function356 (type $7) (param $0 (ref $type23)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type12)) (result (ref null $type12))
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $type12))
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type12
      (array.get $type23
       (local.get $0)
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function356
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (local.get $7)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type285))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready664)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global664)
   )
  )
  (struct.set $type285 1
   (local.tee $1
    (struct.new_default $type285)
   )
   (struct.new $type283
    (struct.new $environment354
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type285 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type285 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function354
   (struct.get $type283 0
    (struct.get $type285 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (global.get $empty58)
  )
 )
 (func $main
  (local $0 (ref $type14))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type11)
  )
  (global.set $global373
   (struct.new_default $type24)
  )
  (global.set $global186
   (struct.new_default $type31)
  )
  (global.set $ready186
   (i32.const 1)
  )
  (global.set $global376
   (struct.new_default $type32)
  )
  (global.set $ready376
   (i32.const 1)
  )
  (global.set $global669
   (struct.new_default $type33)
  )
  (global.set $global649
   (struct.new_default $type31)
  )
  (global.set $global656
   (struct.new_default $type48)
  )
  (global.set $global267
   (struct.new_default $type56)
  )
  (global.set $global291
   (struct.new_default $type60)
  )
  (global.set $global522
   (struct.new_default $type66)
  )
  (global.set $global112
   (struct.new_default $type71)
  )
  (global.set $global115
   (struct.new_default $type72)
  )
  (global.set $global118
   (struct.new_default $type73)
  )
  (global.set $global121
   (struct.new_default $type74)
  )
  (global.set $global125
   (struct.new_default $type75)
  )
  (global.set $global128
   (struct.new_default $type79)
  )
  (global.set $global319
   (struct.new_default $type80)
  )
  (global.set $global132
   (struct.new_default $type85)
  )
  (global.set $global134
   (struct.new_default $type86)
  )
  (global.set $global137
   (struct.new_default $type87)
  )
  (global.set $global140
   (struct.new_default $type88)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global145
   (struct.new_default $type89)
  )
  (global.set $global147
   (struct.new_default $type90)
  )
  (global.set $global149
   (struct.new_default $type92)
  )
  (global.set $global231
   (struct.new_default $type95)
  )
  (global.set $global526
   (struct.new_default $type96)
  )
  (global.set $global528
   (struct.new_default $type97)
  )
  (global.set $global550
   (struct.new $type98
    (ref.func $function287)
    (ref.null none)
   )
  )
  (global.set $global561
   (struct.new $type99
    (ref.func $function293)
    (ref.null none)
   )
  )
  (global.set $global178
   (struct.new_default $type100)
  )
  (global.set $global271
   (struct.new_default $type101)
  )
  (global.set $global553
   (struct.new_default $type102)
  )
  (global.set $ready553
   (i32.const 1)
  )
  (global.set $global564
   (struct.new_default $type103)
  )
  (global.set $ready564
   (i32.const 1)
  )
  (global.set $global369
   (struct.new_default $type104)
  )
  (global.set $ready369
   (i32.const 1)
  )
  (global.set $global644
   (struct.new_default $type108)
  )
  (global.set $ready644
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global145)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (global.set $global144
   (struct.new $type93
    (struct.new $type94
     (struct.new $type91
      (struct.new $type12
       (global.get $empty15)
       (ref.null none)
      )
      (struct.new $type91
       (struct.new $type12
        (local.tee $0
         (global.get $empty14)
        )
        (struct.new $type12
         (local.get $0)
         (ref.null none)
        )
       )
       (ref.null none)
      )
     )
    )
   )
  )
  (global.set $global162
   (struct.new_default $type110)
  )
  (global.set $global169
   (struct.new_default $type111)
  )
  (global.set $global175
   (struct.new_default $type112)
  )
  (global.set $global325
   (struct.new_default $type113)
  )
  (global.set $global544
   (struct.new_default $type114)
  )
  (global.set $global151
   (struct.new_default $type115)
  )
  (global.set $global617
   (struct.new_default $type129)
  )
  (global.set $global640
   (struct.new_default $type31)
  )
  (global.set $global661
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global662
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global663
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $global674
   (struct.new_default $type131)
  )
  (global.set $global664
   (struct.new_default $type132)
  )
  (global.set $ready664
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

