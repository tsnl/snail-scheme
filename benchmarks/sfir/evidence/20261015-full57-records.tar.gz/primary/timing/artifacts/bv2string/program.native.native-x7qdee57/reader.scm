(module
 (rec
  (type $call79 (func (param (ref $environment129) (ref null $type23) i64) (result i64)))
  (type $type79 (struct (field (ref $environment129))))
  (type $type67 (struct))
  (type $type81 (struct (field (mut i32)) (field (mut (ref null $type79)))))
  (type $environment129 (struct (field (ref $type81))))
  (type $call59 (func (param (ref null $environment125) i64 i64) (result i64)))
  (type $environment125 (struct (field i64) (field (ref $type78))))
  (type $type78 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $environment122 (struct (field i64) (field i64) (field (ref $type68)) (field (ref $type66))))
  (type $type75 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $type68 (struct (field (ref $type42))))
  (type $environment101 (struct (field (ref $type68)) (field i64) (field (ref $type28)) (field (ref $type75))))
  (type $12 (func (param (ref $type67) (ref $type71) (ref $type70) (ref $type70) (ref $type70) (ref $type67) i64 i64 i64) (result i64)))
  (type $environment93 (struct (field (ref $type67)) (field (ref $type71)) (field (ref $type70)) (field (ref $type70)) (field (ref $type70)) (field (ref $type67))))
  (type $type70 (struct))
  (type $type71 (struct (field (ref $type72))))
  (type $type72 (struct (field (mut i64))))
  (type $17 (func (param (ref $type71) i64) (result i64)))
  (type $type23 (struct (field (ref null $type23))))
  (type $type64 (struct (field (ref $call64)) (field (ref struct))))
  (type $type66 (struct (field (mut i32)) (field (mut (ref null $type64)))))
  (type $environment87 (struct (field (ref $type14)) (field (ref $type66))))
  (type $call64 (func (param (ref struct) i64) (result i32)))
  (type $23 (func (param (ref $type28) (ref $type14) i64 i32 i32 i64 i64) (result i32)))
  (type $24 (func (param (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $25 (func (param (ref $type14) i64) (result (ref $type28))))
  (type $26 (func (param (ref $type14) (ref $type28) i64 i32 i32 i64 i64) (result i32)))
  (type $27 (func (param (ref $type28) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $call42 (func (param (ref null $environment93) i64) (result i64)))
  (type $29 (func (param (ref $type28) i64 i32 i32 i64 i64) (result i64)))
  (type $30 (func (param (ref $type28) i64) (result (ref $type14))))
  (type $type28 (struct (field (ref $type29))))
  (type $type29 (array (mut i8)))
  (type $call27 (func (param (ref null $environment101) i64) (result (ref $type28))))
  (type $type16 (array (mut (ref null $type15))))
  (type $35 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct (field (mut (ref null $type23)))))
  (type $type59 (struct (field (ref $call59)) (field (ref null $environment125))))
  (type $type10 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type24 (struct))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct (field (ref $call42)) (field (ref null $environment93))))
  (type $type33 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment101))))
  (type $type26 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $63 (func (param i32)))
 (type $64 (func (param i64) (result i64)))
 (type $65 (func (param i32) (result i64)))
 (type $66 (func))
 (import "benchmark" "write_character" (func $foreign0 (param i32)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type15 30
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
   (i32.const 70)
   (i32.const 65)
   (i32.const 73)
   (i32.const 76)
   (i32.const 69)
   (i32.const 68)
   (i32.const 32)
   (i32.const 84)
   (i32.const 69)
   (i32.const 83)
   (i32.const 84)
   (i32.const 32)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type15 31
   (i32.const 114)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 112)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 118)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $global101 (mut (ref null $type26)) (ref.null none))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global132 (mut (ref null $type33)) (ref.null none))
 (global $global176 (mut (ref null $type42)) (ref.null none))
 (global $global187 (mut (ref null $type42)) (ref.null none))
 (global $global185 (mut (ref null $type42)) (ref.null none))
 (global $global171 (mut (ref null $type43)) (ref.null none))
 (global $global154 (mut (ref null $type44)) (ref.null none))
 (global $global178 (mut (ref null $type45)) (ref.null none))
 (global $global163 (mut (ref null $type43)) (ref.null none))
 (global $global189 (mut (ref null $type46)) (ref.null none))
 (global $global158 (mut (ref null $type47)) (ref.null none))
 (global $global201 (mut (ref null $type49)) (ref.null none))
 (global $global223 (mut (ref null $type42)) (ref.null none))
 (global $global216 (mut (ref null $type50)) (ref.null none))
 (global $global203 (mut (ref null $type51)) (ref.null none))
 (global $global225 (mut (ref null $type52)) (ref.null none))
 (global $global211 (mut (ref null $type53)) (ref.null none))
 (global $global238 (mut (ref null $type55)) (ref.null none))
 (global $global317 (mut (ref null $type24)) (ref.null none))
 (global $global240 (mut (ref null $type56)) (ref.null none))
 (global $global275 (mut (ref null $type57)) (ref.null none))
 (global $global250 (mut (ref null $type58)) (ref.null none))
 (global $global254 (mut (ref null $type10)) (ref.null none))
 (global $global314 (mut (ref null $type59)) (ref.null none))
 (global $global255 (mut (ref null $type60)) (ref.null none))
 (global $global256 (mut (ref null $type61)) (ref.null none))
 (global $global260 (mut (ref null $type62)) (ref.null none))
 (global $global306 (mut i64) (i64.const 0))
 (global $global307 (mut i64) (i64.const 0))
 (global $global308 (mut i64) (i64.const 0))
 (global $global309 (mut (ref null $type42)) (ref.null none))
 (global $ready309 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function40 (type $35) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type15
       (if (result (ref $type15))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type16
           (struct.get $type14 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call27) (param $0 (ref null $environment101)) (param $1 i64) (result (ref $type28))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type28
   (array.new_default $type29
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
 )
 (func $function57 (type $30) (param $0 (ref $type28)) (param $1 i64) (result (ref $type14))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (local $8 (ref null $type16))
  (local $9 (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.or
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
    (i64.gt_s
     (local.get $1)
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (local.set $7
   (call $function59
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $7)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $3
    (i32.sub
     (local.tee $2
      (i32.wrap_i64
       (local.get $7)
      )
     )
     (local.tee $5
      (select
       (i32.const 8192)
       (local.get $2)
       (i32.ge_u
        (local.get $2)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $8
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $8)
      (local.get $4)
      (array.new_default $type15
       (local.tee $6
        (select
         (i32.const 8192)
         (local.get $3)
         (i32.ge_u
          (local.get $3)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $3
       (i32.sub
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global189)
   )
  )
  (drop
   (call $function67
    (local.tee $9
     (struct.new $type14
      (i32.const 1)
      (local.get $2)
      (array.new_default $type15
       (local.get $5)
      )
      (local.get $8)
     )
    )
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.get $9)
 )
 (func $function59 (type $29) (param $0 (ref $type28)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global176)
     )
    )
    (local.set $6
     (if (result i64)
      (i64.lt_u
       (local.tee $6
        (i64.extend_i32_u
         (array.get_u $type29
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
       (i64.const 128)
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (i32.and
         (i64.lt_u
          (local.get $6)
          (i64.const 224)
         )
         (i64.ge_u
          (local.get $6)
          (i64.const 194)
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $6)
            (i64.const 240)
           )
           (i64.ge_u
            (local.get $6)
            (i64.const 224)
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $6)
              (i64.const 245)
             )
             (i64.ge_u
              (local.get $6)
              (i64.const 240)
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (unreachable)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $1)
          (local.get $4)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.get $6)
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global187)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.extend_i32_u
          (array.get_u $type29
           (struct.get $type28 0
            (local.get $0)
           )
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
        )
        (local.tee $9
         (i64.sub
          (local.get $7)
          (local.tee $8
           (if (result i64)
            (i64.eq
             (local.get $6)
             (i64.const 1)
            )
            (then
             (i64.const 0)
            )
            (else
             (if (result i64)
              (i64.eq
               (local.get $6)
               (i64.const 2)
              )
              (then
               (i64.const 192)
              )
              (else
               (select
                (i64.const 224)
                (i64.const 240)
                (i64.eq
                 (local.get $6)
                 (i64.const 3)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function63
      (local.get $0)
      (local.get $4)
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.tee $7
         (i64.add
          (local.get $4)
          (local.get $6)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $4
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $7)
     (local.get $4)
    )
   )
  )
 )
 (func $function61 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i32.and
      (i64.lt_s
       (local.get $1)
       (i64.const 224)
      )
      (i64.ge_s
       (local.get $1)
       (i64.const 194)
      )
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i32.and
        (i64.lt_s
         (local.get $1)
         (i64.const 240)
        )
        (i64.ge_s
         (local.get $1)
         (i64.const 224)
        )
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i32.and
          (i64.lt_s
           (local.get $1)
           (i64.const 245)
          )
          (i64.ge_s
           (local.get $1)
           (i64.const 240)
          )
         )
         (then
          (i64.const 4)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function63 (type $27) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (drop
     (struct.get $type42 1
      (global.get $global185)
     )
    )
    (if (result i32)
     (i64.gt_s
      (if (result i64)
       (i64.eq
        (local.get $2)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 2)
         )
         (then
          (i64.const 128)
         )
         (else
          (select
           (i64.const 2048)
           (i64.const 65536)
           (i64.eq
            (local.get $2)
            (i64.const 3)
           )
          )
         )
        )
       )
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $6)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $6)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.tee $8
        (i64.shl
         (local.get $6)
         (i64.const 6)
        )
       )
       (i64.const 64)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.get $1)
          (local.get $5)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $5)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.add
          (if (result i64)
           (if (result i32)
            (i64.lt_u
             (local.tee $5
              (i64.extend_i32_u
               (array.get_u $type29
                (struct.get $type28 0
                 (local.get $0)
                )
                (i32.wrap_i64
                 (local.get $6)
                )
               )
              )
             )
             (i64.const 128)
            )
            (then
             (i32.const 1)
            )
            (else
             (i64.gt_u
              (local.get $5)
              (i64.const 191)
             )
            )
           )
           (then
            (unreachable)
           )
           (else
            (local.tee $6
             (i64.sub
              (local.get $5)
              (i64.const 128)
             )
            )
           )
          )
          (local.get $8)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $5)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
     (local.get $5)
    )
   )
  )
 )
 (func $function64 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 128)
     )
     (else
      (select
       (i64.const 2048)
       (i64.const 65536)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 192)
     )
     (else
      (select
       (i64.const 224)
       (i64.const 240)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function67 (type $26) (param $0 (ref $type14)) (param $1 (ref $type28)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i32)
  (local $12 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global176)
     )
    )
    (local.set $7
     (if (result i64)
      (i64.lt_u
       (local.tee $7
        (i64.extend_i32_u
         (array.get_u $type29
          (struct.get $type28 0
           (local.get $1)
          )
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
       (i64.const 128)
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (i32.and
         (i64.lt_u
          (local.get $7)
          (i64.const 224)
         )
         (i64.ge_u
          (local.get $7)
          (i64.const 194)
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $7)
            (i64.const 240)
           )
           (i64.ge_u
            (local.get $7)
            (i64.const 224)
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $7)
              (i64.const 245)
             )
             (i64.ge_u
              (local.get $7)
              (i64.const 240)
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (unreachable)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.sub
          (local.get $2)
          (local.get $5)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (local.get $5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.get $7)
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global187)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.extend_i32_u
          (array.get_u $type29
           (struct.get $type28 0
            (local.get $1)
           )
           (i32.wrap_i64
            (local.get $5)
           )
          )
         )
        )
        (local.tee $10
         (i64.sub
          (local.get $8)
          (local.tee $9
           (if (result i64)
            (i64.eq
             (local.get $7)
             (i64.const 1)
            )
            (then
             (i64.const 0)
            )
            (else
             (if (result i64)
              (i64.eq
               (local.get $7)
               (i64.const 2)
              )
              (then
               (i64.const 192)
              )
              (else
               (select
                (i64.const 224)
                (i64.const 240)
                (i64.eq
                 (local.get $7)
                 (i64.const 3)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (call $function63
      (local.get $1)
      (local.get $5)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (local.get $10)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $11
        (i32.wrap_i64
         (local.get $6)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $11)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $11)
      (i32.const 8191)
     )
     (local.get $12)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $8
         (i64.add
          (local.get $5)
          (local.get $7)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $5
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $8)
     (local.get $5)
    )
   )
  )
 )
 (func $function71 (type $27) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if (result i32)
   (i64.eq
    (local.get $5)
    (i64.const 1)
   )
   (then
    (drop
     (struct.get $type42 1
      (global.get $global187)
     )
    )
    (local.set $2
     (i64.add
      (local.get $6)
      (local.tee $5
       (if (result i64)
        (i64.eq
         (local.get $2)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $2)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $2)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $5)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $1)
          (local.get $7)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.tee $9
           (i64.rem_s
            (local.get $6)
            (i64.const 64)
           )
          )
          (i64.const 128)
         )
        )
        (i64.const 128)
       )
       (i64.xor
        (local.get $7)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $8)
     (i64.div_s
      (local.get $6)
      (i64.const 64)
     )
    )
   )
  )
 )
 (func $function72 (type $25) (param $0 (ref $type14)) (param $1 i64) (result (ref $type28))
  (local $2 i64)
  (local $3 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.or
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
    (i64.gt_s
     (local.get $1)
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global216)
   )
  )
  (local.set $2
   (call $function74
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global225)
   )
  )
  (drop
   (struct.get $type27 1
    (global.get $global106)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function77
    (local.tee $3
     (struct.new $type28
      (array.new_default $type29
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
    )
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.get $3)
 )
 (func $function74 (type $24) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i64)
   (i64.gt_s
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
          (local.get $4)
         )
         (i64.xor
          (local.get $6)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type42 1
        (global.get $global223)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $5)
          (local.tee $4
           (i64.add
            (local.get $5)
            (local.tee $7
             (if (result i64)
              (i64.lt_u
               (local.tee $4
                (i64.extend_i32_u
                 (array.get $type15
                  (if (result (ref $type15))
                   (i32.lt_u
                    (local.tee $8
                     (i32.wrap_i64
                      (local.get $4)
                     )
                    )
                    (i32.const 8192)
                   )
                   (then
                    (struct.get $type14 2
                     (local.get $0)
                    )
                   )
                   (else
                    (ref.as_non_null
                     (array.get $type16
                      (struct.get $type14 3
                       (local.get $0)
                      )
                      (i32.sub
                       (i32.shr_u
                        (local.get $8)
                        (i32.const 13)
                       )
                       (i32.const 1)
                      )
                     )
                    )
                   )
                  )
                  (i32.and
                   (local.get $8)
                   (i32.const 8191)
                  )
                 )
                )
               )
               (i64.const 128)
              )
              (then
               (i64.const 1)
              )
              (else
               (if (result i64)
                (i64.lt_u
                 (local.get $4)
                 (i64.const 2048)
                )
                (then
                 (i64.const 2)
                )
                (else
                 (select
                  (i64.const 3)
                  (i64.const 4)
                  (i64.lt_u
                   (local.get $4)
                   (i64.const 65536)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $7)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $1)
      (i64.const 2048)
     )
     (then
      (i64.const 2)
     )
     (else
      (select
       (i64.const 3)
       (i64.const 4)
       (i64.lt_s
        (local.get $1)
        (i64.const 65536)
       )
      )
     )
    )
   )
  )
 )
 (func $function77 (type $23) (param $0 (ref $type28)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global223)
     )
    )
    (drop
     (call $function71
      (local.get $0)
      (local.get $6)
      (local.tee $7
       (if (result i64)
        (i64.lt_u
         (local.tee $7
          (local.tee $8
           (i64.extend_i32_u
            (array.get $type15
             (if (result (ref $type15))
              (i32.lt_u
               (local.tee $9
                (i32.wrap_i64
                 (local.get $5)
                )
               )
               (i32.const 8192)
              )
              (then
               (struct.get $type14 2
                (local.get $1)
               )
              )
              (else
               (ref.as_non_null
                (array.get $type16
                 (struct.get $type14 3
                  (local.get $1)
                 )
                 (i32.sub
                  (i32.shr_u
                   (local.get $9)
                   (i32.const 13)
                  )
                  (i32.const 1)
                 )
                )
               )
              )
             )
             (i32.and
              (local.get $9)
              (i32.const 8191)
             )
            )
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.lt_u
           (local.get $7)
           (i64.const 2048)
          )
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (i64.lt_u
             (local.get $7)
             (i64.const 65536)
            )
           )
          )
         )
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $8
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $5
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $8)
     (local.get $5)
    )
   )
  )
 )
 (func $function87 (type $call64) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type14))
  (local $3 i32)
  (local $4 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (struct.get $environment87 0
       (ref.cast (ref $environment87)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.tee $2
         (struct.get $environment87 0
          (ref.cast (ref $environment87)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $3
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $2)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $2)
          )
          (i32.sub
           (i32.shr_u
            (local.get $3)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $3)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (struct.get $environment87 1
        (ref.cast (ref $environment87)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (struct.get $type64 1
      (struct.get $type66 1
       (struct.get $environment87 1
        (ref.cast (ref $environment87)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function89 (param $0 i32)
  (local $1 (ref $type66))
  (local $2 (ref $type64))
  (local $3 (ref $type60))
  (drop
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global250)
     )
    )
    (struct.set $type66 1
     (local.tee $1
      (struct.new_default $type66)
     )
     (struct.new $type64
      (ref.func $function87)
      (struct.new $environment87
       (global.get $string0)
       (local.get $1)
      )
     )
    )
    (struct.set $type66 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call64
      (struct.get $type64 1
       (local.tee $2
        (ref.as_non_null
         (struct.get $type66 1
          (local.get $1)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type64 0
       (local.get $2)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global250)
     )
    )
    (struct.set $type66 1
     (local.tee $1
      (struct.new_default $type66)
     )
     (struct.new $type64
      (ref.func $function87)
      (struct.new $environment87
       (global.get $string1)
       (local.get $1)
      )
     )
    )
    (struct.set $type66 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call64
      (struct.get $type64 1
       (local.tee $2
        (ref.as_non_null
         (struct.get $type66 1
          (local.get $1)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type64 0
       (local.get $2)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global254)
     )
    )
    (call $foreign0
     (i32.const 10)
    )
    (struct.set $type60 0
     (local.tee $3
      (ref.as_non_null
       (global.get $global255)
      )
     )
     (struct.new $type23
      (struct.get $type60 0
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function92 (type $17) (param $0 (ref $type71)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type72))
  (local.set $3
   (i64.mul
    (local.tee $2
     (struct.get $type72 0
      (struct.get $type71 0
       (local.get $0)
      )
     )
    )
    (i64.const 701)
   )
  )
  (if
   (i64.ne
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $3)
       (local.get $2)
      )
      (i64.const 701)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $3)
      (local.tee $2
       (i64.add
        (local.get $3)
        (i64.const 743483)
       )
      )
     )
     (i64.xor
      (local.get $2)
      (i64.const 743483)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type72 0
   (local.tee $4
    (struct.get $type71 0
     (local.get $0)
    )
   )
   (i64.rem_s
    (local.get $2)
    (i64.const 524288)
   )
  )
  (i64.rem_s
   (i64.div_s
    (struct.get $type72 0
     (local.get $4)
    )
    (i64.const 8)
   )
   (local.get $1)
  )
 )
 (func $function93 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (local $2 (ref $type67))
  (local $3 (ref $type70))
  (local $4 (ref $type70))
  (local $5 (ref $type70))
  (local $6 (ref $type71))
  (local $7 i64)
  (if
   (i64.lt_s
    (local.get $1)
    (i64.const 16384)
   )
   (then
    (drop
     (struct.get $environment93 0
      (local.get $0)
     )
    )
    (drop
     (struct.get $environment93 2
      (local.get $0)
     )
    )
    (drop
     (struct.get $environment93 3
      (local.get $0)
     )
    )
    (drop
     (struct.get $environment93 4
      (local.get $0)
     )
    )
    (return_call $function92
     (struct.get $environment93 1
      (local.get $0)
     )
     (local.get $1)
    )
   )
   (else
    (return_call $function94
     (struct.get $environment93 0
      (local.get $0)
     )
     (block (result (ref $type71))
      (local.set $3
       (struct.get $environment93 2
        (local.get $0)
       )
      )
      (local.set $4
       (struct.get $environment93 3
        (local.get $0)
       )
      )
      (local.set $5
       (struct.get $environment93 4
        (local.get $0)
       )
      )
      (local.set $7
       (call $function92
        (local.tee $6
         (struct.get $environment93 1
          (local.get $0)
         )
        )
        (i64.const 16384)
       )
      )
      (local.get $6)
     )
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (struct.get $environment93 5
      (local.get $0)
     )
     (i64.div_s
      (local.get $1)
      (i64.const 16384)
     )
     (local.get $7)
     (local.get $1)
    )
   )
  )
  (unreachable)
 )
 (func $function94 (type $12) (param $0 (ref $type67)) (param $1 (ref $type71)) (param $2 (ref $type70)) (param $3 (ref $type70)) (param $4 (ref $type70)) (param $5 (ref $type67)) (param $6 i64) (param $7 i64) (param $8 i64) (result i64)
  (local $9 i64)
  (local $10 i64)
  (drop
   (ref.as_non_null
    (global.get $global275)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $6)
   )
   (then
    (i64.rem_s
     (local.get $7)
     (local.get $8)
    )
   )
   (else
    (local.set $9
     (i64.shl
      (local.get $7)
      (i64.const 14)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $9)
         (local.get $7)
        )
        (i64.const 16384)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $7
         (i64.add
          (local.get $9)
          (local.tee $10
           (call $function92
            (local.get $1)
            (i64.const 16384)
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $7)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function94
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 16384)
     )
     (local.get $7)
     (local.get $8)
    )
   )
  )
 )
 (func $function101 (type $call27) (param $0 (ref null $environment101)) (param $1 i64) (result (ref $type28))
  (local $2 (ref $environment101))
  (local $3 (ref $type42))
  (local $4 i64)
  (if (result (ref $type28))
   (i64.eq
    (struct.get $environment101 1
     (local.tee $2
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $environment101 2
     (local.get $2)
    )
   )
   (else
    (local.set $4
     (call_ref $call42
      (struct.get $type42 1
       (local.tee $3
        (struct.get $type68 0
         (struct.get $environment101 0
          (local.get $2)
         )
        )
       )
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (struct.get $environment101 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment101 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (struct.get $type27 1
      (struct.get $type75 1
       (struct.get $environment101 3
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function122 (type $call64) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type75))
  (local $5 (ref $environment122))
  (local $6 (ref $type14))
  (local $7 (ref $type14))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type68))
  (local $11 (ref $type42))
  (local $12 (ref $type27))
  (local $scratch i32)
  (if (result i32)
   (i64.eq
    (struct.get $environment122 0
     (ref.cast (ref $environment122)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (struct.get $environment122 1
      (local.tee $5
       (ref.cast (ref $environment122)
        (local.get $0)
       )
      )
     )
    )
    (local.set $2
     (call_ref $call42
      (struct.get $type42 1
       (local.tee $11
        (struct.get $type68 0
         (local.tee $10
          (struct.get $environment122 2
           (local.get $5)
          )
         )
        )
       )
      )
      (local.get $2)
      (struct.get $type42 0
       (local.get $11)
      )
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type75 1
     (local.tee $4
      (struct.new_default $type75)
     )
     (struct.new $type27
      (ref.func $function101)
      (struct.new $environment101
       (local.get $10)
       (local.get $2)
       (struct.new $type28
        (array.new_default $type29
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type75 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (call_ref $call27
      (struct.get $type27 1
       (local.tee $12
        (ref.as_non_null
         (struct.get $type75 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type27 0
       (local.get $12)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global201)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global238)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $6
     (call $function57
      (local.get $8)
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 0
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (local.set $9
     (call $function72
      (local.get $6)
      (local.tee $2
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $6)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $7
     (call $function57
      (local.get $9)
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 0
         (local.get $9)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global101)
     )
    )
    (call $function89
     (block (result i32)
      (local.set $scratch
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $7)
          )
         )
         (local.get $2)
        )
        (then
         (call $function40
          (local.get $6)
          (local.get $7)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global256)
       )
      )
      (local.get $scratch)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (struct.get $environment122 3
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function122
     (struct.get $type64 1
      (struct.get $type66 1
       (struct.get $environment122 3
        (local.get $5)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function123 (type $call42) (param $0 (ref null $environment93)) (param $1 i64) (result i64)
  (local $2 (ref $type78))
  (local $3 (ref $type59))
  (struct.set $type78 1
   (local.tee $2
    (struct.new_default $type78)
   )
   (struct.new $type59
    (ref.func $function125)
    (struct.new $environment125
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type78 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type78 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call59
   (struct.get $type59 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type78 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type59 0
    (local.get $3)
   )
  )
 )
 (func $function125 (type $call59) (param $0 (ref null $environment125)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type23))
  (local $4 (ref $environment129))
  (local $5 (ref $type75))
  (local $6 (ref $type66))
  (local $7 (ref $type81))
  (local $8 (ref $type14))
  (local $9 (ref $type14))
  (local $10 (ref $type68))
  (local $11 (ref $type28))
  (local $12 (ref $type28))
  (local $13 (ref $type27))
  (local $14 (ref $type64))
  (local $15 i64)
  (local $16 i64)
  (local $17 i32)
  (local $scratch i32)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment125 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (drop
     (struct.get $type59 1
      (global.get $global314)
     )
    )
    (local.set $15
     (call $foreign1
      (global.get $global306)
     )
    )
    (drop
     (struct.get $type59 1
      (global.get $global314)
     )
    )
    (local.set $16
     (call $foreign1
      (global.get $global307)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global260)
     )
    )
    (local.set $2
     (call $function93
      (struct.get $type42 1
       (struct.get $type68 0
        (local.tee $10
         (struct.new $type68
          (struct.new $type42
           (ref.func $function93)
           (struct.new $environment93
            (struct.new_default $type67)
            (struct.new $type71
             (struct.new $type72
              (i64.const 1)
             )
            )
            (struct.new_default $type70)
            (struct.new_default $type70)
            (struct.new_default $type70)
            (struct.new_default $type67)
           )
          )
         )
        )
       )
      )
      (i64.const 10)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type75 1
     (local.tee $5
      (struct.new_default $type75)
     )
     (struct.new $type27
      (ref.func $function101)
      (struct.new $environment101
       (local.get $10)
       (local.get $2)
       (struct.new $type28
        (array.new_default $type29
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $5)
      )
     )
    )
    (struct.set $type75 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type75 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (call_ref $call27
      (struct.get $type27 1
       (local.tee $13
        (ref.as_non_null
         (struct.get $type75 1
          (local.get $5)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type27 0
       (local.get $13)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global201)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global238)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $8
     (call $function57
      (local.get $11)
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 0
         (local.get $11)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (local.set $12
     (call $function72
      (local.get $8)
      (local.tee $2
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $9
     (call $function57
      (local.get $12)
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 0
         (local.get $12)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global101)
     )
    )
    (call $function89
     (block (result i32)
      (local.set $scratch
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $9)
          )
         )
         (local.get $2)
        )
        (then
         (call $function40
          (local.get $8)
          (local.get $9)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global256)
       )
      )
      (local.get $scratch)
     )
    )
    (struct.set $type66 1
     (local.tee $6
      (struct.new_default $type66)
     )
     (struct.new $type64
      (ref.func $function122)
      (struct.new $environment122
       (local.get $15)
       (local.get $16)
       (local.get $10)
       (local.get $6)
      )
     )
    )
    (struct.set $type66 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type66 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call64
      (struct.get $type64 1
       (local.tee $14
        (ref.as_non_null
         (struct.get $type66 1
          (local.get $6)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type64 0
       (local.get $14)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global317)
     )
    )
    (local.set $3
     (struct.get $type60 0
      (global.get $global255)
     )
    )
    (struct.set $type81 1
     (local.tee $7
      (struct.new_default $type81)
     )
     (struct.new $type79
      (struct.new $environment129
       (local.get $7)
      )
     )
    )
    (struct.set $type81 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type79 0
      (struct.get $type81 1
       (local.get $7)
      )
     )
    )
    (local.set $1
     (if (result i64)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $3
        (struct.get $type23 0
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (struct.get $type81 0
          (struct.get $environment129 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type79 0
         (struct.get $type81 1
          (struct.get $environment129 0
           (local.get $4)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $3
          (struct.get $type23 0
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type81 0
            (struct.get $environment129 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type79 0
           (struct.get $type81 1
            (struct.get $environment129 0
             (local.get $4)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $3
            (struct.get $type23 0
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type81 0
              (struct.get $environment129 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type79 0
             (struct.get $type81 1
              (struct.get $environment129 0
               (local.get $4)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $3
              (struct.get $type23 0
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type81 0
                (struct.get $environment129 0
                 (local.get $4)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.get $type79 0
               (struct.get $type81 1
                (struct.get $environment129 0
                 (local.get $4)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $3
                (struct.get $type23 0
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type81 0
                  (struct.get $environment129 0
                   (local.get $4)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.get $type79 0
                 (struct.get $type81 1
                  (struct.get $environment129 0
                   (local.get $4)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $3
                  (struct.get $type23 0
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type81 0
                    (struct.get $environment129 0
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type79 0
                   (struct.get $type81 1
                    (struct.get $environment129 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type23 0
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type81 0
                      (struct.get $environment129 0
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.get $type79 0
                     (struct.get $type81 1
                      (struct.get $environment129 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $3
                      (struct.get $type23 0
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type81 0
                        (struct.get $environment129 0
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (struct.get $type79 0
                       (struct.get $type81 1
                        (struct.get $environment129 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $3
                        (struct.get $type23 0
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type81 0
                          (struct.get $environment129 0
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type79 0
                         (struct.get $type81 1
                          (struct.get $environment129 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $3
                          (struct.get $type23 0
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type81 0
                            (struct.get $environment129 0
                             (local.get $4)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $4
                          (struct.get $type79 0
                           (struct.get $type81 1
                            (struct.get $environment129 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $3
                            (struct.get $type23 0
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type81 0
                              (struct.get $environment129 0
                               (local.get $4)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $4
                            (struct.get $type79 0
                             (struct.get $type81 1
                              (struct.get $environment129 0
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $3
                              (struct.get $type23 0
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type81 0
                                (struct.get $environment129 0
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type79 0
                               (struct.get $type81 1
                                (struct.get $environment129 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $3
                                (struct.get $type23 0
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type81 0
                                  (struct.get $environment129 0
                                   (local.get $4)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $4
                                (struct.get $type79 0
                                 (struct.get $type81 1
                                  (struct.get $environment129 0
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type23 0
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type81 0
                                    (struct.get $environment129 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function129
                                  (struct.get $type79 0
                                   (struct.get $type81 1
                                    (struct.get $environment129 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (struct.get $environment125 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function125
     (struct.get $type59 1
      (struct.get $type78 1
       (struct.get $environment125 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.and
      (i64.eq
       (global.get $global308)
       (local.get $2)
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function126 (type $call59) (param $0 (ref null $environment125)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign1
   (local.get $2)
  )
 )
 (func $function129 (type $call79) (param $0 (ref $environment129)) (param $1 (ref null $type23)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type23 0
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (struct.get $environment129 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function129
     (struct.get $type79 0
      (struct.get $type81 1
       (struct.get $environment129 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type78))
  (local $2 (ref $type59))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready309)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type42 1
    (global.get $global309)
   )
  )
  (struct.set $type78 1
   (local.tee $1
    (struct.new_default $type78)
   )
   (struct.new $type59
    (ref.func $function125)
    (struct.new $environment125
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type78 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type78 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call59
   (struct.get $type59 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type78 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type59 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $global101
   (struct.new_default $type26)
  )
  (global.set $global106
   (struct.new $type27
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $global132
   (struct.new_default $type33)
  )
  (global.set $global176
   (struct.new $type42
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $global187
   (struct.new $type42
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $global185
   (struct.new $type42
    (ref.func $function64)
    (ref.null none)
   )
  )
  (global.set $global171
   (struct.new_default $type43)
  )
  (global.set $global154
   (struct.new_default $type44)
  )
  (global.set $global178
   (struct.new_default $type45)
  )
  (global.set $global163
   (struct.new_default $type43)
  )
  (global.set $global189
   (struct.new_default $type46)
  )
  (global.set $global158
   (struct.new_default $type47)
  )
  (global.set $global201
   (struct.new_default $type49)
  )
  (global.set $global223
   (struct.new $type42
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $global216
   (struct.new_default $type50)
  )
  (global.set $global203
   (struct.new_default $type51)
  )
  (global.set $global225
   (struct.new_default $type52)
  )
  (global.set $global211
   (struct.new_default $type53)
  )
  (global.set $global238
   (struct.new_default $type55)
  )
  (global.set $global317
   (struct.new_default $type24)
  )
  (global.set $global240
   (struct.new_default $type56)
  )
  (global.set $global275
   (struct.new_default $type57)
  )
  (global.set $global250
   (struct.new_default $type58)
  )
  (global.set $global254
   (struct.new_default $type10)
  )
  (global.set $global314
   (struct.new $type59
    (ref.func $function126)
    (ref.null none)
   )
  )
  (global.set $global255
   (struct.new_default $type60)
  )
  (global.set $global256
   (struct.new_default $type61)
  )
  (global.set $global260
   (struct.new_default $type62)
  )
  (global.set $global306
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $global307
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $global308
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $global309
   (struct.new $type42
    (ref.func $function123)
    (ref.null none)
   )
  )
  (global.set $ready309
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

