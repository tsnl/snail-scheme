(module
 (rec
  (type $call124 (func (param (ref $environment162) (ref null $type40) i64) (result i64)))
  (type $type124 (struct (field (ref $environment162))))
  (type $type126 (struct (field (mut i32)) (field (mut (ref null $type124)))))
  (type $environment162 (struct (field (ref $type126))))
  (type $call45 (func (param (ref null $environment158) i64 i64) (result i64)))
  (type $environment158 (struct (field i64) (field (ref $type123))))
  (type $type123 (struct (field (mut i32)) (field (mut (ref null $type45)))))
  (type $type105 (struct (field (ref $environment126))))
  (type $type107 (struct (field (mut i32)) (field (mut (ref null $type105)))))
  (type $call119 (func (param (ref $environment145) i64 i64 (ref null $type40)) (result (ref null $type40))))
  (type $call114 (func (param (ref $environment136) (ref null $type16)) (result i32)))
  (type $type114 (struct (field (ref $environment136))))
  (type $type55 (struct (field (ref $environment133))))
  (type $environment133 (struct (field i64)))
  (type $type116 (struct (field (mut i32)) (field (mut (ref null $type114)))))
  (type $environment136 (struct (field (ref $type55)) (field (ref $type116))))
  (type $environment142 (struct (field (ref $type14))))
  (type $type8 (struct (field (ref $environment122))))
  (type $environment140 (struct (field i64) (field (ref $type41)) (field (ref $type118))))
  (type $environment132 (struct (field (ref null $type16))))
  (type $type16 (struct (field (ref $type17)) (field (ref null $type16))))
  (type $environment122 (struct (field i64) (field (ref $type18)) (field (ref $type62)) (field (ref $type63))))
  (type $type118 (struct (field (mut i32)) (field (mut (ref null $type41)))))
  (type $call110 (func (param (ref $environment129) i64 i64 (ref null $type13) (ref null $type16) (ref null $type40)) (result (ref null $type40))))
  (type $type40 (struct (field (ref null $type40))))
  (type $type119 (struct (field (ref $environment145))))
  (type $environment145 (struct (field (ref $type18)) (field (ref $type14)) (field (ref $type64)) (field (ref $type107)) (field i64) (field (ref $type17)) (field (ref $type121))))
  (type $type110 (struct (field (ref $environment129))))
  (type $environment129 (struct (field i64) (field i64) (field (ref $type14)) (field (ref $type8)) (field (ref $type18)) (field (ref $type17)) (field (ref $type112))))
  (type $environment126 (struct (field i64) (field i64) (field (ref $type18)) (field (ref $type14)) (field (ref $type64)) (field (ref $type41)) (field (ref $type8)) (field (ref $type107))))
  (type $type121 (struct (field (mut i32)) (field (mut (ref null $type119)))))
  (type $type112 (struct (field (mut i32)) (field (mut (ref null $type110)))))
  (type $call105 (func (param (ref $environment126) i64 (ref null $type40)) (result (ref null $type40))))
  (type $environment118 (struct (field i64) (field (ref $type18))))
  (type $type62 (struct (field (ref $environment58))))
  (type $environment116 (struct (field (ref $type18)) (field (ref $type62)) (field (ref $type63))))
  (type $environment109 (struct (field i64)))
  (type $environment102 (struct (field (ref $type17)) (field (ref $type17))))
  (type $environment105 (struct (field i64) (field (ref $type44)) (field (ref $type76))))
  (type $environment100 (struct (field i64) (field (ref $type18)) (field i64) (field (ref $type17))))
  (type $environment98 (struct (field i64) (field (ref $type18))))
  (type $type51 (struct (field (ref $call51)) (field (ref struct))))
  (type $environment96 (struct (field i64) (field (ref $type51)) (field (ref $type18)) (field (ref $type76))))
  (type $call43 (func (param (ref $type44) (ref null $type13)) (result i32)))
  (type $environment86 (struct (field (ref $type17))))
  (type $environment84 (struct (field i64) (field (ref $type14))))
  (type $call51 (func (param (ref struct) i64) (result (ref $type17))))
  (type $call90 (func (param (ref $environment82) (ref null $type13) (ref null $type13)) (result (ref null $type13))))
  (type $environment76 (struct (field (ref $type87)) (field (ref null $type13)) (field i64) (field (ref null $type13))))
  (type $type85 (struct (field (ref $environment73))))
  (type $call63 (func (param (ref null $environment118) (ref $type64) (ref $type59)) (result i32)))
  (type $type63 (struct (field (ref $call63)) (field (ref null $environment118))))
  (type $environment73 (struct (field (ref $type57)) (field (ref $type84)) (field i64) (field (ref $type59)) (field (ref $type87))))
  (type $type87 (struct (field (mut i32)) (field (mut (ref null $type85)))))
  (type $call82 (func (param (ref $environment71) (ref null $type13) i64 i32 (ref $type59)) (result i32)))
  (type $type17 (array (mut i32)))
  (type $call59 (func (param (ref null $environment76) i32) (result i32)))
  (type $type58 (struct (field (ref $environment79))))
  (type $type90 (struct (field (ref $environment82))))
  (type $call70 (func (param (ref null $environment63) i64) (result i64)))
  (type $environment63 (struct (field (ref $type18)) (field (ref $type64)) (field i64) (field i64) (field (ref $type17)) (field (ref $type17)) (field (ref $type79))))
  (type $type18 (array (mut (ref $type17))))
  (type $environment79 (struct (field (ref $type84)) (field (ref null $type13)) (field (ref null $type13)) (field (ref $type59))))
  (type $type92 (struct (field (mut i32)) (field (mut (ref null $type90)))))
  (type $type79 (struct (field (mut i32)) (field (mut (ref null $type70)))))
  (type $environment82 (struct (field (ref $type47)) (field (ref $type92))))
  (type $call57 (func (param (ref $environment59) i64 i64 i32 (ref $type58) (ref $type59)) (result i32)))
  (type $type59 (struct (field (ref $call59)) (field (ref null $environment76))))
  (type $type82 (struct (field (ref $environment71))))
  (type $environment71 (struct (field (ref $type57)) (field (ref $type60)) (field (ref $type84))))
  (type $type60 (struct (field (ref $environment67))))
  (type $environment67 (struct (field (ref $type64)) (field (ref $type63))))
  (type $type57 (struct (field (ref $environment59))))
  (type $environment59 (struct (field (ref $type64)) (field (ref $type18))))
  (type $environment58 (struct (field (ref $type14)) (field (ref $type64))))
  (type $type64 (array (mut i64)))
  (type $type84 (struct (field (mut i32)) (field (mut (ref null $type82)))))
  (type $call62 (func (param (ref $environment58) i64 (ref $type18) (ref $type63)) (result i32)))
  (type $type44 (struct (field (ref $call44)) (field (ref struct))))
  (type $type76 (struct (field (mut i32)) (field (mut (ref null $type44)))))
  (type $type14 (array (mut (ref null $type13))))
  (type $environment56 (struct (field i64) (field (ref $type49)) (field (ref $type14)) (field (ref $type76))))
  (type $call44 (func (param (ref struct) i64) (result i32)))
  (type $call41 (func (param structref i64) (result i32)))
  (type $type13 (struct (field i64) (field (ref null $type13))))
  (type $call47 (func (param (ref null $environment45) i64 (ref null $type13)) (result (ref null $type13))))
  (type $environment45 (struct (field (ref $type73))))
  (type $type47 (struct (field (ref $call47)) (field (ref null $environment45))))
  (type $type73 (struct (field (mut i32)) (field (mut (ref null $type47)))))
  (type $call49 (func (param (ref null $environment142) i64) (result (ref null $type13))))
  (type $type70 (struct (field (ref $call70)) (field (ref null $environment63))))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type61 (struct))
  (type $type56 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type49 (struct (field (ref $call49)) (field (ref null $environment142))))
  (type $type50 (struct))
  (type $type48 (struct))
  (type $type46 (struct))
  (type $type45 (struct (field (ref $call45)) (field (ref null $environment158))))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct (field (ref $call41)) (field structref)))
  (type $type39 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $113 (func (param i64) (result i64)))
 (type $114 (func (param i32) (result i64)))
 (type $115 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type11)) (ref.null none))
 (global $global206 (mut (ref null $type15)) (ref.null none))
 (global $global124 (mut (ref null $type19)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global208 (mut (ref null $type20)) (ref.null none))
 (global $ready208 (mut i32) (i32.const 0))
 (global $global309 (mut (ref null $type39)) (ref.null none))
 (global $global116 (mut (ref null $type41)) (ref.null none))
 (global $global106 (mut (ref null $type42)) (ref.null none))
 (global $global200 (mut (ref null $type43)) (ref.null none))
 (global $ready200 (mut i32) (i32.const 0))
 (global $global306 (mut (ref null $type45)) (ref.null none))
 (global $global187 (mut (ref null $type46)) (ref.null none))
 (global $global119 (mut (ref null $type48)) (ref.null none))
 (global $global203 (mut (ref null $type50)) (ref.null none))
 (global $global111 (mut (ref null $type49)) (ref.null none))
 (global $global228 (mut (ref null $type52)) (ref.null none))
 (global $global280 (mut (ref null $type53)) (ref.null none))
 (global $global274 (mut (ref null $type54)) (ref.null none))
 (global $global165 (mut (ref null $type56)) (ref.null none))
 (global $global109 (mut (ref null $type61)) (ref.null none))
 (global $global149 (mut (ref null $type65)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type66)) (ref.null none))
 (global $global194 (mut (ref null $type68)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global233 (mut (ref null $type69)) (ref.null none))
 (global $global300 (mut i64) (i64.const 0))
 (global $global301 (mut (ref null $type70)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call49) (param $0 (ref null $environment142)) (param $1 i64) (result (ref null $type13))
  (local $2 (ref $type73))
  (local $3 (ref $type47))
  (struct.set $type73 1
   (local.tee $2
    (struct.new_default $type73)
   )
   (struct.new $type47
    (ref.func $function45)
    (struct.new $environment45
     (local.get $2)
    )
   )
  )
  (struct.set $type73 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type73 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call47
   (struct.get $type47 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type73 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $1)
   (ref.null none)
   (struct.get $type47 0
    (local.get $3)
   )
  )
 )
 (func $function45 (type $call47) (param $0 (ref null $environment45)) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 i64)
  (local $4 (ref $type73))
  (drop
   (struct.get $type41 1
    (global.get $global116)
   )
  )
  (if (result (ref null $type13))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type73 0
       (local.tee $4
        (struct.get $environment45 0
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type47 1
      (struct.get $type73 1
       (local.get $4)
      )
     )
     (local.get $3)
     (struct.new $type13
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function46 (type $call41) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function56 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment56))
  (local $3 (ref $type49))
  (local $4 (ref null $type13))
  (local $5 i64)
  (if (result i32)
   (i64.gt_s
    (struct.get $environment56 0
     (local.tee $2
      (ref.cast (ref $environment56)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call49
      (struct.get $type49 1
       (local.tee $3
        (struct.get $environment56 1
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type49 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $environment56 2
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (struct.get $environment56 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (struct.get $type44 1
      (struct.get $type76 1
       (struct.get $environment56 3
        (local.get $2)
       )
      )
     )
     (local.get $5)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function58 (type $call62) (param $0 (ref $environment58)) (param $1 i64) (param $2 (ref $type18)) (param $3 (ref $type63)) (result i32)
  (local $4 (ref $type84))
  (local $5 (ref null $type13))
  (local $6 (ref $type64))
  (drop
   (ref.as_non_null
    (global.get $global165)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (array.get $type14
    (struct.get $environment58 0
     (local.get $0)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (struct.set $type84 1
   (local.tee $4
    (struct.new_default $type84)
   )
   (struct.new $type82
    (struct.new $environment71
     (struct.new $type57
      (struct.new $environment59
       (local.tee $6
        (struct.get $environment58 1
         (local.get $0)
        )
       )
       (local.get $2)
      )
     )
     (struct.new $type60
      (struct.new $environment67
       (local.get $6)
       (local.get $3)
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type84 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type84 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function71
   (struct.get $type82 0
    (struct.get $type84 1
     (local.get $4)
    )
   )
   (local.get $5)
   (i64.const 0)
   (i32.const 1)
   (struct.new $type59
    (ref.func $function69)
    (ref.null none)
   )
  )
 )
 (func $function59 (type $call57) (param $0 (ref $environment59)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type58)) (param $5 (ref $type59)) (result i32)
  (local $6 (ref $environment82))
  (local $7 (ref null $type13))
  (local $8 (ref null $type13))
  (local $9 (ref null $type13))
  (local $10 (ref $type47))
  (local $11 (ref $type79))
  (local $12 (ref $type92))
  (local $13 (ref $environment79))
  (local $14 (ref $type18))
  (local $15 (ref $type64))
  (local $16 (ref $type70))
  (local $17 i64)
  (if
   (i32.eqz
    (global.get $ready149)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type79 1
   (local.tee $11
    (struct.new_default $type79)
   )
   (struct.new $type70
    (ref.func $function63)
    (struct.new $environment63
     (local.tee $14
      (struct.get $environment59 1
       (local.get $0)
      )
     )
     (local.tee $15
      (struct.get $environment59 0
       (local.get $0)
      )
     )
     (local.get $2)
     (local.get $1)
     (array.get $type18
      (local.get $14)
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (array.get $type18
      (local.get $14)
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $11)
    )
   )
  )
  (struct.set $type79 0
   (local.get $11)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type79 0
     (local.get $11)
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $17
     (call_ref $call70
      (struct.get $type70 1
       (local.tee $16
        (ref.as_non_null
         (struct.get $type79 1
          (local.get $11)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type70 0
       (local.get $16)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eq
      (local.get $17)
      (i64.const 1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type64
       (local.get $15)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global187)
       )
      )
      (struct.set $type92 1
       (local.tee $12
        (struct.new_default $type92)
       )
       (struct.new $type90
        (struct.new $environment82
         (struct.new $type47
          (ref.func $primitive0)
          (ref.null none)
         )
         (local.get $12)
        )
       )
      )
      (struct.set $type92 0
       (local.get $12)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type92 0
         (local.get $12)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.get $type90 0
        (struct.get $type92 1
         (local.get $12)
        )
       )
      )
      (local.set $9
       (struct.get $environment79 1
        (local.tee $13
         (struct.get $type58 0
          (local.get $4)
         )
        )
       )
      )
      (local.set $8
       (struct.get $environment79 2
        (local.get $13)
       )
      )
      (if
       (i32.eqz
        (ref.is_null
         (local.get $9)
        )
       )
       (then
        (local.set $7
         (struct.get $type13 1
          (local.get $9)
         )
        )
        (local.set $8
         (call_ref $call47
          (struct.get $type47 1
           (local.tee $10
            (struct.get $environment82 0
             (local.get $6)
            )
           )
          )
          (struct.get $type13 0
           (local.get $9)
          )
          (local.get $8)
          (struct.get $type47 0
           (local.get $10)
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type92 0
           (struct.get $environment82 1
            (local.get $6)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.get $type90 0
          (struct.get $type92 1
           (struct.get $environment82 1
            (local.get $6)
           )
          )
         )
        )
        (local.set $8
         (if (result (ref null $type13))
          (ref.is_null
           (local.get $7)
          )
          (then
           (local.get $8)
          )
          (else
           (local.set $9
            (struct.get $type13 1
             (local.get $7)
            )
           )
           (local.set $7
            (call_ref $call47
             (struct.get $type47 1
              (local.tee $10
               (struct.get $environment82 0
                (local.get $6)
               )
              )
             )
             (struct.get $type13 0
              (local.get $7)
             )
             (local.get $8)
             (struct.get $type47 0
              (local.get $10)
             )
            )
           )
           (if
            (i32.eqz
             (struct.get $type92 0
              (struct.get $environment82 1
               (local.get $6)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (struct.get $type90 0
             (struct.get $type92 1
              (struct.get $environment82 1
               (local.get $6)
              )
             )
            )
           )
           (if (result (ref null $type13))
            (ref.is_null
             (local.get $9)
            )
            (then
             (local.get $7)
            )
            (else
             (local.set $8
              (struct.get $type13 1
               (local.get $9)
              )
             )
             (local.set $7
              (call_ref $call47
               (struct.get $type47 1
                (local.tee $10
                 (struct.get $environment82 0
                  (local.get $6)
                 )
                )
               )
               (struct.get $type13 0
                (local.get $9)
               )
               (local.get $7)
               (struct.get $type47 0
                (local.get $10)
               )
              )
             )
             (if
              (i32.eqz
               (struct.get $type92 0
                (struct.get $environment82 1
                 (local.get $6)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $6
              (struct.get $type90 0
               (struct.get $type92 1
                (struct.get $environment82 1
                 (local.get $6)
                )
               )
              )
             )
             (if (result (ref null $type13))
              (ref.is_null
               (local.get $8)
              )
              (then
               (local.get $7)
              )
              (else
               (local.set $9
                (struct.get $type13 1
                 (local.get $8)
                )
               )
               (local.set $7
                (call_ref $call47
                 (struct.get $type47 1
                  (local.tee $10
                   (struct.get $environment82 0
                    (local.get $6)
                   )
                  )
                 )
                 (struct.get $type13 0
                  (local.get $8)
                 )
                 (local.get $7)
                 (struct.get $type47 0
                  (local.get $10)
                 )
                )
               )
               (if
                (i32.eqz
                 (struct.get $type92 0
                  (struct.get $environment82 1
                   (local.get $6)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $6
                (struct.get $type90 0
                 (struct.get $type92 1
                  (struct.get $environment82 1
                   (local.get $6)
                  )
                 )
                )
               )
               (if (result (ref null $type13))
                (ref.is_null
                 (local.get $9)
                )
                (then
                 (local.get $7)
                )
                (else
                 (local.set $8
                  (struct.get $type13 1
                   (local.get $9)
                  )
                 )
                 (local.set $7
                  (call_ref $call47
                   (struct.get $type47 1
                    (local.tee $10
                     (struct.get $environment82 0
                      (local.get $6)
                     )
                    )
                   )
                   (struct.get $type13 0
                    (local.get $9)
                   )
                   (local.get $7)
                   (struct.get $type47 0
                    (local.get $10)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type92 0
                    (struct.get $environment82 1
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $6
                  (struct.get $type90 0
                   (struct.get $type92 1
                    (struct.get $environment82 1
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (if (result (ref null $type13))
                  (ref.is_null
                   (local.get $8)
                  )
                  (then
                   (local.get $7)
                  )
                  (else
                   (local.set $9
                    (struct.get $type13 1
                     (local.get $8)
                    )
                   )
                   (local.set $7
                    (call_ref $call47
                     (struct.get $type47 1
                      (local.tee $10
                       (struct.get $environment82 0
                        (local.get $6)
                       )
                      )
                     )
                     (struct.get $type13 0
                      (local.get $8)
                     )
                     (local.get $7)
                     (struct.get $type47 0
                      (local.get $10)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type92 0
                      (struct.get $environment82 1
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $6
                    (struct.get $type90 0
                     (struct.get $type92 1
                      (struct.get $environment82 1
                       (local.get $6)
                      )
                     )
                    )
                   )
                   (if (result (ref null $type13))
                    (ref.is_null
                     (local.get $9)
                    )
                    (then
                     (local.get $7)
                    )
                    (else
                     (local.set $8
                      (struct.get $type13 1
                       (local.get $9)
                      )
                     )
                     (local.set $7
                      (call_ref $call47
                       (struct.get $type47 1
                        (local.tee $10
                         (struct.get $environment82 0
                          (local.get $6)
                         )
                        )
                       )
                       (struct.get $type13 0
                        (local.get $9)
                       )
                       (local.get $7)
                       (struct.get $type47 0
                        (local.get $10)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type92 0
                        (struct.get $environment82 1
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $6
                      (struct.get $type90 0
                       (struct.get $type92 1
                        (struct.get $environment82 1
                         (local.get $6)
                        )
                       )
                      )
                     )
                     (if (result (ref null $type13))
                      (ref.is_null
                       (local.get $8)
                      )
                      (then
                       (local.get $7)
                      )
                      (else
                       (local.set $9
                        (struct.get $type13 1
                         (local.get $8)
                        )
                       )
                       (local.set $7
                        (call_ref $call47
                         (struct.get $type47 1
                          (local.tee $10
                           (struct.get $environment82 0
                            (local.get $6)
                           )
                          )
                         )
                         (struct.get $type13 0
                          (local.get $8)
                         )
                         (local.get $7)
                         (struct.get $type47 0
                          (local.get $10)
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type92 0
                          (struct.get $environment82 1
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $6
                        (struct.get $type90 0
                         (struct.get $type92 1
                          (struct.get $environment82 1
                           (local.get $6)
                          )
                         )
                        )
                       )
                       (if (result (ref null $type13))
                        (ref.is_null
                         (local.get $9)
                        )
                        (then
                         (local.get $7)
                        )
                        (else
                         (local.set $8
                          (struct.get $type13 1
                           (local.get $9)
                          )
                         )
                         (local.set $7
                          (call_ref $call47
                           (struct.get $type47 1
                            (local.tee $10
                             (struct.get $environment82 0
                              (local.get $6)
                             )
                            )
                           )
                           (struct.get $type13 0
                            (local.get $9)
                           )
                           (local.get $7)
                           (struct.get $type47 0
                            (local.get $10)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type92 0
                            (struct.get $environment82 1
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (struct.get $type90 0
                           (struct.get $type92 1
                            (struct.get $environment82 1
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (if (result (ref null $type13))
                          (ref.is_null
                           (local.get $8)
                          )
                          (then
                           (local.get $7)
                          )
                          (else
                           (local.set $9
                            (struct.get $type13 1
                             (local.get $8)
                            )
                           )
                           (local.set $7
                            (call_ref $call47
                             (struct.get $type47 1
                              (local.tee $10
                               (struct.get $environment82 0
                                (local.get $6)
                               )
                              )
                             )
                             (struct.get $type13 0
                              (local.get $8)
                             )
                             (local.get $7)
                             (struct.get $type47 0
                              (local.get $10)
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type92 0
                              (struct.get $environment82 1
                               (local.get $6)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $6
                            (struct.get $type90 0
                             (struct.get $type92 1
                              (struct.get $environment82 1
                               (local.get $6)
                              )
                             )
                            )
                           )
                           (if (result (ref null $type13))
                            (ref.is_null
                             (local.get $9)
                            )
                            (then
                             (local.get $7)
                            )
                            (else
                             (local.set $8
                              (struct.get $type13 1
                               (local.get $9)
                              )
                             )
                             (local.set $7
                              (call_ref $call47
                               (struct.get $type47 1
                                (local.tee $10
                                 (struct.get $environment82 0
                                  (local.get $6)
                                 )
                                )
                               )
                               (struct.get $type13 0
                                (local.get $9)
                               )
                               (local.get $7)
                               (struct.get $type47 0
                                (local.get $10)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type92 0
                                (struct.get $environment82 1
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $6
                              (struct.get $type90 0
                               (struct.get $type92 1
                                (struct.get $environment82 1
                                 (local.get $6)
                                )
                               )
                              )
                             )
                             (if (result (ref null $type13))
                              (ref.is_null
                               (local.get $8)
                              )
                              (then
                               (local.get $7)
                              )
                              (else
                               (local.set $9
                                (struct.get $type13 1
                                 (local.get $8)
                                )
                               )
                               (local.set $8
                                (call_ref $call47
                                 (struct.get $type47 1
                                  (local.tee $10
                                   (struct.get $environment82 0
                                    (local.get $6)
                                   )
                                  )
                                 )
                                 (struct.get $type13 0
                                  (local.get $8)
                                 )
                                 (local.get $7)
                                 (struct.get $type47 0
                                  (local.get $10)
                                 )
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type92 0
                                  (struct.get $environment82 1
                                   (local.get $6)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $6
                                (struct.get $type90 0
                                 (struct.get $type92 1
                                  (struct.get $environment82 1
                                   (local.get $6)
                                  )
                                 )
                                )
                               )
                               (if (result (ref null $type13))
                                (ref.is_null
                                 (local.get $9)
                                )
                                (then
                                 (local.get $8)
                                )
                                (else
                                 (local.set $7
                                  (struct.get $type13 1
                                   (local.get $9)
                                  )
                                 )
                                 (local.set $8
                                  (call_ref $call47
                                   (struct.get $type47 1
                                    (local.tee $10
                                     (struct.get $environment82 0
                                      (local.get $6)
                                     )
                                    )
                                   )
                                   (struct.get $type13 0
                                    (local.get $9)
                                   )
                                   (local.get $8)
                                   (struct.get $type47 0
                                    (local.get $10)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type92 0
                                    (struct.get $environment82 1
                                     (local.get $6)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function82
                                  (struct.get $type90 0
                                   (struct.get $type92 1
                                    (struct.get $environment82 1
                                     (local.get $6)
                                    )
                                   )
                                  )
                                  (local.get $7)
                                  (local.get $8)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type84 0
         (struct.get $environment79 0
          (local.get $13)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function71
       (struct.get $type82 0
        (struct.get $type84 1
         (struct.get $environment79 0
          (local.get $13)
         )
        )
       )
       (local.get $8)
       (local.get $1)
       (local.get $3)
       (struct.get $environment79 3
        (local.get $13)
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $17)
        (i64.const 2)
       )
       (then
        (return_call_ref $call59
         (struct.get $type59 1
          (local.get $5)
         )
         (local.get $3)
         (struct.get $type59 0
          (local.get $5)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function63 (type $call70) (param $0 (ref null $environment63)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 (ref $type18))
  (local $8 (ref $type79))
  (local $9 (ref $type17))
  (if (result i64)
   (i64.eq
    (local.get $1)
    (struct.get $environment63 2
     (local.get $0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type17
      (struct.get $environment63 4
       (local.get $0)
      )
      (local.tee $5
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (local.set $7
     (struct.get $environment63 0
      (local.get $0)
     )
    )
    (local.set $3
     (struct.get $environment63 2
      (local.get $0)
     )
    )
    (local.set $4
     (struct.get $environment63 3
      (local.get $0)
     )
    )
    (if (result i64)
     (select
      (local.tee $5
       (array.get $type17
        (struct.get $environment63 5
         (local.get $0)
        )
        (block (result i32)
         (local.set $8
          (struct.get $environment63 6
           (local.get $0)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global106)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (array.get $type64
             (struct.get $environment63 1
              (local.get $0)
             )
             (local.get $5)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
      (i32.eqz
       (local.get $5)
      )
      (local.get $6)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type17
        (array.get $type18
         (local.get $7)
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (select
        (local.tee $5
         (array.get $type17
          (array.get $type18
           (local.get $7)
           (i32.wrap_i64
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
        (i32.eqz
         (local.get $5)
        )
        (local.get $6)
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.tee $2
             (i64.add
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (struct.get $type79 0
           (local.get $8)
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function63
         (struct.get $type70 1
          (struct.get $type79 1
           (local.get $8)
          )
         )
         (local.get $2)
        )
       )
       (else
        (select
         (i64.const 0)
         (i64.const 2)
         (local.get $6)
        )
       )
      )
     )
     (else
      (select
       (i64.const 0)
       (i64.const 2)
       (local.get $6)
      )
     )
    )
   )
  )
 )
 (func $function69 (type $call59) (param $0 (ref null $environment76)) (param $1 i32) (result i32)
  (local.get $1)
 )
 (func $function71 (type $call82) (param $0 (ref $environment71)) (param $1 (ref null $type13)) (param $2 i64) (param $3 i32) (param $4 (ref $type59)) (result i32)
  (local $5 (ref $type87))
  (local $6 (ref $type87))
  (local $7 (ref $environment73))
  (local $8 (ref $environment67))
  (local $9 (ref $type63))
  (local $10 (ref $type57))
  (local $scratch (ref $type57))
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (return_call_ref $call63
     (struct.get $type63 1
      (local.tee $9
       (struct.get $environment67 1
        (local.tee $8
         (struct.get $type60 0
          (struct.get $environment71 1
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (struct.get $environment67 0
      (local.get $8)
     )
     (local.get $4)
     (struct.get $type63 0
      (local.get $9)
     )
    )
   )
   (else
    (struct.set $type87 1
     (local.tee $5
      (struct.new_default $type87)
     )
     (struct.new $type85
      (struct.new $environment73
       (struct.get $environment71 0
        (local.get $0)
       )
       (struct.get $environment71 2
        (local.get $0)
       )
       (local.get $2)
       (local.get $4)
       (local.get $5)
      )
     )
    )
    (struct.set $type87 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type87 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type57 0
      (block (result (ref $type57))
       (local.set $scratch
        (struct.get $environment73 0
         (local.tee $7
          (struct.get $type85 0
           (struct.get $type87 1
            (local.get $5)
           )
          )
         )
        )
       )
       (local.set $4
        (struct.get $environment73 3
         (local.get $7)
        )
       )
       (local.set $6
        (struct.get $environment73 4
         (local.get $7)
        )
       )
       (local.get $scratch)
      )
     )
     (local.tee $2
      (struct.get $type13 0
       (local.get $1)
      )
     )
     (struct.get $environment73 2
      (local.get $7)
     )
     (local.get $3)
     (struct.new $type58
      (struct.new $environment79
       (struct.get $environment73 1
        (local.get $7)
       )
       (ref.null none)
       (local.tee $1
        (struct.get $type13 1
         (local.get $1)
        )
       )
       (block (result (ref $type59))
        (if
         (i32.eqz
          (ref.is_null
           (local.get $1)
          )
         )
         (then
          (local.set $4
           (struct.new $type59
            (ref.func $function76)
            (struct.new $environment76
             (local.get $6)
             (ref.null none)
             (local.get $2)
             (local.get $1)
            )
           )
          )
         )
        )
        (local.get $4)
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (unreachable)
 )
 (func $function76 (type $call59) (param $0 (ref null $environment76)) (param $1 i32) (result i32)
  (local $2 (ref null $type13))
  (local $3 (ref $environment76))
  (local $4 (ref $environment73))
  (local $5 (ref $type59))
  (local $6 (ref $type57))
  (local $7 (ref $type87))
  (local $8 (ref $type13))
  (local $9 i64)
  (local $scratch (ref $type57))
  (local.set $2
   (struct.get $environment76 3
    (local.tee $3
     (ref.as_non_null
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type87 0
     (struct.get $environment76 0
      (local.get $3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function59
   (struct.get $type57 0
    (block (result (ref $type57))
     (local.set $scratch
      (struct.get $environment73 0
       (local.tee $4
        (struct.get $type85 0
         (struct.get $type87 1
          (struct.get $environment76 0
           (local.get $3)
          )
         )
        )
       )
      )
     )
     (local.set $5
      (struct.get $environment73 3
       (local.get $4)
      )
     )
     (local.set $7
      (struct.get $environment73 4
       (local.get $4)
      )
     )
     (local.get $scratch)
    )
   )
   (local.tee $9
    (struct.get $type13 0
     (local.get $2)
    )
   )
   (struct.get $environment73 2
    (local.get $4)
   )
   (local.get $1)
   (struct.new $type58
    (struct.new $environment79
     (struct.get $environment73 1
      (local.get $4)
     )
     (local.tee $8
      (struct.new $type13
       (struct.get $environment76 2
        (local.get $3)
       )
       (struct.get $environment76 1
        (local.get $3)
       )
      )
     )
     (local.tee $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
     (block (result (ref $type59))
      (if
       (i32.eqz
        (ref.is_null
         (local.get $2)
        )
       )
       (then
        (local.set $5
         (struct.new $type59
          (ref.func $function76)
          (struct.new $environment76
           (local.get $7)
           (local.get $8)
           (local.get $9)
           (local.get $2)
          )
         )
        )
       )
      )
      (local.get $5)
     )
    )
   )
   (local.get $5)
  )
 )
 (func $function82 (type $call90) (param $0 (ref $environment82)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type47))
  (if (result (ref null $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (local.set $1
     (call_ref $call47
      (struct.get $type47 1
       (local.tee $4
        (struct.get $environment82 0
         (local.get $0)
        )
       )
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (local.get $2)
      (struct.get $type47 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type92 0
       (struct.get $environment82 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function82
     (struct.get $type90 0
      (struct.get $type92 1
       (struct.get $environment82 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
 )
 (func $function84 (type $call51) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (local $2 (ref null $type13))
  (local $3 (ref $type44))
  (local $4 (ref $type17))
  (local $5 (ref $environment84))
  (local $6 (ref $type14))
  (local $7 i64)
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $2
      (array.get $type14
       (struct.get $environment84 1
        (local.tee $5
         (ref.cast (ref $environment84)
          (local.get $0)
         )
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $7
           (struct.get $environment84 0
            (local.get $5)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (local.tee $4
          (array.new_default $type17
           (i32.wrap_i64
            (local.get $7)
           )
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 1)
        )
        (drop
         (ref.as_non_null
          (global.get $global200)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call44
       (struct.get $type44 1
        (local.tee $3
         (struct.new $type44
          (ref.func $function86)
          (struct.new $environment86
           (local.get $4)
          )
         )
        )
       )
       (struct.get $type13 0
        (local.get $2)
       )
       (struct.get $type44 0
        (local.get $3)
       )
      )
     )
     (local.set $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready200)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global200)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $2)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call44
         (struct.get $type44 1
          (local.get $3)
         )
         (struct.get $type13 0
          (local.get $2)
         )
         (struct.get $type44 0
          (local.get $3)
         )
        )
       )
       (local.set $2
        (struct.get $type13 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready200)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global200)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call44
           (struct.get $type44 1
            (local.get $3)
           )
           (struct.get $type13 0
            (local.get $2)
           )
           (struct.get $type44 0
            (local.get $3)
           )
          )
         )
         (local.set $2
          (struct.get $type13 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready200)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global200)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call44
             (struct.get $type44 1
              (local.get $3)
             )
             (struct.get $type13 0
              (local.get $2)
             )
             (struct.get $type44 0
              (local.get $3)
             )
            )
           )
           (local.set $2
            (struct.get $type13 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready200)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global200)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call44
               (struct.get $type44 1
                (local.get $3)
               )
               (struct.get $type13 0
                (local.get $2)
               )
               (struct.get $type44 0
                (local.get $3)
               )
              )
             )
             (local.set $2
              (struct.get $type13 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready200)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global200)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call44
                 (struct.get $type44 1
                  (local.get $3)
                 )
                 (struct.get $type13 0
                  (local.get $2)
                 )
                 (struct.get $type44 0
                  (local.get $3)
                 )
                )
               )
               (local.set $2
                (struct.get $type13 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready200)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global200)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call44
                   (struct.get $type44 1
                    (local.get $3)
                   )
                   (struct.get $type13 0
                    (local.get $2)
                   )
                   (struct.get $type44 0
                    (local.get $3)
                   )
                  )
                 )
                 (local.set $2
                  (struct.get $type13 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready200)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global200)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call44
                     (struct.get $type44 1
                      (local.get $3)
                     )
                     (struct.get $type13 0
                      (local.get $2)
                     )
                     (struct.get $type44 0
                      (local.get $3)
                     )
                    )
                   )
                   (local.set $2
                    (struct.get $type13 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready200)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global200)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call44
                       (struct.get $type44 1
                        (local.get $3)
                       )
                       (struct.get $type13 0
                        (local.get $2)
                       )
                       (struct.get $type44 0
                        (local.get $3)
                       )
                      )
                     )
                     (local.set $2
                      (struct.get $type13 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready200)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global200)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call_ref $call44
                         (struct.get $type44 1
                          (local.get $3)
                         )
                         (struct.get $type13 0
                          (local.get $2)
                         )
                         (struct.get $type44 0
                          (local.get $3)
                         )
                        )
                       )
                       (local.set $2
                        (struct.get $type13 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready200)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global200)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (call_ref $call44
                           (struct.get $type44 1
                            (local.get $3)
                           )
                           (struct.get $type13 0
                            (local.get $2)
                           )
                           (struct.get $type44 0
                            (local.get $3)
                           )
                          )
                         )
                         (local.set $2
                          (struct.get $type13 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready200)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global200)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (call_ref $call44
                             (struct.get $type44 1
                              (local.get $3)
                             )
                             (struct.get $type13 0
                              (local.get $2)
                             )
                             (struct.get $type44 0
                              (local.get $3)
                             )
                            )
                           )
                           (local.set $2
                            (struct.get $type13 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready200)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global200)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (call_ref $call44
                               (struct.get $type44 1
                                (local.get $3)
                               )
                               (struct.get $type13 0
                                (local.get $2)
                               )
                               (struct.get $type44 0
                                (local.get $3)
                               )
                              )
                             )
                             (local.set $2
                              (struct.get $type13 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready200)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global200)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (call_ref $call44
                                 (struct.get $type44 1
                                  (local.get $3)
                                 )
                                 (struct.get $type13 0
                                  (local.get $2)
                                 )
                                 (struct.get $type44 0
                                  (local.get $3)
                                 )
                                )
                               )
                               (local.set $2
                                (struct.get $type13 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready200)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global200)
                                )
                               )
                               (call $function87
                                (local.get $3)
                                (local.get $2)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $4)
 )
 (func $function86 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $environment86 0
    (ref.cast (ref $environment86)
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (i32.const 0)
 )
 (func $function87 (type $call43) (param $0 (ref $type44)) (param $1 (ref null $type13)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call44
      (struct.get $type44 1
       (local.get $0)
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (struct.get $type44 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready200)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global200)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function96 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment96))
  (local $3 (ref $type51))
  (local $4 (ref $type17))
  (local $5 i64)
  (if (result i32)
   (i64.gt_s
    (struct.get $environment96 0
     (local.tee $2
      (ref.cast (ref $environment96)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call51
      (struct.get $type51 1
       (local.tee $3
        (struct.get $environment96 1
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type51 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (struct.get $environment96 2
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (struct.get $environment96 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (struct.get $type44 1
      (struct.get $type76 1
       (struct.get $environment96 3
        (local.get $2)
       )
      )
     )
     (local.get $5)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function98 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type76))
  (local $3 (ref $environment98))
  (local $4 (ref $type18))
  (local $5 (ref $type44))
  (local $6 i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global228)
   )
  )
  (struct.set $type76 1
   (local.tee $2
    (struct.new_default $type76)
   )
   (struct.new $type44
    (ref.func $function105)
    (struct.new $environment105
     (local.tee $6
      (struct.get $environment98 0
       (local.tee $3
        (ref.cast (ref $environment98)
         (local.get $0)
        )
       )
      )
     )
     (struct.new $type44
      (ref.func $function100)
      (struct.new $environment100
       (local.get $6)
       (local.tee $4
        (struct.get $environment98 1
         (local.get $3)
        )
       )
       (local.get $1)
       (array.get $type18
        (local.get $4)
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type76 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type76 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call44
   (struct.get $type44 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type76 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type44 0
    (local.get $5)
   )
  )
 )
 (func $function100 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type76))
  (local $3 (ref $environment100))
  (local $4 (ref $type17))
  (local $5 (ref $type44))
  (local $6 i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $environment100 0
    (local.tee $3
     (ref.cast (ref $environment100)
      (local.get $0)
     )
    )
   )
  )
  (local.set $4
   (array.get $type18
    (struct.get $environment100 1
     (local.get $3)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment100 2
      (local.get $3)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (array.get $type17
    (local.get $4)
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global228)
     )
    )
    (struct.set $type76 1
     (local.tee $2
      (struct.new_default $type76)
     )
     (struct.new $type44
      (ref.func $function105)
      (struct.new $environment105
       (local.get $6)
       (struct.new $type44
        (ref.func $function102)
        (struct.new $environment102
         (struct.get $environment100 3
          (local.get $3)
         )
         (local.get $4)
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type76 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call44
     (struct.get $type44 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type76 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type44 0
      (local.get $5)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function102 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $type17
    (struct.get $environment102 0
     (ref.cast (ref $environment102)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $environment102 1
      (ref.cast (ref $environment102)
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function105 (type $call44) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $type44))
  (if (result i32)
   (i64.eq
    (struct.get $environment105 0
     (ref.cast (ref $environment105)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call44
      (struct.get $type44 1
       (local.tee $3
        (struct.get $environment105 1
         (ref.cast (ref $environment105)
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type44 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (struct.get $environment105 2
        (ref.cast (ref $environment105)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (struct.get $type44 1
      (struct.get $type76 1
       (struct.get $environment105 2
        (ref.cast (ref $environment105)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function109 (type $call51) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment109 0
      (ref.cast (ref $environment109)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.new_default $type17
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function114 (type $call63) (param $0 (ref null $environment118)) (param $1 (ref $type64)) (param $2 (ref $type59)) (result i32)
  (return_call_ref $call59
   (struct.get $type59 1
    (local.get $2)
   )
   (i32.const 1)
   (struct.get $type59 0
    (local.get $2)
   )
  )
 )
 (func $function116 (type $call41) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment116))
  (return_call $function58
   (struct.get $type62 0
    (struct.get $environment116 1
     (local.tee $2
      (ref.cast (ref $environment116)
       (local.get $0)
      )
     )
    )
   )
   (local.get $1)
   (struct.get $environment116 0
    (local.get $2)
   )
   (struct.get $environment116 2
    (local.get $2)
   )
  )
 )
 (func $function118 (type $call63) (param $0 (ref null $environment118)) (param $1 (ref $type64)) (param $2 (ref $type59)) (result i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type79))
  (local $6 (ref $type18))
  (local $7 (ref $type17))
  (local $8 (ref $type70))
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (local.set $6
   (struct.get $environment118 1
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (struct.get $environment118 0
      (local.get $0)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type79 1
   (local.tee $5
    (struct.new_default $type79)
   )
   (struct.new $type70
    (ref.func $function63)
    (struct.new $environment63
     (local.get $6)
     (local.get $1)
     (local.get $3)
     (local.get $3)
     (local.tee $7
      (array.get $type18
       (local.get $6)
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
     (local.get $7)
     (local.get $5)
    )
   )
  )
  (struct.set $type79 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type79 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (call_ref $call70
      (struct.get $type70 1
       (local.tee $8
        (ref.as_non_null
         (struct.get $type79 1
          (local.get $5)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type70 0
       (local.get $8)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (select
      (local.tee $4
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.eq
       (local.get $3)
       (i64.const 2)
      )
      (local.get $4)
     )
     (then
      (return_call_ref $call59
       (struct.get $type59 1
        (local.get $2)
       )
       (i32.const 1)
       (struct.get $type59 0
        (local.get $2)
       )
      )
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function126 (type $call105) (param $0 (ref $environment126)) (param $1 i64) (param $2 (ref null $type40)) (result (ref null $type40))
  (local $3 (ref $type76))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type112))
  (local $7 (ref $type121))
  (local $8 (ref $type44))
  (local $9 (ref $type14))
  (local $10 (ref $type51))
  (local $11 (ref $type41))
  (local $12 (ref $type17))
  (if (result (ref null $type40))
   (call_ref $call41
    (struct.get $type41 1
     (local.tee $11
      (struct.get $environment126 5
       (local.get $0)
      )
     )
    )
    (local.get $1)
    (struct.get $type41 0
     (local.get $11)
    )
   )
   (then
    (if
     (i64.eq
      (struct.get $environment126 1
       (local.get $0)
      )
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready194)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global194)
       )
      )
      (local.set $9
       (struct.get $environment126 3
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (drop
       (struct.get $type41 1
        (global.get $global116)
       )
      )
      (local.set $4
       (if (result (ref $type18))
        (i64.eqz
         (local.tee $1
          (struct.get $environment126 1
           (local.get $0)
          )
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global206)
          )
         )
         (if
          (i32.eqz
           (global.get $ready208)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global208)
          )
         )
         (array.new_fixed $type18 0)
        )
        (else
         (struct.set $type76 1
          (local.tee $3
           (struct.new_default $type76)
          )
          (struct.new $type44
           (ref.func $function96)
           (struct.new $environment96
            (local.get $1)
            (local.tee $10
             (struct.new $type51
              (ref.func $function84)
              (struct.new $environment84
               (local.get $1)
               (local.get $9)
              )
             )
            )
            (local.tee $4
             (array.new $type18
              (call_ref $call51
               (struct.get $type51 1
                (local.get $10)
               )
               (i64.const 0)
               (struct.get $type51 0
                (local.get $10)
               )
              )
              (block (result i32)
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
         (struct.set $type76 0
          (local.get $3)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type76 0
            (local.get $3)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call_ref $call44
           (struct.get $type44 1
            (local.tee $8
             (ref.as_non_null
              (struct.get $type76 1
               (local.get $3)
              )
             )
            )
           )
           (i64.const 1)
           (struct.get $type44 0
            (local.get $8)
           )
          )
         )
         (local.get $4)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global228)
       )
      )
      (struct.set $type76 1
       (local.tee $3
        (struct.new_default $type76)
       )
       (struct.new $type44
        (ref.func $function105)
        (struct.new $environment105
         (local.get $1)
         (struct.new $type44
          (ref.func $function98)
          (struct.new $environment98
           (local.get $1)
           (local.get $4)
          )
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type76 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type76 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call44
        (struct.get $type44 1
         (local.tee $8
          (ref.as_non_null
           (struct.get $type76 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type44 0
         (local.get $8)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type112 1
       (local.tee $6
        (struct.new_default $type112)
       )
       (struct.new $type110
        (struct.new $environment129
         (struct.get $environment126 0
          (local.get $0)
         )
         (local.get $1)
         (local.get $9)
         (struct.get $environment126 6
          (local.get $0)
         )
         (local.get $4)
         (array.get $type18
          (struct.get $environment126 2
           (local.get $0)
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
         (local.get $6)
        )
       )
      )
      (struct.set $type112 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type112 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function129
       (struct.get $type110 0
        (struct.get $type112 1
         (local.get $6)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (ref.null none)
       (ref.null none)
       (local.get $2)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $12
       (array.get $type18
        (local.tee $5
         (struct.get $environment126 2
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (struct.set $type121 1
       (local.tee $7
        (struct.new_default $type121)
       )
       (struct.new $type119
        (struct.new $environment145
         (local.get $5)
         (struct.get $environment126 3
          (local.get $0)
         )
         (struct.get $environment126 4
          (local.get $0)
         )
         (struct.get $environment126 7
          (local.get $0)
         )
         (local.get $1)
         (local.get $12)
         (local.get $7)
        )
       )
      )
      (struct.set $type121 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type121 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function145
       (struct.get $type119 0
        (struct.get $type121 1
         (local.get $7)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function129 (type $call110) (param $0 (ref $environment129)) (param $1 i64) (param $2 i64) (param $3 (ref null $type13)) (param $4 (ref null $type16)) (param $5 (ref null $type40)) (result (ref null $type40))
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (local $9 (ref $type118))
  (local $10 (ref $type76))
  (local $11 (ref $environment122))
  (local $12 (ref $type49))
  (local $13 (ref $type112))
  (local $14 (ref $type41))
  (local $15 (ref $type14))
  (local $16 (ref $type44))
  (local $17 (ref $type16))
  (if (result (ref null $type40))
   (select
    (local.tee $8
     (i64.eq
      (local.tee $6
       (struct.get $environment129 1
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (i64.eq
     (local.get $2)
     (i64.const 2)
    )
    (local.get $8)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (struct.set $type118 1
     (local.tee $9
      (struct.new_default $type118)
     )
     (struct.new $type41
      (ref.func $function140)
      (struct.new $environment140
       (local.get $6)
       (struct.new $type41
        (ref.func $function132)
        (struct.new $environment132
         (local.get $4)
        )
       )
       (local.get $9)
      )
     )
    )
    (struct.set $type118 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type118 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref null $type40))
     (if (result i32)
      (call_ref $call41
       (struct.get $type41 1
        (local.tee $14
         (ref.as_non_null
          (struct.get $type118 1
           (local.get $9)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type41 0
        (local.get $14)
       )
      )
      (then
       (call $function58
        (struct.get $type62 0
         (struct.get $environment122 2
          (local.tee $11
           (struct.get $type8 0
            (struct.get $environment129 3
             (local.get $0)
            )
           )
          )
         )
        )
        (struct.get $environment122 0
         (local.get $11)
        )
        (struct.get $environment122 1
         (local.get $11)
        )
        (struct.get $environment122 3
         (local.get $11)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $environment129 1
          (local.get $0)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $environment129 2
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $3)
      )
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (drop
       (struct.get $type41 1
        (global.get $global116)
       )
      )
      (drop
       (if (result (ref $type14))
        (i64.eqz
         (local.tee $1
          (struct.get $environment129 0
           (local.get $0)
          )
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (if
          (i32.eqz
           (global.get $ready124)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global124)
          )
         )
         (array.new_fixed $type14 0)
        )
        (else
         (struct.set $type76 1
          (local.tee $10
           (struct.new_default $type76)
          )
          (struct.new $type44
           (ref.func $function56)
           (struct.new $environment56
            (local.get $1)
            (local.tee $12
             (struct.new $type49
              (ref.func $function142)
              (struct.new $environment142
               (struct.get $environment129 2
                (local.get $0)
               )
              )
             )
            )
            (local.tee $15
             (array.new $type14
              (call_ref $call49
               (struct.get $type49 1
                (local.get $12)
               )
               (i64.const 0)
               (struct.get $type49 0
                (local.get $12)
               )
              )
              (block (result i32)
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
            )
            (local.get $10)
           )
          )
         )
         (struct.set $type76 0
          (local.get $10)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type76 0
            (local.get $10)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call_ref $call44
           (struct.get $type44 1
            (local.tee $16
             (ref.as_non_null
              (struct.get $type76 1
               (local.get $10)
              )
             )
            )
           )
           (i64.const 1)
           (struct.get $type44 0
            (local.get $16)
           )
          )
         )
         (local.get $15)
        )
       )
      )
      (struct.new $type40
       (local.get $5)
      )
     )
     (else
      (local.get $5)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $environment129 5
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (struct.new $type16
      (array.get $type18
       (struct.get $environment129 4
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type112 0
       (struct.get $environment129 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call $function129
      (struct.get $type110 0
       (struct.get $type112 1
        (local.tee $13
         (struct.get $environment129 6
          (local.get $0)
         )
        )
       )
      )
      (local.get $6)
      (local.get $7)
      (struct.new $type13
       (local.get $1)
       (local.get $3)
      )
      (local.get $17)
      (local.get $5)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $environment129 5
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type112 0
       (local.get $13)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function129
     (struct.get $type110 0
      (struct.get $type112 1
       (local.get $13)
      )
     )
     (local.get $6)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function132 (type $call41) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref null $type16))
  (local $3 (ref $environment136))
  (local $4 (ref $type17))
  (local $5 (ref $type116))
  (local $6 (ref $type116))
  (local $7 i32)
  (drop
   (ref.as_non_null
    (global.get $global274)
   )
  )
  (local.set $2
   (struct.get $environment132 0
    (ref.cast (ref $environment132)
     (local.get $0)
    )
   )
  )
  (struct.set $type116 1
   (local.tee $6
    (struct.new_default $type116)
   )
   (struct.new $type114
    (struct.new $environment136
     (struct.new $type55
      (struct.new $environment133
       (local.get $1)
      )
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type116 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type116 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type114 0
    (struct.get $type116 1
     (local.get $6)
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $7
      (array.get $type17
       (struct.get $type16 0
        (local.get $2)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment133 0
            (struct.get $type55 0
             (struct.get $environment136 0
              (local.get $3)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (then
      (local.get $7)
     )
     (else
      (local.set $2
       (struct.get $type16 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type116 0
         (local.tee $5
          (struct.get $environment136 1
           (local.get $3)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type114 0
        (struct.get $type116 1
         (local.get $5)
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $7
          (array.get $type17
           (struct.get $type16 0
            (local.get $2)
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.tee $1
               (struct.get $environment133 0
                (struct.get $type55 0
                 (struct.get $environment136 0
                  (local.get $3)
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (local.get $7)
         )
         (else
          (local.set $2
           (struct.get $type16 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type116 0
             (local.tee $5
              (struct.get $environment136 1
               (local.get $3)
              )
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type114 0
            (struct.get $type116 1
             (local.get $5)
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $7
              (array.get $type17
               (struct.get $type16 0
                (local.get $2)
               )
               (block (result i32)
                (if
                 (i64.gt_u
                  (local.tee $1
                   (struct.get $environment133 0
                    (struct.get $type55 0
                     (struct.get $environment136 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
             (then
              (local.get $7)
             )
             (else
              (local.set $2
               (struct.get $type16 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type116 0
                 (local.tee $5
                  (struct.get $environment136 1
                   (local.get $3)
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type114 0
                (struct.get $type116 1
                 (local.get $5)
                )
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $7
                  (array.get $type17
                   (struct.get $type16 0
                    (local.get $2)
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (struct.get $environment133 0
                        (struct.get $type55 0
                         (struct.get $environment136 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (local.set $2
                   (struct.get $type16 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type116 0
                     (local.tee $5
                      (struct.get $environment136 1
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type114 0
                    (struct.get $type116 1
                     (local.get $5)
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $7
                      (array.get $type17
                       (struct.get $type16 0
                        (local.get $2)
                       )
                       (block (result i32)
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (struct.get $environment133 0
                            (struct.get $type55 0
                             (struct.get $environment136 0
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i32.wrap_i64
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (local.set $2
                       (struct.get $type16 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type116 0
                         (local.tee $5
                          (struct.get $environment136 1
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type114 0
                        (struct.get $type116 1
                         (local.get $5)
                        )
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $7
                          (array.get $type17
                           (struct.get $type16 0
                            (local.get $2)
                           )
                           (block (result i32)
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (struct.get $environment133 0
                                (struct.get $type55 0
                                 (struct.get $environment136 0
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $7)
                         )
                         (else
                          (local.set $2
                           (struct.get $type16 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type116 0
                             (local.tee $5
                              (struct.get $environment136 1
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $3
                           (struct.get $type114 0
                            (struct.get $type116 1
                             (local.get $5)
                            )
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $7
                              (array.get $type17
                               (struct.get $type16 0
                                (local.get $2)
                               )
                               (block (result i32)
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (struct.get $environment133 0
                                    (struct.get $type55 0
                                     (struct.get $environment136 0
                                      (local.get $3)
                                     )
                                    )
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i32.wrap_i64
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $7)
                             )
                             (else
                              (local.set $2
                               (struct.get $type16 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type116 0
                                 (local.tee $5
                                  (struct.get $environment136 1
                                   (local.get $3)
                                  )
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $3
                               (struct.get $type114 0
                                (struct.get $type116 1
                                 (local.get $5)
                                )
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $7
                                  (array.get $type17
                                   (struct.get $type16 0
                                    (local.get $2)
                                   )
                                   (block (result i32)
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (struct.get $environment133 0
                                        (struct.get $type55 0
                                         (struct.get $environment136 0
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i32.wrap_i64
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $7)
                                 )
                                 (else
                                  (local.set $2
                                   (struct.get $type16 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (struct.get $type116 0
                                     (local.tee $5
                                      (struct.get $environment136 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $3
                                   (struct.get $type114 0
                                    (struct.get $type116 1
                                     (local.get $5)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $7
                                      (array.get $type17
                                       (struct.get $type16 0
                                        (local.get $2)
                                       )
                                       (block (result i32)
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (struct.get $environment133 0
                                            (struct.get $type55 0
                                             (struct.get $environment136 0
                                              (local.get $3)
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i32.wrap_i64
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $7)
                                     )
                                     (else
                                      (local.set $2
                                       (struct.get $type16 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type116 0
                                         (local.tee $5
                                          (struct.get $environment136 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $3
                                       (struct.get $type114 0
                                        (struct.get $type116 1
                                         (local.get $5)
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if (result i32)
                                         (local.tee $7
                                          (array.get $type17
                                           (struct.get $type16 0
                                            (local.get $2)
                                           )
                                           (block (result i32)
                                            (if
                                             (i64.gt_u
                                              (local.tee $1
                                               (struct.get $environment133 0
                                                (struct.get $type55 0
                                                 (struct.get $environment136 0
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                              )
                                              (i64.const 4294967295)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (i32.wrap_i64
                                             (local.get $1)
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $7)
                                         )
                                         (else
                                          (local.set $2
                                           (struct.get $type16 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (struct.get $type116 0
                                             (local.tee $5
                                              (struct.get $environment136 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type114 0
                                            (struct.get $type116 1
                                             (local.get $5)
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (local.tee $7
                                              (array.get $type17
                                               (struct.get $type16 0
                                                (local.get $2)
                                               )
                                               (block (result i32)
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (struct.get $environment133 0
                                                    (struct.get $type55 0
                                                     (struct.get $environment136 0
                                                      (local.get $3)
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (i64.const 4294967295)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (local.get $7)
                                             )
                                             (else
                                              (local.set $2
                                               (struct.get $type16 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (struct.get $type116 0
                                                 (local.tee $5
                                                  (struct.get $environment136 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (local.set $3
                                               (struct.get $type114 0
                                                (struct.get $type116 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (local.tee $7
                                                  (array.get $type17
                                                   (struct.get $type16 0
                                                    (local.get $2)
                                                   )
                                                   (block (result i32)
                                                    (if
                                                     (i64.gt_u
                                                      (local.tee $1
                                                       (struct.get $environment133 0
                                                        (struct.get $type55 0
                                                         (struct.get $environment136 0
                                                          (local.get $3)
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (i64.const 4294967295)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (i32.wrap_i64
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (local.get $7)
                                                 )
                                                 (else
                                                  (local.set $2
                                                   (struct.get $type16 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (struct.get $type116 0
                                                     (local.tee $5
                                                      (struct.get $environment136 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (local.set $3
                                                   (struct.get $type114 0
                                                    (struct.get $type116 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (local.tee $7
                                                      (array.get $type17
                                                       (struct.get $type16 0
                                                        (local.get $2)
                                                       )
                                                       (block (result i32)
                                                        (if
                                                         (i64.gt_u
                                                          (local.tee $1
                                                           (struct.get $environment133 0
                                                            (struct.get $type55 0
                                                             (struct.get $environment136 0
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (i64.const 4294967295)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (i32.wrap_i64
                                                         (local.get $1)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (local.get $7)
                                                     )
                                                     (else
                                                      (local.set $2
                                                       (struct.get $type16 1
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (struct.get $type116 0
                                                         (local.tee $5
                                                          (struct.get $environment136 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (local.set $3
                                                       (struct.get $type114 0
                                                        (struct.get $type116 1
                                                         (local.get $5)
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $2)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (local.tee $7
                                                          (array.get $type17
                                                           (struct.get $type16 0
                                                            (local.get $2)
                                                           )
                                                           (block (result i32)
                                                            (if
                                                             (i64.gt_u
                                                              (local.tee $1
                                                               (struct.get $environment133 0
                                                                (struct.get $type55 0
                                                                 (struct.get $environment136 0
                                                                  (local.get $3)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                              (i64.const 4294967295)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (i32.wrap_i64
                                                             (local.get $1)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (then
                                                          (local.get $7)
                                                         )
                                                         (else
                                                          (local.set $2
                                                           (struct.get $type16 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (struct.get $type116 0
                                                             (local.tee $5
                                                              (struct.get $environment136 1
                                                               (local.get $3)
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (return_call $function136
                                                           (struct.get $type114 0
                                                            (struct.get $type116 1
                                                             (local.get $5)
                                                            )
                                                           )
                                                           (local.get $2)
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function136 (type $call114) (param $0 (ref $environment136)) (param $1 (ref null $type16)) (result i32)
  (local $2 (ref $type17))
  (local $3 (ref $type116))
  (local $4 i64)
  (local $5 i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $5
      (array.get $type17
       (struct.get $type16 0
        (local.get $1)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $4
           (struct.get $environment133 0
            (struct.get $type55 0
             (struct.get $environment136 0
              (local.get $0)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
     (then
      (local.get $5)
     )
     (else
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type116 0
         (local.tee $3
          (struct.get $environment136 1
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function136
       (struct.get $type114 0
        (struct.get $type116 1
         (local.get $3)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function140 (type $call41) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment140))
  (local $3 (ref $type41))
  (local $4 (ref $type118))
  (local $5 i64)
  (local $6 i32)
  (local.set $3
   (struct.get $environment140 1
    (local.tee $2
     (ref.cast (ref $environment140)
      (local.get $0)
     )
    )
   )
  )
  (if (result i32)
   (local.tee $6
    (i64.eq
     (struct.get $environment140 0
      (local.get $2)
     )
     (local.get $1)
    )
   )
   (then
    (local.get $6)
   )
   (else
    (if (result i32)
     (call_ref $call41
      (struct.get $type41 1
       (local.get $3)
      )
      (local.get $1)
      (struct.get $type41 0
       (local.get $3)
      )
     )
     (then
      (local.set $4
       (struct.get $environment140 2
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $5
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type118 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function140
       (struct.get $type41 1
        (struct.get $type118 1
         (local.get $4)
        )
       )
       (local.get $5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function142 (type $call49) (param $0 (ref null $environment142)) (param $1 i64) (result (ref null $type13))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (struct.get $environment142 0
    (local.get $0)
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function145 (type $call119) (param $0 (ref $environment145)) (param $1 i64) (param $2 i64) (param $3 (ref null $type40)) (result (ref null $type40))
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (local $9 (ref $type14))
  (local $10 (ref $type121))
  (local $11 (ref null $type13))
  (local $12 (ref $type17))
  (local $13 (ref $type17))
  (local $14 (ref $type64))
  (if (result (ref null $type40))
   (i64.eq
    (local.tee $4
     (struct.get $environment145 4
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type64
     (struct.get $environment145 2
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $2)
    )
    (local.set $1
     (i64.add
      (local.tee $2
       (struct.get $environment145 4
        (local.get $0)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type107 0
       (struct.get $environment145 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function126
     (struct.get $type105 0
      (struct.get $type107 1
       (struct.get $environment145 3
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type121 0
       (struct.get $environment145 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function145
      (struct.get $type119 0
       (struct.get $type121 1
        (local.tee $10
         (struct.get $environment145 6
          (local.get $0)
         )
        )
       )
      )
      (local.get $4)
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $13
     (array.get $type18
      (struct.get $environment145 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.get $environment145 1
      (local.get $0)
     )
    )
    (local.set $4
     (struct.get $environment145 4
      (local.get $0)
     )
    )
    (local.set $12
     (struct.get $environment145 5
      (local.get $0)
     )
    )
    (if
     (i64.ne
      (local.tee $6
       (array.get $type64
        (local.tee $14
         (struct.get $environment145 2
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (i64.const 2)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $9)
       (local.tee $8
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (struct.new $type13
        (local.get $4)
        (array.get $type14
         (local.get $9)
         (local.get $8)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $13)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 1)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.add
            (local.get $6)
            (i64.const 1)
           )
          )
          (local.get $6)
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type64
       (local.get $14)
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $5)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type121 0
         (local.get $10)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function145
        (struct.get $type119 0
         (struct.get $type121 1
          (local.get $10)
         )
        )
        (local.get $5)
        (local.get $2)
        (local.get $3)
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 2)
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (local.get $12)
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 1)
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.get $9)
         (local.tee $8
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (struct.new $type13
          (local.get $1)
          (array.get $type14
           (local.get $9)
           (local.get $8)
          )
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.tee $5
             (i64.add
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $5)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $7
             (i64.add
              (local.get $2)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
           (i64.xor
            (local.get $7)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (struct.get $type121 0
           (local.get $10)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (call $function145
          (struct.get $type119 0
           (struct.get $type121 1
            (local.get $10)
           )
          )
          (local.get $5)
          (local.get $7)
          (local.get $3)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $11
         (struct.get $type13 1
          (array.get $type14
           (local.get $9)
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.get $9)
         (i32.wrap_i64
          (local.get $4)
         )
         (local.get $11)
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (local.get $12)
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 0)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type64
       (local.get $14)
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $6)
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $13)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $11
       (struct.get $type13 1
        (array.get $type14
         (local.get $9)
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $9)
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $11)
      )
     )
    )
    (if
     (i64.ne
      (local.get $2)
      (i64.const 2)
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $9)
       (local.tee $8
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (struct.new $type13
        (local.get $1)
        (array.get $type14
         (local.get $9)
         (local.get $8)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $12)
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 1)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $6)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $2)
          (local.tee $5
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type121 0
         (local.get $10)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function145
        (struct.get $type119 0
         (struct.get $type121 1
          (local.get $10)
         )
        )
        (local.get $6)
        (local.get $5)
        (local.get $3)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $12)
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 0)
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $11
       (struct.get $type13 1
        (array.get $type14
         (local.get $9)
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $9)
       (i32.wrap_i64
        (local.get $4)
       )
       (local.get $11)
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function156 (type $call70) (param $0 (ref null $environment63)) (param $1 i64) (result i64)
  (local $2 (ref $type123))
  (local $3 (ref $type45))
  (struct.set $type123 1
   (local.tee $2
    (struct.new_default $type123)
   )
   (struct.new $type45
    (ref.func $function158)
    (struct.new $environment158
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type123 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type123 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call45
   (struct.get $type45 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type123 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type45 0
    (local.get $3)
   )
  )
 )
 (func $function158 (type $call45) (param $0 (ref null $environment158)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type40))
  (local $4 (ref $environment162))
  (local $5 (ref $type76))
  (local $6 (ref $type18))
  (local $7 (ref $type107))
  (local $8 (ref $type126))
  (local $9 (ref $type44))
  (local $10 (ref $type14))
  (local $11 (ref $type49))
  (local $12 (ref $type51))
  (local $13 (ref $type62))
  (local $14 i64)
  (local $15 i64)
  (local $16 i32)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment158 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $15
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $15)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type45 1
      (global.get $global306)
     )
    )
    (drop
     (struct.get $environment158 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global300)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global233)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (drop
     (struct.get $type41 1
      (global.get $global116)
     )
    )
    (local.set $6
     (if (result (ref $type18))
      (i64.eqz
       (local.get $1)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global206)
        )
       )
       (if
        (i32.eqz
         (global.get $ready208)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global208)
        )
       )
       (array.new_fixed $type18 0)
      )
      (else
       (struct.set $type76 1
        (local.tee $5
         (struct.new_default $type76)
        )
        (struct.new $type44
         (ref.func $function96)
         (struct.new $environment96
          (local.get $1)
          (local.tee $12
           (struct.new $type51
            (ref.func $function109)
            (struct.new $environment109
             (local.get $1)
            )
           )
          )
          (local.tee $6
           (array.new $type18
            (call_ref $call51
             (struct.get $type51 1
              (local.get $12)
             )
             (i64.const 0)
             (struct.get $type51 0
              (local.get $12)
             )
            )
            (block (result i32)
             (if
              (i64.gt_u
               (local.get $1)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
          (local.get $5)
         )
        )
       )
       (struct.set $type76 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type76 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (call_ref $call44
         (struct.get $type44 1
          (local.tee $9
           (ref.as_non_null
            (struct.get $type76 1
             (local.get $5)
            )
           )
          )
         )
         (i64.const 1)
         (struct.get $type44 0
          (local.get $9)
         )
        )
       )
       (local.get $6)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (array.new_default $type14
      (local.tee $16
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $14
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $14)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (local.set $11
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (drop
     (struct.get $type41 1
      (global.get $global116)
     )
    )
    (struct.set $type107 1
     (local.tee $7
      (struct.new_default $type107)
     )
     (struct.new $type105
      (struct.new $environment126
       (local.get $1)
       (local.get $2)
       (local.get $6)
       (local.get $10)
       (array.new_default $type64
        (local.get $16)
       )
       (struct.new $type41
        (ref.func $function116)
        (struct.new $environment116
         (local.get $6)
         (local.tee $13
          (struct.new $type62
           (struct.new $environment58
            (if (result (ref $type14))
             (i64.eqz
              (local.get $14)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (if
               (i32.eqz
                (global.get $ready124)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global124)
               )
              )
              (array.new_fixed $type14 0)
             )
             (else
              (struct.set $type76 1
               (local.tee $5
                (struct.new_default $type76)
               )
               (struct.new $type44
                (ref.func $function56)
                (struct.new $environment56
                 (local.get $14)
                 (local.get $11)
                 (local.tee $10
                  (array.new $type14
                   (call_ref $call49
                    (struct.get $type49 1
                     (local.get $11)
                    )
                    (i64.const 0)
                    (struct.get $type49 0
                     (local.get $11)
                    )
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.get $14)
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $14)
                    )
                   )
                  )
                 )
                 (local.get $5)
                )
               )
              )
              (struct.set $type76 0
               (local.get $5)
               (i32.const 1)
              )
              (if
               (i32.eqz
                (struct.get $type76 0
                 (local.get $5)
                )
               )
               (then
                (unreachable)
               )
              )
              (drop
               (call_ref $call44
                (struct.get $type44 1
                 (local.tee $9
                  (ref.as_non_null
                   (struct.get $type76 1
                    (local.get $5)
                   )
                  )
                 )
                )
                (i64.const 1)
                (struct.get $type44 0
                 (local.get $9)
                )
               )
              )
              (local.get $10)
             )
            )
            (block (result (ref (exact $type64)))
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.new_default $type64
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
           )
          )
         )
         (struct.new $type63
          (ref.func $function114)
          (ref.null none)
         )
        )
       )
       (struct.new $type8
        (struct.new $environment122
         (local.get $2)
         (local.get $6)
         (local.get $13)
         (struct.new $type63
          (ref.func $function118)
          (struct.new $environment118
           (local.get $2)
           (local.get $6)
          )
         )
        )
       )
       (local.get $7)
      )
     )
    )
    (struct.set $type107 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type107 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function126
      (struct.get $type105 0
       (struct.get $type107 1
        (local.get $7)
       )
      )
      (i64.const 0)
      (ref.null none)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global309)
     )
    )
    (struct.set $type126 1
     (local.tee $8
      (struct.new_default $type126)
     )
     (struct.new $type124
      (struct.new $environment162
       (local.get $8)
      )
     )
    )
    (struct.set $type126 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type126 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type124 0
      (struct.get $type126 1
       (local.get $8)
      )
     )
    )
    (local.set $1
     (if (result i64)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $3
        (struct.get $type40 0
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (struct.get $type126 0
          (struct.get $environment162 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type124 0
         (struct.get $type126 1
          (struct.get $environment162 0
           (local.get $4)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $3
          (struct.get $type40 0
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type126 0
            (struct.get $environment162 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type124 0
           (struct.get $type126 1
            (struct.get $environment162 0
             (local.get $4)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $3
            (struct.get $type40 0
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type126 0
              (struct.get $environment162 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type124 0
             (struct.get $type126 1
              (struct.get $environment162 0
               (local.get $4)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $3
              (struct.get $type40 0
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type126 0
                (struct.get $environment162 0
                 (local.get $4)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.get $type124 0
               (struct.get $type126 1
                (struct.get $environment162 0
                 (local.get $4)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $3
                (struct.get $type40 0
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type126 0
                  (struct.get $environment162 0
                   (local.get $4)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.get $type124 0
                 (struct.get $type126 1
                  (struct.get $environment162 0
                   (local.get $4)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $3
                  (struct.get $type40 0
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type126 0
                    (struct.get $environment162 0
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type124 0
                   (struct.get $type126 1
                    (struct.get $environment162 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type40 0
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type126 0
                      (struct.get $environment162 0
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.get $type124 0
                     (struct.get $type126 1
                      (struct.get $environment162 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $3
                      (struct.get $type40 0
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type126 0
                        (struct.get $environment162 0
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (struct.get $type124 0
                       (struct.get $type126 1
                        (struct.get $environment162 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $3
                        (struct.get $type40 0
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type126 0
                          (struct.get $environment162 0
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type124 0
                         (struct.get $type126 1
                          (struct.get $environment162 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $3
                          (struct.get $type40 0
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type126 0
                            (struct.get $environment162 0
                             (local.get $4)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $4
                          (struct.get $type124 0
                           (struct.get $type126 1
                            (struct.get $environment162 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $3
                            (struct.get $type40 0
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type126 0
                              (struct.get $environment162 0
                               (local.get $4)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $4
                            (struct.get $type124 0
                             (struct.get $type126 1
                              (struct.get $environment162 0
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $3
                              (struct.get $type40 0
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type126 0
                                (struct.get $environment162 0
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type124 0
                               (struct.get $type126 1
                                (struct.get $environment162 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $3
                                (struct.get $type40 0
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type126 0
                                  (struct.get $environment162 0
                                   (local.get $4)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $4
                                (struct.get $type124 0
                                 (struct.get $type126 1
                                  (struct.get $environment162 0
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type40 0
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type126 0
                                    (struct.get $environment162 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function162
                                  (struct.get $type124 0
                                   (struct.get $type126 1
                                    (struct.get $environment162 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type123 0
       (struct.get $environment158 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function158
     (struct.get $type45 1
      (struct.get $type123 1
       (struct.get $environment158 1
        (local.get $0)
       )
      )
     )
     (local.get $15)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function159 (type $call45) (param $0 (ref null $environment158)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function162 (type $call124) (param $0 (ref $environment162)) (param $1 (ref null $type40)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type40 0
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type126 0
       (struct.get $environment162 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function162
     (struct.get $type124 0
      (struct.get $type126 1
       (struct.get $environment162 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $primitive0 (type $call47) (param $0 (ref null $environment45)) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (struct.new $type13
   (local.get $1)
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type123))
  (local $2 (ref $type45))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type70 1
    (global.get $global301)
   )
  )
  (struct.set $type123 1
   (local.tee $1
    (struct.new_default $type123)
   )
   (struct.new $type45
    (ref.func $function158)
    (struct.new $environment158
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type123 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type123 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call45
   (struct.get $type45 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type123 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type45 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type11)
  )
  (global.set $global206
   (struct.new_default $type15)
  )
  (global.set $global124
   (struct.new_default $type19)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global208
   (struct.new_default $type20)
  )
  (global.set $ready208
   (i32.const 1)
  )
  (global.set $global309
   (struct.new_default $type39)
  )
  (global.set $global116
   (struct.new $type41
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new_default $type42)
  )
  (global.set $global200
   (struct.new_default $type43)
  )
  (global.set $ready200
   (i32.const 1)
  )
  (global.set $global306
   (struct.new $type45
    (ref.func $function159)
    (ref.null none)
   )
  )
  (global.set $global187
   (struct.new_default $type46)
  )
  (global.set $global119
   (struct.new_default $type48)
  )
  (global.set $global203
   (struct.new_default $type50)
  )
  (global.set $global111
   (struct.new $type49
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $global228
   (struct.new_default $type52)
  )
  (global.set $global280
   (struct.new_default $type53)
  )
  (global.set $global274
   (struct.new_default $type54)
  )
  (global.set $global165
   (struct.new_default $type56)
  )
  (global.set $global109
   (struct.new_default $type61)
  )
  (global.set $global149
   (struct.new_default $type65)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type66)
  )
  (global.set $global194
   (struct.new_default $type68)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global233
   (struct.new_default $type69)
  )
  (global.set $global300
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global301
   (struct.new $type70
    (ref.func $function156)
    (ref.null none)
   )
  )
  (global.set $ready301
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

