(module
 (rec
  (type $call39 (func (param (ref $environment53) (ref null $type28) i64) (result i64)))
  (type $call36 (func (param (ref $environment49) (ref null $type28) (ref $type28)) (result (ref null $type28))))
  (type $type36 (struct (field (ref $environment49))))
  (type $type38 (struct (field (mut i32)) (field (mut (ref null $type36)))))
  (type $environment49 (struct (field (ref $type38))))
  (type $type39 (struct (field (ref $environment53))))
  (type $environment46 (struct (field i64) (field (ref $type35))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type39)))))
  (type $environment53 (struct (field (ref $type41))))
  (type $call32 (func (param i64) (result i64)))
  (type $type33 (struct (field (ref $call33)) (field (ref struct))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $environment43 (struct (field (ref $type35))))
  (type $call33 (func (param (ref struct) i64 (ref null $type28)) (result (ref null $type28))))
  (type $type32 (struct))
  (type $type28 (struct (field nullref) (field (ref null $type28))))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type27 (struct))
 )
 (type $19 (func (param i32) (result i64)))
 (type $20 (func (param i64) (result i64)))
 (type $21 (func))
 (import "benchmark" "input_i64" (func $foreign0 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type27)) (ref.null none))
 (global $global124 (mut (ref null $type30)) (ref.null none))
 (global $global106 (mut (ref null $type31)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type27)) (ref.null none))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $global112 (mut (ref null $type32)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call33) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type33 1
      (struct.get $type35 1
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (ref.null none)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function44 (type $call32) (param $0 i64) (result i64)
  (local $1 (ref null $type28))
  (local $2 (ref $environment53))
  (local $3 (ref $type35))
  (local $4 (ref $type41))
  (local $5 (ref $type33))
  (struct.set $type35 1
   (local.tee $3
    (struct.new_default $type35)
   )
   (struct.new $type33
    (ref.func $function46)
    (struct.new $environment46
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type35 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call33
    (struct.get $type33 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type33 0
     (local.get $5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (struct.set $type41 1
   (local.tee $4
    (struct.new_default $type41)
   )
   (struct.new $type39
    (struct.new $environment53
     (local.get $4)
    )
   )
  )
  (struct.set $type41 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type41 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type39 0
    (struct.get $type41 1
     (local.get $4)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment53 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type39 0
      (struct.get $type41 1
       (struct.get $environment53 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type39 0
        (struct.get $type41 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type28 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type41 0
           (struct.get $environment53 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type39 0
          (struct.get $type41 1
           (struct.get $environment53 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type41 0
             (struct.get $environment53 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type39 0
            (struct.get $type41 1
             (struct.get $environment53 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type28 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type41 0
               (struct.get $environment53 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type39 0
              (struct.get $type41 1
               (struct.get $environment53 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type41 0
                 (struct.get $environment53 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type39 0
                (struct.get $type41 1
                 (struct.get $environment53 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type28 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type41 0
                   (struct.get $environment53 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type39 0
                  (struct.get $type41 1
                   (struct.get $environment53 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type41 0
                     (struct.get $environment53 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type39 0
                    (struct.get $type41 1
                     (struct.get $environment53 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type28 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type41 0
                       (struct.get $environment53 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function53
                     (struct.get $type39 0
                      (struct.get $type41 1
                       (struct.get $environment53 0
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function46 (type $call33) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 (ref $environment49))
  (local $4 (ref $type28))
  (local $5 (ref null $type28))
  (local $6 nullref)
  (local $7 (ref $type38))
  (local $8 i64)
  (if (result (ref null $type28))
   (i64.gt_s
    (struct.get $environment46 0
     (ref.cast (ref $environment46)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $8
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (struct.set $type38 1
     (local.tee $7
      (struct.new_default $type38)
     )
     (struct.new $type36
      (struct.new $environment49
       (local.get $7)
      )
     )
    )
    (struct.set $type38 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type36 0
      (struct.get $type38 1
       (local.get $7)
      )
     )
    )
    (local.set $2
     (if (result (ref null $type28))
      (ref.is_null
       (local.tee $2
        (global.get $global111)
       )
      )
      (then
       (ref.null none)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (local.set $5
        (struct.get $type28 1
         (struct.get $type28 1
          (local.get $2)
         )
        )
       )
       (local.set $4
        (struct.new $type28
         (struct.get $type28 0
          (local.get $2)
         )
         (block (result nullref)
          (if
           (i32.eqz
            (struct.get $type38 0
             (struct.get $environment49 0
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type36 0
            (struct.get $type38 1
             (struct.get $environment49 0
              (local.get $3)
             )
            )
           )
          )
          (ref.null none)
         )
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $5)
        )
        (then
         (local.get $4)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (local.set $2
          (struct.get $type28 1
           (struct.get $type28 1
            (local.get $5)
           )
          )
         )
         (local.set $4
          (struct.new $type28
           (struct.get $type28 0
            (local.get $5)
           )
           (block (result (ref $type28))
            (if
             (i32.eqz
              (struct.get $type38 0
               (struct.get $environment49 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type36 0
              (struct.get $type38 1
               (struct.get $environment49 0
                (local.get $3)
               )
              )
             )
            )
            (local.get $4)
           )
          )
         )
         (if (result (ref null $type28))
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $4)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.set $5
            (struct.get $type28 1
             (struct.get $type28 1
              (local.get $2)
             )
            )
           )
           (local.set $4
            (struct.new $type28
             (struct.get $type28 0
              (local.get $2)
             )
             (block (result (ref $type28))
              (if
               (i32.eqz
                (struct.get $type38 0
                 (struct.get $environment49 0
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type36 0
                (struct.get $type38 1
                 (struct.get $environment49 0
                  (local.get $3)
                 )
                )
               )
              )
              (local.get $4)
             )
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $5)
            )
            (then
             (local.get $4)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.set $2
              (struct.get $type28 1
               (struct.get $type28 1
                (local.get $5)
               )
              )
             )
             (local.set $4
              (struct.new $type28
               (struct.get $type28 0
                (local.get $5)
               )
               (block (result (ref $type28))
                (if
                 (i32.eqz
                  (struct.get $type38 0
                   (struct.get $environment49 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type36 0
                  (struct.get $type38 1
                   (struct.get $environment49 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (local.get $4)
               )
              )
             )
             (if (result (ref null $type28))
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $4)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global122)
                )
               )
               (local.set $5
                (struct.get $type28 1
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
               )
               (local.set $4
                (struct.new $type28
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (block (result (ref $type28))
                  (if
                   (i32.eqz
                    (struct.get $type38 0
                     (struct.get $environment49 0
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type36 0
                    (struct.get $type38 1
                     (struct.get $environment49 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (local.get $4)
                 )
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $5)
                )
                (then
                 (local.get $4)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global122)
                  )
                 )
                 (local.set $2
                  (struct.get $type28 1
                   (struct.get $type28 1
                    (local.get $5)
                   )
                  )
                 )
                 (local.set $4
                  (struct.new $type28
                   (struct.get $type28 0
                    (local.get $5)
                   )
                   (block (result (ref $type28))
                    (if
                     (i32.eqz
                      (struct.get $type38 0
                       (struct.get $environment49 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type36 0
                      (struct.get $type38 1
                       (struct.get $environment49 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (local.get $4)
                   )
                  )
                 )
                 (if (result (ref null $type28))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global122)
                    )
                   )
                   (local.set $5
                    (struct.get $type28 1
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                   )
                   (local.set $4
                    (struct.new $type28
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (block (result (ref $type28))
                      (if
                       (i32.eqz
                        (struct.get $type38 0
                         (struct.get $environment49 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type36 0
                        (struct.get $type38 1
                         (struct.get $environment49 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (local.get $4)
                     )
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $5)
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global122)
                      )
                     )
                     (local.set $2
                      (struct.get $type28 1
                       (struct.get $type28 1
                        (local.get $5)
                       )
                      )
                     )
                     (local.set $4
                      (struct.new $type28
                       (struct.get $type28 0
                        (local.get $5)
                       )
                       (block (result (ref $type28))
                        (if
                         (i32.eqz
                          (struct.get $type38 0
                           (struct.get $environment49 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $3
                         (struct.get $type36 0
                          (struct.get $type38 1
                           (struct.get $environment49 0
                            (local.get $3)
                           )
                          )
                         )
                        )
                        (local.get $4)
                       )
                      )
                     )
                     (if (result (ref null $type28))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $4)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global122)
                        )
                       )
                       (local.set $5
                        (struct.get $type28 1
                         (struct.get $type28 1
                          (local.get $2)
                         )
                        )
                       )
                       (local.set $6
                        (struct.get $type28 0
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type38 0
                          (struct.get $environment49 0
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function49
                        (struct.get $type36 0
                         (struct.get $type38 1
                          (struct.get $environment49 0
                           (local.get $3)
                          )
                         )
                        )
                        (local.get $5)
                        (struct.new $type28
                         (local.get $6)
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment46 1
        (ref.cast (ref $environment46)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (struct.get $type33 1
      (struct.get $type35 1
       (struct.get $environment46 1
        (ref.cast (ref $environment46)
         (local.get $0)
        )
       )
      )
     )
     (local.get $8)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function49 (type $call36) (param $0 (ref $environment49)) (param $1 (ref null $type28)) (param $2 (ref $type28)) (result (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 nullref)
  (if (result (ref $type28))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $3
     (struct.get $type28 1
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
    (local.set $4
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (struct.get $environment49 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type36 0
      (struct.get $type38 1
       (struct.get $environment49 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function53 (type $call39) (param $0 (ref $environment53)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment53 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function53
     (struct.get $type39 0
      (struct.get $type41 1
       (struct.get $environment53 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (return_call $function44
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type35))
  (local $1 (ref $type33))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type27)
  )
  (global.set $global124
   (struct.new_default $type30)
  )
  (global.set $global106
   (struct.new_default $type31)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type27)
  )
  (local.set $2
   (call $foreign0
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (struct.set $type35 1
   (local.tee $0
    (struct.new_default $type35)
   )
   (struct.new $type33
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
    )
   )
  )
  (struct.set $type35 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global111
   (call_ref $call33
    (struct.get $type33 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type33 0
     (local.get $1)
    )
   )
  )
  (global.set $global112
   (struct.new_default $type32)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

