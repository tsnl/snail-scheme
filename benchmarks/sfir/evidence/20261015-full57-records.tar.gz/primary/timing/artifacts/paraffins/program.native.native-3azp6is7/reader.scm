(module
 (rec
  (type $type19 (sub (struct)))
  (type $type84 (struct (field (mut i32)) (field (mut (ref null $type45)))))
  (type $environment115 (struct (field i64) (field (ref $type84))))
  (type $call80 (func (param (ref $environment112) (ref null $type16) i64) (result i64)))
  (type $type80 (struct (field (ref $environment112))))
  (type $type82 (struct (field (mut i32)) (field (mut (ref null $type80)))))
  (type $environment112 (struct (field (ref $type82))))
  (type $call44 (func (param (ref null $type16)) (result i64)))
  (type $8 (func (param (ref null $type23) i32 i32 i32 (ref null $type15) i64) (result (ref $type23))))
  (type $9 (func (param i32 i32 (ref null $type15) i64) (result i64)))
  (type $type23 (array (mut (ref null $type16))))
  (type $type15 (struct (field (ref null $type16)) (field (ref null $type15))))
  (type $environment100 (struct (field (ref null $type52)) (field (ref null $type52)) (field (ref null $type52)) (field (ref $type71))))
  (type $environment98 (struct (field (ref $type51)) (field i64) (field i64) (field (ref null $type52)) (field (ref null $type52)) (field (ref $type71))))
  (type $environment96 (struct (field (ref $type51)) (field i64) (field i64) (field i64) (field (ref null $type52)) (field (ref $type71))))
  (type $environment94 (struct (field (ref $type51)) (field i64) (field i64) (field i64) (field i64) (field (ref $type71))))
  (type $type72 (struct (field (ref $environment86))))
  (type $environment89 (struct (field (ref $type51)) (field (ref $type74)) (field (ref null $type49)) (field (ref null $type16)) (field (ref $type13)) (field i64)))
  (type $type74 (struct (field (mut i32)) (field (mut (ref null $type72)))))
  (type $environment86 (struct (field (ref $type51)) (field (ref $type74))))
  (type $20 (func (param (ref $environment89) i64) (result (ref null $type16))))
  (type $call45 (func (param (ref null $environment115) i64 i64) (result i64)))
  (type $environment84 (struct (field i64) (field i64) (field (ref $type61)) (field i64) (field i64) (field (ref $type61))))
  (type $environment80 (struct (field i64) (field (ref $type61)) (field i64) (field (ref $type61))))
  (type $environment78 (struct (field i64) (field (ref $type61))))
  (type $type16 (struct (field (ref null $type16))))
  (type $environment74 (struct (field (ref null $type52)) (field (ref $type71))))
  (type $environment72 (struct (field (ref $type71))))
  (type $type69 (struct (field (ref $call69)) (field (ref struct))))
  (type $type71 (struct (field (mut i32)) (field (mut (ref null $type69)))))
  (type $call69 (func (param (ref struct) (ref null $type52) (ref null $type16)) (result (ref null $type16))))
  (type $type21 (sub $type19 (struct)))
  (type $environment69 (struct (field (ref null $type52)) (field (ref null $type52)) (field (ref $type68))))
  (type $environment67 (struct (field (ref $type51)) (field i64) (field i64) (field (ref null $type52)) (field (ref $type68))))
  (type $call66 (func (param (ref struct) (ref null $type52) (ref null $type52)) (result (ref null $type52))))
  (type $environment65 (struct (field (ref $type51)) (field i64) (field i64) (field i64) (field (ref $type68))))
  (type $type57 (struct (field (ref $environment58))))
  (type $environment61 (struct (field (ref $type51)) (field (ref $type62)) (field (ref null $type49)) (field (ref null $type52)) (field (ref $type13)) (field i64)))
  (type $type66 (struct (field (ref $call66)) (field (ref struct))))
  (type $type62 (struct (field (mut i32)) (field (mut (ref null $type57)))))
  (type $environment58 (struct (field (ref $type51)) (field (ref $type62))))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type66)))))
  (type $42 (func (param (ref $environment61) i64) (result (ref null $type52))))
  (type $43 (func (param (ref null $type13) i32 i32 i32 (ref null $type12) i64) (result (ref $type13))))
  (type $44 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $type13 (array (mut i64)))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $type49 (struct (field (ref $type13)) (field (ref null $type49))))
  (type $environment51 (struct (field i64) (field (ref $type61)) (field i64) (field (ref $type61))))
  (type $type59 (struct (field (ref $call59)) (field (ref struct))))
  (type $environment49 (struct (field i64) (field (ref $type61))))
  (type $type61 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $call59 (func (param (ref struct) (ref null $type49) i64) (result (ref null $type49))))
  (type $environment102 (struct (field i64) (field i64) (field (ref $type51)) (field (ref $type78))))
  (type $type51 (array (mut (ref null $type52))))
  (type $type52 (struct (field (ref $type19)) (field (ref null $type52))))
  (type $type78 (struct (field (mut i32)) (field (mut (ref null $type47)))))
  (type $call47 (func (param (ref null $environment102) i64) (result (ref $type23))))
  (type $type50 (struct))
  (type $type48 (struct))
  (type $type47 (struct (field (ref $call47)) (field (ref null $environment102))))
  (type $type46 (struct))
  (type $type45 (struct (field (ref $call45)) (field (ref null $environment115))))
  (type $type44 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type14 (struct))
  (type $type11 (struct))
  (type $type20 (sub $type19 (struct)))
 )
 (type $71 (func (param i64) (result i64)))
 (type $72 (func (param i32) (result i64)))
 (type $73 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty20 (ref $type20) (struct.new_default $type20))
 (global $global122 (mut (ref null $type11)) (ref.null none))
 (global $global198 (mut (ref null $type14)) (ref.null none))
 (global $global124 (mut (ref null $type24)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global200 (mut (ref null $type25)) (ref.null none))
 (global $ready200 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type28)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type29)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global214 (mut (ref null $type44)) (ref.null none))
 (global $global169 (mut (ref null $type45)) (ref.null none))
 (global $global106 (mut (ref null $type46)) (ref.null none))
 (global $global225 (mut (ref null $type45)) (ref.null none))
 (global $global108 (mut (ref null $type47)) (ref.null none))
 (global $global114 (mut (ref null $type48)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type48)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type50)) (ref.null none))
 (global $global219 (mut i64) (i64.const 0))
 (global $global220 (mut (ref null $type50)) (ref.null none))
 (global $ready220 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function42 (type $call47) (param $0 (ref null $environment102)) (param $1 i64) (result (ref $type23))
  (local $2 (ref $type78))
  (local $3 (ref $type47))
  (local $4 i64)
  (local $5 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $5
       (i64.div_s
        (local.get $1)
        (i64.const 2)
       )
      )
      (local.tee $4
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $4)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type78 1
   (local.tee $2
    (struct.new_default $type78)
   )
   (struct.new $type47
    (ref.func $function102)
    (struct.new $environment102
     (local.get $1)
     (local.get $5)
     (array.new $type51
      (struct.new $type52
       (global.get $empty20)
       (ref.null none)
      )
      (i32.wrap_i64
       (local.get $4)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type78 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type78 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call47
   (struct.get $type47 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type78 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type47 0
    (local.get $3)
   )
  )
 )
 (func $function49 (type $call59) (param $0 (ref struct)) (param $1 (ref null $type49)) (param $2 i64) (result (ref null $type49))
  (local $3 (ref $type61))
  (local $4 (ref $environment49))
  (local $5 (ref $type59))
  (local $6 i64)
  (local $7 i64)
  (if (result (ref null $type49))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $7
     (i64.sub
      (local.tee $6
       (struct.get $environment49 0
        (ref.cast (ref $environment49)
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.get $7)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type61 1
     (local.tee $3
      (struct.new_default $type61)
     )
     (struct.new $type59
      (ref.func $function51)
      (struct.new $environment51
       (struct.get $environment49 0
        (local.tee $4
         (ref.cast (ref $environment49)
          (local.get $0)
         )
        )
       )
       (struct.get $environment49 1
        (local.get $4)
       )
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.set $type61 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call59
     (struct.get $type59 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type61 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (local.get $7)
      (i64.const 2)
     )
     (struct.get $type59 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function51 (type $call59) (param $0 (ref struct)) (param $1 (ref null $type49)) (param $2 i64) (result (ref null $type49))
  (local $3 (ref null $type12))
  (local $4 (ref $environment51))
  (local $5 (ref $type12))
  (local $6 (ref $type49))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if
   (i64.gt_s
    (struct.get $environment51 2
     (local.tee $4
      (ref.cast (ref $environment51)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.set $7
     (i64.sub
      (local.tee $2
       (struct.get $environment51 2
        (local.get $4)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $7)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment51 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type59 1
      (struct.get $type61 1
       (struct.get $environment51 1
        (local.get $4)
       )
      )
     )
     (local.get $1)
     (local.get $7)
    )
   )
   (else
    (local.set $7
     (i64.add
      (local.get $2)
      (local.tee $8
       (struct.get $environment51 2
        (local.get $4)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
       (i64.xor
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (struct.get $environment51 0
          (local.get $4)
         )
        )
        (local.tee $9
         (i64.sub
          (local.get $8)
          (local.get $7)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (if (result i64)
        (ref.is_null
         (local.tee $3
          (struct.get $type12 1
           (local.tee $5
            (struct.new $type12
             (struct.get $environment51 2
              (local.get $4)
             )
             (struct.new $type12
              (local.get $2)
              (struct.new $type12
               (local.get $9)
               (ref.null none)
              )
             )
            )
           )
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $3
            (struct.get $type12 1
             (local.get $3)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $3)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (call $function55
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                                (i64.const 13)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.new $type49
      (call $function56
       (array.new $type13
        (struct.get $type12 0
         (local.get $5)
        )
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (local.get $5)
       (i64.const 0)
      )
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment51 3
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type59 1
      (struct.get $type61 1
       (struct.get $environment51 3
        (local.get $4)
       )
      )
     )
     (local.get $6)
     (local.get $7)
    )
   )
  )
  (unreachable)
 )
 (func $function55 (type $44) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function55
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function56 (type $43) (param $0 (ref null $type13)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type13))
  (local $6 i64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function61 (type $42) (param $0 (ref $environment61)) (param $1 i64) (result (ref null $type52))
  (local $2 (ref null $type52))
  (local $3 (ref null $type52))
  (local $4 (ref $type68))
  (local $5 (ref null $type49))
  (local $6 (ref $environment58))
  (local $7 (ref $type13))
  (local $8 (ref $type51))
  (local $9 (ref $type62))
  (local $10 (ref $type66))
  (local $11 i64)
  (local $12 i64)
  (local.set $2
   (struct.get $environment61 3
    (local.get $0)
   )
  )
  (local.set $12
   (array.get $type13
    (struct.get $environment61 4
     (local.get $0)
    )
    (i32.const 2)
   )
  )
  (if
   (i64.gt_u
    (local.tee $11
     (struct.get $environment61 5
      (local.get $0)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (array.get $type51
    (local.tee $8
     (struct.get $environment61 0
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $11)
    )
   )
  )
  (local.set $5
   (struct.get $type49 1
    (struct.get $environment61 2
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type62 0
     (local.tee $9
      (struct.get $environment61 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type57 0
    (struct.get $type62 1
     (local.get $9)
    )
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $5)
    )
   )
   (then
    (local.set $2
     (call $function61
      (struct.new $environment61
       (struct.get $environment58 0
        (local.get $6)
       )
       (struct.get $environment58 1
        (local.get $6)
       )
       (local.get $5)
       (local.get $2)
       (local.tee $7
        (struct.get $type49 0
         (local.get $5)
        )
       )
       (array.get $type13
        (local.get $7)
        (i32.const 0)
       )
      )
      (array.get $type13
       (local.get $7)
       (i32.const 1)
      )
     )
    )
   )
  )
  (struct.set $type68 1
   (local.tee $4
    (struct.new_default $type68)
   )
   (struct.new $type66
    (ref.func $function65)
    (struct.new $environment65
     (local.get $8)
     (local.get $11)
     (local.get $1)
     (local.get $12)
     (local.get $4)
    )
   )
  )
  (struct.set $type68 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call66
   (struct.get $type66 1
    (local.tee $10
     (ref.as_non_null
      (struct.get $type68 1
       (local.get $4)
      )
     )
    )
   )
   (local.get $3)
   (local.get $2)
   (struct.get $type66 0
    (local.get $10)
   )
  )
 )
 (func $function65 (type $call66) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type52)) (result (ref null $type52))
  (local $3 (ref $environment65))
  (local $4 (ref $type68))
  (local $5 (ref null $type52))
  (local $6 (ref null $type52))
  (local $7 (ref $type66))
  (local $8 i64)
  (if (result (ref null $type52))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (if (result (ref null $type52))
      (i64.eq
       (struct.get $environment65 1
        (local.tee $3
         (ref.cast (ref $environment65)
          (local.get $0)
         )
        )
       )
       (struct.get $environment65 2
        (local.get $3)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $environment65 2
           (local.get $3)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type51
        (struct.get $environment65 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment65 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function65
      (struct.get $type66 1
       (struct.get $type68 1
        (struct.get $environment65 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type68 1
     (local.tee $4
      (struct.new_default $type68)
     )
     (struct.new $type66
      (ref.func $function67)
      (struct.new $environment67
       (struct.get $environment65 0
        (local.get $3)
       )
       (struct.get $environment65 2
        (local.get $3)
       )
       (struct.get $environment65 3
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type68 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call66
     (struct.get $type66 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type68 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type66 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function67 (type $call66) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type52)) (result (ref null $type52))
  (local $3 (ref $environment67))
  (local $4 (ref $type68))
  (local $5 (ref null $type52))
  (local $6 (ref null $type52))
  (local $7 (ref $type66))
  (local $8 i64)
  (if (result (ref null $type52))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (if (result (ref null $type52))
      (i64.eq
       (struct.get $environment67 1
        (local.tee $3
         (ref.cast (ref $environment67)
          (local.get $0)
         )
        )
       )
       (struct.get $environment67 2
        (local.get $3)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $environment67 2
           (local.get $3)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type51
        (struct.get $environment67 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment67 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function67
      (struct.get $type66 1
       (struct.get $type68 1
        (struct.get $environment67 4
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type68 1
     (local.tee $4
      (struct.new_default $type68)
     )
     (struct.new $type66
      (ref.func $function69)
      (struct.new $environment69
       (struct.get $environment67 3
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type68 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call66
     (struct.get $type66 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type68 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type66 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function69 (type $call66) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type52)) (result (ref null $type52))
  (local $3 (ref $environment69))
  (if (result (ref null $type52))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type52 0
      (struct.get $environment69 0
       (local.tee $3
        (ref.cast (ref $environment69)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type52 0
      (struct.get $environment69 1
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type52 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type68 0
       (struct.get $environment69 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type52
     (struct.new_default $type21)
     (call $function69
      (struct.get $type66 1
       (struct.get $type68 1
        (struct.get $environment69 2
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function72 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $type71))
  (local $4 (ref null $type52))
  (local $5 (ref $type69))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment72 0
        (ref.cast (ref $environment72)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function72
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment72 0
         (ref.cast (ref $environment72)
          (local.get $0)
         )
        )
       )
      )
      (local.get $4)
      (local.get $2)
     )
    )
    (struct.set $type71 1
     (local.tee $3
      (struct.new_default $type71)
     )
     (struct.new $type69
      (ref.func $function74)
      (struct.new $environment74
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type71 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call69
     (struct.get $type69 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type71 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (local.get $2)
     (struct.get $type69 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function74 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment74))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type52 0
      (struct.get $environment74 0
       (local.tee $3
        (ref.cast (ref $environment74)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type52 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment74 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type16
     (call $function74
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment74 1
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function78 (type $call59) (param $0 (ref struct)) (param $1 (ref null $type49)) (param $2 i64) (result (ref null $type49))
  (local $3 (ref $type61))
  (local $4 (ref $environment78))
  (local $5 (ref $type59))
  (local $6 i64)
  (local $7 i64)
  (if (result (ref null $type49))
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $7
     (i64.sub
      (local.tee $6
       (struct.get $environment78 0
        (ref.cast (ref $environment78)
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.get $7)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type61 1
     (local.tee $3
      (struct.new_default $type61)
     )
     (struct.new $type59
      (ref.func $function80)
      (struct.new $environment80
       (struct.get $environment78 0
        (local.tee $4
         (ref.cast (ref $environment78)
          (local.get $0)
         )
        )
       )
       (struct.get $environment78 1
        (local.get $4)
       )
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.set $type61 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call59
     (struct.get $type59 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type61 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (local.get $7)
      (i64.const 3)
     )
     (struct.get $type59 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function80 (type $call59) (param $0 (ref struct)) (param $1 (ref null $type49)) (param $2 i64) (result (ref null $type49))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 (ref $environment80))
  (local $9 (ref $type61))
  (local $10 (ref $type59))
  (if
   (i64.gt_s
    (struct.get $environment80 2
     (local.tee $8
      (ref.cast (ref $environment80)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.set $3
     (i64.sub
      (local.tee $2
       (struct.get $environment80 2
        (local.get $8)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment80 1
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function78
     (struct.get $type59 1
      (struct.get $type61 1
       (struct.get $environment80 1
        (local.get $8)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
   (else
    (local.set $5
     (i64.add
      (local.tee $3
       (struct.get $environment80 0
        (local.get $8)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.add
      (local.get $2)
      (local.tee $4
       (struct.get $environment80 2
        (local.get $8)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.sub
      (local.tee $4
       (i64.div_s
        (local.get $5)
        (i64.const 2)
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.get $5)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type45 1
      (global.get $global169)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.tee $4
           (local.tee $6
            (struct.get $environment80 2
             (local.get $8)
            )
           )
          )
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (struct.get $environment80 0
          (local.get $8)
         )
        )
        (local.tee $7
         (i64.sub
          (local.get $4)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type61 1
     (local.tee $9
      (struct.new_default $type61)
     )
     (struct.new $type59
      (ref.func $function84)
      (struct.new $environment84
       (local.get $4)
       (local.get $6)
       (struct.get $environment80 3
        (local.get $8)
       )
       (local.get $2)
       (select
        (local.get $2)
        (local.get $5)
        (i64.gt_s
         (local.get $2)
         (local.get $5)
        )
       )
       (local.get $9)
      )
     )
    )
    (struct.set $type61 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call59
     (struct.get $type59 1
      (local.tee $10
       (ref.as_non_null
        (struct.get $type61 1
         (local.get $9)
        )
       )
      )
     )
     (local.get $1)
     (i64.div_s
      (local.get $7)
      (i64.const 2)
     )
     (struct.get $type59 0
      (local.get $10)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function81 (type $call45) (param $0 (ref null $environment115)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function84 (type $call59) (param $0 (ref struct)) (param $1 (ref null $type49)) (param $2 i64) (result (ref null $type49))
  (local $3 (ref null $type12))
  (local $4 (ref $environment84))
  (local $5 (ref $type12))
  (local $6 (ref $type49))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (if
   (i64.gt_s
    (struct.get $environment84 4
     (local.tee $4
      (ref.cast (ref $environment84)
       (local.get $0)
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.set $7
     (i64.sub
      (local.tee $2
       (struct.get $environment84 3
        (local.get $4)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $7)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment84 2
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function80
     (struct.get $type59 1
      (struct.get $type61 1
       (struct.get $environment84 2
        (local.get $4)
       )
      )
     )
     (local.get $1)
     (local.get $7)
    )
   )
   (else
    (local.set $10
     (local.tee $8
      (struct.get $environment84 3
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $7
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $7)
          (local.tee $9
           (struct.get $environment84 1
            (local.get $4)
           )
          )
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (struct.get $environment84 0
          (local.get $4)
         )
        )
        (local.tee $9
         (i64.sub
          (local.get $7)
          (local.get $8)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready127)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (if (result i64)
        (ref.is_null
         (local.tee $3
          (struct.get $type12 1
           (local.tee $5
            (struct.new $type12
             (struct.get $environment84 1
              (local.get $4)
             )
             (struct.new $type12
              (local.get $10)
              (struct.new $type12
               (local.get $2)
               (struct.new $type12
                (local.get $9)
                (ref.null none)
               )
              )
             )
            )
           )
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $3
            (struct.get $type12 1
             (local.get $3)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $3)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (call $function55
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                                (i64.const 13)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.new $type49
      (call $function56
       (array.new $type13
        (struct.get $type12 0
         (local.get $5)
        )
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (local.get $5)
       (i64.const 0)
      )
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment84 5
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (struct.get $type59 1
      (struct.get $type61 1
       (struct.get $environment84 5
        (local.get $4)
       )
      )
     )
     (local.get $6)
     (local.get $7)
    )
   )
  )
  (unreachable)
 )
 (func $function89 (type $20) (param $0 (ref $environment89)) (param $1 i64) (result (ref null $type16))
  (local $2 (ref $type13))
  (local $3 (ref null $type16))
  (local $4 (ref $type71))
  (local $5 (ref null $type49))
  (local $6 (ref $environment86))
  (local $7 (ref $type51))
  (local $8 (ref null $type52))
  (local $9 (ref $type74))
  (local $10 (ref $type69))
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local.set $12
   (array.get $type13
    (local.tee $2
     (struct.get $environment89 4
      (local.get $0)
     )
    )
    (i32.const 2)
   )
  )
  (local.set $13
   (array.get $type13
    (local.get $2)
    (i32.const 3)
   )
  )
  (if
   (i64.gt_u
    (local.tee $11
     (struct.get $environment89 5
      (local.get $0)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (array.get $type51
    (local.tee $7
     (struct.get $environment89 0
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $11)
    )
   )
  )
  (local.set $5
   (struct.get $type49 1
    (struct.get $environment89 2
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (local.tee $9
      (struct.get $environment89 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type72 0
    (struct.get $type74 1
     (local.get $9)
    )
   )
  )
  (local.set $3
   (struct.get $environment89 3
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $5)
    )
   )
   (then
    (local.set $3
     (call $function89
      (struct.new $environment89
       (struct.get $environment86 0
        (local.get $6)
       )
       (struct.get $environment86 1
        (local.get $6)
       )
       (local.get $5)
       (local.get $3)
       (local.tee $2
        (struct.get $type49 0
         (local.get $5)
        )
       )
       (array.get $type13
        (local.get $2)
        (i32.const 0)
       )
      )
      (array.get $type13
       (local.get $2)
       (i32.const 1)
      )
     )
    )
   )
  )
  (struct.set $type71 1
   (local.tee $4
    (struct.new_default $type71)
   )
   (struct.new $type69
    (ref.func $function94)
    (struct.new $environment94
     (local.get $7)
     (local.get $11)
     (local.get $1)
     (local.get $12)
     (local.get $13)
     (local.get $4)
    )
   )
  )
  (struct.set $type71 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type71 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call69
   (struct.get $type69 1
    (local.tee $10
     (ref.as_non_null
      (struct.get $type71 1
       (local.get $4)
      )
     )
    )
   )
   (local.get $8)
   (local.get $3)
   (struct.get $type69 0
    (local.get $10)
   )
  )
 )
 (func $function94 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment94))
  (local $4 (ref $type71))
  (local $5 (ref null $type52))
  (local $6 (ref null $type52))
  (local $7 (ref $type69))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (if (result (ref null $type52))
      (i64.eq
       (struct.get $environment94 1
        (local.tee $3
         (ref.cast (ref $environment94)
          (local.get $0)
         )
        )
       )
       (struct.get $environment94 2
        (local.get $3)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $environment94 2
           (local.get $3)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type51
        (struct.get $environment94 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment94 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function94
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment94 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type71 1
     (local.tee $4
      (struct.new_default $type71)
     )
     (struct.new $type69
      (ref.func $function96)
      (struct.new $environment96
       (struct.get $environment94 0
        (local.get $3)
       )
       (struct.get $environment94 2
        (local.get $3)
       )
       (struct.get $environment94 3
        (local.get $3)
       )
       (struct.get $environment94 4
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type71 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call69
     (struct.get $type69 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type71 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type69 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function96 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment96))
  (local $4 (ref $type71))
  (local $5 (ref null $type52))
  (local $6 (ref null $type52))
  (local $7 (ref $type69))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (if (result (ref null $type52))
      (i64.eq
       (struct.get $environment96 1
        (local.tee $3
         (ref.cast (ref $environment96)
          (local.get $0)
         )
        )
       )
       (struct.get $environment96 2
        (local.get $3)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $environment96 2
           (local.get $3)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type51
        (struct.get $environment96 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment96 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function96
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment96 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type71 1
     (local.tee $4
      (struct.new_default $type71)
     )
     (struct.new $type69
      (ref.func $function98)
      (struct.new $environment98
       (struct.get $environment96 0
        (local.get $3)
       )
       (struct.get $environment96 2
        (local.get $3)
       )
       (struct.get $environment96 3
        (local.get $3)
       )
       (struct.get $environment96 4
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type71 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call69
     (struct.get $type69 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type71 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type69 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function98 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment98))
  (local $4 (ref $type71))
  (local $5 (ref null $type52))
  (local $6 (ref null $type52))
  (local $7 (ref $type69))
  (local $8 i64)
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (if (result (ref null $type52))
      (i64.eq
       (struct.get $environment98 1
        (local.tee $3
         (ref.cast (ref $environment98)
          (local.get $0)
         )
        )
       )
       (struct.get $environment98 2
        (local.get $3)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $8
          (struct.get $environment98 2
           (local.get $3)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type51
        (struct.get $environment98 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (local.set $6
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment98 5
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function98
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment98 5
         (local.get $3)
        )
       )
      )
      (local.get $6)
      (local.get $2)
     )
    )
    (struct.set $type71 1
     (local.tee $4
      (struct.new_default $type71)
     )
     (struct.new $type69
      (ref.func $function100)
      (struct.new $environment100
       (struct.get $environment98 3
        (local.get $3)
       )
       (struct.get $environment98 4
        (local.get $3)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type71 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call69
     (struct.get $type69 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type71 1
         (local.get $4)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
     (struct.get $type69 0
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function100 (type $call69) (param $0 (ref struct)) (param $1 (ref null $type52)) (param $2 (ref null $type16)) (result (ref null $type16))
  (local $3 (ref $environment100))
  (if (result (ref null $type16))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (struct.get $type52 0
      (struct.get $environment100 0
       (local.tee $3
        (ref.cast (ref $environment100)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (struct.get $type52 0
      (struct.get $environment100 1
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type52 0
      (struct.get $environment100 2
       (local.get $3)
      )
     )
    )
    (drop
     (struct.get $type52 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type52 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment100 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type16
     (call $function100
      (struct.get $type69 1
       (struct.get $type71 1
        (struct.get $environment100 3
         (local.get $3)
        )
       )
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function102 (type $call47) (param $0 (ref null $environment102)) (param $1 i64) (result (ref $type23))
  (local $2 (ref null $type15))
  (local $3 (ref $type61))
  (local $4 (ref $environment102))
  (local $5 (ref null $type49))
  (local $6 (ref $type13))
  (local $7 (ref $type71))
  (local $8 (ref $type74))
  (local $9 (ref $type62))
  (local $10 (ref null $type52))
  (local $11 (ref $type59))
  (local $12 (ref $environment86))
  (local $13 (ref $type15))
  (local $14 (ref $environment58))
  (local $15 (ref $type51))
  (local $16 (ref $type69))
  (local $17 (ref null $type16))
  (local $18 (ref null $type16))
  (local $19 i64)
  (if
   (i64.lt_s
    (struct.get $environment102 1
     (local.tee $4
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $15
     (struct.get $environment102 2
      (local.get $4)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (if (result i64)
        (ref.is_null
         (local.tee $2
          (struct.get $type15 1
           (local.tee $13
            (struct.new $type15
             (if (result (ref null $type16))
              (i32.wrap_i64
               (i64.and
                (local.tee $1
                 (struct.get $environment102 0
                  (local.get $4)
                 )
                )
                (i64.const 1)
               )
              )
              (then
               (ref.null none)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.div_s
                   (local.get $1)
                   (i64.const 2)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (local.set $10
                (array.get $type51
                 (local.get $15)
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
               (struct.set $type71 1
                (local.tee $7
                 (struct.new_default $type71)
                )
                (struct.new $type69
                 (ref.func $function72)
                 (struct.new $environment72
                  (local.get $7)
                 )
                )
               )
               (struct.set $type71 0
                (local.get $7)
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (struct.get $type71 0
                  (local.get $7)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (call_ref $call69
                (struct.get $type69 1
                 (local.tee $16
                  (ref.as_non_null
                   (struct.get $type71 1
                    (local.get $7)
                   )
                  )
                 )
                )
                (local.get $10)
                (ref.null none)
                (struct.get $type69 0
                 (local.get $16)
                )
               )
              )
             )
             (block (result (ref (exact $type15)))
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $1
                   (struct.get $environment102 0
                    (local.get $4)
                   )
                  )
                  (local.tee $19
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                 )
                 (i64.xor
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready161)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global161)
               )
              )
              (struct.set $type61 1
               (local.tee $3
                (struct.new_default $type61)
               )
               (struct.new $type59
                (ref.func $function78)
                (struct.new $environment78
                 (local.get $19)
                 (local.get $3)
                )
               )
              )
              (struct.set $type61 0
               (local.get $3)
               (i32.const 1)
              )
              (if
               (i32.eqz
                (struct.get $type61 0
                 (local.get $3)
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $5
               (call_ref $call59
                (struct.get $type59 1
                 (local.tee $11
                  (ref.as_non_null
                   (struct.get $type61 1
                    (local.get $3)
                   )
                  )
                 )
                )
                (ref.null none)
                (i64.div_s
                 (local.get $19)
                 (i64.const 4)
                )
                (struct.get $type59 0
                 (local.get $11)
                )
               )
              )
              (struct.set $type74 1
               (local.tee $8
                (struct.new_default $type74)
               )
               (struct.new $type72
                (struct.new $environment86
                 (struct.get $environment102 2
                  (local.get $4)
                 )
                 (local.get $8)
                )
               )
              )
              (struct.set $type74 0
               (local.get $8)
               (i32.const 1)
              )
              (if
               (i32.eqz
                (struct.get $type74 0
                 (local.get $8)
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $12
               (struct.get $type72 0
                (struct.get $type74 1
                 (local.get $8)
                )
               )
              )
              (struct.new $type15
               (if (result (ref null $type16))
                (ref.is_null
                 (local.get $5)
                )
                (then
                 (ref.null none)
                )
                (else
                 (call $function89
                  (struct.new $environment89
                   (struct.get $environment86 0
                    (local.get $12)
                   )
                   (struct.get $environment86 1
                    (local.get $12)
                   )
                   (local.get $5)
                   (ref.null none)
                   (local.tee $6
                    (struct.get $type49 0
                     (local.get $5)
                    )
                   )
                   (array.get $type13
                    (local.get $6)
                    (i32.const 0)
                   )
                  )
                  (array.get $type13
                   (local.get $6)
                   (i32.const 1)
                  )
                 )
                )
               )
               (block (result nullref)
                (drop
                 (ref.as_non_null
                  (global.get $global198)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready200)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global200)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready203)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global203)
                 )
                )
                (ref.null none)
               )
              )
             )
            )
           )
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type15 1
             (local.get $2)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type15 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type15 1
                 (local.get $2)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type15 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type15 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type15 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type15 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $2
                          (struct.get $type15 1
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $2
                            (struct.get $type15 1
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $2
                              (struct.get $type15 1
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $2
                                (struct.get $type15 1
                                 (local.get $2)
                                )
                               )
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (call $function106
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type15 1
                                 (local.get $2)
                                )
                                (i64.const 13)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function107
     (array.new $type23
      (struct.get $type15 0
       (local.get $13)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (local.get $13)
     (i64.const 0)
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $19
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready114)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global114)
     )
    )
    (struct.set $type61 1
     (local.tee $3
      (struct.new_default $type61)
     )
     (struct.new $type59
      (ref.func $function49)
      (struct.new $environment49
       (local.get $19)
       (local.get $3)
      )
     )
    )
    (struct.set $type61 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call59
      (struct.get $type59 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type61 1
          (local.get $3)
         )
        )
       )
      )
      (ref.null none)
      (i64.div_s
       (local.get $19)
       (i64.const 3)
      )
      (struct.get $type59 0
       (local.get $11)
      )
     )
    )
    (struct.set $type62 1
     (local.tee $9
      (struct.new_default $type62)
     )
     (struct.new $type57
      (struct.new $environment58
       (struct.get $environment102 2
        (local.get $4)
       )
       (local.get $9)
      )
     )
    )
    (struct.set $type62 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (struct.get $type57 0
      (struct.get $type62 1
       (local.get $9)
      )
     )
    )
    (local.set $10
     (if (result (ref null $type52))
      (ref.is_null
       (local.get $5)
      )
      (then
       (ref.null none)
      )
      (else
       (call $function61
        (struct.new $environment61
         (struct.get $environment58 0
          (local.get $14)
         )
         (struct.get $environment58 1
          (local.get $14)
         )
         (local.get $5)
         (ref.null none)
         (local.tee $6
          (struct.get $type49 0
           (local.get $5)
          )
         )
         (array.get $type13
          (local.get $6)
          (i32.const 0)
         )
        )
        (array.get $type13
         (local.get $6)
         (i32.const 1)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type51
     (struct.get $environment102 2
      (local.get $4)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $10)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $19
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $19)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (struct.get $environment102 3
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function102
     (struct.get $type47 1
      (struct.get $type78 1
       (struct.get $environment102 3
        (local.get $4)
       )
      )
     )
     (local.get $19)
    )
   )
  )
  (unreachable)
 )
 (func $function106 (type $9) (param $0 i32) (param $1 i32) (param $2 (ref null $type15)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type15 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function106
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function107 (type $8) (param $0 (ref null $type23)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type15)) (param $5 i64) (result (ref $type23))
  (local $6 i64)
  (local $7 (ref null $type16))
  (if (result (ref $type23))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type15 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type23
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type15 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function107
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function110 (type $call44) (param $0 (ref null $type16)) (result i64)
  (local $1 (ref $environment112))
  (local $2 (ref $type82))
  (struct.set $type82 1
   (local.tee $2
    (struct.new_default $type82)
   )
   (struct.new $type80
    (struct.new $environment112
     (local.get $2)
    )
   )
  )
  (struct.set $type82 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type82 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type80 0
    (struct.get $type82 1
     (local.get $2)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $0
     (struct.get $type16 0
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment112 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type80 0
      (struct.get $type82 1
       (struct.get $environment112 0
        (local.get $1)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $0
       (struct.get $type16 0
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type82 0
         (struct.get $environment112 0
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type80 0
        (struct.get $type82 1
         (struct.get $environment112 0
          (local.get $1)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $0
         (struct.get $type16 0
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (struct.get $type82 0
           (struct.get $environment112 0
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type80 0
          (struct.get $type82 1
           (struct.get $environment112 0
            (local.get $1)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $0)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $0
           (struct.get $type16 0
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (struct.get $type82 0
             (struct.get $environment112 0
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type80 0
            (struct.get $type82 1
             (struct.get $environment112 0
              (local.get $1)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $0
             (struct.get $type16 0
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type82 0
               (struct.get $environment112 0
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (struct.get $type80 0
              (struct.get $type82 1
               (struct.get $environment112 0
                (local.get $1)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $0)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $0
               (struct.get $type16 0
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (struct.get $type82 0
                 (struct.get $environment112 0
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $1
               (struct.get $type80 0
                (struct.get $type82 1
                 (struct.get $environment112 0
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $0
                 (struct.get $type16 0
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type82 0
                   (struct.get $environment112 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type80 0
                  (struct.get $type82 1
                   (struct.get $environment112 0
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $0
                   (struct.get $type16 0
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type82 0
                     (struct.get $environment112 0
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type80 0
                    (struct.get $type82 1
                     (struct.get $environment112 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $0
                     (struct.get $type16 0
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type82 0
                       (struct.get $environment112 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $1
                     (struct.get $type80 0
                      (struct.get $type82 1
                       (struct.get $environment112 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $0)
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (local.set $0
                       (struct.get $type16 0
                        (local.get $0)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type82 0
                         (struct.get $environment112 0
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $1
                       (struct.get $type80 0
                        (struct.get $type82 1
                         (struct.get $environment112 0
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (local.set $0
                         (struct.get $type16 0
                          (local.get $0)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type82 0
                           (struct.get $environment112 0
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $1
                         (struct.get $type80 0
                          (struct.get $type82 1
                           (struct.get $environment112 0
                            (local.get $1)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (ref.is_null
                          (local.get $0)
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (local.set $0
                           (struct.get $type16 0
                            (local.get $0)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type82 0
                             (struct.get $environment112 0
                              (local.get $1)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $1
                           (struct.get $type80 0
                            (struct.get $type82 1
                             (struct.get $environment112 0
                              (local.get $1)
                             )
                            )
                           )
                          )
                          (if (result i64)
                           (ref.is_null
                            (local.get $0)
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (local.set $0
                             (struct.get $type16 0
                              (local.get $0)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type82 0
                               (struct.get $environment112 0
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.set $1
                             (struct.get $type80 0
                              (struct.get $type82 1
                               (struct.get $environment112 0
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (if (result i64)
                             (ref.is_null
                              (local.get $0)
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (local.set $0
                               (struct.get $type16 0
                                (local.get $0)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type82 0
                                 (struct.get $environment112 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $1
                               (struct.get $type80 0
                                (struct.get $type82 1
                                 (struct.get $environment112 0
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                              (if (result i64)
                               (ref.is_null
                                (local.get $0)
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (local.set $0
                                 (struct.get $type16 0
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type82 0
                                   (struct.get $environment112 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (return_call $function112
                                 (struct.get $type80 0
                                  (struct.get $type82 1
                                   (struct.get $environment112 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (local.get $0)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function112 (type $call80) (param $0 (ref $environment112)) (param $1 (ref null $type16)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type16 0
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment112 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function112
     (struct.get $type80 0
      (struct.get $type82 1
       (struct.get $environment112 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function115 (type $call45) (param $0 (ref null $environment115)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type23))
  (local $4 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment115 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type45 1
      (global.get $global225)
     )
    )
    (drop
     (struct.get $environment115 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global219)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (local.set $3
     (call $function42
      (struct.get $type47 1
       (global.get $global108)
      )
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global214)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (call $function110
          (array.get $type23
           (local.get $3)
           (i32.const 0)
          )
         )
        )
        (block (result i64)
         (drop
          (ref.as_non_null
           (global.get $global214)
          )
         )
         (local.tee $1
          (i64.add
           (local.tee $4
            (call $function110
             (array.get $type23
              (local.get $3)
              (i32.const 1)
             )
            )
           )
           (local.get $1)
          )
         )
        )
       )
       (i64.xor
        (local.get $1)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type84 0
       (struct.get $environment115 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function115
     (struct.get $type45 1
      (struct.get $type84 1
       (struct.get $environment115 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function116 (type $call45) (param $0 (ref null $environment115)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type84))
  (local $2 (ref $type45))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready220)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (struct.set $type84 1
   (local.tee $1
    (struct.new_default $type84)
   )
   (struct.new $type45
    (ref.func $function115)
    (struct.new $environment115
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type84 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type84 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call45
   (struct.get $type45 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type84 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type45 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type11)
  )
  (global.set $global198
   (struct.new_default $type14)
  )
  (global.set $global124
   (struct.new_default $type24)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global200
   (struct.new_default $type25)
  )
  (global.set $ready200
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type28)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type29)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global214
   (struct.new_default $type44)
  )
  (global.set $global169
   (struct.new $type45
    (ref.func $function81)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new_default $type46)
  )
  (global.set $global225
   (struct.new $type45
    (ref.func $function116)
    (ref.null none)
   )
  )
  (global.set $global108
   (struct.new $type47
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $global114
   (struct.new_default $type48)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type48)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global211
   (struct.new_default $type50)
  )
  (global.set $global219
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global220
   (struct.new_default $type50)
  )
  (global.set $ready220
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

