(module
 (rec
  (type $call28 (func (param i64) (result i64)))
  (type $type30 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $environment43 (struct (field i64) (field (ref $type30))))
  (type $call27 (func (param (ref null $environment43) i64 i64) (result i64)))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment43))))
 )
 (type $6 (func (param i64) (result i64)))
 (type $7 (func (param i32) (result i64)))
 (type $8 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type27)) (ref.null none))
 (global $global115 (mut (ref null $type28)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global106 (mut i64) (i64.const 0))
 (global $global107 (mut (ref null $type28)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment43 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global112)
     )
    )
    (drop
     (struct.get $environment43 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $function45
      (block (result i64)
       (local.set $scratch
        (call $foreign0
         (global.get $global106)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global115)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type27 1
      (struct.get $type30 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function45 (type $call28) (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 i64)
  (if
   (i64.ge_s
    (local.get $0)
    (i64.const 2)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready115)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (local.set $1
     (call $function45
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $0)
          (i64.const 2)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready115)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $0
         (i64.add
          (local.get $1)
          (local.tee $2
           (call $function45
            (local.get $2)
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $0)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (local.get $0)
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type30))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (struct.set $type30 1
   (local.tee $1
    (struct.new_default $type30)
   )
   (struct.new $type27
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type30 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type30 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global112
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global115
   (struct.new_default $type28)
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global106
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global107
   (struct.new_default $type28)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

