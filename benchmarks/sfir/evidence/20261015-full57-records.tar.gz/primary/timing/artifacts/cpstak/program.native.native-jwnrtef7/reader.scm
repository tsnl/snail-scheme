(module
 (rec
  (type $environment50 (struct (field (ref $type32)) (field (ref $type29)) (field i64) (field i64)))
  (type $environment49 (struct (field (ref $type32)) (field i64) (field i64) (field i64) (field (ref $type29)) (field i64)))
  (type $environment48 (struct (field (ref $type32)) (field i64) (field i64) (field i64) (field (ref $type29))))
  (type $3 (func (param (ref $type32) i64 i64 i64 (ref $type29)) (result i64)))
  (type $type32 (struct (field i32)))
  (type $call27 (func (param (ref null $environment43) i64 i64) (result i64)))
  (type $environment43 (struct (field i64) (field (ref $type31))))
  (type $type31 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $call29 (func (param structref i64) (result i64)))
  (type $type29 (struct (field (ref $call29)) (field structref)))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment43))))
 )
 (type $12 (func (param i64) (result i64)))
 (type $13 (func (param i32) (result i64)))
 (type $14 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type27)) (ref.null none))
 (global $global117 (mut (ref null $type28)) (ref.null none))
 (global $global106 (mut i64) (i64.const 0))
 (global $global107 (mut i64) (i64.const 0))
 (global $global108 (mut i64) (i64.const 0))
 (global $global109 (mut (ref null $type29)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call29) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type31))
  (local $3 (ref $type27))
  (struct.set $type31 1
   (local.tee $2
    (struct.new_default $type31)
   )
   (struct.new $type27
    (ref.func $function43)
    (struct.new $environment43
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type31 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type31 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $3)
   )
  )
 )
 (func $function43 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $type29))
  (local $8 (ref $type32))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment43 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global114)
     )
    )
    (drop
     (struct.get $environment43 0
      (local.get $0)
     )
    )
    (local.set $3
     (call $foreign0
      (global.get $global106)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global114)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global107)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global114)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global108)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if
     (i64.lt_s
      (local.get $2)
      (local.get $3)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $4
           (i64.sub
            (local.get $3)
            (i64.const 1)
           )
          )
          (local.get $3)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (struct.new $type29
        (ref.func $function48)
        (struct.new $environment48
         (local.tee $8
          (struct.new $type32
           (i32.const 1)
          )
         )
         (local.get $3)
         (local.get $2)
         (local.get $1)
         (struct.new $type29
          (ref.func $function46)
          (ref.null none)
         )
        )
       )
      )
      (local.set $1
       (if (result i64)
        (i64.lt_s
         (local.get $2)
         (local.get $4)
        )
        (then
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $5
              (i64.sub
               (local.get $4)
               (i64.const 1)
              )
             )
             (local.get $4)
            )
            (i64.xor
             (local.get $4)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (struct.new $type29
           (ref.func $function48)
           (struct.new $environment48
            (local.get $8)
            (local.get $4)
            (local.get $2)
            (local.get $1)
            (local.get $7)
           )
          )
         )
         (if (result i64)
          (i64.lt_s
           (local.get $2)
           (local.get $5)
          )
          (then
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $3
                (i64.sub
                 (local.get $5)
                 (i64.const 1)
                )
               )
               (local.get $5)
              )
              (i64.xor
               (local.get $5)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (local.set $7
            (struct.new $type29
             (ref.func $function48)
             (struct.new $environment48
              (local.get $8)
              (local.get $5)
              (local.get $2)
              (local.get $1)
              (local.get $7)
             )
            )
           )
           (if (result i64)
            (i64.lt_s
             (local.get $2)
             (local.get $3)
            )
            (then
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $4
                  (i64.sub
                   (local.get $3)
                   (i64.const 1)
                  )
                 )
                 (local.get $3)
                )
                (i64.xor
                 (local.get $3)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (local.set $7
              (struct.new $type29
               (ref.func $function48)
               (struct.new $environment48
                (local.get $8)
                (local.get $3)
                (local.get $2)
                (local.tee $3
                 (local.get $1)
                )
                (local.get $7)
               )
              )
             )
             (if (result i64)
              (i64.lt_s
               (local.get $2)
               (local.tee $1
                (local.get $4)
               )
              )
              (then
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $4
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (local.get $1)
                  )
                  (i64.xor
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (call $function47
                (local.get $8)
                (local.get $4)
                (local.get $2)
                (local.get $3)
                (struct.new $type29
                 (ref.func $function48)
                 (struct.new $environment48
                  (local.get $8)
                  (local.get $1)
                  (local.get $2)
                  (local.get $3)
                  (local.get $7)
                 )
                )
               )
              )
              (else
               (call_ref $call29
                (struct.get $type29 1
                 (local.get $7)
                )
                (local.get $3)
                (struct.get $type29 0
                 (local.get $7)
                )
               )
              )
             )
            )
            (else
             (call_ref $call29
              (struct.get $type29 1
               (local.get $7)
              )
              (local.get $1)
              (struct.get $type29 0
               (local.get $7)
              )
             )
            )
           )
          )
          (else
           (call_ref $call29
            (struct.get $type29 1
             (local.get $7)
            )
            (local.get $1)
            (struct.get $type29 0
             (local.get $7)
            )
           )
          )
         )
        )
        (else
         (call_ref $call29
          (struct.get $type29 1
           (local.get $7)
          )
          (local.get $1)
          (struct.get $type29 0
           (local.get $7)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type27 1
      (struct.get $type31 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $6)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function46 (type $call29) (param $0 structref) (param $1 i64) (result i64)
  (local.get $1)
 )
 (func $function47 (type $3) (param $0 (ref $type32)) (param $1 i64) (param $2 i64) (param $3 i64) (param $4 (ref $type29)) (result i64)
  (local $5 i64)
  (if
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (local.get $0)
     (local.get $5)
     (local.get $2)
     (local.get $3)
     (struct.new $type29
      (ref.func $function48)
      (struct.new $environment48
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
      )
     )
    )
   )
   (else
    (return_call_ref $call29
     (struct.get $type29 1
      (local.get $4)
     )
     (local.get $3)
     (struct.get $type29 0
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function48 (type $call29) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type29))
  (local $7 (ref $type32))
  (local $8 (ref $environment48))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.sub
        (local.tee $2
         (struct.get $environment48 2
          (ref.cast (ref $environment48)
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $environment48 3
    (local.tee $8
     (ref.cast (ref $environment48)
      (local.get $0)
     )
    )
   )
  )
  (local.set $6
   (struct.new $type29
    (ref.func $function49)
    (struct.new $environment49
     (local.tee $7
      (struct.get $environment48 0
       (local.get $8)
      )
     )
     (local.tee $4
      (struct.get $environment48 1
       (local.get $8)
      )
     )
     (struct.get $environment48 2
      (local.get $8)
     )
     (struct.get $environment48 3
      (local.get $8)
     )
     (struct.get $environment48 4
      (local.get $8)
     )
     (local.get $1)
    )
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.new $type29
      (ref.func $function48)
      (struct.new $environment48
       (local.get $7)
       (local.get $3)
       (local.get $2)
       (local.get $4)
       (ref.as_non_null
        (local.get $6)
       )
      )
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.new $type29
        (ref.func $function48)
        (struct.new $environment48
         (local.get $7)
         (local.get $1)
         (local.get $2)
         (local.get $4)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $2)
        (local.get $3)
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $3)
              (i64.const 1)
             )
            )
            (local.get $3)
           )
           (i64.xor
            (local.get $3)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.new $type29
          (ref.func $function48)
          (struct.new $environment48
           (local.get $7)
           (local.get $3)
           (local.get $2)
           (local.get $4)
           (ref.as_non_null
            (local.get $6)
           )
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $2)
          (local.get $5)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $1
               (i64.sub
                (local.get $5)
                (i64.const 1)
               )
              )
              (local.get $5)
             )
             (i64.xor
              (local.get $5)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $6
           (struct.new $type29
            (ref.func $function48)
            (struct.new $environment48
             (local.get $7)
             (local.get $5)
             (local.get $2)
             (local.get $4)
             (ref.as_non_null
              (local.get $6)
             )
            )
           )
          )
          (if
           (i64.gt_s
            (local.get $1)
            (local.get $2)
           )
           (then
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $3
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $1)
               )
               (i64.xor
                (local.get $1)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function47
             (local.get $7)
             (local.get $3)
             (local.get $2)
             (local.get $4)
             (struct.new $type29
              (ref.func $function48)
              (struct.new $environment48
               (local.get $7)
               (local.get $1)
               (local.get $2)
               (local.get $4)
               (ref.as_non_null
                (local.get $6)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.get $6)
   )
   (local.get $4)
   (struct.get $type29 0
    (local.get $6)
   )
  )
 )
 (func $function49 (type $call29) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type29))
  (local $7 (ref $type32))
  (local $8 (ref $environment49))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.sub
        (local.tee $2
         (struct.get $environment49 3
          (ref.cast (ref $environment49)
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $environment49 1
    (local.tee $8
     (ref.cast (ref $environment49)
      (local.get $0)
     )
    )
   )
  )
  (local.set $4
   (struct.get $environment49 2
    (local.get $8)
   )
  )
  (local.set $6
   (struct.new $type29
    (ref.func $function50)
    (struct.new $environment50
     (local.tee $7
      (struct.get $environment49 0
       (local.get $8)
      )
     )
     (struct.get $environment49 4
      (local.get $8)
     )
     (struct.get $environment49 5
      (local.get $8)
     )
     (local.get $1)
    )
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.new $type29
      (ref.func $function48)
      (struct.new $environment48
       (local.get $7)
       (local.get $3)
       (local.get $2)
       (local.get $4)
       (ref.as_non_null
        (local.get $6)
       )
      )
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.new $type29
        (ref.func $function48)
        (struct.new $environment48
         (local.get $7)
         (local.get $1)
         (local.get $2)
         (local.get $4)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $2)
        (local.get $3)
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $3)
              (i64.const 1)
             )
            )
            (local.get $3)
           )
           (i64.xor
            (local.get $3)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.new $type29
          (ref.func $function48)
          (struct.new $environment48
           (local.get $7)
           (local.get $3)
           (local.get $2)
           (local.get $4)
           (ref.as_non_null
            (local.get $6)
           )
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $2)
          (local.get $5)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $1
               (i64.sub
                (local.get $5)
                (i64.const 1)
               )
              )
              (local.get $5)
             )
             (i64.xor
              (local.get $5)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $6
           (struct.new $type29
            (ref.func $function48)
            (struct.new $environment48
             (local.get $7)
             (local.get $5)
             (local.get $2)
             (local.get $4)
             (ref.as_non_null
              (local.get $6)
             )
            )
           )
          )
          (if
           (i64.gt_s
            (local.get $1)
            (local.get $2)
           )
           (then
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $3
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $1)
               )
               (i64.xor
                (local.get $1)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function47
             (local.get $7)
             (local.get $3)
             (local.get $2)
             (local.get $4)
             (struct.new $type29
              (ref.func $function48)
              (struct.new $environment48
               (local.get $7)
               (local.get $1)
               (local.get $2)
               (local.get $4)
               (ref.as_non_null
                (local.get $6)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.get $6)
   )
   (local.get $4)
   (struct.get $type29 0
    (local.get $6)
   )
  )
 )
 (func $function50 (type $call29) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type29))
  (local $7 (ref $type29))
  (local $8 (ref $type32))
  (local $9 (ref null $type29))
  (local $10 (ref $environment50))
  (local.set $2
   (struct.get $environment50 2
    (local.tee $10
     (ref.cast (ref $environment50)
      (local.get $0)
     )
    )
   )
  )
  (local.set $7
   (struct.get $environment50 1
    (local.get $10)
   )
  )
  (if
   (i64.lt_s
    (local.tee $3
     (struct.get $environment50 3
      (local.get $10)
     )
    )
    (local.get $2)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.new $type29
      (ref.func $function48)
      (struct.new $environment48
       (local.tee $8
        (struct.get $environment50 0
         (local.get $10)
        )
       )
       (local.get $2)
       (local.get $3)
       (local.get $1)
       (local.get $7)
      )
     )
    )
    (if
     (i64.lt_s
      (local.get $3)
      (local.get $4)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.sub
            (local.get $4)
            (i64.const 1)
           )
          )
          (local.get $4)
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (struct.new $type29
        (ref.func $function48)
        (struct.new $environment48
         (local.get $8)
         (local.get $4)
         (local.get $3)
         (local.get $1)
         (ref.as_non_null
          (local.get $9)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $3)
        (local.get $5)
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $2
             (i64.sub
              (local.get $5)
              (i64.const 1)
             )
            )
            (local.get $5)
           )
           (i64.xor
            (local.get $5)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.new $type29
          (ref.func $function48)
          (struct.new $environment48
           (local.get $8)
           (local.get $5)
           (local.get $3)
           (local.get $1)
           (ref.as_non_null
            (local.get $9)
           )
          )
         )
        )
        (if
         (i64.gt_s
          (local.get $2)
          (local.get $3)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $4
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (local.get $2)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.set $6
           (struct.new $type29
            (ref.func $function48)
            (struct.new $environment48
             (local.get $8)
             (local.get $2)
             (local.get $3)
             (local.tee $2
              (local.get $1)
             )
             (local.get $6)
            )
           )
          )
          (if
           (i64.lt_s
            (local.get $3)
            (local.tee $1
             (local.get $4)
            )
           )
           (then
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $4
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $1)
               )
               (i64.xor
                (local.get $1)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function47
             (local.get $8)
             (local.get $4)
             (local.get $3)
             (local.get $2)
             (struct.new $type29
              (ref.func $function48)
              (struct.new $environment48
               (local.get $8)
               (local.get $1)
               (local.get $3)
               (local.get $2)
               (local.get $6)
              )
             )
            )
           )
           (else
            (return_call_ref $call29
             (struct.get $type29 1
              (local.get $6)
             )
             (local.get $2)
             (struct.get $type29 0
              (local.get $6)
             )
            )
           )
          )
          (unreachable)
         )
         (else
          (return_call_ref $call29
           (struct.get $type29 1
            (local.get $6)
           )
           (local.get $1)
           (struct.get $type29 0
            (local.get $6)
           )
          )
         )
        )
        (unreachable)
       )
      )
     )
    )
   )
   (else
    (return_call_ref $call29
     (struct.get $type29 1
      (local.get $7)
     )
     (local.get $1)
     (struct.get $type29 0
      (local.get $7)
     )
    )
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.get $9)
   )
   (local.get $1)
   (struct.get $type29 0
    (local.get $9)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type31))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type29 1
    (global.get $global109)
   )
  )
  (struct.set $type31 1
   (local.tee $1
    (struct.new_default $type31)
   )
   (struct.new $type27
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type31 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type31 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global114
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global117
   (struct.new_default $type28)
  )
  (global.set $global106
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global107
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global108
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $global109
   (struct.new $type29
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

