(module
 (rec
  (type $call36 (func (param (ref $environment51) (ref null $type28) i64) (result i64)))
  (type $call27 (func (param (ref null $type28)) (result (ref null $type28))))
  (type $2 (func (param (ref null $type28)) (result (ref null $type28))))
  (type $type36 (struct (field (ref $environment51))))
  (type $environment46 (struct (field i64) (field (ref $type35))))
  (type $type38 (struct (field (mut i32)) (field (mut (ref null $type36)))))
  (type $environment51 (struct (field (ref $type38))))
  (type $call32 (func (param i64) (result i64)))
  (type $type33 (struct (field (ref $call33)) (field (ref struct))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $environment43 (struct (field (ref $type35))))
  (type $call33 (func (param (ref struct) i64 (ref null $type28)) (result (ref null $type28))))
  (type $type32 (struct))
  (type $type28 (struct (field nullref) (field (ref null $type28))))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type27 (struct))
 )
 (type $17 (func (param i32) (result i64)))
 (type $18 (func (param i64) (result i64)))
 (type $19 (func))
 (import "benchmark" "input_i64" (func $foreign0 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type27)) (ref.null none))
 (global $global121 (mut (ref null $type30)) (ref.null none))
 (global $global106 (mut (ref null $type31)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type27)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $global112 (mut (ref null $type32)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call33) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type33 1
      (struct.get $type35 1
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (ref.null none)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function44 (type $call32) (param $0 i64) (result i64)
  (local $1 (ref null $type28))
  (local $2 (ref $environment51))
  (local $3 (ref $type35))
  (local $4 (ref $type38))
  (local $5 (ref $type33))
  (struct.set $type35 1
   (local.tee $3
    (struct.new_default $type35)
   )
   (struct.new $type33
    (ref.func $function46)
    (struct.new $environment46
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type35 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call33
    (struct.get $type33 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type33 0
     (local.get $5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (struct.set $type38 1
   (local.tee $4
    (struct.new_default $type38)
   )
   (struct.new $type36
    (struct.new $environment51
     (local.get $4)
    )
   )
  )
  (struct.set $type38 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type38 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type36 0
    (struct.get $type38 1
     (local.get $4)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (struct.get $environment51 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type36 0
      (struct.get $type38 1
       (struct.get $environment51 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type38 0
         (struct.get $environment51 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type36 0
        (struct.get $type38 1
         (struct.get $environment51 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type28 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type38 0
           (struct.get $environment51 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type36 0
          (struct.get $type38 1
           (struct.get $environment51 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type38 0
             (struct.get $environment51 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type36 0
            (struct.get $type38 1
             (struct.get $environment51 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type28 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type38 0
               (struct.get $environment51 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type36 0
              (struct.get $type38 1
               (struct.get $environment51 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type38 0
                 (struct.get $environment51 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type36 0
                (struct.get $type38 1
                 (struct.get $environment51 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type28 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type38 0
                   (struct.get $environment51 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type36 0
                  (struct.get $type38 1
                   (struct.get $environment51 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type38 0
                     (struct.get $environment51 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type36 0
                    (struct.get $type38 1
                     (struct.get $environment51 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type28 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type38 0
                       (struct.get $environment51 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function51
                     (struct.get $type36 0
                      (struct.get $type38 1
                       (struct.get $environment51 0
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function46 (type $call33) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 nullref)
  (local $5 i64)
  (local $scratch (ref null $type28))
  (if (result (ref null $type28))
   (i64.gt_s
    (struct.get $environment46 0
     (ref.cast (ref $environment46)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (local.set $2
     (if (result (ref null $type28))
      (ref.is_null
       (local.tee $3
        (global.get $global111)
       )
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type28
        (struct.get $type28 0
         (local.get $3)
        )
        (block (result (ref null $type28))
         (drop
          (ref.as_non_null
           (global.get $global119)
          )
         )
         (local.set $3
          (struct.get $type28 1
           (struct.get $type28 1
            (local.get $3)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready117)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global117)
          )
         )
         (if (result (ref null $type28))
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type28
            (struct.get $type28 0
             (local.get $3)
            )
            (block (result (ref null $type28))
             (drop
              (ref.as_non_null
               (global.get $global119)
              )
             )
             (local.set $3
              (struct.get $type28 1
               (struct.get $type28 1
                (local.get $3)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready117)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global117)
              )
             )
             (if (result (ref null $type28))
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type28
                (struct.get $type28 0
                 (local.get $3)
                )
                (block (result (ref null $type28))
                 (drop
                  (ref.as_non_null
                   (global.get $global119)
                  )
                 )
                 (local.set $3
                  (struct.get $type28 1
                   (struct.get $type28 1
                    (local.get $3)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready117)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global117)
                  )
                 )
                 (if (result (ref null $type28))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type28
                    (struct.get $type28 0
                     (local.get $3)
                    )
                    (block (result (ref null $type28))
                     (drop
                      (ref.as_non_null
                       (global.get $global119)
                      )
                     )
                     (local.set $3
                      (struct.get $type28 1
                       (struct.get $type28 1
                        (local.get $3)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready117)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global117)
                      )
                     )
                     (if (result (ref null $type28))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type28
                        (struct.get $type28 0
                         (local.get $3)
                        )
                        (block (result (ref null $type28))
                         (drop
                          (ref.as_non_null
                           (global.get $global119)
                          )
                         )
                         (local.set $3
                          (struct.get $type28 1
                           (struct.get $type28 1
                            (local.get $3)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready117)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global117)
                          )
                         )
                         (if (result (ref null $type28))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type28
                            (struct.get $type28 0
                             (local.get $3)
                            )
                            (block (result (ref null $type28))
                             (drop
                              (ref.as_non_null
                               (global.get $global119)
                              )
                             )
                             (local.set $3
                              (struct.get $type28 1
                               (struct.get $type28 1
                                (local.get $3)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready117)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global117)
                              )
                             )
                             (if (result (ref null $type28))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type28
                                (struct.get $type28 0
                                 (local.get $3)
                                )
                                (block (result (ref null $type28))
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global119)
                                  )
                                 )
                                 (local.set $3
                                  (struct.get $type28 1
                                   (struct.get $type28 1
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready117)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global117)
                                  )
                                 )
                                 (if (result (ref null $type28))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type28
                                    (struct.get $type28 0
                                     (local.get $3)
                                    )
                                    (block (result (ref null $type28))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global119)
                                      )
                                     )
                                     (local.set $3
                                      (struct.get $type28 1
                                       (struct.get $type28 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready117)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global117)
                                      )
                                     )
                                     (if (result (ref null $type28))
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type28
                                        (struct.get $type28 0
                                         (local.get $3)
                                        )
                                        (block (result (ref null $type28))
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global119)
                                          )
                                         )
                                         (local.set $3
                                          (struct.get $type28 1
                                           (struct.get $type28 1
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready117)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global117)
                                          )
                                         )
                                         (if (result (ref null $type28))
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type28
                                            (struct.get $type28 0
                                             (local.get $3)
                                            )
                                            (block (result (ref null $type28))
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global119)
                                              )
                                             )
                                             (call $function47
                                              (block (result (ref null $type28))
                                               (local.set $scratch
                                                (call $function48
                                                 (local.get $3)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready117)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global117)
                                                )
                                               )
                                               (local.get $scratch)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment46 1
        (ref.cast (ref $environment46)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (struct.get $type33 1
      (struct.get $type35 1
       (struct.get $environment46 1
        (ref.cast (ref $environment46)
         (local.get $0)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function47 (type $2) (param $0 (ref null $type28)) (result (ref null $type28))
  (local $1 nullref)
  (local $scratch (ref null $type28))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (block (result (ref null $type28))
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (call $function47
       (block (result (ref null $type28))
        (local.set $scratch
         (call $function48
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready117)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global117)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function48 (type $call27) (param $0 (ref null $type28)) (result (ref null $type28))
  (struct.get $type28 1
   (struct.get $type28 1
    (local.get $0)
   )
  )
 )
 (func $function51 (type $call36) (param $0 (ref $environment51)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (struct.get $environment51 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type36 0
      (struct.get $type38 1
       (struct.get $environment51 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (return_call $function44
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type35))
  (local $1 (ref $type33))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type27)
  )
  (global.set $global121
   (struct.new_default $type30)
  )
  (global.set $global106
   (struct.new_default $type31)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type27)
  )
  (global.set $ready117
   (i32.const 1)
  )
  (local.set $2
   (call $foreign0
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (struct.set $type35 1
   (local.tee $0
    (struct.new_default $type35)
   )
   (struct.new $type33
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
    )
   )
  )
  (struct.set $type35 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global111
   (call_ref $call33
    (struct.get $type33 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type33 0
     (local.get $1)
    )
   )
  )
  (global.set $global112
   (struct.new_default $type32)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

