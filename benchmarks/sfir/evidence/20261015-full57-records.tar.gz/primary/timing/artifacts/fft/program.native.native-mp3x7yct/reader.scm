(module
 (rec
  (type $type0 (struct (field (ref $environment80))))
  (type $type56 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment80 (struct (field i64) (field (ref $type56))))
  (type $call0 (func (param (ref $environment80) i64 f64) (result f64)))
  (type $environment70 (struct (field (ref $type28)) (field i64) (field i64) (field f64) (field f64) (field (ref $type52)) (field f64) (field f64) (field i64) (field (ref $type39))))
  (type $type50 (struct (field (ref $environment68))))
  (type $type37 (struct (field (ref $call37)) (field (ref struct))))
  (type $environment61 (struct (field (ref $type28)) (field i64) (field (ref $type39))))
  (type $type39 (struct (field (mut i32)) (field (mut (ref null $type37)))))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $environment68 (struct (field (ref $type28)) (field i64) (field i64) (field f64) (field f64) (field (ref $type52))))
  (type $call37 (func (param (ref struct) i64) (result i32)))
  (type $environment59 (struct (field (ref $type47)) (field i64) (field (ref $type47))))
  (type $type45 (struct (field (ref $call45)) (field (ref struct))))
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type45)))))
  (type $environment55 (struct (field (ref $type28)) (field i64) (field (ref $type47))))
  (type $type28 (array (mut f64)))
  (type $call45 (func (param (ref struct) i64 i64) (result i32)))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
 )
 (type $22 (func (param f64) (result f64)))
 (type $23 (func (result i32)))
 (type $24 (func (param i32) (result f64)))
 (type $25 (func (param i32) (result i64)))
 (type $26 (func (param i64) (result f64)))
 (type $27 (func))
 (import "math" "snail_sin" (func $foreign4 (param f64) (result f64)))
 (import "benchmark" "barrier" (func $foreign6 (result i32)))
 (import "benchmark" "input_f64" (func $foreign7 (param i32) (result f64)))
 (import "benchmark" "input_i64" (func $foreign8 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type29)) (ref.null none))
 (global $global161 (mut (ref null $type32)) (ref.null none))
 (global $global123 (mut (ref null $type33)) (ref.null none))
 (global $global164 (mut (ref null $type34)) (ref.null none))
 (global $global154 (mut i64) (i64.const 0))
 (global $global155 (mut f64) (f64.const 0.0))
 (global $global156 (mut (ref null $type29)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function55 (type $call45) (param $0 (ref struct)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $type28))
  (local $8 (ref $environment55))
  (local $9 (ref $type47))
  (local $10 (ref $type45))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment55 1
     (local.tee $8
      (ref.cast (ref $environment55)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (array.get $type28
        (local.tee $7
         (struct.get $environment55 0
          (local.get $8)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type28
        (local.get $7)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type28
       (local.get $7)
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $6)
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type28
       (local.get $7)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $5)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (array.get $type28
        (local.tee $7
         (struct.get $environment55 0
          (local.get $8)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $4
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type28
        (local.get $7)
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type28
       (local.get $7)
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $6)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type28
       (local.get $7)
       (i32.wrap_i64
        (local.get $3)
       )
       (local.get $5)
      )
     )
    )
    (struct.set $type47 1
     (local.tee $9
      (struct.new_default $type47)
     )
     (struct.new $type45
      (ref.func $function59)
      (struct.new $environment59
       (struct.get $environment55 2
        (local.get $8)
       )
       (local.get $1)
       (local.get $9)
      )
     )
    )
    (struct.set $type47 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call45
     (struct.get $type45 1
      (local.tee $10
       (ref.as_non_null
        (struct.get $type47 1
         (local.get $9)
        )
       )
      )
     )
     (i64.div_s
      (struct.get $environment55 1
       (local.get $8)
      )
      (i64.const 2)
     )
     (local.get $2)
     (struct.get $type45 0
      (local.get $10)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function59 (type $call45) (param $0 (ref struct)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (if
   (i32.and
    (i64.le_s
     (local.get $1)
     (local.get $2)
    )
    (i64.ge_s
     (local.get $1)
     (i64.const 2)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $2)
          (local.get $1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment59 2
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type45 1
      (struct.get $type47 1
       (struct.get $environment59 2
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (i64.div_s
      (local.get $1)
      (i64.const 2)
     )
     (local.get $3)
    )
   )
   (else
    (local.set $3
     (i64.add
      (local.tee $4
       (struct.get $environment59 1
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
      (i64.const 2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
       (i64.xor
        (local.get $3)
        (i64.const 2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $4
         (i64.add
          (local.get $1)
          (local.get $2)
         )
        )
       )
       (i64.xor
        (local.get $1)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment59 0
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type45 1
      (struct.get $type47 1
       (struct.get $environment59 0
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (local.get $4)
    )
   )
  )
  (unreachable)
 )
 (func $function61 (type $call37) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $environment68))
  (local $8 (ref $type52))
  (local $9 (ref $type39))
  (local $10 (ref $type39))
  (local $11 (ref $environment61))
  (local $12 (ref $type37))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment61 1
     (local.tee $11
      (ref.cast (ref $environment61)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.eq
        (f64.abs
         (local.tee $3
          (f64.div
           (f64.const 6.28318530717959)
           (local.tee $2
            (f64.convert_i64_s
             (local.get $1)
            )
           )
          )
         )
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $2)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.mul
          (local.get $3)
          (f64.const 0.5)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (local.tee $6
        (f64.lt
         (f64.abs
          (local.tee $2
           (call $foreign4
            (local.get $2)
           )
          )
         )
         (f64.const inf)
        )
       )
       (local.get $6)
      )
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.mul
          (local.get $2)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.mul
          (local.get $2)
          (f64.const -2.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type52 1
     (local.tee $8
      (struct.new_default $type52)
     )
     (struct.new $type50
      (struct.new $environment68
       (struct.get $environment61 0
        (local.get $11)
       )
       (struct.get $environment61 1
        (local.get $11)
       )
       (local.get $1)
       (local.get $4)
       (call $foreign4
        (local.get $3)
       )
       (local.get $8)
      )
     )
    )
    (struct.set $type52 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $5
        (struct.get $environment68 2
         (local.tee $7
          (struct.get $type50 0
           (struct.get $type52 1
            (local.get $8)
           )
          )
         )
        )
       )
       (i64.const 0)
      )
      (then
       (struct.set $type39 1
        (local.tee $9
         (struct.new_default $type39)
        )
        (struct.new $type37
         (ref.func $function70)
         (struct.new $environment70
          (struct.get $environment68 0
           (local.get $7)
          )
          (struct.get $environment68 1
           (local.get $7)
          )
          (local.get $5)
          (struct.get $environment68 3
           (local.get $7)
          )
          (struct.get $environment68 4
           (local.get $7)
          )
          (struct.get $environment68 5
           (local.get $7)
          )
          (f64.const 1.0)
          (f64.const 0.0)
          (i64.const 0)
          (local.get $9)
         )
        )
       )
       (struct.set $type39 0
        (local.get $9)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type39 0
          (local.get $9)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call37
        (struct.get $type37 1
         (local.tee $12
          (ref.as_non_null
           (struct.get $type39 1
            (local.get $9)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type37 0
         (local.get $12)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.div_s
       (local.tee $5
        (i64.shl
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 2)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (local.tee $10
        (struct.get $environment61 2
         (local.get $11)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function61
     (struct.get $type37 1
      (struct.get $type39 1
       (local.get $10)
      )
     )
     (local.get $5)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function70 (type $call37) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 (ref $environment70))
  (local $11 (ref $type28))
  (local $12 (ref $environment68))
  (local $13 (ref $type39))
  (local $14 (ref $type39))
  (local $15 (ref $type37))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment70 1
     (local.tee $10
      (ref.cast (ref $environment70)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.tee $7
           (struct.get $environment70 2
            (local.get $10)
           )
          )
          (local.get $1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (f64.mul
      (local.tee $2
       (struct.get $environment70 6
        (local.get $10)
       )
      )
      (local.tee $4
       (array.get $type28
        (local.tee $11
         (struct.get $environment70 0
          (local.get $10)
         )
        )
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (f64.mul
      (local.tee $4
       (struct.get $environment70 7
        (local.get $10)
       )
      )
      (local.tee $6
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $7)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $6)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $5)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.sub
          (local.get $3)
          (local.get $5)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (f64.mul
      (local.get $2)
      (local.tee $6
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $7)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $6)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $5)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (f64.mul
      (local.get $4)
      (local.tee $6
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $8)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $6)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.add
          (local.get $5)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (f64.sub
      (local.tee $5
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type28
     (local.get $11)
     (i32.wrap_i64
      (local.get $8)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (f64.sub
      (local.tee $5
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type28
     (local.get $11)
     (i32.wrap_i64
      (local.get $7)
     )
     (local.get $4)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (f64.add
      (local.tee $5
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type28
     (local.get $11)
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $9
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (f64.add
      (local.tee $4
       (array.get $type28
        (local.get $11)
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type28
     (local.get $11)
     (i32.wrap_i64
      (local.get $7)
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $1
         (i64.add
          (local.get $8)
          (local.tee $7
           (struct.get $environment70 2
            (local.get $10)
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $1)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (local.tee $14
        (struct.get $environment70 9
         (local.get $10)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type37 1
      (struct.get $type39 1
       (local.get $14)
      )
     )
     (local.get $1)
    )
   )
   (else
    (local.set $3
     (f64.mul
      (local.tee $2
       (struct.get $environment70 6
        (local.get $10)
       )
      )
      (local.tee $4
       (struct.get $environment70 3
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (f64.mul
      (local.tee $4
       (struct.get $environment70 7
        (local.get $10)
       )
      )
      (local.tee $5
       (struct.get $environment70 4
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.sub
          (local.get $3)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (f64.add
      (local.get $3)
      (local.tee $2
       (struct.get $environment70 6
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (f64.mul
      (local.tee $2
       (struct.get $environment70 7
        (local.get $10)
       )
      )
      (local.tee $5
       (struct.get $environment70 3
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (f64.mul
      (local.tee $5
       (struct.get $environment70 6
        (local.get $10)
       )
      )
      (local.tee $6
       (struct.get $environment70 4
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $6)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.add
          (local.get $3)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (f64.add
      (local.get $3)
      (local.tee $5
       (struct.get $environment70 7
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (i64.add
      (local.tee $8
       (struct.get $environment70 8
        (local.get $10)
       )
      )
      (i64.const 2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $8)
       )
       (i64.xor
        (local.get $1)
        (i64.const 2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment70 5
        (local.get $10)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.gt_s
      (local.tee $8
       (struct.get $environment68 2
        (local.tee $12
         (struct.get $type50 0
          (struct.get $type52 1
           (struct.get $environment70 5
            (local.get $10)
           )
          )
         )
        )
       )
      )
      (local.get $1)
     )
     (then
      (struct.set $type39 1
       (local.tee $13
        (struct.new_default $type39)
       )
       (struct.new $type37
        (ref.func $function70)
        (struct.new $environment70
         (struct.get $environment68 0
          (local.get $12)
         )
         (struct.get $environment68 1
          (local.get $12)
         )
         (local.get $8)
         (struct.get $environment68 3
          (local.get $12)
         )
         (struct.get $environment68 4
          (local.get $12)
         )
         (struct.get $environment68 5
          (local.get $12)
         )
         (local.get $4)
         (local.get $2)
         (local.get $1)
         (local.get $13)
        )
       )
      )
      (struct.set $type39 0
       (local.get $13)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type39 0
         (local.get $13)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call37
       (struct.get $type37 1
        (local.tee $15
         (ref.as_non_null
          (struct.get $type39 1
           (local.get $13)
          )
         )
        )
       )
       (local.get $1)
       (struct.get $type37 0
        (local.get $15)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function80 (type $call0) (param $0 (ref $environment80)) (param $1 i64) (param $2 f64) (result f64)
  (local $3 (ref $type28))
  (local $4 (ref $type47))
  (local $5 (ref $type39))
  (local $6 (ref $type45))
  (local $7 (ref $type37))
  (local $8 i64)
  (if (result f64)
   (i64.gt_s
    (struct.get $environment80 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $8
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global161)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (global.get $global154)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.new $type28
      (global.get $global155)
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (call $foreign6)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global123)
     )
    )
    (struct.set $type47 1
     (local.tee $4
      (struct.new_default $type47)
     )
     (struct.new $type45
      (ref.func $function55)
      (struct.new $environment55
       (local.get $3)
       (local.tee $1
        (i64.extend_i32_u
         (array.len
          (local.get $3)
         )
        )
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type47 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call45
      (struct.get $type45 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type47 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (i64.const 0)
      (struct.get $type45 0
       (local.get $6)
      )
     )
    )
    (struct.set $type39 1
     (local.tee $5
      (struct.new_default $type39)
     )
     (struct.new $type37
      (ref.func $function61)
      (struct.new $environment61
       (local.get $3)
       (local.get $1)
       (local.get $5)
      )
     )
    )
    (struct.set $type39 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call37
      (struct.get $type37 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type39 1
          (local.get $5)
         )
        )
       )
      )
      (i64.const 2)
      (struct.get $type37 0
       (local.get $7)
      )
     )
    )
    (local.set $2
     (array.get $type28
      (local.get $3)
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment80 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function80
     (struct.get $type0 0
      (struct.get $type56 1
       (struct.get $environment80 1
        (local.get $0)
       )
      )
     )
     (local.get $8)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result f64)
  (local $1 (ref $type56))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready156)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global156)
   )
  )
  (struct.set $type56 1
   (local.tee $1
    (struct.new_default $type56)
   )
   (struct.new $type0
    (struct.new $environment80
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type56 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type56 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function80
   (struct.get $type0 0
    (struct.get $type56 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (f64.const 0.0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global112
   (struct.new_default $type29)
  )
  (global.set $global161
   (struct.new_default $type32)
  )
  (global.set $global123
   (struct.new_default $type33)
  )
  (global.set $global164
   (struct.new_default $type34)
  )
  (global.set $global154
   (call $foreign8
    (i32.const 0)
   )
  )
  (global.set $global155
   (call $foreign7
    (i32.const 1)
   )
  )
  (global.set $global156
   (struct.new_default $type29)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

