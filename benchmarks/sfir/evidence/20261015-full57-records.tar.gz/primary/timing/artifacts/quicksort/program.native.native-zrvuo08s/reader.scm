(module
 (rec
  (type $call67 (func (param (ref $environment119) i64 (ref $type12)) (result (ref $type12))))
  (type $type67 (struct (field (ref $environment119))))
  (type $environment119 (struct (field i64) (field (ref $type69))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type67)))))
  (type $type64 (struct (field (ref $environment106))))
  (type $environment106 (struct (field (ref $type12)) (field (ref $type66))))
  (type $type66 (struct (field (mut i32)) (field (mut (ref null $type64)))))
  (type $call64 (func (param (ref $environment106) i64) (result i32)))
  (type $environment97 (struct (field (ref $type12)) (field (ref $type47)) (field (ref $type62)) (field i64) (field i64)))
  (type $9 (func (param (ref $environment97) i64) (result (ref $type12))))
  (type $10 (func (param (ref $environment94) i64) (result i64)))
  (type $11 (func (param (ref $type12) i64 (ref $type47) i64 (ref $type62) i64) (result i64)))
  (type $environment94 (struct (field (ref $type12)) (field i64) (field i64) (field (ref $type47)) (field i64) (field (ref $type62)) (field (ref $type62)) (field (ref $type62)) (field i64)))
  (type $type62 (struct))
  (type $call49 (func (param (ref $type12) i64 i64 (ref $type47)) (result i64)))
  (type $environment83 (struct (field (ref $type37)) (field (ref $type12)) (field i64) (field (ref $type12)) (field (ref $type55))))
  (type $type55 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $environment75 (struct (field (ref $type12)) (field (ref $type55))))
  (type $18 (func (param i64 (ref $type12) i32 i32 i32 i64) (result (ref $type12))))
  (type $call11 (func (param structref i64) (result (ref $type12))))
  (type $call37 (func (param i64) (result i64)))
  (type $type56 (struct (field (ref $type15))))
  (type $environment57 (struct (field (ref $type56))))
  (type $23 (func (param (ref null $type15) i32 i32 i32 (ref null $type14) i64) (result (ref $type15))))
  (type $24 (func (param i32 i32 (ref null $type14) i64) (result i64)))
  (type $type15 (array (mut f64)))
  (type $type14 (struct (field f64) (field (ref null $type14))))
  (type $call13 (func (param (ref $type14)) (result (ref $type15))))
  (type $call7 (func (param (ref null $environment57)) (result f64)))
  (type $type12 (array (mut i64)))
  (type $type47 (struct))
  (type $type52 (struct (field (mut (ref $type7)))))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type39 (struct))
  (type $type44 (struct))
  (type $type7 (struct (field (ref $call7)) (field (ref null $environment57))))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type37 (struct (field (ref $call37))))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type19 (struct))
  (type $type16 (struct))
  (type $type13 (struct))
  (type $type11 (struct (field (ref $call11)) (field structref)))
  (type $type5 (struct))
 )
 (type $51 (func (result i32)))
 (type $52 (func (param i32) (result i64)))
 (type $53 (func (result i64)))
 (type $54 (func (param i64) (result i64)))
 (type $55 (func))
 (import "benchmark" "barrier" (func $foreign2 (result i32)))
 (import "benchmark" "input_i64" (func $foreign5 (param i32) (result i64)))
 (import "benchmark" "count" (func $foreign6 (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $global178 (mut (ref null $type11)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type13)) (ref.null none))
 (global $global125 (mut (ref null $type16)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type19)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type35)) (ref.null none))
 (global $global108 (mut (ref null $type36)) (ref.null none))
 (global $global189 (mut (ref null $type37)) (ref.null none))
 (global $global116 (mut (ref null $type42)) (ref.null none))
 (global $global118 (mut (ref null $type43)) (ref.null none))
 (global $global119 (mut (ref null $type7)) (ref.null none))
 (global $global191 (mut (ref null $type44)) (ref.null none))
 (global $global229 (mut (ref null $type39)) (ref.null none))
 (global $global167 (mut (ref null $type45)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global174 (mut (ref null $type46)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type48)) (ref.null none))
 (global $global204 (mut (ref null $type49)) (ref.null none))
 (global $ready204 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type50)) (ref.null none))
 (global $global121 (mut (ref null $type51)) (ref.null none))
 (global $global122 (mut (ref null $type52)) (ref.null none))
 (global $global163 (mut (ref null $type37)) (ref.null none))
 (global $ready165 (mut i32) (i32.const 0))
 (global $global166 (mut i64) (i64.const 0))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global170 (mut i64) (i64.const 0))
 (global $global171 (mut (ref null $type47)) (ref.null none))
 (global $global177 (mut (ref null $type12)) (ref.null none))
 (global $global250 (mut (ref null $type37)) (ref.null none))
 (global $ready250 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function50 (type $call7) (param $0 (ref null $environment57)) (result f64)
  (unreachable)
 )
 (func $function51 (type $call13) (param $0 (ref $type14)) (result (ref $type15))
  (local $1 (ref null $type14))
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready125)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (if
   (i32.eqz
    (global.get $ready128)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (if
   (i64.gt_u
    (local.tee $2
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type14 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $1
          (struct.get $type14 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type14 1
             (local.get $1)
            )
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type14 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type14 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 5)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type14 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 6)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type14 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $1
                      (struct.get $type14 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $1
                        (struct.get $type14 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $1
                          (struct.get $type14 1
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $1
                            (struct.get $type14 1
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $1
                              (struct.get $type14 1
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $1
                                (struct.get $type14 1
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $1
                                  (struct.get $type14 1
                                   (local.get $1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 14)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $1
                                    (struct.get $type14 1
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 15)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $1
                                      (struct.get $type14 1
                                       (local.get $1)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 16)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.tee $1
                                        (struct.get $type14 1
                                         (local.get $1)
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 17)
                                      )
                                      (else
                                       (if (result i64)
                                        (ref.is_null
                                         (local.tee $1
                                          (struct.get $type14 1
                                           (local.get $1)
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const 18)
                                        )
                                        (else
                                         (call $function54
                                          (i32.const 0)
                                          (i32.const 1)
                                          (struct.get $type14 1
                                           (local.get $1)
                                          )
                                          (i64.const 19)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function55
   (array.new $type15
    (struct.get $type14 0
     (local.get $0)
    )
    (i32.wrap_i64
     (local.get $2)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function54 (type $24) (param $0 i32) (param $1 i32) (param $2 (ref null $type14)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function54
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function55 (type $23) (param $0 (ref null $type15)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type14)) (param $5 i64) (result (ref $type15))
  (local $6 i64)
  (local $7 f64)
  (if (result (ref $type15))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type14 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type14 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function57 (type $call7) (param $0 (ref null $environment57)) (result f64)
  (local $1 f64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $type15))
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.mul
        (local.tee $1
         (array.get $type15
          (local.tee $6
           (struct.get $type56 0
            (struct.get $environment57 0
             (local.get $0)
            )
           )
          )
          (i32.const 1)
         )
        )
        (f64.const 1403580.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $1)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.tee $3
         (array.get $type15
          (local.get $6)
          (i32.const 0)
         )
        )
        (f64.const 810728.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.sub
        (local.get $2)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.tee $3
         (array.get $type15
          (local.get $6)
          (i32.const 5)
         )
        )
        (f64.const 527612.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.tee $4
         (array.get $type15
          (local.get $6)
          (i32.const 3)
         )
        )
        (f64.const 1370589.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $4)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.sub
        (local.get $1)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.div
        (local.get $2)
        (f64.const 4294967087.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $4
       (f64.div
        (local.get $1)
        (f64.const 4294944443.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $1)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type15
   (local.get $6)
   (i32.const 0)
   (array.get $type15
    (local.get $6)
    (i32.const 1)
   )
  )
  (array.set $type15
   (local.get $6)
   (i32.const 3)
   (array.get $type15
    (local.get $6)
    (i32.const 4)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.tee $5
         (f64.trunc
          (local.get $3)
         )
        )
        (f64.const 4294967087.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $5)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.sub
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.lt
     (f64.abs
      (local.tee $3
       (f64.trunc
        (local.get $4)
       )
      )
     )
     (f64.const inf)
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.get $3)
        (f64.const 4294944443.0)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.sub
        (local.get $1)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type15
   (local.get $6)
   (i32.const 1)
   (array.get $type15
    (local.get $6)
    (i32.const 2)
   )
  )
  (array.set $type15
   (local.get $6)
   (i32.const 4)
   (array.get $type15
    (local.get $6)
    (i32.const 5)
   )
  )
  (if
   (f64.lt
    (local.get $2)
    (f64.const 0.0)
   )
   (then
    (if
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.add
          (local.get $2)
          (f64.const 4294967087.0)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if
   (f64.lt
    (local.get $1)
    (f64.const 0.0)
   )
   (then
    (if
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $1)
       )
       (f64.const inf)
      )
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.add
          (local.get $1)
          (f64.const 4294944443.0)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (array.set $type15
   (local.get $6)
   (i32.const 2)
   (local.get $2)
  )
  (array.set $type15
   (local.get $6)
   (i32.const 5)
   (local.get $1)
  )
  (if
   (f64.ge
    (local.get $1)
    (local.get $2)
   )
   (then
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.sub
          (local.get $2)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.add
          (local.get $1)
          (f64.const 4294967087.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $1)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
   (else
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.sub
          (local.get $2)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.get $2)
        (f64.const 2.328306549295728e-10)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.get $1)
 )
 (func $function67 (type $call37) (param $0 i64) (result i64)
  (local $1 f64)
  (local $2 f64)
  (local $3 f64)
  (local $4 (ref $type7))
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (local.set $1
   (f64.mul
    (local.tee $2
     (f64.convert_i64_s
      (local.get $0)
     )
    )
    (local.tee $3
     (call_ref $call7
      (struct.get $type7 1
       (local.tee $4
        (struct.get $type52 0
         (global.get $global122)
        )
       )
      )
      (struct.get $type7 0
       (local.get $4)
      )
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $1)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global108)
   )
  )
  (i64.trunc_f64_s
   (f64.trunc
    (local.get $1)
   )
  )
 )
 (func $function71 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (if (result (ref $type12))
   (i32.or
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
    (i64.gt_s
     (local.get $1)
     (i64.const 4294967295)
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function72
       (local.get $1)
       (array.new_default $type12
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function72 (type $18) (param $0 i64) (param $1 (ref $type12)) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type12))
  (local $6 i64)
  (if (result (ref $type12))
   (i64.eq
    (local.get $0)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
     (i64.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function75 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 i64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $type12))
  (local $7 (ref $type7))
  (if (result (ref $type12))
   (i64.eq
    (global.get $global166)
    (local.get $1)
   )
   (then
    (struct.get $environment75 0
     (ref.cast (ref $environment75)
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type12
     (struct.get $environment75 0
      (ref.cast (ref $environment75)
       (local.get $0)
      )
     )
     (block (result i32)
      (drop
       (ref.as_non_null
        (global.get $global163)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (local.set $3
       (f64.mul
        (local.tee $4
         (f64.convert_i64_s
          (global.get $global170)
         )
        )
        (local.tee $5
         (call_ref $call7
          (struct.get $type7 1
           (local.tee $7
            (struct.get $type52 0
             (global.get $global122)
            )
           )
          )
          (struct.get $type7 0
           (local.get $7)
          )
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $3)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global108)
       )
      )
      (local.set $2
       (i64.trunc_f64_s
        (f64.trunc
         (local.get $3)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type11 1
      (struct.get $type55 1
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function78 (type $call37) (param $0 i64) (result i64)
  (local.get $0)
 )
 (func $function83 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment83))
  (local $3 i64)
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment83 2
     (local.tee $2
      (ref.cast (ref $environment83)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $environment83 3
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call_ref $call37
      (array.get $type12
       (struct.get $environment83 1
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (struct.get $type37 0
       (struct.get $environment83 0
        (local.get $2)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment83 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type55 0
       (struct.get $environment83 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (struct.get $type11 1
      (struct.get $type55 1
       (struct.get $environment83 4
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function86 (type $call49) (param $0 (ref $type12)) (param $1 i64) (param $2 i64) (param $3 (ref $type47)) (result i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type62))
  (local $7 (ref $type62))
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (array.get $type12
    (local.get $0)
    (i32.wrap_i64
     (local.get $2)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.tee $5
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function94
   (struct.new $environment94
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.get $4)
    (local.tee $6
     (struct.new_default $type62)
    )
    (local.tee $7
     (struct.new_default $type62)
    )
    (struct.new_default $type62)
    (call $function88
     (local.get $0)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
     (local.get $5)
    )
   )
   (call $function90
    (local.get $0)
    (local.get $1)
    (local.get $3)
    (local.get $4)
    (local.get $7)
    (local.get $2)
   )
  )
 )
 (func $function88 (type $11) (param $0 (ref $type12)) (param $1 i64) (param $2 (ref $type47)) (param $3 i64) (param $4 (ref $type62)) (param $5 i64) (result i64)
  (local $6 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $5)
      (local.tee $6
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $6)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (if (result i32)
    (i64.gt_s
     (local.get $1)
     (local.get $6)
    )
    (then
     (if
      (i64.gt_u
       (local.get $6)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.gt_s
      (local.get $3)
      (array.get $type12
       (local.get $0)
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (return_call $function88
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
   (else
    (local.get $6)
   )
  )
 )
 (func $function90 (type $11) (param $0 (ref $type12)) (param $1 i64) (param $2 (ref $type47)) (param $3 i64) (param $4 (ref $type62)) (param $5 i64) (result i64)
  (local $6 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $6
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (local.get $5)
     )
     (i64.xor
      (local.get $5)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (local.get $6)
    )
    (then
     (if
      (i64.gt_u
       (local.get $6)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.gt_s
      (array.get $type12
       (local.get $0)
       (i32.wrap_i64
        (local.get $6)
       )
      )
      (local.get $3)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
   (else
    (local.get $6)
   )
  )
 )
 (func $function94 (type $10) (param $0 (ref $environment94)) (param $1 i64) (result i64)
  (local $2 (ref $type12))
  (local $3 (ref $type47))
  (local $4 (ref $type62))
  (local $5 (ref $type62))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if
   (i64.gt_u
    (local.tee $6
     (struct.get $environment94 8
      (local.get $0)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (array.get $type12
    (local.tee $2
     (struct.get $environment94 0
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $7
   (array.get $type12
    (local.get $2)
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type12
   (local.get $2)
   (i32.wrap_i64
    (local.get $6)
   )
   (local.get $7)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $7
   (struct.get $environment94 2
    (local.get $0)
   )
  )
  (array.set $type12
   (local.get $2)
   (i32.wrap_i64
    (local.get $1)
   )
   (local.get $8)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $1)
    (local.get $6)
   )
   (then
    (return_call $function94
     (struct.new $environment94
      (local.get $2)
      (local.tee $9
       (struct.get $environment94 1
        (local.get $0)
       )
      )
      (local.get $7)
      (local.tee $3
       (struct.get $environment94 3
        (local.get $0)
       )
      )
      (local.tee $8
       (struct.get $environment94 4
        (local.get $0)
       )
      )
      (local.tee $4
       (struct.get $environment94 5
        (local.get $0)
       )
      )
      (local.tee $5
       (struct.get $environment94 6
        (local.get $0)
       )
      )
      (struct.get $environment94 7
       (local.get $0)
      )
      (call $function88
       (local.get $2)
       (local.get $7)
       (local.get $3)
       (local.get $8)
       (local.get $4)
       (local.get $6)
      )
     )
     (call $function90
      (local.get $2)
      (local.get $9)
      (local.get $3)
      (local.get $8)
      (local.get $5)
      (local.get $1)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type12
      (local.get $2)
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $2)
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $9)
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.get $type12
      (local.get $2)
      (i32.wrap_i64
       (local.get $7)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $2)
     (i32.wrap_i64
      (local.get $6)
     )
     (local.get $1)
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $2)
     (i32.wrap_i64
      (local.get $7)
     )
     (local.get $8)
    )
    (local.get $6)
   )
  )
 )
 (func $function97 (type $9) (param $0 (ref $environment97)) (param $1 i64) (result (ref $type12))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type12))
  (local $6 (ref $type47))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $4
       (i64.sub
        (local.get $1)
        (local.tee $2
         (struct.get $environment97 3
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
     )
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (i64.sub
    (local.tee $2
     (struct.get $environment97 4
      (local.get $0)
     )
    )
    (local.get $1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type12))
   (i64.gt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment97 0
      (local.get $0)
     )
    )
    (drop
     (if (result (ref $type12))
      (i64.gt_s
       (local.get $2)
       (local.tee $3
        (struct.get $environment97 3
         (local.get $0)
        )
       )
      )
      (then
       (if
        (i32.eqz
         (global.get $ready204)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global204)
        )
       )
       (call $function97
        (struct.new $environment97
         (local.get $5)
         (local.tee $6
          (struct.get $environment97 1
           (local.get $0)
          )
         )
         (struct.get $environment97 2
          (local.get $0)
         )
         (local.get $3)
         (local.get $2)
        )
        (call $function86
         (local.get $5)
         (local.get $3)
         (local.get $2)
         (local.get $6)
        )
       )
      )
      (else
       (local.get $5)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment97 0
      (local.get $0)
     )
    )
    (if (result (ref $type12))
     (i64.gt_s
      (local.tee $1
       (struct.get $environment97 4
        (local.get $0)
       )
      )
      (local.get $2)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready204)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global204)
       )
      )
      (return_call $function97
       (struct.new $environment97
        (local.get $5)
        (local.tee $6
         (struct.get $environment97 1
          (local.get $0)
         )
        )
        (struct.get $environment97 2
         (local.get $0)
        )
        (local.get $2)
        (local.get $1)
       )
       (call $function86
        (local.get $5)
        (local.get $2)
        (local.get $1)
        (local.get $6)
       )
      )
     )
     (else
      (local.get $5)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment97 0
      (local.get $0)
     )
    )
    (drop
     (if (result (ref $type12))
      (i64.gt_s
       (local.tee $3
        (struct.get $environment97 4
         (local.get $0)
        )
       )
       (local.get $2)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready204)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global204)
        )
       )
       (call $function97
        (struct.new $environment97
         (local.get $5)
         (local.tee $6
          (struct.get $environment97 1
           (local.get $0)
          )
         )
         (struct.get $environment97 2
          (local.get $0)
         )
         (local.get $2)
         (local.get $3)
        )
        (call $function86
         (local.get $5)
         (local.get $2)
         (local.get $3)
         (local.get $6)
        )
       )
      )
      (else
       (local.get $5)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment97 0
      (local.get $0)
     )
    )
    (if (result (ref $type12))
     (i64.gt_s
      (local.get $2)
      (local.tee $1
       (struct.get $environment97 3
        (local.get $0)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready204)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global204)
       )
      )
      (return_call $function97
       (struct.new $environment97
        (local.get $5)
        (local.tee $6
         (struct.get $environment97 1
          (local.get $0)
         )
        )
        (struct.get $environment97 2
         (local.get $0)
        )
        (local.get $1)
        (local.get $2)
       )
       (call $function86
        (local.get $5)
        (local.get $1)
        (local.get $2)
        (local.get $6)
       )
      )
     )
     (else
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function106 (type $call64) (param $0 (ref $environment106)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type12))
  (local $5 (ref $type66))
  (if (result i32)
   (local.tee $3
    (i64.le_s
     (i64.extend_i32_u
      (array.len
       (local.tee $4
        (struct.get $environment106 0
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.ge_s
      (array.get $type12
       (local.get $4)
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (array.get $type12
       (local.get $4)
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type66 0
         (local.tee $5
          (struct.get $environment106 1
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function106
       (struct.get $type64 0
        (struct.get $type66 1
         (local.get $5)
        )
       )
       (local.get $2)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function117 (type $call37) (param $0 i64) (result i64)
  (local $1 (ref $type69))
  (local $2 (ref $type66))
  (local $3 (ref $type12))
  (local.set $3
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (struct.set $type69 1
   (local.tee $1
    (struct.new_default $type69)
   )
   (struct.new $type67
    (struct.new $environment119
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type69 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type69 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (call $function119
    (struct.get $type67 0
     (struct.get $type69 1
      (local.get $1)
     )
    )
    (i64.const 0)
    (local.get $3)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global229)
   )
  )
  (struct.set $type66 1
   (local.tee $2
    (struct.new_default $type66)
   )
   (struct.new $type64
    (struct.new $environment106
     (local.get $3)
     (local.get $2)
    )
   )
  )
  (struct.set $type66 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type66 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function106
     (struct.get $type64 0
      (struct.get $type66 1
       (local.get $2)
      )
     )
     (i64.const 1)
    )
    (i32.const 0)
   )
  )
 )
 (func $function119 (type $call67) (param $0 (ref $environment119)) (param $1 i64) (param $2 (ref $type12)) (result (ref $type12))
  (local $3 (ref $type55))
  (local $4 (ref $type37))
  (local $5 (ref $type47))
  (local $6 (ref $type11))
  (local $7 i64)
  (if (result (ref $type12))
   (i64.gt_s
    (struct.get $environment119 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $7
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global191)
     )
    )
    (local.set $4
     (ref.as_non_null
      (global.get $global189)
     )
    )
    (local.set $2
     (if (result (ref $type12))
      (i64.eqz
       (local.tee $1
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (ref.as_non_null
            (global.get $global177)
           )
          )
         )
        )
       )
      )
      (then
       (array.new_fixed $type12 0)
      )
      (else
       (struct.set $type55 1
        (local.tee $3
         (struct.new_default $type55)
        )
        (struct.new $type11
         (ref.func $function83)
         (struct.new $environment83
          (local.get $4)
          (local.get $2)
          (local.get $1)
          (array.new $type12
           (call_ref $call37
            (array.get $type12
             (local.get $2)
             (i32.const 0)
            )
            (struct.get $type37 0
             (local.get $4)
            )
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (local.get $3)
         )
        )
       )
       (struct.set $type55 0
        (local.get $3)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type55 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call11
        (struct.get $type11 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type55 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 1)
        (struct.get $type11 0
         (local.get $6)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (if
     (i64.gt_s
      (local.tee $1
       (i64.sub
        (i64.extend_i32_u
         (array.len
          (local.get $2)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready204)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global204)
       )
      )
      (local.set $2
       (call $function97
        (struct.new $environment97
         (local.get $2)
         (local.get $5)
         (struct.new_default $type62)
         (i64.const 0)
         (local.get $1)
        )
        (call $function86
         (local.get $2)
         (i64.const 0)
         (local.get $1)
         (local.get $5)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment119 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function119
     (struct.get $type67 0
      (struct.get $type69 1
       (struct.get $environment119 1
        (local.get $0)
       )
      )
     )
     (local.get $7)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready250)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global250)
   )
  )
  (return_call $function117
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 (ref $type55))
  (local $2 (ref $type56))
  (local $3 (ref $type11))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $global178
   (struct.new $type11
    (ref.func $function71)
    (ref.null none)
   )
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global123
   (struct.new_default $type13)
  )
  (global.set $global125
   (struct.new_default $type16)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type19)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type35)
  )
  (global.set $global108
   (struct.new_default $type36)
  )
  (global.set $global189
   (struct.new $type37
    (ref.func $function78)
   )
  )
  (global.set $global116
   (struct.new_default $type42)
  )
  (global.set $global118
   (struct.new_default $type43)
  )
  (global.set $global119
   (struct.new $type7
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $global191
   (struct.new_default $type44)
  )
  (global.set $global229
   (struct.new_default $type39)
  )
  (global.set $global167
   (struct.new_default $type45)
  )
  (global.set $ready167
   (i32.const 1)
  )
  (global.set $global174
   (struct.new_default $type46)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global198
   (struct.new_default $type48)
  )
  (global.set $global204
   (struct.new_default $type49)
  )
  (global.set $ready204
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global120
   (struct.new_default $type50)
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (global.set $global121
   (struct.new_default $type51)
  )
  (global.set $global122
   (struct.new $type52
    (ref.as_non_null
     (global.get $global119)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global123)
   )
  )
  (local.set $2
   (struct.new $type56
    (call $function51
     (struct.new $type14
      (f64.const 1.0)
      (struct.new $type14
       (f64.const 0.0)
       (struct.new $type14
        (f64.const 0.0)
        (struct.new $type14
         (f64.const 1.0)
         (struct.new $type14
          (f64.const 0.0)
          (struct.new_default $type14)
         )
        )
       )
      )
     )
    )
   )
  )
  (struct.set $type52 0
   (global.get $global122)
   (struct.new $type7
    (ref.func $function57)
    (struct.new $environment57
     (local.get $2)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (global.set $global163
   (struct.new $type37
    (ref.func $function67)
   )
  )
  (drop
   (call $foreign6)
  )
  (global.set $ready165
   (i32.const 1)
  )
  (local.set $0
   (call $foreign5
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (global.set $global166
   (if (result i64)
    (call $foreign2)
    (then
     (local.get $0)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready166
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready165)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (call $foreign5
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (global.set $global170
   (if (result i64)
    (call $foreign2)
    (then
     (local.get $0)
    )
    (else
     (unreachable)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready165)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready174)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global174)
   )
  )
  (global.set $global171
   (if (result (ref $type47))
    (call $foreign2)
    (then
     (struct.new_default $type47)
    )
    (else
     (unreachable)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type11 1
    (global.get $global178)
   )
  )
  (struct.set $type55 1
   (local.tee $1
    (struct.new_default $type55)
   )
   (struct.new $type11
    (ref.func $function75)
    (struct.new $environment75
     (if (result (ref $type12))
      (i32.or
       (i64.lt_s
        (local.tee $0
         (global.get $global166)
        )
        (i64.const 0)
       )
       (i64.gt_s
        (local.get $0)
        (i64.const 4294967295)
       )
      )
      (then
       (unreachable)
      )
      (else
       (if (result (ref $type12))
        (i64.eqz
         (local.get $0)
        )
        (then
         (array.new_fixed $type12 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (if
          (i64.gt_u
           (local.get $0)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call $function72
          (local.get $0)
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $0)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 1)
         )
        )
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type55 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type55 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global177
   (call_ref $call11
    (struct.get $type11 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type55 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type11 0
     (local.get $3)
    )
   )
  )
  (global.set $global250
   (struct.new $type37
    (ref.func $function117)
   )
  )
  (global.set $ready250
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

