(module
 (rec
  (type $type30 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $environment43 (struct (field i64) (field (ref $type30))))
  (type $call27 (func (param (ref null $environment43) i64 i64) (result i64)))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment43))))
 )
 (type $5 (func (param i64) (result i64)))
 (type $6 (func (param i32) (result i64)))
 (type $7 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type27)) (ref.null none))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global106 (mut i64) (i64.const 0))
 (global $global107 (mut i64) (i64.const 0))
 (global $global108 (mut (ref null $type28)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment43 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global113)
     )
    )
    (drop
     (struct.get $environment43 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global106)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global113)
     )
    )
    (local.set $3
     (call $foreign0
      (global.get $global107)
     )
    )
    (local.set $1
     (call $function45
      (struct.get $type27 1
       (global.get $global116)
      )
      (local.get $1)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type27 1
      (struct.get $type30 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function45 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (local.get $2)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function45
       (struct.get $type27 1
        (global.get $global116)
       )
       (local.get $2)
       (i64.const 1)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $4
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (call $function45
        (struct.get $type27 1
         (global.get $global116)
        )
        (local.get $1)
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function45
       (struct.get $type27 1
        (global.get $global116)
       )
       (local.get $3)
       (local.get $1)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type30))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready108)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global108)
   )
  )
  (struct.set $type30 1
   (local.tee $1
    (struct.new_default $type30)
   )
   (struct.new $type27
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type30 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type30 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global113
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global116
   (struct.new $type27
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global106
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global107
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global108
   (struct.new_default $type28)
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

