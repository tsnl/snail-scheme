(module
 (rec
  (type $call37 (func (param (ref $environment51) (ref null $type28) i64) (result i64)))
  (type $1 (func (param (ref $environment48) i32) (result i32)))
  (type $environment48 (struct (field (ref null $type28)) (field (ref null $type28))))
  (type $call31 (func (param (ref null $type28) (ref null $type28) (ref null $type28)) (result (ref null $type28))))
  (type $type37 (struct (field (ref $environment51))))
  (type $call29 (func (param (ref null $environment44) i64 (ref null $type28)) (result (ref null $type28))))
  (type $environment44 (struct (field i64) (field (ref $type35))))
  (type $type39 (struct (field (mut i32)) (field (mut (ref null $type37)))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $environment51 (struct (field (ref $type39))))
  (type $call33 (func (param i64) (result i64)))
  (type $call30 (func (param i64) (result (ref null $type28))))
  (type $type33 (struct))
  (type $type28 (struct (field (ref null $type28))))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field (ref $call29)) (field (ref null $environment44))))
  (type $type27 (struct))
 )
 (type $19 (func (result i32)))
 (type $20 (func (param i32) (result i64)))
 (type $21 (func (param i64) (result i64)))
 (type $22 (func))
 (import "benchmark" "barrier" (func $foreign0 (result i32)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type27)) (ref.null none))
 (global $global119 (mut (ref null $type29)) (ref.null none))
 (global $global107 (mut (ref null $type30)) (ref.null none))
 (global $ready107 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type31)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type32)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $global112 (mut (ref null $type28)) (ref.null none))
 (global $global113 (mut (ref null $type28)) (ref.null none))
 (global $global114 (mut (ref null $type33)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call30) (param $0 i64) (result (ref null $type28))
  (local $1 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready107)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global107)
     )
    )
    (struct.new $type28
     (call $function41
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function42 (type $call33) (param $0 i64) (result i64)
  (local $1 (ref null $type28))
  (local $2 (ref $environment51))
  (local $3 (ref $type35))
  (local $4 (ref $type39))
  (local $5 (ref $type29))
  (struct.set $type35 1
   (local.tee $3
    (struct.new_default $type35)
   )
   (struct.new $type29
    (ref.func $function44)
    (struct.new $environment44
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type35 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call29
    (struct.get $type29 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type35 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type29 0
     (local.get $5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (struct.set $type39 1
   (local.tee $4
    (struct.new_default $type39)
   )
   (struct.new $type37
    (struct.new $environment51
     (local.get $4)
    )
   )
  )
  (struct.set $type39 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type37 0
    (struct.get $type39 1
     (local.get $4)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment51 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type37 0
      (struct.get $type39 1
       (struct.get $environment51 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type28 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type39 0
         (struct.get $environment51 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type37 0
        (struct.get $type39 1
         (struct.get $environment51 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type28 0
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type39 0
           (struct.get $environment51 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type37 0
          (struct.get $type39 1
           (struct.get $environment51 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type28 0
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type39 0
             (struct.get $environment51 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type37 0
            (struct.get $type39 1
             (struct.get $environment51 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type28 0
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type39 0
               (struct.get $environment51 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type37 0
              (struct.get $type39 1
               (struct.get $environment51 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type28 0
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type39 0
                 (struct.get $environment51 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type37 0
                (struct.get $type39 1
                 (struct.get $environment51 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type28 0
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type39 0
                   (struct.get $environment51 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type37 0
                  (struct.get $type39 1
                   (struct.get $environment51 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type28 0
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type39 0
                     (struct.get $environment51 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type37 0
                    (struct.get $type39 1
                     (struct.get $environment51 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type28 0
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type39 0
                       (struct.get $environment51 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function51
                     (struct.get $type37 0
                      (struct.get $type39 1
                       (struct.get $environment51 0
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function44 (type $call29) (param $0 (ref null $environment44)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 i64)
  (local $4 (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref null $type28))
  (local $scratch (ref null $type28))
  (if (result (ref null $type28))
   (i64.gt_s
    (struct.get $environment44 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global119)
     )
    )
    (drop
     (struct.get $environment44 0
      (local.get $0)
     )
    )
    (local.set $2
     (call $function46
      (global.get $global111)
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type29 1
         (global.get $global119)
        )
       )
       (global.get $global112)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type29 1
         (global.get $global119)
        )
       )
       (local.set $scratch
        (global.get $global113)
       )
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type29 1
      (struct.get $type35 1
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function45 (type $call29) (param $0 (ref null $environment44)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (if (result (ref null $type28))
   (call $foreign0)
   (then
    (local.get $2)
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function46 (type $call31) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 i32)
  (local $scratch (ref null $type28))
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if (result (ref null $type28))
   (if (result i32)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (if (result i32)
      (local.tee $5
       (ref.is_null
        (local.get $1)
       )
      )
      (then
       (local.get $5)
      )
      (else
       (local.set $3
        (struct.get $type28 0
         (local.get $1)
        )
       )
       (local.set $4
        (struct.get $type28 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready126)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global126)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (local.tee $5
           (ref.is_null
            (local.get $3)
           )
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $3
            (struct.get $type28 0
             (local.get $3)
            )
           )
           (local.set $4
            (struct.get $type28 0
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (global.get $ready126)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (local.tee $5
               (ref.is_null
                (local.get $3)
               )
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type28 0
                 (local.get $3)
                )
               )
               (local.set $4
                (struct.get $type28 0
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready126)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global126)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (local.tee $5
                   (ref.is_null
                    (local.get $3)
                   )
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type28 0
                     (local.get $3)
                    )
                   )
                   (local.set $4
                    (struct.get $type28 0
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready126)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global126)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (local.tee $5
                       (ref.is_null
                        (local.get $3)
                       )
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type28 0
                         (local.get $3)
                        )
                       )
                       (local.set $4
                        (struct.get $type28 0
                         (local.get $4)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready126)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global126)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (local.tee $5
                           (ref.is_null
                            (local.get $3)
                           )
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $3
                            (struct.get $type28 0
                             (local.get $3)
                            )
                           )
                           (local.set $4
                            (struct.get $type28 0
                             (local.get $4)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready126)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global126)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (local.tee $5
                               (ref.is_null
                                (local.get $3)
                               )
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $3
                                (struct.get $type28 0
                                 (local.get $3)
                                )
                               )
                               (local.set $4
                                (struct.get $type28 0
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready126)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global126)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (if (result i32)
                                  (local.tee $5
                                   (ref.is_null
                                    (local.get $3)
                                   )
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (local.set $3
                                    (struct.get $type28 0
                                     (local.get $3)
                                    )
                                   )
                                   (local.set $4
                                    (struct.get $type28 0
                                     (local.get $4)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready126)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global126)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $4)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (local.tee $5
                                       (ref.is_null
                                        (local.get $3)
                                       )
                                      )
                                      (then
                                       (local.get $5)
                                      )
                                      (else
                                       (local.set $3
                                        (struct.get $type28 0
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $4
                                        (struct.get $type28 0
                                         (local.get $4)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready126)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global126)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $4)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (call $function48
                                          (struct.new $environment48
                                           (local.get $3)
                                           (local.get $4)
                                          )
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (return_call $function46
     (call $function46
      (struct.get $type28 0
       (local.get $0)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (global.get $ready122)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (local.get $1)
      )
      (local.get $2)
     )
     (call $function46
      (struct.get $type28 0
       (local.get $1)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (global.get $ready122)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (local.get $2)
      )
      (local.get $0)
     )
     (block (result (ref null $type28))
      (local.set $scratch
       (call $function46
        (struct.get $type28 0
         (local.get $2)
        )
        (block (result (ref null $type28))
         (if
          (i32.eqz
           (global.get $ready122)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (local.get $0)
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready122)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function48 (type $1) (param $0 (ref $environment48)) (param $1 i32) (result i32)
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (if (result i32)
   (local.get $1)
   (then
    (local.get $1)
   )
   (else
    (local.set $2
     (struct.get $type28 0
      (struct.get $environment48 0
       (local.get $0)
      )
     )
    )
    (local.set $3
     (struct.get $type28 0
      (struct.get $environment48 1
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if (result i32)
     (ref.is_null
      (local.get $3)
     )
     (then
      (i32.const 0)
     )
     (else
      (return_call $function48
       (struct.new $environment48
        (local.get $2)
        (local.get $3)
       )
       (ref.is_null
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call37) (param $0 (ref $environment51)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment51 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type37 0
      (struct.get $type39 1
       (struct.get $environment51 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (return_call $function42
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type27)
  )
  (global.set $global119
   (struct.new $type29
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $global107
   (struct.new_default $type30)
  )
  (global.set $ready107
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (drop
   (call $function41
    (i64.const 8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (drop
   (call $function41
    (i64.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (global.set $global122
   (struct.new_default $type31)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type32)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (local.set $0
   (call $foreign1
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (global.set $global111
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $1
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
         (local.get $0)
        )
        (i64.xor
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (global.get $ready107)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global107)
      )
     )
     (struct.new $type28
      (if (result (ref null $type28))
       (i64.eqz
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $0
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $1)
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready107)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global107)
         )
        )
        (struct.new $type28
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
               (local.get $0)
              )
              (i64.xor
               (local.get $0)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready107)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global107)
            )
           )
           (struct.new $type28
            (if (result (ref null $type28))
             (i64.eqz
              (local.get $1)
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $0
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $1)
                 )
                 (i64.xor
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready107)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global107)
               )
              )
              (struct.new $type28
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $0)
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $1
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                     (local.get $0)
                    )
                    (i64.xor
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready107)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global107)
                  )
                 )
                 (struct.new $type28
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $0
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (local.get $1)
                       )
                       (i64.xor
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready107)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global107)
                     )
                    )
                    (struct.new $type28
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $0)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $1
                            (i64.sub
                             (local.get $0)
                             (i64.const 1)
                            )
                           )
                           (local.get $0)
                          )
                          (i64.xor
                           (local.get $0)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready107)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global107)
                        )
                       )
                       (struct.new $type28
                        (if (result (ref null $type28))
                         (i64.eqz
                          (local.get $1)
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $0
                               (i64.sub
                                (local.get $1)
                                (i64.const 1)
                               )
                              )
                              (local.get $1)
                             )
                             (i64.xor
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready107)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global107)
                           )
                          )
                          (struct.new $type28
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.get $0)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                 (local.get $0)
                                )
                                (i64.xor
                                 (local.get $0)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready107)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global107)
                              )
                             )
                             (struct.new $type28
                              (if (result (ref null $type28))
                               (i64.eqz
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i64.lt_s
                                  (i64.and
                                   (i64.xor
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $1)
                                      (i64.const 1)
                                     )
                                    )
                                    (local.get $1)
                                   )
                                   (i64.xor
                                    (local.get $1)
                                    (i64.const 1)
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready107)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global107)
                                 )
                                )
                                (struct.new $type28
                                 (call $function41
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $0
   (call $foreign1
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (global.set $global112
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $1
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
         (local.get $0)
        )
        (i64.xor
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (global.get $ready107)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global107)
      )
     )
     (struct.new $type28
      (if (result (ref null $type28))
       (i64.eqz
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $0
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $1)
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready107)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global107)
         )
        )
        (struct.new $type28
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
               (local.get $0)
              )
              (i64.xor
               (local.get $0)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready107)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global107)
            )
           )
           (struct.new $type28
            (if (result (ref null $type28))
             (i64.eqz
              (local.get $1)
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $0
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $1)
                 )
                 (i64.xor
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready107)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global107)
               )
              )
              (struct.new $type28
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $0)
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $1
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                     (local.get $0)
                    )
                    (i64.xor
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready107)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global107)
                  )
                 )
                 (struct.new $type28
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $0
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (local.get $1)
                       )
                       (i64.xor
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready107)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global107)
                     )
                    )
                    (struct.new $type28
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $0)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $1
                            (i64.sub
                             (local.get $0)
                             (i64.const 1)
                            )
                           )
                           (local.get $0)
                          )
                          (i64.xor
                           (local.get $0)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready107)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global107)
                        )
                       )
                       (struct.new $type28
                        (if (result (ref null $type28))
                         (i64.eqz
                          (local.get $1)
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $0
                               (i64.sub
                                (local.get $1)
                                (i64.const 1)
                               )
                              )
                              (local.get $1)
                             )
                             (i64.xor
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready107)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global107)
                           )
                          )
                          (struct.new $type28
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.get $0)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                 (local.get $0)
                                )
                                (i64.xor
                                 (local.get $0)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready107)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global107)
                              )
                             )
                             (struct.new $type28
                              (if (result (ref null $type28))
                               (i64.eqz
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i64.lt_s
                                  (i64.and
                                   (i64.xor
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $1)
                                      (i64.const 1)
                                     )
                                    )
                                    (local.get $1)
                                   )
                                   (i64.xor
                                    (local.get $1)
                                    (i64.const 1)
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready107)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global107)
                                 )
                                )
                                (struct.new $type28
                                 (call $function41
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $0
   (call $foreign1
    (i32.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready107)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (global.set $global113
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $1
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
         (local.get $0)
        )
        (i64.xor
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (global.get $ready107)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global107)
      )
     )
     (struct.new $type28
      (if (result (ref null $type28))
       (i64.eqz
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $0
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $1)
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready107)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global107)
         )
        )
        (struct.new $type28
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
               (local.get $0)
              )
              (i64.xor
               (local.get $0)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready107)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global107)
            )
           )
           (struct.new $type28
            (if (result (ref null $type28))
             (i64.eqz
              (local.get $1)
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $0
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $1)
                 )
                 (i64.xor
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready107)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global107)
               )
              )
              (struct.new $type28
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $0)
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $1
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                     (local.get $0)
                    )
                    (i64.xor
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready107)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global107)
                  )
                 )
                 (struct.new $type28
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $0
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (local.get $1)
                       )
                       (i64.xor
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready107)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global107)
                     )
                    )
                    (struct.new $type28
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $0)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $1
                            (i64.sub
                             (local.get $0)
                             (i64.const 1)
                            )
                           )
                           (local.get $0)
                          )
                          (i64.xor
                           (local.get $0)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready107)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global107)
                        )
                       )
                       (struct.new $type28
                        (if (result (ref null $type28))
                         (i64.eqz
                          (local.get $1)
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $0
                               (i64.sub
                                (local.get $1)
                                (i64.const 1)
                               )
                              )
                              (local.get $1)
                             )
                             (i64.xor
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready107)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global107)
                           )
                          )
                          (struct.new $type28
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.get $0)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                 (local.get $0)
                                )
                                (i64.xor
                                 (local.get $0)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready107)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global107)
                              )
                             )
                             (struct.new $type28
                              (if (result (ref null $type28))
                               (i64.eqz
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i64.lt_s
                                  (i64.and
                                   (i64.xor
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $1)
                                      (i64.const 1)
                                     )
                                    )
                                    (local.get $1)
                                   )
                                   (i64.xor
                                    (local.get $1)
                                    (i64.const 1)
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready107)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global107)
                                 )
                                )
                                (struct.new $type28
                                 (call $function41
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $global114
   (struct.new_default $type33)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

