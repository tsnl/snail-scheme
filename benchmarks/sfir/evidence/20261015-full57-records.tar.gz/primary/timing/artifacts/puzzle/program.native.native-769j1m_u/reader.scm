(module
 (rec
  (type $type27 (sub (struct)))
  (type $environment93 (struct (field i64) (field (ref $type36)) (field i64) (field i64) (field (ref $type50))))
  (type $environment91 (struct (field i64) (field i64) (field (ref $type36)) (field i64) (field (ref $type50))))
  (type $environment89 (struct (field i64) (field i64) (field i64) (field (ref $type36)) (field (ref $type50))))
  (type $4 (func (param i64 i64 i64 i64)))
  (type $environment85 (struct (field i64) (field i64) (field (ref $type50))))
  (type $environment81 (struct (field i64) (field i64) (field (ref $type50))))
  (type $environment79 (struct (field i64) (field (ref $type50))))
  (type $type29 (sub $type27 (struct (field i64))))
  (type $environment83 (struct (field i64) (field (ref $type50))))
  (type $environment77 (struct (field (ref $type50))))
  (type $environment75 (struct (field i64) (field (ref $type50))))
  (type $call55 (func (param (ref $environment71) i64 (ref $type27)) (result i64)))
  (type $type55 (struct (field (ref $environment71))))
  (type $environment71 (struct (field i64) (field (ref $type57))))
  (type $type57 (struct (field (mut i32)) (field (mut (ref null $type55)))))
  (type $call31 (func (param (ref $type32) (ref null $type33)) (result i32)))
  (type $type33 (struct (field i64) (field (ref null $type33))))
  (type $type52 (struct (field (ref $environment67))))
  (type $type54 (struct (field (mut i32)) (field (mut (ref null $type52)))))
  (type $environment67 (struct (field (ref $type54))))
  (type $call52 (func (param (ref $environment67) i64 (ref null $type33)) (result (ref null $type33))))
  (type $environment60 (struct (field i64) (field (ref $type46))))
  (type $environment57 (struct (field i64) (field i64) (field i64) (field (ref $type50))))
  (type $call44 (func (param (ref null $environment52) i64) (result i64)))
  (type $environment52 (struct (field (ref $type51))))
  (type $call32 (func (param structref i64) (result i32)))
  (type $environment50 (struct (field i64) (field i64) (field i64) (field (ref $type50))))
  (type $type32 (struct (field (ref $call32)) (field structref)))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type44)))))
  (type $type50 (struct (field (mut i32)) (field (mut (ref null $type32)))))
  (type $call34 (func (param i64 i64) (result i64)))
  (type $type46 (struct (field (mut i32)) (field (mut (ref null $type30)))))
  (type $environment45 (struct (field i64) (field i64) (field i64) (field (ref $type46))))
  (type $call30 (func (param structref i64) (result i32)))
  (type $type44 (struct (field (ref $call44)) (field (ref null $environment52))))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (array (mut (ref $type38))))
  (type $type38 (array (mut i32)))
  (type $type37 (array (mut i64)))
  (type $type36 (struct (field (mut i64))))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type31 (struct))
  (type $type10 (struct))
  (type $type30 (struct (field (ref $call30)) (field structref)))
  (type $type28 (sub $type27 (struct)))
 )
 (type $50 (func (param i64) (result i64)))
 (type $51 (func (param i64)))
 (type $52 (func (param i32) (result i64)))
 (type $53 (func))
 (import "benchmark" "print_text" (func $foreign0 (param i64)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty28 (ref $type28) (struct.new_default $type28))
 (global $global106 (mut (ref null $type28)) (ref.null none))
 (global $global145 (mut (ref null $type30)) (ref.null none))
 (global $global107 (mut (ref null $type10)) (ref.null none))
 (global $global155 (mut (ref null $type31)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type34)) (ref.null none))
 (global $global150 (mut (ref null $type35)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type36)) (ref.null none))
 (global $global112 (mut (ref null $type36)) (ref.null none))
 (global $global114 (mut (ref null $type37)) (ref.null none))
 (global $global115 (mut (ref null $type37)) (ref.null none))
 (global $global116 (mut (ref null $type37)) (ref.null none))
 (global $global117 (mut (ref null $type38)) (ref.null none))
 (global $global118 (mut (ref null $type39)) (ref.null none))
 (global $global119 (mut (ref null $type40)) (ref.null none))
 (global $global126 (mut (ref null $type34)) (ref.null none))
 (global $global135 (mut (ref null $type41)) (ref.null none))
 (global $global141 (mut (ref null $type30)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type42)) (ref.null none))
 (global $global169 (mut (ref null $type43)) (ref.null none))
 (global $global158 (mut i64) (i64.const 0))
 (global $global159 (mut i64) (i64.const 0))
 (global $global160 (mut i64) (i64.const 0))
 (global $global161 (mut (ref null $type44)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function45 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $environment45))
  (local $6 (ref $type38))
  (local.set $2
   (struct.get $environment45 0
    (local.tee $5
     (ref.cast (ref $environment45)
      (local.get $0)
     )
    )
   )
  )
  (local.set $3
   (struct.get $environment45 1
    (local.get $5)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (struct.get $environment45 2
       (local.get $5)
      )
      (local.get $1)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (if
      (i64.gt_u
       (local.get $2)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (array.get $type38
       (array.get $type39
        (global.get $global118)
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (then
       (array.get $type38
        (ref.as_non_null
         (global.get $global117)
        )
        (block (result i32)
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $2
              (i64.add
               (local.get $1)
               (local.get $3)
              )
             )
             (local.get $3)
            )
            (i64.xor
             (local.get $1)
             (local.get $2)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $2)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type46 0
       (struct.get $environment45 3
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type30 1
      (struct.get $type46 1
       (struct.get $environment45 3
        (local.get $5)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function47 (type $call34) (param $0 i64) (param $1 i64) (result i64)
  (local $2 (ref $type50))
  (local $3 (ref $type51))
  (local $4 (ref $type32))
  (local $5 (ref $type37))
  (local $6 (ref $type44))
  (local $7 i64)
  (local $8 i64)
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type50 1
   (local.tee $2
    (struct.new_default $type50)
   )
   (struct.new $type32
    (ref.func $function50)
    (struct.new $environment50
     (local.get $0)
     (local.get $1)
     (array.get $type37
      (global.get $global116)
      (i32.wrap_i64
       (local.get $0)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type50 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call32
    (struct.get $type32 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type50 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type32 0
     (local.get $4)
    )
   )
  )
  (array.set $type37
   (ref.as_non_null
    (global.get $global114)
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (array.get $type37
      (global.get $global115)
      (i32.wrap_i64
       (local.get $0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $0
       (array.get $type37
        (global.get $global115)
        (i32.wrap_i64
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.sub
          (local.tee $0
           (array.get $type37
            (global.get $global114)
            (i32.wrap_i64
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $7)
    )
   )
   (local.get $8)
  )
  (struct.set $type51 1
   (local.tee $3
    (struct.new_default $type51)
   )
   (struct.new $type44
    (ref.func $function52)
    (struct.new $environment52
     (local.get $3)
    )
   )
  )
  (struct.set $type51 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call44
   (struct.get $type44 1
    (local.tee $6
     (ref.as_non_null
      (struct.get $type51 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (struct.get $type44 0
    (local.get $6)
   )
  )
 )
 (func $function50 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type38))
  (if (result i32)
   (i64.lt_s
    (struct.get $environment50 2
     (ref.cast (ref $environment50)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $environment50 0
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (array.get $type38
      (array.get $type39
       (global.get $global118)
       (i32.wrap_i64
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (then
      (array.set $type38
       (ref.as_non_null
        (global.get $global117)
       )
       (block (result i32)
        (local.set $2
         (i64.add
          (local.get $1)
          (local.tee $3
           (struct.get $environment50 1
            (ref.cast (ref $environment50)
             (local.get $0)
            )
           )
          )
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $2)
            (local.get $3)
           )
           (i64.xor
            (local.get $1)
            (local.get $2)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $2)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i32.const 1)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment50 3
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function50
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment50 3
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function52 (type $call44) (param $0 (ref null $environment52)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i32)
  (if (result i64)
   (if (result i32)
    (local.tee $3
     (i64.gt_s
      (local.get $1)
      (i64.const 511)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i32.eqz
      (array.get $type38
       (global.get $global117)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
   )
   (then
    (select
     (local.get $1)
     (i64.const 0)
     (i64.le_s
      (local.get $1)
      (i64.const 511)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type44 1
      (struct.get $type51 1
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function57 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type38))
  (if (result i32)
   (i64.lt_s
    (struct.get $environment57 2
     (ref.cast (ref $environment57)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $environment57 0
        (ref.cast (ref $environment57)
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (array.get $type38
      (array.get $type39
       (global.get $global118)
       (i32.wrap_i64
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (then
      (array.set $type38
       (ref.as_non_null
        (global.get $global117)
       )
       (block (result i32)
        (local.set $2
         (i64.add
          (local.get $1)
          (local.tee $3
           (struct.get $environment57 1
            (ref.cast (ref $environment57)
             (local.get $0)
            )
           )
          )
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $2)
            (local.get $3)
           )
           (i64.xor
            (local.get $1)
            (local.get $2)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $2)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment57 3
        (ref.cast (ref $environment57)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment57 3
        (ref.cast (ref $environment57)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function58 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type46))
  (local $3 (ref $type30))
  (struct.set $type46 1
   (local.tee $2
    (struct.new_default $type46)
   )
   (struct.new $type30
    (ref.func $function60)
    (struct.new $environment60
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type46 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type46 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call30
   (struct.get $type30 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type46 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type30 0
    (local.get $3)
   )
  )
 )
 (func $function60 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type46))
  (local $7 (ref $type46))
  (local $8 (ref $type50))
  (local $9 (ref $type36))
  (local $10 (ref $type30))
  (local $11 (ref $environment60))
  (local $12 (ref $type32))
  (local $13 (ref $type37))
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 12)
   )
   (then
    (local.set $1
     (i64.add
      (local.tee $2
       (struct.get $type36 0
        (local.tee $9
         (ref.as_non_null
          (global.get $global112)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 0
     (local.get $9)
     (local.get $1)
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (array.get $type37
        (global.get $global115)
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type30 1
      (global.get $global145)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.eqz
       (array.get $type37
        (global.get $global114)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global119)
        )
       )
       (local.set $2
        (struct.get $environment60 0
         (ref.cast (ref $environment60)
          (local.get $0)
         )
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type46 1
        (local.tee $6
         (struct.new_default $type46)
        )
        (struct.new $type30
         (ref.func $function45)
         (struct.new $environment45
          (local.get $1)
          (local.get $2)
          (array.get $type37
           (global.get $global116)
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (local.get $6)
         )
        )
       )
       (struct.set $type46 0
        (local.get $6)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type46 0
          (local.get $6)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call30
        (struct.get $type30 1
         (local.tee $10
          (ref.as_non_null
           (struct.get $type46 1
            (local.get $6)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type30 0
         (local.get $10)
        )
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global126)
       )
      )
      (local.set $2
       (call $function47
        (local.get $1)
        (struct.get $environment60 0
         (local.tee $11
          (ref.cast (ref $environment60)
           (local.get $0)
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready141)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type30 1
        (global.get $global141)
       )
      )
      (struct.set $type46 1
       (local.tee $6
        (struct.new_default $type46)
       )
       (struct.new $type30
        (ref.func $function60)
        (struct.new $environment60
         (local.get $2)
         (local.get $6)
        )
       )
      )
      (struct.set $type46 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type46 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (if (result i32)
        (local.tee $5
         (call_ref $call30
          (struct.get $type30 1
           (local.tee $10
            (ref.as_non_null
             (struct.get $type46 1
              (local.get $6)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type30 0
           (local.get $10)
          )
         )
        )
        (then
         (local.get $5)
        )
        (else
         (drop
          (struct.get $type30 1
           (global.get $global145)
          )
         )
         (i64.eqz
          (local.get $2)
         )
        )
       )
       (then
        (local.set $1
         (i64.add
          (local.tee $2
           (struct.get $type36 0
            (local.tee $9
             (ref.as_non_null
              (global.get $global112)
             )
            )
           )
          )
          (i64.const 1)
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.get $2)
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type36 0
         (local.get $9)
         (local.get $1)
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global135)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type50 1
         (local.tee $8
          (struct.new_default $type50)
         )
         (struct.new $type32
          (ref.func $function57)
          (struct.new $environment57
           (local.get $1)
           (struct.get $environment60 0
            (local.get $11)
           )
           (array.get $type37
            (global.get $global116)
            (i32.wrap_i64
             (local.get $1)
            )
           )
           (local.get $8)
          )
         )
        )
        (struct.set $type50 0
         (local.get $8)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type50 0
           (local.get $8)
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (call_ref $call32
          (struct.get $type32 1
           (local.tee $12
            (ref.as_non_null
             (struct.get $type50 1
              (local.get $8)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type32 0
           (local.get $12)
          )
         )
        )
        (array.set $type37
         (ref.as_non_null
          (global.get $global114)
         )
         (block (result i32)
          (if
           (i64.gt_u
            (local.get $1)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (array.get $type37
            (global.get $global115)
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (if
           (i64.gt_u
            (local.get $1)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.tee $2
             (array.get $type37
              (global.get $global115)
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (i64.add
            (local.tee $4
             (array.get $type37
              (global.get $global114)
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i64.const 1)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $2)
              (local.get $4)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $2)
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.tee $2
             (i64.add
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (struct.get $type46 0
           (local.tee $7
            (struct.get $environment60 1
             (local.get $11)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function60
         (struct.get $type30 1
          (struct.get $type46 1
           (local.get $7)
          )
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type46 0
         (struct.get $environment60 1
          (ref.cast (ref $environment60)
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function60
       (struct.get $type30 1
        (struct.get $type46 1
         (struct.get $environment60 1
          (ref.cast (ref $environment60)
           (local.get $0)
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function61 (type $call30) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function64 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type39
   (global.get $global118)
   (i32.wrap_i64
    (local.get $1)
   )
   (array.new $type38
    (i32.const 1)
    (i32.const 512)
   )
  )
  (i32.const 0)
 )
 (func $function67 (type $call52) (param $0 (ref $environment67)) (param $1 i64) (param $2 (ref null $type33)) (result (ref null $type33))
  (local $3 i64)
  (local $4 i64)
  (drop
   (struct.get $type30 1
    (global.get $global145)
   )
  )
  (if (result (ref null $type33))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment67 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (struct.get $type52 0
      (struct.get $type54 1
       (struct.get $environment67 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type33
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function68 (type $call31) (param $0 (ref $type32)) (param $1 (ref null $type33)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.get $0)
      )
      (struct.get $type33 0
       (local.get $1)
      )
      (struct.get $type32 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type33 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (return_call $function68
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function69 (type $call44) (param $0 (ref null $environment52)) (param $1 i64) (result i64)
  (local $2 (ref $type57))
  (local $3 (ref $type28))
  (local.set $3
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (struct.set $type57 1
   (local.tee $2
    (struct.new_default $type57)
   )
   (struct.new $type55
    (struct.new $environment71
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type57 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type57 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function71
   (struct.get $type55 0
    (struct.get $type57 1
     (local.get $2)
    )
   )
   (i64.const 0)
   (local.get $3)
  )
 )
 (func $function71 (type $call55) (param $0 (ref $environment71)) (param $1 i64) (param $2 (ref $type27)) (result i64)
  (local $3 (ref $type50))
  (local $4 (ref $type46))
  (local $5 (ref $type32))
  (local $6 (ref $type37))
  (local $7 (ref $type30))
  (local $8 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment71 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $8
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (local.set $1
     (call $foreign1
      (global.get $global158)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global169)
     )
    )
    (struct.set $type36 0
     (global.get $global112)
     (i64.const 0)
    )
    (struct.set $type50 1
     (local.tee $3
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function75)
      (struct.new $environment75
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type50 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type32 0
       (local.get $5)
      )
     )
    )
    (struct.set $type50 1
     (local.tee $3
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function77)
      (struct.new $environment77
       (local.get $3)
      )
     )
    )
    (struct.set $type50 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type32 0
       (local.get $5)
      )
     )
    )
    (struct.set $type50 1
     (local.tee $3
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function83)
      (struct.new $environment83
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type50 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type32 0
       (local.get $5)
      )
     )
    )
    (struct.set $type36 0
     (global.get $global111)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 3)
     (i64.const 1)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 1)
     (i64.const 0)
     (i64.const 3)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 0)
     (i64.const 3)
     (i64.const 1)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 1)
     (i64.const 3)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 3)
     (i64.const 0)
     (i64.const 1)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 0)
     (i64.const 0)
     (i64.const 1)
     (i64.const 3)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 1)
     (i64.const 2)
     (i64.const 0)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 1)
     (i64.const 0)
     (i64.const 2)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 1)
     (i64.const 0)
     (i64.const 0)
     (i64.const 2)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 2)
     (i64.const 1)
     (i64.const 1)
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 2)
     (i64.const 1)
     (i64.const 0)
     (i64.const 1)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 2)
     (i64.const 0)
     (i64.const 1)
     (i64.const 1)
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (call $function86
     (i64.const 3)
     (i64.const 1)
     (i64.const 1)
     (i64.const 1)
    )
    (array.set $type37
     (local.tee $6
      (ref.as_non_null
       (global.get $global114)
      )
     )
     (i32.const 0)
     (i64.const 13)
    )
    (array.set $type37
     (local.get $6)
     (i32.const 1)
     (i64.const 3)
    )
    (array.set $type37
     (local.get $6)
     (i32.const 2)
     (i64.const 1)
    )
    (array.set $type37
     (local.get $6)
     (i32.const 3)
     (i64.const 1)
    )
    (local.set $1
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (struct.set $type46 1
     (local.tee $4
      (struct.new_default $type46)
     )
     (struct.new $type30
      (ref.func $function45)
      (struct.new $environment45
       (i64.const 0)
       (i64.const 73)
       (array.get $type37
        (global.get $global116)
        (i32.const 0)
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type46 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type46 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (call_ref $call30
       (struct.get $type30 1
        (local.tee $7
         (ref.as_non_null
          (struct.get $type46 1
           (local.get $4)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type30 0
        (local.get $7)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global126)
        )
       )
       (local.set $1
        (call $function47
         (i64.const 0)
         (i64.const 73)
        )
       )
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global107)
        )
       )
       (call $foreign0
        (i64.const 0)
       )
       (call $foreign0
        (i64.const 1)
       )
       (i32.const 0)
      )
     )
    )
    (drop
     (struct.get $type30 1
      (global.get $global141)
     )
    )
    (struct.set $type46 1
     (local.tee $4
      (struct.new_default $type46)
     )
     (struct.new $type30
      (ref.func $function60)
      (struct.new $environment60
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type46 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type46 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (if (result (ref $type27))
      (call_ref $call30
       (struct.get $type30 1
        (local.tee $7
         (ref.as_non_null
          (struct.get $type46 1
           (local.get $4)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type30 0
        (local.get $7)
       )
      )
      (then
       (struct.new $type29
        (struct.get $type36 0
         (global.get $global112)
        )
       )
      )
      (else
       (ref.as_non_null
        (global.get $global106)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type57 0
       (struct.get $environment71 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (struct.get $type55 0
      (struct.get $type57 1
       (struct.get $environment71 1
        (local.get $0)
       )
      )
     )
     (local.get $8)
     (local.get $2)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.test (ref $type28)
        (local.get $2)
       )
       (then
        (i64.eqz
         (global.get $global159)
        )
       )
       (else
        (i32.and
         (i64.eq
          (global.get $global160)
          (struct.get $type29 0
           (ref.cast (ref $type29)
            (local.get $2)
           )
          )
         )
         (i64.eq
          (global.get $global159)
          (i64.const 2)
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function75 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment75 0
     (ref.cast (ref $environment75)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type38
     (global.get $global117)
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function77 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $type32))
  (local $4 i64)
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 5)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type50 1
     (local.tee $2
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function79)
      (struct.new $environment79
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type50 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type32 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment77 0
        (ref.cast (ref $environment77)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment77 0
        (ref.cast (ref $environment77)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function79 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $type32))
  (local $4 i64)
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 5)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type50 1
     (local.tee $2
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function81)
      (struct.new $environment81
       (struct.get $environment79 0
        (ref.cast (ref $environment79)
         (local.get $0)
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type50 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type32 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment79 1
        (ref.cast (ref $environment79)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment79 1
        (ref.cast (ref $environment79)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function81 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $environment81))
  (local $7 (ref $type38))
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 5)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type38
     (ref.as_non_null
      (global.get $global117)
     )
     (block (result i32)
      (local.set $4
       (struct.get $environment81 0
        (local.tee $6
         (ref.cast (ref $environment81)
          (local.get $0)
         )
        )
       )
      )
      (local.set $3
       (i64.shl
        (local.get $1)
        (i64.const 3)
       )
      )
      (if
       (i64.ne
        (local.get $1)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $3)
           (local.get $1)
          )
          (i64.const 8)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $3)
            (local.tee $5
             (struct.get $environment81 1
              (local.get $6)
             )
            )
           )
          )
          (local.get $5)
         )
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (i64.shl
        (local.get $2)
        (i64.const 3)
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $3)
           (local.get $2)
          )
          (i64.const 8)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $3)
            (local.get $4)
           )
          )
          (local.get $4)
         )
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment81 2
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment81 2
        (local.get $6)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function83 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $type32))
  (local $4 i64)
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 12)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type50 1
     (local.tee $2
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function85)
      (struct.new $environment85
       (struct.get $environment83 0
        (ref.cast (ref $environment83)
         (local.get $0)
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type50 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type32 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment83 1
        (ref.cast (ref $environment83)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment83 1
        (ref.cast (ref $environment83)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function85 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment85 0
     (ref.cast (ref $environment85)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $environment85 1
        (ref.cast (ref $environment85)
         (local.get $0)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type38
     (array.get $type39
      (global.get $global118)
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment85 2
        (ref.cast (ref $environment85)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment85 2
        (ref.cast (ref $environment85)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function86 (type $4) (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64)
  (local $4 (ref $type50))
  (local $5 (ref $type36))
  (local $6 (ref $type32))
  (local $7 (ref null $type36))
  (struct.set $type50 1
   (local.tee $4
    (struct.new_default $type50)
   )
   (struct.new $type32
    (ref.func $function89)
    (struct.new $environment89
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.tee $5
      (struct.new_default $type36)
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type50 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call32
    (struct.get $type32 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type50 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type32 0
     (local.get $6)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $type36 0
      (global.get $global111)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type37
   (global.get $global115)
   (i32.wrap_i64
    (local.get $1)
   )
   (local.get $0)
  )
  (if
   (i64.gt_u
    (local.tee $0
     (struct.get $type36 0
      (global.get $global111)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type37
   (global.get $global116)
   (i32.wrap_i64
    (local.get $0)
   )
   (struct.get $type36 0
    (local.get $5)
   )
  )
  (if
   (i64.ne
    (struct.get $type36 0
     (global.get $global111)
    )
    (i64.const 12)
   )
   (then
    (local.set $0
     (i64.add
      (local.tee $1
       (struct.get $type36 0
        (local.tee $7
         (global.get $global111)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $0)
        (local.get $1)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 0
     (local.get $7)
     (local.get $0)
    )
   )
  )
 )
 (func $function89 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $environment89))
  (local $4 (ref $type32))
  (local $5 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment89 0
     (ref.cast (ref $environment89)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type50 1
     (local.tee $2
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function91)
      (struct.new $environment91
       (struct.get $environment89 1
        (local.tee $3
         (ref.cast (ref $environment89)
          (local.get $0)
         )
        )
       )
       (struct.get $environment89 2
        (local.get $3)
       )
       (struct.get $environment89 3
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type50 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type32 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment89 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment89 4
        (local.get $3)
       )
      )
     )
     (local.get $5)
    )
   )
  )
 )
 (func $function91 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type50))
  (local $3 (ref $environment91))
  (local $4 (ref $type32))
  (local $5 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment91 0
     (ref.cast (ref $environment91)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type50 1
     (local.tee $2
      (struct.new_default $type50)
     )
     (struct.new $type32
      (ref.func $function93)
      (struct.new $environment93
       (struct.get $environment91 1
        (local.tee $3
         (ref.cast (ref $environment91)
          (local.get $0)
         )
        )
       )
       (struct.get $environment91 2
        (local.get $3)
       )
       (struct.get $environment91 3
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type50 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call32
      (struct.get $type32 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type32 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment91 4
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function91
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment91 4
        (local.get $3)
       )
      )
     )
     (local.get $5)
    )
   )
  )
 )
 (func $function93 (type $call32) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $environment93))
  (local $6 (ref $type36))
  (if (result i32)
   (i64.lt_s
    (struct.get $environment93 0
     (ref.cast (ref $environment93)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type36 0
     (struct.get $environment93 1
      (local.tee $5
       (ref.cast (ref $environment93)
        (local.get $0)
       )
      )
     )
     (block (result i64)
      (local.set $3
       (i64.shl
        (local.get $1)
        (i64.const 3)
       )
      )
      (if
       (i64.ne
        (local.get $1)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $3)
           (local.get $1)
          )
          (i64.const 8)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $3)
            (local.tee $4
             (struct.get $environment93 3
              (local.get $5)
             )
            )
           )
          )
          (local.get $4)
         )
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (i64.shl
        (local.get $2)
        (i64.const 3)
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $3)
           (local.get $2)
          )
          (i64.const 8)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (struct.get $environment93 2
            (local.get $5)
           )
          )
          (local.tee $2
           (i64.add
            (local.get $2)
            (local.get $3)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $type36 0
        (global.get $global111)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $type36 0
        (struct.get $environment93 1
         (local.get $5)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type38
     (array.get $type39
      (global.get $global118)
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.const 1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment93 4
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function93
     (struct.get $type32 1
      (struct.get $type50 1
       (struct.get $environment93 4
        (local.get $5)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type57))
  (local $2 (ref $type28))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type44 1
    (global.get $global161)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (struct.set $type57 1
   (local.tee $1
    (struct.new_default $type57)
   )
   (struct.new $type55
    (struct.new $environment71
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type57 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type57 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function71
   (struct.get $type55 0
    (struct.get $type57 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (local.get $2)
  )
 )
 (func $main
  (local $0 (ref null $type33))
  (local $1 (ref $type54))
  (local $2 (ref $type32))
  (local $3 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (global.get $empty28)
  )
  (global.set $global145
   (struct.new $type30
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $global107
   (struct.new_default $type10)
  )
  (global.set $global155
   (struct.new_default $type31)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type34)
  )
  (global.set $global150
   (struct.new_default $type35)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type36)
  )
  (global.set $global112
   (struct.new_default $type36)
  )
  (global.set $global114
   (array.new_default $type37
    (i32.const 4)
   )
  )
  (global.set $global115
   (array.new_default $type37
    (i32.const 13)
   )
  )
  (global.set $global116
   (array.new_default $type37
    (i32.const 13)
   )
  )
  (global.set $global117
   (array.new $type38
    (i32.const 1)
    (i32.const 512)
   )
  )
  (global.set $global118
   (array.new $type39
    (array.new $type38
     (i32.const 1)
     (i32.const 0)
    )
    (i32.const 13)
   )
  )
  (global.set $global119
   (struct.new_default $type40)
  )
  (global.set $global126
   (struct.new_default $type34)
  )
  (global.set $global135
   (struct.new_default $type41)
  )
  (global.set $global141
   (struct.new $type30
    (ref.func $function58)
    (ref.null none)
   )
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type42)
  )
  (global.set $global169
   (struct.new_default $type43)
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (struct.set $type54 1
   (local.tee $1
    (struct.new_default $type54)
   )
   (struct.new $type52
    (struct.new $environment67
     (local.get $1)
    )
   )
  )
  (struct.set $type54 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type54 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (call $function67
    (struct.get $type52 0
     (struct.get $type54 1
      (local.get $1)
     )
    )
    (i64.const 13)
    (ref.null none)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i64.gt_u
       (local.tee $3
        (struct.get $type33 0
         (local.get $0)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (array.set $type39
      (global.get $global118)
      (i32.wrap_i64
       (local.get $3)
      )
      (array.new $type38
       (i32.const 1)
       (i32.const 512)
      )
     )
     (local.set $0
      (struct.get $type33 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready155)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global155)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $0)
      )
      (then
       (i32.const 0)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $3
          (struct.get $type33 0
           (local.get $0)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.set $type39
        (global.get $global118)
        (i32.wrap_i64
         (local.get $3)
        )
        (array.new $type38
         (i32.const 1)
         (i32.const 512)
        )
       )
       (local.set $0
        (struct.get $type33 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready155)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global155)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i32.const 0)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $3
            (struct.get $type33 0
             (local.get $0)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type39
          (global.get $global118)
          (i32.wrap_i64
           (local.get $3)
          )
          (array.new $type38
           (i32.const 1)
           (i32.const 512)
          )
         )
         (local.set $0
          (struct.get $type33 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (global.get $ready155)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global155)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $0)
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $3
              (struct.get $type33 0
               (local.get $0)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.set $type39
            (global.get $global118)
            (i32.wrap_i64
             (local.get $3)
            )
            (array.new $type38
             (i32.const 1)
             (i32.const 512)
            )
           )
           (local.set $0
            (struct.get $type33 1
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (global.get $ready155)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global155)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $0)
            )
            (then
             (i32.const 0)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $3
                (struct.get $type33 0
                 (local.get $0)
                )
               )
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.set $type39
              (global.get $global118)
              (i32.wrap_i64
               (local.get $3)
              )
              (array.new $type38
               (i32.const 1)
               (i32.const 512)
              )
             )
             (local.set $0
              (struct.get $type33 1
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (global.get $ready155)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global155)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $0)
              )
              (then
               (i32.const 0)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $3
                  (struct.get $type33 0
                   (local.get $0)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (array.set $type39
                (global.get $global118)
                (i32.wrap_i64
                 (local.get $3)
                )
                (array.new $type38
                 (i32.const 1)
                 (i32.const 512)
                )
               )
               (local.set $0
                (struct.get $type33 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready155)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global155)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $0)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if
                  (i64.gt_u
                   (local.tee $3
                    (struct.get $type33 0
                     (local.get $0)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.set $type39
                  (global.get $global118)
                  (i32.wrap_i64
                   (local.get $3)
                  )
                  (array.new $type38
                   (i32.const 1)
                   (i32.const 512)
                  )
                 )
                 (local.set $0
                  (struct.get $type33 1
                   (local.get $0)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready155)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global155)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $0)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if
                    (i64.gt_u
                     (local.tee $3
                      (struct.get $type33 0
                       (local.get $0)
                      )
                     )
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (array.set $type39
                    (global.get $global118)
                    (i32.wrap_i64
                     (local.get $3)
                    )
                    (array.new $type38
                     (i32.const 1)
                     (i32.const 512)
                    )
                   )
                   (local.set $0
                    (struct.get $type33 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready155)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global155)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $0)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if
                      (i64.gt_u
                       (local.tee $3
                        (struct.get $type33 0
                         (local.get $0)
                        )
                       )
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (array.set $type39
                      (global.get $global118)
                      (i32.wrap_i64
                       (local.get $3)
                      )
                      (array.new $type38
                       (i32.const 1)
                       (i32.const 512)
                      )
                     )
                     (local.set $0
                      (struct.get $type33 1
                       (local.get $0)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready155)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global155)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $0)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if
                        (i64.gt_u
                         (local.tee $3
                          (struct.get $type33 0
                           (local.get $0)
                          )
                         )
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (array.set $type39
                        (global.get $global118)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                        (array.new $type38
                         (i32.const 1)
                         (i32.const 512)
                        )
                       )
                       (local.set $0
                        (struct.get $type33 1
                         (local.get $0)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready155)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global155)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $0)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if
                          (i64.gt_u
                           (local.tee $3
                            (struct.get $type33 0
                             (local.get $0)
                            )
                           )
                           (i64.const 4294967295)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (array.set $type39
                          (global.get $global118)
                          (i32.wrap_i64
                           (local.get $3)
                          )
                          (array.new $type38
                           (i32.const 1)
                           (i32.const 512)
                          )
                         )
                         (local.set $0
                          (struct.get $type33 1
                           (local.get $0)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready155)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global155)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $0)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if
                            (i64.gt_u
                             (local.tee $3
                              (struct.get $type33 0
                               (local.get $0)
                              )
                             )
                             (i64.const 4294967295)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (array.set $type39
                            (global.get $global118)
                            (i32.wrap_i64
                             (local.get $3)
                            )
                            (array.new $type38
                             (i32.const 1)
                             (i32.const 512)
                            )
                           )
                           (local.set $0
                            (struct.get $type33 1
                             (local.get $0)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready155)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global155)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $0)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if
                              (i64.gt_u
                               (local.tee $3
                                (struct.get $type33 0
                                 (local.get $0)
                                )
                               )
                               (i64.const 4294967295)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (array.set $type39
                              (global.get $global118)
                              (i32.wrap_i64
                               (local.get $3)
                              )
                              (array.new $type38
                               (i32.const 1)
                               (i32.const 512)
                              )
                             )
                             (local.set $0
                              (struct.get $type33 1
                               (local.get $0)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready155)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global155)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $0)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if
                                (i64.gt_u
                                 (local.tee $3
                                  (struct.get $type33 0
                                   (local.get $0)
                                  )
                                 )
                                 (i64.const 4294967295)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (array.set $type39
                                (global.get $global118)
                                (i32.wrap_i64
                                 (local.get $3)
                                )
                                (array.new $type38
                                 (i32.const 1)
                                 (i32.const 512)
                                )
                               )
                               (local.set $0
                                (struct.get $type33 1
                                 (local.get $0)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready155)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global155)
                                )
                               )
                               (local.set $2
                                (struct.new $type32
                                 (ref.func $function64)
                                 (ref.null none)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $0)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (drop
                                  (call $function64
                                   (ref.null none)
                                   (struct.get $type33 0
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (local.set $0
                                  (struct.get $type33 1
                                   (local.get $0)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready155)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global155)
                                  )
                                 )
                                 (call $function68
                                  (local.get $2)
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $global158
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $global159
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $global160
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $global161
   (struct.new $type44
    (ref.func $function69)
    (ref.null none)
   )
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

