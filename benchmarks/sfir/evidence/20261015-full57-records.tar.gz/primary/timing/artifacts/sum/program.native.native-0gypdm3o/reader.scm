(module
 (rec
  (type $environment46 (struct (field i64) (field (ref $type30))))
  (type $type30 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $environment43 (struct (field (ref $type30))))
  (type $call27 (func (param structref i64 i64) (result i64)))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field structref)))
 )
 (type $6 (func (param i64) (result i64)))
 (type $7 (func (param i32) (result i64)))
 (type $8 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type27)) (ref.null none))
 (global $global106 (mut (ref null $type28)) (ref.null none))
 (global $global111 (mut i64) (i64.const 0))
 (global $global112 (mut (ref null $type28)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (local.get $2)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type27 1
      (struct.get $type30 1
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function46 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type30))
  (local $4 (ref $environment46))
  (local $5 (ref $type27))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment46 0
     (ref.cast (ref $environment46)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global117)
     )
    )
    (local.set $4
     (ref.cast (ref $environment46)
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global111)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (struct.set $type30 1
     (local.tee $3
      (struct.new_default $type30)
     )
     (struct.new $type27
      (ref.func $function43)
      (struct.new $environment43
       (local.get $3)
      )
     )
    )
    (struct.set $type30 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call27
      (struct.get $type27 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type30 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (i64.const 0)
      (struct.get $type27 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment46 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (struct.get $type27 1
      (struct.get $type30 1
       (struct.get $environment46 1
        (local.get $4)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function47 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type30))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type30 1
   (local.tee $1
    (struct.new_default $type30)
   )
   (struct.new $type27
    (ref.func $function46)
    (struct.new $environment46
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type30 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type30 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global117
   (struct.new $type27
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new_default $type28)
  )
  (global.set $global111
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global112
   (struct.new_default $type28)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

