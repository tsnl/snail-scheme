(module
 (rec
  (type $0 (func (param i32 i32 i64 (ref null $type28)) (result (ref null $type28))))
  (type $1 (func (param (ref null $type28)) (result (ref null $type28))))
  (type $call31 (func (param i64 i64) (result (ref null $type28))))
  (type $environment47 (struct (field i64) (field (ref $type37))))
  (type $call34 (func (param i64) (result i64)))
  (type $call29 (func (param (ref null $type28) (ref null $type28)) (result i32)))
  (type $type35 (struct (field (ref $call35)) (field (ref struct))))
  (type $type37 (struct (field (mut i32)) (field (mut (ref null $type35)))))
  (type $environment43 (struct (field (ref $type37))))
  (type $call35 (func (param (ref struct) i64 (ref null $type28)) (result (ref null $type28))))
  (type $type34 (struct))
  (type $type28 (struct (field i64) (field (ref null $type28))))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type27 (struct (field nullref)))
 )
 (type $18 (func (param i64) (result i64)))
 (type $19 (func (result i64)))
 (type $20 (func (param i32) (result i64)))
 (type $21 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type29)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type30)) (ref.null none))
 (global $global125 (mut (ref null $type31)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type32)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global123 (mut (ref null $type33)) (ref.null none))
 (global $global113 (mut i64) (i64.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $global115 (mut (ref null $type34)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 i64)
  (local $4 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $foreign1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type35 1
      (struct.get $type37 1
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function44 (type $call29) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (result i32)
  (local $scratch (ref null $type28))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type28 0
         (local.get $0)
        )
        (struct.get $type28 0
         (local.get $1)
        )
       )
       (then
        (return_call $function44
         (struct.get $type28 1
          (local.get $0)
         )
         (block (result (ref null $type28))
          (local.set $scratch
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready110)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global110)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function45 (type $call34) (param $0 i64) (result i64)
  (local $1 (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref $type37))
  (local $4 (ref $type35))
  (local $scratch (ref null $type28))
  (struct.set $type37 1
   (local.tee $3
    (struct.new_default $type37)
   )
   (struct.new $type35
    (ref.func $function47)
    (struct.new $environment47
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type37 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type37 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type35 0
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (local.set $1
   (global.get $global114)
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (ref.is_null
       (local.get $1)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type28 0
           (local.get $2)
          )
          (struct.get $type28 0
           (local.get $1)
          )
         )
         (then
          (local.set $2
           (struct.get $type28 1
            (local.get $2)
           )
          )
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready110)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global110)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.is_null
             (local.get $1)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type28 0
                 (local.get $2)
                )
                (struct.get $type28 0
                 (local.get $1)
                )
               )
               (then
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.get $type28 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready110)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global110)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.is_null
                   (local.get $1)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type28 0
                       (local.get $2)
                      )
                      (struct.get $type28 0
                       (local.get $1)
                      )
                     )
                     (then
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (local.set $1
                       (struct.get $type28 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready110)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global110)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.is_null
                         (local.get $1)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type28 0
                             (local.get $2)
                            )
                            (struct.get $type28 0
                             (local.get $1)
                            )
                           )
                           (then
                            (local.set $2
                             (struct.get $type28 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.get $type28 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready110)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global110)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.is_null
                               (local.get $1)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type28 0
                                   (local.get $2)
                                  )
                                  (struct.get $type28 0
                                   (local.get $1)
                                  )
                                 )
                                 (then
                                  (local.set $2
                                   (struct.get $type28 1
                                    (local.get $2)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type28 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready110)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global110)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type28 0
                                         (local.get $2)
                                        )
                                        (struct.get $type28 0
                                         (local.get $1)
                                        )
                                       )
                                       (then
                                        (local.set $2
                                         (struct.get $type28 1
                                          (local.get $2)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type28 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready110)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global110)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type28 0
                                               (local.get $2)
                                              )
                                              (struct.get $type28 0
                                               (local.get $1)
                                              )
                                             )
                                             (then
                                              (local.set $2
                                               (struct.get $type28 1
                                                (local.get $2)
                                               )
                                              )
                                              (local.set $1
                                               (struct.get $type28 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready110)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global110)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type28 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type28 0
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $2
                                                     (struct.get $type28 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (local.set $1
                                                     (struct.get $type28 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready110)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global110)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type28 0
                                                           (local.get $2)
                                                          )
                                                          (struct.get $type28 0
                                                           (local.get $1)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $2
                                                           (struct.get $type28 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (local.set $1
                                                           (struct.get $type28 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready110)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global110)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type28 0
                                                                 (local.get $2)
                                                                )
                                                                (struct.get $type28 0
                                                                 (local.get $1)
                                                                )
                                                               )
                                                               (then
                                                                (call $function44
                                                                 (struct.get $type28 1
                                                                  (local.get $2)
                                                                 )
                                                                 (block (result (ref null $type28))
                                                                  (local.set $scratch
                                                                   (struct.get $type28 1
                                                                    (local.get $1)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (global.get $ready110)
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global110)
                                                                   )
                                                                  )
                                                                  (local.get $scratch)
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function47 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type28)) (result (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref $environment47))
  (local $5 i64)
  (if (result (ref null $type28))
   (i64.gt_s
    (struct.get $environment47 0
     (ref.cast (ref $environment47)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (ref.cast (ref $environment47)
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (local.set $1
     (call $foreign2
      (global.get $global113)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global123)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (local.set $2
     (if (result (ref null $type28))
      (i64.lt_s
       (local.get $1)
       (i64.const 2)
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready125)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global125)
        )
       )
       (struct.new $type28
        (i64.const 2)
        (if (result (ref null $type28))
         (i64.lt_s
          (local.get $1)
          (i64.const 3)
         )
         (then
          (ref.null none)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready125)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global125)
           )
          )
          (struct.new $type28
           (i64.const 3)
           (if (result (ref null $type28))
            (i64.lt_s
             (local.get $1)
             (i64.const 4)
            )
            (then
             (ref.null none)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready125)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global125)
              )
             )
             (struct.new $type28
              (i64.const 4)
              (if (result (ref null $type28))
               (i64.lt_s
                (local.get $1)
                (i64.const 5)
               )
               (then
                (ref.null none)
               )
               (else
                (if
                 (i32.eqz
                  (global.get $ready125)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global125)
                 )
                )
                (struct.new $type28
                 (i64.const 5)
                 (if (result (ref null $type28))
                  (i64.lt_s
                   (local.get $1)
                   (i64.const 6)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready125)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global125)
                    )
                   )
                   (struct.new $type28
                    (i64.const 6)
                    (if (result (ref null $type28))
                     (i64.lt_s
                      (local.get $1)
                      (i64.const 7)
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (if
                       (i32.eqz
                        (global.get $ready125)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global125)
                       )
                      )
                      (struct.new $type28
                       (i64.const 7)
                       (if (result (ref null $type28))
                        (i64.lt_s
                         (local.get $1)
                         (i64.const 8)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready125)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global125)
                          )
                         )
                         (struct.new $type28
                          (i64.const 8)
                          (if (result (ref null $type28))
                           (i64.lt_s
                            (local.get $1)
                            (i64.const 9)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (if
                             (i32.eqz
                              (global.get $ready125)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global125)
                             )
                            )
                            (struct.new $type28
                             (i64.const 9)
                             (if (result (ref null $type28))
                              (i64.lt_s
                               (local.get $1)
                               (i64.const 10)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (if
                                (i32.eqz
                                 (global.get $ready125)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global125)
                                )
                               )
                               (struct.new $type28
                                (i64.const 10)
                                (call $function50
                                 (i64.const 11)
                                 (local.get $1)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (local.set $2
     (if (result (ref null $type28))
      (ref.is_null
       (local.get $2)
      )
      (then
       (ref.null none)
      )
      (else
       (local.set $3
        (call $function53
         (i32.const 0)
         (i32.const 1)
         (local.tee $1
          (struct.get $type28 0
           (local.get $2)
          )
         )
         (struct.get $type28 1
          (local.get $2)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready128)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global128)
        )
       )
       (struct.new $type28
        (local.get $1)
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $3)
         )
         (then
          (ref.null none)
         )
         (else
          (local.set $3
           (call $function53
            (i32.const 0)
            (i32.const 1)
            (local.tee $1
             (struct.get $type28 0
              (local.get $3)
             )
            )
            (struct.get $type28 1
             (local.get $3)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready128)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global128)
           )
          )
          (struct.new $type28
           (local.get $1)
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $3)
            )
            (then
             (ref.null none)
            )
            (else
             (local.set $3
              (call $function53
               (i32.const 0)
               (i32.const 1)
               (local.tee $1
                (struct.get $type28 0
                 (local.get $3)
                )
               )
               (struct.get $type28 1
                (local.get $3)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready128)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global128)
              )
             )
             (struct.new $type28
              (local.get $1)
              (if (result (ref null $type28))
               (ref.is_null
                (local.get $3)
               )
               (then
                (ref.null none)
               )
               (else
                (local.set $3
                 (call $function53
                  (i32.const 0)
                  (i32.const 1)
                  (local.tee $1
                   (struct.get $type28 0
                    (local.get $3)
                   )
                  )
                  (struct.get $type28 1
                   (local.get $3)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready128)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global128)
                 )
                )
                (struct.new $type28
                 (local.get $1)
                 (if (result (ref null $type28))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (local.set $3
                    (call $function53
                     (i32.const 0)
                     (i32.const 1)
                     (local.tee $1
                      (struct.get $type28 0
                       (local.get $3)
                      )
                     )
                     (struct.get $type28 1
                      (local.get $3)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready128)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global128)
                    )
                   )
                   (struct.new $type28
                    (local.get $1)
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (ref.null none)
                     )
                     (else
                      (local.set $3
                       (call $function53
                        (i32.const 0)
                        (i32.const 1)
                        (local.tee $1
                         (struct.get $type28 0
                          (local.get $3)
                         )
                        )
                        (struct.get $type28 1
                         (local.get $3)
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready128)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global128)
                       )
                      )
                      (struct.new $type28
                       (local.get $1)
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (local.set $3
                          (call $function53
                           (i32.const 0)
                           (i32.const 1)
                           (local.tee $1
                            (struct.get $type28 0
                             (local.get $3)
                            )
                           )
                           (struct.get $type28 1
                            (local.get $3)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready128)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global128)
                          )
                         )
                         (struct.new $type28
                          (local.get $1)
                          (if (result (ref null $type28))
                           (ref.is_null
                            (local.get $3)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (local.set $3
                             (call $function53
                              (i32.const 0)
                              (i32.const 1)
                              (local.tee $1
                               (struct.get $type28 0
                                (local.get $3)
                               )
                              )
                              (struct.get $type28 1
                               (local.get $3)
                              )
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready128)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global128)
                             )
                            )
                            (struct.new $type28
                             (local.get $1)
                             (if (result (ref null $type28))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (local.set $3
                                (call $function53
                                 (i32.const 0)
                                 (i32.const 1)
                                 (local.tee $1
                                  (struct.get $type28 0
                                   (local.get $3)
                                  )
                                 )
                                 (struct.get $type28 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready128)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global128)
                                )
                               )
                               (struct.new $type28
                                (local.get $1)
                                (call $function51
                                 (local.get $3)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment47 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (struct.get $type35 1
      (struct.get $type37 1
       (struct.get $environment47 1
        (local.get $4)
       )
      )
     )
     (local.get $5)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function50 (type $call31) (param $0 i64) (param $1 i64) (result (ref null $type28))
  (local $2 i64)
  (if (result (ref null $type28))
   (i64.gt_s
    (local.get $0)
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.add
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 1)
       )
       (i64.xor
        (local.get $0)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (struct.new $type28
     (local.get $0)
     (call $function50
      (local.get $2)
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function51 (type $1) (param $0 (ref null $type28)) (result (ref null $type28))
  (local $1 i64)
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $0
     (call $function53
      (i32.const 0)
      (i32.const 1)
      (local.tee $1
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (struct.new $type28
     (local.get $1)
     (call $function51
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function53 (type $0) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 (ref null $type28)) (result (ref null $type28))
  (local $4 i64)
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $3)
   )
   (then
    (ref.null none)
   )
   (else
    (if (result (ref $type28))
     (i64.eqz
      (i64.rem_s
       (struct.get $type28 0
        (local.get $3)
       )
       (local.get $2)
      )
     )
     (then
      (local.set $3
       (struct.get $type28 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function53
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
     (else
      (struct.new $type28
       (struct.get $type28 0
        (local.get $3)
       )
       (block (result (ref null $type28))
        (local.set $3
         (struct.get $type28 1
          (local.get $3)
         )
        )
        (if
         (i32.eqz
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (call $function53
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready115)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (return_call $function45
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type37))
  (local $1 (ref $type35))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type29)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type30)
  )
  (global.set $global125
   (struct.new_default $type31)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type32)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global123
   (struct.new_default $type33)
  )
  (global.set $global113
   (call $foreign3
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (local.set $2
   (call $foreign0)
  )
  (struct.set $type37 1
   (local.tee $0
    (struct.new_default $type37)
   )
   (struct.new $type35
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
    )
   )
  )
  (struct.set $type37 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global114
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type37 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type35 0
     (local.get $1)
    )
   )
  )
  (global.set $global115
   (struct.new_default $type34)
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

