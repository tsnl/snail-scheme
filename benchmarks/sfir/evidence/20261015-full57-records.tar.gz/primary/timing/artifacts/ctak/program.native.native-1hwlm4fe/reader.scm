(module
 (rec
  (type $type28 (sub (struct (field i32))))
  (type $1 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $type32 (sub $type28 (struct (field i32) (field i64) (field i64) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field i32) (field i64) (field i64) (field i64) (field (ref $type28)))))
  (type $type31 (sub $type28 (struct (field i32) (field i64) (field i64) (field i64) (field i64) (field (ref $type28)))))
  (type $call33 (func (param (ref $type28) i64 i64 i64) (result i64)))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type27 (struct))
  (type $type29 (sub $type28 (struct (field i32))))
 )
 (type $12 (func (param i64) (result i64)))
 (type $13 (func (param i32) (result i64)))
 (type $14 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty29 (ref $type29) (struct.new $type29
  (i32.const 0)
 ))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global108 (mut (ref null $type33)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type34)) (ref.null none))
 (global $ready113 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type35)) (ref.null none))
 (global $global134 (mut i64) (i64.const 0))
 (global $global135 (mut i64) (i64.const 0))
 (global $global136 (mut i64) (i64.const 0))
 (global $global137 (mut (ref null $type36)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function42 (type $call33) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type31))
  (local $7 (ref $type31))
  (local $8 (ref $type30))
  (local $9 (ref $type32))
  (if (result i64)
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready108)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global108)
     )
    )
    (return_call $function42
     (struct.new $type30
      (i32.const 1)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $0)
     )
     (local.get $4)
     (local.get $2)
     (local.get $3)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready113)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (if (result i64)
     (local.tee $5
      (struct.get $type28 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eq
        (local.get $5)
        (i32.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global106)
         )
        )
        (return_call $function42
         (struct.new $type31
          (i32.const 2)
          (local.get $3)
          (local.tee $2
           (struct.get $type30 1
            (local.tee $8
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
           )
          )
          (local.tee $1
           (struct.get $type30 2
            (local.get $8)
           )
          )
          (local.tee $3
           (struct.get $type30 3
            (local.get $8)
           )
          )
          (struct.get $type30 4
           (local.get $8)
          )
         )
         (block (result i64)
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $4
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global108)
           )
          )
          (local.get $4)
         )
         (local.get $3)
         (local.get $2)
        )
       )
       (else
        (if
         (i32.eq
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (local.set $4
           (struct.get $type31 2
            (local.tee $6
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global106)
           )
          )
          (local.set $2
           (i64.sub
            (local.tee $1
             (struct.get $type31 4
              (local.get $6)
             )
            )
            (i64.const 1)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $1)
              (local.get $2)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global108)
           )
          )
          (return_call $function42
           (struct.new $type32
            (i32.const 3)
            (struct.get $type31 1
             (local.get $6)
            )
            (local.get $3)
            (struct.get $type31 5
             (local.get $6)
            )
           )
           (local.get $2)
           (local.get $4)
           (struct.get $type31 3
            (local.get $6)
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global108)
           )
          )
          (return_call $function42
           (struct.get $type32 3
            (local.tee $9
             (ref.cast (ref $type32)
              (local.get $0)
             )
            )
           )
           (struct.get $type32 1
            (local.get $9)
           )
           (struct.get $type32 2
            (local.get $9)
           )
           (local.get $3)
          )
         )
        )
        (unreachable)
       )
      )
      (unreachable)
     )
     (else
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function46 (type $1) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $foreign0
      (global.get $global134)
     )
    )
    (local.set $5
     (call $foreign0
      (global.get $global135)
     )
    )
    (local.set $6
     (call $foreign0
      (global.get $global136)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global108)
     )
    )
    (local.set $3
     (call $function42
      (global.get $empty29)
      (local.get $3)
      (local.get $5)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
     (local.get $3)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready137)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (return_call $function46
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global108
   (struct.new_default $type33)
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $global113
   (struct.new_default $type34)
  )
  (global.set $ready113
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type35)
  )
  (global.set $global134
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global135
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global136
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $global137
   (struct.new_default $type36)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

