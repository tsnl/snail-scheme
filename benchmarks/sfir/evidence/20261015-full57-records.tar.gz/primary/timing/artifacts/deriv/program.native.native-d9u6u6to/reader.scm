(module
 (rec
  (type $type28 (sub (struct (field i32))))
  (type $type58 (struct (field (mut i32)) (field (mut (ref null $type51)))))
  (type $environment73 (struct (field i64) (field (ref $type58))))
  (type $call51 (func (param (ref null $environment73) i64 (ref $type28)) (result (ref $type28))))
  (type $type48 (struct (field (mut i64))))
  (type $call50 (func (param i32 (ref $type48)) (result (ref $type28))))
  (type $call46 (func (param (ref $type28) (ref $type28)) (result i32)))
  (type $call45 (func (param (ref $type42) (ref $type28)) (result (ref $type28))))
  (type $call42 (func (param (ref $type28)) (result (ref $type28))))
  (type $type40 (sub $type28 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $call27 (func (param (ref $type28)) (result i64)))
  (type $type52 (struct))
  (type $type51 (struct (field (ref $call51)) (field (ref null $environment73))))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct (field (ref $call42))))
  (type $type41 (struct))
  (type $type39 (sub $type28 (struct (field i32) (field i64))))
  (type $type27 (struct))
  (type $type38 (sub $type28 (struct (field i32))))
  (type $type37 (sub $type28 (struct (field i32))))
  (type $type36 (sub $type28 (struct (field i32))))
  (type $type35 (sub $type28 (struct (field i32))))
  (type $type34 (sub $type28 (struct (field i32))))
  (type $type33 (sub $type28 (struct (field i32))))
  (type $type32 (sub $type28 (struct (field i32))))
  (type $type31 (sub $type28 (struct (field i32))))
  (type $type30 (sub $type28 (struct (field i32))))
  (type $type29 (sub $type28 (struct (field i32))))
 )
 (type $34 (func (param i32 i64) (result i64)))
 (type $35 (func (param i32) (result i64)))
 (type $36 (func (result i32)))
 (type $37 (func (param i64) (result i64)))
 (type $38 (func))
 (import "benchmark" "vector_i64" (func $foreign0 (param i32 i64) (result i64)))
 (import "benchmark" "vector_length" (func $foreign1 (param i32) (result i64)))
 (import "benchmark" "barrier" (func $foreign2 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty29 (ref $type29) (struct.new $type29
  (i32.const 0)
 ))
 (global $empty30 (ref $type30) (struct.new $type30
  (i32.const 1)
 ))
 (global $empty31 (ref $type31) (struct.new $type31
  (i32.const 2)
 ))
 (global $empty32 (ref $type32) (struct.new $type32
  (i32.const 3)
 ))
 (global $empty33 (ref $type33) (struct.new $type33
  (i32.const 4)
 ))
 (global $empty34 (ref $type34) (struct.new $type34
  (i32.const 5)
 ))
 (global $empty35 (ref $type35) (struct.new $type35
  (i32.const 6)
 ))
 (global $empty36 (ref $type36) (struct.new $type36
  (i32.const 7)
 ))
 (global $empty37 (ref $type37) (struct.new $type37
  (i32.const 8)
 ))
 (global $empty38 (ref $type38) (struct.new $type38
  (i32.const 9)
 ))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global112 (mut (ref null $type29)) (ref.null none))
 (global $global113 (mut (ref null $type30)) (ref.null none))
 (global $global114 (mut (ref null $type31)) (ref.null none))
 (global $global115 (mut (ref null $type32)) (ref.null none))
 (global $global116 (mut (ref null $type33)) (ref.null none))
 (global $global117 (mut (ref null $type34)) (ref.null none))
 (global $global118 (mut (ref null $type35)) (ref.null none))
 (global $global119 (mut (ref null $type36)) (ref.null none))
 (global $global120 (mut (ref null $type37)) (ref.null none))
 (global $global121 (mut (ref null $type38)) (ref.null none))
 (global $global122 (mut (ref null $type39)) (ref.null none))
 (global $global123 (mut (ref null $type39)) (ref.null none))
 (global $global124 (mut (ref null $type41)) (ref.null none))
 (global $global130 (mut (ref null $type41)) (ref.null none))
 (global $global136 (mut (ref null $type41)) (ref.null none))
 (global $global154 (mut (ref null $type41)) (ref.null none))
 (global $global160 (mut (ref null $type41)) (ref.null none))
 (global $global166 (mut (ref null $type41)) (ref.null none))
 (global $global172 (mut (ref null $type41)) (ref.null none))
 (global $global178 (mut (ref null $type42)) (ref.null none))
 (global $global180 (mut (ref null $type42)) (ref.null none))
 (global $global182 (mut (ref null $type43)) (ref.null none))
 (global $global186 (mut (ref null $type44)) (ref.null none))
 (global $global191 (mut (ref null $type45)) (ref.null none))
 (global $ready191 (mut i32) (i32.const 0))
 (global $global194 (mut (ref null $type46)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type47)) (ref.null none))
 (global $global202 (mut (ref null $type49)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global205 (mut (ref null $type50)) (ref.null none))
 (global $ready205 (mut i32) (i32.const 0))
 (global $global222 (mut (ref null $type51)) (ref.null none))
 (global $global212 (mut (ref null $type42)) (ref.null none))
 (global $ready212 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type28)) (ref.null none))
 (global $global216 (mut (ref null $type28)) (ref.null none))
 (global $global217 (mut (ref null $type52)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call27) (param $0 (ref $type28)) (result i64)
  (local $1 i32)
  (if (result i64)
   (local.tee $1
    (struct.get $type28 0
     (local.get $0)
    )
   )
   (then
    (if (result i64)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i32.eq
        (struct.get $type28 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (i64.const 5)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (i64.const 6)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (i64.const 7)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type28 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (i64.const 8)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type28 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (i64.const 9)
                 )
                 (else
                  (if (result i64)
                   (i32.eq
                    (struct.get $type28 0
                     (local.get $0)
                    )
                    (i32.const 8)
                   )
                   (then
                    (i64.const 10)
                   )
                   (else
                    (if (result i64)
                     (i32.eq
                      (struct.get $type28 0
                       (local.get $0)
                      )
                      (i32.const 9)
                     )
                     (then
                      (i64.const 11)
                     )
                     (else
                      (if (result i64)
                       (i32.eq
                        (struct.get $type28 0
                         (local.get $0)
                        )
                        (i32.const 10)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type39)
                          (local.get $0)
                         )
                        )
                        (i64.const 3)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type40)
                          (local.get $0)
                         )
                        )
                        (i64.const 4)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function51 (type $call42) (param $0 (ref $type28)) (result (ref $type28))
  (if
   (i32.ne
    (struct.get $type28 0
     (local.get $0)
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type28 0
     (local.tee $0
      (struct.get $type40 2
       (ref.cast (ref $type40)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type40 1
   (ref.cast (ref $type40)
    (local.get $0)
   )
  )
 )
 (func $function52 (type $call42) (param $0 (ref $type28)) (result (ref $type28))
  (if
   (i32.ne
    (struct.get $type28 0
     (local.get $0)
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type28 0
     (local.tee $0
      (struct.get $type40 2
       (ref.cast (ref $type40)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type28 0
     (local.tee $0
      (struct.get $type40 2
       (ref.cast (ref $type40)
        (local.get $0)
       )
      )
     )
    )
    (i32.const 11)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type40 1
   (ref.cast (ref $type40)
    (local.get $0)
   )
  )
 )
 (func $function55 (type $call45) (param $0 (ref $type42)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 i32)
  (local $3 (ref $type40))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (local.tee $2
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $2)
       (i32.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i32.eq
         (struct.get $type28 0
          (local.get $1)
         )
         (i32.const 2)
        )
        (then
         (i32.const 1)
        )
        (else
         (if
          (i32.ne
           (local.tee $2
            (struct.get $type28 0
             (local.get $1)
            )
           )
           (i32.const 3)
          )
          (then
           (if
            (i32.and
             (i32.ne
              (local.get $2)
              (i32.const 4)
             )
             (i32.ne
              (local.get $2)
              (i32.const 5)
             )
            )
            (then
             (if
              (i32.and
               (i32.ne
                (local.get $2)
                (i32.const 6)
               )
               (i32.ne
                (local.get $2)
                (i32.const 7)
               )
              )
              (then
               (if
                (i32.and
                 (i32.ne
                  (local.get $2)
                  (i32.const 8)
                 )
                 (i32.ne
                  (local.get $2)
                  (i32.const 9)
                 )
                )
                (then
                 (if
                  (i32.eq
                   (local.get $2)
                   (i32.const 10)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type39)
                     (local.get $1)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type40)
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (ref.as_non_null
     (global.get $global114)
    )
   )
   (else
    (if
     (i32.ne
      (struct.get $type28 0
       (local.get $1)
      )
      (i32.const 11)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call42
      (struct.get $type40 1
       (local.tee $3
        (ref.cast (ref $type40)
         (local.get $1)
        )
       )
      )
      (struct.get $type42 0
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready191)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global191)
     )
    )
    (struct.new $type40
     (i32.const 11)
     (local.get $1)
     (call $function55
      (local.get $0)
      (struct.get $type40 2
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function56 (type $call46) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i32)
  (local $2 i64)
  (local $3 (ref $type28))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (local $scratch_6 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (local.set $2
   (call $function41
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if (result i32)
   (i64.eq
    (call $function41
     (local.get $1)
    )
    (local.get $2)
   )
   (then
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 3)
     )
     (then
      (if
       (i32.ne
        (struct.get $type28 0
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type39 1
        (ref.cast (ref $type39)
         (local.get $0)
        )
       )
      )
      (if
       (i32.ne
        (struct.get $type28 0
         (local.get $1)
        )
        (i32.const 10)
       )
       (then
        (unreachable)
       )
      )
      (i64.eq
       (struct.get $type39 1
        (ref.cast (ref $type39)
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
     (else
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 4)
       )
       (then
        (if
         (i32.ne
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (call $function56
          (struct.get $type40 1
           (ref.cast (ref $type40)
            (local.get $0)
           )
          )
          (block (result (ref $type28))
           (if
            (i32.ne
             (struct.get $type28 0
              (local.get $1)
             )
             (i32.const 11)
            )
            (then
             (unreachable)
            )
           )
           (local.set $scratch
            (struct.get $type40 1
             (ref.cast (ref $type40)
              (local.get $1)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready194)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global194)
            )
           )
           (local.get $scratch)
          )
         )
         (then
          (if
           (i32.ne
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (return_call $function56
           (struct.get $type40 2
            (ref.cast (ref $type40)
             (local.get $0)
            )
           )
           (block (result (ref $type28))
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $1)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $scratch_6
             (struct.get $type40 2
              (ref.cast (ref $type40)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready194)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global194)
             )
            )
            (local.get $scratch_6)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 1)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function62 (type $call50) (param $0 i32) (param $1 (ref $type48)) (result (ref $type28))
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global198)
   )
  )
  (local.set $2
   (struct.get $type48 0
    (local.get $1)
   )
  )
  (if (result (ref $type28))
   (i64.eq
    (local.tee $2
     (if (result i64)
      (i64.gt_s
       (call $foreign1
        (local.get $0)
       )
       (local.get $2)
      )
      (then
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $3
            (i64.add
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $2)
          )
          (i64.xor
           (local.get $3)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type48 0
        (local.get $1)
        (local.get $3)
       )
       (call $foreign0
        (local.get $0)
        (local.get $2)
       )
      )
      (else
       (unreachable)
      )
     )
    )
    (i64.const 3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (local.set $2
     (struct.get $type48 0
      (local.get $1)
     )
    )
    (struct.new $type39
     (i32.const 10)
     (if (result i64)
      (i64.gt_s
       (call $foreign1
        (local.get $0)
       )
       (local.get $2)
      )
      (then
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $3
            (i64.add
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $2)
          )
          (i64.xor
           (local.get $3)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type48 0
        (local.get $1)
        (local.get $3)
       )
       (call $foreign0
        (local.get $0)
        (local.get $2)
       )
      )
      (else
       (unreachable)
      )
     )
    )
   )
   (else
    (if (result (ref $type28))
     (i64.eq
      (local.get $2)
      (i64.const 4)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready205)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global205)
       )
      )
      (local.set $4
       (call $function62
        (local.get $0)
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready205)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global205)
       )
      )
      (struct.new $type40
       (i32.const 11)
       (local.get $4)
       (call $function62
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (else
      (if (result (ref $type28))
       (i64.eqz
        (local.get $2)
       )
       (then
        (ref.as_non_null
         (global.get $global112)
        )
       )
       (else
        (if (result (ref $type28))
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (ref.as_non_null
           (global.get $global113)
          )
         )
         (else
          (if (result (ref $type28))
           (i64.eq
            (local.get $2)
            (i64.const 2)
           )
           (then
            (ref.as_non_null
             (global.get $global114)
            )
           )
           (else
            (if (result (ref $type28))
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (ref.as_non_null
               (global.get $global115)
              )
             )
             (else
              (if (result (ref $type28))
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (ref.as_non_null
                 (global.get $global116)
                )
               )
               (else
                (if (result (ref $type28))
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (ref.as_non_null
                   (global.get $global117)
                  )
                 )
                 (else
                  (if (result (ref $type28))
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (ref.as_non_null
                     (global.get $global118)
                    )
                   )
                   (else
                    (if (result (ref $type28))
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (ref.as_non_null
                       (global.get $global119)
                      )
                     )
                     (else
                      (if (result (ref $type28))
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (ref.as_non_null
                         (global.get $global120)
                        )
                       )
                       (else
                        (if (result (ref $type38))
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (ref.as_non_null
                           (global.get $global121)
                          )
                         )
                         (else
                          (unreachable)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function69 (type $call42) (param $0 (ref $type28)) (result (ref $type28))
  (local $1 (ref $type28))
  (local $2 (ref $type28))
  (local $3 (ref $type28))
  (local $4 (ref $type28))
  (local $5 (ref $type28))
  (local $6 (ref $type35))
  (local $7 (ref $type42))
  (local $8 (ref $type36))
  (local $9 (ref $type37))
  (local $10 (ref $type31))
  (local $11 (ref $type40))
  (local $12 (ref $type40))
  (local $13 (ref $type38))
  (local $14 (ref $type38))
  (local $15 i32)
  (local $scratch (ref $type28))
  (local $scratch_17 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (local.tee $15
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $15)
       (i32.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i32.eq
         (struct.get $type28 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type28 0
            (local.get $0)
           )
           (i32.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type28 0
              (local.get $0)
             )
             (i32.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type28 0
                (local.get $0)
               )
               (i32.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type28 0
                  (local.get $0)
                 )
                 (i32.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type28 0
                    (local.get $0)
                   )
                   (i32.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type28 0
                      (local.get $0)
                     )
                     (i32.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type28 0
                        (local.get $0)
                       )
                       (i32.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type28 0
                          (local.get $0)
                         )
                         (i32.const 10)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type39)
                           (local.get $0)
                          )
                         )
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (ref.cast (ref $type40)
                           (local.get $0)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.ne
      (struct.get $type28 0
       (local.get $0)
      )
      (i32.const 11)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (if (result (ref $type40))
     (if (result i32)
      (local.tee $15
       (struct.get $type28 0
        (local.tee $1
         (struct.get $type40 1
          (ref.cast (ref $type40)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $15)
         (i32.const 1)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type28 0
            (local.get $1)
           )
           (i32.const 2)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type28 0
              (local.get $1)
             )
             (i32.const 3)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type28 0
                (local.get $1)
               )
               (i32.const 4)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (i32.const 5)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type28 0
                    (local.get $1)
                   )
                   (i32.const 6)
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (if
                    (i32.ne
                     (local.tee $15
                      (struct.get $type28 0
                       (local.get $1)
                      )
                     )
                     (i32.const 7)
                    )
                    (then
                     (if
                      (i32.and
                       (i32.ne
                        (local.get $15)
                        (i32.const 8)
                       )
                       (i32.ne
                        (local.get $15)
                        (i32.const 9)
                       )
                      )
                      (then
                       (if
                        (i32.eq
                         (local.get $15)
                         (i32.const 10)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type39)
                           (local.get $1)
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type40)
                           (local.get $1)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (local.set $6
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (global.get $ready212)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (ref.as_non_null
        (global.get $global212)
       )
      )
      (if
       (i32.ne
        (struct.get $type28 0
         (local.get $0)
        )
        (i32.const 11)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global191)
       )
      )
      (struct.new $type40
       (i32.const 11)
       (local.get $6)
       (call $function55
        (local.get $7)
        (struct.get $type40 2
         (ref.cast (ref $type40)
          (local.get $0)
         )
        )
       )
      )
     )
     (else
      (if
       (i32.ne
        (struct.get $type28 0
         (local.get $0)
        )
        (i32.const 11)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global160)
       )
      )
      (if (result (ref $type40))
       (if (result i32)
        (local.tee $15
         (struct.get $type28 0
          (local.tee $1
           (struct.get $type40 1
            (ref.cast (ref $type40)
             (local.get $0)
            )
           )
          )
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $15)
           (i32.const 1)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type28 0
              (local.get $1)
             )
             (i32.const 2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type28 0
                (local.get $1)
               )
               (i32.const 3)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (i32.const 4)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type28 0
                    (local.get $1)
                   )
                   (i32.const 5)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type28 0
                      (local.get $1)
                     )
                     (i32.const 6)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type28 0
                        (local.get $1)
                       )
                       (i32.const 7)
                      )
                      (then
                       (i32.const 1)
                      )
                      (else
                       (if
                        (i32.and
                         (i32.ne
                          (local.tee $15
                           (struct.get $type28 0
                            (local.get $1)
                           )
                          )
                          (i32.const 8)
                         )
                         (i32.ne
                          (local.get $15)
                          (i32.const 9)
                         )
                        )
                        (then
                         (if
                          (i32.eq
                           (local.get $15)
                           (i32.const 10)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type39)
                             (local.get $1)
                            )
                           )
                          )
                          (else
                           (drop
                            (ref.cast (ref $type40)
                             (local.get $1)
                            )
                           )
                          )
                         )
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (local.set $8
         (ref.as_non_null
          (global.get $global119)
         )
        )
        (if
         (i32.eqz
          (global.get $ready212)
         )
         (then
          (unreachable)
         )
        )
        (local.set $7
         (ref.as_non_null
          (global.get $global212)
         )
        )
        (if
         (i32.ne
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global191)
         )
        )
        (struct.new $type40
         (i32.const 11)
         (local.get $8)
         (call $function55
          (local.get $7)
          (struct.get $type40 2
           (ref.cast (ref $type40)
            (local.get $0)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.ne
          (struct.get $type28 0
           (local.get $0)
          )
          (i32.const 11)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global166)
         )
        )
        (if (result (ref $type40))
         (if (result i32)
          (local.tee $15
           (struct.get $type28 0
            (local.tee $1
             (struct.get $type40 1
              (ref.cast (ref $type40)
               (local.get $0)
              )
             )
            )
           )
          )
          (then
           (if (result i32)
            (i32.eq
             (local.get $15)
             (i32.const 1)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i32.eq
               (struct.get $type28 0
                (local.get $1)
               )
               (i32.const 2)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (i32.const 3)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type28 0
                    (local.get $1)
                   )
                   (i32.const 4)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type28 0
                      (local.get $1)
                     )
                     (i32.const 5)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type28 0
                        (local.get $1)
                       )
                       (i32.const 6)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type28 0
                          (local.get $1)
                         )
                         (i32.const 7)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i32.eq
                           (struct.get $type28 0
                            (local.get $1)
                           )
                           (i32.const 8)
                          )
                          (then
                           (i32.const 1)
                          )
                          (else
                           (if
                            (i32.ne
                             (local.tee $15
                              (struct.get $type28 0
                               (local.get $1)
                              )
                             )
                             (i32.const 9)
                            )
                            (then
                             (if
                              (i32.eq
                               (local.get $15)
                               (i32.const 10)
                              )
                              (then
                               (drop
                                (ref.cast (ref $type39)
                                 (local.get $1)
                                )
                               )
                              )
                              (else
                               (drop
                                (ref.cast (ref $type40)
                                 (local.get $1)
                                )
                               )
                              )
                             )
                            )
                           )
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (local.set $9
           (ref.as_non_null
            (global.get $global120)
           )
          )
          (local.set $6
           (ref.as_non_null
            (global.get $global118)
           )
          )
          (if
           (i32.ne
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global191)
           )
          )
          (local.set $0
           (call $function55
            (struct.new $type42
             (ref.func $function70)
            )
            (struct.get $type40 2
             (local.tee $11
              (ref.cast (ref $type40)
               (local.get $0)
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global182)
           )
          )
          (struct.new $type40
           (i32.const 11)
           (local.get $9)
           (struct.new $type40
            (i32.const 11)
            (local.get $11)
            (struct.new $type40
             (i32.const 11)
             (struct.new $type40
              (i32.const 11)
              (local.get $6)
              (local.get $0)
             )
             (ref.as_non_null
              (global.get $global114)
             )
            )
           )
          )
         )
         (else
          (if
           (i32.ne
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.const 11)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global172)
           )
          )
          (if (result (ref $type40))
           (if (result i32)
            (local.tee $15
             (struct.get $type28 0
              (local.tee $1
               (struct.get $type40 1
                (ref.cast (ref $type40)
                 (local.get $0)
                )
               )
              )
             )
            )
            (then
             (if (result i32)
              (i32.eq
               (local.get $15)
               (i32.const 1)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i32.eq
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (i32.const 2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i32.eq
                   (struct.get $type28 0
                    (local.get $1)
                   )
                   (i32.const 3)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i32.eq
                     (struct.get $type28 0
                      (local.get $1)
                     )
                     (i32.const 4)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (i32.eq
                       (struct.get $type28 0
                        (local.get $1)
                       )
                       (i32.const 5)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i32.eq
                         (struct.get $type28 0
                          (local.get $1)
                         )
                         (i32.const 6)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i32.eq
                           (struct.get $type28 0
                            (local.get $1)
                           )
                           (i32.const 7)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if (result i32)
                            (i32.eq
                             (struct.get $type28 0
                              (local.get $1)
                             )
                             (i32.const 8)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (i32.eq
                               (struct.get $type28 0
                                (local.get $1)
                               )
                               (i32.const 9)
                              )
                              (then
                               (i32.const 1)
                              )
                              (else
                               (if
                                (i32.eq
                                 (struct.get $type28 0
                                  (local.get $1)
                                 )
                                 (i32.const 10)
                                )
                                (then
                                 (drop
                                  (ref.cast (ref $type39)
                                   (local.get $1)
                                  )
                                 )
                                )
                                (else
                                 (drop
                                  (ref.cast (ref $type40)
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (i32.const 0)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (local.set $8
             (ref.as_non_null
              (global.get $global119)
             )
            )
            (local.set $13
             (ref.as_non_null
              (global.get $global121)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global178)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $1
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (call $function69
              (block (result (ref $type28))
               (local.set $scratch
                (struct.get $type40 1
                 (ref.cast (ref $type40)
                  (local.get $1)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready212)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global212)
                )
               )
               (local.get $scratch)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global182)
             )
            )
            (local.set $14
             (ref.as_non_null
              (global.get $global121)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global178)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $5
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $5
             (struct.get $type40 1
              (ref.cast (ref $type40)
               (local.get $5)
              )
             )
            )
            (local.set $9
             (ref.as_non_null
              (global.get $global120)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global180)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $2
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $2
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $2)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type40 1
              (ref.cast (ref $type40)
               (local.get $2)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global180)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $3
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $3
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type40 1
              (ref.cast (ref $type40)
               (local.get $3)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global180)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $4
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.ne
              (struct.get $type28 0
               (local.tee $4
                (struct.get $type40 2
                 (ref.cast (ref $type40)
                  (local.get $4)
                 )
                )
               )
              )
              (i32.const 11)
             )
             (then
              (unreachable)
             )
            )
            (local.set $0
             (call $function69
              (block (result (ref $type28))
               (local.set $scratch_17
                (struct.get $type40 1
                 (ref.cast (ref $type40)
                  (local.get $4)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready212)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global180)
                )
               )
               (if
                (i32.ne
                 (struct.get $type28 0
                  (local.get $0)
                 )
                 (i32.const 11)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.ne
                 (struct.get $type28 0
                  (local.tee $0
                   (struct.get $type40 2
                    (ref.cast (ref $type40)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 11)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.ne
                 (struct.get $type28 0
                  (local.tee $0
                   (struct.get $type40 2
                    (ref.cast (ref $type40)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 11)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global212)
                )
               )
               (local.set $12
                (struct.new $type40
                 (i32.const 11)
                 (local.get $13)
                 (struct.new $type40
                  (i32.const 11)
                  (local.get $1)
                  (struct.new $type40
                   (i32.const 11)
                   (struct.get $type40 1
                    (ref.cast (ref $type40)
                     (local.get $0)
                    )
                   )
                   (ref.as_non_null
                    (global.get $global114)
                   )
                  )
                 )
                )
               )
               (local.get $scratch_17)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global186)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global182)
             )
            )
            (struct.new $type40
             (i32.const 11)
             (local.get $8)
             (struct.new $type40
              (i32.const 11)
              (local.get $12)
              (struct.new $type40
               (i32.const 11)
               (struct.new $type40
                (i32.const 11)
                (local.get $14)
                (struct.new $type40
                 (i32.const 11)
                 (local.get $5)
                 (struct.new $type40
                  (i32.const 11)
                  (struct.new $type40
                   (i32.const 11)
                   (local.get $9)
                   (struct.new $type40
                    (i32.const 11)
                    (local.get $2)
                    (struct.new $type40
                     (i32.const 11)
                     (local.get $3)
                     (struct.new $type40
                      (i32.const 11)
                      (local.get $0)
                      (local.tee $10
                       (ref.as_non_null
                        (global.get $global114)
                       )
                      )
                     )
                    )
                   )
                  )
                  (local.get $10)
                 )
                )
               )
               (local.get $10)
              )
             )
            )
           )
           (else
            (unreachable)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (ref.as_non_null
     (select (result (ref null $type39))
      (global.get $global123)
      (global.get $global122)
      (if (result i32)
       (local.tee $15
        (struct.get $type28 0
         (local.get $0)
        )
       )
       (then
        (if (result i32)
         (i32.eq
          (local.get $15)
          (i32.const 1)
         )
         (then
          (i32.const 0)
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type28 0
               (local.get $0)
              )
              (i32.const 3)
             )
             (then
              (i32.const 1)
             )
             (else
              (if
               (i32.and
                (i32.ne
                 (local.tee $15
                  (struct.get $type28 0
                   (local.get $0)
                  )
                 )
                 (i32.const 4)
                )
                (i32.ne
                 (local.get $15)
                 (i32.const 5)
                )
               )
               (then
                (if
                 (i32.and
                  (i32.ne
                   (local.get $15)
                   (i32.const 6)
                  )
                  (i32.ne
                   (local.get $15)
                   (i32.const 7)
                  )
                 )
                 (then
                  (if
                   (i32.and
                    (i32.ne
                     (local.get $15)
                     (i32.const 8)
                    )
                    (i32.ne
                     (local.get $15)
                     (i32.const 9)
                    )
                   )
                   (then
                    (if
                     (i32.eq
                      (local.get $15)
                      (i32.const 10)
                     )
                     (then
                      (drop
                       (ref.cast (ref $type39)
                        (local.get $0)
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.cast (ref $type40)
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (i32.const 0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function70 (type $call42) (param $0 (ref $type28)) (result (ref $type28))
  (local $1 (ref $type38))
  (local $2 (ref $type28))
  (local.set $1
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i32.eqz
    (global.get $ready212)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global212)
   )
  )
  (local.set $2
   (call $function69
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (struct.new $type40
   (i32.const 11)
   (local.get $1)
   (struct.new $type40
    (i32.const 11)
    (local.get $2)
    (struct.new $type40
     (i32.const 11)
     (local.get $0)
     (ref.as_non_null
      (global.get $global114)
     )
    )
   )
  )
 )
 (func $function73 (type $call51) (param $0 (ref null $environment73)) (param $1 i64) (param $2 (ref $type28)) (result (ref $type28))
  (local $3 i64)
  (local $scratch (ref $type28))
  (if (result (ref $type28))
   (i64.gt_s
    (struct.get $environment73 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type51 1
      (global.get $global222)
     )
    )
    (drop
     (struct.get $environment73 0
      (local.get $0)
     )
    )
    (local.set $2
     (call $function69
      (block (result (ref $type28))
       (local.set $scratch
        (ref.as_non_null
         (global.get $global215)
        )
       )
       (if
        (i32.eqz
         (call $foreign2)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global212)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (struct.get $environment73 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (struct.get $type51 1
      (struct.get $type58 1
       (struct.get $environment73 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function74 (type $call51) (param $0 (ref null $environment73)) (param $1 i64) (param $2 (ref $type28)) (result (ref $type28))
  (if (result (ref $type28))
   (call $foreign2)
   (then
    (local.get $2)
   )
   (else
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type58))
  (local $2 (ref $type29))
  (local $3 (ref $type51))
  (local $4 (ref $type28))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready217)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type58 1
   (local.tee $1
    (struct.new_default $type58)
   )
   (struct.new $type51
    (ref.func $function73)
    (struct.new $environment73
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type58 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type58 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function56
     (call_ref $call51
      (struct.get $type51 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type58 1
          (local.get $1)
         )
        )
       )
      )
      (i64.const 0)
      (local.get $2)
      (struct.get $type51 0
       (local.get $3)
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global194)
       )
      )
      (ref.as_non_null
       (global.get $global216)
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (local $0 (ref $type48))
  (local $1 (ref $type28))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global112
   (global.get $empty29)
  )
  (global.set $global113
   (global.get $empty30)
  )
  (global.set $global114
   (global.get $empty31)
  )
  (global.set $global115
   (global.get $empty32)
  )
  (global.set $global116
   (global.get $empty33)
  )
  (global.set $global117
   (global.get $empty34)
  )
  (global.set $global118
   (global.get $empty35)
  )
  (global.set $global119
   (global.get $empty36)
  )
  (global.set $global120
   (global.get $empty37)
  )
  (global.set $global121
   (global.get $empty38)
  )
  (global.set $global122
   (struct.new $type39
    (i32.const 10)
    (i64.const 0)
   )
  )
  (global.set $global123
   (struct.new $type39
    (i32.const 10)
    (i64.const 1)
   )
  )
  (global.set $global124
   (struct.new_default $type41)
  )
  (global.set $global130
   (struct.new_default $type41)
  )
  (global.set $global136
   (struct.new_default $type41)
  )
  (global.set $global154
   (struct.new_default $type41)
  )
  (global.set $global160
   (struct.new_default $type41)
  )
  (global.set $global166
   (struct.new_default $type41)
  )
  (global.set $global172
   (struct.new_default $type41)
  )
  (global.set $global178
   (struct.new $type42
    (ref.func $function51)
   )
  )
  (global.set $global180
   (struct.new $type42
    (ref.func $function52)
   )
  )
  (global.set $global182
   (struct.new_default $type43)
  )
  (global.set $global186
   (struct.new_default $type44)
  )
  (global.set $global191
   (struct.new_default $type45)
  )
  (global.set $ready191
   (i32.const 1)
  )
  (global.set $global194
   (struct.new_default $type46)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global198
   (struct.new_default $type47)
  )
  (global.set $global202
   (struct.new_default $type49)
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global205
   (struct.new_default $type50)
  )
  (global.set $ready205
   (i32.const 1)
  )
  (global.set $global222
   (struct.new $type51
    (ref.func $function74)
    (ref.null none)
   )
  )
  (global.set $global212
   (struct.new $type42
    (ref.func $function69)
   )
  )
  (global.set $ready212
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global202)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (local.set $1
   (call $function62
    (i32.const 0)
    (local.tee $0
     (struct.new_default $type48)
    )
   )
  )
  (global.set $global215
   (if (result (ref $type28))
    (i64.eq
     (struct.get $type48 0
      (local.get $0)
     )
     (call $foreign1
      (i32.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (unreachable)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready202)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global202)
   )
  )
  (if
   (i32.eqz
    (global.get $ready205)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global205)
   )
  )
  (local.set $1
   (call $function62
    (i32.const 1)
    (local.tee $0
     (struct.new_default $type48)
    )
   )
  )
  (global.set $global216
   (if (result (ref $type28))
    (i64.eq
     (struct.get $type48 0
      (local.get $0)
     )
     (call $foreign1
      (i32.const 1)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $global217
   (struct.new_default $type52)
  )
  (global.set $ready217
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

