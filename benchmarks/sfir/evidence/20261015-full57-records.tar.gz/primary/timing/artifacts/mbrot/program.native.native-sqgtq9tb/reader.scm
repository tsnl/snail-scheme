(module
 (rec
  (type $type43 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $environment59 (struct (field i64) (field (ref $type43))))
  (type $call27 (func (param (ref null $environment59) i64 i64) (result i64)))
  (type $call39 (func (param (ref $environment54) f64 f64 i64) (result i64)))
  (type $type39 (struct (field (ref $environment54))))
  (type $environment54 (struct (field f64) (field f64) (field (ref $type41))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type39)))))
  (type $environment49 (struct (field (ref $type30)) (field (ref $type36)) (field i64) (field (ref $type36))))
  (type $environment47 (struct (field (ref $type30)) (field i64) (field (ref $type36))))
  (type $type34 (struct (field (ref $call34)) (field (ref struct))))
  (type $type36 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $type31 (array (mut i64)))
  (type $type30 (array (mut (ref $type31))))
  (type $environment44 (struct (field i64) (field (ref $type30)) (field (ref $type36))))
  (type $call34 (func (param (ref struct) i64) (result i32)))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment59))))
 )
 (type $19 (func (param i64) (result i64)))
 (type $20 (func (param i32) (result i64)))
 (type $21 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global145 (mut (ref null $type27)) (ref.null none))
 (global $global121 (mut (ref null $type28)) (ref.null none))
 (global $global111 (mut (ref null $type29)) (ref.null none))
 (global $global106 (mut (ref null $type32)) (ref.null none))
 (global $global139 (mut i64) (i64.const 0))
 (global $global140 (mut (ref null $type32)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function44 (type $call34) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment44))
  (local $3 (ref $type30))
  (local $4 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (array.set $type30
     (struct.get $environment44 1
      (local.tee $2
       (ref.cast (ref $environment44)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment44 0
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (array.new_default $type31
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment44 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type34 1
      (struct.get $type36 1
       (struct.get $environment44 2
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function47 (type $call34) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type36))
  (local $3 (ref $environment47))
  (local $4 (ref $type34))
  (local $5 i64)
  (local $6 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $6
     (i64.sub
      (local.tee $5
       (struct.get $environment47 1
        (ref.cast (ref $environment47)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.get $6)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 1
     (local.tee $2
      (struct.new_default $type36)
     )
     (struct.new $type34
      (ref.func $function49)
      (struct.new $environment49
       (struct.get $environment47 0
        (local.tee $3
         (ref.cast (ref $environment47)
          (local.get $0)
         )
        )
       )
       (struct.get $environment47 2
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type36 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call34
     (struct.get $type34 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type36 1
         (local.get $2)
        )
       )
      )
     )
     (local.get $6)
     (struct.get $type34 0
      (local.get $4)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function49 (type $call34) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $type41))
  (local $8 (ref $environment49))
  (local $9 (ref $type31))
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type31
     (array.get $type30
      (struct.get $environment49 0
       (local.tee $8
        (ref.cast (ref $environment49)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (block (result i32)
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.mul
            (local.tee $5
             (f64.convert_i64_s
              (local.get $1)
             )
            )
            (f64.const 0.005)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $5)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $5
           (f64.add
            (local.get $4)
            (f64.const -1.0)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.mul
            (local.tee $6
             (f64.convert_i64_s
              (local.tee $2
               (struct.get $environment49 2
                (local.get $8)
               )
              )
             )
            )
            (f64.const 0.005)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $6)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $6
           (f64.add
            (local.get $4)
            (f64.const -0.5)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type41 1
       (local.tee $7
        (struct.new_default $type41)
       )
       (struct.new $type39
        (struct.new $environment54
         (local.get $5)
         (local.get $6)
         (local.get $7)
        )
       )
      )
      (struct.set $type41 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function54
        (struct.get $type39 0
         (struct.get $type41 1
          (local.get $7)
         )
        )
        (local.get $5)
        (local.get $6)
        (i64.const 0)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment49 3
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type34 1
      (struct.get $type36 1
       (struct.get $environment49 3
        (local.get $8)
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (local.set $2
     (i64.sub
      (local.tee $1
       (struct.get $environment49 2
        (ref.cast (ref $environment49)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment49 1
        (ref.cast (ref $environment49)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (struct.get $type34 1
      (struct.get $type36 1
       (struct.get $environment49 1
        (ref.cast (ref $environment49)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function54 (type $call39) (param $0 (ref $environment54)) (param $1 f64) (param $2 f64) (param $3 i64) (result i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 i32)
  (local $8 i64)
  (local $9 (ref $type41))
  (if (result i64)
   (i64.eq
    (local.get $3)
    (i64.const 64)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.and
      (i32.and
       (local.tee $7
        (f64.lt
         (f64.abs
          (local.get $1)
         )
         (f64.const inf)
        )
       )
       (local.get $7)
      )
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.mul
          (local.get $1)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (local.tee $7
        (f64.lt
         (f64.abs
          (local.get $2)
         )
         (f64.const inf)
        )
       )
       (local.get $7)
      )
      (f64.eq
       (f64.abs
        (local.tee $5
         (f64.mul
          (local.get $2)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $6
         (f64.add
          (local.get $4)
          (local.get $5)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (f64.gt
      (local.get $6)
      (f64.const 16.0)
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.sub
            (local.get $4)
            (local.get $5)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.tee $5
            (struct.get $environment54 0
             (local.get $0)
            )
           )
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.add
            (local.get $4)
            (local.get $5)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $1)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $2)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.tee $1
           (f64.mul
            (local.get $1)
            (local.get $2)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $2
           (f64.add
            (local.get $1)
            (local.get $1)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $1)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $2)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.tee $1
            (struct.get $environment54 1
             (local.get $0)
            )
           )
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.tee $1
           (f64.add
            (local.get $2)
            (local.get $1)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $8
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $8)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.tee $9
          (struct.get $environment54 2
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function54
       (struct.get $type39 0
        (struct.get $type41 1
         (local.get $9)
        )
       )
       (local.get $4)
       (local.get $1)
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call27) (param $0 (ref null $environment59)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type36))
  (local $4 (ref $type34))
  (local $5 (ref $type30))
  (local $6 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment59 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global145)
     )
    )
    (drop
     (struct.get $environment59 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global139)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 1
     (local.tee $3
      (struct.new_default $type36)
     )
     (struct.new $type34
      (ref.func $function44)
      (struct.new $environment44
       (local.get $1)
       (local.tee $5
        (array.new $type30
         (array.new_fixed $type31 0)
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type36 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call34
      (struct.get $type34 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type36 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $6)
      (struct.get $type34 0
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type36 1
     (local.tee $3
      (struct.new_default $type36)
     )
     (struct.new $type34
      (ref.func $function47)
      (struct.new $environment47
       (local.get $5)
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type36 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call34
      (struct.get $type34 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type36 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $6)
      (struct.get $type34 0
       (local.get $4)
      )
     )
    )
    (local.set $1
     (array.get $type31
      (array.get $type30
       (local.get $5)
       (i32.const 0)
      )
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment59 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type27 1
      (struct.get $type43 1
       (struct.get $environment59 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function60 (type $call27) (param $0 (ref null $environment59)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type43))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready140)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (struct.set $type43 1
   (local.tee $1
    (struct.new_default $type43)
   )
   (struct.new $type27
    (ref.func $function59)
    (struct.new $environment59
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type43 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type43 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type43 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global145
   (struct.new $type27
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $global121
   (struct.new_default $type28)
  )
  (global.set $global111
   (struct.new_default $type29)
  )
  (global.set $global106
   (struct.new_default $type32)
  )
  (global.set $global139
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global140
   (struct.new_default $type32)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

