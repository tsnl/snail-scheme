(module
 (rec
  (type $type33 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment46 (struct (field i64) (field (ref $type33))))
  (type $call0 (func (param (ref null $environment46) i64 f64) (result f64)))
  (type $type29 (struct (field (ref $environment43))))
  (type $type31 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $environment43 (struct (field (ref $type31))))
  (type $call29 (func (param (ref $environment43) f64 f64) (result f64)))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment46))))
 )
 (type $10 (func (param f64) (result f64)))
 (type $11 (func (param i32) (result f64)))
 (type $12 (func (param i64) (result f64)))
 (type $13 (func))
 (import "benchmark" "hide_f64" (func $foreign0 (param f64) (result f64)))
 (import "benchmark" "input_f64" (func $foreign1 (param i32) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type0)) (ref.null none))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global111 (mut f64) (f64.const 0.0))
 (global $global112 (mut (ref null $type28)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call29) (param $0 (ref $environment43)) (param $1 f64) (param $2 f64) (result f64)
  (local $3 f64)
  (if (result f64)
   (f64.lt
    (local.get $1)
    (f64.const 0.0)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.add
          (local.get $1)
          (f64.const -1.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $1)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.add
          (local.get $1)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type29 0
      (struct.get $type31 1
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
 )
 (func $function46 (type $call0) (param $0 (ref null $environment46)) (param $1 i64) (param $2 f64) (result f64)
  (local $3 (ref $type31))
  (local $4 i64)
  (if (result f64)
   (i64.gt_s
    (struct.get $environment46 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global117)
     )
    )
    (drop
     (struct.get $environment46 0
      (local.get $0)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global111)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (struct.set $type31 1
     (local.tee $3
      (struct.new_default $type31)
     )
     (struct.new $type29
      (struct.new $environment43
       (local.get $3)
      )
     )
    )
    (struct.set $type31 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function43
      (struct.get $type29 0
       (struct.get $type31 1
        (local.get $3)
       )
      )
      (local.get $2)
      (f64.const 0.0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type33 0
       (struct.get $environment46 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (struct.get $type0 1
      (struct.get $type33 1
       (struct.get $environment46 1
        (local.get $0)
       )
      )
     )
     (local.get $4)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function47 (type $call0) (param $0 (ref null $environment46)) (param $1 i64) (param $2 f64) (result f64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result f64)
  (local $1 (ref $type33))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type33 1
   (local.tee $1
    (struct.new_default $type33)
   )
   (struct.new $type0
    (ref.func $function46)
    (struct.new $environment46
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type33 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type33 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type33 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (f64.const 0.0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global117
   (struct.new $type0
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global111
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global112
   (struct.new_default $type28)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

