(module
 (rec
  (type $environment59 (struct (field i64) (field (ref $type43))))
  (type $call40 (func (param i64) (result i64)))
  (type $2 (func (param (ref $type13) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
  (type $environment54 (struct (field (ref $type45))))
  (type $type37 (struct (field (ref null $type12))))
  (type $type45 (struct (field (mut i32)) (field (mut (ref null $type38)))))
  (type $call38 (func (param (ref null $environment54) i64 i64) (result i32)))
  (type $7 (func (param (ref null $type13) i32 i32 i32 (ref null $type12) i64) (result (ref $type13))))
  (type $8 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $call11 (func (param (ref $type12)) (result (ref $type13))))
  (type $call34 (func (param (ref null $type12) (ref null $type12)) (result i32)))
  (type $type41 (struct (field (ref $call41)) (field (ref struct))))
  (type $type43 (struct (field (mut i32)) (field (mut (ref null $type41)))))
  (type $environment43 (struct (field (ref $type43))))
  (type $call41 (func (param (ref struct) i64 (ref null $type12)) (result (ref null $type12))))
  (type $type40 (struct))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $type39 (struct))
  (type $type38 (struct (field (ref $call38)) (field (ref null $environment54))))
  (type $type36 (struct (field (mut (ref null $type37)))))
  (type $type13 (array (mut i64)))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type11 (struct))
 )
 (type $28 (func (param i64) (result i64)))
 (type $29 (func (result i64)))
 (type $30 (func (param i32) (result i64)))
 (type $31 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type11)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type16)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type17)) (ref.null none))
 (global $global114 (mut (ref null $type32)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type33)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type34)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type35)) (ref.null none))
 (global $global113 (mut (ref null $type13)) (ref.null none))
 (global $global127 (mut (ref null $type13)) (ref.null none))
 (global $global128 (mut (ref null $type13)) (ref.null none))
 (global $global129 (mut (ref null $type13)) (ref.null none))
 (global $global130 (mut (ref null $type13)) (ref.null none))
 (global $global131 (mut (ref null $type36)) (ref.null none))
 (global $global132 (mut (ref null $type38)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type39)) (ref.null none))
 (global $global147 (mut i64) (i64.const 0))
 (global $global148 (mut i64) (i64.const 0))
 (global $global149 (mut (ref null $type12)) (ref.null none))
 (global $global150 (mut (ref null $type40)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call41) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (local $3 i64)
  (local $4 i64)
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $foreign1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type41 1
      (struct.get $type43 1
       (struct.get $environment43 0
        (ref.cast (ref $environment43)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type12
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function44 (type $call34) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result i32)
  (local $scratch (ref null $type12))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (then
        (return_call $function44
         (struct.get $type12 1
          (local.get $0)
         )
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready110)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global110)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function46 (type $call11) (param $0 (ref $type12)) (result (ref $type13))
  (local $1 (ref null $type12))
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready119)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (if
   (i64.gt_u
    (local.tee $2
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type12 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $1
          (struct.get $type12 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type12 1
             (local.get $1)
            )
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 5)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 6)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $1
                        (struct.get $type12 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $1
                          (struct.get $type12 1
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $1
                            (struct.get $type12 1
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $1
                              (struct.get $type12 1
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $1
                                (struct.get $type12 1
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (call $function48
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type12 1
                                 (local.get $1)
                                )
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function49
   (array.new $type13
    (struct.get $type12 0
     (local.get $0)
    )
    (i32.wrap_i64
     (local.get $2)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function48 (type $8) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function48
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function49 (type $7) (param $0 (ref null $type13)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type13))
  (local $6 i64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $6)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function50 (type $call38) (param $0 (ref null $environment54)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 (ref $type45))
  (local $5 (ref $type36))
  (local $6 (ref $type13))
  (local $7 (ref null $type12))
  (local $8 (ref $type38))
  (local $scratch (ref null $type12))
  (if (result i32)
   (i64.eq
    (local.get $2)
    (i64.const 14)
   )
   (then
    (struct.set $type36 0
     (ref.as_non_null
      (global.get $global131)
     )
     (block (result (ref (exact $type37)))
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (struct.new $type37
       (block (result (ref null $type12))
        (local.set $scratch
         (struct.get $type12 1
          (call $function52
           (local.tee $6
            (ref.as_non_null
             (global.get $global127)
            )
           )
           (i32.const 0)
           (i32.const 1)
           (i64.extend_i32_u
            (array.len
             (local.get $6)
            )
           )
           (ref.null none)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global131)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
    (i32.const 1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (array.get $type13
        (global.get $global128)
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.eq
       (array.get $type13
        (global.get $global113)
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i64.const 1)
      )
      (then
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $3
          (array.get $type13
           (global.get $global129)
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (i64.eq
         (array.get $type13
          (global.get $global113)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i64.const 1)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $3
            (array.get $type13
             (global.get $global130)
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.eqz
          (array.get $type13
           (global.get $global113)
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (array.get $type13
          (global.get $global128)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $3)
       )
       (i64.const 0)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (array.get $type13
          (global.get $global129)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $3)
       )
       (i64.const 0)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (array.get $type13
          (global.get $global130)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $3)
       )
       (i64.const 1)
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global127)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $2)
          (local.tee $3
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type45 1
       (local.tee $4
        (struct.new_default $type45)
       )
       (struct.new $type38
        (ref.func $function54)
        (struct.new $environment54
         (local.get $4)
        )
       )
      )
      (struct.set $type45 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type45 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call38
        (struct.get $type38 1
         (local.tee $8
          (ref.as_non_null
           (struct.get $type45 1
            (local.get $4)
           )
          )
         )
        )
        (i64.const 0)
        (local.get $3)
        (struct.get $type38 0
         (local.get $8)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (array.get $type13
          (global.get $global128)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $2)
       )
       (i64.const 1)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (array.get $type13
          (global.get $global129)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $2)
       )
       (i64.const 1)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (array.get $type13
          (global.get $global130)
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type13
       (global.get $global113)
       (i32.wrap_i64
        (local.get $1)
       )
       (i64.const 0)
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function52 (type $2) (param $0 (ref $type13)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type12)) (result (ref null $type12))
  (local $5 i64)
  (local $6 i64)
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type13
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (struct.new $type12
      (local.get $3)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function54 (type $call38) (param $0 (ref null $environment54)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i32)
  (if (result i32)
   (if (result i32)
    (local.tee $4
     (i64.eq
      (local.get $1)
      (i64.const 36)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready132)
      )
      (then
       (unreachable)
      )
     )
     (call $function50
      (struct.get $type38 1
       (global.get $global132)
      )
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type45 0
       (struct.get $environment54 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type38 1
      (struct.get $type45 1
       (struct.get $environment54 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function57 (type $call40) (param $0 i64) (result i64)
  (local $1 (ref null $type12))
  (local $2 (ref null $type12))
  (local $3 (ref $type43))
  (local $4 (ref $type41))
  (local $scratch (ref null $type12))
  (struct.set $type43 1
   (local.tee $3
    (struct.new_default $type43)
   )
   (struct.new $type41
    (ref.func $function59)
    (struct.new $environment59
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type43 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type43 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call41
    (struct.get $type41 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type43 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type41 0
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (local.set $1
   (global.get $global149)
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (ref.is_null
       (local.get $1)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type12 0
           (local.get $2)
          )
          (struct.get $type12 0
           (local.get $1)
          )
         )
         (then
          (local.set $2
           (struct.get $type12 1
            (local.get $2)
           )
          )
          (local.set $1
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready110)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global110)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.is_null
             (local.get $1)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type12 0
                 (local.get $2)
                )
                (struct.get $type12 0
                 (local.get $1)
                )
               )
               (then
                (local.set $2
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.get $type12 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready110)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global110)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.is_null
                   (local.get $1)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type12 0
                       (local.get $2)
                      )
                      (struct.get $type12 0
                       (local.get $1)
                      )
                     )
                     (then
                      (local.set $2
                       (struct.get $type12 1
                        (local.get $2)
                       )
                      )
                      (local.set $1
                       (struct.get $type12 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready110)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global110)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.is_null
                         (local.get $1)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type12 0
                             (local.get $2)
                            )
                            (struct.get $type12 0
                             (local.get $1)
                            )
                           )
                           (then
                            (local.set $2
                             (struct.get $type12 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.get $type12 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready110)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global110)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.is_null
                               (local.get $1)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type12 0
                                   (local.get $2)
                                  )
                                  (struct.get $type12 0
                                   (local.get $1)
                                  )
                                 )
                                 (then
                                  (local.set $2
                                   (struct.get $type12 1
                                    (local.get $2)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type12 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready110)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global110)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type12 0
                                         (local.get $2)
                                        )
                                        (struct.get $type12 0
                                         (local.get $1)
                                        )
                                       )
                                       (then
                                        (local.set $2
                                         (struct.get $type12 1
                                          (local.get $2)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type12 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready110)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global110)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type12 0
                                               (local.get $2)
                                              )
                                              (struct.get $type12 0
                                               (local.get $1)
                                              )
                                             )
                                             (then
                                              (local.set $2
                                               (struct.get $type12 1
                                                (local.get $2)
                                               )
                                              )
                                              (local.set $1
                                               (struct.get $type12 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready110)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global110)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type12 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type12 0
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $2
                                                     (struct.get $type12 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (local.set $1
                                                     (struct.get $type12 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready110)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global110)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type12 0
                                                           (local.get $2)
                                                          )
                                                          (struct.get $type12 0
                                                           (local.get $1)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $2
                                                           (struct.get $type12 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (local.set $1
                                                           (struct.get $type12 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready110)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global110)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type12 0
                                                                 (local.get $2)
                                                                )
                                                                (struct.get $type12 0
                                                                 (local.get $1)
                                                                )
                                                               )
                                                               (then
                                                                (local.set $2
                                                                 (struct.get $type12 1
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (local.set $1
                                                                 (struct.get $type12 1
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready110)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global110)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (ref.is_null
                                                                  (local.get $2)
                                                                 )
                                                                 (then
                                                                  (ref.is_null
                                                                   (local.get $1)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (if (result i32)
                                                                   (ref.is_null
                                                                    (local.get $1)
                                                                   )
                                                                   (then
                                                                    (i32.const 0)
                                                                   )
                                                                   (else
                                                                    (if (result i32)
                                                                     (i64.eq
                                                                      (struct.get $type12 0
                                                                       (local.get $2)
                                                                      )
                                                                      (struct.get $type12 0
                                                                       (local.get $1)
                                                                      )
                                                                     )
                                                                     (then
                                                                      (local.set $2
                                                                       (struct.get $type12 1
                                                                        (local.get $2)
                                                                       )
                                                                      )
                                                                      (local.set $1
                                                                       (struct.get $type12 1
                                                                        (local.get $1)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (global.get $ready110)
                                                                       )
                                                                       (then
                                                                        (unreachable)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global110)
                                                                       )
                                                                      )
                                                                      (if (result i32)
                                                                       (ref.is_null
                                                                        (local.get $2)
                                                                       )
                                                                       (then
                                                                        (ref.is_null
                                                                         (local.get $1)
                                                                        )
                                                                       )
                                                                       (else
                                                                        (if (result i32)
                                                                         (ref.is_null
                                                                          (local.get $1)
                                                                         )
                                                                         (then
                                                                          (i32.const 0)
                                                                         )
                                                                         (else
                                                                          (if (result i32)
                                                                           (i64.eq
                                                                            (struct.get $type12 0
                                                                             (local.get $2)
                                                                            )
                                                                            (struct.get $type12 0
                                                                             (local.get $1)
                                                                            )
                                                                           )
                                                                           (then
                                                                            (local.set $2
                                                                             (struct.get $type12 1
                                                                              (local.get $2)
                                                                             )
                                                                            )
                                                                            (local.set $1
                                                                             (struct.get $type12 1
                                                                              (local.get $1)
                                                                             )
                                                                            )
                                                                            (if
                                                                             (i32.eqz
                                                                              (global.get $ready110)
                                                                             )
                                                                             (then
                                                                              (unreachable)
                                                                             )
                                                                            )
                                                                            (drop
                                                                             (ref.as_non_null
                                                                              (global.get $global110)
                                                                             )
                                                                            )
                                                                            (if (result i32)
                                                                             (ref.is_null
                                                                              (local.get $2)
                                                                             )
                                                                             (then
                                                                              (ref.is_null
                                                                               (local.get $1)
                                                                              )
                                                                             )
                                                                             (else
                                                                              (if (result i32)
                                                                               (ref.is_null
                                                                                (local.get $1)
                                                                               )
                                                                               (then
                                                                                (i32.const 0)
                                                                               )
                                                                               (else
                                                                                (if (result i32)
                                                                                 (i64.eq
                                                                                  (struct.get $type12 0
                                                                                   (local.get $2)
                                                                                  )
                                                                                  (struct.get $type12 0
                                                                                   (local.get $1)
                                                                                  )
                                                                                 )
                                                                                 (then
                                                                                  (local.set $2
                                                                                   (struct.get $type12 1
                                                                                    (local.get $2)
                                                                                   )
                                                                                  )
                                                                                  (local.set $1
                                                                                   (struct.get $type12 1
                                                                                    (local.get $1)
                                                                                   )
                                                                                  )
                                                                                  (if
                                                                                   (i32.eqz
                                                                                    (global.get $ready110)
                                                                                   )
                                                                                   (then
                                                                                    (unreachable)
                                                                                   )
                                                                                  )
                                                                                  (drop
                                                                                   (ref.as_non_null
                                                                                    (global.get $global110)
                                                                                   )
                                                                                  )
                                                                                  (if (result i32)
                                                                                   (ref.is_null
                                                                                    (local.get $2)
                                                                                   )
                                                                                   (then
                                                                                    (ref.is_null
                                                                                     (local.get $1)
                                                                                    )
                                                                                   )
                                                                                   (else
                                                                                    (if (result i32)
                                                                                     (ref.is_null
                                                                                      (local.get $1)
                                                                                     )
                                                                                     (then
                                                                                      (i32.const 0)
                                                                                     )
                                                                                     (else
                                                                                      (if (result i32)
                                                                                       (i64.eq
                                                                                        (struct.get $type12 0
                                                                                         (local.get $2)
                                                                                        )
                                                                                        (struct.get $type12 0
                                                                                         (local.get $1)
                                                                                        )
                                                                                       )
                                                                                       (then
                                                                                        (local.set $2
                                                                                         (struct.get $type12 1
                                                                                          (local.get $2)
                                                                                         )
                                                                                        )
                                                                                        (local.set $1
                                                                                         (struct.get $type12 1
                                                                                          (local.get $1)
                                                                                         )
                                                                                        )
                                                                                        (if
                                                                                         (i32.eqz
                                                                                          (global.get $ready110)
                                                                                         )
                                                                                         (then
                                                                                          (unreachable)
                                                                                         )
                                                                                        )
                                                                                        (drop
                                                                                         (ref.as_non_null
                                                                                          (global.get $global110)
                                                                                         )
                                                                                        )
                                                                                        (if (result i32)
                                                                                         (ref.is_null
                                                                                          (local.get $2)
                                                                                         )
                                                                                         (then
                                                                                          (ref.is_null
                                                                                           (local.get $1)
                                                                                          )
                                                                                         )
                                                                                         (else
                                                                                          (if (result i32)
                                                                                           (ref.is_null
                                                                                            (local.get $1)
                                                                                           )
                                                                                           (then
                                                                                            (i32.const 0)
                                                                                           )
                                                                                           (else
                                                                                            (if (result i32)
                                                                                             (i64.eq
                                                                                              (struct.get $type12 0
                                                                                               (local.get $2)
                                                                                              )
                                                                                              (struct.get $type12 0
                                                                                               (local.get $1)
                                                                                              )
                                                                                             )
                                                                                             (then
                                                                                              (call $function44
                                                                                               (struct.get $type12 1
                                                                                                (local.get $2)
                                                                                               )
                                                                                               (block (result (ref null $type12))
                                                                                                (local.set $scratch
                                                                                                 (struct.get $type12 1
                                                                                                  (local.get $1)
                                                                                                 )
                                                                                                )
                                                                                                (if
                                                                                                 (i32.eqz
                                                                                                  (global.get $ready110)
                                                                                                 )
                                                                                                 (then
                                                                                                  (unreachable)
                                                                                                 )
                                                                                                )
                                                                                                (drop
                                                                                                 (ref.as_non_null
                                                                                                  (global.get $global110)
                                                                                                 )
                                                                                                )
                                                                                                (local.get $scratch)
                                                                                               )
                                                                                              )
                                                                                             )
                                                                                             (else
                                                                                              (i32.const 0)
                                                                                             )
                                                                                            )
                                                                                           )
                                                                                          )
                                                                                         )
                                                                                        )
                                                                                       )
                                                                                       (else
                                                                                        (i32.const 0)
                                                                                       )
                                                                                      )
                                                                                     )
                                                                                    )
                                                                                   )
                                                                                  )
                                                                                 )
                                                                                 (else
                                                                                  (i32.const 0)
                                                                                 )
                                                                                )
                                                                               )
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                           (else
                                                                            (i32.const 0)
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                     (else
                                                                      (i32.const 0)
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function59 (type $call41) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $environment59))
  (if (result (ref null $type12))
   (i64.gt_s
    (struct.get $environment59 0
     (ref.cast (ref $environment59)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (ref.cast (ref $environment59)
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (local.set $1
     (call $foreign2
      (global.get $global147)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (local.set $4
     (call $foreign2
      (global.get $global148)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type36 0
     (global.get $global131)
     (ref.null none)
    )
    (drop
     (call $function50
      (struct.get $type38 1
       (global.get $global132)
      )
      (local.get $1)
      (local.get $4)
     )
    )
    (local.set $2
     (struct.get $type37 0
      (struct.get $type36 0
       (global.get $global131)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment59 1
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type41 1
      (struct.get $type43 1
       (struct.get $environment59 1
        (local.get $5)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (return_call $function57
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type43))
  (local $1 (ref $type41))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type11)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type16)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type17)
  )
  (global.set $global114
   (struct.new_default $type32)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type33)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type34)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type35)
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global113
   (call $function46
    (struct.new $type12
     (i64.const 1)
     (struct.new $type12
      (i64.const 1)
      (struct.new $type12
       (i64.const 1)
       (struct.new $type12
        (i64.const 1)
        (struct.new $type12
         (i64.const 1)
         (struct.new $type12
          (i64.const 0)
          (struct.new $type12
           (i64.const 1)
           (struct.new $type12
            (i64.const 1)
            (struct.new $type12
             (i64.const 1)
             (struct.new $type12
              (i64.const 1)
              (struct.new $type12
               (i64.const 1)
               (struct.new $type12
                (i64.const 1)
                (struct.new $type12
                 (i64.const 1)
                 (struct.new $type12
                  (i64.const 1)
                  (struct.new $type12
                   (i64.const 1)
                   (struct.new $type12
                    (i64.const 1)
                    (ref.null none)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global127
   (call $function46
    (struct.new $type12
     (i64.const 0)
     (struct.new $type12
      (i64.const 0)
      (struct.new $type12
       (i64.const 0)
       (struct.new $type12
        (i64.const 0)
        (struct.new $type12
         (i64.const 0)
         (struct.new $type12
          (i64.const 0)
          (struct.new $type12
           (i64.const 0)
           (struct.new $type12
            (i64.const 0)
            (struct.new $type12
             (i64.const 0)
             (struct.new $type12
              (i64.const 0)
              (struct.new $type12
               (i64.const 0)
               (struct.new $type12
                (i64.const 0)
                (struct.new $type12
                 (i64.const 0)
                 (struct.new_default $type12)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global128
   (call $function46
    (struct.new $type12
     (i64.const 1)
     (struct.new $type12
      (i64.const 2)
      (struct.new $type12
       (i64.const 4)
       (struct.new $type12
        (i64.const 3)
        (struct.new $type12
         (i64.const 5)
         (struct.new $type12
          (i64.const 6)
          (struct.new $type12
           (i64.const 1)
           (struct.new $type12
            (i64.const 3)
            (struct.new $type12
             (i64.const 6)
             (struct.new $type12
              (i64.const 2)
              (struct.new $type12
               (i64.const 5)
               (struct.new $type12
                (i64.const 4)
                (struct.new $type12
                 (i64.const 11)
                 (struct.new $type12
                  (i64.const 12)
                  (struct.new $type12
                   (i64.const 13)
                   (struct.new $type12
                    (i64.const 7)
                    (struct.new $type12
                     (i64.const 8)
                     (struct.new $type12
                      (i64.const 4)
                      (struct.new $type12
                       (i64.const 4)
                       (struct.new $type12
                        (i64.const 7)
                        (struct.new $type12
                         (i64.const 11)
                         (struct.new $type12
                          (i64.const 8)
                          (struct.new $type12
                           (i64.const 12)
                           (struct.new $type12
                            (i64.const 13)
                            (struct.new $type12
                             (i64.const 6)
                             (struct.new $type12
                              (i64.const 10)
                              (struct.new $type12
                               (i64.const 15)
                               (struct.new $type12
                                (i64.const 9)
                                (struct.new $type12
                                 (i64.const 14)
                                 (struct.new $type12
                                  (i64.const 13)
                                  (struct.new $type12
                                   (i64.const 13)
                                   (struct.new $type12
                                    (i64.const 14)
                                    (struct.new $type12
                                     (i64.const 15)
                                     (struct.new $type12
                                      (i64.const 9)
                                      (struct.new $type12
                                       (i64.const 10)
                                       (struct.new $type12
                                        (i64.const 6)
                                        (struct.new $type12
                                         (i64.const 6)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global129
   (call $function46
    (struct.new $type12
     (i64.const 2)
     (struct.new $type12
      (i64.const 4)
      (struct.new $type12
       (i64.const 7)
       (struct.new $type12
        (i64.const 5)
        (struct.new $type12
         (i64.const 8)
         (struct.new $type12
          (i64.const 9)
          (struct.new $type12
           (i64.const 3)
           (struct.new $type12
            (i64.const 6)
            (struct.new $type12
             (i64.const 10)
             (struct.new $type12
              (i64.const 5)
              (struct.new $type12
               (i64.const 9)
               (struct.new $type12
                (i64.const 8)
                (struct.new $type12
                 (i64.const 12)
                 (struct.new $type12
                  (i64.const 13)
                  (struct.new $type12
                   (i64.const 14)
                   (struct.new $type12
                    (i64.const 8)
                    (struct.new $type12
                     (i64.const 9)
                     (struct.new $type12
                      (i64.const 5)
                      (struct.new $type12
                       (i64.const 2)
                       (struct.new $type12
                        (i64.const 4)
                        (struct.new $type12
                         (i64.const 7)
                         (struct.new $type12
                          (i64.const 5)
                          (struct.new $type12
                           (i64.const 8)
                           (struct.new $type12
                            (i64.const 9)
                            (struct.new $type12
                             (i64.const 3)
                             (struct.new $type12
                              (i64.const 6)
                              (struct.new $type12
                               (i64.const 10)
                               (struct.new $type12
                                (i64.const 5)
                                (struct.new $type12
                                 (i64.const 9)
                                 (struct.new $type12
                                  (i64.const 8)
                                  (struct.new $type12
                                   (i64.const 12)
                                   (struct.new $type12
                                    (i64.const 13)
                                    (struct.new $type12
                                     (i64.const 14)
                                     (struct.new $type12
                                      (i64.const 8)
                                      (struct.new $type12
                                       (i64.const 9)
                                       (struct.new $type12
                                        (i64.const 5)
                                        (struct.new $type12
                                         (i64.const 5)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (global.set $global130
   (call $function46
    (struct.new $type12
     (i64.const 4)
     (struct.new $type12
      (i64.const 7)
      (struct.new $type12
       (i64.const 11)
       (struct.new $type12
        (i64.const 8)
        (struct.new $type12
         (i64.const 12)
         (struct.new $type12
          (i64.const 13)
          (struct.new $type12
           (i64.const 6)
           (struct.new $type12
            (i64.const 10)
            (struct.new $type12
             (i64.const 15)
             (struct.new $type12
              (i64.const 9)
              (struct.new $type12
               (i64.const 14)
               (struct.new $type12
                (i64.const 13)
                (struct.new $type12
                 (i64.const 13)
                 (struct.new $type12
                  (i64.const 14)
                  (struct.new $type12
                   (i64.const 15)
                   (struct.new $type12
                    (i64.const 9)
                    (struct.new $type12
                     (i64.const 10)
                     (struct.new $type12
                      (i64.const 6)
                      (struct.new $type12
                       (i64.const 1)
                       (struct.new $type12
                        (i64.const 2)
                        (struct.new $type12
                         (i64.const 4)
                         (struct.new $type12
                          (i64.const 3)
                          (struct.new $type12
                           (i64.const 5)
                           (struct.new $type12
                            (i64.const 6)
                            (struct.new $type12
                             (i64.const 1)
                             (struct.new $type12
                              (i64.const 3)
                              (struct.new $type12
                               (i64.const 6)
                               (struct.new $type12
                                (i64.const 2)
                                (struct.new $type12
                                 (i64.const 5)
                                 (struct.new $type12
                                  (i64.const 4)
                                  (struct.new $type12
                                   (i64.const 11)
                                   (struct.new $type12
                                    (i64.const 12)
                                    (struct.new $type12
                                     (i64.const 13)
                                     (struct.new $type12
                                      (i64.const 7)
                                      (struct.new $type12
                                       (i64.const 8)
                                       (struct.new $type12
                                        (i64.const 4)
                                        (struct.new $type12
                                         (i64.const 4)
                                         (ref.null none)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $global131
   (struct.new_default $type36)
  )
  (global.set $global132
   (struct.new $type38
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type39)
  )
  (global.set $global147
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $global148
   (call $foreign3
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (local.set $2
   (call $foreign0)
  )
  (struct.set $type43 1
   (local.tee $0
    (struct.new_default $type43)
   )
   (struct.new $type41
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
    )
   )
  )
  (struct.set $type43 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type43 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global149
   (call_ref $call41
    (struct.get $type41 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type43 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type41 0
     (local.get $1)
    )
   )
  )
  (global.set $global150
   (struct.new_default $type40)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

