(module
 (rec
  (type $call85 (func (param (ref null $type80) (ref null $type80)) (result i32)))
  (type $call84 (func (param i64 i64 i64) (result (ref null $type80))))
  (type $type106 (struct (field (ref $environment198))))
  (type $type108 (struct (field (mut i32)) (field (mut (ref null $type106)))))
  (type $environment198 (struct (field i64) (field (ref $type108))))
  (type $call106 (func (param (ref $environment198) i64 (ref null $type80)) (result i64)))
  (type $type104 (struct (field (ref $environment195))))
  (type $type105 (struct (field (mut i32)) (field (mut (ref null $type104)))))
  (type $environment195 (struct (field (ref $type105))))
  (type $call104 (func (param (ref $environment195) i64) (result (ref null $type80))))
  (type $call100 (func (param (ref $environment193) (ref null $type80)) (result i32)))
  (type $type100 (struct (field (ref $environment193))))
  (type $type102 (struct (field (mut i32)) (field (mut (ref null $type100)))))
  (type $environment193 (struct (field (ref $type102))))
  (type $14 (func (param (ref null $type80))))
  (type $call97 (func (param (ref $environment189) i64) (result i32)))
  (type $type97 (struct (field (ref $environment189))))
  (type $environment189 (struct (field (ref $type16)) (field (ref $type99))))
  (type $type12 (struct))
  (type $type99 (struct (field (mut i32)) (field (mut (ref null $type97)))))
  (type $call86 (func (param (ref $type29)) (result i32)))
  (type $environment185 (struct (field i64) (field i64) (field (ref $type16)) (field (ref $type95))))
  (type $type95 (struct (field (mut i32)) (field (mut (ref null $type38)))))
  (type $23 (func (param (ref $type29) (ref $type29)) (result (ref $type80))))
  (type $24 (func (param (ref $type29) i32 i32 (ref $type29)) (result (ref $type29))))
  (type $25 (func (param i32 i32 (ref $type29) (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $26 (func (param (ref $type29)) (result (ref $type29))))
  (type $call66 (func (param (ref $type16) i64 (ref null $type63) i64) (result i32)))
  (type $28 (func (param (ref $type16) i32 i32 i64 i64 i64) (result i32)))
  (type $29 (func (param i32 i32 (ref null $type63) i64) (result i64)))
  (type $call64 (func (param (ref null $type63)) (result i64)))
  (type $31 (func (param i32 i32 (ref $type14) (ref $type63)) (result (ref null $type63))))
  (type $type63 (struct (field i64) (field (ref null $type63))))
  (type $call62 (func (param (ref $type14)) (result (ref null $type63))))
  (type $34 (func (param (ref $type16) i32 i64 i32 i32 i32 i64 (ref $type29)) (result (ref $type29))))
  (type $35 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $36 (func (param (ref $type16) i64 i32 i32 i64 i64) (result i64)))
  (type $type53 (struct (field (ref $type29)) (field (ref $type29))))
  (type $38 (func (param (ref $type29) (ref $type29)) (result (ref $type53))))
  (type $39 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $40 (func (param (ref $type14) (ref $type14) i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $41 (func (param (ref $type14) (ref $type14) i64 i64 i32 i64 i32 i32 i32 i64 i64) (result i64)))
  (type $42 (func (param (ref $type14) (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $call48 (func (param (ref $type14) (ref $type14)) (result i64)))
  (type $44 (func (param (ref $type14) i64 i64 i32 (ref $type14) i32 i32 i32 i64 i64) (result (ref $type14))))
  (type $45 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i32 i64) (result (ref $type14))))
  (type $46 (func (param (ref $type14) (ref $type14) i64 i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $47 (func (param (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $48 (func (param (ref $type14) (ref $type14) i64 i32 (ref $type14) i32 i32 i32 i64 i64) (result (ref $type14))))
  (type $call42 (func (param (ref $type29) (ref $type29)) (result i32)))
  (type $call41 (func (param (ref $type29) (ref $type29)) (result i64)))
  (type $51 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i64)))
  (type $52 (func (param i32 i32 (ref $type14) i32 i32 i32 i64 i64) (result (ref $type29))))
  (type $call38 (func (param (ref null $environment185) i64) (result (ref $type29))))
  (type $54 (func (param i32 i32 i64 i64) (result i64)))
  (type $call37 (func (param i64) (result i64)))
  (type $call13 (func (param (ref $type14)) (result (ref $type14))))
  (type $type14 (array (mut i32)))
  (type $58 (func (param (ref $type14) i32 i32 i64) (result i64)))
  (type $59 (func (param (ref $type16) i32 i32 i32 (ref null $type12) i64) (result (ref $type16))))
  (type $type16 (struct (field i32) (field (ref $type17)) (field (ref null $type18))))
  (type $type17 (array (mut i32)))
  (type $type18 (array (mut (ref null $type17))))
  (type $63 (func (param i32) (result (ref $type16))))
  (type $type10 (struct))
  (type $type89 (struct (field (mut (ref null $type80)))))
  (type $type80 (struct (field (ref $type29)) (field (ref null $type80))))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct))
  (type $type79 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type38 (struct (field (ref $call38)) (field (ref null $environment185))))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field i32) (field (ref $type14))))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $114 (func (param i64) (result i64)))
 (type $115 (func))
 (type $116 (func (param i64 i64) (result i32)))
 (type $117 (func (param i32)))
 (type $118 (func (result i64)))
 (type $119 (func (param i32) (result i64)))
 (import "benchmark" "expected_length" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "expected_character" (func $foreign1 (param i64 i64) (result i32)))
 (import "benchmark" "emit_character" (func $foreign2 (param i32)))
 (import "benchmark" "expected_count" (func $foreign3 (result i64)))
 (import "benchmark" "hide_i64" (func $foreign4 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign5 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $global391 (mut (ref null $type13)) (ref.null none))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $global63 (mut (ref null $type19)) (ref.null none))
 (global $global65 (mut (ref null $type20)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global108 (mut (ref null $type29)) (ref.null none))
 (global $global109 (mut (ref null $type30)) (ref.null none))
 (global $global112 (mut (ref null $type31)) (ref.null none))
 (global $global116 (mut (ref null $type32)) (ref.null none))
 (global $global118 (mut (ref null $type33)) (ref.null none))
 (global $global122 (mut (ref null $type13)) (ref.null none))
 (global $global126 (mut (ref null $type34)) (ref.null none))
 (global $global130 (mut (ref null $type35)) (ref.null none))
 (global $global132 (mut (ref null $type36)) (ref.null none))
 (global $global134 (mut (ref null $type36)) (ref.null none))
 (global $global136 (mut (ref null $type37)) (ref.null none))
 (global $global141 (mut (ref null $type38)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type40)) (ref.null none))
 (global $global171 (mut (ref null $type41)) (ref.null none))
 (global $global175 (mut (ref null $type42)) (ref.null none))
 (global $global187 (mut (ref null $type42)) (ref.null none))
 (global $global190 (mut (ref null $type30)) (ref.null none))
 (global $global193 (mut (ref null $type43)) (ref.null none))
 (global $global202 (mut (ref null $type43)) (ref.null none))
 (global $global211 (mut (ref null $type44)) (ref.null none))
 (global $global215 (mut (ref null $type45)) (ref.null none))
 (global $global222 (mut (ref null $type45)) (ref.null none))
 (global $global225 (mut (ref null $type46)) (ref.null none))
 (global $global236 (mut (ref null $type43)) (ref.null none))
 (global $global242 (mut (ref null $type45)) (ref.null none))
 (global $global245 (mut (ref null $type47)) (ref.null none))
 (global $global254 (mut (ref null $type48)) (ref.null none))
 (global $global262 (mut (ref null $type48)) (ref.null none))
 (global $global274 (mut (ref null $type49)) (ref.null none))
 (global $global286 (mut (ref null $type50)) (ref.null none))
 (global $global295 (mut (ref null $type48)) (ref.null none))
 (global $global300 (mut (ref null $type51)) (ref.null none))
 (global $global306 (mut (ref null $type52)) (ref.null none))
 (global $global315 (mut (ref null $type54)) (ref.null none))
 (global $global324 (mut (ref null $type54)) (ref.null none))
 (global $global330 (mut (ref null $type45)) (ref.null none))
 (global $global336 (mut (ref null $type55)) (ref.null none))
 (global $global344 (mut (ref null $type56)) (ref.null none))
 (global $global350 (mut (ref null $type57)) (ref.null none))
 (global $global361 (mut (ref null $type58)) (ref.null none))
 (global $global385 (mut (ref null $type62)) (ref.null none))
 (global $global395 (mut (ref null $type37)) (ref.null none))
 (global $global400 (mut (ref null $type64)) (ref.null none))
 (global $global405 (mut (ref null $type65)) (ref.null none))
 (global $global414 (mut (ref null $type66)) (ref.null none))
 (global $ready414 (mut i32) (i32.const 0))
 (global $global419 (mut (ref null $type67)) (ref.null none))
 (global $global425 (mut (ref null $type36)) (ref.null none))
 (global $global429 (mut (ref null $type45)) (ref.null none))
 (global $ready429 (mut i32) (i32.const 0))
 (global $global440 (mut (ref null $type68)) (ref.null none))
 (global $global443 (mut (ref null $type37)) (ref.null none))
 (global $global448 (mut (ref null $type36)) (ref.null none))
 (global $global456 (mut (ref null $type36)) (ref.null none))
 (global $global567 (mut (ref null $type79)) (ref.null none))
 (global $global573 (mut (ref null $type81)) (ref.null none))
 (global $global576 (mut (ref null $type81)) (ref.null none))
 (global $global553 (mut (ref null $type82)) (ref.null none))
 (global $global556 (mut (ref null $type38)) (ref.null none))
 (global $global558 (mut (ref null $type29)) (ref.null none))
 (global $global559 (mut (ref null $type29)) (ref.null none))
 (global $global560 (mut (ref null $type29)) (ref.null none))
 (global $global561 (mut (ref null $type29)) (ref.null none))
 (global $global562 (mut (ref null $type29)) (ref.null none))
 (global $global563 (mut (ref null $type83)) (ref.null none))
 (global $ready563 (mut i32) (i32.const 0))
 (global $global582 (mut (ref null $type38)) (ref.null none))
 (global $global621 (mut (ref null $type84)) (ref.null none))
 (global $ready621 (mut i32) (i32.const 0))
 (global $global590 (mut (ref null $type38)) (ref.null none))
 (global $global625 (mut (ref null $type85)) (ref.null none))
 (global $ready625 (mut i32) (i32.const 0))
 (global $global596 (mut (ref null $type86)) (ref.null none))
 (global $global603 (mut (ref null $type87)) (ref.null none))
 (global $global609 (mut i64) (i64.const 0))
 (global $global610 (mut i64) (i64.const 0))
 (global $global611 (mut i64) (i64.const 0))
 (global $global612 (mut (ref null $type80)) (ref.null none))
 (global $global615 (mut (ref null $type89)) (ref.null none))
 (global $global616 (mut (ref null $type37)) (ref.null none))
 (global $ready616 (mut i32) (i32.const 0))
 (global $global628 (mut (ref null $type10)) (ref.null none))
 (global $ready628 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "observe" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $63) (param $0 i32) (result (ref $type16))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type18))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type18
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type18
      (local.get $5)
      (local.get $2)
      (array.new_default $type17
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type16
   (local.get $0)
   (array.new_default $type17
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $function30 (type $59) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type16))
  (local $6 i32)
  (local $7 i64)
  (if (result (ref $type16))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (local.get $4)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 1
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 2
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (i32.const 48)
    )
    (drop
     (ref.as_non_null
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (ref.null none)
     (local.get $7)
    )
   )
  )
 )
 (func $function45 (type $58) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $4
          (i64.sub
           (local.get $3)
           (i64.const 1)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.get $4)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (i64.extend_i32_s
       (array.get $type14
        (local.get $0)
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function46 (type $call13) (param $0 (ref $type14)) (result (ref $type14))
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.tee $1
     (call $function45
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.tee $2
       (i64.extend_i32_u
        (array.len
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.tee $4
      (array.new_default $type14
       (local.tee $3
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (i32.const 0)
     (local.get $0)
     (i32.const 0)
     (local.get $3)
    )
    (local.get $4)
   )
  )
 )
 (func $function51 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function52
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function52 (type $54) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 1073741824)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function53 (type $call38) (param $0 (ref null $environment185)) (param $1 i64) (result (ref $type29))
  (local $2 i64)
  (local $3 i32)
  (return_call $function54
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (block (result i32)
    (drop
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $1)
         (local.tee $2
          (i64.sub
           (i64.const 0)
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (local.get $2)
      )
     )
    )
    (local.set $2
     (call $function51
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.const 1)
   )
   (array.new_default $type14
    (i32.wrap_i64
     (local.get $2)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (local.get $1)
   (i64.const 0)
  )
 )
 (func $function54 (type $52) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type29))
  (local $8 i64)
  (local $9 i64)
  (if (result (ref $type29))
   (i64.eqz
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $0)
       (local.get $2)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (local.tee $8
        (i64.sub
         (i64.const 0)
         (local.tee $9
          (i64.rem_s
           (local.get $6)
           (i64.const 1073741824)
          )
         )
        )
       )
       (local.get $9)
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (local.get $8)
      (i64.extend32_s
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $2)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 1073741824)
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function58 (type $51) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (if (result i64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.extend_i32_s
      (array.get $type14
       (local.get $0)
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (local.get $5)
     )
     (then
      (i64.const -1)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.get $5)
        (local.get $6)
       )
       (then
        (i64.const 1)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $4)
              (i64.const 1)
             )
            )
            (local.get $4)
           )
           (i64.xor
            (local.get $4)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function58
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $5)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call41) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (i32.ne
      (local.tee $4
       (struct.get $type29 0
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (struct.get $type29 0
       (local.get $1)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $2
     (if (result i64)
      (i64.lt_s
       (local.tee $2
        (i64.extend_i32_u
         (array.len
          (local.tee $5
           (struct.get $type29 1
            (local.get $0)
           )
          )
         )
        )
       )
       (local.tee $3
        (i64.extend_i32_u
         (array.len
          (local.tee $6
           (struct.get $type29 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (if (result i64)
        (i64.gt_s
         (local.get $2)
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (call $function58
          (local.get $5)
          (local.get $6)
          (i32.const 0)
          (i32.const 1)
          (local.get $2)
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (local.get $4)
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $2)
         (local.tee $3
          (i64.sub
           (i64.const 0)
           (local.get $2)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $3)
     )
     (else
      (local.get $2)
     )
    )
   )
   (else
    (select
     (i64.const -1)
     (i64.const 1)
     (struct.get $type29 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function60 (type $call42) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i32)
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (i64.eqz
   (call $function59
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $function67 (type $48) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 (ref $type14)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type14))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (if (result i64)
          (i64.gt_s
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (local.get $8)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (if
            (i64.gt_u
             (local.get $8)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i64.extend_i32_s
            (array.get $type14
             (local.get $0)
             (i32.wrap_i64
              (local.get $8)
             )
            )
           )
          )
          (else
           (i64.const 0)
          )
         )
        )
        (local.tee $10
         (i64.add
          (local.tee $11
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global109)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type14
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $11)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $11)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function69 (type $48) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 (ref $type14)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type14))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
        )
        (local.tee $11
         (i64.sub
          (local.get $10)
          (local.tee $12
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global109)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type14
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.sub
          (local.get $11)
          (local.get $9)
         )
        )
        (local.get $11)
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (if (result i64)
         (i64.lt_s
          (local.get $10)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $10)
              (local.tee $9
               (i64.add
                (local.get $10)
                (i64.const 1073741824)
               )
              )
             )
             (i64.xor
              (local.get $9)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $9)
         )
         (else
          (local.get $10)
         )
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.extend_i32_u
      (i64.lt_s
       (local.get $10)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function71 (type $47) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $scratch (ref $type14))
  (local $scratch_8 (ref $type14))
  (local $scratch_9 (ref $type14))
  (local.set $2
   (struct.get $type29 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type29 1
    (local.get $1)
   )
  )
  (if (result (ref $type29))
   (select
    (local.tee $6
     (struct.get $type29 0
      (local.get $1)
     )
    )
    (i32.eqz
     (local.get $6)
    )
    (local.tee $6
     (struct.get $type29 0
      (local.get $0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global193)
     )
    )
    (local.set $4
     (i64.add
      (local.tee $5
       (select
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
        (i64.gt_s
         (local.get $4)
         (local.get $5)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.get $5)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type14))
           (local.set $scratch
            (call $function67
             (local.get $2)
             (local.get $3)
             (local.get $5)
             (i32.const 1)
             (array.new_default $type14
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $6)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (local.set $6
     (struct.get $type29 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if (result (ref $type29))
     (i64.lt_s
      (if (result i64)
       (i64.lt_s
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.get $4)
          (local.get $5)
         )
         (then
          (i64.const 1)
         )
         (else
          (call $function58
           (local.get $2)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (local.get $4)
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global202)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch_8
              (call $function69
               (local.get $3)
               (local.get $2)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type14)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (i32.eqz
          (local.get $6)
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global202)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch_9
              (call $function69
               (local.get $2)
               (local.get $3)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type14)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_9)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (local.get $6)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function74 (type $46) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $10)
          (local.tee $13
           (i64.extend_i32_s
            (array.get $type14
             (local.get $0)
             (i32.wrap_i64
              (local.get $12)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $11)
        (local.get $13)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function76 (type $45) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type14))
  (local $7 i64)
  (if (result (ref $type14))
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global225)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function74
      (local.get $2)
      (local.get $1)
      (local.get $6)
      (i64.extend_i32_s
       (array.get $type14
        (local.get $0)
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $7
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $7)
    )
   )
  )
 )
 (func $function77 (type $47) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 i32)
  (local $5 i64)
  (local $scratch (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type29 1
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global236)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (struct.get $type29 1
            (local.get $0)
           )
          )
         )
        )
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type29 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type14))
           (local.set $scratch
            (call $function76
             (local.get $2)
             (local.get $3)
             (array.new_default $type14
              (i32.wrap_i64
               (local.get $5)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (local.set $4
            (select
             (i32.eqz
              (local.tee $4
               (struct.get $type29 0
                (local.get $1)
               )
              )
             )
             (local.get $4)
             (struct.get $type29 0
              (local.get $0)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $4)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function79 (type $44) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type14)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type14))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.mul
      (local.get $1)
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $11)
         (local.get $1)
        )
        (local.get $10)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function80 (type $call48) (param $0 (ref $type14)) (param $1 (ref $type14)) (result i64)
  (return_call $function81
   (local.get $0)
   (local.get $1)
   (i64.const 1000000000)
   (i32.const 0)
   (i32.const 1)
   (i64.extend_i32_u
    (array.len
     (local.get $1)
    )
   )
   (i64.const 0)
  )
 )
 (func $function81 (type $42) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (local.get $6)
   )
   (else
    (if
     (i64.ne
      (i64.div_s
       (local.tee $7
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
       )
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $6
         (i64.add
          (local.get $7)
          (local.tee $8
           (i64.extend_i32_s
            (array.get $type14
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $8
        (i64.div_s
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.rem_s
      (local.get $6)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
     (local.get $5)
    )
   )
  )
 )
 (func $function83 (type $41) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i64) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i64) (param $10 i64) (result i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $10)
     (i64.const 1073741824)
    )
    (then
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.sub
           (local.get $3)
           (i64.const 2)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.get $11)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $13
      (i64.mul
       (local.tee $11
        (i64.extend_i32_s
         (array.get $type14
          (local.get $1)
          (i32.wrap_i64
           (local.get $11)
          )
         )
        )
       )
       (local.get $9)
      )
     )
     (if
      (i64.ne
       (local.get $11)
       (i64.const 0)
      )
      (then
       (if
        (i64.ne
         (i64.div_s
          (local.get $13)
          (local.get $11)
         )
         (local.get $9)
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (if
      (i64.ne
       (i64.div_s
        (local.tee $14
         (i64.shl
          (local.get $10)
          (i64.const 30)
         )
        )
        (i64.const 1073741824)
       )
       (local.get $10)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.add
           (local.get $2)
           (local.get $3)
          )
         )
         (local.get $2)
        )
        (i64.xor
         (local.get $3)
         (local.get $11)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $12
          (i64.sub
           (local.get $11)
           (i64.const 2)
          )
         )
         (local.get $11)
        )
        (i64.xor
         (local.get $11)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.get $12)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $14)
         (local.tee $11
          (i64.add
           (local.get $14)
           (local.tee $12
            (i64.extend_i32_s
             (array.get $type14
              (local.get $0)
              (i32.wrap_i64
               (local.get $12)
              )
             )
            )
           )
          )
         )
        )
        (i64.xor
         (local.get $11)
         (local.get $12)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (i64.lt_s
      (local.get $11)
      (local.get $13)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.sub
          (local.get $9)
          (i64.const 1)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $5)
          (local.get $10)
         )
        )
        (local.get $10)
       )
       (i64.xor
        (local.get $5)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $11)
     (local.get $9)
    )
   )
   (else
    (local.get $9)
   )
  )
 )
 (func $function85 (type $46) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.sub
      (local.tee $8
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.get $3)
       (i64.const -1)
      )
      (i64.gt_s
       (local.get $3)
       (i64.const 0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (if (result i64)
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.add
                (local.get $3)
                (i64.const 1073741824)
               )
              )
              (local.get $3)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $2)
         )
         (else
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i64.lt_s
     (local.get $3)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.sub
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
      (local.tee $12
       (i64.and
        (local.get $11)
        (i64.const 1073741823)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $10
        (if (result i64)
         (i64.lt_s
          (local.get $9)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $10
               (i64.add
                (local.get $9)
                (i64.const 1073741824)
               )
              )
              (local.get $9)
             )
             (i64.xor
              (local.get $10)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $10)
         )
         (else
          (local.get $9)
         )
        )
       )
      )
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $10)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $10
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $10)
     (i64.add
      (i64.extend_i32_u
       (i64.lt_s
        (local.get $9)
        (i64.const 0)
       )
      )
      (i64.shr_u
       (local.get $11)
       (i64.const 30)
      )
     )
    )
   )
  )
 )
 (func $function87 (type $40) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.add
      (local.get $8)
      (local.tee $3
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (i64.rem_s
         (local.get $2)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
        )
        (local.tee $9
         (i64.add
          (local.get $9)
          (local.tee $10
           (i64.extend_i32_s
            (array.get $type14
             (local.get $1)
             (i32.wrap_i64
              (local.get $7)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $10
         (i64.add
          (local.get $8)
          (local.get $9)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $8)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function90 (type $39) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $13
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global295)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global262)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.sub
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.extend_i32_s
      (array.get $type14
       (local.get $2)
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $6)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.shl
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (i64.const 30)
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.get $7)
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $12
         (i64.add
          (local.get $7)
          (local.tee $6
           (i64.extend_i32_s
            (array.get $type14
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_s
      (local.tee $8
       (i64.div_s
        (local.get $12)
        (local.get $11)
       )
      )
      (i64.const 1073741824)
     )
     (then
      (local.set $8
       (i64.const 1073741823)
      )
     )
    )
    (local.set $7
     (i64.mul
      (local.get $8)
      (local.get $11)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $7)
         (local.get $11)
        )
        (local.get $8)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $12)
          (local.get $7)
         )
        )
        (local.get $12)
       )
       (i64.xor
        (local.get $7)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function83
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $10)
      (i32.const 1)
      (local.get $11)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (local.get $8)
      (local.get $6)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global274)
     )
    )
    (if
     (call $function85
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $7)
      (local.tee $6
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global286)
       )
      )
      (drop
       (call $function87
        (local.get $1)
        (local.get $2)
        (local.get $9)
        (local.get $6)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
        (i64.const 0)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.sub
            (local.get $7)
            (i64.const 1)
           )
          )
          (local.get $7)
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (local.get $6)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.extend32_s
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $13)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $13)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function93 (type $38) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type53))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type53))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i32)
  (local $scratch (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type53))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global315)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $7
     (struct.get $type53 0
      (local.tee $9
       (if (result (ref $type53))
        (i64.lt_s
         (if (result i64)
          (i64.lt_s
           (local.tee $10
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (struct.get $type29 1
                (local.get $0)
               )
              )
             )
            )
           )
           (local.tee $11
            (i64.extend_i32_u
             (array.len
              (local.tee $3
               (struct.get $type29 1
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (if (result i64)
            (i64.gt_s
             (local.get $10)
             (local.get $11)
            )
            (then
             (i64.const 1)
            )
            (else
             (call $function58
              (local.get $2)
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $10)
             )
            )
           )
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global132)
          )
         )
         (struct.new $type53
          (ref.as_non_null
           (global.get $global108)
          )
          (if (result (ref $type29))
           (struct.get $type29 0
            (local.get $0)
           )
           (then
            (struct.new $type29
             (i32.const 0)
             (struct.get $type29 1
              (local.get $0)
             )
            )
           )
           (else
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type53))
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (i64.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global254)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (call $function81
             (local.tee $4
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
             (local.get $2)
             (i64.extend_i32_s
              (array.get $type14
               (local.get $3)
               (i32.const 0)
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type53
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $4)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type29
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (call $function53
             (struct.get $type38 1
              (global.get $global141)
             )
             (local.get $10)
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global306)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (i64.sub
               (local.tee $10
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $11
            (i64.add
             (local.tee $12
              (i64.extend_i32_s
               (array.get $type14
                (local.get $3)
                (i32.wrap_i64
                 (local.get $11)
                )
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $11)
               (local.get $12)
              )
              (i64.xor
               (local.get $11)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global245)
            )
           )
           (local.set $11
            (i64.div_s
             (i64.const 1073741824)
             (local.get $11)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (call $function79
             (local.get $2)
             (local.get $11)
             (local.get $12)
             (i32.const 1)
             (array.new_default $type14
              (i32.wrap_i64
               (local.get $13)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global245)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (call $function46
             (block (result (ref $type14))
              (local.set $scratch
               (call $function79
                (local.get $3)
                (local.get $11)
                (local.get $12)
                (i32.const 1)
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $13)
                 )
                )
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $12
                (i64.add
                 (local.tee $13
                  (i64.sub
                   (i64.extend_i32_u
                    (array.len
                     (local.get $2)
                    )
                   )
                   (local.get $10)
                  )
                 )
                 (i64.const 1)
                )
               )
               (local.get $13)
              )
              (i64.xor
               (local.get $12)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.get $12)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global300)
            )
           )
           (drop
            (call $function90
             (local.tee $6
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $12)
               )
              )
             )
             (local.get $5)
             (local.get $3)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $6)
              )
             )
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.copy $type14 $type14
            (local.tee $4
             (array.new_default $type14
              (local.tee $14
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
            )
            (i32.const 0)
            (local.get $5)
            (i32.const 0)
            (local.get $14)
           )
           (drop
            (ref.as_non_null
             (global.get $global254)
            )
           )
           (if
            (i64.ne
             (call $function81
              (local.get $4)
              (local.get $4)
              (local.get $11)
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $4)
               )
              )
              (i64.const 0)
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type53
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $6)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type29
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type29))
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.tee $2
                  (call $function46
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (then
               (ref.as_non_null
                (global.get $global108)
               )
              )
              (else
               (struct.new $type29
                (i32.const 0)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type53 1
      (local.get $9)
     )
    )
    (struct.new $type53
     (if (result (ref $type29))
      (select
       (i32.eqz
        (local.tee $14
         (struct.get $type29 0
          (local.get $1)
         )
        )
       )
       (local.get $14)
       (struct.get $type29 0
        (local.get $0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type29 1
            (local.get $7)
           )
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (struct.new $type29
          (i32.eqz
           (struct.get $type29 0
            (local.get $7)
           )
          )
          (struct.get $type29 1
           (local.get $7)
          )
         )
        )
       )
      )
      (else
       (local.get $7)
      )
     )
     (if (result (ref $type29))
      (struct.get $type29 0
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type29 1
            (local.get $8)
           )
          )
         )
        )
        (then
         (local.get $8)
        )
        (else
         (struct.new $type29
          (i32.eqz
           (struct.get $type29 0
            (local.get $8)
           )
          )
          (struct.get $type29 1
           (local.get $8)
          )
         )
        )
       )
      )
      (else
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function97 (type $36) (param $0 (ref $type16)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.tee $6
        (i64.sub
         (i64.extend_i32_u
          (array.get $type17
           (if (result (ref $type17))
            (i32.lt_u
             (local.tee $8
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type16 1
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type18
               (struct.get $type16 2
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $8)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $8)
            (i32.const 8191)
           )
          )
         )
         (i64.const 48)
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $6)
       (i64.const 9)
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $5)
        (i64.div_s
         (local.tee $4
          (i64.mul
           (local.get $5)
           (i64.const 10)
          )
         )
         (i64.const 10)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $5
           (i64.add
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (local.get $6)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function97
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
       (local.get $5)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function99 (type $35) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
    (if
     (i64.ne
      (local.get $0)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $0)
        )
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
 )
 (func $function101 (type $34) (param $0 (ref $type16)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref $type29)) (result (ref $type29))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 (ref $type14))
  (local $13 (ref $type29))
  (local $scratch (ref $type14))
  (local $scratch_15 (ref $type29))
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (if (result (ref $type29))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type29 1
           (local.get $7)
          )
         )
        )
       )
       (then
        (local.get $7)
       )
       (else
        (struct.new $type29
         (i32.eqz
          (struct.get $type29 0
           (local.get $7)
          )
         )
         (struct.get $type29 1
          (local.get $7)
         )
        )
       )
      )
     )
     (else
      (local.get $7)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $2)
          (local.get $6)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global344)
     )
    )
    (local.set $8
     (call $function99
      (i64.const 10)
      (i32.const 0)
      (i32.const 1)
      (local.tee $9
       (if (result i64)
        (i64.gt_s
         (local.get $9)
         (i64.const 9)
        )
        (then
         (i64.const 9)
        )
        (else
         (if
          (i32.eqz
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $9
              (i64.sub
               (local.get $2)
               (local.get $6)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (local.get $6)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.get $9)
        )
       )
      )
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global245)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (i64.add
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.tee $12
            (struct.get $type29 1
             (local.get $7)
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function71
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $12
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch
              (call $function79
               (local.get $12)
               (local.get $8)
               (local.get $10)
               (i32.const 1)
               (array.new_default $type14
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (i32.const 0)
         (local.get $12)
        )
       )
      )
      (block (result (ref $type29))
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
           (local.get $6)
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global336)
        )
       )
       (local.set $8
        (call $function97
         (local.get $0)
         (local.get $8)
         (i32.const 0)
         (i32.const 1)
         (local.get $6)
         (i64.const 0)
        )
       )
       (local.set $scratch_15
        (call $function53
         (struct.get $type38 1
          (global.get $global141)
         )
         (local.get $8)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $6)
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global215)
        )
       )
       (local.get $scratch_15)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $8)
     (local.get $7)
    )
   )
  )
 )
 (func $function107 (type $call62) (param $0 (ref $type14)) (result (ref null $type63))
  (local $1 (ref $type63))
  (local $2 (ref $type14))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global391)
   )
  )
  (if (result (ref null $type63))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $2
       (if (result (ref $type14))
        (i64.eqz
         (local.tee $3
          (i64.extend_i32_u
           (array.len
            (local.get $0)
           )
          )
         )
        )
        (then
         (array.new_fixed $type14 0)
        )
        (else
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (array.new $type14
           (array.get $type14
            (local.get $0)
            (i32.const 0)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.copy $type14 $type14
          (local.get $2)
          (i32.const 0)
          (local.get $0)
          (i32.const 0)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global254)
     )
    )
    (local.set $1
     (struct.new $type63
      (call $function81
       (local.get $2)
       (local.get $2)
       (i64.const 1000000000)
       (i32.const 0)
       (i32.const 1)
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
       (i64.const 0)
      )
      (block (result nullref)
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type63))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $0
         (call $function46
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global254)
       )
      )
      (local.set $1
       (struct.new $type63
        (call $function81
         (local.get $0)
         (local.get $0)
         (i64.const 1000000000)
         (i32.const 0)
         (i32.const 1)
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 0)
        )
        (block (result (ref $type63))
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (local.get $1)
        )
       )
      )
      (if (result (ref $type63))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $0
           (call $function46
            (local.get $0)
           )
          )
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global254)
         )
        )
        (local.set $1
         (struct.new $type63
          (call $function81
           (local.get $0)
           (local.get $0)
           (i64.const 1000000000)
           (i32.const 0)
           (i32.const 1)
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.const 0)
          )
          (block (result (ref $type63))
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $1)
          )
         )
        )
        (if (result (ref $type63))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $0
             (call $function46
              (local.get $0)
             )
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global254)
           )
          )
          (local.set $1
           (struct.new $type63
            (call $function81
             (local.get $0)
             (local.get $0)
             (i64.const 1000000000)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $0)
              )
             )
             (i64.const 0)
            )
            (block (result (ref $type63))
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $1)
            )
           )
          )
          (if (result (ref $type63))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (local.tee $0
               (call $function46
                (local.get $0)
               )
              )
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global254)
             )
            )
            (local.set $1
             (struct.new $type63
              (call $function81
               (local.get $0)
               (local.get $0)
               (i64.const 1000000000)
               (i32.const 0)
               (i32.const 1)
               (i64.extend_i32_u
                (array.len
                 (local.get $0)
                )
               )
               (i64.const 0)
              )
              (block (result (ref $type63))
               (drop
                (ref.as_non_null
                 (global.get $global122)
                )
               )
               (local.get $1)
              )
             )
            )
            (if (result (ref $type63))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $0
                 (call $function46
                  (local.get $0)
                 )
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global254)
               )
              )
              (local.set $1
               (struct.new $type63
                (call $function81
                 (local.get $0)
                 (local.get $0)
                 (i64.const 1000000000)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (array.len
                   (local.get $0)
                  )
                 )
                 (i64.const 0)
                )
                (block (result (ref $type63))
                 (drop
                  (ref.as_non_null
                   (global.get $global122)
                  )
                 )
                 (local.get $1)
                )
               )
              )
              (if (result (ref $type63))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (local.tee $0
                   (call $function46
                    (local.get $0)
                   )
                  )
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global254)
                 )
                )
                (local.set $1
                 (struct.new $type63
                  (call $function81
                   (local.get $0)
                   (local.get $0)
                   (i64.const 1000000000)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.extend_i32_u
                    (array.len
                     (local.get $0)
                    )
                   )
                   (i64.const 0)
                  )
                  (block (result (ref $type63))
                   (drop
                    (ref.as_non_null
                     (global.get $global122)
                    )
                   )
                   (local.get $1)
                  )
                 )
                )
                (if (result (ref $type63))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (local.tee $0
                     (call $function46
                      (local.get $0)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global254)
                   )
                  )
                  (local.set $1
                   (struct.new $type63
                    (call $function81
                     (local.get $0)
                     (local.get $0)
                     (i64.const 1000000000)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.extend_i32_u
                      (array.len
                       (local.get $0)
                      )
                     )
                     (i64.const 0)
                    )
                    (block (result (ref $type63))
                     (drop
                      (ref.as_non_null
                       (global.get $global122)
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (if (result (ref $type63))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (local.tee $0
                       (call $function46
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global254)
                     )
                    )
                    (local.set $1
                     (struct.new $type63
                      (call $function81
                       (local.get $0)
                       (local.get $0)
                       (i64.const 1000000000)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.extend_i32_u
                        (array.len
                         (local.get $0)
                        )
                       )
                       (i64.const 0)
                      )
                      (block (result (ref $type63))
                       (drop
                        (ref.as_non_null
                         (global.get $global122)
                        )
                       )
                       (local.get $1)
                      )
                     )
                    )
                    (if (result (ref $type63))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (local.tee $0
                         (call $function46
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global254)
                       )
                      )
                      (local.set $1
                       (struct.new $type63
                        (call $function81
                         (local.get $0)
                         (local.get $0)
                         (i64.const 1000000000)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.extend_i32_u
                          (array.len
                           (local.get $0)
                          )
                         )
                         (i64.const 0)
                        )
                        (block (result (ref $type63))
                         (drop
                          (ref.as_non_null
                           (global.get $global122)
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                      (if (result (ref $type63))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (local.tee $0
                           (call $function46
                            (local.get $0)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global254)
                         )
                        )
                        (local.set $1
                         (struct.new $type63
                          (call $function81
                           (local.get $0)
                           (local.get $0)
                           (i64.const 1000000000)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.extend_i32_u
                            (array.len
                             (local.get $0)
                            )
                           )
                           (i64.const 0)
                          )
                          (block (result (ref $type63))
                           (drop
                            (ref.as_non_null
                             (global.get $global122)
                            )
                           )
                           (local.get $1)
                          )
                         )
                        )
                        (if (result (ref $type63))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (local.tee $0
                             (call $function46
                              (local.get $0)
                             )
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global254)
                           )
                          )
                          (local.set $1
                           (struct.new $type63
                            (call $function81
                             (local.get $0)
                             (local.get $0)
                             (i64.const 1000000000)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.extend_i32_u
                              (array.len
                               (local.get $0)
                              )
                             )
                             (i64.const 0)
                            )
                            (block (result (ref $type63))
                             (drop
                              (ref.as_non_null
                               (global.get $global122)
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (if (result (ref $type63))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (local.tee $0
                               (call $function46
                                (local.get $0)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global254)
                             )
                            )
                            (local.set $1
                             (struct.new $type63
                              (call $function81
                               (local.get $0)
                               (local.get $0)
                               (i64.const 1000000000)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.extend_i32_u
                                (array.len
                                 (local.get $0)
                                )
                               )
                               (i64.const 0)
                              )
                              (block (result (ref $type63))
                               (drop
                                (ref.as_non_null
                                 (global.get $global122)
                                )
                               )
                               (local.get $1)
                              )
                             )
                            )
                            (if (result (ref $type63))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (local.tee $0
                                 (call $function46
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global254)
                               )
                              )
                              (local.set $1
                               (struct.new $type63
                                (call $function81
                                 (local.get $0)
                                 (local.get $0)
                                 (i64.const 1000000000)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.extend_i32_u
                                  (array.len
                                   (local.get $0)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (block (result (ref $type63))
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global122)
                                  )
                                 )
                                 (local.get $1)
                                )
                               )
                              )
                              (if (result (ref $type63))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (local.tee $0
                                   (call $function46
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global254)
                                 )
                                )
                                (local.set $3
                                 (call $function80
                                  (local.get $0)
                                  (local.get $0)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global122)
                                 )
                                )
                                (return_call $function108
                                 (i32.const 0)
                                 (i32.const 1)
                                 (call $function46
                                  (local.get $0)
                                 )
                                 (struct.new $type63
                                  (local.get $3)
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function108 (type $31) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 (ref $type63)) (result (ref null $type63))
  (local $4 i64)
  (if (result (ref $type63))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $2)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global254)
     )
    )
    (local.set $4
     (call $function80
      (local.get $2)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $2
     (call $function46
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function108
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (struct.new $type63
      (local.get $4)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function110 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $0)
    (i64.const 10)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const 10)
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i64.lt_s
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 10)
         )
        )
        (i64.const 10)
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i64.lt_s
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 10)
           )
          )
          (i64.const 10)
         )
         (then
          (i64.const 4)
         )
         (else
          (if (result i64)
           (i64.lt_s
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 10)
             )
            )
            (i64.const 10)
           )
           (then
            (i64.const 5)
           )
           (else
            (if (result i64)
             (i64.lt_s
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 10)
               )
              )
              (i64.const 10)
             )
             (then
              (i64.const 6)
             )
             (else
              (if (result i64)
               (i64.lt_s
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 10)
                 )
                )
                (i64.const 10)
               )
               (then
                (i64.const 7)
               )
               (else
                (if (result i64)
                 (i64.lt_s
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 10)
                   )
                  )
                  (i64.const 10)
                 )
                 (then
                  (i64.const 8)
                 )
                 (else
                  (if (result i64)
                   (i64.lt_s
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 10)
                     )
                    )
                    (i64.const 10)
                   )
                   (then
                    (i64.const 9)
                   )
                   (else
                    (if (result i64)
                     (i64.lt_s
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 10)
                       )
                      )
                      (i64.const 10)
                     )
                     (then
                      (i64.const 10)
                     )
                     (else
                      (if (result i64)
                       (i64.lt_s
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i64.const 11)
                       )
                       (else
                        (if (result i64)
                         (i64.lt_s
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 10)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (i64.const 12)
                         )
                         (else
                          (if (result i64)
                           (i64.lt_s
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 10)
                             )
                            )
                            (i64.const 10)
                           )
                           (then
                            (i64.const 13)
                           )
                           (else
                            (if (result i64)
                             (i64.lt_s
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 10)
                               )
                              )
                              (i64.const 10)
                             )
                             (then
                              (i64.const 14)
                             )
                             (else
                              (if (result i64)
                               (i64.lt_s
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                )
                                (i64.const 10)
                               )
                               (then
                                (i64.const 15)
                               )
                               (else
                                (return_call $function111
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                 (i64.const 16)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function111 (type $54) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.lt_s
    (local.get $2)
    (i64.const 10)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 10)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function112 (type $call64) (param $0 (ref null $type63)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type63 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type63 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type63 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type63 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type63 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type63 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type63 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type63 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type63 1
                        (local.get $0)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $0
                         (struct.get $type63 1
                          (local.get $0)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $0
                           (struct.get $type63 1
                            (local.get $0)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $0
                             (struct.get $type63 1
                              (local.get $0)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $0
                               (struct.get $type63 1
                                (local.get $0)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $0
                                 (struct.get $type63 1
                                  (local.get $0)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function113
                                 (i32.const 0)
                                 (i32.const 1)
                                 (struct.get $type63 1
                                  (local.get $0)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function113 (type $29) (param $0 i32) (param $1 i32) (param $2 (ref null $type63)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type63 1
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function113
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function115 (type $28) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (if (result i32)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.tee $8
           (i64.rem_s
            (local.get $5)
            (i64.const 10)
           )
          )
          (i64.const 48)
         )
        )
        (i64.const 48)
       )
       (i64.xor
        (local.get $6)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $6)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $6)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $9
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 1
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 2
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $9)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $9)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $6)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function115
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (local.get $3)
     (i64.div_s
      (local.get $5)
      (i64.const 10)
     )
    )
   )
  )
 )
 (func $function116 (type $call66) (param $0 (ref $type16)) (param $1 i64) (param $2 (ref null $type63)) (param $3 i64) (result i32)
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.add
          (local.get $1)
          (local.get $3)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global405)
     )
    )
    (drop
     (call $function115
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.get $4)
      (local.get $3)
      (struct.get $type63 0
       (local.get $2)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type63 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready414)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global414)
     )
    )
    (return_call $function116
     (local.get $0)
     (local.get $4)
     (local.get $2)
     (i64.const 9)
    )
   )
  )
 )
 (func $function118 (type $26) (param $0 (ref $type29)) (result (ref $type29))
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global254)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (i64.extend_i32_u
      (array.len
       (local.tee $1
        (struct.get $type29 1
         (local.get $0)
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function81
    (local.tee $2
     (array.new_default $type14
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (local.get $1)
    (i64.const 2)
    (i32.const 0)
    (i32.const 1)
    (i64.extend_i32_u
     (array.len
      (local.get $1)
     )
    )
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $1
       (call $function46
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (struct.new $type29
     (i32.const 0)
     (local.get $1)
    )
   )
  )
 )
 (func $function120 (type $25) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 (ref $type29)) (param $4 (ref $type29)) (result (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (i64.extend_i32_s
        (array.get $type14
         (struct.get $type29 1
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (i64.const 1)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global242)
       )
      )
      (local.set $4
       (call $function77
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global425)
     )
    )
    (local.set $5
     (call $function118
      (local.get $3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $5)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global242)
       )
      )
      (local.set $6
       (call $function77
        (local.get $2)
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function120
       (local.get $0)
       (local.get $1)
       (local.get $6)
       (local.get $5)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function122 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 2)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 2)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 2)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 2)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 2)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 2)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 2)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 2)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 2)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 2)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 2)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 2)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 2)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function123
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function123 (type $54) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function123
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 2)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function126 (type $24) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 (ref $type29)) (result (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global330)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global324)
   )
  )
  (local.set $5
   (struct.get $type53 0
    (call $function93
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (local.set $4
   (call $function118
    (block (result (ref $type29))
     (local.set $scratch
      (call $function71
       (local.get $3)
       (local.get $5)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global425)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global187)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (if (result (ref $type29))
   (i64.ge_s
    (call $function59
     (local.get $4)
     (local.get $3)
    )
    (i64.const 0)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function126
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function155 (type $call38) (param $0 (ref null $environment185)) (param $1 i64) (result (ref $type29))
  (local $2 f64)
  (local $3 f64)
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.div
        (local.tee $3
         (f64.convert_i64_s
          (local.get $1)
         )
        )
        (f64.const 14.181647462)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.add
        (local.get $2)
        (f64.const 2.0)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global553)
   )
  )
  (if
   (f64.lt
    (local.get $3)
    (local.tee $2
     (f64.trunc
      (local.get $3)
     )
    )
   )
   (then
    (if
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.add
          (local.get $2)
          (f64.const -1.0)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (return_call $function53
   (struct.get $type38 1
    (global.get $global141)
   )
   (i64.trunc_f64_s
    (local.get $2)
   )
  )
 )
 (func $function156 (type $23) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type80))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type80))
  (local $10 (ref $type80))
  (local $11 (ref null $type80))
  (local $12 (ref null $type80))
  (local $scratch (ref $type29))
  (local $scratch_14 (ref $type29))
  (local $scratch_15 (ref $type29))
  (local $scratch_16 (ref $type29))
  (local $scratch_17 (ref $type29))
  (local $scratch_18 (ref $type29))
  (local $scratch_19 (ref $type29))
  (local $scratch_20 (ref $type29))
  (if (result (ref $type80))
   (i64.eqz
    (call $function59
     (call $function53
      (struct.get $type38 1
       (global.get $global141)
      )
      (i64.const 1)
     )
     (block (result (ref $type29))
      (drop
       (ref.as_non_null
        (global.get $global222)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global215)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (local.set $scratch
       (call $function71
        (local.get $1)
        (if (result (ref $type29))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type29 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.get $0)
         )
         (else
          (struct.new $type29
           (i32.eqz
            (struct.get $type29 0
             (local.get $0)
            )
           )
           (struct.get $type29 1
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global175)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global171)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (then
    (local.set $4
     (call $function77
      (call $function77
       (call $function71
        (call $function77
         (call $function53
          (struct.get $type38 1
           (global.get $global141)
          )
          (i64.const 6)
         )
         (block (result (ref $type29))
          (drop
           (ref.as_non_null
            (global.get $global242)
           )
          )
          (local.get $1)
         )
        )
        (block (result (ref $type29))
         (local.set $0
          (call $function53
           (struct.get $type38 1
            (global.get $global141)
           )
           (i64.const 5)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global222)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global134)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global215)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global130)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (i64.extend_i32_u
            (array.len
             (struct.get $type29 1
              (local.get $0)
             )
            )
           )
          )
          (then
           (local.get $0)
          )
          (else
           (struct.new $type29
            (i32.eqz
             (struct.get $type29 0
              (local.get $0)
             )
            )
            (struct.get $type29 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (block (result (ref $type29))
        (local.set $scratch_14
         (call $function71
          (call $function77
           (call $function53
            (struct.get $type38 1
             (global.get $global141)
            )
            (i64.const 2)
           )
           (block (result (ref $type29))
            (drop
             (ref.as_non_null
              (global.get $global242)
             )
            )
            (local.get $1)
           )
          )
          (block (result (ref $type29))
           (local.set $0
            (call $function53
             (struct.get $type38 1
              (global.get $global141)
             )
             (i64.const 1)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global222)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global134)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global215)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global130)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (i64.extend_i32_u
              (array.len
               (struct.get $type29 1
                (local.get $0)
               )
              )
             )
            )
            (then
             (local.get $0)
            )
            (else
             (struct.new $type29
              (i32.eqz
               (struct.get $type29 0
                (local.get $0)
               )
              )
              (struct.get $type29 1
               (local.get $0)
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global242)
         )
        )
        (local.get $scratch_14)
       )
      )
      (block (result (ref $type29))
       (local.set $scratch_15
        (call $function71
         (call $function77
          (call $function53
           (struct.get $type38 1
            (global.get $global141)
           )
           (i64.const 6)
          )
          (block (result (ref $type29))
           (drop
            (ref.as_non_null
             (global.get $global242)
            )
           )
           (local.get $1)
          )
         )
         (block (result (ref $type29))
          (local.set $0
           (call $function53
            (struct.get $type38 1
             (global.get $global141)
            )
            (i64.const 1)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global222)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global134)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global215)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global130)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type29 1
               (local.get $0)
              )
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (struct.new $type29
             (i32.eqz
              (struct.get $type29 0
               (local.get $0)
              )
             )
             (struct.get $type29 1
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.get $scratch_15)
      )
     )
    )
    (local.set $0
     (struct.get $type53 0
      (call $function93
       (call $function77
        (ref.as_non_null
         (global.get $global561)
        )
        (block (result (ref $type29))
         (local.set $0
          (call $function53
           (struct.get $type38 1
            (global.get $global141)
           )
           (i64.const 3)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global429)
          )
         )
         (local.set $scratch_16
          (if (result (ref $type29))
           (struct.get $type29 0
            (local.get $0)
           )
           (then
            (unreachable)
           )
           (else
            (call $function120
             (i32.const 0)
             (i32.const 1)
             (local.get $1)
             (local.get $0)
             (call $function53
              (struct.get $type38 1
               (global.get $global141)
              )
              (i64.const 1)
             )
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global242)
          )
         )
         (local.get $scratch_16)
        )
       )
       (block (result (ref $type29))
        (local.set $scratch_17
         (call $function53
          (struct.get $type38 1
           (global.get $global141)
          )
          (i64.const 24)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global330)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global324)
         )
        )
        (local.get $scratch_17)
       )
      )
     )
    )
    (local.set $3
     (call $function53
      (struct.get $type38 1
       (global.get $global141)
      )
      (i64.const -1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global429)
     )
    )
    (local.set $2
     (call $function77
      (call $function77
       (if (result (ref $type29))
        (struct.get $type29 0
         (local.get $1)
        )
        (then
         (unreachable)
        )
        (else
         (call $function120
          (i32.const 0)
          (i32.const 1)
          (local.get $3)
          (local.get $1)
          (call $function53
           (struct.get $type38 1
            (global.get $global141)
           )
           (i64.const 1)
          )
         )
        )
       )
       (block (result (ref $type29))
        (drop
         (ref.as_non_null
          (global.get $global242)
         )
        )
        (local.get $4)
       )
      )
      (block (result (ref $type29))
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.set $scratch_18
        (call $function71
         (call $function77
          (local.get $1)
          (ref.as_non_null
           (global.get $global559)
          )
         )
         (block (result (ref $type29))
          (drop
           (ref.as_non_null
            (global.get $global215)
           )
          )
          (ref.as_non_null
           (global.get $global558)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.get $scratch_18)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global567)
     )
    )
    (struct.new $type80
     (local.get $4)
     (struct.new $type80
      (local.get $0)
      (struct.new $type80
       (local.get $2)
       (ref.null none)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (local.set $3
     (struct.get $type53 0
      (call $function93
       (call $function71
        (local.get $0)
        (local.get $1)
       )
       (block (result (ref $type29))
        (local.set $scratch_19
         (call $function53
          (struct.get $type38 1
           (global.get $global141)
          )
          (i64.const 2)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global330)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global324)
         )
        )
        (local.get $scratch_19)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready563)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global563)
     )
    )
    (local.set $9
     (call $function156
      (local.get $0)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready563)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global563)
     )
    )
    (local.set $10
     (call $function156
      (local.get $3)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global573)
     )
    )
    (local.set $0
     (struct.get $type80 0
      (local.tee $11
       (struct.get $type80 1
        (local.get $10)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global576)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global242)
     )
    )
    (local.set $2
     (call $function77
      (struct.get $type80 0
       (local.tee $12
        (struct.get $type80 1
         (local.get $9)
        )
       )
      )
      (block (result (ref $type29))
       (local.set $3
        (struct.get $type80 0
         (struct.get $type80 1
          (local.get $12)
         )
        )
       )
       (local.set $6
        (struct.get $type80 0
         (struct.get $type80 1
          (local.get $11)
         )
        )
       )
       (local.set $4
        (call $function77
         (local.tee $7
          (struct.get $type80 0
           (local.get $9)
          )
         )
         (struct.get $type80 0
          (local.get $10)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.get $0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global242)
     )
    )
    (local.set $5
     (call $function71
      (call $function77
       (local.get $3)
       (local.get $0)
      )
      (block (result (ref $type29))
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.set $scratch_20
        (call $function77
         (local.get $6)
         (local.get $7)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global215)
        )
       )
       (local.get $scratch_20)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global567)
     )
    )
    (struct.new $type80
     (local.get $4)
     (struct.new $type80
      (local.get $2)
      (struct.new $type80
       (local.get $5)
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function171 (type $call38) (param $0 (ref null $environment185)) (param $1 i64) (result (ref $type29))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type29))
  (local $8 (ref $type14))
  (local $9 (ref $type14))
  (local $10 (ref $type80))
  (local $11 (ref null $type80))
  (local $12 i64)
  (local $13 i64)
  (local $scratch (ref $type29))
  (local $scratch_15 (ref $type80))
  (local $scratch_16 (ref $type29))
  (local.set $6
   (call $function155
    (struct.get $type38 1
     (global.get $global556)
    )
    (local.get $1)
   )
  )
  (local.set $3
   (call $function77
    (ref.as_non_null
     (global.get $global560)
    )
    (block (result (ref $type29))
     (local.set $7
      (call $function53
       (struct.get $type38 1
        (global.get $global141)
       )
       (i64.const 100)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global440)
      )
     )
     (local.set $2
      (call $function53
       (struct.get $type38 1
        (global.get $global141)
       )
       (local.get $1)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global429)
      )
     )
     (local.set $scratch
      (if (result (ref $type29))
       (struct.get $type29 0
        (local.get $2)
       )
       (then
        (unreachable)
       )
       (else
        (call $function120
         (i32.const 0)
         (i32.const 1)
         (local.get $7)
         (local.get $2)
         (call $function53
          (struct.get $type38 1
           (global.get $global141)
          )
          (i64.const 1)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global242)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global456)
   )
  )
  (local.set $4
   (if (result (ref $type29))
    (struct.get $type29 0
     (local.get $3)
    )
    (then
     (unreachable)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (if (result (ref $type29))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (struct.get $type29 1
          (local.get $3)
         )
        )
       )
      )
      (then
       (local.get $3)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global448)
        )
       )
       (if
        (i64.ne
         (i64.div_s
          (local.tee $13
           (i64.mul
            (local.tee $12
             (i64.sub
              (local.tee $1
               (i64.extend_i32_u
                (array.len
                 (local.tee $8
                  (struct.get $type29 1
                   (local.get $3)
                  )
                 )
                )
               )
              )
              (i64.const 1)
             )
            )
            (i64.const 30)
           )
          )
          (i64.const 30)
         )
         (local.get $12)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global109)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global443)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $13)
           (local.tee $1
            (i64.add
             (local.get $13)
             (local.tee $12
              (call $function122
               (i64.extend_i32_s
                (array.get $type14
                 (local.get $8)
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
          (i64.xor
           (local.get $1)
           (local.get $12)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.tee $13
            (i64.add
             (local.get $1)
             (i64.const 1)
            )
           )
          )
          (i64.xor
           (local.get $13)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (i64.add
         (local.tee $13
          (i64.div_s
           (local.tee $12
            (i64.div_s
             (local.get $13)
             (i64.const 2)
            )
           )
           (i64.const 30)
          )
         )
         (i64.const 1)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.get $13)
          )
          (i64.xor
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global116)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global344)
        )
       )
       (local.set $12
        (call $function99
         (i64.const 2)
         (i32.const 0)
         (i32.const 1)
         (i64.rem_s
          (local.get $12)
          (i64.const 30)
         )
         (i64.const 1)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global112)
        )
       )
       (if
        (i64.ne
         (local.get $12)
         (i64.extend32_s
          (local.get $12)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $13)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.set $type14
        (local.tee $9
         (array.new_default $type14
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (i32.wrap_i64
         (local.get $13)
        )
        (i32.wrap_i64
         (local.get $12)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global126)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (call $function126
        (local.get $3)
        (i32.const 0)
        (i32.const 1)
        (if (result (ref $type29))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $8
             (call $function46
              (local.get $9)
             )
            )
           )
          )
         )
         (then
          (ref.as_non_null
           (global.get $global108)
          )
         )
         (else
          (struct.new $type29
           (i32.const 0)
           (local.get $8)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $2
   (struct.get $type80 0
    (local.tee $11
     (struct.get $type80 1
      (block (result (ref $type80))
       (local.set $scratch_15
        (call $function156
         (call $function53
          (struct.get $type38 1
           (global.get $global141)
          )
          (i64.const 0)
         )
         (block (result (ref $type29))
          (drop
           (ref.as_non_null
            (global.get $global563)
           )
          )
          (local.get $6)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global573)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global576)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global242)
        )
       )
       (local.get $scratch_15)
      )
     )
    )
   )
  )
  (local.set $5
   (call $function71
    (struct.get $type80 0
     (struct.get $type80 1
      (local.get $11)
     )
    )
    (block (result (ref $type29))
     (local.set $3
      (call $function77
       (call $function77
        (local.get $2)
        (ref.as_non_null
         (global.get $global560)
        )
       )
       (block (result (ref $type29))
        (drop
         (ref.as_non_null
          (global.get $global242)
         )
        )
        (local.get $4)
       )
      )
     )
     (local.set $4
      (ref.as_non_null
       (global.get $global562)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global242)
      )
     )
     (local.set $scratch_16
      (call $function77
       (local.get $2)
       (ref.as_non_null
        (global.get $global558)
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global215)
      )
     )
     (local.get $scratch_16)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global242)
   )
  )
  (local.set $5
   (call $function77
    (local.get $4)
    (local.get $5)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global330)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global324)
   )
  )
  (struct.get $type53 0
   (call $function93
    (local.get $3)
    (local.get $5)
   )
  )
 )
 (func $function180 (type $call38) (param $0 (ref null $environment185)) (param $1 i64) (result (ref $type29))
  (local $2 (ref $type95))
  (local $3 (ref $type38))
  (local $4 i64)
  (local.set $4
   (call $foreign0
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type95 1
   (local.tee $2
    (struct.new_default $type95)
   )
   (struct.new $type38
    (ref.func $function185)
    (struct.new $environment185
     (local.get $1)
     (local.get $4)
     (call $string-new
      (i32.wrap_i64
       (local.get $4)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type95 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type95 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call38
   (struct.get $type38 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type95 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type38 0
    (local.get $3)
   )
  )
 )
 (func $function185 (type $call38) (param $0 (ref null $environment185)) (param $1 i64) (result (ref $type29))
  (local $2 (ref $type16))
  (local $3 (ref $environment185))
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (if
   (i64.eq
    (struct.get $environment185 1
     (local.tee $3
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global361)
     )
    )
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.tee $2
         (struct.get $environment185 2
          (local.get $3)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type16 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global350)
       )
      )
      (if
       (i64.eq
        (local.tee $1
         (i64.extend_i32_u
          (i32.or
           (local.tee $5
            (i32.eq
             (local.tee $4
              (array.get $type17
               (struct.get $type16 1
                (local.get $2)
               )
               (i32.const 0)
              )
             )
             (i32.const 45)
            )
           )
           (i32.eq
            (local.get $4)
            (i32.const 43)
           )
          )
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type16 0
           (local.get $2)
          )
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (return_call $function101
         (local.get $2)
         (local.get $5)
         (local.get $6)
         (i32.const 1)
         (i32.const 0)
         (i32.const 1)
         (local.get $1)
         (ref.as_non_null
          (global.get $global108)
         )
        )
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
   (else
    (local.set $5
     (call $foreign1
      (struct.get $environment185 0
       (local.get $3)
      )
      (local.get $1)
     )
    )
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.tee $2
         (struct.get $environment185 2
          (local.get $3)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $4
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 1
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 2
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $4)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $4)
      (i32.const 8191)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type95 0
       (struct.get $environment185 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function185
     (struct.get $type38 1
      (struct.get $type95 1
       (struct.get $environment185 3
        (local.get $3)
       )
      )
     )
     (local.get $6)
    )
   )
  )
  (unreachable)
 )
 (func $function186 (type $call86) (param $0 (ref $type29)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type99))
  (local $7 (ref $type16))
  (local $8 (ref null $type63))
  (drop
   (ref.as_non_null
    (global.get $global419)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (struct.set $type99 1
   (local.tee $6
    (struct.new_default $type99)
   )
   (struct.new $type97
    (struct.new $environment189
     (if (result (ref $type16))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (struct.get $type29 1
          (local.get $0)
         )
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global63)
        )
       )
       (if
        (i32.eqz
         (global.get $ready65)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global65)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global68)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (call $function30
        (call $string-new
         (i32.const 1)
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (struct.new_default $type12)
        (i64.const 0)
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global385)
        )
       )
       (local.set $8
        (call $function107
         (struct.get $type29 1
          (local.get $0)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global395)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $3
            (i64.add
             (local.tee $1
              (local.tee $4
               (i64.extend_i32_u
                (i32.ne
                 (struct.get $type29 0
                  (local.get $0)
                 )
                 (i32.const 0)
                )
               )
              )
             )
             (local.tee $2
              (local.tee $5
               (call $function110
                (struct.get $type63 0
                 (local.get $8)
                )
               )
              )
             )
            )
           )
           (local.get $1)
          )
          (i64.xor
           (local.get $2)
           (local.get $3)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global400)
        )
       )
       (local.set $1
        (i64.sub
         (local.tee $2
          (call $function112
           (local.get $8)
          )
         )
         (i64.const 1)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.get $2)
          )
          (i64.xor
           (local.get $2)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (i64.mul
         (local.get $1)
         (i64.const 9)
        )
       )
       (if
        (i64.ne
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.ne
           (i64.div_s
            (local.get $2)
            (local.get $1)
           )
           (i64.const 9)
          )
          (then
           (unreachable)
          )
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $3)
           (local.tee $1
            (i64.add
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (i64.xor
           (local.get $1)
           (local.get $2)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (call $string-new
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (struct.get $type29 0
         (local.get $0)
        )
        (then
         (if
          (i64.eqz
           (i64.extend_i32_u
            (struct.get $type16 0
             (local.get $7)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (array.set $type17
          (struct.get $type16 1
           (local.get $7)
          )
          (i32.const 0)
          (i32.const 45)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global414)
        )
       )
       (drop
        (call $function116
         (local.get $7)
         (local.get $4)
         (local.get $8)
         (local.get $5)
        )
       )
       (local.get $7)
      )
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type99 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type99 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function189
   (struct.get $type97 0
    (struct.get $type99 1
     (local.get $6)
    )
   )
   (i64.const 0)
  )
 )
 (func $function189 (type $call97) (param $0 (ref $environment189)) (param $1 i64) (result i32)
  (local $2 (ref $type16))
  (local $3 i32)
  (local $4 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type16 0
      (struct.get $environment189 0
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type16 0
        (local.tee $2
         (struct.get $environment189 0
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign2
     (array.get $type17
      (if (result (ref $type17))
       (i32.lt_u
        (local.tee $3
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type16 1
         (local.get $2)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type18
          (struct.get $type16 2
           (local.get $2)
          )
          (i32.sub
           (i32.shr_u
            (local.get $3)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $3)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (struct.get $environment189 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function189
     (struct.get $type97 0
      (struct.get $type99 1
       (struct.get $environment189 1
        (local.get $0)
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function191 (type $14) (param $0 (ref null $type80))
  (local $1 (ref $environment193))
  (local $2 (ref $type102))
  (call $foreign2
   (i32.const 40)
  )
  (struct.set $type102 1
   (local.tee $2
    (struct.new_default $type102)
   )
   (struct.new $type100
    (struct.new $environment193
     (local.get $2)
    )
   )
  )
  (struct.set $type102 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type102 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type100 0
    (struct.get $type102 1
     (local.get $2)
    )
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call $function186
       (struct.get $type80 0
        (local.get $0)
       )
      )
     )
     (local.set $0
      (struct.get $type80 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type102 0
        (struct.get $environment193 0
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $1
      (struct.get $type100 0
       (struct.get $type102 1
        (struct.get $environment193 0
         (local.get $1)
        )
       )
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $0)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign2
        (i32.const 32)
       )
       (drop
        (call $function186
         (struct.get $type80 0
          (local.get $0)
         )
        )
       )
       (local.set $0
        (struct.get $type80 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (struct.get $type102 0
          (struct.get $environment193 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type100 0
         (struct.get $type102 1
          (struct.get $environment193 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign2
          (i32.const 32)
         )
         (drop
          (call $function186
           (struct.get $type80 0
            (local.get $0)
           )
          )
         )
         (local.set $0
          (struct.get $type80 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (struct.get $type102 0
            (struct.get $environment193 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type100 0
           (struct.get $type102 1
            (struct.get $environment193 0
             (local.get $1)
            )
           )
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $0)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign2
            (i32.const 32)
           )
           (drop
            (call $function186
             (struct.get $type80 0
              (local.get $0)
             )
            )
           )
           (local.set $0
            (struct.get $type80 1
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (struct.get $type102 0
              (struct.get $environment193 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type100 0
             (struct.get $type102 1
              (struct.get $environment193 0
               (local.get $1)
              )
             )
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $0)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign2
              (i32.const 32)
             )
             (drop
              (call $function186
               (struct.get $type80 0
                (local.get $0)
               )
              )
             )
             (local.set $0
              (struct.get $type80 1
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (struct.get $type102 0
                (struct.get $environment193 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type100 0
               (struct.get $type102 1
                (struct.get $environment193 0
                 (local.get $1)
                )
               )
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $0)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign2
                (i32.const 32)
               )
               (drop
                (call $function186
                 (struct.get $type80 0
                  (local.get $0)
                 )
                )
               )
               (local.set $0
                (struct.get $type80 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type102 0
                  (struct.get $environment193 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type100 0
                 (struct.get $type102 1
                  (struct.get $environment193 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $0)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign2
                  (i32.const 32)
                 )
                 (drop
                  (call $function186
                   (struct.get $type80 0
                    (local.get $0)
                   )
                  )
                 )
                 (local.set $0
                  (struct.get $type80 1
                   (local.get $0)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type102 0
                    (struct.get $environment193 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type100 0
                   (struct.get $type102 1
                    (struct.get $environment193 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $0)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign2
                    (i32.const 32)
                   )
                   (drop
                    (call $function186
                     (struct.get $type80 0
                      (local.get $0)
                     )
                    )
                   )
                   (local.set $0
                    (struct.get $type80 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type102 0
                      (struct.get $environment193 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type100 0
                     (struct.get $type102 1
                      (struct.get $environment193 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $0)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign2
                      (i32.const 32)
                     )
                     (drop
                      (call $function186
                       (struct.get $type80 0
                        (local.get $0)
                       )
                      )
                     )
                     (local.set $0
                      (struct.get $type80 1
                       (local.get $0)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type102 0
                        (struct.get $environment193 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type100 0
                       (struct.get $type102 1
                        (struct.get $environment193 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $0)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign2
                        (i32.const 32)
                       )
                       (drop
                        (call $function186
                         (struct.get $type80 0
                          (local.get $0)
                         )
                        )
                       )
                       (local.set $0
                        (struct.get $type80 1
                         (local.get $0)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type102 0
                          (struct.get $environment193 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type100 0
                         (struct.get $type102 1
                          (struct.get $environment193 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $0)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $foreign2
                          (i32.const 32)
                         )
                         (drop
                          (call $function186
                           (struct.get $type80 0
                            (local.get $0)
                           )
                          )
                         )
                         (local.set $0
                          (struct.get $type80 1
                           (local.get $0)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type102 0
                            (struct.get $environment193 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type100 0
                           (struct.get $type102 1
                            (struct.get $environment193 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $0)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $foreign2
                            (i32.const 32)
                           )
                           (drop
                            (call $function186
                             (struct.get $type80 0
                              (local.get $0)
                             )
                            )
                           )
                           (local.set $0
                            (struct.get $type80 1
                             (local.get $0)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type102 0
                              (struct.get $environment193 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $1
                            (struct.get $type100 0
                             (struct.get $type102 1
                              (struct.get $environment193 0
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $0)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $foreign2
                              (i32.const 32)
                             )
                             (drop
                              (call $function186
                               (struct.get $type80 0
                                (local.get $0)
                               )
                              )
                             )
                             (local.set $0
                              (struct.get $type80 1
                               (local.get $0)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type102 0
                                (struct.get $environment193 0
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $1
                              (struct.get $type100 0
                               (struct.get $type102 1
                                (struct.get $environment193 0
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $0)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $foreign2
                                (i32.const 32)
                               )
                               (drop
                                (call $function186
                                 (struct.get $type80 0
                                  (local.get $0)
                                 )
                                )
                               )
                               (local.set $0
                                (struct.get $type80 1
                                 (local.get $0)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type102 0
                                  (struct.get $environment193 0
                                   (local.get $1)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $1
                                (struct.get $type100 0
                                 (struct.get $type102 1
                                  (struct.get $environment193 0
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $0)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (call $foreign2
                                  (i32.const 32)
                                 )
                                 (drop
                                  (call $function186
                                   (struct.get $type80 0
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (local.set $0
                                  (struct.get $type80 1
                                   (local.get $0)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type102 0
                                    (struct.get $environment193 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function193
                                  (struct.get $type100 0
                                   (struct.get $type102 1
                                    (struct.get $environment193 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (call $foreign2
   (i32.const 41)
  )
 )
 (func $function193 (type $call100) (param $0 (ref $environment193)) (param $1 (ref null $type80)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign2
     (i32.const 32)
    )
    (drop
     (call $function186
      (struct.get $type80 0
       (local.get $1)
      )
     )
    )
    (local.set $1
     (struct.get $type80 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type102 0
       (struct.get $environment193 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function193
     (struct.get $type100 0
      (struct.get $type102 1
       (struct.get $environment193 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $function195 (type $call104) (param $0 (ref $environment195)) (param $1 i64) (result (ref null $type80))
  (local $2 i64)
  (local $3 (ref $type29))
  (if (result (ref null $type80))
   (i64.eq
    (call $foreign3)
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type80
     (call $function180
      (struct.get $type38 1
       (global.get $global590)
      )
      (local.get $1)
     )
     (block (result (ref null $type80))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type105 0
         (struct.get $environment195 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function195
       (struct.get $type104 0
        (struct.get $type105 1
         (struct.get $environment195 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function198 (type $call106) (param $0 (ref $environment198)) (param $1 i64) (param $2 (ref null $type80)) (result i64)
  (local $3 (ref null $type80))
  (local $4 (ref null $type80))
  (local $5 (ref null $type80))
  (local $6 (ref $type29))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $scratch (ref null $type80))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment198 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $11
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $11)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $foreign4
      (global.get $global609)
     )
    )
    (local.set $9
     (call $foreign4
      (global.get $global610)
     )
    )
    (local.set $1
     (call $foreign4
      (global.get $global611)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global621)
     )
    )
    (local.set $2
     (if (result (ref null $type80))
      (i64.gt_s
       (local.get $7)
       (local.get $9)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type80
        (call $function171
         (struct.get $type38 1
          (global.get $global582)
         )
         (local.get $7)
        )
        (block (result (ref null $type80))
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.get $7)
             (local.tee $8
              (i64.add
               (local.get $1)
               (local.get $7)
              )
             )
            )
            (i64.xor
             (local.get $1)
             (local.get $8)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (global.get $ready621)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global621)
          )
         )
         (if (result (ref null $type80))
          (i64.gt_s
           (local.get $8)
           (local.get $9)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type80
            (call $function171
             (struct.get $type38 1
              (global.get $global582)
             )
             (local.get $8)
            )
            (block (result (ref null $type80))
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.get $8)
                 (local.tee $7
                  (i64.add
                   (local.get $1)
                   (local.get $8)
                  )
                 )
                )
                (i64.xor
                 (local.get $1)
                 (local.get $7)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (global.get $ready621)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global621)
              )
             )
             (if (result (ref null $type80))
              (i64.gt_s
               (local.get $7)
               (local.get $9)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type80
                (call $function171
                 (struct.get $type38 1
                  (global.get $global582)
                 )
                 (local.get $7)
                )
                (block (result (ref null $type80))
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.get $7)
                     (local.tee $8
                      (i64.add
                       (local.get $1)
                       (local.get $7)
                      )
                     )
                    )
                    (i64.xor
                     (local.get $1)
                     (local.get $8)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready621)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global621)
                  )
                 )
                 (if (result (ref null $type80))
                  (i64.gt_s
                   (local.get $8)
                   (local.get $9)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type80
                    (call $function171
                     (struct.get $type38 1
                      (global.get $global582)
                     )
                     (local.get $8)
                    )
                    (block (result (ref null $type80))
                     (if
                      (i64.lt_s
                       (i64.and
                        (i64.xor
                         (local.get $8)
                         (local.tee $7
                          (i64.add
                           (local.get $1)
                           (local.get $8)
                          )
                         )
                        )
                        (i64.xor
                         (local.get $1)
                         (local.get $7)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready621)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global621)
                      )
                     )
                     (if (result (ref null $type80))
                      (i64.gt_s
                       (local.get $7)
                       (local.get $9)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type80
                        (call $function171
                         (struct.get $type38 1
                          (global.get $global582)
                         )
                         (local.get $7)
                        )
                        (block (result (ref null $type80))
                         (if
                          (i64.lt_s
                           (i64.and
                            (i64.xor
                             (local.get $7)
                             (local.tee $8
                              (i64.add
                               (local.get $1)
                               (local.get $7)
                              )
                             )
                            )
                            (i64.xor
                             (local.get $1)
                             (local.get $8)
                            )
                           )
                           (i64.const 0)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready621)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global621)
                          )
                         )
                         (if (result (ref null $type80))
                          (i64.gt_s
                           (local.get $8)
                           (local.get $9)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type80
                            (call $function171
                             (struct.get $type38 1
                              (global.get $global582)
                             )
                             (local.get $8)
                            )
                            (block (result (ref null $type80))
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.get $8)
                                 (local.tee $7
                                  (i64.add
                                   (local.get $1)
                                   (local.get $8)
                                  )
                                 )
                                )
                                (i64.xor
                                 (local.get $1)
                                 (local.get $7)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready621)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global621)
                              )
                             )
                             (if (result (ref null $type80))
                              (i64.gt_s
                               (local.get $7)
                               (local.get $9)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type80
                                (call $function171
                                 (struct.get $type38 1
                                  (global.get $global582)
                                 )
                                 (local.get $7)
                                )
                                (block (result (ref null $type80))
                                 (if
                                  (i64.lt_s
                                   (i64.and
                                    (i64.xor
                                     (local.get $7)
                                     (local.tee $8
                                      (i64.add
                                       (local.get $1)
                                       (local.get $7)
                                      )
                                     )
                                    )
                                    (i64.xor
                                     (local.get $1)
                                     (local.get $8)
                                    )
                                   )
                                   (i64.const 0)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready621)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global621)
                                  )
                                 )
                                 (if (result (ref null $type80))
                                  (i64.gt_s
                                   (local.get $8)
                                   (local.get $9)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type80
                                    (call $function171
                                     (struct.get $type38 1
                                      (global.get $global582)
                                     )
                                     (local.get $8)
                                    )
                                    (block (result (ref null $type80))
                                     (if
                                      (i64.lt_s
                                       (i64.and
                                        (i64.xor
                                         (local.get $8)
                                         (local.tee $7
                                          (i64.add
                                           (local.get $1)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                        (i64.xor
                                         (local.get $1)
                                         (local.get $7)
                                        )
                                       )
                                       (i64.const 0)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready621)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global621)
                                      )
                                     )
                                     (if (result (ref null $type80))
                                      (i64.gt_s
                                       (local.get $7)
                                       (local.get $9)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type80
                                        (call $function171
                                         (struct.get $type38 1
                                          (global.get $global582)
                                         )
                                         (local.get $7)
                                        )
                                        (block (result (ref null $type80))
                                         (if
                                          (i64.lt_s
                                           (i64.and
                                            (i64.xor
                                             (local.get $7)
                                             (local.tee $8
                                              (i64.add
                                               (local.get $1)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                            (i64.xor
                                             (local.get $1)
                                             (local.get $8)
                                            )
                                           )
                                           (i64.const 0)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready621)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global621)
                                          )
                                         )
                                         (if (result (ref null $type80))
                                          (i64.gt_s
                                           (local.get $8)
                                           (local.get $9)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type80
                                            (call $function171
                                             (struct.get $type38 1
                                              (global.get $global582)
                                             )
                                             (local.get $8)
                                            )
                                            (block (result (ref null $type80))
                                             (if
                                              (i64.lt_s
                                               (i64.and
                                                (i64.xor
                                                 (local.get $8)
                                                 (local.tee $7
                                                  (i64.add
                                                   (local.get $1)
                                                   (local.get $8)
                                                  )
                                                 )
                                                )
                                                (i64.xor
                                                 (local.get $1)
                                                 (local.get $7)
                                                )
                                               )
                                               (i64.const 0)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready621)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global621)
                                              )
                                             )
                                             (if (result (ref null $type80))
                                              (i64.gt_s
                                               (local.get $7)
                                               (local.get $9)
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (struct.new $type80
                                                (call $function171
                                                 (struct.get $type38 1
                                                  (global.get $global582)
                                                 )
                                                 (local.get $7)
                                                )
                                                (block (result (ref null $type80))
                                                 (if
                                                  (i64.lt_s
                                                   (i64.and
                                                    (i64.xor
                                                     (local.get $7)
                                                     (local.tee $8
                                                      (i64.add
                                                       (local.get $1)
                                                       (local.get $7)
                                                      )
                                                     )
                                                    )
                                                    (i64.xor
                                                     (local.get $1)
                                                     (local.get $8)
                                                    )
                                                   )
                                                   (i64.const 0)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready621)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global621)
                                                  )
                                                 )
                                                 (if (result (ref null $type80))
                                                  (i64.gt_s
                                                   (local.get $8)
                                                   (local.get $9)
                                                  )
                                                  (then
                                                   (ref.null none)
                                                  )
                                                  (else
                                                   (struct.new $type80
                                                    (call $function171
                                                     (struct.get $type38 1
                                                      (global.get $global582)
                                                     )
                                                     (local.get $8)
                                                    )
                                                    (block (result (ref null $type80))
                                                     (if
                                                      (i64.lt_s
                                                       (i64.and
                                                        (i64.xor
                                                         (local.get $8)
                                                         (local.tee $7
                                                          (i64.add
                                                           (local.get $1)
                                                           (local.get $8)
                                                          )
                                                         )
                                                        )
                                                        (i64.xor
                                                         (local.get $1)
                                                         (local.get $7)
                                                        )
                                                       )
                                                       (i64.const 0)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready621)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global621)
                                                      )
                                                     )
                                                     (if (result (ref null $type80))
                                                      (i64.gt_s
                                                       (local.get $7)
                                                       (local.get $9)
                                                      )
                                                      (then
                                                       (ref.null none)
                                                      )
                                                      (else
                                                       (struct.new $type80
                                                        (call $function171
                                                         (struct.get $type38 1
                                                          (global.get $global582)
                                                         )
                                                         (local.get $7)
                                                        )
                                                        (block (result (ref null $type80))
                                                         (if
                                                          (i64.lt_s
                                                           (i64.and
                                                            (i64.xor
                                                             (local.get $7)
                                                             (local.tee $10
                                                              (i64.add
                                                               (local.get $1)
                                                               (local.get $7)
                                                              )
                                                             )
                                                            )
                                                            (i64.xor
                                                             (local.get $1)
                                                             (local.get $10)
                                                            )
                                                           )
                                                           (i64.const 0)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready621)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global621)
                                                          )
                                                         )
                                                         (if (result (ref null $type80))
                                                          (i64.lt_s
                                                           (local.get $9)
                                                           (local.get $10)
                                                          )
                                                          (then
                                                           (ref.null none)
                                                          )
                                                          (else
                                                           (struct.new $type80
                                                            (call $function171
                                                             (struct.get $type38 1
                                                              (global.get $global582)
                                                             )
                                                             (local.get $10)
                                                            )
                                                            (block (result (ref null $type80))
                                                             (if
                                                              (i64.lt_s
                                                               (i64.and
                                                                (i64.xor
                                                                 (local.get $10)
                                                                 (local.tee $8
                                                                  (i64.add
                                                                   (local.get $1)
                                                                   (local.get $10)
                                                                  )
                                                                 )
                                                                )
                                                                (i64.xor
                                                                 (local.get $1)
                                                                 (local.get $8)
                                                                )
                                                               )
                                                               (i64.const 0)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready621)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global621)
                                                              )
                                                             )
                                                             (if (result (ref null $type80))
                                                              (i64.gt_s
                                                               (local.get $8)
                                                               (local.get $9)
                                                              )
                                                              (then
                                                               (ref.null none)
                                                              )
                                                              (else
                                                               (struct.new $type80
                                                                (call $function171
                                                                 (struct.get $type38 1
                                                                  (global.get $global582)
                                                                 )
                                                                 (local.get $8)
                                                                )
                                                                (block (result (ref null $type80))
                                                                 (if
                                                                  (i64.lt_s
                                                                   (i64.and
                                                                    (i64.xor
                                                                     (local.get $8)
                                                                     (local.tee $7
                                                                      (i64.add
                                                                       (local.get $1)
                                                                       (local.get $8)
                                                                      )
                                                                     )
                                                                    )
                                                                    (i64.xor
                                                                     (local.get $1)
                                                                     (local.get $7)
                                                                    )
                                                                   )
                                                                   (i64.const 0)
                                                                  )
                                                                  (then
                                                                   (unreachable)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (global.get $ready621)
                                                                  )
                                                                  (then
                                                                   (unreachable)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global621)
                                                                  )
                                                                 )
                                                                 (call $function199
                                                                  (local.get $7)
                                                                  (local.get $9)
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type108 0
       (struct.get $environment198 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function198
     (struct.get $type106 0
      (struct.get $type108 1
       (struct.get $environment198 1
        (local.get $0)
       )
      )
     )
     (local.get $11)
     (local.get $2)
    )
   )
   (else
    (struct.set $type89 0
     (global.get $global615)
     (local.get $2)
    )
    (drop
     (ref.as_non_null
      (global.get $global625)
     )
    )
    (local.set $5
     (global.get $global612)
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (ref.is_null
         (local.get $5)
        )
       )
       (else
        (if (result i32)
         (ref.is_null
          (local.get $5)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global175)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (if (result i32)
           (i64.eqz
            (call $function59
             (struct.get $type80 0
              (local.get $2)
             )
             (struct.get $type80 0
              (local.get $5)
             )
            )
           )
           (then
            (local.set $4
             (struct.get $type80 1
              (local.get $2)
             )
            )
            (local.set $3
             (struct.get $type80 1
              (local.get $5)
             )
            )
            (if
             (i32.eqz
              (global.get $ready625)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global625)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $4)
             )
             (then
              (ref.is_null
               (local.get $3)
              )
             )
             (else
              (if (result i32)
               (ref.is_null
                (local.get $3)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global175)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global171)
                 )
                )
                (if (result i32)
                 (i64.eqz
                  (call $function59
                   (struct.get $type80 0
                    (local.get $4)
                   )
                   (struct.get $type80 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.set $4
                   (struct.get $type80 1
                    (local.get $4)
                   )
                  )
                  (local.set $3
                   (struct.get $type80 1
                    (local.get $3)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready625)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global625)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $4)
                   )
                   (then
                    (ref.is_null
                     (local.get $3)
                    )
                   )
                   (else
                    (if (result i32)
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global175)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global171)
                       )
                      )
                      (if (result i32)
                       (i64.eqz
                        (call $function59
                         (struct.get $type80 0
                          (local.get $4)
                         )
                         (struct.get $type80 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (local.set $4
                         (struct.get $type80 1
                          (local.get $4)
                         )
                        )
                        (local.set $3
                         (struct.get $type80 1
                          (local.get $3)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready625)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global625)
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $4)
                         )
                         (then
                          (ref.is_null
                           (local.get $3)
                          )
                         )
                         (else
                          (if (result i32)
                           (ref.is_null
                            (local.get $3)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global175)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global171)
                             )
                            )
                            (if (result i32)
                             (i64.eqz
                              (call $function59
                               (struct.get $type80 0
                                (local.get $4)
                               )
                               (struct.get $type80 0
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.set $4
                               (struct.get $type80 1
                                (local.get $4)
                               )
                              )
                              (local.set $3
                               (struct.get $type80 1
                                (local.get $3)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready625)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global625)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $4)
                               )
                               (then
                                (ref.is_null
                                 (local.get $3)
                                )
                               )
                               (else
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $3)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global175)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global171)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eqz
                                    (call $function59
                                     (struct.get $type80 0
                                      (local.get $4)
                                     )
                                     (struct.get $type80 0
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (local.set $4
                                     (struct.get $type80 1
                                      (local.get $4)
                                     )
                                    )
                                    (local.set $3
                                     (struct.get $type80 1
                                      (local.get $3)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready625)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global625)
                                     )
                                    )
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $4)
                                     )
                                     (then
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                     )
                                     (else
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $3)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global175)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global171)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eqz
                                          (call $function59
                                           (struct.get $type80 0
                                            (local.get $4)
                                           )
                                           (struct.get $type80 0
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (then
                                          (local.set $4
                                           (struct.get $type80 1
                                            (local.get $4)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type80 1
                                            (local.get $3)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready625)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global625)
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $4)
                                           )
                                           (then
                                            (ref.is_null
                                             (local.get $3)
                                            )
                                           )
                                           (else
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $3)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global175)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global171)
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eqz
                                                (call $function59
                                                 (struct.get $type80 0
                                                  (local.get $4)
                                                 )
                                                 (struct.get $type80 0
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                               (then
                                                (local.set $4
                                                 (struct.get $type80 1
                                                  (local.get $4)
                                                 )
                                                )
                                                (local.set $3
                                                 (struct.get $type80 1
                                                  (local.get $3)
                                                 )
                                                )
                                                (if
                                                 (i32.eqz
                                                  (global.get $ready625)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global625)
                                                 )
                                                )
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $4)
                                                 )
                                                 (then
                                                  (ref.is_null
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $3)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global175)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global171)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (i64.eqz
                                                      (call $function59
                                                       (struct.get $type80 0
                                                        (local.get $4)
                                                       )
                                                       (struct.get $type80 0
                                                        (local.get $3)
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (local.set $4
                                                       (struct.get $type80 1
                                                        (local.get $4)
                                                       )
                                                      )
                                                      (local.set $3
                                                       (struct.get $type80 1
                                                        (local.get $3)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (global.get $ready625)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global625)
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $4)
                                                       )
                                                       (then
                                                        (ref.is_null
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $3)
                                                         )
                                                         (then
                                                          (i32.const 0)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global175)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global171)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (i64.eqz
                                                            (call $function59
                                                             (struct.get $type80 0
                                                              (local.get $4)
                                                             )
                                                             (struct.get $type80 0
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                           (then
                                                            (local.set $4
                                                             (struct.get $type80 1
                                                              (local.get $4)
                                                             )
                                                            )
                                                            (local.set $3
                                                             (struct.get $type80 1
                                                              (local.get $3)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (global.get $ready625)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global625)
                                                             )
                                                            )
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $4)
                                                             )
                                                             (then
                                                              (ref.is_null
                                                               (local.get $3)
                                                              )
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (ref.is_null
                                                                (local.get $3)
                                                               )
                                                               (then
                                                                (i32.const 0)
                                                               )
                                                               (else
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global175)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global171)
                                                                 )
                                                                )
                                                                (if (result i32)
                                                                 (i64.eqz
                                                                  (call $function59
                                                                   (struct.get $type80 0
                                                                    (local.get $4)
                                                                   )
                                                                   (struct.get $type80 0
                                                                    (local.get $3)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (local.set $4
                                                                   (struct.get $type80 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                  (local.set $3
                                                                   (struct.get $type80 1
                                                                    (local.get $3)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (global.get $ready625)
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global625)
                                                                   )
                                                                  )
                                                                  (if (result i32)
                                                                   (ref.is_null
                                                                    (local.get $4)
                                                                   )
                                                                   (then
                                                                    (ref.is_null
                                                                     (local.get $3)
                                                                    )
                                                                   )
                                                                   (else
                                                                    (if (result i32)
                                                                     (ref.is_null
                                                                      (local.get $3)
                                                                     )
                                                                     (then
                                                                      (i32.const 0)
                                                                     )
                                                                     (else
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global175)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global171)
                                                                       )
                                                                      )
                                                                      (if (result i32)
                                                                       (i64.eqz
                                                                        (call $function59
                                                                         (struct.get $type80 0
                                                                          (local.get $4)
                                                                         )
                                                                         (struct.get $type80 0
                                                                          (local.get $3)
                                                                         )
                                                                        )
                                                                       )
                                                                       (then
                                                                        (local.set $4
                                                                         (struct.get $type80 1
                                                                          (local.get $4)
                                                                         )
                                                                        )
                                                                        (local.set $3
                                                                         (struct.get $type80 1
                                                                          (local.get $3)
                                                                         )
                                                                        )
                                                                        (if
                                                                         (i32.eqz
                                                                          (global.get $ready625)
                                                                         )
                                                                         (then
                                                                          (unreachable)
                                                                         )
                                                                        )
                                                                        (drop
                                                                         (ref.as_non_null
                                                                          (global.get $global625)
                                                                         )
                                                                        )
                                                                        (if (result i32)
                                                                         (ref.is_null
                                                                          (local.get $4)
                                                                         )
                                                                         (then
                                                                          (ref.is_null
                                                                           (local.get $3)
                                                                          )
                                                                         )
                                                                         (else
                                                                          (if (result i32)
                                                                           (ref.is_null
                                                                            (local.get $3)
                                                                           )
                                                                           (then
                                                                            (i32.const 0)
                                                                           )
                                                                           (else
                                                                            (drop
                                                                             (ref.as_non_null
                                                                              (global.get $global175)
                                                                             )
                                                                            )
                                                                            (drop
                                                                             (ref.as_non_null
                                                                              (global.get $global171)
                                                                             )
                                                                            )
                                                                            (if (result i32)
                                                                             (i64.eqz
                                                                              (call $function59
                                                                               (struct.get $type80 0
                                                                                (local.get $4)
                                                                               )
                                                                               (struct.get $type80 0
                                                                                (local.get $3)
                                                                               )
                                                                              )
                                                                             )
                                                                             (then
                                                                              (local.set $4
                                                                               (struct.get $type80 1
                                                                                (local.get $4)
                                                                               )
                                                                              )
                                                                              (local.set $3
                                                                               (struct.get $type80 1
                                                                                (local.get $3)
                                                                               )
                                                                              )
                                                                              (if
                                                                               (i32.eqz
                                                                                (global.get $ready625)
                                                                               )
                                                                               (then
                                                                                (unreachable)
                                                                               )
                                                                              )
                                                                              (drop
                                                                               (ref.as_non_null
                                                                                (global.get $global625)
                                                                               )
                                                                              )
                                                                              (if (result i32)
                                                                               (ref.is_null
                                                                                (local.get $4)
                                                                               )
                                                                               (then
                                                                                (ref.is_null
                                                                                 (local.get $3)
                                                                                )
                                                                               )
                                                                               (else
                                                                                (if (result i32)
                                                                                 (ref.is_null
                                                                                  (local.get $3)
                                                                                 )
                                                                                 (then
                                                                                  (i32.const 0)
                                                                                 )
                                                                                 (else
                                                                                  (drop
                                                                                   (ref.as_non_null
                                                                                    (global.get $global175)
                                                                                   )
                                                                                  )
                                                                                  (drop
                                                                                   (ref.as_non_null
                                                                                    (global.get $global171)
                                                                                   )
                                                                                  )
                                                                                  (if (result i32)
                                                                                   (i64.eqz
                                                                                    (call $function59
                                                                                     (struct.get $type80 0
                                                                                      (local.get $4)
                                                                                     )
                                                                                     (struct.get $type80 0
                                                                                      (local.get $3)
                                                                                     )
                                                                                    )
                                                                                   )
                                                                                   (then
                                                                                    (local.set $4
                                                                                     (struct.get $type80 1
                                                                                      (local.get $4)
                                                                                     )
                                                                                    )
                                                                                    (local.set $3
                                                                                     (struct.get $type80 1
                                                                                      (local.get $3)
                                                                                     )
                                                                                    )
                                                                                    (if
                                                                                     (i32.eqz
                                                                                      (global.get $ready625)
                                                                                     )
                                                                                     (then
                                                                                      (unreachable)
                                                                                     )
                                                                                    )
                                                                                    (drop
                                                                                     (ref.as_non_null
                                                                                      (global.get $global625)
                                                                                     )
                                                                                    )
                                                                                    (if (result i32)
                                                                                     (ref.is_null
                                                                                      (local.get $4)
                                                                                     )
                                                                                     (then
                                                                                      (ref.is_null
                                                                                       (local.get $3)
                                                                                      )
                                                                                     )
                                                                                     (else
                                                                                      (if (result i32)
                                                                                       (ref.is_null
                                                                                        (local.get $3)
                                                                                       )
                                                                                       (then
                                                                                        (i32.const 0)
                                                                                       )
                                                                                       (else
                                                                                        (drop
                                                                                         (ref.as_non_null
                                                                                          (global.get $global175)
                                                                                         )
                                                                                        )
                                                                                        (drop
                                                                                         (ref.as_non_null
                                                                                          (global.get $global171)
                                                                                         )
                                                                                        )
                                                                                        (if (result i32)
                                                                                         (i64.eqz
                                                                                          (call $function59
                                                                                           (struct.get $type80 0
                                                                                            (local.get $4)
                                                                                           )
                                                                                           (struct.get $type80 0
                                                                                            (local.get $3)
                                                                                           )
                                                                                          )
                                                                                         )
                                                                                         (then
                                                                                          (local.set $4
                                                                                           (struct.get $type80 1
                                                                                            (local.get $4)
                                                                                           )
                                                                                          )
                                                                                          (local.set $3
                                                                                           (struct.get $type80 1
                                                                                            (local.get $3)
                                                                                           )
                                                                                          )
                                                                                          (if
                                                                                           (i32.eqz
                                                                                            (global.get $ready625)
                                                                                           )
                                                                                           (then
                                                                                            (unreachable)
                                                                                           )
                                                                                          )
                                                                                          (drop
                                                                                           (ref.as_non_null
                                                                                            (global.get $global625)
                                                                                           )
                                                                                          )
                                                                                          (if (result i32)
                                                                                           (ref.is_null
                                                                                            (local.get $4)
                                                                                           )
                                                                                           (then
                                                                                            (ref.is_null
                                                                                             (local.get $3)
                                                                                            )
                                                                                           )
                                                                                           (else
                                                                                            (if (result i32)
                                                                                             (ref.is_null
                                                                                              (local.get $3)
                                                                                             )
                                                                                             (then
                                                                                              (i32.const 0)
                                                                                             )
                                                                                             (else
                                                                                              (drop
                                                                                               (ref.as_non_null
                                                                                                (global.get $global175)
                                                                                               )
                                                                                              )
                                                                                              (if (result i32)
                                                                                               (call $function60
                                                                                                (struct.get $type80 0
                                                                                                 (local.get $4)
                                                                                                )
                                                                                                (struct.get $type80 0
                                                                                                 (local.get $3)
                                                                                                )
                                                                                               )
                                                                                               (then
                                                                                                (call $function200
                                                                                                 (struct.get $type80 1
                                                                                                  (local.get $4)
                                                                                                 )
                                                                                                 (block (result (ref null $type80))
                                                                                                  (local.set $scratch
                                                                                                   (struct.get $type80 1
                                                                                                    (local.get $3)
                                                                                                   )
                                                                                                  )
                                                                                                  (if
                                                                                                   (i32.eqz
                                                                                                    (global.get $ready625)
                                                                                                   )
                                                                                                   (then
                                                                                                    (unreachable)
                                                                                                   )
                                                                                                  )
                                                                                                  (drop
                                                                                                   (ref.as_non_null
                                                                                                    (global.get $global625)
                                                                                                   )
                                                                                                  )
                                                                                                  (local.get $scratch)
                                                                                                 )
                                                                                                )
                                                                                               )
                                                                                               (else
                                                                                                (i32.const 0)
                                                                                               )
                                                                                              )
                                                                                             )
                                                                                            )
                                                                                           )
                                                                                          )
                                                                                         )
                                                                                         (else
                                                                                          (i32.const 0)
                                                                                         )
                                                                                        )
                                                                                       )
                                                                                      )
                                                                                     )
                                                                                    )
                                                                                   )
                                                                                   (else
                                                                                    (i32.const 0)
                                                                                   )
                                                                                  )
                                                                                 )
                                                                                )
                                                                               )
                                                                              )
                                                                             )
                                                                             (else
                                                                              (i32.const 0)
                                                                             )
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                       (else
                                                                        (i32.const 0)
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                 (else
                                                                  (i32.const 0)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (else
                                                            (i32.const 0)
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (else
                                                      (i32.const 0)
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (i32.const 0)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function199 (type $call84) (param $0 i64) (param $1 i64) (param $2 i64) (result (ref null $type80))
  (local $3 i64)
  (local $4 (ref $type29))
  (if (result (ref null $type80))
   (i64.gt_s
    (local.get $0)
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type80
     (call $function171
      (struct.get $type38 1
       (global.get $global582)
      )
      (local.get $0)
     )
     (block (result (ref null $type80))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $0)
          (local.tee $3
           (i64.add
            (local.get $0)
            (local.get $2)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready621)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global621)
       )
      )
      (call $function199
       (local.get $3)
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function200 (type $call85) (param $0 (ref null $type80)) (param $1 (ref null $type80)) (result i32)
  (local $scratch (ref null $type80))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global175)
       )
      )
      (if (result i32)
       (call $function60
        (struct.get $type80 0
         (local.get $0)
        )
        (struct.get $type80 0
         (local.get $1)
        )
       )
       (then
        (return_call $function200
         (struct.get $type80 1
          (local.get $0)
         )
         (block (result (ref null $type80))
          (local.set $scratch
           (struct.get $type80 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready625)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global625)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type108))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready616)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global616)
   )
  )
  (if (result i64)
   (i64.le_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i64.const 0)
   )
   (else
    (struct.set $type108 1
     (local.tee $1
      (struct.new_default $type108)
     )
     (struct.new $type106
      (struct.new $environment198
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (struct.set $type108 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type108 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function198
     (struct.get $type106 0
      (struct.get $type108 1
       (local.get $1)
      )
     )
     (i64.const 0)
     (ref.null none)
    )
   )
  )
 )
 (func $export1
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready628)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global628)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global603)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global596)
   )
  )
  (call $function191
   (struct.get $type89 0
    (global.get $global615)
   )
  )
  (call $foreign2
   (i32.const 10)
  )
 )
 (func $main
  (local $0 (ref $environment195))
  (local $1 (ref $type29))
  (local $2 (ref $type29))
  (local $3 (ref $type105))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type11)
  )
  (global.set $global391
   (struct.new_default $type13)
  )
  (global.set $global61
   (struct.new_default $type15)
  )
  (global.set $global63
   (struct.new_default $type19)
  )
  (global.set $global65
   (struct.new_default $type20)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global108
   (struct.new $type29
    (i32.const 0)
    (array.new_fixed $type14 0)
   )
  )
  (global.set $global109
   (struct.new_default $type30)
  )
  (global.set $global112
   (struct.new_default $type31)
  )
  (global.set $global116
   (struct.new_default $type32)
  )
  (global.set $global118
   (struct.new_default $type33)
  )
  (global.set $global122
   (struct.new_default $type13)
  )
  (global.set $global126
   (struct.new_default $type34)
  )
  (global.set $global130
   (struct.new_default $type35)
  )
  (global.set $global132
   (struct.new_default $type36)
  )
  (global.set $global134
   (struct.new_default $type36)
  )
  (global.set $global136
   (struct.new_default $type37)
  )
  (global.set $global141
   (struct.new $type38
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type40)
  )
  (global.set $global171
   (struct.new_default $type41)
  )
  (global.set $global175
   (struct.new_default $type42)
  )
  (global.set $global187
   (struct.new_default $type42)
  )
  (global.set $global190
   (struct.new_default $type30)
  )
  (global.set $global193
   (struct.new_default $type43)
  )
  (global.set $global202
   (struct.new_default $type43)
  )
  (global.set $global211
   (struct.new_default $type44)
  )
  (global.set $global215
   (struct.new_default $type45)
  )
  (global.set $global222
   (struct.new_default $type45)
  )
  (global.set $global225
   (struct.new_default $type46)
  )
  (global.set $global236
   (struct.new_default $type43)
  )
  (global.set $global242
   (struct.new_default $type45)
  )
  (global.set $global245
   (struct.new_default $type47)
  )
  (global.set $global254
   (struct.new_default $type48)
  )
  (global.set $global262
   (struct.new_default $type48)
  )
  (global.set $global274
   (struct.new_default $type49)
  )
  (global.set $global286
   (struct.new_default $type50)
  )
  (global.set $global295
   (struct.new_default $type48)
  )
  (global.set $global300
   (struct.new_default $type51)
  )
  (global.set $global306
   (struct.new_default $type52)
  )
  (global.set $global315
   (struct.new_default $type54)
  )
  (global.set $global324
   (struct.new_default $type54)
  )
  (global.set $global330
   (struct.new_default $type45)
  )
  (global.set $global336
   (struct.new_default $type55)
  )
  (global.set $global344
   (struct.new_default $type56)
  )
  (global.set $global350
   (struct.new_default $type57)
  )
  (global.set $global361
   (struct.new_default $type58)
  )
  (global.set $global385
   (struct.new_default $type62)
  )
  (global.set $global395
   (struct.new_default $type37)
  )
  (global.set $global400
   (struct.new_default $type64)
  )
  (global.set $global405
   (struct.new_default $type65)
  )
  (global.set $global414
   (struct.new_default $type66)
  )
  (global.set $ready414
   (i32.const 1)
  )
  (global.set $global419
   (struct.new_default $type67)
  )
  (global.set $global425
   (struct.new_default $type36)
  )
  (global.set $global429
   (struct.new_default $type45)
  )
  (global.set $ready429
   (i32.const 1)
  )
  (global.set $global440
   (struct.new_default $type68)
  )
  (global.set $global443
   (struct.new_default $type37)
  )
  (global.set $global448
   (struct.new_default $type36)
  )
  (global.set $global456
   (struct.new_default $type36)
  )
  (global.set $global567
   (struct.new_default $type79)
  )
  (global.set $global573
   (struct.new_default $type81)
  )
  (global.set $global576
   (struct.new_default $type81)
  )
  (global.set $global553
   (struct.new_default $type82)
  )
  (global.set $global556
   (struct.new $type38
    (ref.func $function155)
    (ref.null none)
   )
  )
  (global.set $global558
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 13591409)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global559
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 545140134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global560
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 640320)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 640320)
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready429)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global429)
   )
  )
  (global.set $global561
   (if (result (ref $type29))
    (struct.get $type29 0
     (local.get $1)
    )
    (then
     (unreachable)
    )
    (else
     (call $function120
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
      (local.get $1)
      (call $function53
       (struct.get $type38 1
        (global.get $global141)
       )
       (i64.const 1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global562
   (call $function53
    (struct.get $type38 1
     (global.get $global141)
    )
    (i64.const 12)
   )
  )
  (global.set $global563
   (struct.new_default $type83)
  )
  (global.set $ready563
   (i32.const 1)
  )
  (global.set $global582
   (struct.new $type38
    (ref.func $function171)
    (ref.null none)
   )
  )
  (global.set $global621
   (struct.new_default $type84)
  )
  (global.set $ready621
   (i32.const 1)
  )
  (global.set $global590
   (struct.new $type38
    (ref.func $function180)
    (ref.null none)
   )
  )
  (global.set $global625
   (struct.new_default $type85)
  )
  (global.set $ready625
   (i32.const 1)
  )
  (global.set $global596
   (struct.new_default $type86)
  )
  (global.set $global603
   (struct.new_default $type87)
  )
  (global.set $global609
   (call $foreign5
    (i32.const 0)
   )
  )
  (global.set $global610
   (call $foreign5
    (i32.const 1)
   )
  )
  (global.set $global611
   (call $foreign5
    (i32.const 2)
   )
  )
  (struct.set $type105 1
   (local.tee $3
    (struct.new_default $type105)
   )
   (struct.new $type104
    (struct.new $environment195
     (local.get $3)
    )
   )
  )
  (struct.set $type105 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type105 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (struct.get $type104 0
    (struct.get $type105 1
     (local.get $3)
    )
   )
  )
  (global.set $global612
   (if (result (ref null $type80))
    (i64.eqz
     (call $foreign3)
    )
    (then
     (ref.null none)
    )
    (else
     (struct.new $type80
      (call $function180
       (struct.get $type38 1
        (global.get $global590)
       )
       (i64.const 0)
      )
      (block (result (ref null $type80))
       (if
        (i32.eqz
         (struct.get $type105 0
          (struct.get $environment195 0
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $0
        (struct.get $type104 0
         (struct.get $type105 1
          (struct.get $environment195 0
           (local.get $0)
          )
         )
        )
       )
       (if (result (ref null $type80))
        (i64.eq
         (call $foreign3)
         (i64.const 1)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type80
          (call $function180
           (struct.get $type38 1
            (global.get $global590)
           )
           (i64.const 1)
          )
          (block (result (ref null $type80))
           (if
            (i32.eqz
             (struct.get $type105 0
              (struct.get $environment195 0
               (local.get $0)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $0
            (struct.get $type104 0
             (struct.get $type105 1
              (struct.get $environment195 0
               (local.get $0)
              )
             )
            )
           )
           (if (result (ref null $type80))
            (i64.eq
             (call $foreign3)
             (i64.const 2)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type80
              (call $function180
               (struct.get $type38 1
                (global.get $global590)
               )
               (i64.const 2)
              )
              (block (result (ref null $type80))
               (if
                (i32.eqz
                 (struct.get $type105 0
                  (struct.get $environment195 0
                   (local.get $0)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $0
                (struct.get $type104 0
                 (struct.get $type105 1
                  (struct.get $environment195 0
                   (local.get $0)
                  )
                 )
                )
               )
               (if (result (ref null $type80))
                (i64.eq
                 (call $foreign3)
                 (i64.const 3)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type80
                  (call $function180
                   (struct.get $type38 1
                    (global.get $global590)
                   )
                   (i64.const 3)
                  )
                  (block (result (ref null $type80))
                   (if
                    (i32.eqz
                     (struct.get $type105 0
                      (struct.get $environment195 0
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $0
                    (struct.get $type104 0
                     (struct.get $type105 1
                      (struct.get $environment195 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (if (result (ref null $type80))
                    (i64.eq
                     (call $foreign3)
                     (i64.const 4)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type80
                      (call $function180
                       (struct.get $type38 1
                        (global.get $global590)
                       )
                       (i64.const 4)
                      )
                      (block (result (ref null $type80))
                       (if
                        (i32.eqz
                         (struct.get $type105 0
                          (struct.get $environment195 0
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $0
                        (struct.get $type104 0
                         (struct.get $type105 1
                          (struct.get $environment195 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (if (result (ref null $type80))
                        (i64.eq
                         (call $foreign3)
                         (i64.const 5)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type80
                          (call $function180
                           (struct.get $type38 1
                            (global.get $global590)
                           )
                           (i64.const 5)
                          )
                          (block (result (ref null $type80))
                           (if
                            (i32.eqz
                             (struct.get $type105 0
                              (struct.get $environment195 0
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $0
                            (struct.get $type104 0
                             (struct.get $type105 1
                              (struct.get $environment195 0
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (if (result (ref null $type80))
                            (i64.eq
                             (call $foreign3)
                             (i64.const 6)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type80
                              (call $function180
                               (struct.get $type38 1
                                (global.get $global590)
                               )
                               (i64.const 6)
                              )
                              (block (result (ref null $type80))
                               (if
                                (i32.eqz
                                 (struct.get $type105 0
                                  (struct.get $environment195 0
                                   (local.get $0)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $0
                                (struct.get $type104 0
                                 (struct.get $type105 1
                                  (struct.get $environment195 0
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (if (result (ref null $type80))
                                (i64.eq
                                 (call $foreign3)
                                 (i64.const 7)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type80
                                  (call $function180
                                   (struct.get $type38 1
                                    (global.get $global590)
                                   )
                                   (i64.const 7)
                                  )
                                  (block (result (ref null $type80))
                                   (if
                                    (i32.eqz
                                     (struct.get $type105 0
                                      (struct.get $environment195 0
                                       (local.get $0)
                                      )
                                     )
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (local.set $0
                                    (struct.get $type104 0
                                     (struct.get $type105 1
                                      (struct.get $environment195 0
                                       (local.get $0)
                                      )
                                     )
                                    )
                                   )
                                   (if (result (ref null $type80))
                                    (i64.eq
                                     (call $foreign3)
                                     (i64.const 8)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type80
                                      (call $function180
                                       (struct.get $type38 1
                                        (global.get $global590)
                                       )
                                       (i64.const 8)
                                      )
                                      (block (result (ref null $type80))
                                       (if
                                        (i32.eqz
                                         (struct.get $type105 0
                                          (struct.get $environment195 0
                                           (local.get $0)
                                          )
                                         )
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (local.set $0
                                        (struct.get $type104 0
                                         (struct.get $type105 1
                                          (struct.get $environment195 0
                                           (local.get $0)
                                          )
                                         )
                                        )
                                       )
                                       (if (result (ref null $type80))
                                        (i64.eq
                                         (call $foreign3)
                                         (i64.const 9)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type80
                                          (call $function180
                                           (struct.get $type38 1
                                            (global.get $global590)
                                           )
                                           (i64.const 9)
                                          )
                                          (block (result (ref null $type80))
                                           (if
                                            (i32.eqz
                                             (struct.get $type105 0
                                              (struct.get $environment195 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (local.set $0
                                            (struct.get $type104 0
                                             (struct.get $type105 1
                                              (struct.get $environment195 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (if (result (ref null $type80))
                                            (i64.eq
                                             (call $foreign3)
                                             (i64.const 10)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type80
                                              (call $function180
                                               (struct.get $type38 1
                                                (global.get $global590)
                                               )
                                               (i64.const 10)
                                              )
                                              (block (result (ref null $type80))
                                               (if
                                                (i32.eqz
                                                 (struct.get $type105 0
                                                  (struct.get $environment195 0
                                                   (local.get $0)
                                                  )
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (local.set $0
                                                (struct.get $type104 0
                                                 (struct.get $type105 1
                                                  (struct.get $environment195 0
                                                   (local.get $0)
                                                  )
                                                 )
                                                )
                                               )
                                               (if (result (ref null $type80))
                                                (i64.eq
                                                 (call $foreign3)
                                                 (i64.const 11)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (struct.new $type80
                                                  (call $function180
                                                   (struct.get $type38 1
                                                    (global.get $global590)
                                                   )
                                                   (i64.const 11)
                                                  )
                                                  (block (result (ref null $type80))
                                                   (if
                                                    (i32.eqz
                                                     (struct.get $type105 0
                                                      (struct.get $environment195 0
                                                       (local.get $0)
                                                      )
                                                     )
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (local.set $0
                                                    (struct.get $type104 0
                                                     (struct.get $type105 1
                                                      (struct.get $environment195 0
                                                       (local.get $0)
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (if (result (ref null $type80))
                                                    (i64.eq
                                                     (call $foreign3)
                                                     (i64.const 12)
                                                    )
                                                    (then
                                                     (ref.null none)
                                                    )
                                                    (else
                                                     (struct.new $type80
                                                      (call $function180
                                                       (struct.get $type38 1
                                                        (global.get $global590)
                                                       )
                                                       (i64.const 12)
                                                      )
                                                      (block (result (ref null $type80))
                                                       (if
                                                        (i32.eqz
                                                         (struct.get $type105 0
                                                          (struct.get $environment195 0
                                                           (local.get $0)
                                                          )
                                                         )
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (local.set $0
                                                        (struct.get $type104 0
                                                         (struct.get $type105 1
                                                          (struct.get $environment195 0
                                                           (local.get $0)
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (if (result (ref null $type80))
                                                        (i64.eq
                                                         (call $foreign3)
                                                         (i64.const 13)
                                                        )
                                                        (then
                                                         (ref.null none)
                                                        )
                                                        (else
                                                         (struct.new $type80
                                                          (call $function180
                                                           (struct.get $type38 1
                                                            (global.get $global590)
                                                           )
                                                           (i64.const 13)
                                                          )
                                                          (block (result (ref null $type80))
                                                           (if
                                                            (i32.eqz
                                                             (struct.get $type105 0
                                                              (struct.get $environment195 0
                                                               (local.get $0)
                                                              )
                                                             )
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (local.set $0
                                                            (struct.get $type104 0
                                                             (struct.get $type105 1
                                                              (struct.get $environment195 0
                                                               (local.get $0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (if (result (ref null $type80))
                                                            (i64.eq
                                                             (call $foreign3)
                                                             (i64.const 14)
                                                            )
                                                            (then
                                                             (ref.null none)
                                                            )
                                                            (else
                                                             (struct.new $type80
                                                              (call $function180
                                                               (struct.get $type38 1
                                                                (global.get $global590)
                                                               )
                                                               (i64.const 14)
                                                              )
                                                              (block (result (ref null $type80))
                                                               (if
                                                                (i32.eqz
                                                                 (struct.get $type105 0
                                                                  (struct.get $environment195 0
                                                                   (local.get $0)
                                                                  )
                                                                 )
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (call $function195
                                                                (struct.get $type104 0
                                                                 (struct.get $type105 1
                                                                  (struct.get $environment195 0
                                                                   (local.get $0)
                                                                  )
                                                                 )
                                                                )
                                                                (i64.const 15)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $global615
   (struct.new_default $type89)
  )
  (global.set $global616
   (struct.new_default $type37)
  )
  (global.set $ready616
   (i32.const 1)
  )
  (global.set $global628
   (struct.new_default $type10)
  )
  (global.set $ready628
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

