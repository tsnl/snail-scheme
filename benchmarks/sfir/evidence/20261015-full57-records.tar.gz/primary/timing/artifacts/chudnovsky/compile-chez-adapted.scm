(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-checked-full57-20261015-v1/timing/artifacts/chudnovsky/chez-adapted.scm" "/tmp/sfir-checked-full57-20261015-v1/timing/artifacts/chudnovsky/chez-adapted.so"))
