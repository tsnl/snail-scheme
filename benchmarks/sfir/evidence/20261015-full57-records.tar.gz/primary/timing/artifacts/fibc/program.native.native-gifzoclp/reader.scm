(module
 (rec
  (type $type28 (sub (struct (field i32))))
  (type $1 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call34 (func (param i64 (ref $type28)) (result i64)))
  (type $type31 (sub $type28 (struct (field i32) (field i64) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field i32) (field i64) (field (ref $type28)))))
  (type $call35 (func (param (ref $type28) i64) (result i64)))
  (type $call33 (func (param i64 i64 (ref $type28)) (result i64)))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type27 (struct))
  (type $type29 (sub $type28 (struct (field i32))))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (result i32)))
 (type $16 (func (param i32) (result i64)))
 (type $17 (func))
 (import "benchmark" "barrier" (func $foreign0 (result i32)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty29 (ref $type29) (struct.new $type29
  (i32.const 0)
 ))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global108 (mut (ref null $type32)) (ref.null none))
 (global $global110 (mut (ref null $type32)) (ref.null none))
 (global $global112 (mut (ref null $type33)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type34)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type35)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global127 (mut i64) (i64.const 0))
 (global $global128 (mut (ref null $type36)) (ref.null none))
 (global $global129 (mut (ref null $type32)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function44 (type $call33) (param $0 i64) (param $1 i64) (param $2 (ref $type28)) (result i64)
  (local $3 i64)
  (if
   (i64.eqz
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (return_call $function45
     (local.get $2)
     (local.get $0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global108)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $0)
        (local.tee $3
         (i64.add
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $0
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (return_call $function44
     (local.get $3)
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function45 (type $call35) (param $0 (ref $type28)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type30))
  (local $6 (ref $type31))
  (if (result i64)
   (local.tee $4
    (struct.get $type28 0
     (local.get $0)
    )
   )
   (then
    (if
     (i32.eq
      (local.get $4)
      (i32.const 1)
     )
     (then
      (local.set $0
       (struct.get $type30 2
        (local.tee $5
         (ref.cast (ref $type30)
          (local.get $0)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (struct.get $type30 1
            (local.get $5)
           )
          )
          (local.tee $3
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $3)
            (i64.const 1)
           )
          )
          (local.get $3)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function46
       (local.get $2)
       (struct.new $type31
        (i32.const 2)
        (local.get $1)
        (local.get $0)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (return_call $function44
       (struct.get $type31 1
        (local.tee $6
         (ref.cast (ref $type31)
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (struct.get $type31 2
        (local.get $6)
       )
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $function46 (type $call34) (param $0 i64) (param $1 (ref $type28)) (result i64)
  (local $2 i64)
  (if
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (return_call $function45
     (local.get $1)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.eqz
      (local.get $2)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready116)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (return_call $function45
       (local.get $1)
       (i64.const 1)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global110)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (if
       (i32.eqz
        (global.get $ready122)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (return_call $function46
       (local.get $2)
       (struct.new $type30
        (i32.const 1)
        (local.get $0)
        (local.get $1)
       )
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function49 (type $1) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function46
      (call $foreign1
       (global.get $global127)
      )
      (block (result (ref $type29))
       (drop
        (ref.as_non_null
         (global.get $global128)
        )
       )
       (drop
        (call $foreign0)
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (global.get $empty29)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
     (local.get $3)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (return_call $function49
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global108
   (struct.new_default $type32)
  )
  (global.set $global110
   (struct.new_default $type32)
  )
  (global.set $global112
   (struct.new_default $type33)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type34)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type35)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global127
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $global128
   (struct.new_default $type36)
  )
  (global.set $global129
   (struct.new_default $type32)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

