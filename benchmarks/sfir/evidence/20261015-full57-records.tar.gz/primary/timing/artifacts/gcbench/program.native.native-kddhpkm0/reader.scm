(module
 (rec
  (type $type28 (sub (struct)))
  (type $environment89 (struct (field i64) (field (ref $type52))))
  (type $environment83 (struct (field (ref $type44)) (field (ref $type45)) (field (ref $type40)) (field i64) (field i64) (field (ref $type52))))
  (type $environment79 (struct (field (ref $type44)) (field (ref $type40)) (field i64) (field i64) (field (ref $type52))))
  (type $4 (func (param (ref $type44) (ref $type40) i64 (ref $type28)) (result i32)))
  (type $5 (func (param (ref $type44) (ref $type45) (ref $type40) i64) (result (ref $type30))))
  (type $call36 (func (param (ref null $environment55) i64 i64) (result i64)))
  (type $environment55 (struct (field (ref $type42))))
  (type $type42 (struct (field (mut i32)) (field (mut (ref null $type36)))))
  (type $environment73 (struct (field i64) (field i64) (field (ref $type44)) (field (ref $type45)) (field (ref $type40)) (field (ref $type40)) (field (ref $type52))))
  (type $environment71 (struct (field i64) (field (ref $type48)) (field (ref $type52))))
  (type $type30 (sub $type28 (struct (field (ref $type31)) (field (ref $type31)))))
  (type $type31 (struct (field (mut (ref $type28)))))
  (type $type40 (struct))
  (type $type45 (struct))
  (type $type48 (array (mut f64)))
  (type $type44 (struct))
  (type $type52 (struct (field (mut i32)) (field (mut (ref null $type39)))))
  (type $call39 (func (param structref i64) (result i32)))
  (type $type39 (struct (field (ref $call39)) (field structref)))
  (type $type10 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct (field (ref $call36)) (field (ref null $environment55))))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type27 (struct))
  (type $type29 (sub $type28 (struct)))
 )
 (type $30 (func (param i64) (result i64)))
 (type $31 (func (param i64 i64)))
 (type $32 (func (param i64)))
 (type $33 (func (param i32) (result i64)))
 (type $34 (func))
 (import "benchmark" "print_text" (func $foreign0 (param i64)))
 (import "benchmark" "print_size" (func $foreign1 (param i64 i64)))
 (import "benchmark" "print_construction" (func $foreign2 (param i64 i64)))
 (import "benchmark" "hide_i64" (func $foreign3 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign4 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty29 (ref $type29) (struct.new_default $type29))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global115 (mut (ref null $type32)) (ref.null none))
 (global $global120 (mut (ref null $type33)) (ref.null none))
 (global $global122 (mut (ref null $type33)) (ref.null none))
 (global $global124 (mut (ref null $type34)) (ref.null none))
 (global $global127 (mut (ref null $type34)) (ref.null none))
 (global $global138 (mut (ref null $type35)) (ref.null none))
 (global $global177 (mut (ref null $type36)) (ref.null none))
 (global $global130 (mut (ref null $type37)) (ref.null none))
 (global $global186 (mut (ref null $type36)) (ref.null none))
 (global $global171 (mut (ref null $type38)) (ref.null none))
 (global $global132 (mut (ref null $type10)) (ref.null none))
 (global $global133 (mut (ref null $type39)) (ref.null none))
 (global $global181 (mut i64) (i64.const 0))
 (global $global182 (mut (ref null $type35)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function50 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type52))
  (local $3 (ref $type39))
  (local $4 (ref $type44))
  (local $5 (ref $type48))
  (local $6 (ref $type45))
  (local $7 (ref $type40))
  (local $8 (ref $type40))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 f64)
  (local $13 f64)
  (local $14 f64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $10
       (i64.sub
        (local.get $1)
        (i64.const 2)
       )
      )
      (local.get $1)
     )
     (i64.xor
      (local.get $1)
      (i64.const 2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $9
   (i64.shl
    (local.tee $11
     (call $function52
      (local.get $10)
     )
    )
    (i64.const 2)
   )
  )
  (if
   (i64.ne
    (local.get $11)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $9)
       (local.get $11)
      )
      (i64.const 4)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (call $foreign0
   (i64.const 3)
  )
  (call $foreign0
   (i64.const 0)
  )
  (call $foreign1
   (i64.const 0)
   (local.get $1)
  )
  (call $foreign0
   (i64.const 0)
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (call $foreign0
   (i64.const 6)
  )
  (call $foreign0
   (i64.const 0)
  )
  (drop
   (call $function65
    (local.tee $4
     (struct.new_default $type44)
    )
    (local.tee $6
     (struct.new_default $type45)
    )
    (local.tee $7
     (struct.new_default $type40)
    )
    (local.get $1)
   )
  )
  (call $foreign1
   (i64.const 1)
   (local.get $10)
  )
  (call $foreign0
   (i64.const 0)
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (drop
   (call $function67
    (local.get $4)
    (local.tee $8
     (struct.new_default $type40)
    )
    (local.get $10)
    (struct.new $type30
     (struct.new $type31
      (global.get $empty29)
     )
     (struct.new $type31
      (global.get $empty29)
     )
    )
   )
  )
  (call $foreign1
   (i64.const 2)
   (local.get $9)
  )
  (call $foreign0
   (i64.const 0)
  )
  (if
   (i64.gt_u
    (local.get $9)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type52 1
   (local.tee $2
    (struct.new_default $type52)
   )
   (struct.new $type39
    (ref.func $function71)
    (struct.new $environment71
     (local.get $9)
     (local.tee $5
      (array.new_default $type48
       (i32.wrap_i64
        (local.get $9)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type52 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call39
    (struct.get $type39 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type52 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type39 0
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (struct.set $type52 1
   (local.tee $2
    (struct.new_default $type52)
   )
   (struct.new $type39
    (ref.func $function73)
    (struct.new $environment73
     (local.get $1)
     (local.get $10)
     (local.get $4)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $2)
    )
   )
  )
  (struct.set $type52 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call39
    (struct.get $type39 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type52 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 4)
    (struct.get $type39 0
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (drop
   (struct.get $type36 1
    (global.get $global177)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (select
      (i64.const 1000)
      (local.tee $1
       (i64.sub
        (i64.shr_u
         (i64.extend_i32_u
          (array.len
           (local.get $5)
          )
         )
         (i64.const 1)
        )
        (i64.const 1)
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 1000)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (f64.ne
    (array.get $type48
     (local.get $5)
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (block (result f64)
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $1)
         (local.tee $9
          (i64.add
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (i64.xor
         (local.get $9)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (if
      (i32.and
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $14
           (f64.div
            (f64.const 1.0)
            (local.tee $12
             (f64.convert_i64_s
              (local.get $9)
             )
            )
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $12)
         )
         (f64.const inf)
        )
       )
       (f64.ne
        (local.get $12)
        (f64.const 0.0)
       )
      )
      (then
       (unreachable)
      )
     )
     (local.get $14)
    )
   )
   (then
    (call $foreign0
     (i64.const 7)
    )
    (call $foreign0
     (i64.const 0)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (call $foreign0
   (i64.const 1)
  )
  (call $foreign0
   (i64.const 2)
  )
  (call $foreign0
   (i64.const 0)
  )
  (i32.const 0)
 )
 (func $function52 (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 (ref $type42))
  (local $3 (ref $type36))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $0)
      (local.tee $1
       (i64.add
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (struct.set $type42 1
   (local.tee $2
    (struct.new_default $type42)
   )
   (struct.new $type36
    (ref.func $function55)
    (struct.new $environment55
     (local.get $2)
    )
   )
  )
  (struct.set $type42 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type42 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $1
       (i64.sub
        (local.tee $0
         (call_ref $call36
          (struct.get $type36 1
           (local.tee $3
            (ref.as_non_null
             (struct.get $type42 1
              (local.get $2)
             )
            )
           )
          )
          (local.get $1)
          (i64.const 1)
          (struct.get $type36 0
           (local.get $3)
          )
         )
        )
        (i64.const 1)
       )
      )
      (local.get $0)
     )
     (i64.xor
      (local.get $0)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.get $1)
 )
 (func $function55 (type $call36) (param $0 (ref null $environment55)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.tee $1
        (i64.shl
         (local.get $2)
         (i64.const 1)
        )
       )
       (i64.const 2)
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type42 0
       (struct.get $environment55 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type36 1
      (struct.get $type42 1
       (struct.get $environment55 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
 )
 (func $function65 (type $5) (param $0 (ref $type44)) (param $1 (ref $type45)) (param $2 (ref $type40)) (param $3 i64) (result (ref $type30))
  (local $4 i64)
  (local $5 (ref $type30))
  (local $6 (ref $type30))
  (local $scratch (ref $type30))
  (if (result (ref $type30))
   (i64.le_s
    (local.get $3)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (struct.new $type30
     (struct.new $type31
      (global.get $empty29)
     )
     (struct.new $type31
      (global.get $empty29)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (struct.new $type31
      (block (result (ref $type30))
       (local.set $scratch
        (call $function65
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $4)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $4
            (i64.sub
             (local.get $3)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
          (i64.xor
           (local.get $3)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (local.set $6
        (call $function65
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $4)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global115)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.new $type31
      (local.get $6)
     )
    )
   )
  )
 )
 (func $function67 (type $4) (param $0 (ref $type44)) (param $1 (ref $type40)) (param $2 i64) (param $3 (ref $type28)) (result i32)
  (local $4 i64)
  (local $5 (ref $type30))
  (local $6 (ref $type31))
  (if (result i32)
   (i64.le_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type29)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type31 0
     (struct.get $type30 0
      (local.tee $5
       (ref.cast (ref $type30)
        (local.get $3)
       )
      )
     )
     (struct.new $type30
      (struct.new $type31
       (global.get $empty29)
      )
      (struct.new $type31
       (global.get $empty29)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (struct.set $type31 0
     (local.tee $6
      (struct.get $type30 1
       (local.get $5)
      )
     )
     (struct.new $type30
      (struct.new $type31
       (global.get $empty29)
      )
      (struct.new $type31
       (global.get $empty29)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (drop
     (call $function67
      (local.get $0)
      (local.get $1)
      (local.get $4)
      (struct.get $type31 0
       (struct.get $type30 0
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (struct.get $type31 0
      (local.get $6)
     )
    )
   )
  )
 )
 (func $function71 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 f64)
  (local $4 f64)
  (local $5 (ref $type48))
  (if (result i32)
   (i64.le_s
    (i64.div_s
     (struct.get $environment71 0
      (ref.cast (ref $environment71)
       (local.get $0)
      )
     )
     (i64.const 2)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type48
     (struct.get $environment71 1
      (ref.cast (ref $environment71)
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.eq
          (f64.abs
           (local.tee $4
            (f64.div
             (f64.const 1.0)
             (local.tee $3
              (f64.convert_i64_s
               (local.get $2)
              )
             )
            )
           )
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $3)
          )
          (f64.const inf)
         )
        )
        (f64.ne
         (local.get $3)
         (f64.const 0.0)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment71 2
        (ref.cast (ref $environment71)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (struct.get $type39 1
      (struct.get $type52 1
       (struct.get $environment71 2
        (ref.cast (ref $environment71)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function73 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type52))
  (local $3 (ref $environment73))
  (local $4 (ref $type39))
  (local $5 (ref $type44))
  (local $6 i64)
  (local $7 i64)
  (if (result i32)
   (i64.lt_s
    (struct.get $environment73 1
     (ref.cast (ref $environment73)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $7
     (i64.shl
      (local.tee $6
       (call $function52
        (struct.get $environment73 0
         (local.tee $3
          (ref.cast (ref $environment73)
           (local.get $0)
          )
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.ne
      (local.get $6)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $7)
         (local.get $6)
        )
        (i64.const 2)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (call $foreign2
     (local.tee $6
      (i64.div_s
       (local.get $7)
       (call $function52
        (local.get $1)
       )
      )
     )
     (local.get $1)
    )
    (call $foreign0
     (i64.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (call $foreign0
     (i64.const 4)
    )
    (call $foreign0
     (i64.const 0)
    )
    (struct.set $type52 1
     (local.tee $2
      (struct.new_default $type52)
     )
     (struct.new $type39
      (ref.func $function79)
      (struct.new $environment79
       (local.tee $5
        (struct.get $environment73 2
         (local.get $3)
        )
       )
       (struct.get $environment73 5
        (local.get $3)
       )
       (local.get $1)
       (local.get $6)
       (local.get $2)
      )
     )
    )
    (struct.set $type52 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call39
      (struct.get $type39 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type52 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type39 0
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (call $foreign0
     (i64.const 5)
    )
    (call $foreign0
     (i64.const 0)
    )
    (struct.set $type52 1
     (local.tee $2
      (struct.new_default $type52)
     )
     (struct.new $type39
      (ref.func $function83)
      (struct.new $environment83
       (local.get $5)
       (struct.get $environment73 3
        (local.get $3)
       )
       (struct.get $environment73 4
        (local.get $3)
       )
       (local.get $1)
       (local.get $6)
       (local.get $2)
      )
     )
    )
    (struct.set $type52 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call39
      (struct.get $type39 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type52 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type39 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 2)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment73 6
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function73
     (struct.get $type39 1
      (struct.get $type52 1
       (struct.get $environment73 6
        (local.get $3)
       )
      )
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function79 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment79))
  (local $3 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $environment79 3
     (ref.cast (ref $environment79)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $environment79 2
      (local.tee $2
       (ref.cast (ref $environment79)
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function67
      (struct.get $environment79 0
       (local.get $2)
      )
      (struct.get $environment79 1
       (local.get $2)
      )
      (local.get $3)
      (struct.new $type30
       (struct.new $type31
        (global.get $empty29)
       )
       (struct.new $type31
        (global.get $empty29)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment79 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (struct.get $type39 1
      (struct.get $type52 1
       (struct.get $environment79 4
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function83 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment83))
  (local $3 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $environment83 4
     (ref.cast (ref $environment83)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $environment83 3
      (local.tee $2
       (ref.cast (ref $environment83)
        (local.get $0)
       )
      )
     )
    )
    (drop
     (call $function65
      (struct.get $environment83 0
       (local.get $2)
      )
      (struct.get $environment83 1
       (local.get $2)
      )
      (struct.get $environment83 2
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment83 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (struct.get $type39 1
      (struct.get $type52 1
       (struct.get $environment83 5
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function85 (type $call36) (param $0 (ref null $environment55)) (param $1 i64) (param $2 i64) (result i64)
  (select
   (local.get $1)
   (local.get $2)
   (i64.lt_s
    (local.get $1)
    (local.get $2)
   )
  )
 )
 (func $function89 (type $call39) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (if (result i32)
   (i64.eq
    (struct.get $environment89 0
     (ref.cast (ref $environment89)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (struct.get $type36 1
      (global.get $global186)
     )
    )
    (drop
     (ref.cast (ref $environment89)
      (local.get $0)
     )
    )
    (local.set $2
     (call $foreign3
      (global.get $global181)
     )
    )
    (drop
     (call $function50
      (struct.get $type39 1
       (global.get $global133)
      )
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type52 0
       (struct.get $environment89 1
        (ref.cast (ref $environment89)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (struct.get $type39 1
      (struct.get $type52 1
       (struct.get $environment89 1
        (ref.cast (ref $environment89)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function90 (type $call36) (param $0 (ref null $environment55)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign3
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type52))
  (local $2 (ref $type39))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global182)
   )
  )
  (struct.set $type52 1
   (local.tee $1
    (struct.new_default $type52)
   )
   (struct.new $type39
    (ref.func $function89)
    (struct.new $environment89
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type52 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type52 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call39
    (struct.get $type39 1
     (local.tee $2
      (ref.as_non_null
       (struct.get $type52 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type39 0
     (local.get $2)
    )
   )
  )
  (i64.const 1)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global115
   (struct.new_default $type32)
  )
  (global.set $global120
   (struct.new_default $type33)
  )
  (global.set $global122
   (struct.new_default $type33)
  )
  (global.set $global124
   (struct.new_default $type34)
  )
  (global.set $global127
   (struct.new_default $type34)
  )
  (global.set $global138
   (struct.new_default $type35)
  )
  (global.set $global177
   (struct.new $type36
    (ref.func $function85)
    (ref.null none)
   )
  )
  (global.set $global130
   (struct.new_default $type37)
  )
  (global.set $global186
   (struct.new $type36
    (ref.func $function90)
    (ref.null none)
   )
  )
  (global.set $global171
   (struct.new_default $type38)
  )
  (global.set $global132
   (struct.new_default $type10)
  )
  (global.set $global133
   (struct.new $type39
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $global181
   (call $foreign4
    (i32.const 0)
   )
  )
  (global.set $global182
   (struct.new_default $type35)
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

