(module
 (rec
  (type $type288 (sub (struct)))
  (type $type294 (sub (struct (field i32))))
  (type $type276 (sub (struct (field i32))))
  (type $type223 (sub (struct (field i32))))
  (type $type13 (sub (struct (field i32))))
  (type $type216 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type32 (sub (struct (field i32))))
  (type $type84 (sub (struct)))
  (type $type325 (struct (field (ref $environment491))))
  (type $type327 (struct (field (mut i32)) (field (mut (ref null $type325)))))
  (type $environment491 (struct (field i64) (field (ref $type327))))
  (type $call325 (func (param (ref $environment491) i64 (ref $type13)) (result i64)))
  (type $call316 (func (param (ref $type68) f64) (result f64)))
  (type $call315 (func (param (ref $type13)) (result f64)))
  (type $call261 (func (param (ref $type68)) (result (ref $type223))))
  (type $call312 (func (param (ref null $type12) (ref $type41) i64) (result (ref $type223))))
  (type $17 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call308 (func (param (ref null $type12) (ref $type36)) (result (ref $type13))))
  (type $type41 (struct (field (ref $type42))))
  (type $type42 (array (mut i8)))
  (type $21 (func (param (ref $type68) i64 (ref null $type12)) (result (ref $type223))))
  (type $call303 (func (param (ref $type68) (ref $type276)) (result (ref $type223))))
  (type $23 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type294))))
  (type $24 (func (param (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $25 (func (param (ref $type68) (ref $type268) i32 i32 i32) (result (ref $type18))))
  (type $call266 (func (param i64) (result i32)))
  (type $call274 (func (param (ref $type68) i64) (result i32)))
  (type $28 (func (param (ref $type268) i32)))
  (type $call299 (func (param (ref $type68) i64) (result (ref $type294))))
  (type $call301 (func (param (ref $type68) i64 i64) (result (ref $type294))))
  (type $call291 (func (param (ref $type68) i32 (ref $type268)) (result (ref $type288))))
  (type $type290 (sub $type288 (struct (field (ref $type18)))))
  (type $type289 (sub $type288 (struct (field (ref $type18)))))
  (type $call286 (func (param (ref $type68) i32 i32) (result (ref $type276))))
  (type $call76 (func (param (ref $type68)) (result i32)))
  (type $call264 (func (param i64 i32) (result i32)))
  (type $call262 (func (param (ref $type84)) (result i64)))
  (type $call263 (func (param (ref $type68)) (result i64)))
  (type $type297 (sub $type294 (struct (field i32) (field (ref $type18)))))
  (type $type295 (sub $type294 (struct (field i32) (field i32))))
  (type $type269 (struct (field (mut (ref $type18)))))
  (type $type277 (sub $type276 (struct (field i32) (field (ref $type13)))))
  (type $type283 (sub $type276 (struct (field i32) (field (ref $type18)))))
  (type $type282 (sub $type276 (struct (field i32) (field (ref $type18)))))
  (type $type281 (sub $type276 (struct (field i32) (field i64))))
  (type $type268 (struct (field (ref $type269)) (field (ref $type228))))
  (type $call275 (func (param (ref $type68)) (result (ref $type276))))
  (type $type226 (sub $type223 (struct (field i32) (field (ref $type18)))))
  (type $type225 (sub $type223 (struct (field i32) (field (ref $type13)))))
  (type $call260 (func (param (ref $type223)) (result (ref $type13))))
  (type $51 (func (param (ref null $type39) i32 i32 i32 (ref null $type12) i64) (result (ref $type39))))
  (type $52 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $type39 (array (mut (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $call46 (func (param (ref null $type12)) (result (ref $type39))))
  (type $type40 (sub $type13 (struct (field i32))))
  (type $type38 (sub $type13 (struct (field i32))))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type21 (sub $type13 (struct (field i32))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type16 (sub $type13 (struct (field i32))))
  (type $type15 (sub $type13 (struct (field i32))))
  (type $call235 (func (param (ref $type13)) (result i32)))
  (type $type36 (sub $type13 (struct (field i32))))
  (type $65 (func (result (ref $type36))))
  (type $type218 (sub $type216 (struct (field i32) (field (ref $type24)))))
  (type $type31 (sub $type24 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $type30 (sub $type24 (struct (field i32) (field f64))))
  (type $type26 (sub $type24 (struct (field i32) (field (ref $type27)))))
  (type $type219 (sub $type216 (struct (field i32) (field (ref $type18)))))
  (type $call215 (func (param i32 i32) (result (ref $type216))))
  (type $73 (func (param i32 i64 i32 (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $type35 (sub $type32 (struct (field i32) (field f64))))
  (type $type34 (sub $type32 (struct (field i32) (field (ref $type27)))))
  (type $type33 (sub $type32 (struct (field i32) (field i64))))
  (type $call212 (func (param i32 i32 i32) (result (ref $type32))))
  (type $78 (func (param i32 i32 i32 i64 i32 (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $79 (func (param (ref $type18) i32 i32 i64 i32 i32 i32 i64) (result i32)))
  (type $type27 (struct (field (ref $type28)) (field (ref $type28))))
  (type $call171 (func (param (ref $type28) (ref $type28)) (result (ref $type27))))
  (type $82 (func (param i32 i32 (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $call169 (func (param (ref $type28) (ref $type28)) (result f64)))
  (type $84 (func (param f64 i32 i32 i32 i64 f64) (result f64)))
  (type $call134 (func (param (ref $type28)) (result i64)))
  (type $86 (func (param i32 i32 (ref $type28) (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $call155 (func (param (ref $type18) i64) (result (ref $type28))))
  (type $88 (func (param (ref $type18) i32 i64 i32 i32 i64 (ref $type28)) (result (ref $type28))))
  (type $89 (func (param (ref $type18) i32 i64 i32 i32 i32 i64 (ref $type28)) (result (ref $type28))))
  (type $90 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $91 (func (param (ref $type18) i64 i32 i32 i64 i64) (result i64)))
  (type $call140 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $type148 (struct (field (ref $type28)) (field (ref $type28))))
  (type $94 (func (param (ref $type28) (ref $type28)) (result (ref $type148))))
  (type $95 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i64) (result i32)))
  (type $96 (func (param (ref $type29) (ref $type29) i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $97 (func (param (ref $type29) (ref $type29) i64 i64 i32 i64 i32 i32 i32 i64 i64) (result i64)))
  (type $98 (func (param (ref $type29) (ref $type29) i64 i32 i32 i64 i64) (result i64)))
  (type $99 (func (param (ref $type29) i64 i64 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type29))))
  (type $100 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i32 i64) (result (ref $type29))))
  (type $101 (func (param (ref $type29) (ref $type29) i64 i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $102 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $103 (func (param (ref $type29) (ref $type29) i64 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type29))))
  (type $call136 (func (param (ref $type28) (ref $type28)) (result i64)))
  (type $105 (func (param (ref $type29) (ref $type29) i32 i32 i64) (result i64)))
  (type $106 (func (param (ref $type29) i32 i32 i32 i64 i32 i32 i32 i64 i64) (result i64)))
  (type $107 (func (param i32 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type28))))
  (type $call133 (func (param i64) (result (ref $type28))))
  (type $109 (func (param i32 i32 i64 i64) (result i64)))
  (type $call112 (func (param i64) (result i64)))
  (type $call131 (func (param (ref $type28)) (result i32)))
  (type $call52 (func (param (ref $type29)) (result (ref $type29))))
  (type $type29 (array (mut i32)))
  (type $114 (func (param (ref $type29) i32 i32 i64) (result i64)))
  (type $type86 (sub $type84 (struct (field i32))))
  (type $type66 (struct (field (mut i32))))
  (type $type68 (struct (field (ref $type66))))
  (type $call88 (func (param (ref $type68)) (result (ref $type84))))
  (type $119 (func (param (ref $type18) i64 i32 i32 i32 i64) (result i32)))
  (type $120 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call63 (func (param (ref $type18) (ref null $type61) i64) (result i32)))
  (type $122 (func (param i32 i32 (ref null $type61) i64) (result i64)))
  (type $type61 (struct (field (ref $type18)) (field (ref null $type61))))
  (type $call60 (func (param (ref $type61)) (result (ref $type18))))
  (type $125 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $type20 (array (mut (ref null $type19))))
  (type $127 (func (param i32) (result (ref $type18))))
  (type $type318 (struct))
  (type $type81 (struct))
  (type $type317 (struct))
  (type $type79 (struct))
  (type $type314 (struct))
  (type $type311 (struct))
  (type $type310 (struct))
  (type $type309 (struct))
  (type $type307 (struct))
  (type $type306 (struct))
  (type $type304 (struct))
  (type $type302 (struct))
  (type $type298 (struct))
  (type $type293 (struct))
  (type $type292 (struct))
  (type $type287 (struct))
  (type $type285 (struct))
  (type $type284 (struct))
  (type $type271 (struct))
  (type $type259 (struct))
  (type $type234 (struct))
  (type $type230 (struct))
  (type $type227 (struct))
  (type $type222 (struct))
  (type $type221 (struct))
  (type $type220 (struct))
  (type $type214 (struct))
  (type $type211 (struct))
  (type $type193 (struct))
  (type $type190 (struct))
  (type $type189 (struct))
  (type $type182 (struct))
  (type $type168 (struct))
  (type $type167 (struct))
  (type $type166 (struct))
  (type $type154 (struct))
  (type $type153 (struct))
  (type $type152 (struct))
  (type $type151 (struct))
  (type $type150 (struct))
  (type $type120 (struct))
  (type $type147 (struct))
  (type $type146 (struct))
  (type $type145 (struct))
  (type $type144 (struct))
  (type $type141 (struct))
  (type $type139 (struct))
  (type $type137 (struct))
  (type $type129 (struct))
  (type $type101 (struct))
  (type $type80 (struct))
  (type $type78 (struct))
  (type $type62 (struct))
  (type $type50 (struct))
  (type $type46 (struct))
  (type $type316 (struct))
  (type $type312 (struct))
  (type $type301 (struct))
  (type $type300 (struct))
  (type $type112 (struct))
  (type $type299 (struct))
  (type $type291 (struct))
  (type $type286 (struct))
  (type $type272 (struct))
  (type $type266 (struct))
  (type $type235 (struct))
  (type $type5 (struct))
  (type $type215 (struct))
  (type $type210 (struct))
  (type $type207 (struct))
  (type $type171 (struct))
  (type $type155 (struct))
  (type $type138 (struct))
  (type $type134 (struct))
  (type $type77 (struct))
  (type $type74 (struct))
  (type $type71 (struct))
  (type $type63 (struct))
  (type $type59 (struct))
  (type $type82 (struct (field i64) (field (ref $type18)) (field (ref $type13))))
  (type $type315 (struct))
  (type $type305 (struct))
  (type $type274 (struct))
  (type $type273 (struct))
  (type $type183 (struct))
  (type $type143 (struct))
  (type $type135 (struct))
  (type $type267 (struct))
  (type $type261 (struct))
  (type $type260 (struct))
  (type $type228 (struct (field (mut i64))))
  (type $type142 (struct))
  (type $type58 (struct))
  (type $type303 (struct))
  (type $type213 (struct))
  (type $type212 (struct))
  (type $type187 (struct))
  (type $type160 (struct))
  (type $type136 (struct))
  (type $type132 (struct))
  (type $type60 (struct))
  (type $type270 (struct))
  (type $type180 (struct))
  (type $type169 (struct))
  (type $type76 (struct))
  (type $type265 (struct))
  (type $type186 (struct))
  (type $type173 (struct))
  (type $type275 (struct))
  (type $type149 (struct))
  (type $type140 (struct))
  (type $type308 (struct))
  (type $type231 (struct))
  (type $type229 (struct))
  (type $type130 (struct))
  (type $type52 (struct))
  (type $type206 (struct))
  (type $type54 (struct))
  (type $type128 (struct))
  (type $type127 (struct))
  (type $type64 (struct))
  (type $type263 (struct))
  (type $type205 (struct))
  (type $type28 (struct (field i32) (field (ref $type29))))
  (type $type133 (struct))
  (type $type88 (struct))
  (type $type262 (struct))
  (type $type131 (struct))
  (type $type126 (struct))
  (type $type87 (struct))
  (type $type264 (struct))
  (type $type296 (sub $type294 (struct (field i32))))
  (type $type280 (sub $type276 (struct (field i32))))
  (type $type279 (sub $type276 (struct (field i32))))
  (type $type278 (sub $type276 (struct (field i32))))
  (type $type224 (sub $type223 (struct (field i32))))
  (type $type217 (sub $type216 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type85 (sub $type84 (struct)))
 )
 (type $269 (func (param i32) (result i32)))
 (type $270 (func (result i32)))
 (type $271 (func (param i32)))
 (type $272 (func (param i32 i32) (result i32)))
 (type $273 (func))
 (type $274 (func (param f64) (result f64)))
 (type $275 (func (param i32 i32) (result i64)))
 (type $276 (func (param i32 i32)))
 (type $277 (func (param i32 i32 i32) (result i32)))
 (type $278 (func (param i32 i32 i32 i32) (result i32)))
 (type $279 (func (param i32 i32) (result f64)))
 (type $280 (func (param i64) (result i64)))
 (type $281 (func (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:math/cos" (func $foreign11 (param f64) (result f64)))
 (import "snail.library" "snail:math/sin" (func $foreign12 (param f64) (result f64)))
 (import "snail.library" "snail:datum/token-open" (func $foreign18 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign19 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign20 (param i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign21 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign22 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-length" (func $foreign26 (param i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-character" (func $foreign27 (param i32 i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-scale" (func $foreign28 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-radix" (func $foreign29 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign30 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign31 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign32 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign33 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign34 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse-radix" (func $foreign35 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign36 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign37 (param i32) (result i32)))
 (import "benchmark" "barrier" (func $foreign38 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign39 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign40 (result i32)))
 (global $global1584 (mut (ref null $type264)) (ref.null none))
 (global $global137 (mut (ref null $type87)) (ref.null none))
 (global $empty85 (ref $type85) (struct.new_default $type85))
 (global $global324 (mut (ref null $type126)) (ref.null none))
 (global $global345 (mut (ref null $type131)) (ref.null none))
 (global $global1578 (mut (ref null $type262)) (ref.null none))
 (global $global139 (mut (ref null $type88)) (ref.null none))
 (global $global356 (mut (ref null $type133)) (ref.null none))
 (global $global323 (mut (ref null $type28)) (ref.null none))
 (global $global1128 (mut (ref null $type205)) (ref.null none))
 (global $global1576 (mut (ref null $type263)) (ref.null none))
 (global $global101 (mut (ref null $type64)) (ref.null none))
 (global $global327 (mut (ref null $type127)) (ref.null none))
 (global $global331 (mut (ref null $type128)) (ref.null none))
 (global $global61 (mut (ref null $type54)) (ref.null none))
 (global $global1136 (mut (ref null $type206)) (ref.null none))
 (global $global337 (mut (ref null $type52)) (ref.null none))
 (global $global341 (mut (ref null $type130)) (ref.null none))
 (global $global1219 (mut (ref null $type229)) (ref.null none))
 (global $global1224 (mut (ref null $type231)) (ref.null none))
 (global $global1731 (mut (ref null $type308)) (ref.null none))
 (global $global141 (mut (ref null $type88)) (ref.null none))
 (global $global1596 (mut (ref null $type263)) (ref.null none))
 (global $ready1731 (mut i32) (i32.const 0))
 (global $global457 (mut (ref null $type140)) (ref.null none))
 (global $global539 (mut (ref null $type149)) (ref.null none))
 (global $global1573 (mut (ref null $type275)) (ref.null none))
 (global $global780 (mut (ref null $type173)) (ref.null none))
 (global $global847 (mut (ref null $type186)) (ref.null none))
 (global $global1593 (mut (ref null $type265)) (ref.null none))
 (global $global1587 (mut (ref null $type76)) (ref.null none))
 (global $global548 (mut (ref null $type140)) (ref.null none))
 (global $global734 (mut (ref null $type169)) (ref.null none))
 (global $global827 (mut (ref null $type180)) (ref.null none))
 (global $global853 (mut (ref null $type186)) (ref.null none))
 (global $global1645 (mut (ref null $type270)) (ref.null none))
 (global $ready1587 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type60)) (ref.null none))
 (global $global347 (mut (ref null $type132)) (ref.null none))
 (global $global349 (mut (ref null $type132)) (ref.null none))
 (global $global386 (mut (ref null $type136)) (ref.null none))
 (global $global644 (mut (ref null $type140)) (ref.null none))
 (global $global655 (mut (ref null $type160)) (ref.null none))
 (global $global859 (mut (ref null $type187)) (ref.null none))
 (global $global1171 (mut (ref null $type212)) (ref.null none))
 (global $global1177 (mut (ref null $type213)) (ref.null none))
 (global $ready1573 (mut i32) (i32.const 0))
 (global $global1715 (mut (ref null $type303)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type58)) (ref.null none))
 (global $global460 (mut (ref null $type142)) (ref.null none))
 (global $global702 (mut (ref null $type133)) (ref.null none))
 (global $global1216 (mut (ref null $type228)) (ref.null none))
 (global $global1566 (mut (ref null $type260)) (ref.null none))
 (global $global1571 (mut (ref null $type261)) (ref.null none))
 (global $global1606 (mut (ref null $type267)) (ref.null none))
 (global $ready1715 (mut i32) (i32.const 0))
 (global $global1793 (mut (ref null $type261)) (ref.null none))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $global373 (mut (ref null $type135)) (ref.null none))
 (global $global405 (mut (ref null $type126)) (ref.null none))
 (global $global430 (mut (ref null $type140)) (ref.null none))
 (global $global469 (mut (ref null $type143)) (ref.null none))
 (global $global837 (mut (ref null $type183)) (ref.null none))
 (global $global1678 (mut (ref null $type273)) (ref.null none))
 (global $global1669 (mut (ref null $type274)) (ref.null none))
 (global $global1722 (mut (ref null $type305)) (ref.null none))
 (global $global1799 (mut (ref null $type315)) (ref.null none))
 (global $global1827 (mut (ref null $type82)) (ref.null none))
 (global $global86 (mut (ref null $type59)) (ref.null none))
 (global $global96 (mut (ref null $type63)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type71)) (ref.null none))
 (global $global124 (mut (ref null $type74)) (ref.null none))
 (global $global131 (mut (ref null $type76)) (ref.null none))
 (global $global128 (mut (ref null $type77)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global364 (mut (ref null $type134)) (ref.null none))
 (global $global417 (mut (ref null $type138)) (ref.null none))
 (global $global545 (mut (ref null $type140)) (ref.null none))
 (global $global594 (mut (ref null $type155)) (ref.null none))
 (global $global698 (mut (ref null $type134)) (ref.null none))
 (global $global769 (mut (ref null $type171)) (ref.null none))
 (global $global1142 (mut (ref null $type207)) (ref.null none))
 (global $global1154 (mut (ref null $type210)) (ref.null none))
 (global $global1194 (mut (ref null $type215)) (ref.null none))
 (global $global1217 (mut (ref null $type5)) (ref.null none))
 (global $global1251 (mut (ref null $type235)) (ref.null none))
 (global $global1582 (mut (ref null $type266)) (ref.null none))
 (global $global1676 (mut (ref null $type266)) (ref.null none))
 (global $global1612 (mut (ref null $type272)) (ref.null none))
 (global $global1686 (mut (ref null $type59)) (ref.null none))
 (global $ready1669 (mut i32) (i32.const 0))
 (global $global1598 (mut (ref null $type286)) (ref.null none))
 (global $ready1598 (mut i32) (i32.const 0))
 (global $global1607 (mut (ref null $type291)) (ref.null none))
 (global $ready1607 (mut i32) (i32.const 0))
 (global $global1636 (mut (ref null $type76)) (ref.null none))
 (global $global1633 (mut (ref null $type299)) (ref.null none))
 (global $ready1633 (mut i32) (i32.const 0))
 (global $global1629 (mut (ref null $type112)) (ref.null none))
 (global $global1626 (mut (ref null $type266)) (ref.null none))
 (global $global1623 (mut (ref null $type300)) (ref.null none))
 (global $global1618 (mut (ref null $type301)) (ref.null none))
 (global $ready1618 (mut i32) (i32.const 0))
 (global $ready1722 (mut i32) (i32.const 0))
 (global $global1745 (mut (ref null $type312)) (ref.null none))
 (global $ready1745 (mut i32) (i32.const 0))
 (global $global1809 (mut (ref null $type316)) (ref.null none))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 58)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 117)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 32)
   (i32.const 118)
   (i32.const 105)
   (i32.const 101)
   (i32.const 119)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 104)
   (i32.const 97)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $global1418 (mut (ref null $type46)) (ref.null none))
 (global $global1421 (mut (ref null $type50)) (ref.null none))
 (global $ready1421 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type62)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global1817 (mut (ref null $type78)) (ref.null none))
 (global $global1828 (mut (ref null $type80)) (ref.null none))
 (global $ready1828 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type101)) (ref.null none))
 (global $global333 (mut (ref null $type129)) (ref.null none))
 (global $global351 (mut (ref null $type112)) (ref.null none))
 (global $global390 (mut (ref null $type137)) (ref.null none))
 (global $global393 (mut (ref null $type137)) (ref.null none))
 (global $global396 (mut (ref null $type137)) (ref.null none))
 (global $global402 (mut (ref null $type137)) (ref.null none))
 (global $global408 (mut (ref null $type138)) (ref.null none))
 (global $global426 (mut (ref null $type139)) (ref.null none))
 (global $global440 (mut (ref null $type141)) (ref.null none))
 (global $global451 (mut (ref null $type138)) (ref.null none))
 (global $global477 (mut (ref null $type143)) (ref.null none))
 (global $global489 (mut (ref null $type144)) (ref.null none))
 (global $global501 (mut (ref null $type145)) (ref.null none))
 (global $global510 (mut (ref null $type143)) (ref.null none))
 (global $global515 (mut (ref null $type146)) (ref.null none))
 (global $global521 (mut (ref null $type147)) (ref.null none))
 (global $global530 (mut (ref null $type149)) (ref.null none))
 (global $global551 (mut (ref null $type120)) (ref.null none))
 (global $global559 (mut (ref null $type150)) (ref.null none))
 (global $global565 (mut (ref null $type151)) (ref.null none))
 (global $global576 (mut (ref null $type152)) (ref.null none))
 (global $global581 (mut (ref null $type153)) (ref.null none))
 (global $global586 (mut (ref null $type154)) (ref.null none))
 (global $global640 (mut (ref null $type132)) (ref.null none))
 (global $global658 (mut (ref null $type112)) (ref.null none))
 (global $global704 (mut (ref null $type166)) (ref.null none))
 (global $global713 (mut (ref null $type167)) (ref.null none))
 (global $global717 (mut (ref null $type136)) (ref.null none))
 (global $global724 (mut (ref null $type168)) (ref.null none))
 (global $global729 (mut (ref null $type169)) (ref.null none))
 (global $global740 (mut (ref null $type131)) (ref.null none))
 (global $global742 (mut (ref null $type140)) (ref.null none))
 (global $global768 (mut (ref null $type28)) (ref.null none))
 (global $global778 (mut (ref null $type173)) (ref.null none))
 (global $global835 (mut (ref null $type182)) (ref.null none))
 (global $global871 (mut (ref null $type189)) (ref.null none))
 (global $global874 (mut (ref null $type189)) (ref.null none))
 (global $global881 (mut (ref null $type190)) (ref.null none))
 (global $global889 (mut (ref null $type190)) (ref.null none))
 (global $global905 (mut (ref null $type190)) (ref.null none))
 (global $global911 (mut (ref null $type193)) (ref.null none))
 (global $global1162 (mut (ref null $type211)) (ref.null none))
 (global $global1181 (mut (ref null $type214)) (ref.null none))
 (global $global1187 (mut (ref null $type215)) (ref.null none))
 (global $global1197 (mut (ref null $type220)) (ref.null none))
 (global $global1203 (mut (ref null $type221)) (ref.null none))
 (global $global1205 (mut (ref null $type222)) (ref.null none))
 (global $global1212 (mut (ref null $type227)) (ref.null none))
 (global $global1222 (mut (ref null $type230)) (ref.null none))
 (global $global1237 (mut (ref null $type234)) (ref.null none))
 (global $global1561 (mut (ref null $type259)) (ref.null none))
 (global $global1649 (mut (ref null $type271)) (ref.null none))
 (global $ready1649 (mut i32) (i32.const 0))
 (global $global1664 (mut (ref null $type275)) (ref.null none))
 (global $global1590 (mut (ref null $type284)) (ref.null none))
 (global $ready1590 (mut i32) (i32.const 0))
 (global $global1661 (mut (ref null $type275)) (ref.null none))
 (global $ready1661 (mut i32) (i32.const 0))
 (global $global1702 (mut (ref null $type275)) (ref.null none))
 (global $ready1702 (mut i32) (i32.const 0))
 (global $global1704 (mut (ref null $type285)) (ref.null none))
 (global $ready1704 (mut i32) (i32.const 0))
 (global $global1710 (mut (ref null $type285)) (ref.null none))
 (global $ready1710 (mut i32) (i32.const 0))
 (global $global1603 (mut (ref null $type287)) (ref.null none))
 (global $ready1603 (mut i32) (i32.const 0))
 (global $global1655 (mut (ref null $type292)) (ref.null none))
 (global $ready1655 (mut i32) (i32.const 0))
 (global $global1638 (mut (ref null $type293)) (ref.null none))
 (global $ready1638 (mut i32) (i32.const 0))
 (global $global1614 (mut (ref null $type298)) (ref.null none))
 (global $ready1614 (mut i32) (i32.const 0))
 (global $global1631 (mut (ref null $type266)) (ref.null none))
 (global $ready1631 (mut i32) (i32.const 0))
 (global $ready1636 (mut i32) (i32.const 0))
 (global $global1694 (mut (ref null $type302)) (ref.null none))
 (global $global1673 (mut (ref null $type275)) (ref.null none))
 (global $ready1673 (mut i32) (i32.const 0))
 (global $global1683 (mut (ref null $type285)) (ref.null none))
 (global $ready1683 (mut i32) (i32.const 0))
 (global $global1692 (mut (ref null $type302)) (ref.null none))
 (global $ready1692 (mut i32) (i32.const 0))
 (global $global1782 (mut (ref null $type304)) (ref.null none))
 (global $ready1782 (mut i32) (i32.const 0))
 (global $global1772 (mut (ref null $type306)) (ref.null none))
 (global $ready1772 (mut i32) (i32.const 0))
 (global $global1758 (mut (ref null $type307)) (ref.null none))
 (global $ready1758 (mut i32) (i32.const 0))
 (global $global1734 (mut (ref null $type309)) (ref.null none))
 (global $global1728 (mut (ref null $type310)) (ref.null none))
 (global $ready1728 (mut i32) (i32.const 0))
 (global $global1739 (mut (ref null $type311)) (ref.null none))
 (global $ready1739 (mut i32) (i32.const 0))
 (global $global1750 (mut (ref null $type234)) (ref.null none))
 (global $global1791 (mut (ref null $type314)) (ref.null none))
 (global $global1801 (mut (ref null $type234)) (ref.null none))
 (global $ready1809 (mut i32) (i32.const 0))
 (global $global1813 (mut (ref null $type79)) (ref.null none))
 (global $global1815 (mut (ref null $type317)) (ref.null none))
 (global $global1822 (mut (ref null $type81)) (ref.null none))
 (global $global1833 (mut (ref null $type18)) (ref.null none))
 (global $global1834 (mut (ref null $type13)) (ref.null none))
 (global $global1835 (mut (ref null $type5)) (ref.null none))
 (global $ready1835 (mut i32) (i32.const 0))
 (global $global1836 (mut (ref null $type318)) (ref.null none))
 (global $global1839 (mut (ref null $type112)) (ref.null none))
 (global $ready1839 (mut i32) (i32.const 0))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 43)
  (array.new_fixed $type19 43
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 120)
   (i32.const 105)
   (i32.const 115)
   (i32.const 32)
   (i32.const 112)
   (i32.const 111)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 115)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string52 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string55 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string56 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string57 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string58 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string59 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string60 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string61 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string62 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string63 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string64 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string65 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string66 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string67 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string68 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string69 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string70 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string71 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string72 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string73 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string74 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string75 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string76 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string77 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 115)
   (i32.const 117)
   (i32.const 109)
   (i32.const 49)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string78 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 98)
   (i32.const 101)
   (i32.const 110)
   (i32.const 99)
   (i32.const 104)
   (i32.const 109)
   (i32.const 97)
   (i32.const 114)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string79 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 98)
   (i32.const 101)
   (i32.const 110)
   (i32.const 99)
   (i32.const 104)
   (i32.const 109)
   (i32.const 97)
   (i32.const 114)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 73)
   (i32.const 54)
   (i32.const 52)
  )
  (ref.null none)
 ))
 (global $string80 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $empty217 (ref $type217) (struct.new $type217
  (i32.const 0)
 ))
 (global $empty224 (ref $type224) (struct.new $type224
  (i32.const 0)
 ))
 (global $empty278 (ref $type278) (struct.new $type278
  (i32.const 1)
 ))
 (global $empty279 (ref $type279) (struct.new $type279
  (i32.const 2)
 ))
 (global $empty280 (ref $type280) (struct.new $type280
  (i32.const 3)
 ))
 (global $empty296 (ref $type296) (struct.new $type296
  (i32.const 1)
 ))
 (export "bench" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $127) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy (type $125) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call60) (param $0 (ref $type61)) (result (ref $type18))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref null $type61))
  (local $5 (ref null $type61))
  (local $6 (ref $type18))
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (local.set $4
   (struct.get $type61 1
    (local.get $0)
   )
  )
  (local.set $1
   (if (result i64)
    (i64.gt_u
     (local.tee $1
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type61 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (local.get $1)
      )
      (else
       (local.set $5
        (struct.get $type61 1
         (local.get $4)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $2
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type61 0
              (local.get $4)
             )
            )
           )
           (local.get $1)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type61 1
             (local.get $5)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $2)
               (local.tee $1
                (i64.add
                 (local.tee $3
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (struct.get $type61 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
              (i64.xor
               (local.get $1)
               (local.get $3)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.get $1)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $5
                (struct.get $type61 1
                 (local.get $4)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.get $1)
                   (local.tee $2
                    (i64.add
                     (local.tee $3
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (struct.get $type61 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (i64.xor
                   (local.get $2)
                   (local.get $3)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.get $2)
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $4
                    (struct.get $type61 1
                     (local.get $5)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.get $2)
                       (local.tee $1
                        (i64.add
                         (local.tee $3
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (struct.get $type61 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.get $2)
                        )
                       )
                      )
                      (i64.xor
                       (local.get $1)
                       (local.get $3)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.get $1)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (local.set $5
                        (struct.get $type61 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.get $1)
                           (local.tee $2
                            (i64.add
                             (local.tee $3
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (struct.get $type61 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (i64.xor
                           (local.get $2)
                           (local.get $3)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.get $2)
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (local.set $4
                            (struct.get $type61 1
                             (local.get $5)
                            )
                           )
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.get $2)
                               (local.tee $1
                                (i64.add
                                 (local.tee $3
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (struct.get $type61 0
                                     (local.get $5)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $2)
                                )
                               )
                              )
                              (i64.xor
                               (local.get $1)
                               (local.get $3)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.get $1)
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $1)
                              )
                              (else
                               (local.set $5
                                (struct.get $type61 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.get $1)
                                   (local.tee $2
                                    (i64.add
                                     (local.tee $3
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (struct.get $type61 0
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (i64.xor
                                   (local.get $2)
                                   (local.get $3)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.get $2)
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $5)
                                  )
                                  (then
                                   (local.get $2)
                                  )
                                  (else
                                   (local.set $4
                                    (struct.get $type61 1
                                     (local.get $5)
                                    )
                                   )
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.get $2)
                                       (local.tee $1
                                        (i64.add
                                         (local.tee $3
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (struct.get $type61 0
                                             (local.get $5)
                                            )
                                           )
                                          )
                                         )
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.xor
                                       (local.get $1)
                                       (local.get $3)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.get $1)
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $4)
                                      )
                                      (then
                                       (local.get $1)
                                      )
                                      (else
                                       (local.set $5
                                        (struct.get $type61 1
                                         (local.get $4)
                                        )
                                       )
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.get $1)
                                           (local.tee $2
                                            (i64.add
                                             (local.tee $3
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (struct.get $type61 0
                                                 (local.get $4)
                                                )
                                               )
                                              )
                                             )
                                             (local.get $1)
                                            )
                                           )
                                          )
                                          (i64.xor
                                           (local.get $2)
                                           (local.get $3)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.get $2)
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $5)
                                          )
                                          (then
                                           (local.get $2)
                                          )
                                          (else
                                           (local.set $4
                                            (struct.get $type61 1
                                             (local.get $5)
                                            )
                                           )
                                           (if
                                            (i64.lt_s
                                             (i64.and
                                              (i64.xor
                                               (local.get $2)
                                               (local.tee $1
                                                (i64.add
                                                 (local.tee $3
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (struct.get $type61 0
                                                     (local.get $5)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (local.get $2)
                                                )
                                               )
                                              )
                                              (i64.xor
                                               (local.get $1)
                                               (local.get $3)
                                              )
                                             )
                                             (i64.const 0)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.get $1)
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $4)
                                              )
                                              (then
                                               (local.get $1)
                                              )
                                              (else
                                               (local.set $5
                                                (struct.get $type61 1
                                                 (local.get $4)
                                                )
                                               )
                                               (if
                                                (i64.lt_s
                                                 (i64.and
                                                  (i64.xor
                                                   (local.get $1)
                                                   (local.tee $2
                                                    (i64.add
                                                     (local.tee $3
                                                      (i64.extend_i32_u
                                                       (struct.get $type18 1
                                                        (struct.get $type61 0
                                                         (local.get $4)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                  (i64.xor
                                                   (local.get $2)
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (i64.const 0)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.get $2)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                  (then
                                                   (local.get $2)
                                                  )
                                                  (else
                                                   (local.set $4
                                                    (struct.get $type61 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                   (if
                                                    (i64.lt_s
                                                     (i64.and
                                                      (i64.xor
                                                       (local.get $2)
                                                       (local.tee $1
                                                        (i64.add
                                                         (local.tee $3
                                                          (i64.extend_i32_u
                                                           (struct.get $type18 1
                                                            (struct.get $type61 0
                                                             (local.get $5)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (local.get $2)
                                                        )
                                                       )
                                                      )
                                                      (i64.xor
                                                       (local.get $1)
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (i64.const 0)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.get $1)
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $4)
                                                      )
                                                      (then
                                                       (local.get $1)
                                                      )
                                                      (else
                                                       (local.set $5
                                                        (struct.get $type61 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (if
                                                        (i64.lt_s
                                                         (i64.and
                                                          (i64.xor
                                                           (local.get $1)
                                                           (local.tee $2
                                                            (i64.add
                                                             (local.tee $3
                                                              (i64.extend_i32_u
                                                               (struct.get $type18 1
                                                                (struct.get $type61 0
                                                                 (local.get $4)
                                                                )
                                                               )
                                                              )
                                                             )
                                                             (local.get $1)
                                                            )
                                                           )
                                                          )
                                                          (i64.xor
                                                           (local.get $2)
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (i64.const 0)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (call $function37
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (local.get $5)
                                                        (local.get $2)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (call $string-new
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (drop
   (call $function38
    (local.get $6)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $6)
 )
 (func $function37 (type $122) (param $0 i32) (param $1 i32) (param $2 (ref null $type61)) (param $3 i64) (result i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type61))
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $6
       (struct.get $type61 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.tee $5
             (i64.extend_i32_u
              (struct.get $type18 1
               (struct.get $type61 0
                (local.get $2)
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call63) (param $0 (ref $type18)) (param $1 (ref null $type61)) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type18))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $5
      (struct.get $type61 0
       (local.get $1)
      )
     )
     (local.tee $3
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $5)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type61 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $4
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (local.get $4)
    )
   )
  )
 )
 (func $function40 (type $120) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function45 (type $119) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (local $7 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (if (result (ref $type19))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type18 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type20
          (struct.get $type18 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
    )
   )
  )
 )
 (func $function55 (type $call88) (param $0 (ref $type68)) (result (ref $type84))
  (local $1 i64)
  (local $2 i32)
  (local.set $2
   (call $foreign7
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if (result (ref $type84))
   (i32.eq
    (local.get $2)
    (i32.const -1)
   )
   (then
    (global.get $empty85)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $1
       (i64.extend_i32_s
        (local.get $2)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $1)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $1)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type86
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function114 (type $114) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $4
          (i64.sub
           (local.get $3)
           (i64.const 1)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global324)
      )
     )
     (if
      (i64.gt_u
       (local.get $4)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function114
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function115 (type $call52) (param $0 (ref $type29)) (result (ref $type29))
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global333)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.tee $1
     (call $function114
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.tee $2
       (i64.extend_i32_u
        (array.len
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type29 $type29
     (local.tee $4
      (array.new_default $type29
       (local.tee $3
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (i32.const 0)
     (local.get $0)
     (i32.const 0)
     (local.get $3)
    )
    (local.get $4)
   )
  )
 )
 (func $function117 (type $call131) (param $0 (ref $type28)) (result i32)
  (i64.eqz
   (i64.extend_i32_u
    (array.len
     (struct.get $type28 1
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function120 (type $call112) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function121
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function121 (type $109) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function121
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 1073741824)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function122 (type $call133) (param $0 i64) (result (ref $type28))
  (local $1 i64)
  (local $2 i32)
  (return_call $function123
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (block (result i32)
    (drop
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (if
     (i64.gt_s
      (local.get $0)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $0)
         (local.tee $1
          (i64.sub
           (i64.const 0)
           (local.get $0)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $0
       (local.get $1)
      )
     )
    )
    (local.set $1
     (call $function120
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.const 1)
   )
   (array.new_default $type29
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function123 (type $107) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type28))
  (local $8 i64)
  (local $9 i64)
  (if (result (ref $type28))
   (i64.eqz
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global341)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global337)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function115
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global323)
      )
     )
     (else
      (struct.new $type28
       (local.get $0)
       (local.get $2)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (local.tee $8
        (i64.sub
         (i64.const 0)
         (local.tee $9
          (i64.rem_s
           (local.get $6)
           (i64.const 1073741824)
          )
         )
        )
       )
       (local.get $9)
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (local.get $8)
      (i64.extend32_s
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $2)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function123
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 1073741824)
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function125 (type $106) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i64)
  (local $10 i64)
  (local $11 i64)
  (if (result i64)
   (i64.eqz
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (local.get $2)
     (then
      (local.get $9)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (local.get $9)
         (local.tee $4
          (i64.sub
           (i64.const 0)
           (local.get $9)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $4)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.sub
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.extend_i32_s
      (array.get $type29
       (local.get $0)
       (i32.wrap_i64
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.add
          (local.get $4)
          (local.get $10)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (i64.div_s
       (local.get $11)
       (i64.const 1073741824)
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $11
           (i64.sub
            (local.get $8)
            (i64.const 1)
           )
          )
          (local.get $8)
         )
         (i64.xor
          (local.get $8)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (i64.div_s
         (local.tee $8
          (i64.shl
           (local.get $9)
           (i64.const 30)
          )
         )
         (i64.const 1073741824)
        )
        (local.get $9)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $9
           (i64.sub
            (local.get $8)
            (local.get $10)
           )
          )
          (local.get $8)
         )
         (i64.xor
          (local.get $8)
          (local.get $10)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $7)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function125
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $11)
       (local.get $9)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function127 (type $105) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (if (result i64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.extend_i32_s
      (array.get $type29
       (local.get $0)
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (local.get $5)
     )
     (then
      (i64.const -1)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.get $5)
        (local.get $6)
       )
       (then
        (i64.const 1)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $4)
              (i64.const 1)
             )
            )
            (local.get $4)
           )
           (i64.xor
            (local.get $4)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function127
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $5)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function128 (type $call136) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (i32.ne
      (local.tee $4
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (struct.get $type28 0
       (local.get $1)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global373)
     )
    )
    (local.set $2
     (if (result i64)
      (i64.lt_s
       (local.tee $2
        (i64.extend_i32_u
         (array.len
          (local.tee $5
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
       )
       (local.tee $3
        (i64.extend_i32_u
         (array.len
          (local.tee $6
           (struct.get $type28 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (if (result i64)
        (i64.gt_s
         (local.get $2)
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (call $function127
          (local.get $5)
          (local.get $6)
          (i32.const 0)
          (i32.const 1)
          (local.get $2)
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (local.get $4)
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $2)
         (local.tee $3
          (i64.sub
           (i64.const 0)
           (local.get $2)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $3)
     )
     (else
      (local.get $2)
     )
    )
   )
   (else
    (select
     (i64.const -1)
     (i64.const 1)
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function136 (type $103) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global405)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (if (result i64)
          (i64.gt_s
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (local.get $8)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global324)
            )
           )
           (if
            (i64.gt_u
             (local.get $8)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i64.extend_i32_s
            (array.get $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $8)
             )
            )
           )
          )
          (else
           (i64.const 0)
          )
         )
        )
        (local.tee $10
         (i64.add
          (local.tee $11
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global324)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type29
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $11)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function136
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $11)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function138 (type $103) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global405)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
        )
        (local.tee $11
         (i64.sub
          (local.get $10)
          (local.tee $12
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global324)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type29
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.sub
          (local.get $11)
          (local.get $9)
         )
        )
        (local.get $11)
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (if (result i64)
         (i64.lt_s
          (local.get $10)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $10)
              (local.tee $9
               (i64.add
                (local.get $10)
                (i64.const 1073741824)
               )
              )
             )
             (i64.xor
              (local.get $9)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $9)
         )
         (else
          (local.get $10)
         )
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function138
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.extend_i32_u
      (i64.lt_s
       (local.get $10)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function140 (type $102) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $scratch (ref $type29))
  (local $scratch_8 (ref $type29))
  (local $scratch_9 (ref $type29))
  (local.set $2
   (struct.get $type28 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type28 1
    (local.get $1)
   )
  )
  (if (result (ref $type28))
   (select
    (local.tee $6
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (i32.eqz
     (local.get $6)
    )
    (local.tee $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global408)
     )
    )
    (local.set $4
     (i64.add
      (local.tee $5
       (select
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
        (i64.gt_s
         (local.get $4)
         (local.get $5)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.get $5)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function115
          (block (result (ref $type29))
           (local.set $scratch
            (call $function136
             (local.get $2)
             (local.get $3)
             (local.get $5)
             (i32.const 1)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global341)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global337)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global323)
      )
     )
     (else
      (struct.new $type28
       (local.get $6)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global426)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global373)
     )
    )
    (if (result (ref $type28))
     (i64.lt_s
      (if (result i64)
       (i64.lt_s
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.get $4)
          (local.get $5)
         )
         (then
          (i64.const 1)
         )
         (else
          (call $function127
           (local.get $2)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (local.get $4)
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global417)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global331)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function115
            (block (result (ref $type29))
             (local.set $scratch_8
              (call $function138
               (local.get $3)
               (local.get $2)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global341)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global337)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (else
        (struct.new $type28
         (i32.eqz
          (local.get $6)
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global417)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global331)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function115
            (block (result (ref $type29))
             (local.set $scratch_9
              (call $function138
               (local.get $2)
               (local.get $3)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global341)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global337)
              )
             )
             (local.get $scratch_9)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (else
        (struct.new $type28
         (local.get $6)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function143 (type $101) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $10)
          (local.tee $13
           (i64.extend_i32_s
            (array.get $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $12)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $11)
        (local.get $13)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function143
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function145 (type $100) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type29))
  (local $7 i64)
  (if (result (ref $type29))
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global440)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function143
      (local.get $2)
      (local.get $1)
      (local.get $6)
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $7
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function145
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $7)
    )
   )
  )
 )
 (func $function146 (type $102) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i32)
  (local $5 i64)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 1
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global345)
      )
     )
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global323)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global451)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type28 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function115
          (block (result (ref $type29))
           (local.set $scratch
            (call $function145
             (local.get $2)
             (local.get $3)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $5)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global341)
            )
           )
           (local.set $4
            (select
             (i32.eqz
              (local.tee $4
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
             (local.get $4)
             (struct.get $type28 0
              (local.get $0)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global337)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global323)
      )
     )
     (else
      (struct.new $type28
       (local.get $4)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function148 (type $99) (param $0 (ref $type29)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.mul
      (local.get $1)
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $11)
         (local.get $1)
        )
        (local.get $10)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function148
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function150 (type $98) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (local.get $6)
   )
   (else
    (if
     (i64.ne
      (i64.div_s
       (local.tee $7
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
       )
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $6
         (i64.add
          (local.get $7)
          (local.tee $8
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $8
        (i64.div_s
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.rem_s
      (local.get $6)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function150
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
     (local.get $5)
    )
   )
  )
 )
 (func $function152 (type $97) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i64) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i64) (param $10 i64) (result i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $10)
     (i64.const 1073741824)
    )
    (then
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.sub
           (local.get $3)
           (i64.const 2)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global324)
      )
     )
     (if
      (i64.gt_u
       (local.get $11)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $13
      (i64.mul
       (local.tee $11
        (i64.extend_i32_s
         (array.get $type29
          (local.get $1)
          (i32.wrap_i64
           (local.get $11)
          )
         )
        )
       )
       (local.get $9)
      )
     )
     (if
      (i64.ne
       (local.get $11)
       (i64.const 0)
      )
      (then
       (if
        (i64.ne
         (i64.div_s
          (local.get $13)
          (local.get $11)
         )
         (local.get $9)
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (if
      (i64.ne
       (i64.div_s
        (local.tee $14
         (i64.shl
          (local.get $10)
          (i64.const 30)
         )
        )
        (i64.const 1073741824)
       )
       (local.get $10)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.add
           (local.get $2)
           (local.get $3)
          )
         )
         (local.get $2)
        )
        (i64.xor
         (local.get $3)
         (local.get $11)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $12
          (i64.sub
           (local.get $11)
           (i64.const 2)
          )
         )
         (local.get $11)
        )
        (i64.xor
         (local.get $11)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global324)
      )
     )
     (if
      (i64.gt_u
       (local.get $12)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $14)
         (local.tee $11
          (i64.add
           (local.get $14)
           (local.tee $12
            (i64.extend_i32_s
             (array.get $type29
              (local.get $0)
              (i32.wrap_i64
               (local.get $12)
              )
             )
            )
           )
          )
         )
        )
        (i64.xor
         (local.get $11)
         (local.get $12)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (i64.lt_s
      (local.get $11)
      (local.get $13)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.sub
          (local.get $9)
          (i64.const 1)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $5)
          (local.get $10)
         )
        )
        (local.get $10)
       )
       (i64.xor
        (local.get $5)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function152
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $11)
     (local.get $9)
    )
   )
   (else
    (local.get $9)
   )
  )
 )
 (func $function154 (type $101) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.sub
      (local.tee $8
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.get $3)
       (i64.const -1)
      )
      (i64.gt_s
       (local.get $3)
       (i64.const 0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (if (result i64)
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.add
                (local.get $3)
                (i64.const 1073741824)
               )
              )
              (local.get $3)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $2)
         )
         (else
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i64.lt_s
     (local.get $3)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.sub
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
      (local.tee $12
       (i64.and
        (local.get $11)
        (i64.const 1073741823)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $10
        (if (result i64)
         (i64.lt_s
          (local.get $9)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $10
               (i64.add
                (local.get $9)
                (i64.const 1073741824)
               )
              )
              (local.get $9)
             )
             (i64.xor
              (local.get $10)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $10)
         )
         (else
          (local.get $9)
         )
        )
       )
      )
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $10)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $10
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function154
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $10)
     (i64.add
      (i64.extend_i32_u
       (i64.lt_s
        (local.get $9)
        (i64.const 0)
       )
      )
      (i64.shr_u
       (local.get $11)
       (i64.const 30)
      )
     )
    )
   )
  )
 )
 (func $function156 (type $96) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.add
      (local.get $8)
      (local.tee $3
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (i64.rem_s
         (local.get $2)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
        )
        (local.tee $9
         (i64.add
          (local.get $9)
          (local.tee $10
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $7)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $10
         (i64.add
          (local.get $8)
          (local.get $9)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function156
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $8)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function159 (type $95) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $13
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global510)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global477)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.sub
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.extend_i32_s
      (array.get $type29
       (local.get $2)
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $6)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.shl
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (i64.const 30)
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.get $7)
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $12
         (i64.add
          (local.get $7)
          (local.tee $6
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_s
      (local.tee $8
       (i64.div_s
        (local.get $12)
        (local.get $11)
       )
      )
      (i64.const 1073741824)
     )
     (then
      (local.set $8
       (i64.const 1073741823)
      )
     )
    )
    (local.set $7
     (i64.mul
      (local.get $8)
      (local.get $11)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $7)
         (local.get $11)
        )
        (local.get $8)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $12)
          (local.get $7)
         )
        )
        (local.get $12)
       )
       (i64.xor
        (local.get $7)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function152
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $10)
      (i32.const 1)
      (local.get $11)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (local.get $8)
      (local.get $6)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global489)
     )
    )
    (if
     (call $function154
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $7)
      (local.tee $6
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global501)
       )
      )
      (drop
       (call $function156
        (local.get $1)
        (local.get $2)
        (local.get $9)
        (local.get $6)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
        (i64.const 0)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.sub
            (local.get $7)
            (i64.const 1)
           )
          )
          (local.get $7)
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (local.get $6)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global327)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.extend32_s
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $13)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $13)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function159
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function162 (type $94) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type148))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type148))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i32)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type148))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global373)
     )
    )
    (local.set $7
     (struct.get $type148 0
      (local.tee $9
       (if (result (ref $type148))
        (i64.lt_s
         (if (result i64)
          (i64.lt_s
           (local.tee $10
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (struct.get $type28 1
                (local.get $0)
               )
              )
             )
            )
           )
           (local.tee $11
            (i64.extend_i32_u
             (array.len
              (local.tee $3
               (struct.get $type28 1
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (if (result i64)
            (i64.gt_s
             (local.get $10)
             (local.get $11)
            )
            (then
             (i64.const 1)
            )
            (else
             (call $function127
              (local.get $2)
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $10)
             )
            )
           )
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global347)
          )
         )
         (struct.new $type148
          (ref.as_non_null
           (global.get $global323)
          )
          (if (result (ref $type28))
           (struct.get $type28 0
            (local.get $0)
           )
           (then
            (struct.new $type28
             (i32.const 0)
             (struct.get $type28 1
              (local.get $0)
             )
            )
           )
           (else
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type148))
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (i64.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global331)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global324)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global469)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (call $function150
             (local.tee $4
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
             (local.get $2)
             (i64.extend_i32_s
              (array.get $type29
               (local.get $3)
               (i32.const 0)
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global341)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global337)
            )
           )
           (struct.new $type148
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function115
                  (local.get $4)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global323)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global356)
              )
             )
             (call $function122
              (local.get $10)
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global521)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global324)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (i64.sub
               (local.tee $10
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $11
            (i64.add
             (local.tee $12
              (i64.extend_i32_s
               (array.get $type29
                (local.get $3)
                (i32.wrap_i64
                 (local.get $11)
                )
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $11)
               (local.get $12)
              )
              (i64.xor
               (local.get $11)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global460)
            )
           )
           (local.set $11
            (i64.div_s
             (i64.const 1073741824)
             (local.get $11)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global331)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (call $function148
             (local.get $2)
             (local.get $11)
             (local.get $12)
             (i32.const 1)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $13)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global460)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global331)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (call $function115
             (block (result (ref $type29))
              (local.set $scratch
               (call $function148
                (local.get $3)
                (local.get $11)
                (local.get $12)
                (i32.const 1)
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $13)
                 )
                )
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global337)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $12
                (i64.add
                 (local.tee $13
                  (i64.sub
                   (i64.extend_i32_u
                    (array.len
                     (local.get $2)
                    )
                   )
                   (local.get $10)
                  )
                 )
                 (i64.const 1)
                )
               )
               (local.get $13)
              )
              (i64.xor
               (local.get $12)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global331)
            )
           )
           (if
            (i64.gt_u
             (local.get $12)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global331)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global515)
            )
           )
           (drop
            (call $function159
             (local.tee $6
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $12)
               )
              )
             )
             (local.get $5)
             (local.get $3)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $6)
              )
             )
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.copy $type29 $type29
            (local.tee $4
             (array.new_default $type29
              (local.tee $14
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
            )
            (i32.const 0)
            (local.get $5)
            (i32.const 0)
            (local.get $14)
           )
           (drop
            (ref.as_non_null
             (global.get $global469)
            )
           )
           (if
            (i64.ne
             (call $function150
              (local.get $4)
              (local.get $4)
              (local.get $11)
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $4)
               )
              )
              (i64.const 0)
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global341)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global337)
            )
           )
           (struct.new $type148
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function115
                  (local.get $6)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global323)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global341)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global337)
              )
             )
             (if (result (ref $type28))
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.tee $2
                  (call $function115
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (then
               (ref.as_non_null
                (global.get $global323)
               )
              )
              (else
               (struct.new $type28
                (i32.const 0)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type148 1
      (local.get $9)
     )
    )
    (struct.new $type148
     (if (result (ref $type28))
      (select
       (i32.eqz
        (local.tee $14
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
       (local.get $14)
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global349)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global345)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $7)
           )
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $7)
           )
          )
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
       )
      )
      (else
       (local.get $7)
      )
     )
     (if (result (ref $type28))
      (struct.get $type28 0
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global349)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global345)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $8)
           )
          )
         )
        )
        (then
         (local.get $8)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $8)
           )
          )
          (struct.get $type28 1
           (local.get $8)
          )
         )
        )
       )
      )
      (else
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function164 (type $call140) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global539)
   )
  )
  (struct.get $type148 1
   (call $function162
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $function166 (type $91) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.tee $6
        (i64.sub
         (i64.extend_i32_u
          (array.get $type19
           (if (result (ref $type19))
            (i32.lt_u
             (local.tee $8
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type18 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type20
               (struct.get $type18 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $8)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $8)
            (i32.const 8191)
           )
          )
         )
         (i64.const 48)
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $6)
       (i64.const 9)
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $5)
        (i64.div_s
         (local.tee $4
          (i64.mul
           (local.get $5)
           (i64.const 10)
          )
         )
         (i64.const 10)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $5
           (i64.add
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (local.get $6)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function166
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
       (local.get $5)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function168 (type $90) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
    (if
     (i64.ne
      (local.get $0)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $0)
        )
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function168
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
 )
 (func $function170 (type $89) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref $type28)) (result (ref $type28))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 (ref $type29))
  (local $13 (ref $type28))
  (local $scratch (ref $type29))
  (local $scratch_15 i64)
  (local $scratch_16 (ref $type28))
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global349)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
       )
       (then
        (local.get $7)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $7)
          )
         )
         (struct.get $type28 1
          (local.get $7)
         )
        )
       )
      )
     )
     (else
      (local.get $7)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $2)
          (local.get $6)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global559)
     )
    )
    (local.set $8
     (call $function168
      (i64.const 10)
      (i32.const 0)
      (i32.const 1)
      (local.tee $9
       (if (result i64)
        (i64.gt_s
         (local.get $9)
         (i64.const 9)
        )
        (then
         (i64.const 9)
        )
        (else
         (if
          (i32.eqz
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $9
              (i64.sub
               (local.get $2)
               (local.get $6)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (local.get $6)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.get $9)
        )
       )
      )
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global460)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (i64.add
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.tee $12
            (struct.get $type28 1
             (local.get $7)
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function140
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $12
           (call $function115
            (block (result (ref $type29))
             (local.set $scratch
              (call $function148
               (local.get $12)
               (local.get $8)
               (local.get $10)
               (i32.const 1)
               (array.new_default $type29
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global341)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global337)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $12)
        )
       )
      )
      (block (result (ref $type28))
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
           (local.get $6)
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global551)
        )
       )
       (local.set $scratch_16
        (call $function122
         (block (result i64)
          (local.set $scratch_15
           (call $function166
            (local.get $0)
            (local.get $8)
            (i32.const 0)
            (i32.const 1)
            (local.get $6)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global356)
           )
          )
          (local.get $scratch_15)
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $6)
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global430)
        )
       )
       (local.get $scratch_16)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function170
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $8)
     (local.get $7)
    )
   )
  )
 )
 (func $function174 (type $88) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type28)) (result (ref $type28))
  (local $7 (ref $type29))
  (local $8 (ref $type28))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i32)
  (local $scratch (ref $type29))
  (local $scratch_14 (ref $type28))
  (if (result (ref $type28))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $5)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global349)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $6)
          )
         )
        )
       )
       (then
        (local.get $6)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $6)
          )
         )
         (struct.get $type28 1
          (local.get $6)
         )
        )
       )
      )
     )
     (else
      (local.get $6)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global460)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (i64.add
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.tee $7
            (struct.get $type28 1
             (local.get $6)
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $function140
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $7
           (call $function115
            (block (result (ref $type29))
             (local.set $scratch
              (call $function148
               (local.get $7)
               (local.get $2)
               (local.get $10)
               (i32.const 1)
               (array.new_default $type29
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global341)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global337)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $7)
        )
       )
      )
      (block (result (ref $type28))
       (if
        (i64.ge_u
         (local.get $5)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global581)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global356)
        )
       )
       (local.set $scratch_14
        (call $function122
         (if (result i64)
          (if (result i32)
           (i64.lt_s
            (local.tee $5
             (if (result i64)
              (if (result i32)
               (i64.ge_u
                (local.tee $5
                 (i64.extend_i32_u
                  (array.get $type19
                   (if (result (ref $type19))
                    (i32.lt_u
                     (local.tee $12
                      (i32.wrap_i64
                       (local.get $5)
                      )
                     )
                     (i32.const 8192)
                    )
                    (then
                     (struct.get $type18 2
                      (local.get $0)
                     )
                    )
                    (else
                     (ref.as_non_null
                      (array.get $type20
                       (struct.get $type18 3
                        (local.get $0)
                       )
                       (i32.sub
                        (i32.shr_u
                         (local.get $12)
                         (i32.const 13)
                        )
                        (i32.const 1)
                       )
                      )
                     )
                    )
                   )
                   (i32.and
                    (local.get $12)
                    (i32.const 8191)
                   )
                  )
                 )
                )
                (i64.const 48)
               )
               (then
                (i64.le_u
                 (local.get $5)
                 (i64.const 57)
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (i64.sub
                (local.get $5)
                (i64.const 48)
               )
              )
              (else
               (if (result i64)
                (i32.and
                 (i64.le_u
                  (local.get $5)
                  (i64.const 90)
                 )
                 (i64.ge_u
                  (local.get $5)
                  (i64.const 65)
                 )
                )
                (then
                 (i64.sub
                  (local.get $5)
                  (i64.const 55)
                 )
                )
                (else
                 (select
                  (i64.sub
                   (local.get $5)
                   (i64.const 87)
                  )
                  (i64.const -1)
                  (i32.and
                   (i64.le_u
                    (local.get $5)
                    (i64.const 122)
                   )
                   (i64.ge_u
                    (local.get $5)
                    (i64.const 97)
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (i64.const 0)
           )
           (then
            (i32.const 1)
           )
           (else
            (i64.le_s
             (local.get $2)
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (local.get $5)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global430)
        )
       )
       (local.get $scratch_14)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function174
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $9)
     (local.get $6)
    )
   )
  )
 )
 (func $function175 (type $call155) (param $0 (ref $type18)) (param $1 i64) (result (ref $type28))
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (if
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (i64.const 2)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i64.eqz
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $0)
        )
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 36)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.eq
      (local.get $1)
      (i64.const 10)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global576)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global565)
         )
        )
        (if
         (i64.eq
          (local.tee $1
           (i64.extend_i32_u
            (i32.or
             (local.tee $3
              (i32.eq
               (local.tee $2
                (array.get $type19
                 (struct.get $type18 2
                  (local.get $0)
                 )
                 (i32.const 0)
                )
               )
               (i32.const 45)
              )
             )
             (i32.eq
              (local.get $2)
              (i32.const 43)
             )
            )
           )
          )
          (local.tee $4
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
         (else
          (return_call $function170
           (local.get $0)
           (local.get $3)
           (local.get $4)
           (i32.const 1)
           (i32.const 0)
           (i32.const 1)
           (local.get $1)
           (ref.as_non_null
            (global.get $global323)
           )
          )
         )
        )
        (unreachable)
       )
      )
      (unreachable)
     )
     (else
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global586)
       )
      )
      (if
       (i64.eq
        (local.tee $4
         (i64.extend_i32_u
          (i32.or
           (local.tee $3
            (i32.eq
             (local.tee $2
              (array.get $type19
               (struct.get $type18 2
                (local.get $0)
               )
               (i32.const 0)
              )
             )
             (i32.const 45)
            )
           )
           (i32.eq
            (local.get $2)
            (i32.const 43)
           )
          )
         )
        )
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (return_call $function174
         (local.get $0)
         (local.get $3)
         (local.get $1)
         (i32.const 0)
         (i32.const 1)
         (local.get $4)
         (ref.as_non_null
          (global.get $global323)
         )
        )
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function189 (type $86) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (param $4 (ref $type28)) (result (ref $type28))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (i64.extend_i32_s
        (array.get $type29
         (struct.get $type28 1
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (i64.const 1)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global457)
       )
      )
      (local.set $4
       (call $function146
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global640)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global331)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global469)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (struct.get $type28 1
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function150
      (local.tee $6
       (array.new_default $type29
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $5)
      (i64.const 2)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $5)
       )
      )
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global341)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global337)
     )
    )
    (local.set $7
     (if (result (ref $type28))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (call $function115
           (local.get $6)
          )
         )
        )
       )
      )
      (then
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (else
       (struct.new $type28
        (i32.const 0)
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $7)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global457)
       )
      )
      (local.set $8
       (call $function146
        (local.get $2)
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function189
       (local.get $0)
       (local.get $1)
       (local.get $8)
       (local.get $7)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function191 (type $call112) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 2)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 2)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 2)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 2)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 2)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 2)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 2)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 2)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 2)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 2)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 2)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 2)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 2)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function192
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function192 (type $109) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function192
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 2)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function203 (type $call134) (param $0 (ref $type28)) (result i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type29))
  (if (result i64)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (array.len
       (local.tee $4
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i64.ne
      (i64.div_s
       (local.tee $3
        (i64.mul
         (local.tee $2
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 30)
        )
       )
       (i64.const 30)
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $1
         (i64.add
          (local.get $3)
          (local.tee $2
           (call $function191
            (i64.extend_i32_s
             (array.get $type29
              (local.get $4)
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function206 (type $84) (param $0 f64) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 f64) (result f64)
  (local $6 i64)
  (if (result f64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $0)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $5
         (f64.mul
          (local.get $5)
          (local.get $0)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function206
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $6)
     (local.get $5)
    )
   )
  )
 )
 (func $function211 (type $call169) (param $0 (ref $type28)) (param $1 (ref $type28)) (result f64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 f64)
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type28))
  (local $12 (ref $type28))
  (local $13 (ref $type28))
  (local $14 (ref $type148))
  (local $15 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result f64)
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if (result f64)
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (f64.const 0.0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global729)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global698)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (call $function203
            (local.tee $9
             (if (result (ref $type28))
              (struct.get $type28 0
               (local.get $0)
              )
              (then
               (struct.new $type28
                (i32.const 0)
                (struct.get $type28 1
                 (local.get $0)
                )
               )
              )
              (else
               (local.get $0)
              )
             )
            )
           )
          )
          (block (result i64)
           (drop
            (ref.as_non_null
             (global.get $global698)
            )
           )
           (local.tee $2
            (i64.sub
             (local.get $3)
             (local.tee $4
              (call $function203
               (local.tee $11
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (then
                  (struct.new $type28
                   (i32.const 0)
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i64.xor
          (local.get $3)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (if (result f64)
        (i64.gt_s
         (local.get $2)
         (i64.const 1024)
        )
        (then
         (f64.const inf)
        )
        (else
         (if (result f64)
          (i64.lt_s
           (local.get $2)
           (i64.const -1075)
          )
          (then
           (f64.const 0.0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global713)
            )
           )
           (local.set $7
            (local.get $9)
           )
           (local.set $10
            (local.get $11)
           )
           (if
            (i64.lt_s
             (local.get $2)
             (i64.const 0)
            )
            (then
             (if
              (i64.lt_s
               (i64.and
                (local.get $2)
                (local.tee $3
                 (i64.sub
                  (i64.const 0)
                  (local.get $2)
                 )
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global702)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global356)
              )
             )
             (local.set $12
              (call $function122
               (i64.const 2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global655)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global356)
              )
             )
             (local.set $8
              (call $function122
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global644)
              )
             )
             (local.set $8
              (if (result (ref $type28))
               (struct.get $type28 0
                (local.get $8)
               )
               (then
                (unreachable)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global356)
                 )
                )
                (call $function189
                 (i32.const 0)
                 (i32.const 1)
                 (local.get $12)
                 (local.get $8)
                 (call $function122
                  (i64.const 1)
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global457)
              )
             )
             (local.set $7
              (call $function146
               (local.get $7)
               (local.get $8)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global702)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global356)
              )
             )
             (local.set $12
              (call $function122
               (i64.const 2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global655)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global356)
              )
             )
             (local.set $8
              (call $function122
               (local.get $2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global644)
              )
             )
             (local.set $8
              (if (result (ref $type28))
               (struct.get $type28 0
                (local.get $8)
               )
               (then
                (unreachable)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global356)
                 )
                )
                (call $function189
                 (i32.const 0)
                 (i32.const 1)
                 (local.get $12)
                 (local.get $8)
                 (call $function122
                  (i64.const 1)
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global457)
              )
             )
             (local.set $10
              (call $function146
               (local.get $10)
               (local.get $8)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global393)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global386)
            )
           )
           (if
            (i64.lt_s
             (call $function128
              (local.get $7)
              (local.get $10)
             )
             (i64.const 0)
            )
            (then
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $3
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (local.get $2)
                )
                (i64.xor
                 (local.get $2)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (local.get $3)
             )
            )
           )
           (if (result f64)
            (i64.gt_s
             (local.get $2)
             (i64.const 1023)
            )
            (then
             (f64.const inf)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global724)
              )
             )
             (if
              (i64.lt_s
               (local.tee $3
                (if (result i64)
                 (i64.lt_s
                  (local.get $2)
                  (i64.const -1022)
                 )
                 (then
                  (i64.const -1074)
                 )
                 (else
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $3
                       (i64.sub
                        (local.get $2)
                        (i64.const 52)
                       )
                      )
                      (local.get $2)
                     )
                     (i64.xor
                      (local.get $2)
                      (i64.const 52)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.get $3)
                 )
                )
               )
               (i64.const 0)
              )
              (then
               (if
                (i64.lt_s
                 (i64.and
                  (local.get $3)
                  (local.tee $2
                   (i64.sub
                    (i64.const 0)
                    (local.get $3)
                   )
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global702)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global356)
                )
               )
               (local.set $10
                (call $function122
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global655)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global356)
                )
               )
               (local.set $7
                (call $function122
                 (local.get $2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global644)
                )
               )
               (local.set $7
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $7)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global356)
                   )
                  )
                  (call $function189
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $10)
                   (local.get $7)
                   (call $function122
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global457)
                )
               )
               (local.set $9
                (call $function146
                 (local.get $9)
                 (local.get $7)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global702)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global356)
                )
               )
               (local.set $10
                (call $function122
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global655)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global356)
                )
               )
               (local.set $7
                (call $function122
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global644)
                )
               )
               (local.set $7
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $7)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global356)
                   )
                  )
                  (call $function189
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $10)
                   (local.get $7)
                   (call $function122
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global457)
                )
               )
               (local.set $11
                (call $function146
                 (local.get $11)
                 (local.get $7)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global717)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global539)
              )
             )
             (local.set $14
              (call $function162
               (local.get $9)
               (local.get $11)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global364)
              )
             )
             (local.set $2
              (call $function125
               (local.tee $15
                (struct.get $type28 1
                 (local.tee $9
                  (struct.get $type148 0
                   (local.get $14)
                  )
                 )
                )
               )
               (i32.const 1)
               (local.tee $5
                (struct.get $type28 0
                 (local.get $9)
                )
               )
               (i32.const 1)
               (select
                (i64.const -9223372036854775808)
                (i64.const -9223372036854775807)
                (local.get $5)
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.extend_i32_u
                (array.len
                 (local.get $15)
                )
               )
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global430)
              )
             )
             (if
              (if (result i32)
               (i64.gt_s
                (local.tee $4
                 (call $function128
                  (call $function140
                   (local.tee $9
                    (struct.get $type148 1
                     (local.get $14)
                    )
                   )
                   (local.get $9)
                  )
                  (block (result (ref $type28))
                   (drop
                    (ref.as_non_null
                     (global.get $global386)
                    )
                   )
                   (local.get $11)
                  )
                 )
                )
                (i64.const 0)
               )
               (then
                (i32.const 1)
               )
               (else
                (if (result i32)
                 (i64.eqz
                  (local.get $4)
                 )
                 (then
                  (i64.eq
                   (i64.rem_s
                    (local.get $2)
                    (i64.const 2)
                   )
                   (i64.const 1)
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
              (then
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.get $2)
                   (local.tee $2
                    (i64.add
                     (local.get $2)
                     (i64.const 1)
                    )
                   )
                  )
                  (i64.xor
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global704)
              )
             )
             (f64.mul
              (f64.convert_i64_s
               (local.get $2)
              )
              (call $function206
               (select
                (f64.const 0.5)
                (f64.const 2.0)
                (local.tee $5
                 (i64.lt_s
                  (local.get $3)
                  (i64.const 0)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (if (result i64)
                (local.get $5)
                (then
                 (if
                  (i64.lt_s
                   (i64.and
                    (local.get $3)
                    (local.tee $2
                     (i64.sub
                      (i64.const 0)
                      (local.get $3)
                     )
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.get $2)
                )
                (else
                 (local.get $3)
                )
               )
               (f64.const 1.0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (select
        (i32.eqz
         (local.tee $5
          (struct.get $type28 0
           (local.get $1)
          )
         )
        )
        (local.get $5)
        (struct.get $type28 0
         (local.get $0)
        )
       )
       (then
        (if
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $6)
           )
           (f64.const inf)
          )
          (f64.eq
           (f64.abs
            (local.tee $6
             (f64.sub
              (f64.const -0.0)
              (local.get $6)
             )
            )
           )
           (f64.const inf)
          )
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (local.get $6)
     )
    )
   )
  )
 )
 (func $function214 (type $call140) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global347)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $0)
   )
   (then
    (local.set $0
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global347)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global548)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global539)
     )
    )
    (local.set $0
     (struct.get $type148 1
      (call $function162
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global548)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global539)
       )
      )
      (local.set $1
       (struct.get $type148 1
        (call $function162
         (local.get $1)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global548)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global539)
         )
        )
        (local.set $0
         (struct.get $type148 1
          (call $function162
           (local.get $0)
           (local.get $1)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global345)
         )
        )
        (if (result (ref $type28))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type28 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global548)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global539)
           )
          )
          (local.set $1
           (struct.get $type148 1
            (call $function162
             (local.get $1)
             (local.get $0)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global345)
           )
          )
          (if (result (ref $type28))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type28 1
               (local.get $1)
              )
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global548)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global539)
             )
            )
            (local.set $0
             (struct.get $type148 1
              (call $function162
               (local.get $0)
               (local.get $1)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global345)
             )
            )
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type28 1
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global548)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global539)
               )
              )
              (local.set $1
               (struct.get $type148 1
                (call $function162
                 (local.get $1)
                 (local.get $0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global345)
               )
              )
              (if (result (ref $type28))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type28 1
                   (local.get $1)
                  )
                 )
                )
               )
               (then
                (local.get $0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global548)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global539)
                 )
                )
                (local.set $0
                 (struct.get $type148 1
                  (call $function162
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (if (result (ref $type28))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (struct.get $type28 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global548)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global539)
                   )
                  )
                  (local.set $1
                   (struct.get $type148 1
                    (call $function162
                     (local.get $1)
                     (local.get $0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (if (result (ref $type28))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type28 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global548)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global539)
                     )
                    )
                    (local.set $0
                     (struct.get $type148 1
                      (call $function162
                       (local.get $0)
                       (local.get $1)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global345)
                     )
                    )
                    (if (result (ref $type28))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global548)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global539)
                       )
                      )
                      (local.set $1
                       (struct.get $type148 1
                        (call $function162
                         (local.get $1)
                         (local.get $0)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global345)
                       )
                      )
                      (if (result (ref $type28))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type28 1
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global548)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global539)
                         )
                        )
                        (local.set $0
                         (struct.get $type148 1
                          (call $function162
                           (local.get $0)
                           (local.get $1)
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global345)
                         )
                        )
                        (if (result (ref $type28))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type28 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global548)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global539)
                           )
                          )
                          (local.set $1
                           (struct.get $type148 1
                            (call $function162
                             (local.get $1)
                             (local.get $0)
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global345)
                           )
                          )
                          (if (result (ref $type28))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type28 1
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global548)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global539)
                             )
                            )
                            (local.set $0
                             (struct.get $type148 1
                              (call $function162
                               (local.get $0)
                               (local.get $1)
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global345)
                             )
                            )
                            (if (result (ref $type28))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (struct.get $type28 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global548)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global539)
                               )
                              )
                              (local.set $1
                               (struct.get $type148 1
                                (call $function162
                                 (local.get $1)
                                 (local.get $0)
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global345)
                               )
                              )
                              (if (result (ref $type28))
                               (call $function117
                                (local.get $1)
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global548)
                                 )
                                )
                                (return_call $function215
                                 (i32.const 0)
                                 (i32.const 1)
                                 (local.get $1)
                                 (call $function164
                                  (local.get $0)
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function215 (type $82) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type28))
   (call $function117
    (local.get $3)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global548)
     )
    )
    (local.set $2
     (call $function164
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function215
     (local.get $0)
     (local.get $1)
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function222 (type $call171) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type27))
  (local $2 (ref $type28))
  (local $3 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type27))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global349)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (if
       (i64.ne
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $0
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $0)
           )
          )
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global347)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global742)
     )
    )
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (local.set $1
       (struct.new $type28
        (i32.const 0)
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
    (local.set $2
     (call $function214
      (local.get $0)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global545)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global539)
     )
    )
    (struct.new $type27
     (struct.get $type148 0
      (call $function162
       (local.get $0)
       (local.get $2)
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global545)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global539)
       )
      )
      (struct.get $type148 0
       (call $function162
        (local.get $1)
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function310 (type $79) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result i32)
  (local $8 i32)
  (local $9 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign19
     (local.get $1)
     (array.get $type19
      (if (result (ref $type19))
       (i32.lt_u
        (local.tee $8
         (i32.wrap_i64
          (local.get $7)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type18 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type20
          (struct.get $type18 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $8)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $8)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $9
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function310
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $9)
    )
   )
  )
 )
 (func $function318 (type $78) (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i32) (param $5 (ref $type18)) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i64) (result (ref $type18))
  (local $10 i32)
  (local $11 i32)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $3)
    (local.get $9)
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (local.get $5)
   )
   (else
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (call $foreign27
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.wrap_i64
       (local.get $9)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $5)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $9)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $10
        (i32.wrap_i64
         (local.get $9)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $5)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $5)
         )
         (i32.sub
          (i32.shr_u
           (local.get $10)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $10)
      (i32.const 8191)
     )
     (local.get $11)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $12
         (i64.add
          (local.get $9)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $12)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function318
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $12)
    )
   )
  )
 )
 (func $function320 (type $call212) (param $0 i32) (param $1 i32) (param $2 i32) (result (ref $type32))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type27))
  (local $12 (ref $type18))
  (local $13 (ref $type18))
  (local $14 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global1154)
   )
  )
  (local.set $12
   (call $function318
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (local.tee $3
     (i64.extend_i32_s
      (call $foreign26
       (local.get $0)
       (local.get $1)
       (i32.const 0)
      )
     )
    )
    (i32.const 1)
    (block (result (ref $type18))
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (if
      (i64.gt_u
       (local.get $3)
       (i64.const 4294967294)
      )
      (then
       (unreachable)
      )
     )
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1162)
   )
  )
  (local.set $4
   (i64.extend_i32_s
    (call $foreign29
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (local.set $3
   (call $foreign28
    (local.get $0)
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global594)
   )
  )
  (local.set $6
   (call $function175
    (local.get $12)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1154)
   )
  )
  (local.set $8
   (call $function175
    (call $function318
     (local.get $0)
     (local.get $1)
     (i32.const 1)
     (local.tee $5
      (i64.extend_i32_s
       (call $foreign26
        (local.get $0)
        (local.get $1)
        (i32.const 1)
       )
      )
     )
     (i32.const 1)
     (block (result (ref $type18))
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-new
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (i64.const 0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global594)
      )
     )
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global356)
   )
  )
  (local.set $10
   (call $function122
    (i64.const 10)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global655)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global356)
   )
  )
  (local.set $7
   (call $function122
    (if (result i64)
     (i64.lt_s
      (local.get $3)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $3)
         (local.tee $4
          (i64.sub
           (i64.const 0)
           (local.get $3)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $4)
     )
     (else
      (local.get $3)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global644)
   )
  )
  (local.set $7
   (if (result (ref $type28))
    (struct.get $type28 0
     (local.get $7)
    )
    (then
     (unreachable)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global356)
      )
     )
     (call $function189
      (i32.const 0)
      (i32.const 1)
      (local.get $10)
      (local.get $7)
      (call $function122
       (i64.const 1)
      )
     )
    )
   )
  )
  (local.set $11
   (if (result (ref $type27))
    (i64.lt_s
     (local.get $3)
     (i64.const 0)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global457)
      )
     )
     (local.set $9
      (call $function146
       (local.get $8)
       (local.get $7)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global769)
      )
     )
     (call $function222
      (local.get $6)
      (local.get $9)
     )
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global457)
      )
     )
     (call $function222
      (call $function146
       (local.get $6)
       (local.get $7)
      )
      (block (result (ref $type28))
       (drop
        (ref.as_non_null
         (global.get $global769)
        )
       )
       (local.get $8)
      )
     )
    )
   )
  )
  (if (result (ref $type32))
   (i32.eq
    (local.get $2)
    (i32.const 5)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global835)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global778)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global390)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global386)
     )
    )
    (if (result (ref $type32))
     (if (result i32)
      (i64.eqz
       (call $function128
        (struct.get $type27 1
         (local.get $11)
        )
        (ref.as_non_null
         (global.get $global768)
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global740)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global356)
        )
       )
       (local.set $6
        (call $function122
         (i64.const -9223372036854775808)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global402)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global386)
        )
       )
       (if (result i32)
        (i64.ge_s
         (call $function128
          (local.tee $8
           (struct.get $type27 0
            (local.get $11)
           )
          )
          (local.get $6)
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global356)
          )
         )
         (local.set $6
          (call $function122
           (i64.const 9223372036854775807)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global396)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global386)
          )
         )
         (i64.le_s
          (call $function128
           (local.get $8)
           (local.get $6)
          )
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global364)
       )
      )
      (struct.new $type33
       (i32.const 0)
       (call $function125
        (local.tee $14
         (struct.get $type28 1
          (local.tee $6
           (struct.get $type27 0
            (local.get $11)
           )
          )
         )
        )
        (i32.const 1)
        (local.tee $0
         (struct.get $type28 0
          (local.get $6)
         )
        )
        (i32.const 1)
        (select
         (i64.const -9223372036854775808)
         (i64.const -9223372036854775807)
         (local.get $0)
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.extend_i32_u
         (array.len
          (local.get $14)
         )
        )
        (i64.const 0)
       )
      )
     )
     (else
      (struct.new $type34
       (i32.const 1)
       (local.get $11)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global780)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (if (result f64)
      (if (result i32)
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (struct.get $type27 0
            (local.get $11)
           )
          )
         )
        )
       )
       (then
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $12)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (array.get $type19
          (struct.get $type18 2
           (local.get $12)
          )
          (i32.const 0)
         )
         (i32.const 45)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (f64.const -0.0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global827)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global734)
        )
       )
       (call $function211
        (struct.get $type27 0
         (local.get $11)
        )
        (struct.get $type27 1
         (local.get $11)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function323 (type $73) (param $0 i32) (param $1 i64) (param $2 i32) (param $3 (ref $type18)) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result (ref $type18))
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.extend32_s
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (call $foreign34
      (local.get $0)
      (i32.wrap_i64
       (local.get $7)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $3)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $3)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $3)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (local.get $9)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $10
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function323
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $10)
    )
   )
  )
 )
 (func $function325 (type $call215) (param $0 i32) (param $1 i32) (result (ref $type216))
  (local $2 (ref $type32))
  (local $3 (ref $type32))
  (local $4 (ref $type27))
  (local $5 i32)
  (local $6 i64)
  (local $7 f64)
  (local $8 f64)
  (if (result (ref $type216))
   (local.get $1)
   (then
    (if (result (ref $type216))
     (i32.eq
      (local.get $1)
      (i32.const 4)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1181)
       )
      )
      (struct.new $type219
       (i32.const 2)
       (call $function323
        (local.get $0)
        (local.tee $6
         (i64.extend_i32_s
          (call $foreign33
           (local.get $0)
          )
         )
        )
        (i32.const 1)
        (block (result (ref $type18))
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (call $string-new
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
     )
     (else
      (if (result (ref $type216))
       (i32.eq
        (local.get $1)
        (i32.const 3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1177)
         )
        )
        (local.set $3
         (if (result (ref $type32))
          (i32.eq
           (local.tee $1
            (call $foreign32
             (local.get $0)
             (i32.const 0)
            )
           )
           (i32.const 1)
          )
          (then
           (struct.new $type33
            (i32.const 0)
            (call $foreign31
             (local.get $0)
             (i32.const 0)
            )
           )
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (local.get $1)
             (i32.const 2)
            )
            (then
             (struct.new $type35
              (i32.const 2)
              (call $foreign30
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1171)
              )
             )
             (call $function320
              (local.get $0)
              (i32.const 0)
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1177)
         )
        )
        (local.set $2
         (if (result (ref $type32))
          (i32.eq
           (local.tee $1
            (call $foreign32
             (local.get $0)
             (i32.const 1)
            )
           )
           (i32.const 1)
          )
          (then
           (struct.new $type33
            (i32.const 0)
            (call $foreign31
             (local.get $0)
             (i32.const 1)
            )
           )
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (local.get $1)
             (i32.const 2)
            )
            (then
             (struct.new $type35
              (i32.const 2)
              (call $foreign30
               (local.get $0)
               (i32.const 1)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1171)
              )
             )
             (call $function320
              (local.get $0)
              (i32.const 1)
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global871)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global847)
         )
        )
        (struct.new $type218
         (i32.const 1)
         (if (result (ref $type24))
          (if (result i32)
           (if (result i32)
            (local.tee $0
             (struct.get $type32 0
              (local.get $2)
             )
            )
            (then
             (if (result i32)
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type34)
                 (local.get $2)
                )
               )
               (i32.const 1)
              )
              (else
               (drop
                (ref.cast (ref $type35)
                 (local.get $2)
                )
               )
               (i32.const 0)
              )
             )
            )
            (else
             (drop
              (ref.cast (ref $type33)
               (local.get $2)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global853)
             )
            )
            (if (result i32)
             (local.tee $0
              (struct.get $type32 0
               (local.get $2)
              )
             )
             (then
              (if (result i32)
               (i32.eq
                (local.get $0)
                (i32.const 1)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global780)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (i64.eqz
                 (i64.extend_i32_u
                  (array.len
                   (struct.get $type28 1
                    (struct.get $type27 0
                     (struct.get $type34 1
                      (ref.cast (ref $type34)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (f64.eq
                 (struct.get $type35 1
                  (ref.cast (ref $type35)
                   (local.get $2)
                  )
                 )
                 (f64.const 0.0)
                )
               )
              )
             )
             (else
              (i64.eqz
               (struct.get $type33 1
                (ref.cast (ref $type33)
                 (local.get $2)
                )
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global837)
            )
           )
           (if (result (ref $type24))
            (local.tee $0
             (struct.get $type32 0
              (local.get $3)
             )
            )
            (then
             (if (result (ref $type24))
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (struct.new $type26
                (i32.const 1)
                (struct.get $type34 1
                 (ref.cast (ref $type34)
                  (local.get $3)
                 )
                )
               )
              )
              (else
               (struct.new $type30
                (i32.const 2)
                (struct.get $type35 1
                 (ref.cast (ref $type35)
                  (local.get $3)
                 )
                )
               )
              )
             )
            )
            (else
             (struct.new $type25
              (i32.const 0)
              (struct.get $type33 1
               (ref.cast (ref $type33)
                (local.get $3)
               )
              )
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global847)
            )
           )
           (if (result (ref $type31))
            (if (result i32)
             (if (result i32)
              (local.tee $0
               (struct.get $type32 0
                (local.get $3)
               )
              )
              (then
               (if (result i32)
                (i32.eq
                 (local.get $0)
                 (i32.const 1)
                )
                (then
                 (drop
                  (ref.cast (ref $type34)
                   (local.get $3)
                  )
                 )
                 (i32.const 1)
                )
                (else
                 (drop
                  (ref.cast (ref $type35)
                   (local.get $3)
                  )
                 )
                 (i32.const 0)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type33)
                 (local.get $3)
                )
               )
               (i32.const 1)
              )
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global847)
               )
              )
              (if (result i32)
               (local.tee $0
                (struct.get $type32 0
                 (local.get $2)
                )
               )
               (then
                (if (result i32)
                 (i32.eq
                  (local.get $0)
                  (i32.const 1)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type34)
                    (local.get $2)
                   )
                  )
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.cast (ref $type35)
                    (local.get $2)
                   )
                  )
                  (i32.const 0)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type33)
                  (local.get $2)
                 )
                )
                (i32.const 1)
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (struct.new $type31
              (i32.const 3)
              (local.get $3)
              (local.get $2)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global859)
              )
             )
             (struct.new $type31
              (i32.const 3)
              (struct.new $type35
               (i32.const 2)
               (if (result f64)
                (local.tee $0
                 (struct.get $type32 0
                  (local.get $3)
                 )
                )
                (then
                 (if (result f64)
                  (i32.eq
                   (local.get $0)
                   (i32.const 1)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global827)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global734)
                    )
                   )
                   (call $function211
                    (struct.get $type27 0
                     (local.tee $4
                      (struct.get $type34 1
                       (ref.cast (ref $type34)
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (struct.get $type27 1
                     (local.get $4)
                    )
                   )
                  )
                  (else
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (local.get $3)
                    )
                   )
                  )
                 )
                )
                (else
                 (f64.convert_i64_s
                  (struct.get $type33 1
                   (ref.cast (ref $type33)
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
              (block (result (ref (exact $type35)))
               (drop
                (ref.as_non_null
                 (global.get $global859)
                )
               )
               (struct.new $type35
                (i32.const 2)
                (if (result f64)
                 (local.tee $0
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result f64)
                   (i32.eq
                    (local.get $0)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global827)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global734)
                     )
                    )
                    (call $function211
                     (struct.get $type27 0
                      (local.tee $4
                       (struct.get $type34 1
                        (ref.cast (ref $type34)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (struct.get $type27 1
                      (local.get $4)
                     )
                    )
                   )
                   (else
                    (struct.get $type35 1
                     (ref.cast (ref $type35)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (f64.convert_i64_s
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (else
        (if (result (ref $type216))
         (i32.or
          (i32.eq
           (local.get $1)
           (i32.const 8)
          )
          (i32.eq
           (local.get $1)
           (i32.const 7)
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global1187)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1177)
           )
          )
          (local.set $2
           (if (result (ref $type32))
            (i32.eq
             (local.tee $5
              (call $foreign32
               (local.get $0)
               (i32.const 0)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign31
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $5)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign30
                 (local.get $0)
                 (i32.const 0)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1171)
                )
               )
               (call $function320
                (local.get $0)
                (i32.const 0)
                (local.get $5)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1177)
           )
          )
          (local.set $3
           (if (result (ref $type32))
            (i32.eq
             (local.tee $5
              (call $foreign32
               (local.get $0)
               (i32.const 1)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign31
               (local.get $0)
               (i32.const 1)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $5)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign30
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1171)
                )
               )
               (call $function320
                (local.get $0)
                (i32.const 1)
                (local.get $5)
               )
              )
             )
            )
           )
          )
          (if (result (ref $type216))
           (if (result i32)
            (i32.eq
             (local.get $1)
             (i32.const 8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global847)
              )
             )
             (i32.eqz
              (if (result i32)
               (if (result i32)
                (if (result i32)
                 (local.tee $0
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result i32)
                   (i32.eq
                    (local.get $0)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.cast (ref $type34)
                      (local.get $2)
                     )
                    )
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.cast (ref $type35)
                      (local.get $2)
                     )
                    )
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type33)
                    (local.get $2)
                   )
                  )
                  (i32.const 1)
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global853)
                  )
                 )
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $2)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global780)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global345)
                      )
                     )
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type28 1
                         (struct.get $type27 0
                          (struct.get $type34 1
                           (ref.cast (ref $type34)
                            (local.get $2)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (f64.eq
                      (struct.get $type35 1
                       (ref.cast (ref $type35)
                        (local.get $2)
                       )
                      )
                      (f64.const 0.0)
                     )
                    )
                   )
                  )
                  (else
                   (i64.eqz
                    (struct.get $type33 1
                     (ref.cast (ref $type33)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global847)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $3)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type34)
                       (local.get $3)
                      )
                     )
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type35)
                       (local.get $3)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type33)
                     (local.get $3)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global853)
                   )
                  )
                  (if (result i32)
                   (local.tee $0
                    (struct.get $type32 0
                     (local.get $3)
                    )
                   )
                   (then
                    (if (result i32)
                     (i32.eq
                      (local.get $0)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global780)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global345)
                       )
                      )
                      (i64.eqz
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type28 1
                          (struct.get $type27 0
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $3)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (f64.eq
                       (struct.get $type35 1
                        (ref.cast (ref $type35)
                         (local.get $3)
                        )
                       )
                       (f64.const 0.0)
                      )
                     )
                    )
                   )
                   (else
                    (i64.eqz
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (struct.new $type219
             (i32.const 2)
             (global.get $string7)
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global874)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global847)
             )
            )
            (struct.new $type218
             (i32.const 1)
             (if (result (ref $type24))
              (if (result i32)
               (if (result i32)
                (local.tee $0
                 (struct.get $type32 0
                  (local.get $2)
                 )
                )
                (then
                 (if (result i32)
                  (i32.eq
                   (local.get $0)
                   (i32.const 1)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type34)
                     (local.get $2)
                    )
                   )
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type35)
                     (local.get $2)
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (drop
                  (ref.cast (ref $type33)
                   (local.get $2)
                  )
                 )
                 (i32.const 1)
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global853)
                 )
                )
                (if (result i32)
                 (local.tee $0
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result i32)
                   (i32.eq
                    (local.get $0)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global780)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global345)
                     )
                    )
                    (i64.eqz
                     (i64.extend_i32_u
                      (array.len
                       (struct.get $type28 1
                        (struct.get $type27 0
                         (struct.get $type34 1
                          (ref.cast (ref $type34)
                           (local.get $2)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (f64.eq
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $2)
                      )
                     )
                     (f64.const 0.0)
                    )
                   )
                  )
                 )
                 (else
                  (i64.eqz
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (struct.new_default $type25)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global847)
                )
               )
               (if (result (ref $type24))
                (if (result i32)
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $3)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type34)
                       (local.get $3)
                      )
                     )
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type35)
                       (local.get $3)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type33)
                     (local.get $3)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global853)
                   )
                  )
                  (if (result i32)
                   (local.tee $0
                    (struct.get $type32 0
                     (local.get $3)
                    )
                   )
                   (then
                    (if (result i32)
                     (i32.eq
                      (local.get $0)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global780)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global345)
                       )
                      )
                      (i64.eqz
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type28 1
                          (struct.get $type27 0
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $3)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (f64.eq
                       (struct.get $type35 1
                        (ref.cast (ref $type35)
                         (local.get $3)
                        )
                       )
                       (f64.const 0.0)
                      )
                     )
                    )
                   )
                   (else
                    (i64.eqz
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global837)
                  )
                 )
                 (if (result (ref $type24))
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $2)
                   )
                  )
                  (then
                   (if (result (ref $type24))
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (struct.new $type26
                      (i32.const 1)
                      (struct.get $type34 1
                       (ref.cast (ref $type34)
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (else
                     (struct.new $type30
                      (i32.const 2)
                      (struct.get $type35 1
                       (ref.cast (ref $type35)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                  (else
                   (struct.new $type25
                    (i32.const 0)
                    (struct.get $type33 1
                     (ref.cast (ref $type33)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global859)
                  )
                 )
                 (struct.new $type31
                  (i32.const 3)
                  (struct.new $type35
                   (i32.const 2)
                   (f64.mul
                    (local.tee $7
                     (if (result f64)
                      (local.tee $0
                       (struct.get $type32 0
                        (local.get $2)
                       )
                      )
                      (then
                       (if (result f64)
                        (i32.eq
                         (local.get $0)
                         (i32.const 1)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global827)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global734)
                          )
                         )
                         (call $function211
                          (struct.get $type27 0
                           (local.tee $4
                            (struct.get $type34 1
                             (ref.cast (ref $type34)
                              (local.get $2)
                             )
                            )
                           )
                          )
                          (struct.get $type27 1
                           (local.get $4)
                          )
                         )
                        )
                        (else
                         (struct.get $type35 1
                          (ref.cast (ref $type35)
                           (local.get $2)
                          )
                         )
                        )
                       )
                      )
                      (else
                       (f64.convert_i64_s
                        (struct.get $type33 1
                         (ref.cast (ref $type33)
                          (local.get $2)
                         )
                        )
                       )
                      )
                     )
                    )
                    (block (result f64)
                     (drop
                      (ref.as_non_null
                       (global.get $global859)
                      )
                     )
                     (call $foreign11
                      (local.tee $8
                       (if (result f64)
                        (local.tee $0
                         (struct.get $type32 0
                          (local.get $3)
                         )
                        )
                        (then
                         (if (result f64)
                          (i32.eq
                           (local.get $0)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.as_non_null
                             (global.get $global827)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global734)
                            )
                           )
                           (call $function211
                            (struct.get $type27 0
                             (local.tee $4
                              (struct.get $type34 1
                               (ref.cast (ref $type34)
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (struct.get $type27 1
                             (local.get $4)
                            )
                           )
                          )
                          (else
                           (struct.get $type35 1
                            (ref.cast (ref $type35)
                             (local.get $3)
                            )
                           )
                          )
                         )
                        )
                        (else
                         (f64.convert_i64_s
                          (struct.get $type33 1
                           (ref.cast (ref $type33)
                            (local.get $3)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (struct.new $type35
                   (i32.const 2)
                   (f64.mul
                    (local.get $7)
                    (call $foreign12
                     (local.get $8)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global1177)
           )
          )
          (local.set $2
           (if (result (ref $type32))
            (i32.eq
             (local.tee $1
              (call $foreign32
               (local.get $0)
               (i32.const 0)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign31
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $1)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign30
                 (local.get $0)
                 (i32.const 0)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1171)
                )
               )
               (call $function320
                (local.get $0)
                (i32.const 0)
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global837)
           )
          )
          (struct.new $type218
           (i32.const 1)
           (if (result (ref $type24))
            (local.tee $0
             (struct.get $type32 0
              (local.get $2)
             )
            )
            (then
             (if (result (ref $type24))
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (struct.new $type26
                (i32.const 1)
                (struct.get $type34 1
                 (ref.cast (ref $type34)
                  (local.get $2)
                 )
                )
               )
              )
              (else
               (struct.new $type30
                (i32.const 2)
                (struct.get $type35 1
                 (ref.cast (ref $type35)
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (else
             (struct.new $type25
              (i32.const 0)
              (struct.get $type33 1
               (ref.cast (ref $type33)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty217)
   )
  )
 )
 (func $function331 (type $65) (result (ref $type36))
  (local $0 i64)
  (local $1 i64)
  (local $2 (ref $type228))
  (drop
   (ref.as_non_null
    (global.get $global1217)
   )
  )
  (if
   (i64.eq
    (local.tee $0
     (struct.get $type228 0
      (global.get $global1216)
     )
    )
    (i64.const 9223372036854775807)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1136)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1128)
     )
    )
    (call $foreign20
     (call $function310
      (global.get $string10)
      (call $foreign18)
      (i32.const 1)
      (i64.const 40)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (unreachable)
   )
   (else
    (struct.set $type228 0
     (ref.as_non_null
      (global.get $global1216)
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $0)
          (local.tee $1
           (i64.add
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $1)
     )
    )
   )
  )
  (struct.new $type36
   (i32.const 6)
  )
 )
 (func $function339 (type $call235) (param $0 (ref $type13)) (result i32)
  (local $1 i32)
  (drop
   (ref.as_non_null
    (global.get $global1237)
   )
  )
  (i64.eq
   (if (result i64)
    (local.tee $1
     (struct.get $type13 0
      (local.get $0)
     )
    )
    (then
     (if (result i64)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type15)
         (local.get $0)
        )
       )
       (i64.const 1)
      )
      (else
       (if (result i64)
        (i32.eq
         (struct.get $type13 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (drop
          (ref.cast (ref $type16)
           (local.get $0)
          )
         )
         (i64.const 2)
        )
        (else
         (if (result i64)
          (i32.eq
           (struct.get $type13 0
            (local.get $0)
           )
           (i32.const 3)
          )
          (then
           (drop
            (ref.cast (ref $type17)
             (local.get $0)
            )
           )
           (i64.const 3)
          )
          (else
           (if (result i64)
            (i32.eq
             (struct.get $type13 0
              (local.get $0)
             )
             (i32.const 4)
            )
            (then
             (drop
              (ref.cast (ref $type21)
               (local.get $0)
              )
             )
             (i64.const 4)
            )
            (else
             (if (result i64)
              (i32.eq
               (struct.get $type13 0
                (local.get $0)
               )
               (i32.const 5)
              )
              (then
               (drop
                (ref.cast (ref $type23)
                 (local.get $0)
                )
               )
               (i64.const 5)
              )
              (else
               (if (result i64)
                (i32.eq
                 (struct.get $type13 0
                  (local.get $0)
                 )
                 (i32.const 6)
                )
                (then
                 (drop
                  (ref.cast (ref $type36)
                   (local.get $0)
                  )
                 )
                 (i64.const 6)
                )
                (else
                 (if (result i64)
                  (i32.eq
                   (struct.get $type13 0
                    (local.get $0)
                   )
                   (i32.const 7)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type38)
                     (local.get $0)
                    )
                   )
                   (i64.const 7)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type40)
                     (local.get $0)
                    )
                   )
                   (i64.const 8)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (i64.const 0)
    )
   )
   (i64.const 5)
  )
 )
 (func $function375 (type $call46) (param $0 (ref null $type12)) (result (ref $type39))
  (local $1 (ref null $type12))
  (local $2 i64)
  (if (result (ref $type39))
   (ref.is_null
    (local.get $0)
   )
   (then
    (array.new_fixed $type39 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1421)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1421)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (if (result i64)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type12 1
             (local.get $0)
            )
           )
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 2)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 3)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 4)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $1
                        (struct.get $type12 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $1
                          (struct.get $type12 1
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $1
                            (struct.get $type12 1
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i64.const 9)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $1
                              (struct.get $type12 1
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (i64.const 10)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $1
                                (struct.get $type12 1
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i64.const 11)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $1
                                  (struct.get $type12 1
                                   (local.get $1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 12)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $1
                                    (struct.get $type12 1
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 13)
                                  )
                                  (else
                                   (call $function377
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type12 1
                                     (local.get $1)
                                    )
                                    (i64.const 14)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function378
     (array.new $type39
      (struct.get $type12 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (local.get $0)
     (i64.const 0)
    )
   )
  )
 )
 (func $function377 (type $52) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function377
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function378 (type $51) (param $0 (ref null $type39)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type39))
  (local $6 i64)
  (local $7 (ref $type13))
  (if (result (ref $type39))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type39
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function378
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function412 (type $call260) (param $0 (ref $type223)) (result (ref $type13))
  (local $1 (ref $type18))
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type223 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (struct.get $type225 1
     (ref.cast (ref $type225)
      (local.get $0)
     )
    )
   )
   (else
    (if
     (struct.get $type223 0
      (local.get $0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global88)
       )
      )
      (local.set $1
       (call $function35
        (struct.new $type61
         (global.get $string27)
         (struct.new $type61
          (struct.get $type226 1
           (ref.cast (ref $type226)
            (local.get $0)
           )
          )
          (ref.null none)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1136)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1128)
       )
      )
      (call $foreign20
       (call $function310
        (local.get $1)
        (call $foreign18)
        (i32.const 1)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $1)
         )
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1136)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1128)
       )
      )
      (call $foreign20
       (call $function310
        (global.get $string28)
        (call $foreign18)
        (i32.const 1)
        (i64.const 44)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function414 (type $call275) (param $0 (ref $type68)) (result (ref $type276))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type84))
  (local $8 (ref $type216))
  (local $9 (ref $type268))
  (local $10 (ref $type223))
  (local $11 (ref $type294))
  (local $12 (ref $type276))
  (local $scratch (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global1576)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $2
   (call $foreign7
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (block $block
   (return
    (if (result (ref $type278))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type85)
         (local.tee $7
          (if (result (ref $type84))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty85)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type86
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type86 0
           (ref.cast (ref $type86)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty278)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1582)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign37
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1584)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1587)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1576)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global139)
         )
        )
        (local.set $2
         (call $foreign7
          (struct.get $type66 0
           (struct.get $type68 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1578)
         )
        )
        (drop
         (if (result i32)
          (if (result i32)
           (i64.lt_s
            (local.tee $1
             (if (result i64)
              (ref.test (ref $type85)
               (local.tee $7
                (if (result (ref $type84))
                 (i32.eq
                  (local.get $2)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty85)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $1
                     (i64.extend_i32_s
                      (local.get $2)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $1)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $1)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type86
                   (i32.wrap_i64
                    (local.get $1)
                   )
                  )
                 )
                )
               )
              )
              (then
               (i64.const -1)
              )
              (else
               (i64.extend_i32_u
                (struct.get $type86 0
                 (ref.cast (ref $type86)
                  (local.get $7)
                 )
                )
               )
              )
             )
            )
            (i64.const 0)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1584)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 10)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1584)
               )
              )
              (i64.eq
               (local.get $1)
               (i64.const 13)
              )
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready1587)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1587)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1576)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global139)
            )
           )
           (local.set $2
            (call $foreign7
             (struct.get $type66 0
              (struct.get $type68 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1578)
            )
           )
           (if (result i32)
            (if (result i32)
             (i64.lt_s
              (local.tee $1
               (if (result i64)
                (ref.test (ref $type85)
                 (local.tee $7
                  (if (result (ref $type84))
                   (i32.eq
                    (local.get $2)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty85)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (i64.extend_i32_s
                        (local.get $2)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $1)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $1)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type86
                     (i32.wrap_i64
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type86 0
                   (ref.cast (ref $type86)
                    (local.get $7)
                   )
                  )
                 )
                )
               )
              )
              (i64.const 0)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1584)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 10)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1584)
                 )
                )
                (i64.eq
                 (local.get $1)
                 (i64.const 13)
                )
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready1587)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1587)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1576)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global139)
              )
             )
             (local.set $2
              (call $foreign7
               (struct.get $type66 0
                (struct.get $type68 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1578)
              )
             )
             (if (result i32)
              (if (result i32)
               (i64.lt_s
                (local.tee $1
                 (if (result i64)
                  (ref.test (ref $type85)
                   (local.tee $7
                    (if (result (ref $type84))
                     (i32.eq
                      (local.get $2)
                      (i32.const -1)
                     )
                     (then
                      (global.get $empty85)
                     )
                     (else
                      (if
                       (i64.gt_u
                        (local.tee $1
                         (i64.extend_i32_s
                          (local.get $2)
                         )
                        )
                        (i64.const 1114111)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.and
                        (i64.le_u
                         (local.get $1)
                         (i64.const 57343)
                        )
                        (i64.ge_u
                         (local.get $1)
                         (i64.const 55296)
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (struct.new $type86
                       (i32.wrap_i64
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i64.const -1)
                  )
                  (else
                   (i64.extend_i32_u
                    (struct.get $type86 0
                     (ref.cast (ref $type86)
                      (local.get $7)
                     )
                    )
                   )
                  )
                 )
                )
                (i64.const 0)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1584)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 10)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1584)
                   )
                  )
                  (i64.eq
                   (local.get $1)
                   (i64.const 13)
                  )
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready1587)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1587)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1576)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global139)
                )
               )
               (local.set $2
                (call $foreign7
                 (struct.get $type66 0
                  (struct.get $type68 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global137)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1578)
                )
               )
               (if (result i32)
                (if (result i32)
                 (i64.lt_s
                  (local.tee $1
                   (if (result i64)
                    (ref.test (ref $type85)
                     (local.tee $7
                      (if (result (ref $type84))
                       (i32.eq
                        (local.get $2)
                        (i32.const -1)
                       )
                       (then
                        (global.get $empty85)
                       )
                       (else
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (i64.extend_i32_s
                            (local.get $2)
                           )
                          )
                          (i64.const 1114111)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if
                         (i32.and
                          (i64.le_u
                           (local.get $1)
                           (i64.const 57343)
                          )
                          (i64.ge_u
                           (local.get $1)
                           (i64.const 55296)
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (struct.new $type86
                         (i32.wrap_i64
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i64.const -1)
                    )
                    (else
                     (i64.extend_i32_u
                      (struct.get $type86 0
                       (ref.cast (ref $type86)
                        (local.get $7)
                       )
                      )
                     )
                    )
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1584)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 10)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1584)
                     )
                    )
                    (i64.eq
                     (local.get $1)
                     (i64.const 13)
                    )
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready1587)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1587)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1576)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global139)
                  )
                 )
                 (local.set $2
                  (call $foreign7
                   (struct.get $type66 0
                    (struct.get $type68 0
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global137)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1578)
                  )
                 )
                 (if (result i32)
                  (if (result i32)
                   (i64.lt_s
                    (local.tee $1
                     (if (result i64)
                      (ref.test (ref $type85)
                       (local.tee $7
                        (if (result (ref $type84))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty85)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type86
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                      )
                      (then
                       (i64.const -1)
                      )
                      (else
                       (i64.extend_i32_u
                        (struct.get $type86 0
                         (ref.cast (ref $type86)
                          (local.get $7)
                         )
                        )
                       )
                      )
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1584)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 10)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1584)
                       )
                      )
                      (i64.eq
                       (local.get $1)
                       (i64.const 13)
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready1587)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1587)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1576)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global139)
                    )
                   )
                   (local.set $2
                    (call $foreign7
                     (struct.get $type66 0
                      (struct.get $type68 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1578)
                    )
                   )
                   (if (result i32)
                    (if (result i32)
                     (i64.lt_s
                      (local.tee $1
                       (if (result i64)
                        (ref.test (ref $type85)
                         (local.tee $7
                          (if (result (ref $type84))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty85)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type86
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type86 0
                           (ref.cast (ref $type86)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1584)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1584)
                         )
                        )
                        (i64.eq
                         (local.get $1)
                         (i64.const 13)
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if
                      (i32.eqz
                       (global.get $ready1587)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1587)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1576)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global139)
                      )
                     )
                     (local.set $2
                      (call $foreign7
                       (struct.get $type66 0
                        (struct.get $type68 0
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global137)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1578)
                      )
                     )
                     (if (result i32)
                      (if (result i32)
                       (i64.lt_s
                        (local.tee $1
                         (if (result i64)
                          (ref.test (ref $type85)
                           (local.tee $7
                            (if (result (ref $type84))
                             (i32.eq
                              (local.get $2)
                              (i32.const -1)
                             )
                             (then
                              (global.get $empty85)
                             )
                             (else
                              (if
                               (i64.gt_u
                                (local.tee $1
                                 (i64.extend_i32_s
                                  (local.get $2)
                                 )
                                )
                                (i64.const 1114111)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (if
                               (i32.and
                                (i64.le_u
                                 (local.get $1)
                                 (i64.const 57343)
                                )
                                (i64.ge_u
                                 (local.get $1)
                                 (i64.const 55296)
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (struct.new $type86
                               (i32.wrap_i64
                                (local.get $1)
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i64.const -1)
                          )
                          (else
                           (i64.extend_i32_u
                            (struct.get $type86 0
                             (ref.cast (ref $type86)
                              (local.get $7)
                             )
                            )
                           )
                          )
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1584)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 10)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1584)
                           )
                          )
                          (i64.eq
                           (local.get $1)
                           (i64.const 13)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready1587)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1587)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1576)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global139)
                        )
                       )
                       (local.set $2
                        (call $foreign7
                         (struct.get $type66 0
                          (struct.get $type68 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global137)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1578)
                        )
                       )
                       (if (result i32)
                        (if (result i32)
                         (i64.lt_s
                          (local.tee $1
                           (if (result i64)
                            (ref.test (ref $type85)
                             (local.tee $7
                              (if (result (ref $type84))
                               (i32.eq
                                (local.get $2)
                                (i32.const -1)
                               )
                               (then
                                (global.get $empty85)
                               )
                               (else
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (i64.extend_i32_s
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 1114111)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if
                                 (i32.and
                                  (i64.le_u
                                   (local.get $1)
                                   (i64.const 57343)
                                  )
                                  (i64.ge_u
                                   (local.get $1)
                                   (i64.const 55296)
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (struct.new $type86
                                 (i32.wrap_i64
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (then
                             (i64.const -1)
                            )
                            (else
                             (i64.extend_i32_u
                              (struct.get $type86 0
                               (ref.cast (ref $type86)
                                (local.get $7)
                               )
                              )
                             )
                            )
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1584)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 10)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (i64.eq
                             (local.get $1)
                             (i64.const 13)
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready1587)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1587)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1576)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global139)
                          )
                         )
                         (local.set $2
                          (call $foreign7
                           (struct.get $type66 0
                            (struct.get $type68 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global137)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1578)
                          )
                         )
                         (if (result i32)
                          (if (result i32)
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type85)
                               (local.tee $7
                                (if (result (ref $type84))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty85)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type86
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type86 0
                                 (ref.cast (ref $type86)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 10)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1584)
                               )
                              )
                              (i64.eq
                               (local.get $1)
                               (i64.const 13)
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if
                            (i32.eqz
                             (global.get $ready1587)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1587)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1576)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global139)
                            )
                           )
                           (local.set $2
                            (call $foreign7
                             (struct.get $type66 0
                              (struct.get $type68 0
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global137)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1578)
                            )
                           )
                           (if (result i32)
                            (if (result i32)
                             (i64.lt_s
                              (local.tee $1
                               (if (result i64)
                                (ref.test (ref $type85)
                                 (local.tee $7
                                  (if (result (ref $type84))
                                   (i32.eq
                                    (local.get $2)
                                    (i32.const -1)
                                   )
                                   (then
                                    (global.get $empty85)
                                   )
                                   (else
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (i64.extend_i32_s
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 1114111)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (if
                                     (i32.and
                                      (i64.le_u
                                       (local.get $1)
                                       (i64.const 57343)
                                      )
                                      (i64.ge_u
                                       (local.get $1)
                                       (i64.const 55296)
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (struct.new $type86
                                     (i32.wrap_i64
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i64.const -1)
                                )
                                (else
                                 (i64.extend_i32_u
                                  (struct.get $type86 0
                                   (ref.cast (ref $type86)
                                    (local.get $7)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (i64.const 0)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1584)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 10)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1584)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 13)
                                )
                               )
                              )
                             )
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if
                              (i32.eqz
                               (global.get $ready1587)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1587)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1576)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global139)
                              )
                             )
                             (local.set $2
                              (call $foreign7
                               (struct.get $type66 0
                                (struct.get $type68 0
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global137)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1578)
                              )
                             )
                             (if (result i32)
                              (if (result i32)
                               (i64.lt_s
                                (local.tee $1
                                 (if (result i64)
                                  (ref.test (ref $type85)
                                   (local.tee $7
                                    (if (result (ref $type84))
                                     (i32.eq
                                      (local.get $2)
                                      (i32.const -1)
                                     )
                                     (then
                                      (global.get $empty85)
                                     )
                                     (else
                                      (if
                                       (i64.gt_u
                                        (local.tee $1
                                         (i64.extend_i32_s
                                          (local.get $2)
                                         )
                                        )
                                        (i64.const 1114111)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (if
                                       (i32.and
                                        (i64.le_u
                                         (local.get $1)
                                         (i64.const 57343)
                                        )
                                        (i64.ge_u
                                         (local.get $1)
                                         (i64.const 55296)
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (struct.new $type86
                                       (i32.wrap_i64
                                        (local.get $1)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const -1)
                                  )
                                  (else
                                   (i64.extend_i32_u
                                    (struct.get $type86 0
                                     (ref.cast (ref $type86)
                                      (local.get $7)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1584)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 10)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1584)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $1)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if
                                (i32.eqz
                                 (global.get $ready1587)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1587)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1576)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global139)
                                )
                               )
                               (local.set $2
                                (call $foreign7
                                 (struct.get $type66 0
                                  (struct.get $type68 0
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global137)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1578)
                                )
                               )
                               (if (result i32)
                                (if (result i32)
                                 (i64.lt_s
                                  (local.tee $1
                                   (if (result i64)
                                    (ref.test (ref $type85)
                                     (local.tee $7
                                      (if (result (ref $type84))
                                       (i32.eq
                                        (local.get $2)
                                        (i32.const -1)
                                       )
                                       (then
                                        (global.get $empty85)
                                       )
                                       (else
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (i64.extend_i32_s
                                            (local.get $2)
                                           )
                                          )
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type86
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const -1)
                                    )
                                    (else
                                     (i64.extend_i32_u
                                      (struct.get $type86 0
                                       (ref.cast (ref $type86)
                                        (local.get $7)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1584)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 10)
                                   )
                                   (then
                                    (i32.const 1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1584)
                                     )
                                    )
                                    (i64.eq
                                     (local.get $1)
                                     (i64.const 13)
                                    )
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (if
                                  (i32.eqz
                                   (global.get $ready1587)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1587)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1576)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global139)
                                  )
                                 )
                                 (local.set $2
                                  (call $foreign7
                                   (struct.get $type66 0
                                    (struct.get $type68 0
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global137)
                                  )
                                 )
                                 (local.set $7
                                  (if (result (ref $type84))
                                   (i32.eq
                                    (local.get $2)
                                    (i32.const -1)
                                   )
                                   (then
                                    (global.get $empty85)
                                   )
                                   (else
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (i64.extend_i32_s
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 1114111)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (if
                                     (i32.and
                                      (i64.le_u
                                       (local.get $1)
                                       (i64.const 57343)
                                      )
                                      (i64.ge_u
                                       (local.get $1)
                                       (i64.const 55296)
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (struct.new $type86
                                     (i32.wrap_i64
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1578)
                                  )
                                 )
                                 (if (result i32)
                                  (if (result i32)
                                   (i64.lt_s
                                    (local.tee $1
                                     (if (result i64)
                                      (ref.test (ref $type85)
                                       (local.get $7)
                                      )
                                      (then
                                       (i64.const -1)
                                      )
                                      (else
                                       (i64.extend_i32_u
                                        (struct.get $type86 0
                                         (ref.cast (ref $type86)
                                          (local.get $7)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (i32.const 1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1584)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 10)
                                     )
                                     (then
                                      (i32.const 1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1584)
                                       )
                                      )
                                      (i64.eq
                                       (local.get $1)
                                       (i64.const 13)
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (if
                                    (i32.eqz
                                     (global.get $ready1587)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1587)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1576)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global139)
                                    )
                                   )
                                   (if (result i32)
                                    (if (result i32)
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function416
                                        (block (result (ref $type84))
                                         (local.set $scratch
                                          (call $function55
                                           (local.get $0)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1578)
                                          )
                                         )
                                         (local.get $scratch)
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (i32.const 1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1584)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 10)
                                       )
                                       (then
                                        (i32.const 1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1584)
                                         )
                                        )
                                        (i64.eq
                                         (local.get $1)
                                         (i64.const 13)
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if
                                      (i32.eqz
                                       (global.get $ready1587)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1587)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1576)
                                      )
                                     )
                                     (if (result i32)
                                      (if (result i32)
                                       (i64.lt_s
                                        (local.tee $1
                                         (call $function415
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                       (then
                                        (i32.const 1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1584)
                                         )
                                        )
                                        (if (result i32)
                                         (call $function418
                                          (local.get $1)
                                          (i32.const 10)
                                         )
                                         (then
                                          (i32.const 1)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1584)
                                           )
                                          )
                                          (call $function418
                                           (local.get $1)
                                           (i32.const 13)
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (if
                                        (i32.eqz
                                         (global.get $ready1587)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1587)
                                        )
                                       )
                                       (call $function419
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready1590)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1590)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1584)
         )
        )
        (return
         (if (result (ref $type276))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type281
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global1584)
            )
           )
           (if (result (ref $type276))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty279)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1584)
              )
             )
             (if (result (ref $type276))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type282
                (i32.const 5)
                (global.get $string33)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1584)
                )
               )
               (if (result (ref $type276))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type282
                  (i32.const 5)
                  (global.get $string32)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global1584)
                  )
                 )
                 (if (result (ref $type276))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global1593)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1596)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global141)
                    )
                   )
                   (local.set $2
                    (call $foreign8
                     (struct.get $type66 0
                      (struct.get $type68 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1578)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1584)
                    )
                   )
                   (struct.new $type282
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string31)
                     (global.get $string30)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type85)
                         (local.tee $7
                          (if (result (ref $type84))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty85)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type86
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type86 0
                           (ref.cast (ref $type86)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global139)
                        )
                       )
                       (local.set $2
                        (call $foreign7
                         (struct.get $type66 0
                          (struct.get $type68 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global137)
                        )
                       )
                       (drop
                        (if (result (ref $type84))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty85)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type86
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global1584)
                    )
                   )
                   (if (result (ref $type283))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready1598)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1598)
                      )
                     )
                     (return_call $function423
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global1584)
                      )
                     )
                     (if (result (ref $type283))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready1598)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1598)
                        )
                       )
                       (return_call $function423
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global1584)
                        )
                       )
                       (if (result (ref $type283))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready1661)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1661)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1576)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global139)
                          )
                         )
                         (local.set $2
                          (call $foreign7
                           (struct.get $type66 0
                            (struct.get $type68 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global137)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1578)
                          )
                         )
                         (return
                          (if (result (ref $type276))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type85)
                               (local.tee $7
                                (if (result (ref $type84))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty85)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type86
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type86 0
                                 (ref.cast (ref $type86)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type283
                             (i32.const 6)
                             (global.get $string44)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (if (result (ref $type276))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type281
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1584)
                               )
                              )
                              (if (result (ref $type276))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1664)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1571)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready1573)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1573)
                                 )
                                )
                                (local.set $12
                                 (call $function414
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready1715)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1715)
                                 )
                                )
                                (if (result (ref $type283))
                                 (i32.eq
                                  (struct.get $type223 0
                                   (local.tee $10
                                    (call $function456
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type225)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type283))
                                   (struct.get $type223 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type283
                                     (i32.const 6)
                                     (struct.get $type226 1
                                      (ref.cast (ref $type226)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type283
                                     (i32.const 6)
                                     (global.get $string45)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1584)
                                 )
                                )
                                (if (result (ref $type276))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1669)
                                   )
                                  )
                                  (if (result (ref $type283))
                                   (call $function442
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1573)
                                     )
                                    )
                                    (return_call $function414
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type283
                                     (i32.const 6)
                                     (global.get $string43)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1584)
                                   )
                                  )
                                  (if (result (ref $type276))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready1673)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1673)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1576)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global139)
                                     )
                                    )
                                    (local.set $2
                                     (call $foreign7
                                      (struct.get $type66 0
                                       (struct.get $type68 0
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global137)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1578)
                                     )
                                    )
                                    (if (result (ref $type276))
                                     (i64.lt_s
                                      (local.tee $1
                                       (if (result i64)
                                        (ref.test (ref $type85)
                                         (local.tee $7
                                          (if (result (ref $type84))
                                           (i32.eq
                                            (local.get $2)
                                            (i32.const -1)
                                           )
                                           (then
                                            (global.get $empty85)
                                           )
                                           (else
                                            (if
                                             (i64.gt_u
                                              (local.tee $1
                                               (i64.extend_i32_s
                                                (local.get $2)
                                               )
                                              )
                                              (i64.const 1114111)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (if
                                             (i32.and
                                              (i64.le_u
                                               (local.get $1)
                                               (i64.const 57343)
                                              )
                                              (i64.ge_u
                                               (local.get $1)
                                               (i64.const 55296)
                                              )
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (struct.new $type86
                                             (i32.wrap_i64
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const -1)
                                        )
                                        (else
                                         (i64.extend_i32_u
                                          (struct.get $type86 0
                                           (ref.cast (ref $type86)
                                            (local.get $7)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type283
                                       (i32.const 6)
                                       (global.get $string46)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1676)
                                       )
                                      )
                                      (if (result (ref $type277))
                                       (call $function444
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type277
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1678)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1606)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type268
                                          (struct.new $type269
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type228)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1645)
                                         )
                                        )
                                        (call $function437
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $4
                                         (call $function446
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 1)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready1683)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1683)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type276))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $4)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (array.get $type19
                                             (struct.get $type18 2
                                              (local.get $4)
                                             )
                                             (i32.const 0)
                                            )
                                           )
                                           (struct.new $type277
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global1686)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global86)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global61)
                                            )
                                           )
                                           (if
                                            (i64.gt_u
                                             (local.tee $1
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $4)
                                               )
                                              )
                                             )
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (call $string-copy
                                            (local.tee $5
                                             (call $string-new
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                            (i64.const 0)
                                            (local.get $4)
                                            (local.get $1)
                                           )
                                           (local.set $4
                                            (call $function449
                                             (local.get $5)
                                             (i32.const 1)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready1692)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global1692)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global101)
                                            )
                                           )
                                           (if (result (ref $type276))
                                            (struct.get $type294 0
                                             (local.tee $11
                                              (if (result (ref $type294))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string56)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type295
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global101)
                                                 )
                                                )
                                                (if (result (ref $type294))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $4)
                                                    (global.get $string55)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type295
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global101)
                                                   )
                                                  )
                                                  (if (result (ref $type294))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $4)
                                                      (global.get $string54)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type295
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global101)
                                                     )
                                                    )
                                                    (if (result (ref $type294))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $4)
                                                        (global.get $string53)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type295
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global101)
                                                       )
                                                      )
                                                      (if (result (ref $type294))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $4)
                                                          (global.get $string52)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type295
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global101)
                                                         )
                                                        )
                                                        (if (result (ref $type294))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $4)
                                                            (global.get $string51)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type295)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global101)
                                                           )
                                                          )
                                                          (if (result (ref $type294))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $4)
                                                              (global.get $string50)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type295
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global101)
                                                             )
                                                            )
                                                            (if (result (ref $type294))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $4)
                                                                (global.get $string49)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type295
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global101)
                                                               )
                                                              )
                                                              (if (result (ref $type294))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $4)
                                                                  (global.get $string48)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type295
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type294))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $4)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global1694)
                                                                   )
                                                                  )
                                                                  (call $function452
                                                                   (local.get $4)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type297
                                                                   (i32.const 2)
                                                                   (global.get $string47)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type283))
                                              (i32.eq
                                               (struct.get $type294 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type283
                                                (i32.const 6)
                                                (struct.get $type297 1
                                                 (ref.cast (ref $type297)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (drop
                                              (ref.cast (ref $type295)
                                               (local.get $11)
                                              )
                                             )
                                             (struct.new $type277
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1584)
                                     )
                                    )
                                    (if (result (ref $type276))
                                     (if (result i32)
                                      (i64.eq
                                       (local.get $1)
                                       (i64.const 117)
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1584)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready1702)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1702)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1593)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1596)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global141)
                                       )
                                      )
                                      (local.set $2
                                       (call $foreign8
                                        (struct.get $type66 0
                                         (struct.get $type68 0
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global137)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1578)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1584)
                                       )
                                      )
                                      (if (result (ref $type276))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type85)
                                            (local.tee $7
                                             (if (result (ref $type84))
                                              (i32.eq
                                               (local.get $2)
                                               (i32.const -1)
                                              )
                                              (then
                                               (global.get $empty85)
                                              )
                                              (else
                                               (if
                                                (i64.gt_u
                                                 (local.tee $1
                                                  (i64.extend_i32_s
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i64.const 1114111)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.and
                                                 (i64.le_u
                                                  (local.get $1)
                                                  (i64.const 57343)
                                                 )
                                                 (i64.ge_u
                                                  (local.get $1)
                                                  (i64.const 55296)
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.new $type86
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type86 0
                                              (ref.cast (ref $type86)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global139)
                                           )
                                          )
                                          (local.set $2
                                           (call $foreign7
                                            (struct.get $type66 0
                                             (struct.get $type68 0
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global137)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type84))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty85)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type86
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1593)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1596)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global141)
                                          )
                                         )
                                         (local.set $2
                                          (call $foreign8
                                           (struct.get $type66 0
                                            (struct.get $type68 0
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global137)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1578)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1584)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type85)
                                             (local.tee $7
                                              (if (result (ref $type84))
                                               (i32.eq
                                                (local.get $2)
                                                (i32.const -1)
                                               )
                                               (then
                                                (global.get $empty85)
                                               )
                                               (else
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (i64.extend_i32_s
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 1114111)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (if
                                                 (i32.and
                                                  (i64.le_u
                                                   (local.get $1)
                                                   (i64.const 57343)
                                                  )
                                                  (i64.ge_u
                                                   (local.get $1)
                                                   (i64.const 55296)
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (struct.new $type86
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type86 0
                                               (ref.cast (ref $type86)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global139)
                                            )
                                           )
                                           (local.set $2
                                            (call $foreign7
                                             (struct.get $type66 0
                                              (struct.get $type68 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global137)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type84))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty85)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type86
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type281
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type283
                                         (i32.const 6)
                                         (global.get $string58)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1584)
                                       )
                                      )
                                      (if (result (ref $type276))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type283
                                         (i32.const 6)
                                         (global.get $string42)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type276))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type283
                                           (i32.const 6)
                                           (global.get $string41)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1678)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1606)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type268
                                            (struct.new $type269
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type228)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1645)
                                           )
                                          )
                                          (call $function437
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $4
                                           (call $function446
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 1)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (local.set $5
                                           (call $function35
                                            (struct.new $type61
                                             (global.get $string40)
                                             (struct.new $type61
                                              (local.get $4)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready1704)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1704)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1686)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global86)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.tee $1
                                             (i64.extend_i32_u
                                              (struct.get $type18 1
                                               (local.get $5)
                                              )
                                             )
                                            )
                                            (i64.const 4294967294)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $string-copy
                                           (local.tee $6
                                            (call $string-new
                                             (i32.wrap_i64
                                              (local.get $1)
                                             )
                                            )
                                           )
                                           (i64.const 0)
                                           (local.get $5)
                                           (local.get $1)
                                          )
                                          (local.set $4
                                           (call $function449
                                            (local.get $6)
                                            (i32.const 1)
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global101)
                                           )
                                          )
                                          (if (result (ref $type276))
                                           (if (result i32)
                                            (if (result i32)
                                             (i64.eq
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $4)
                                               )
                                              )
                                              (i64.const 2)
                                             )
                                             (then
                                              (call $function40
                                               (local.get $4)
                                               (global.get $string63)
                                               (i32.const 0)
                                               (i32.const 1)
                                               (i64.const 0)
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                            (then
                                             (i32.const 1)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global101)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string62)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type277
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global101)
                                             )
                                            )
                                            (if (result (ref $type276))
                                             (if (result i32)
                                              (if (result i32)
                                               (i64.eq
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $4)
                                                 )
                                                )
                                                (i64.const 2)
                                               )
                                               (then
                                                (call $function40
                                                 (local.get $4)
                                                 (global.get $string61)
                                                 (i32.const 0)
                                                 (i32.const 1)
                                                 (i64.const 0)
                                                )
                                               )
                                               (else
                                                (i32.const 0)
                                               )
                                              )
                                              (then
                                               (i32.const 1)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global101)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string60)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type277
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1203)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1197)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1128)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign35
                                                (local.tee $2
                                                 (call $function310
                                                  (local.get $5)
                                                  (call $foreign18)
                                                  (i32.const 1)
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (local.get $5)
                                                   )
                                                  )
                                                  (i32.const 1)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (i32.const 10)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1194)
                                               )
                                              )
                                              (local.set $8
                                               (call $function325
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign21
                                               (local.get $2)
                                              )
                                              (if (result (ref $type276))
                                               (i32.eq
                                                (struct.get $type216 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type277
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type218 1
                                                   (ref.cast (ref $type218)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type283))
                                                 (i32.eq
                                                  (struct.get $type216 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type283
                                                   (i32.const 6)
                                                   (struct.get $type219 1
                                                    (ref.cast (ref $type219)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type283
                                                   (i32.const 6)
                                                   (global.get $string59)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global1584)
                          )
                         )
                         (if (result (ref $type283))
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 91)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 93)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1584)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 123)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1584)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type283
                            (i32.const 6)
                            (global.get $string29)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global1678)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1606)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type268
                             (struct.new $type269
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type228)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1645)
                            )
                           )
                           (call $function437
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $4
                            (call $function446
                             (local.get $0)
                             (local.get $9)
                             (i32.const 1)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1710)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1710)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global101)
                            )
                           )
                           (return
                            (if (result (ref $type276))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $4)
                                (global.get $string64)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty280)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1212)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global1128)
                               )
                              )
                              (if (result (ref $type276))
                               (i32.eq
                                (struct.get $type223 0
                                 (local.tee $10
                                  (if (result (ref $type223))
                                   (local.tee $3
                                    (call $foreign36
                                     (local.tee $2
                                      (call $function310
                                       (local.get $4)
                                       (call $foreign18)
                                       (i32.const 1)
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (local.get $4)
                                        )
                                       )
                                       (i32.const 1)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.const 0)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1205)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1194)
                                     )
                                    )
                                    (local.set $8
                                     (call $function325
                                      (local.get $2)
                                      (local.get $3)
                                     )
                                    )
                                    (call $foreign21
                                     (local.get $2)
                                    )
                                    (if (result (ref $type223))
                                     (i32.eq
                                      (struct.get $type216 0
                                       (local.get $8)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type225
                                       (i32.const 1)
                                       (struct.new $type23
                                        (i32.const 5)
                                        (struct.get $type218 1
                                         (ref.cast (ref $type218)
                                          (local.get $8)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (if (result (ref $type226))
                                       (i32.eq
                                        (struct.get $type216 0
                                         (local.get $8)
                                        )
                                        (i32.const 2)
                                       )
                                       (then
                                        (struct.new $type226
                                         (i32.const 2)
                                         (struct.get $type219 1
                                          (ref.cast (ref $type219)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (if (result (ref $type223))
                                     (i32.eq
                                      (call $foreign22
                                       (local.get $2)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (drop
                                       (call $foreign23
                                        (local.get $2)
                                       )
                                      )
                                      (struct.new $type225
                                       (i32.const 1)
                                       (struct.new $type21
                                        (i32.const 4)
                                       )
                                      )
                                     )
                                     (else
                                      (call $foreign21
                                       (local.get $2)
                                      )
                                      (struct.new $type226
                                       (i32.const 2)
                                       (global.get $string9)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type277
                                 (i32.const 0)
                                 (struct.get $type225 1
                                  (ref.cast (ref $type225)
                                   (local.get $10)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type283))
                                 (i32.eq
                                  (struct.get $type223 0
                                   (local.get $10)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type283
                                   (i32.const 6)
                                   (struct.get $type226 1
                                    (ref.cast (ref $type226)
                                     (local.get $10)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (unreachable)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready1573)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1573)
   )
  )
  (return_call $function414
   (local.get $0)
  )
 )
 (func $function415 (type $call263) (param $0 (ref $type68)) (result i64)
  (local $1 (ref $type84))
  (local $scratch (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (return_call $function416
   (block (result (ref $type84))
    (local.set $scratch
     (call $function55
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1578)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function416 (type $call262) (param $0 (ref $type84)) (result i64)
  (if (result i64)
   (ref.test (ref $type85)
    (local.get $0)
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type86 0
      (ref.cast (ref $type86)
       (local.get $0)
      )
     )
    )
   )
  )
 )
 (func $function418 (type $call264) (param $0 i64) (param $1 i32) (result i32)
  (i64.eq
   (i64.extend_i32_u
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $function419 (type $call76) (param $0 (ref $type68)) (result i32)
  (local $1 i64)
  (drop
   (ref.as_non_null
    (global.get $global1576)
   )
  )
  (if (result i32)
   (if (result i32)
    (i64.lt_s
     (local.tee $1
      (call $function415
       (local.get $0)
      )
     )
     (i64.const 0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1584)
      )
     )
     (if (result i32)
      (call $function418
       (local.get $1)
       (i32.const 10)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1584)
        )
       )
       (call $function418
        (local.get $1)
        (i32.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1587)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1587)
     )
    )
    (return_call $function419
     (local.get $0)
    )
   )
  )
 )
 (func $function423 (type $call286) (param $0 (ref $type68)) (param $1 i32) (param $2 i32) (result (ref $type276))
  (local $3 (ref $type18))
  (local $4 (ref $type288))
  (local $5 (ref $type268))
  (if
   (i32.eqz
    (global.get $ready1603)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1603)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1606)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $5
   (struct.new $type268
    (struct.new $type269
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type228)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1607)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1607)
   )
  )
  (if (result (ref $type276))
   (ref.test (ref $type289)
    (local.tee $4
     (call $function426
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type289 0
      (ref.cast (ref $type289)
       (local.get $4)
      )
     )
    )
    (struct.new $type277
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global1142)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1128)
        )
       )
       (drop
        (call $foreign23
         (call $function310
          (local.get $3)
          (call $foreign18)
          (i32.const 1)
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $3)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
       )
       (struct.new $type21
        (i32.const 4)
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
        (local.get $3)
       )
      )
     )
    )
   )
   (else
    (struct.new $type283
     (i32.const 6)
     (struct.get $type290 0
      (ref.cast (ref $type290)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function426 (type $call291) (param $0 (ref $type68)) (param $1 i32) (param $2 (ref $type268)) (result (ref $type288))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type84))
  (local $6 (ref $type294))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global1576)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (block $block
   (return
    (if (result (ref $type288))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type85)
         (local.tee $5
          (if (result (ref $type84))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty85)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type86
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type86 0
           (ref.cast (ref $type86)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type290
       (global.get $string34)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1584)
       )
      )
      (if (result (ref $type288))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1612)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (struct.new $type289
         (if (result (ref $type18))
          (i32.or
           (i64.lt_s
            (local.tee $3
             (struct.get $type228 0
              (struct.get $type268 1
               (local.get $2)
              )
             )
            )
            (i64.const 0)
           )
           (i64.lt_s
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.tee $7
               (struct.get $type269 0
                (struct.get $type268 0
                 (local.get $2)
                )
               )
              )
             )
            )
            (local.get $3)
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1584)
         )
        )
        (if (result (ref $type290))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready1614)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1614)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1576)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.set $4
           (call $foreign7
            (struct.get $type66 0
             (struct.get $type68 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global137)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1578)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1584)
           )
          )
          (local.set $6
           (if (result (ref $type294))
            (i64.eq
             (local.tee $3
              (if (result i64)
               (ref.test (ref $type85)
                (local.tee $5
                 (if (result (ref $type84))
                  (i32.eq
                   (local.get $4)
                   (i32.const -1)
                  )
                  (then
                   (global.get $empty85)
                  )
                  (else
                   (if
                    (i64.gt_u
                     (local.tee $3
                      (i64.extend_i32_s
                       (local.get $4)
                      )
                     )
                     (i64.const 1114111)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.and
                     (i64.le_u
                      (local.get $3)
                      (i64.const 57343)
                     )
                     (i64.ge_u
                      (local.get $3)
                      (i64.const 55296)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (struct.new $type86
                    (i32.wrap_i64
                     (local.get $3)
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const -1)
               )
               (else
                (i64.extend_i32_u
                 (struct.get $type86 0
                  (ref.cast (ref $type86)
                   (local.get $5)
                  )
                 )
                )
               )
              )
             )
             (i64.const 97)
            )
            (then
             (struct.new $type295
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1584)
              )
             )
             (if (result (ref $type294))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type295
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1584)
                )
               )
               (if (result (ref $type294))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type295
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global1584)
                  )
                 )
                 (if (result (ref $type294))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type295
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global1584)
                    )
                   )
                   (if (result (ref $type294))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type295
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global1584)
                      )
                     )
                     (if (result (ref $type294))
                      (if (result i32)
                       (i64.eq
                        (local.get $3)
                        (i64.const 34)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1584)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $3)
                          (i64.const 124)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1584)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type295
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global1584)
                        )
                       )
                       (if (result (ref $type294))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready1618)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1618)
                          )
                         )
                         (call $function429
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type294))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready1631)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global1631)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $3)
                              (i64.const 32)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1584)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $3)
                                (i64.const 9)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1584)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $3)
                                  (i64.const 10)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1584)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready1633)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1633)
                            )
                           )
                           (call $function434
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type297
                            (i32.const 2)
                            (global.get $string35)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1638)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1638)
           )
          )
          (if (result (ref $type290))
           (local.tee $4
            (struct.get $type294 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type290))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type290
               (struct.get $type297 1
                (ref.cast (ref $type297)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1645)
             )
            )
            (call $function437
             (local.get $2)
             (struct.get $type295 1
              (ref.cast (ref $type295)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready1655)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1655)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global1584)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global1593)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1596)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global141)
              )
             )
             (local.set $4
              (call $foreign8
               (struct.get $type66 0
                (struct.get $type68 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1578)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1584)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type85)
                 (local.tee $5
                  (if (result (ref $type84))
                   (i32.eq
                    (local.get $4)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty85)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.extend_i32_s
                        (local.get $4)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $3)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $3)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type86
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type86 0
                   (ref.cast (ref $type86)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global139)
                )
               )
               (local.set $4
                (call $foreign7
                 (struct.get $type66 0
                  (struct.get $type68 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global137)
                )
               )
               (drop
                (if (result (ref $type84))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty85)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type86
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1645)
           )
          )
          (call $function437
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready1607)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1607)
   )
  )
  (return_call $function426
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function429 (type $call301) (param $0 (ref $type68)) (param $1 i64) (param $2 i64) (result (ref $type294))
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global1576)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $5
   (call $foreign7
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1584)
   )
  )
  (if (result (ref $type294))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type85)
       (local.tee $6
        (if (result (ref $type84))
         (i32.eq
          (local.get $5)
          (i32.const -1)
         )
         (then
          (global.get $empty85)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $5)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type86
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type86 0
         (ref.cast (ref $type86)
          (local.get $6)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1623)
     )
    )
    (if (result (ref $type294))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1626)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (i32.or
            (i64.lt_s
             (local.get $1)
             (i64.const 55296)
            )
            (i64.gt_s
             (local.get $1)
             (i64.const 57343)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type295
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type297
       (i32.const 2)
       (global.get $string37)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1629)
     )
    )
    (if (result (ref $type297))
     (i32.or
      (i64.lt_s
       (local.tee $3
        (call $function432
         (local.get $3)
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 69631)
      )
     )
     (then
      (struct.new $type297
       (i32.const 2)
       (global.get $string36)
      )
     )
     (else
      (if
       (i64.ne
        (local.get $1)
        (i64.div_s
         (local.tee $4
          (i64.shl
           (local.get $1)
           (i64.const 4)
          )
         )
         (i64.const 16)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $1
           (i64.add
            (local.get $3)
            (local.get $4)
           )
          )
         )
         (i64.xor
          (local.get $1)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $2)
          (local.tee $3
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready1618)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1618)
       )
      )
      (return_call $function429
       (local.get $0)
       (local.get $1)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function432 (type $call112) (param $0 i64) (result i64)
  (local $1 i64)
  (if (result i64)
   (i32.and
    (i64.le_s
     (local.get $0)
     (i64.const 57)
    )
    (i64.ge_s
     (local.get $0)
     (i64.const 48)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $0)
          (i64.const 48)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 48)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if (result i64)
     (i32.and
      (i64.le_s
       (local.get $0)
       (i64.const 70)
      )
      (i64.ge_s
       (local.get $0)
       (i64.const 65)
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $0)
            (i64.const 55)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 55)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $1)
     )
     (else
      (if (result i64)
       (i32.and
        (i64.le_s
         (local.get $0)
         (i64.const 102)
        )
        (i64.ge_s
         (local.get $0)
         (i64.const 97)
        )
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $1
             (i64.sub
              (local.get $0)
              (i64.const 87)
             )
            )
            (local.get $0)
           )
           (i64.xor
            (local.get $0)
            (i64.const 87)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $1)
       )
       (else
        (i64.const -1)
       )
      )
     )
    )
   )
  )
 )
 (func $function434 (type $call299) (param $0 (ref $type68)) (param $1 i64) (result (ref $type294))
  (local $2 i32)
  (local $3 (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global1584)
   )
  )
  (if (result (ref $type294))
   (if (result i32)
    (i64.eq
     (local.get $1)
     (i64.const 32)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1584)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1576)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type66 0
       (struct.get $type68 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1578)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type85)
       (local.tee $3
        (if (result (ref $type84))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty85)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type86
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type86 0
         (ref.cast (ref $type86)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1633)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1633)
     )
    )
    (return_call $function434
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1584)
     )
    )
    (if (result (ref $type294))
     (if (result i32)
      (i64.eq
       (local.get $1)
       (i64.const 10)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1584)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1584)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1593)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global141)
         )
        )
        (local.set $2
         (call $foreign8
          (struct.get $type66 0
           (struct.get $type68 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1578)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1584)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type85)
            (local.tee $3
             (if (result (ref $type84))
              (i32.eq
               (local.get $2)
               (i32.const -1)
              )
              (then
               (global.get $empty85)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.extend_i32_s
                   (local.get $2)
                  )
                 )
                 (i64.const 1114111)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.and
                 (i64.le_u
                  (local.get $1)
                  (i64.const 57343)
                 )
                 (i64.ge_u
                  (local.get $1)
                  (i64.const 55296)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (struct.new $type86
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type86 0
              (ref.cast (ref $type86)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.set $2
           (call $foreign7
            (struct.get $type66 0
             (struct.get $type68 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global137)
           )
          )
          (drop
           (if (result (ref $type84))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty85)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type86
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1636)
       )
      )
      (drop
       (call $function435
        (local.get $0)
       )
      )
      (global.get $empty296)
     )
     (else
      (struct.new $type297
       (i32.const 2)
       (global.get $string38)
      )
     )
    )
   )
  )
 )
 (func $function435 (type $call76) (param $0 (ref $type68)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global1596)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $2
   (call $foreign8
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1584)
   )
  )
  (if (result i32)
   (if (result i32)
    (i64.eq
     (if (result i64)
      (ref.test (ref $type85)
       (local.tee $3
        (if (result (ref $type84))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty85)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type86
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type86 0
         (ref.cast (ref $type86)
          (local.get $3)
         )
        )
       )
      )
     )
     (i64.const 32)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1596)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global141)
      )
     )
     (local.set $2
      (call $foreign8
       (struct.get $type66 0
        (struct.get $type68 0
         (local.get $0)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1578)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1584)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type85)
        (local.tee $3
         (if (result (ref $type84))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty85)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type86
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type86 0
          (ref.cast (ref $type86)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type66 0
       (struct.get $type68 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (drop
     (if (result (ref $type84))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty85)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type86
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1636)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1636)
     )
    )
    (return_call $function435
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function437 (type $28) (param $0 (ref $type268)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type269))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type228 0
      (struct.get $type268 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type269 0
       (struct.get $type268 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready1649)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1649)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1136)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1128)
       )
      )
      (call $foreign20
       (call $function310
        (global.get $string39)
        (call $foreign18)
        (i32.const 1)
        (i64.const 35)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (if (result i64)
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
          (then
           (i64.const 4294967294)
          )
          (else
           (if
            (i64.ne
             (i64.div_s
              (local.tee $3
               (i64.shl
                (local.get $2)
                (i64.const 1)
               )
              )
              (i64.const 2)
             )
             (local.get $2)
            )
            (then
             (unreachable)
            )
           )
           (local.get $3)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type269 0
        (local.tee $7
         (struct.get $type268 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type269 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type269 0
       (struct.get $type268 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.tee $3
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $3)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type228 0
   (struct.get $type268 1
    (local.get $0)
   )
   (local.get $3)
  )
 )
 (func $function442 (type $call274) (param $0 (ref $type68)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type84))
  (drop
   (ref.as_non_null
    (global.get $global1576)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (block $block
   (return
    (if (result i32)
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type85)
         (local.tee $5
          (if (result (ref $type84))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty85)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type86
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type86 0
           (ref.cast (ref $type86)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1584)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 35)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1593)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1596)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global141)
          )
         )
         (local.set $4
          (call $foreign8
           (struct.get $type66 0
            (struct.get $type68 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1578)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1584)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type85)
             (local.tee $5
              (if (result (ref $type84))
               (i32.eq
                (local.get $4)
                (i32.const -1)
               )
               (then
                (global.get $empty85)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.extend_i32_s
                    (local.get $4)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $2)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $2)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.new $type86
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type86 0
               (ref.cast (ref $type86)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 124)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global139)
            )
           )
           (local.set $4
            (call $foreign7
             (struct.get $type66 0
              (struct.get $type68 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (drop
            (if (result (ref $type84))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty85)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type86
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.tee $1
             (i64.add
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (br $block)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1584)
         )
        )
        (br_if $block
         (i32.eqz
          (if (result i32)
           (i64.eq
            (local.get $3)
            (i64.const 124)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global1593)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1596)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global141)
             )
            )
            (local.set $4
             (call $foreign8
              (struct.get $type66 0
               (struct.get $type68 0
                (local.get $0)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1578)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1584)
             )
            )
            (if (result i32)
             (i64.eq
              (if (result i64)
               (ref.test (ref $type85)
                (local.tee $5
                 (if (result (ref $type84))
                  (i32.eq
                   (local.get $4)
                   (i32.const -1)
                  )
                  (then
                   (global.get $empty85)
                  )
                  (else
                   (if
                    (i64.gt_u
                     (local.tee $2
                      (i64.extend_i32_s
                       (local.get $4)
                      )
                     )
                     (i64.const 1114111)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.and
                     (i64.le_u
                      (local.get $2)
                      (i64.const 57343)
                     )
                     (i64.ge_u
                      (local.get $2)
                      (i64.const 55296)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (struct.new $type86
                    (i32.wrap_i64
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const -1)
               )
               (else
                (i64.extend_i32_u
                 (struct.get $type86 0
                  (ref.cast (ref $type86)
                   (local.get $5)
                  )
                 )
                )
               )
              )
              (i64.const 35)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global139)
               )
              )
              (local.set $4
               (call $foreign7
                (struct.get $type66 0
                 (struct.get $type68 0
                  (local.get $0)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global137)
               )
              )
              (drop
               (if (result (ref $type84))
                (i32.eq
                 (local.get $4)
                 (i32.const -1)
                )
                (then
                 (global.get $empty85)
                )
                (else
                 (if
                  (i64.gt_u
                   (local.tee $2
                    (i64.extend_i32_s
                     (local.get $4)
                    )
                   )
                   (i64.const 1114111)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.and
                   (i64.le_u
                    (local.get $2)
                    (i64.const 57343)
                   )
                   (i64.ge_u
                    (local.get $2)
                    (i64.const 55296)
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (struct.new $type86
                  (i32.wrap_i64
                   (local.get $2)
                  )
                 )
                )
               )
              )
              (i32.const 1)
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 1)
         )
         (then
          (i32.const 1)
         )
         (else
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1669)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1669)
           )
          )
          (return_call $function442
           (local.get $0)
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready1669)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1669)
   )
  )
  (return_call $function442
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function444 (type $call266) (param $0 i64) (result i32)
  (if (result i32)
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1582)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.ge_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $0)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $0)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (i32.eq
        (call $foreign37
         (i32.wrap_i64
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1584)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $0)
        (i64.const 40)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1584)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $0)
          (i64.const 41)
         )
         (then
          (i32.const 1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global1584)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $0)
            (i64.const 34)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1584)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $0)
              (i64.const 59)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1584)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $0)
                (i64.const 124)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1584)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $0)
                  (i64.const 39)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1584)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $0)
                    (i64.const 96)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1584)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $0)
                      (i64.const 44)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1584)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $0)
                        (i64.const 91)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1584)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $0)
                          (i64.const 93)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1584)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $0)
                            (i64.const 123)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1584)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function446 (type $25) (param $0 (ref $type68)) (param $1 (ref $type268)) (param $2 i32) (param $3 i32) (param $4 i32) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $type84))
  (local $8 (ref $type18))
  (local $9 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global1596)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $6
   (call $foreign8
    (struct.get $type66 0
     (struct.get $type68 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1578)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1676)
   )
  )
  (if (result (ref $type18))
   (call $function444
    (if (result i64)
     (ref.test (ref $type85)
      (local.tee $7
       (if (result (ref $type84))
        (i32.eq
         (local.get $6)
         (i32.const -1)
        )
        (then
         (global.get $empty85)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $5
            (i64.extend_i32_s
             (local.get $6)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $5)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $5)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type86
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type86 0
        (ref.cast (ref $type86)
         (local.get $7)
        )
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1612)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (if (result (ref $type18))
     (i32.or
      (i64.lt_s
       (local.tee $5
        (struct.get $type228 0
         (struct.get $type268 1
          (local.get $1)
         )
        )
       )
       (i64.const 0)
      )
      (i64.lt_s
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.tee $8
          (struct.get $type269 0
           (struct.get $type268 0
            (local.get $1)
           )
          )
         )
        )
       )
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $9
        (call $string-new
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
       (i64.const 0)
       (local.get $8)
       (local.get $5)
      )
      (local.get $9)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1576)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $6
     (call $foreign7
      (struct.get $type66 0
       (struct.get $type68 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1578)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (if (result i64)
        (ref.test (ref $type85)
         (local.tee $7
          (if (result (ref $type84))
           (i32.eq
            (local.get $6)
            (i32.const -1)
           )
           (then
            (global.get $empty85)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $5
               (i64.extend_i32_s
                (local.get $6)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $5)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $5)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type86
             (i32.wrap_i64
              (local.get $5)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type86 0
           (ref.cast (ref $type86)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1645)
     )
    )
    (call $function437
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function446
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function449 (type $24) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (if
   (i32.eqz
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $5
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $6
             (i32.wrap_i64
              (local.get $4)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $6)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $6)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $5)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (i64.add
          (local.get $5)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $5)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $5)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $6
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $6)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $6)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.tee $5
         (i64.add
          (local.get $4)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function449
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $5)
    )
   )
  )
 )
 (func $function452 (type $23) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type294))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result (ref $type294))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1623)
     )
    )
    (if (result (ref $type294))
     (if (result i32)
      (i64.gt_s
       (local.get $5)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1626)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (i32.or
            (i64.lt_s
             (local.get $4)
             (i64.const 55296)
            )
            (i64.gt_s
             (local.get $4)
             (i64.const 57343)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type295
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type297
       (i32.const 2)
       (global.get $string37)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1629)
     )
    )
    (if (result (ref $type297))
     (i32.or
      (i64.lt_s
       (local.tee $5
        (call $function432
         (i64.extend_i32_u
          (array.get $type19
           (if (result (ref $type19))
            (i32.lt_u
             (local.tee $7
              (i32.wrap_i64
               (local.get $3)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type18 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type20
               (struct.get $type18 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $7)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $7)
            (i32.const 8191)
           )
          )
         )
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $4)
       (i64.const 69631)
      )
     )
     (then
      (struct.new $type297
       (i32.const 2)
       (global.get $string57)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $6
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $6)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $4)
        (i64.div_s
         (local.tee $3
          (i64.shl
           (local.get $4)
           (i64.const 4)
          )
         )
         (i64.const 16)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (local.get $5)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function452
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function456 (type $call303) (param $0 (ref $type68)) (param $1 (ref $type276)) (result (ref $type223))
  (local $2 (ref $type223))
  (local $3 (ref $type18))
  (local $4 i32)
  (local $5 i64)
  (if (result (ref $type223))
   (local.tee $4
    (struct.get $type276 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type223))
     (i32.eq
      (local.get $4)
      (i32.const 1)
     )
     (then
      (global.get $empty224)
     )
     (else
      (if (result (ref $type223))
       (i32.eq
        (struct.get $type276 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (struct.new $type226
         (i32.const 2)
         (struct.get $type283 1
          (ref.cast (ref $type283)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type223))
         (i32.eq
          (struct.get $type276 0
           (local.get $1)
          )
          (i32.const 4)
         )
         (then
          (local.set $5
           (struct.get $type281 1
            (ref.cast (ref $type281)
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1722)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1722)
           )
          )
          (return_call $function457
           (local.get $0)
           (local.get $5)
           (ref.null none)
          )
         )
         (else
          (if (result (ref $type223))
           (i32.eq
            (struct.get $type276 0
             (local.get $1)
            )
            (i32.const 5)
           )
           (then
            (local.set $3
             (struct.get $type282 1
              (ref.cast (ref $type282)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready1782)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1782)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1571)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1573)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1573)
             )
            )
            (local.set $1
             (call $function414
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1715)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1715)
             )
            )
            (if (result (ref $type223))
             (i32.eq
              (struct.get $type223 0
               (local.tee $2
                (call $function456
                 (local.get $0)
                 (local.get $1)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type225)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1142)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1128)
               )
              )
              (drop
               (call $foreign23
                (call $function310
                 (local.get $3)
                 (call $foreign18)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $3)
                  )
                 )
                 (i32.const 1)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1224)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1219)
               )
              )
              (drop
               (call $function331)
              )
              (drop
               (ref.as_non_null
                (global.get $global1224)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1219)
               )
              )
              (struct.new $type225
               (i32.const 1)
               (call $function331)
              )
             )
             (else
              (if (result (ref $type226))
               (struct.get $type223 0
                (local.get $2)
               )
               (then
                (struct.new $type226
                 (i32.const 2)
                 (struct.get $type226 1
                  (ref.cast (ref $type226)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (struct.new $type226
                 (i32.const 2)
                 (global.get $string76)
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type226))
             (i32.eq
              (struct.get $type276 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type226
               (i32.const 2)
               (global.get $string66)
              )
             )
             (else
              (struct.new $type226
               (i32.const 2)
               (global.get $string65)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type225
     (i32.const 1)
     (struct.get $type277 1
      (ref.cast (ref $type277)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function457 (type $21) (param $0 (ref $type68)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type223))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type36))
  (local $6 (ref $type12))
  (local $7 (ref $type276))
  (local $8 (ref $type223))
  (local $9 (ref $type228))
  (local $10 (ref $type13))
  (local $11 i32)
  (local $12 i64)
  (local $scratch (ref $type36))
  (local $scratch_14 (ref null $type12))
  (local $scratch_15 (ref $type36))
  (drop
   (ref.as_non_null
    (global.get $global1573)
   )
  )
  (if (result (ref $type223))
   (i32.eq
    (struct.get $type276 0
     (local.tee $7
      (call $function414
       (local.get $0)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready1728)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1728)
     )
    )
    (if (result (ref $type225))
     (i64.eqz
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1731)
       )
      )
      (struct.new $type225
       (i32.const 1)
       (if (result (ref $type13))
        (ref.is_null
         (local.get $2)
        )
        (then
         (global.get $empty14)
        )
        (else
         (local.set $3
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1224)
          )
         )
         (drop
          (struct.get $type12 0
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1219)
          )
         )
         (local.set $5
          (call $function331)
         )
         (if
          (i32.eqz
           (global.get $ready1731)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1731)
          )
         )
         (if (result (ref $type13))
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $4
            (struct.get $type12 1
             (local.get $3)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1224)
            )
           )
           (drop
            (struct.get $type12 0
             (local.get $3)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1219)
            )
           )
           (local.set $5
            (call $function331)
           )
           (if
            (i32.eqz
             (global.get $ready1731)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1731)
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $4)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $3
              (struct.get $type12 1
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1224)
              )
             )
             (drop
              (struct.get $type12 0
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1219)
              )
             )
             (local.set $5
              (call $function331)
             )
             (if
              (i32.eqz
               (global.get $ready1731)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1731)
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $4
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1224)
                )
               )
               (drop
                (struct.get $type12 0
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1219)
                )
               )
               (local.set $5
                (call $function331)
               )
               (if
                (i32.eqz
                 (global.get $ready1731)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1731)
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $3
                  (struct.get $type12 1
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1224)
                  )
                 )
                 (drop
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1219)
                  )
                 )
                 (local.set $5
                  (call $function331)
                 )
                 (if
                  (i32.eqz
                   (global.get $ready1731)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1731)
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1224)
                    )
                   )
                   (drop
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1219)
                    )
                   )
                   (local.set $5
                    (call $function331)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready1731)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1731)
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1224)
                      )
                     )
                     (drop
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1219)
                      )
                     )
                     (local.set $5
                      (call $function331)
                     )
                     (if
                      (i32.eqz
                       (global.get $ready1731)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1731)
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1224)
                        )
                       )
                       (drop
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1219)
                        )
                       )
                       (local.set $5
                        (call $function331)
                       )
                       (if
                        (i32.eqz
                         (global.get $ready1731)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1731)
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1224)
                          )
                         )
                         (drop
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1219)
                          )
                         )
                         (local.set $5
                          (call $function331)
                         )
                         (if
                          (i32.eqz
                           (global.get $ready1731)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1731)
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $4
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1224)
                            )
                           )
                           (drop
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1219)
                            )
                           )
                           (local.set $5
                            (call $function331)
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1731)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1731)
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $3
                              (struct.get $type12 1
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1224)
                              )
                             )
                             (drop
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1219)
                              )
                             )
                             (local.set $5
                              (call $function331)
                             )
                             (if
                              (i32.eqz
                               (global.get $ready1731)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1731)
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $4
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1224)
                                )
                               )
                               (drop
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1219)
                                )
                               )
                               (local.set $5
                                (call $function331)
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready1731)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1731)
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1224)
                                  )
                                 )
                                 (drop
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1219)
                                  )
                                 )
                                 (local.set $5
                                  (call $function331)
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready1731)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1731)
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (call $function459
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                    (block (result (ref $type36))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1224)
                                      )
                                     )
                                     (drop
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1219)
                                      )
                                     )
                                     (local.set $scratch
                                      (call $function331)
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready1731)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1731)
                                      )
                                     )
                                     (local.get $scratch)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type225))
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1734)
         )
        )
        (drop
         (call $function375
          (block (result (ref null $type12))
           (local.set $scratch_14
            (if (result (ref null $type12))
             (ref.is_null
              (local.get $2)
             )
             (then
              (ref.null none)
             )
             (else
              (local.set $6
               (struct.new $type12
                (struct.get $type12 0
                 (local.get $2)
                )
                (ref.null none)
               )
              )
              (if (result (ref null $type12))
               (ref.is_null
                (local.tee $3
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
               )
               (then
                (local.get $6)
               )
               (else
                (local.set $6
                 (struct.new $type12
                  (struct.get $type12 0
                   (local.get $3)
                  )
                  (local.get $6)
                 )
                )
                (if (result (ref null $type12))
                 (ref.is_null
                  (local.tee $3
                   (struct.get $type12 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (local.set $6
                   (struct.new $type12
                    (struct.get $type12 0
                     (local.get $3)
                    )
                    (local.get $6)
                   )
                  )
                  (if (result (ref null $type12))
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type12 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (local.get $6)
                   )
                   (else
                    (local.set $6
                     (struct.new $type12
                      (struct.get $type12 0
                       (local.get $3)
                      )
                      (local.get $6)
                     )
                    )
                    (if (result (ref null $type12))
                     (ref.is_null
                      (local.tee $3
                       (struct.get $type12 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (local.set $6
                       (struct.new $type12
                        (struct.get $type12 0
                         (local.get $3)
                        )
                        (local.get $6)
                       )
                      )
                      (if (result (ref null $type12))
                       (ref.is_null
                        (local.tee $3
                         (struct.get $type12 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (local.get $6)
                       )
                       (else
                        (local.set $6
                         (struct.new $type12
                          (struct.get $type12 0
                           (local.get $3)
                          )
                          (local.get $6)
                         )
                        )
                        (if (result (ref null $type12))
                         (ref.is_null
                          (local.tee $3
                           (struct.get $type12 1
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (local.set $6
                           (struct.new $type12
                            (struct.get $type12 0
                             (local.get $3)
                            )
                            (local.get $6)
                           )
                          )
                          (if (result (ref null $type12))
                           (ref.is_null
                            (local.tee $3
                             (struct.get $type12 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (local.get $6)
                           )
                           (else
                            (local.set $6
                             (struct.new $type12
                              (struct.get $type12 0
                               (local.get $3)
                              )
                              (local.get $6)
                             )
                            )
                            (if (result (ref null $type12))
                             (ref.is_null
                              (local.tee $3
                               (struct.get $type12 1
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.get $6)
                             )
                             (else
                              (local.set $6
                               (struct.new $type12
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                                (local.get $6)
                               )
                              )
                              (if (result (ref null $type12))
                               (ref.is_null
                                (local.tee $3
                                 (struct.get $type12 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (local.get $6)
                               )
                               (else
                                (local.set $6
                                 (struct.new $type12
                                  (struct.get $type12 0
                                   (local.get $3)
                                  )
                                  (local.get $6)
                                 )
                                )
                                (if (result (ref null $type12))
                                 (ref.is_null
                                  (local.tee $3
                                   (struct.get $type12 1
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $6)
                                 )
                                 (else
                                  (local.set $6
                                   (struct.new $type12
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                    (local.get $6)
                                   )
                                  )
                                  (if (result (ref null $type12))
                                   (ref.is_null
                                    (local.tee $3
                                     (struct.get $type12 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $6)
                                   )
                                   (else
                                    (local.set $6
                                     (struct.new $type12
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                      (local.get $6)
                                     )
                                    )
                                    (if (result (ref null $type12))
                                     (ref.is_null
                                      (local.tee $3
                                       (struct.get $type12 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $6)
                                     )
                                     (else
                                      (local.set $6
                                       (struct.new $type12
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                        (local.get $6)
                                       )
                                      )
                                      (if (result (ref null $type12))
                                       (ref.is_null
                                        (local.tee $3
                                         (struct.get $type12 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $6)
                                       )
                                       (else
                                        (call $function461
                                         (i32.const 0)
                                         (i32.const 1)
                                         (struct.get $type12 1
                                          (local.get $3)
                                         )
                                         (struct.new $type12
                                          (struct.get $type12 0
                                           (local.get $3)
                                          )
                                          (local.get $6)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1418)
            )
           )
           (local.get $scratch_14)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1222)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1217)
         )
        )
        (if
         (i64.eq
          (local.tee $1
           (struct.get $type228 0
            (global.get $global1216)
           )
          )
          (i64.const 9223372036854775807)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global1136)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1128)
           )
          )
          (call $foreign20
           (call $function310
            (global.get $string10)
            (call $foreign18)
            (i32.const 1)
            (i64.const 40)
            (i32.const 1)
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
          (unreachable)
         )
         (else
          (struct.set $type228 0
           (ref.as_non_null
            (global.get $global1216)
           )
           (block (result i64)
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.get $1)
                (local.tee $12
                 (i64.add
                  (local.get $1)
                  (i64.const 1)
                 )
                )
               )
               (i64.xor
                (local.get $12)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (local.get $12)
           )
          )
         )
        )
        (struct.new $type225
         (i32.const 1)
         (struct.new $type38
          (i32.const 7)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready1739)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1739)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 9)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 10)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 11)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 12)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 13)
                                    )
                                    (else
                                     (call $function463
                                      (i32.const 0)
                                      (i32.const 1)
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                      (i64.const 14)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global187)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready1745)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1745)
         )
        )
        (return_call $function464
         (local.get $2)
         (struct.new $type41
          (array.new_default $type42
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type223))
     (i32.eq
      (struct.get $type276 0
       (local.get $7)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type226
       (i32.const 2)
       (global.get $string68)
      )
     )
     (else
      (if (result (ref $type223))
       (i32.eq
        (struct.get $type276 0
         (local.get $7)
        )
        (i32.const 3)
       )
       (then
        (if (result (ref $type223))
         (i32.and
          (i32.eqz
           (ref.is_null
            (local.get $2)
           )
          )
          (i64.eqz
           (local.get $1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready1758)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1758)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1571)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1573)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1573)
           )
          )
          (local.set $7
           (call $function414
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1715)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1715)
           )
          )
          (if (result (ref $type223))
           (i32.eq
            (struct.get $type223 0
             (local.tee $8
              (call $function456
               (local.get $0)
               (local.get $7)
              )
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $10
             (struct.get $type225 1
              (ref.cast (ref $type225)
               (local.get $8)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1573)
             )
            )
            (if (result (ref $type223))
             (i32.eq
              (struct.get $type276 0
               (local.tee $7
                (call $function414
                 (local.get $0)
                )
               )
              )
              (i32.const 2)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready1731)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1731)
               )
              )
              (struct.new $type225
               (i32.const 1)
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $10)
                )
                (else
                 (local.set $3
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1224)
                  )
                 )
                 (drop
                  (struct.get $type12 0
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1219)
                  )
                 )
                 (local.set $5
                  (call $function331)
                 )
                 (if
                  (i32.eqz
                   (global.get $ready1731)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1731)
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1224)
                    )
                   )
                   (drop
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1219)
                    )
                   )
                   (local.set $5
                    (call $function331)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready1731)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1731)
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1224)
                      )
                     )
                     (drop
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1219)
                      )
                     )
                     (local.set $5
                      (call $function331)
                     )
                     (if
                      (i32.eqz
                       (global.get $ready1731)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1731)
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1224)
                        )
                       )
                       (drop
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1219)
                        )
                       )
                       (local.set $5
                        (call $function331)
                       )
                       (if
                        (i32.eqz
                         (global.get $ready1731)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1731)
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1224)
                          )
                         )
                         (drop
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1219)
                          )
                         )
                         (local.set $5
                          (call $function331)
                         )
                         (if
                          (i32.eqz
                           (global.get $ready1731)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1731)
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $4
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1224)
                            )
                           )
                           (drop
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1219)
                            )
                           )
                           (local.set $5
                            (call $function331)
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1731)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1731)
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $3
                              (struct.get $type12 1
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1224)
                              )
                             )
                             (drop
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1219)
                              )
                             )
                             (local.set $5
                              (call $function331)
                             )
                             (if
                              (i32.eqz
                               (global.get $ready1731)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1731)
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $4
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1224)
                                )
                               )
                               (drop
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1219)
                                )
                               )
                               (local.set $5
                                (call $function331)
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready1731)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1731)
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1224)
                                  )
                                 )
                                 (drop
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1219)
                                  )
                                 )
                                 (local.set $5
                                  (call $function331)
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready1731)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1731)
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (local.set $4
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1224)
                                    )
                                   )
                                   (drop
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1219)
                                    )
                                   )
                                   (local.set $5
                                    (call $function331)
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready1731)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1731)
                                    )
                                   )
                                   (if (result (ref $type13))
                                    (ref.is_null
                                     (local.get $4)
                                    )
                                    (then
                                     (local.get $5)
                                    )
                                    (else
                                     (local.set $3
                                      (struct.get $type12 1
                                       (local.get $4)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1224)
                                      )
                                     )
                                     (drop
                                      (struct.get $type12 0
                                       (local.get $4)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1219)
                                      )
                                     )
                                     (local.set $5
                                      (call $function331)
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready1731)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1731)
                                      )
                                     )
                                     (if (result (ref $type13))
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (local.get $5)
                                      )
                                      (else
                                       (local.set $4
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1224)
                                        )
                                       )
                                       (drop
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1219)
                                        )
                                       )
                                       (local.set $5
                                        (call $function331)
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready1731)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1731)
                                        )
                                       )
                                       (if (result (ref $type13))
                                        (ref.is_null
                                         (local.get $4)
                                        )
                                        (then
                                         (local.get $5)
                                        )
                                        (else
                                         (local.set $3
                                          (struct.get $type12 1
                                           (local.get $4)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1224)
                                          )
                                         )
                                         (drop
                                          (struct.get $type12 0
                                           (local.get $4)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1219)
                                          )
                                         )
                                         (local.set $5
                                          (call $function331)
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready1731)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1731)
                                          )
                                         )
                                         (if (result (ref $type13))
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (local.get $5)
                                          )
                                          (else
                                           (call $function459
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                            (block (result (ref $type36))
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1224)
                                              )
                                             )
                                             (drop
                                              (struct.get $type12 0
                                               (local.get $3)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1219)
                                              )
                                             )
                                             (local.set $scratch_15
                                              (call $function331)
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready1731)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1731)
                                              )
                                             )
                                             (local.get $scratch_15)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type226))
               (i32.eq
                (struct.get $type276 0
                 (local.get $7)
                )
                (i32.const 6)
               )
               (then
                (struct.new $type226
                 (i32.const 2)
                 (struct.get $type283 1
                  (ref.cast (ref $type283)
                   (local.get $7)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type226))
                 (local.tee $11
                  (struct.get $type276 0
                   (local.get $7)
                  )
                 )
                 (then
                  (if (result (ref $type226))
                   (i32.eq
                    (local.get $11)
                    (i32.const 1)
                   )
                   (then
                    (struct.new $type226
                     (i32.const 2)
                     (global.get $string74)
                    )
                   )
                   (else
                    (if (result (ref $type226))
                     (i32.eq
                      (struct.get $type276 0
                       (local.get $7)
                      )
                      (i32.const 3)
                     )
                     (then
                      (struct.new $type226
                       (i32.const 2)
                       (global.get $string73)
                      )
                     )
                     (else
                      (if (result (ref $type226))
                       (i32.eq
                        (struct.get $type276 0
                         (local.get $7)
                        )
                        (i32.const 4)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type281)
                          (local.get $7)
                         )
                        )
                        (struct.new $type226
                         (i32.const 2)
                         (global.get $string72)
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type282)
                          (local.get $7)
                         )
                        )
                        (struct.new $type226
                         (i32.const 2)
                         (global.get $string71)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type277)
                    (local.get $7)
                   )
                  )
                  (struct.new $type226
                   (i32.const 2)
                   (global.get $string75)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type226))
             (struct.get $type223 0
              (local.get $8)
             )
             (then
              (struct.new $type226
               (i32.const 2)
               (struct.get $type226 1
                (ref.cast (ref $type226)
                 (local.get $8)
                )
               )
              )
             )
             (else
              (struct.new $type226
               (i32.const 2)
               (global.get $string70)
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type226
           (i32.const 2)
           (global.get $string67)
          )
         )
        )
       )
       (else
        (if (result (ref $type226))
         (i32.eq
          (struct.get $type276 0
           (local.get $7)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type226
           (i32.const 2)
           (struct.get $type283 1
            (ref.cast (ref $type283)
             (local.get $7)
            )
           )
          )
         )
         (else
          (if (result (ref $type226))
           (local.tee $11
            (struct.get $type276 0
             (local.get $7)
            )
           )
           (then
            (if
             (i32.eq
              (local.get $11)
              (i32.const 4)
             )
             (then
              (drop
               (ref.cast (ref $type281)
                (local.get $7)
               )
              )
             )
             (else
              (drop
               (ref.cast (ref $type282)
                (local.get $7)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1715)
             )
            )
            (local.set $8
             (call $function456
              (local.get $0)
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1772)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1772)
             )
            )
            (if (result (ref $type226))
             (i32.eq
              (struct.get $type223 0
               (local.get $8)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global1722)
               )
              )
              (return_call $function457
               (local.get $0)
               (local.get $1)
               (struct.new $type12
                (struct.get $type225 1
                 (ref.cast (ref $type225)
                  (local.get $8)
                 )
                )
                (local.get $2)
               )
              )
             )
             (else
              (if (result (ref $type226))
               (i32.eq
                (struct.get $type223 0
                 (local.get $8)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type226
                 (i32.const 2)
                 (struct.get $type226 1
                  (ref.cast (ref $type226)
                   (local.get $8)
                  )
                 )
                )
               )
               (else
                (unreachable)
               )
              )
             )
            )
           )
           (else
            (local.set $6
             (struct.new $type12
              (struct.get $type277 1
               (ref.cast (ref $type277)
                (local.get $7)
               )
              )
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1722)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1722)
             )
            )
            (return_call $function457
             (local.get $0)
             (local.get $1)
             (local.get $6)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function459 (type $call308) (param $0 (ref null $type12)) (param $1 (ref $type36)) (result (ref $type13))
  (local $2 (ref null $type12))
  (local $scratch (ref $type36))
  (if (result (ref $type36))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function459
     (struct.get $type12 1
      (local.get $0)
     )
     (block (result (ref $type36))
      (drop
       (ref.as_non_null
        (global.get $global1224)
       )
      )
      (drop
       (struct.get $type12 0
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1219)
       )
      )
      (local.set $scratch
       (call $function331)
      )
      (if
       (i32.eqz
        (global.get $ready1731)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1731)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function461 (type $17) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function461
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function463 (type $52) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function463
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function464 (type $call312) (param $0 (ref null $type12)) (param $1 (ref $type41)) (param $2 i64) (result (ref $type223))
  (local $3 (ref $type24))
  (local $4 (ref $type13))
  (local $5 i64)
  (local $6 i64)
  (if (result (ref $type223))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type225
     (i32.const 1)
     (struct.new $type40
      (i32.const 8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1750)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1251)
     )
    )
    (if (result (ref $type226))
     (if (result i32)
      (i64.lt_s
       (local.tee $5
        (if (result i64)
         (call $function339
          (local.tee $4
           (struct.get $type12 0
            (local.get $0)
           )
          )
         )
         (then
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $4)
            )
            (i32.const 5)
           )
           (then
            (unreachable)
           )
          )
          (if (result i64)
           (struct.get $type24 0
            (local.tee $3
             (struct.get $type23 1
              (ref.cast (ref $type23)
               (local.get $4)
              )
             )
            )
           )
           (then
            (if
             (i32.eq
              (struct.get $type24 0
               (local.get $3)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type26)
                (local.get $3)
               )
              )
             )
             (else
              (if
               (i32.eq
                (struct.get $type24 0
                 (local.get $3)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type30)
                  (local.get $3)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type31)
                  (local.get $3)
                 )
                )
               )
              )
             )
            )
            (i64.const -1)
           )
           (else
            (struct.get $type25 1
             (ref.cast (ref $type25)
              (local.get $3)
             )
            )
           )
          )
         )
         (else
          (i64.const -1)
         )
        )
       )
       (i64.const 0)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $5)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type226
       (i32.const 2)
       (global.get $string69)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type42
       (struct.get $type41 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (return_call $function464
       (struct.get $type12 1
        (local.get $0)
       )
       (block (result (ref $type41))
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready1745)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1745)
         )
        )
        (local.get $1)
       )
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function472 (type $call261) (param $0 (ref $type68)) (result (ref $type223))
  (local $1 (ref $type223))
  (local $2 (ref $type18))
  (local $3 (ref $type276))
  (drop
   (ref.as_non_null
    (global.get $global1571)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1573)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1573)
   )
  )
  (local.set $3
   (call $function414
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1715)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1715)
   )
  )
  (if (result (ref $type223))
   (i32.eq
    (struct.get $type223 0
     (local.tee $1
      (call $function456
       (local.get $0)
       (local.get $3)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (local.set $2
     (call $function35
      (struct.new $type61
       (global.get $string27)
       (struct.new $type61
        (struct.get $type226 1
         (ref.cast (ref $type226)
          (local.get $1)
         )
        )
        (ref.null none)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1136)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1128)
     )
    )
    (call $foreign20
     (call $function310
      (local.get $2)
      (call $foreign18)
      (i32.const 1)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (unreachable)
   )
   (else
    (if
     (i32.eq
      (struct.get $type223 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type225)
        (local.get $1)
       )
      )
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function474 (type $call315) (param $0 (ref $type13)) (result f64)
  (local $1 (ref $type24))
  (local $2 (ref $type32))
  (local $3 (ref $type27))
  (local $4 i32)
  (drop
   (ref.as_non_null
    (global.get $global1251)
   )
  )
  (if (result f64)
   (call $function339
    (local.get $0)
   )
   (then
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global911)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global905)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global859)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global889)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global853)
     )
    )
    (if (result f64)
     (local.tee $4
      (struct.get $type32 0
       (local.tee $2
        (if (result (ref $type32))
         (if (result i32)
          (local.tee $4
           (struct.get $type32 0
            (local.tee $2
             (if (result (ref $type32))
              (local.tee $4
               (struct.get $type24 0
                (local.tee $1
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $0)
                  )
                 )
                )
               )
              )
              (then
               (if (result (ref $type32))
                (i32.eq
                 (local.get $4)
                 (i32.const 1)
                )
                (then
                 (drop
                  (ref.cast (ref $type26)
                   (local.get $1)
                  )
                 )
                 (struct.new_default $type33)
                )
                (else
                 (if (result (ref $type32))
                  (i32.eq
                   (struct.get $type24 0
                    (local.get $1)
                   )
                   (i32.const 2)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type30)
                     (local.get $1)
                    )
                   )
                   (struct.new_default $type33)
                  )
                  (else
                   (struct.get $type31 2
                    (ref.cast (ref $type31)
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type25)
                 (local.get $1)
                )
               )
               (struct.new_default $type33)
              )
             )
            )
           )
          )
          (then
           (if (result i32)
            (i32.eq
             (local.get $4)
             (i32.const 1)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global780)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global345)
              )
             )
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type28 1
                 (struct.get $type27 0
                  (struct.get $type34 1
                   (ref.cast (ref $type34)
                    (local.get $2)
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (f64.eq
              (struct.get $type35 1
               (ref.cast (ref $type35)
                (local.get $2)
               )
              )
              (f64.const 0.0)
             )
            )
           )
          )
          (else
           (i64.eqz
            (struct.get $type33 1
             (ref.cast (ref $type33)
              (local.get $2)
             )
            )
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global881)
           )
          )
          (if (result (ref $type32))
           (local.tee $4
            (struct.get $type24 0
             (local.get $1)
            )
           )
           (then
            (if (result (ref $type32))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (struct.new $type34
               (i32.const 1)
               (struct.get $type26 1
                (ref.cast (ref $type26)
                 (local.get $1)
                )
               )
              )
             )
             (else
              (if (result (ref $type32))
               (i32.eq
                (struct.get $type24 0
                 (local.get $1)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type35
                 (i32.const 2)
                 (struct.get $type30 1
                  (ref.cast (ref $type30)
                   (local.get $1)
                  )
                 )
                )
               )
               (else
                (struct.get $type31 1
                 (ref.cast (ref $type31)
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
           (else
            (struct.new $type33
             (i32.const 0)
             (struct.get $type25 1
              (ref.cast (ref $type25)
               (local.get $1)
              )
             )
            )
           )
          )
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
     (then
      (if (result f64)
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global827)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global734)
         )
        )
        (return_call $function211
         (struct.get $type27 0
          (local.tee $3
           (struct.get $type34 1
            (ref.cast (ref $type34)
             (local.get $2)
            )
           )
          )
         )
         (struct.get $type27 1
          (local.get $3)
         )
        )
       )
       (else
        (struct.get $type35 1
         (ref.cast (ref $type35)
          (local.get $2)
         )
        )
       )
      )
     )
     (else
      (f64.convert_i64_s
       (struct.get $type33 1
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1136)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1128)
     )
    )
    (call $foreign20
     (call $function310
      (global.get $string77)
      (call $foreign18)
      (i32.const 1)
      (i64.const 28)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function476 (type $call316) (param $0 (ref $type68)) (param $1 f64) (result f64)
  (local $2 (ref $type223))
  (local $3 (ref $type13))
  (local $4 f64)
  (local $5 f64)
  (local $6 i32)
  (local $scratch (ref $type13))
  (drop
   (ref.as_non_null
    (global.get $global1793)
   )
  )
  (local.set $2
   (call $function472
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1561)
   )
  )
  (if (result f64)
   (if (result i32)
    (local.tee $6
     (struct.get $type223 0
      (local.get $2)
     )
    )
    (then
     (if
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type225)
         (local.get $2)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type226)
         (local.get $2)
        )
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1566)
     )
    )
    (local.set $4
     (f64.add
      (local.tee $5
       (call $function474
        (block (result (ref $type13))
         (local.set $scratch
          (call $function412
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1799)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready1809)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1809)
     )
    )
    (return_call $function476
     (local.get $0)
     (local.get $4)
    )
   )
  )
 )
 (func $function491 (type $call325) (param $0 (ref $environment491)) (param $1 i64) (param $2 (ref $type13)) (result i64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 i32)
  (local $7 i64)
  (local $8 (ref $type18))
  (local $9 (ref $type68))
  (local $10 (ref $type66))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment491 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $7
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1836)
     )
    )
    (local.set $8
     (ref.as_non_null
      (global.get $global1833)
     )
    )
    (if
     (i32.eqz
      (call $foreign38)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1815)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1817)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1813)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $8)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $8)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $9
     (struct.new $type68
      (struct.new $type66
       (call $foreign5)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1809)
     )
    )
    (local.set $3
     (call $function476
      (local.get $9)
      (f64.const 0.0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $6
         (struct.get $type66 0
          (local.tee $10
           (struct.get $type68 0
            (local.get $9)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $6)
          (i32.const -3)
         )
         (i32.eq
          (local.get $6)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type66 0
       (local.get $10)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type327 0
       (struct.get $environment491 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function491
     (struct.get $type325 0
      (struct.get $type327 1
       (struct.get $environment491 1
        (local.get $0)
       )
      )
     )
     (local.get $7)
     (struct.new $type23
      (i32.const 5)
      (struct.new $type30
       (i32.const 2)
       (local.get $3)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1799)
     )
    )
    (local.set $3
     (f64.sub
      (local.tee $4
       (call $function474
        (local.get $2)
       )
      )
      (block (result f64)
       (drop
        (ref.as_non_null
         (global.get $global1799)
        )
       )
       (local.tee $5
        (call $function474
         (ref.as_non_null
          (global.get $global1834)
         )
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1791)
     )
    )
    (if
     (f64.lt
      (local.get $3)
      (f64.const 0.0)
     )
     (then
      (if
       (i32.and
        (f64.lt
         (f64.abs
          (local.get $3)
         )
         (f64.const inf)
        )
        (f64.eq
         (f64.abs
          (local.tee $3
           (f64.sub
            (f64.const 0.0)
            (local.get $3)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (i64.extend_i32_u
     (f64.le
      (local.get $3)
      (f64.const 1e-09)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type327))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1839)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1839)
   )
  )
  (struct.set $type327 1
   (local.tee $1
    (struct.new_default $type327)
   )
   (struct.new $type325
    (struct.new $environment491
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type327 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type327 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function491
   (struct.get $type325 0
    (struct.get $type327 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (struct.new $type15
    (i32.const 1)
   )
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1835)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1835)
   )
  )
  (struct.get $type82 0
   (global.get $global1827)
  )
 )
 (func $main
  (local $0 (ref $type223))
  (local $1 (ref $type24))
  (local $2 (ref null $type68))
  (local $3 (ref $type13))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type82))
  (local $7 (ref $type66))
  (local $8 i32)
  (local $9 i64)
  (local $scratch (ref $type223))
  (local $scratch_11 (ref $type82))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global1418
   (struct.new_default $type46)
  )
  (global.set $global1421
   (struct.new_default $type50)
  )
  (global.set $ready1421
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type54)
  )
  (global.set $global81
   (struct.new_default $type58)
  )
  (global.set $global86
   (struct.new_default $type59)
  )
  (global.set $global88
   (struct.new_default $type60)
  )
  (global.set $global91
   (struct.new_default $type62)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type63)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type64)
  )
  (drop
   (call $foreign40)
  )
  (drop
   (call $foreign39)
  )
  (global.set $global113
   (struct.new_default $type71)
  )
  (global.set $global124
   (struct.new_default $type74)
  )
  (global.set $global131
   (struct.new_default $type76)
  )
  (global.set $global128
   (struct.new_default $type77)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global1817
   (struct.new_default $type78)
  )
  (global.set $global1828
   (struct.new_default $type80)
  )
  (global.set $ready1828
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type87)
  )
  (global.set $global139
   (struct.new_default $type88)
  )
  (global.set $global141
   (struct.new_default $type88)
  )
  (global.set $global187
   (struct.new_default $type101)
  )
  (global.set $global323
   (struct.new $type28
    (i32.const 0)
    (array.new_fixed $type29 0)
   )
  )
  (global.set $global324
   (struct.new_default $type126)
  )
  (global.set $global327
   (struct.new_default $type127)
  )
  (global.set $global331
   (struct.new_default $type128)
  )
  (global.set $global333
   (struct.new_default $type129)
  )
  (global.set $global337
   (struct.new_default $type52)
  )
  (global.set $global341
   (struct.new_default $type130)
  )
  (global.set $global345
   (struct.new_default $type131)
  )
  (global.set $global347
   (struct.new_default $type132)
  )
  (global.set $global349
   (struct.new_default $type132)
  )
  (global.set $global351
   (struct.new_default $type112)
  )
  (global.set $global356
   (struct.new_default $type133)
  )
  (global.set $global364
   (struct.new_default $type134)
  )
  (global.set $global373
   (struct.new_default $type135)
  )
  (global.set $global386
   (struct.new_default $type136)
  )
  (global.set $global390
   (struct.new_default $type137)
  )
  (global.set $global393
   (struct.new_default $type137)
  )
  (global.set $global396
   (struct.new_default $type137)
  )
  (global.set $global402
   (struct.new_default $type137)
  )
  (global.set $global405
   (struct.new_default $type126)
  )
  (global.set $global408
   (struct.new_default $type138)
  )
  (global.set $global417
   (struct.new_default $type138)
  )
  (global.set $global426
   (struct.new_default $type139)
  )
  (global.set $global430
   (struct.new_default $type140)
  )
  (global.set $global440
   (struct.new_default $type141)
  )
  (global.set $global451
   (struct.new_default $type138)
  )
  (global.set $global457
   (struct.new_default $type140)
  )
  (global.set $global460
   (struct.new_default $type142)
  )
  (global.set $global469
   (struct.new_default $type143)
  )
  (global.set $global477
   (struct.new_default $type143)
  )
  (global.set $global489
   (struct.new_default $type144)
  )
  (global.set $global501
   (struct.new_default $type145)
  )
  (global.set $global510
   (struct.new_default $type143)
  )
  (global.set $global515
   (struct.new_default $type146)
  )
  (global.set $global521
   (struct.new_default $type147)
  )
  (global.set $global530
   (struct.new_default $type149)
  )
  (global.set $global539
   (struct.new_default $type149)
  )
  (global.set $global545
   (struct.new_default $type140)
  )
  (global.set $global548
   (struct.new_default $type140)
  )
  (global.set $global551
   (struct.new_default $type120)
  )
  (global.set $global559
   (struct.new_default $type150)
  )
  (global.set $global565
   (struct.new_default $type151)
  )
  (global.set $global576
   (struct.new_default $type152)
  )
  (global.set $global581
   (struct.new_default $type153)
  )
  (global.set $global586
   (struct.new_default $type154)
  )
  (global.set $global594
   (struct.new_default $type155)
  )
  (global.set $global640
   (struct.new_default $type132)
  )
  (global.set $global644
   (struct.new_default $type140)
  )
  (global.set $global655
   (struct.new_default $type160)
  )
  (global.set $global658
   (struct.new_default $type112)
  )
  (global.set $global698
   (struct.new_default $type134)
  )
  (global.set $global702
   (struct.new_default $type133)
  )
  (global.set $global704
   (struct.new_default $type166)
  )
  (global.set $global713
   (struct.new_default $type167)
  )
  (global.set $global717
   (struct.new_default $type136)
  )
  (global.set $global724
   (struct.new_default $type168)
  )
  (global.set $global729
   (struct.new_default $type169)
  )
  (global.set $global734
   (struct.new_default $type169)
  )
  (global.set $global740
   (struct.new_default $type131)
  )
  (global.set $global742
   (struct.new_default $type140)
  )
  (drop
   (ref.as_non_null
    (global.get $global356)
   )
  )
  (global.set $global768
   (call $function122
    (i64.const 1)
   )
  )
  (global.set $global769
   (struct.new_default $type171)
  )
  (global.set $global778
   (struct.new_default $type173)
  )
  (global.set $global780
   (struct.new_default $type173)
  )
  (global.set $global827
   (struct.new_default $type180)
  )
  (global.set $global835
   (struct.new_default $type182)
  )
  (global.set $global837
   (struct.new_default $type183)
  )
  (global.set $global847
   (struct.new_default $type186)
  )
  (global.set $global853
   (struct.new_default $type186)
  )
  (global.set $global859
   (struct.new_default $type187)
  )
  (global.set $global871
   (struct.new_default $type189)
  )
  (global.set $global874
   (struct.new_default $type189)
  )
  (global.set $global881
   (struct.new_default $type190)
  )
  (global.set $global889
   (struct.new_default $type190)
  )
  (global.set $global905
   (struct.new_default $type190)
  )
  (global.set $global911
   (struct.new_default $type193)
  )
  (global.set $global1128
   (struct.new_default $type205)
  )
  (global.set $global1136
   (struct.new_default $type206)
  )
  (global.set $global1142
   (struct.new_default $type207)
  )
  (global.set $global1154
   (struct.new_default $type210)
  )
  (global.set $global1162
   (struct.new_default $type211)
  )
  (global.set $global1171
   (struct.new_default $type212)
  )
  (global.set $global1177
   (struct.new_default $type213)
  )
  (global.set $global1181
   (struct.new_default $type214)
  )
  (global.set $global1187
   (struct.new_default $type215)
  )
  (global.set $global1194
   (struct.new_default $type215)
  )
  (global.set $global1197
   (struct.new_default $type220)
  )
  (global.set $global1203
   (struct.new_default $type221)
  )
  (global.set $global1205
   (struct.new_default $type222)
  )
  (global.set $global1212
   (struct.new_default $type227)
  )
  (global.set $global1216
   (struct.new $type228
    (i64.const 1)
   )
  )
  (global.set $global1217
   (struct.new_default $type5)
  )
  (global.set $global1219
   (struct.new_default $type229)
  )
  (global.set $global1222
   (struct.new_default $type230)
  )
  (global.set $global1224
   (struct.new_default $type231)
  )
  (global.set $global1237
   (struct.new_default $type234)
  )
  (global.set $global1251
   (struct.new_default $type235)
  )
  (global.set $global1561
   (struct.new_default $type259)
  )
  (global.set $global1566
   (struct.new_default $type260)
  )
  (global.set $global1571
   (struct.new_default $type261)
  )
  (global.set $global1578
   (struct.new_default $type262)
  )
  (global.set $global1596
   (struct.new_default $type263)
  )
  (global.set $global1576
   (struct.new_default $type263)
  )
  (global.set $global1584
   (struct.new_default $type264)
  )
  (global.set $global1593
   (struct.new_default $type265)
  )
  (global.set $global1582
   (struct.new_default $type266)
  )
  (global.set $global1676
   (struct.new_default $type266)
  )
  (global.set $global1606
   (struct.new_default $type267)
  )
  (global.set $global1645
   (struct.new_default $type270)
  )
  (global.set $global1649
   (struct.new_default $type271)
  )
  (global.set $ready1649
   (i32.const 1)
  )
  (global.set $global1612
   (struct.new_default $type272)
  )
  (global.set $global1678
   (struct.new_default $type273)
  )
  (global.set $global1686
   (struct.new_default $type59)
  )
  (global.set $global1587
   (struct.new_default $type76)
  )
  (global.set $ready1587
   (i32.const 1)
  )
  (global.set $global1669
   (struct.new_default $type274)
  )
  (global.set $ready1669
   (i32.const 1)
  )
  (global.set $global1664
   (struct.new_default $type275)
  )
  (global.set $global1573
   (struct.new_default $type275)
  )
  (global.set $ready1573
   (i32.const 1)
  )
  (global.set $global1590
   (struct.new_default $type284)
  )
  (global.set $ready1590
   (i32.const 1)
  )
  (global.set $global1661
   (struct.new_default $type275)
  )
  (global.set $ready1661
   (i32.const 1)
  )
  (global.set $global1702
   (struct.new_default $type275)
  )
  (global.set $ready1702
   (i32.const 1)
  )
  (global.set $global1704
   (struct.new_default $type285)
  )
  (global.set $ready1704
   (i32.const 1)
  )
  (global.set $global1710
   (struct.new_default $type285)
  )
  (global.set $ready1710
   (i32.const 1)
  )
  (global.set $global1598
   (struct.new_default $type286)
  )
  (global.set $ready1598
   (i32.const 1)
  )
  (global.set $global1603
   (struct.new_default $type287)
  )
  (global.set $ready1603
   (i32.const 1)
  )
  (global.set $global1607
   (struct.new_default $type291)
  )
  (global.set $ready1607
   (i32.const 1)
  )
  (global.set $global1655
   (struct.new_default $type292)
  )
  (global.set $ready1655
   (i32.const 1)
  )
  (global.set $global1638
   (struct.new_default $type293)
  )
  (global.set $ready1638
   (i32.const 1)
  )
  (global.set $global1614
   (struct.new_default $type298)
  )
  (global.set $ready1614
   (i32.const 1)
  )
  (global.set $global1631
   (struct.new_default $type266)
  )
  (global.set $ready1631
   (i32.const 1)
  )
  (global.set $global1636
   (struct.new_default $type76)
  )
  (global.set $ready1636
   (i32.const 1)
  )
  (global.set $global1633
   (struct.new_default $type299)
  )
  (global.set $ready1633
   (i32.const 1)
  )
  (global.set $global1629
   (struct.new_default $type112)
  )
  (global.set $global1626
   (struct.new_default $type266)
  )
  (global.set $global1623
   (struct.new_default $type300)
  )
  (global.set $global1618
   (struct.new_default $type301)
  )
  (global.set $ready1618
   (i32.const 1)
  )
  (global.set $global1694
   (struct.new_default $type302)
  )
  (global.set $global1673
   (struct.new_default $type275)
  )
  (global.set $ready1673
   (i32.const 1)
  )
  (global.set $global1683
   (struct.new_default $type285)
  )
  (global.set $ready1683
   (i32.const 1)
  )
  (global.set $global1692
   (struct.new_default $type302)
  )
  (global.set $ready1692
   (i32.const 1)
  )
  (global.set $global1715
   (struct.new_default $type303)
  )
  (global.set $ready1715
   (i32.const 1)
  )
  (global.set $global1782
   (struct.new_default $type304)
  )
  (global.set $ready1782
   (i32.const 1)
  )
  (global.set $global1722
   (struct.new_default $type305)
  )
  (global.set $ready1722
   (i32.const 1)
  )
  (global.set $global1772
   (struct.new_default $type306)
  )
  (global.set $ready1772
   (i32.const 1)
  )
  (global.set $global1758
   (struct.new_default $type307)
  )
  (global.set $ready1758
   (i32.const 1)
  )
  (global.set $global1731
   (struct.new_default $type308)
  )
  (global.set $ready1731
   (i32.const 1)
  )
  (global.set $global1734
   (struct.new_default $type309)
  )
  (global.set $global1728
   (struct.new_default $type310)
  )
  (global.set $ready1728
   (i32.const 1)
  )
  (global.set $global1739
   (struct.new_default $type311)
  )
  (global.set $ready1739
   (i32.const 1)
  )
  (global.set $global1750
   (struct.new_default $type234)
  )
  (global.set $global1745
   (struct.new_default $type312)
  )
  (global.set $ready1745
   (i32.const 1)
  )
  (global.set $global1791
   (struct.new_default $type314)
  )
  (global.set $global1793
   (struct.new_default $type261)
  )
  (global.set $global1799
   (struct.new_default $type315)
  )
  (global.set $global1801
   (struct.new_default $type234)
  )
  (global.set $global1809
   (struct.new_default $type316)
  )
  (global.set $ready1809
   (i32.const 1)
  )
  (global.set $global1813
   (struct.new_default $type79)
  )
  (global.set $global1815
   (struct.new_default $type317)
  )
  (global.set $global1822
   (struct.new_default $type81)
  )
  (drop
   (ref.as_non_null
    (global.get $global1822)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1828)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1828)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global113)
   )
  )
  (call $foreign0)
  (drop
   (call $function45
    (global.get $string80)
    (i64.const 9)
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (global.set $global1827
   (block (result (ref $type82))
    (local.set $scratch_11
     (block $block2 (result (ref $type82))
      (local.set $2
       (struct.new $type68
        (struct.new $type66
         (call $foreign5)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1793)
       )
      )
      (local.set $0
       (call $function472
        (ref.as_non_null
         (local.get $2)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1566)
       )
      )
      (block $block1
       (block $block
        (local.set $3
         (if (result (ref $type13))
          (i32.eq
           (struct.get $type223 0
            (local.get $0)
           )
           (i32.const 1)
          )
          (then
           (struct.get $type225 1
            (ref.cast (ref $type225)
             (local.get $0)
            )
           )
          )
          (else
           (if
            (struct.get $type223 0
             (local.get $0)
            )
            (then
             (br $block)
            )
            (else
             (br $block1)
            )
           )
           (unreachable)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1801)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $3)
          )
          (i32.const 5)
         )
         (then
          (unreachable)
         )
        )
        (br $block2
         (struct.new $type82
          (if (result i64)
           (struct.get $type24 0
            (local.tee $1
             (struct.get $type23 1
              (ref.cast (ref $type23)
               (local.get $3)
              )
             )
            )
           )
           (then
            (if
             (i32.eq
              (struct.get $type24 0
               (local.get $1)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type26)
                (local.get $1)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1136)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1128)
               )
              )
              (call $foreign20
               (call $function310
                (global.get $string79)
                (call $foreign18)
                (i32.const 1)
                (i64.const 37)
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
               )
              )
              (unreachable)
             )
             (else
              (if
               (i32.eq
                (struct.get $type24 0
                 (local.get $1)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type30)
                  (local.get $1)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type31)
                  (local.get $1)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1136)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1128)
               )
              )
              (call $foreign20
               (call $function310
                (global.get $string78)
                (call $foreign18)
                (i32.const 1)
                (i64.const 29)
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
               )
              )
              (unreachable)
             )
            )
            (unreachable)
           )
           (else
            (struct.get $type25 1
             (ref.cast (ref $type25)
              (local.get $1)
             )
            )
           )
          )
          (block (result (ref $type18))
           (drop
            (ref.as_non_null
             (global.get $global1793)
            )
           )
           (if
            (i32.ne
             (struct.get $type13 0
              (local.tee $3
               (call $function412
                (block (result (ref $type223))
                 (local.set $scratch
                  (call $function472
                   (ref.as_non_null
                    (local.get $2)
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1566)
                  )
                 )
                 (local.get $scratch)
                )
               )
              )
             )
             (i32.const 3)
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type17 1
            (ref.cast (ref $type17)
             (local.get $3)
            )
           )
          )
          (block (result (ref $type13))
           (drop
            (ref.as_non_null
             (global.get $global1793)
            )
           )
           (local.set $0
            (call $function472
             (ref.as_non_null
              (local.get $2)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1566)
            )
           )
           (if (result (ref $type13))
            (i32.eq
             (struct.get $type223 0
              (local.get $0)
             )
             (i32.const 1)
            )
            (then
             (struct.get $type225 1
              (ref.cast (ref $type225)
               (local.get $0)
              )
             )
            )
            (else
             (if
              (struct.get $type223 0
               (local.get $0)
              )
              (then
               (br $block)
              )
              (else
               (br $block1)
              )
             )
             (unreachable)
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global88)
        )
       )
       (local.set $4
        (call $function35
         (struct.new $type61
          (global.get $string27)
          (struct.new $type61
           (struct.get $type226 1
            (ref.cast (ref $type226)
             (local.get $0)
            )
           )
           (ref.null none)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1136)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1128)
        )
       )
       (call $foreign20
        (call $function310
         (local.get $4)
         (call $foreign18)
         (i32.const 1)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
         (i32.const 1)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (unreachable)
      )
      (drop
       (ref.as_non_null
        (global.get $global1136)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1128)
       )
      )
      (call $foreign20
       (call $function310
        (global.get $string28)
        (call $foreign18)
        (i32.const 1)
        (i64.const 44)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $8
         (struct.get $type66 0
          (local.tee $7
           (struct.get $type68 0
            (local.get $2)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $8)
          (i32.const -3)
         )
         (i32.eq
          (local.get $8)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type66 0
       (local.get $7)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $8)
      )
     )
    )
    (local.get $scratch_11)
   )
  )
  (global.set $global1833
   (struct.get $type82 1
    (global.get $global1827)
   )
  )
  (global.set $global1834
   (struct.get $type82 2
    (global.get $global1827)
   )
  )
  (global.set $global1835
   (struct.new_default $type5)
  )
  (global.set $ready1835
   (i32.const 1)
  )
  (global.set $global1836
   (struct.new_default $type318)
  )
  (global.set $global1839
   (struct.new_default $type112)
  )
  (global.set $ready1839
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

