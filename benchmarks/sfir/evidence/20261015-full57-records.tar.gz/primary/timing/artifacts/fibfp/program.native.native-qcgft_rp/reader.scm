(module
 (rec
  (type $type30 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment44 (struct (field i64) (field (ref $type30))))
  (type $call0 (func (param (ref null $environment44) i64 f64) (result f64)))
  (type $call27 (func (param f64) (result f64)))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment44))))
 )
 (type $7 (func (param f64) (result f64)))
 (type $8 (func (param i32) (result f64)))
 (type $9 (func (param i64) (result f64)))
 (type $10 (func))
 (import "benchmark" "hide_f64" (func $foreign0 (param f64) (result f64)))
 (import "benchmark" "input_f64" (func $foreign1 (param i32) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type0)) (ref.null none))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global108 (mut f64) (f64.const 0.0))
 (global $global109 (mut (ref null $type28)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call27) (param $0 f64) (result f64)
  (local $1 f64)
  (local $2 f64)
  (if
   (i32.eqz
    (f64.lt
     (local.get $0)
     (f64.const 2.0)
    )
   )
   (then
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.add
          (local.get $0)
          (f64.const -1.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $0)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready106)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (local.set $1
     (call $function41
      (local.get $1)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $2
         (f64.add
          (local.get $0)
          (f64.const -2.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $0)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready106)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (local.set $0
     (f64.add
      (local.get $1)
      (local.tee $2
       (call $function41
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $0)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (local.get $0)
 )
 (func $function44 (type $call0) (param $0 (ref null $environment44)) (param $1 i64) (param $2 f64) (result f64)
  (local $3 i64)
  (local $scratch f64)
  (if (result f64)
   (i64.gt_s
    (struct.get $environment44 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global114)
     )
    )
    (drop
     (struct.get $environment44 0
      (local.get $0)
     )
    )
    (local.set $2
     (call $function41
      (block (result f64)
       (local.set $scratch
        (call $foreign0
         (global.get $global108)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global106)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type0 1
      (struct.get $type30 1
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function45 (type $call0) (param $0 (ref null $environment44)) (param $1 i64) (param $2 f64) (result f64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result f64)
  (local $1 (ref $type30))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (struct.set $type30 1
   (local.tee $1
    (struct.new_default $type30)
   )
   (struct.new $type0
    (ref.func $function44)
    (struct.new $environment44
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type30 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type30 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (f64.const 0.0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global114
   (struct.new $type0
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global108
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global109
   (struct.new_default $type28)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

