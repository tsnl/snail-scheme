(module
 (rec
  (type $type49 (sub (struct)))
  (type $environment90 (struct (field i64) (field (ref $type72))))
  (type $type72 (struct (field (mut i32)) (field (mut (ref null $type66)))))
  (type $call66 (func (param (ref null $environment90) i64) (result i64)))
  (type $environment86 (struct (field i32) (field i64) (field (ref $type14)) (field (ref $type70))))
  (type $type70 (struct (field (mut i32)) (field (mut (ref null $type13)))))
  (type $call64 (func (param i32) (result (ref $type14))))
  (type $call60 (func (param (ref $type33) (ref null $type23)) (result i32)))
  (type $environment74 (struct (field (ref $type27))))
  (type $call62 (func (param (ref $type30) (ref $type27)) (result i32)))
  (type $type51 (sub $type49 (struct (field (ref $type14)))))
  (type $type30 (struct (field (ref $type28))))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $13 (func (param (ref $type30) (ref null $type23)) (result (ref null $type23))))
  (type $type28 (struct (field (mut i32))))
  (type $type27 (struct (field (ref $type28))))
  (type $16 (func (param (ref $type14) (ref $type27) i64 i32 i32 i32 i64) (result i32)))
  (type $call54 (func (param i32 i32 (ref $type14) i64) (result (ref $type14))))
  (type $18 (func (param (ref $type14) i64 i32 i32 i32 i64) (result i32)))
  (type $call33 (func (param (ref null $environment74) (ref $type14)) (result i32)))
  (type $call13 (func (param (ref null $environment86) i64) (result (ref $type14))))
  (type $21 (func (param (ref $type14) (ref $type14) i32)))
  (type $type15 (array (mut i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $24 (func (param i32) (result (ref $type14))))
  (type $type66 (struct (field (ref $call66)) (field (ref null $environment90))))
  (type $type65 (struct))
  (type $type14 (struct (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type48 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct (field (ref $call33)) (field (ref null $environment74))))
  (type $type20 (struct))
  (type $type13 (struct (field (ref $call13)) (field (ref null $environment86))))
  (type $type50 (sub $type49 (struct)))
 )
 (type $52 (func (result i32)))
 (type $53 (func))
 (type $54 (func (param i32)))
 (type $55 (func (param i32) (result i32)))
 (type $56 (func (param i32 i32)))
 (type $57 (func (param i32) (result i64)))
 (type $58 (func (param i32 i64) (result i32)))
 (type $59 (func (param i64) (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign9 (param i32 i32)))
 (import "snail.library" "snail:io/check-output" (func $foreign10 (param i32)))
 (import "benchmark" "path_length" (func $foreign11 (param i32) (result i64)))
 (import "benchmark" "path_character" (func $foreign12 (param i32 i64) (result i32)))
 (import "benchmark" "barrier" (func $foreign13 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign14 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign15 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty50 (ref $type50) (struct.new_default $type50))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $global113 (mut (ref null $type33)) (ref.null none))
 (global $global118 (mut (ref null $type34)) (ref.null none))
 (global $global120 (mut (ref null $type33)) (ref.null none))
 (global $global122 (mut (ref null $type35)) (ref.null none))
 (global $global124 (mut (ref null $type36)) (ref.null none))
 (global $global126 (mut (ref null $type37)) (ref.null none))
 (global $global131 (mut (ref null $type38)) (ref.null none))
 (global $global128 (mut (ref null $type39)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type40)) (ref.null none))
 (global $global208 (mut (ref null $type41)) (ref.null none))
 (global $global143 (mut (ref null $type48)) (ref.null none))
 (global $global147 (mut (ref null $type52)) (ref.null none))
 (global $global156 (mut (ref null $type53)) (ref.null none))
 (global $global151 (mut (ref null $type54)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type55)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type56)) (ref.null none))
 (global $global167 (mut (ref null $type57)) (ref.null none))
 (global $global173 (mut (ref null $type37)) (ref.null none))
 (global $global195 (mut (ref null $type60)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type61)) (ref.null none))
 (global $ready187 (mut i32) (i32.const 0))
 (global $global191 (mut (ref null $type62)) (ref.null none))
 (global $global198 (mut (ref null $type63)) (ref.null none))
 (global $global213 (mut (ref null $type64)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global219 (mut (ref null $type14)) (ref.null none))
 (global $global220 (mut (ref null $type14)) (ref.null none))
 (global $global221 (mut (ref null $type65)) (ref.null none))
 (global $global224 (mut (ref null $type66)) (ref.null none))
 (global $ready224 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $24) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy-forward (type $21) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (loop $label
   (if
    (local.get $2)
    (then
     (local.set $3
      (select
       (local.get $2)
       (local.tee $3
        (select
         (local.tee $3
          (i32.sub
           (i32.const 8192)
           (local.tee $6
            (i32.and
             (local.get $4)
             (i32.const 8191)
            )
           )
          )
         )
         (local.tee $8
          (i32.sub
           (i32.const 8192)
           (local.tee $7
            (i32.and
             (local.get $5)
             (i32.const 8191)
            )
           )
          )
         )
         (i32.lt_u
          (local.get $3)
          (local.get $8)
         )
        )
       )
       (i32.lt_u
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (array.copy $type15 $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $4)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $4)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $6)
      (if (result (ref $type15))
       (i32.lt_u
        (local.get $5)
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $1)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $1)
          )
          (i32.sub
           (i32.shr_u
            (local.get $5)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.get $7)
      (local.get $3)
     )
     (local.set $4
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $5
      (i32.add
       (local.get $3)
       (local.get $5)
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (local.get $3)
      )
     )
     (br $label)
    )
   )
  )
 )
 (func $function25 (type $call13) (param $0 (ref null $environment86)) (param $1 i64) (result (ref $type14))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function44 (type $call33) (param $0 (ref null $environment74)) (param $1 (ref $type14)) (result i32)
  (call $foreign0)
  (return_call $function45
   (local.get $1)
   (i64.extend_i32_u
    (struct.get $type14 0
     (local.get $1)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
  )
 )
 (func $function45 (type $18) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (local $7 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
    )
   )
  )
 )
 (func $function47 (type $call33) (param $0 (ref null $environment74)) (param $1 (ref $type14)) (result i32)
  (drop
   (struct.get $type33 1
    (global.get $global113)
   )
  )
  (call $foreign0)
  (drop
   (call $function45
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (call $foreign3)
  (i32.const 0)
 )
 (func $function59 (type $call54) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 i64) (result (ref $type14))
  (local $4 i64)
  (local $5 (ref $type14))
  (if (result (ref $type14))
   (if (result i32)
    (i32.eq
     (local.get $1)
     (i32.const -1)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i32.eq
       (local.get $1)
       (i32.const 13)
      )
      (i32.eq
       (local.get $1)
       (i32.const 10)
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (local.get $1)
      (i32.const 13)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (if
       (i32.eq
        (call $foreign8
         (local.get $0)
        )
        (i32.const 10)
       )
       (then
        (drop
         (call $foreign7
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
      (local.get $3)
     )
     (then
      (local.get $2)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (if (result (ref $type14))
       (i32.or
        (i64.lt_s
         (local.get $3)
         (i64.const 0)
        )
        (i64.lt_s
         (i64.extend_i32_u
          (struct.get $type14 0
           (local.get $2)
          )
         )
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
       (else
        (drop
         (struct.get $type13 1
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (local.set $5
         (call $string-new
          (i32.wrap_i64
           (local.get $3)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.lt_u
          (i64.extend_i32_u
           (struct.get $type14 0
            (local.get $5)
           )
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (call $string-copy-forward
         (local.get $5)
         (local.get $2)
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (local.get $5)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (if
     (i64.ge_s
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
     )
     (then
      (local.set $2
       (if (result (ref $type14))
        (i64.eq
         (local.get $3)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (drop
          (struct.get $type13 1
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.tee $4
            (if (result i64)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i64.const 64)
             )
             (else
              (if (result i64)
               (i64.gt_s
                (local.get $3)
                (i64.const 2147483647)
               )
               (then
                (i64.const 4294967294)
               )
               (else
                (if
                 (i64.ne
                  (i64.div_s
                   (local.tee $4
                    (i64.shl
                     (local.get $3)
                     (i64.const 1)
                    )
                   )
                   (i64.const 2)
                  )
                  (local.get $3)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.get $4)
               )
              )
             )
            )
           )
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (local.set $5
          (call $string-new
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.extend_i32_u
            (struct.get $type14 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_u
           (i64.extend_i32_u
            (struct.get $type14 0
             (local.get $5)
            )
           )
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (call $string-copy-forward
          (local.get $5)
          (local.get $2)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $5)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.extend_i32_s
        (local.get $1)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $1
        (i32.wrap_i64
         (local.get $3)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 2
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $1)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $1)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (local.set $1
     (call $foreign7
      (local.get $0)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready151)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function64 (type $16) (param $0 (ref $type14)) (param $1 (ref $type27)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (local $7 i32)
  (local $8 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (call $foreign9
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $1)
      )
     )
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $7
         (i32.wrap_i64
          (local.get $6)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $7)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $7)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $8
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $8)
    )
   )
  )
 )
 (func $function71 (type $13) (param $0 (ref $type30)) (param $1 (ref null $type23)) (result (ref null $type23))
  (local $2 (ref $type49))
  (local $3 (ref $type14))
  (local $4 (ref $type23))
  (local $5 i32)
  (local $6 i32)
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (local.set $2
   (if (result (ref $type49))
    (i32.eq
     (local.tee $6
      (call $foreign7
       (local.tee $5
        (struct.get $type28 0
         (struct.get $type30 0
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.const -1)
    )
    (then
     (global.get $empty50)
    )
    (else
     (drop
      (struct.get $type13 1
       (global.get $global61)
      )
     )
     (local.set $3
      (call $string-new
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready151)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global151)
      )
     )
     (struct.new $type51
      (call $function59
       (local.get $5)
       (local.get $6)
       (local.get $3)
       (i64.const 0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (if (result (ref null $type23))
   (if (result i32)
    (ref.test (ref $type50)
     (local.get $2)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type51)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type50)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.new $type23
      (struct.get $type51 0
       (ref.cast (ref $type51)
        (local.get $2)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready187)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global187)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $4)
    )
   )
  )
 )
 (func $function73 (type $call62) (param $0 (ref $type30)) (param $1 (ref $type27)) (result i32)
  (local $2 (ref null $type23))
  (local $3 (ref $type33))
  (drop
   (ref.as_non_null
    (global.get $global187)
   )
  )
  (local.set $2
   (call $function71
    (local.get $0)
    (ref.null none)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call33
      (struct.get $type33 1
       (local.tee $3
        (struct.new $type33
         (ref.func $function74)
         (struct.new $environment74
          (local.get $1)
         )
        )
       )
      )
      (struct.get $type23 0
       (local.get $2)
      )
      (struct.get $type33 0
       (local.get $3)
      )
     )
    )
    (local.set $2
     (struct.get $type23 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready195)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global195)
     )
    )
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (call_ref $call33
        (struct.get $type33 1
         (local.get $3)
        )
        (struct.get $type23 0
         (local.get $2)
        )
        (struct.get $type33 0
         (local.get $3)
        )
       )
      )
      (local.set $2
       (struct.get $type23 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready195)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global195)
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (call_ref $call33
          (struct.get $type33 1
           (local.get $3)
          )
          (struct.get $type23 0
           (local.get $2)
          )
          (struct.get $type33 0
           (local.get $3)
          )
         )
        )
        (local.set $2
         (struct.get $type23 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready195)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global195)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.get $2)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (call_ref $call33
            (struct.get $type33 1
             (local.get $3)
            )
            (struct.get $type23 0
             (local.get $2)
            )
            (struct.get $type33 0
             (local.get $3)
            )
           )
          )
          (local.set $2
           (struct.get $type23 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready195)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global195)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (call_ref $call33
              (struct.get $type33 1
               (local.get $3)
              )
              (struct.get $type23 0
               (local.get $2)
              )
              (struct.get $type33 0
               (local.get $3)
              )
             )
            )
            (local.set $2
             (struct.get $type23 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready195)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global195)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (call_ref $call33
                (struct.get $type33 1
                 (local.get $3)
                )
                (struct.get $type23 0
                 (local.get $2)
                )
                (struct.get $type33 0
                 (local.get $3)
                )
               )
              )
              (local.set $2
               (struct.get $type23 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready195)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global195)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (call_ref $call33
                  (struct.get $type33 1
                   (local.get $3)
                  )
                  (struct.get $type23 0
                   (local.get $2)
                  )
                  (struct.get $type33 0
                   (local.get $3)
                  )
                 )
                )
                (local.set $2
                 (struct.get $type23 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready195)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global195)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (call_ref $call33
                    (struct.get $type33 1
                     (local.get $3)
                    )
                    (struct.get $type23 0
                     (local.get $2)
                    )
                    (struct.get $type33 0
                     (local.get $3)
                    )
                   )
                  )
                  (local.set $2
                   (struct.get $type23 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready195)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global195)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (call_ref $call33
                      (struct.get $type33 1
                       (local.get $3)
                      )
                      (struct.get $type23 0
                       (local.get $2)
                      )
                      (struct.get $type33 0
                       (local.get $3)
                      )
                     )
                    )
                    (local.set $2
                     (struct.get $type23 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready195)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global195)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (call_ref $call33
                        (struct.get $type33 1
                         (local.get $3)
                        )
                        (struct.get $type23 0
                         (local.get $2)
                        )
                        (struct.get $type33 0
                         (local.get $3)
                        )
                       )
                      )
                      (local.set $2
                       (struct.get $type23 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready195)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global195)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (call_ref $call33
                          (struct.get $type33 1
                           (local.get $3)
                          )
                          (struct.get $type23 0
                           (local.get $2)
                          )
                          (struct.get $type33 0
                           (local.get $3)
                          )
                         )
                        )
                        (local.set $2
                         (struct.get $type23 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready195)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global195)
                         )
                        )
                        (if (result i32)
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (call_ref $call33
                            (struct.get $type33 1
                             (local.get $3)
                            )
                            (struct.get $type23 0
                             (local.get $2)
                            )
                            (struct.get $type33 0
                             (local.get $3)
                            )
                           )
                          )
                          (local.set $2
                           (struct.get $type23 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready195)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global195)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (call_ref $call33
                              (struct.get $type33 1
                               (local.get $3)
                              )
                              (struct.get $type23 0
                               (local.get $2)
                              )
                              (struct.get $type33 0
                               (local.get $3)
                              )
                             )
                            )
                            (local.set $2
                             (struct.get $type23 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready195)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global195)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (call_ref $call33
                                (struct.get $type33 1
                                 (local.get $3)
                                )
                                (struct.get $type23 0
                                 (local.get $2)
                                )
                                (struct.get $type33 0
                                 (local.get $3)
                                )
                               )
                              )
                              (local.set $2
                               (struct.get $type23 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready195)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global195)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (call_ref $call33
                                  (struct.get $type33 1
                                   (local.get $3)
                                  )
                                  (struct.get $type23 0
                                   (local.get $2)
                                  )
                                  (struct.get $type33 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (local.set $2
                                 (struct.get $type23 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready195)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global195)
                                 )
                                )
                                (return_call $function75
                                 (local.get $3)
                                 (local.get $2)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function74 (type $call33) (param $0 (ref null $environment74)) (param $1 (ref $type14)) (result i32)
  (local $2 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (call $foreign10
   (struct.get $type28 0
    (struct.get $type27 0
     (local.tee $2
      (struct.get $environment74 0
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (call $function64
    (local.get $1)
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global173)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (call $foreign9
   (struct.get $type28 0
    (struct.get $type27 0
     (local.get $2)
    )
   )
   (i32.const 10)
  )
  (i32.const 0)
 )
 (func $function75 (type $call60) (param $0 (ref $type33)) (param $1 (ref null $type23)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call33
      (struct.get $type33 1
       (local.get $0)
      )
      (struct.get $type23 0
       (local.get $1)
      )
      (struct.get $type33 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type23 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready195)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global195)
     )
    )
    (return_call $function75
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function81 (type $call64) (param $0 i32) (result (ref $type14))
  (local $1 (ref $type70))
  (local $2 (ref $type13))
  (local $3 i64)
  (struct.set $type70 1
   (local.tee $1
    (struct.new_default $type70)
   )
   (struct.new $type13
    (ref.func $function86)
    (struct.new $environment86
     (local.get $0)
     (local.tee $3
      (call $foreign11
       (local.get $0)
      )
     )
     (block (result (ref $type14))
      (drop
       (struct.get $type13 1
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-new
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type70 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type70 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call13
   (struct.get $type13 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type70 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type13 0
    (local.get $2)
   )
  )
 )
 (func $function86 (type $call13) (param $0 (ref null $environment86)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $environment86))
  (local $3 (ref $type14))
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (if (result (ref $type14))
   (i64.eq
    (struct.get $environment86 1
     (local.tee $2
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $environment86 2
     (local.get $2)
    )
   )
   (else
    (local.set $5
     (call $foreign12
      (struct.get $environment86 0
       (local.get $2)
      )
      (local.get $1)
     )
    )
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.tee $3
         (struct.get $environment86 2
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $4
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 1
        (local.get $3)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 2
          (local.get $3)
         )
         (i32.sub
          (i32.shr_u
           (local.get $4)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $4)
      (i32.const 8191)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type70 0
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function86
     (struct.get $type13 1
      (struct.get $type70 1
       (struct.get $environment86 3
        (local.get $2)
       )
      )
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function88 (type $call66) (param $0 (ref null $environment90)) (param $1 i64) (result i64)
  (local $2 (ref $type72))
  (local $3 (ref $type66))
  (struct.set $type72 1
   (local.tee $2
    (struct.new_default $type72)
   )
   (struct.new $type66
    (ref.func $function90)
    (struct.new $environment90
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type72 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type72 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call66
   (struct.get $type66 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type72 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type66 0
    (local.get $3)
   )
  )
 )
 (func $function90 (type $call66) (param $0 (ref null $environment90)) (param $1 i64) (result i64)
  (local $2 i32)
  (local $3 i64)
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type28))
  (local $7 (ref $type30))
  (local $8 (ref $type27))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment90 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global221)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (if
     (i32.eqz
      (call $foreign13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global221)
     )
    )
    (local.set $4
     (ref.as_non_null
      (global.get $global220)
     )
    )
    (if
     (i32.eqz
      (call $foreign13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global208)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (drop
     (struct.get $type33 1
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $5)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $7
     (struct.new $type30
      (struct.new $type28
       (call $foreign5)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (struct.get $type33 1
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $4)
      (local.tee $3
       (i64.extend_i32_u
        (struct.get $type14 0
         (local.get $4)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eq
      (call $foreign2)
      (i32.const 1)
     )
     (then
      (drop
       (struct.get $type33 1
        (global.get $global120)
       )
      )
      (drop
       (struct.get $type33 1
        (global.get $global113)
       )
      )
      (call $foreign0)
      (drop
       (call $function45
        (local.get $4)
        (local.get $3)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (call $foreign3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (struct.get $type33 1
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $4)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $8
     (struct.new $type27
      (struct.new $type28
       (call $foreign4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global191)
     )
    )
    (drop
     (call $function73
      (local.get $7)
      (local.get $8)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $2
         (struct.get $type28 0
          (local.tee $6
           (struct.get $type27 0
            (local.get $8)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $2)
          (i32.const -3)
         )
         (i32.eq
          (local.get $2)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type28 0
       (local.get $6)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $2)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $2
         (struct.get $type28 0
          (local.tee $6
           (struct.get $type30 0
            (local.get $7)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $2)
          (i32.const -3)
         )
         (i32.eq
          (local.get $2)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type28 0
       (local.get $6)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $2)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type72 0
       (struct.get $environment90 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (struct.get $type66 1
      (struct.get $type72 1
       (struct.get $environment90 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
    )
   )
   (else
    (i64.const 1)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type72))
  (local $2 (ref $type66))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready224)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type66 1
    (global.get $global224)
   )
  )
  (struct.set $type72 1
   (local.tee $1
    (struct.new_default $type72)
   )
   (struct.new $type66
    (ref.func $function90)
    (struct.new $environment90
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type72 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type72 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call66
   (struct.get $type66 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type72 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type66 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new $type13
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (drop
   (call $foreign15)
  )
  (drop
   (call $foreign14)
  )
  (global.set $global113
   (struct.new $type33
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global118
   (struct.new_default $type34)
  )
  (global.set $global120
   (struct.new $type33
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $global122
   (struct.new_default $type35)
  )
  (global.set $global124
   (struct.new_default $type36)
  )
  (global.set $global126
   (struct.new_default $type37)
  )
  (global.set $global131
   (struct.new_default $type38)
  )
  (global.set $global128
   (struct.new_default $type39)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type40)
  )
  (global.set $global208
   (struct.new_default $type41)
  )
  (global.set $global143
   (struct.new_default $type48)
  )
  (global.set $global147
   (struct.new_default $type52)
  )
  (global.set $global156
   (struct.new_default $type53)
  )
  (global.set $global151
   (struct.new_default $type54)
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type55)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type56)
  )
  (global.set $global167
   (struct.new_default $type57)
  )
  (global.set $global173
   (struct.new_default $type37)
  )
  (global.set $global195
   (struct.new_default $type60)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global187
   (struct.new_default $type61)
  )
  (global.set $ready187
   (i32.const 1)
  )
  (global.set $global191
   (struct.new_default $type62)
  )
  (global.set $global198
   (struct.new_default $type63)
  )
  (global.set $global213
   (struct.new_default $type64)
  )
  (global.set $ready213
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global213)
   )
  )
  (global.set $global219
   (call $function81
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready213)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global213)
   )
  )
  (global.set $global220
   (call $function81
    (i32.const 1)
   )
  )
  (global.set $global221
   (struct.new_default $type65)
  )
  (global.set $global224
   (struct.new $type66
    (ref.func $function88)
    (ref.null none)
   )
  )
  (global.set $ready224
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

