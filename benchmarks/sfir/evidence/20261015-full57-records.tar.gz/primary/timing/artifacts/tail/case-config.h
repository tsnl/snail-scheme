#define OBSERVE_BARRIERS 0
#ifndef BENCHMARK_CASE_CONFIG
#define BENCHMARK_CASE_CONFIG
#include <stdint.h>
static const int64_t input_integers[] = {0};
static const double input_reals[] = {0};
static const int64_t vector_integers[] = {0};
static const double vector_reals[] = {0};
static const int64_t expected_integers[] = {1};
static const double expected_reals[] = {1};
static const int64_t vector_sizes[] = {0};
static const int64_t vector_offsets[] = {0};
static const int64_t configured_count = 50;
static const int64_t expected_size = 1;
static const int64_t expected_setup = 0;
static const int64_t expected_barriers = 100;
static const int64_t expected_setup_closed = 0;
static const int64_t expected_worker_closed = 100;
static const int64_t expected_result = 1;
static const double expected_tolerance = 0;
#define FLOAT_RESULT 0
#define CONFIGURED_COUNT 0
static const char *diagnostic_text[] = {""};
static const char *diagnostic_prefix[] = {""};
static const char *diagnostic_suffix[] = {""};
static const uint32_t path_characters[] = {105, 110, 112, 117, 116, 115, 47, 98, 105, 98, 111, 117, 116, 112, 117, 116, 115, 47, 116, 97, 105, 108, 46, 111, 117, 116, 112, 117, 116};
static const int64_t path_sizes[] = {10, 19};
static const int64_t path_offsets[] = {0, 10};
#define PATH_ARGUMENTS 1
#endif
