(module
 (rec
  (type $call28 (func (param i64 i64 i64) (result i64)))
  (type $type31 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $environment43 (struct (field i64) (field (ref $type31))))
  (type $call27 (func (param (ref null $environment43) i64 i64) (result i64)))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment43))))
 )
 (type $7 (func (param i64) (result i64)))
 (type $8 (func (param i32) (result i64)))
 (type $9 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type27)) (ref.null none))
 (global $global117 (mut (ref null $type28)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global106 (mut i64) (i64.const 0))
 (global $global107 (mut i64) (i64.const 0))
 (global $global108 (mut i64) (i64.const 0))
 (global $global109 (mut (ref null $type29)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment43 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global114)
     )
    )
    (drop
     (struct.get $environment43 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $function45
      (call $foreign0
       (global.get $global106)
      )
      (block (result i64)
       (drop
        (struct.get $type27 1
         (global.get $global114)
        )
       )
       (call $foreign0
        (global.get $global107)
       )
      )
      (block (result i64)
       (drop
        (struct.get $type27 1
         (global.get $global114)
        )
       )
       (local.set $scratch
        (call $foreign0
         (global.get $global108)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global117)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type31 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type27 1
      (struct.get $type31 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function45 (type $call28) (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready117)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (return_call $function45
     (call $function45
      (local.get $3)
      (local.get $1)
      (local.get $2)
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $4
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready117)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global117)
       )
      )
      (call $function45
       (local.get $4)
       (local.get $2)
       (local.get $0)
      )
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $5
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready117)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global117)
       )
      )
      (local.set $scratch
       (call $function45
        (local.get $5)
        (local.get $0)
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready117)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global117)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type31))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (struct.set $type31 1
   (local.tee $1
    (struct.new_default $type31)
   )
   (struct.new $type27
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type31 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type31 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type31 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global114
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global117
   (struct.new_default $type28)
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global106
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global107
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global108
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $global109
   (struct.new_default $type29)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

