(module
 (rec
  (type $call27 (func (param (ref null $type28) (ref null $type28)) (result (ref null $type28))))
  (type $1 (func (param i32 i32 i64 i64 (ref null $type28)) (result i32)))
  (type $2 (func (param i32 i32 i32 i32 (ref null $type28) (ref null $type28) (ref null $type28)) (result i64)))
  (type $call33 (func (param (ref $environment48) i64 (ref $type28)) (result (ref null $type28))))
  (type $type32 (struct (field (mut i32)) (field (mut (ref null $type29)))))
  (type $type33 (struct (field (ref $environment48))))
  (type $environment43 (struct (field i64) (field (ref $type32))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $type28 (struct (field i64) (field (ref null $type28))))
  (type $environment48 (struct (field (ref $type35))))
  (type $call29 (func (param (ref null $environment43) i64 i64) (result i64)))
  (type $type30 (struct))
  (type $type29 (struct (field (ref $call29)) (field (ref null $environment43))))
  (type $type27 (struct))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type27)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type29)) (ref.null none))
 (global $global116 (mut (ref null $type30)) (ref.null none))
 (global $global107 (mut i64) (i64.const 0))
 (global $global108 (mut (ref null $type30)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call29) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $environment48))
  (local $4 (ref $type28))
  (local $5 (ref $type35))
  (local $6 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment43 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global113)
     )
    )
    (drop
     (struct.get $environment43 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global107)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (struct.set $type35 1
     (local.tee $5
      (struct.new_default $type35)
     )
     (struct.new $type33
      (struct.new $environment48
       (local.get $5)
      )
     )
    )
    (struct.set $type35 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type33 0
      (struct.get $type35 1
       (local.get $5)
      )
     )
    )
    (local.set $1
     (call $function49
      (i32.const 0)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (if (result (ref null $type28))
       (i64.eqz
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $2
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
            (local.get $1)
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (struct.get $type35 0
           (struct.get $environment48 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type33 0
          (struct.get $type35 1
           (struct.get $environment48 0
            (local.get $3)
           )
          )
         )
        )
        (local.set $4
         (struct.new $type28
          (local.get $1)
          (ref.null none)
         )
        )
        (if (result (ref null $type28))
         (i64.eqz
          (local.get $2)
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $1
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (local.get $2)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (struct.get $type35 0
             (struct.get $environment48 0
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type33 0
            (struct.get $type35 1
             (struct.get $environment48 0
              (local.get $3)
             )
            )
           )
          )
          (local.set $4
           (struct.new $type28
            (local.get $2)
            (local.get $4)
           )
          )
          (if (result (ref null $type28))
           (i64.eqz
            (local.get $1)
           )
           (then
            (local.get $4)
           )
           (else
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $2
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $1)
               )
               (i64.xor
                (local.get $1)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (struct.get $type35 0
               (struct.get $environment48 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type33 0
              (struct.get $type35 1
               (struct.get $environment48 0
                (local.get $3)
               )
              )
             )
            )
            (local.set $4
             (struct.new $type28
              (local.get $1)
              (local.get $4)
             )
            )
            (if (result (ref null $type28))
             (i64.eqz
              (local.get $2)
             )
             (then
              (local.get $4)
             )
             (else
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $1
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (local.get $2)
                 )
                 (i64.xor
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (struct.get $type35 0
                 (struct.get $environment48 0
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type33 0
                (struct.get $type35 1
                 (struct.get $environment48 0
                  (local.get $3)
                 )
                )
               )
              )
              (local.set $4
               (struct.new $type28
                (local.get $2)
                (local.get $4)
               )
              )
              (if (result (ref null $type28))
               (i64.eqz
                (local.get $1)
               )
               (then
                (local.get $4)
               )
               (else
                (if
                 (i64.lt_s
                  (i64.and
                   (i64.xor
                    (local.tee $2
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (local.get $1)
                   )
                   (i64.xor
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type35 0
                   (struct.get $environment48 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type33 0
                  (struct.get $type35 1
                   (struct.get $environment48 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (local.set $4
                 (struct.new $type28
                  (local.get $1)
                  (local.get $4)
                 )
                )
                (if (result (ref null $type28))
                 (i64.eqz
                  (local.get $2)
                 )
                 (then
                  (local.get $4)
                 )
                 (else
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $1
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (local.get $2)
                     )
                     (i64.xor
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type35 0
                     (struct.get $environment48 0
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type33 0
                    (struct.get $type35 1
                     (struct.get $environment48 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (local.set $4
                   (struct.new $type28
                    (local.get $2)
                    (local.get $4)
                   )
                  )
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (local.get $4)
                   )
                   (else
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $2
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (local.get $1)
                       )
                       (i64.xor
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type35 0
                       (struct.get $environment48 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type33 0
                      (struct.get $type35 1
                       (struct.get $environment48 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (local.set $4
                     (struct.new $type28
                      (local.get $1)
                      (local.get $4)
                     )
                    )
                    (if (result (ref null $type28))
                     (i64.eqz
                      (local.get $2)
                     )
                     (then
                      (local.get $4)
                     )
                     (else
                      (if
                       (i64.lt_s
                        (i64.and
                         (i64.xor
                          (local.tee $1
                           (i64.sub
                            (local.get $2)
                            (i64.const 1)
                           )
                          )
                          (local.get $2)
                         )
                         (i64.xor
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type35 0
                         (struct.get $environment48 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type33 0
                        (struct.get $type35 1
                         (struct.get $environment48 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (local.set $4
                       (struct.new $type28
                        (local.get $2)
                        (local.get $4)
                       )
                      )
                      (if (result (ref null $type28))
                       (i64.eqz
                        (local.get $1)
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (if
                         (i64.lt_s
                          (i64.and
                           (i64.xor
                            (local.tee $2
                             (i64.sub
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (local.get $1)
                           )
                           (i64.xor
                            (local.get $1)
                            (i64.const 1)
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type35 0
                           (struct.get $environment48 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $function48
                         (struct.get $type33 0
                          (struct.get $type35 1
                           (struct.get $environment48 0
                            (local.get $3)
                           )
                          )
                         )
                         (local.get $2)
                         (struct.new $type28
                          (local.get $1)
                          (local.get $4)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (ref.null none)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (struct.get $type32 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type29 1
      (struct.get $type32 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (local.get $6)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call29) (param $0 (ref null $environment43)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function48 (type $call33) (param $0 (ref $environment48)) (param $1 i64) (param $2 (ref $type28)) (result (ref null $type28))
  (local $3 i64)
  (if (result (ref $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment48 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type33 0
      (struct.get $type35 1
       (struct.get $environment48 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function49 (type $2) (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type28)) (param $5 (ref null $type28)) (param $6 (ref null $type28)) (result i64)
  (local $7 (ref null $type28))
  (local $8 (ref null $type28))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (if (result i64)
   (ref.is_null
    (local.get $4)
   )
   (then
    (i64.extend_i32_u
     (ref.is_null
      (local.get $5)
     )
    )
   )
   (else
    (local.set $9
     (struct.get $type28 0
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (if (result i64)
      (call $function50
       (local.get $2)
       (local.get $3)
       (local.get $9)
       (i64.const 1)
       (local.get $6)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global131)
        )
       )
       (local.set $8
        (if (result (ref null $type28))
         (ref.is_null
          (local.tee $7
           (struct.get $type28 1
            (local.get $4)
           )
          )
         )
         (then
          (local.get $5)
         )
         (else
          (struct.new $type28
           (struct.get $type28 0
            (local.get $7)
           )
           (block (result (ref null $type28))
            (local.set $7
             (struct.get $type28 1
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready131)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global131)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $7)
             )
             (then
              (local.get $5)
             )
             (else
              (struct.new $type28
               (struct.get $type28 0
                (local.get $7)
               )
               (block (result (ref null $type28))
                (local.set $7
                 (struct.get $type28 1
                  (local.get $7)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready131)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global131)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $7)
                 )
                 (then
                  (local.get $5)
                 )
                 (else
                  (struct.new $type28
                   (struct.get $type28 0
                    (local.get $7)
                   )
                   (block (result (ref null $type28))
                    (local.set $7
                     (struct.get $type28 1
                      (local.get $7)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready131)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global131)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $7)
                     )
                     (then
                      (local.get $5)
                     )
                     (else
                      (struct.new $type28
                       (struct.get $type28 0
                        (local.get $7)
                       )
                       (block (result (ref null $type28))
                        (local.set $7
                         (struct.get $type28 1
                          (local.get $7)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready131)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global131)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $7)
                         )
                         (then
                          (local.get $5)
                         )
                         (else
                          (struct.new $type28
                           (struct.get $type28 0
                            (local.get $7)
                           )
                           (block (result (ref null $type28))
                            (local.set $7
                             (struct.get $type28 1
                              (local.get $7)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready131)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global131)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $7)
                             )
                             (then
                              (local.get $5)
                             )
                             (else
                              (struct.new $type28
                               (struct.get $type28 0
                                (local.get $7)
                               )
                               (block (result (ref null $type28))
                                (local.set $7
                                 (struct.get $type28 1
                                  (local.get $7)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready131)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global131)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $7)
                                 )
                                 (then
                                  (local.get $5)
                                 )
                                 (else
                                  (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $7)
                                   )
                                   (block (result (ref null $type28))
                                    (local.set $7
                                     (struct.get $type28 1
                                      (local.get $7)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready131)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global131)
                                     )
                                    )
                                    (if (result (ref null $type28))
                                     (ref.is_null
                                      (local.get $7)
                                     )
                                     (then
                                      (local.get $5)
                                     )
                                     (else
                                      (struct.new $type28
                                       (struct.get $type28 0
                                        (local.get $7)
                                       )
                                       (block (result (ref null $type28))
                                        (local.set $7
                                         (struct.get $type28 1
                                          (local.get $7)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready131)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global131)
                                         )
                                        )
                                        (if (result (ref null $type28))
                                         (ref.is_null
                                          (local.get $7)
                                         )
                                         (then
                                          (local.get $5)
                                         )
                                         (else
                                          (struct.new $type28
                                           (struct.get $type28 0
                                            (local.get $7)
                                           )
                                           (block (result (ref null $type28))
                                            (local.set $7
                                             (struct.get $type28 1
                                              (local.get $7)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready131)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global131)
                                             )
                                            )
                                            (if (result (ref null $type28))
                                             (ref.is_null
                                              (local.get $7)
                                             )
                                             (then
                                              (local.get $5)
                                             )
                                             (else
                                              (struct.new $type28
                                               (struct.get $type28 0
                                                (local.get $7)
                                               )
                                               (call $function51
                                                (struct.get $type28 1
                                                 (local.get $7)
                                                )
                                                (block (result (ref null $type28))
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready131)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global131)
                                                  )
                                                 )
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (local.set $9
        (struct.get $type28 0
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (local.get $1)
        )
        (then
         (unreachable)
        )
       )
       (call $function49
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $8)
        (ref.null none)
        (struct.new $type28
         (local.get $9)
         (local.get $6)
        )
       )
      )
      (else
       (i64.const 0)
      )
     )
    )
    (local.set $7
     (struct.get $type28 1
      (local.get $4)
     )
    )
    (local.set $10
     (struct.get $type28 0
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $10
         (i64.add
          (local.tee $11
           (call $function49
            (local.get $0)
            (local.get $1)
            (local.get $2)
            (local.get $3)
            (local.get $7)
            (struct.new $type28
             (local.get $10)
             (local.get $5)
            )
            (local.get $6)
           )
          )
          (local.get $9)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $10)
   )
  )
 )
 (func $function50 (type $1) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (param $4 (ref null $type28)) (result i32)
  (local $5 i64)
  (local $6 i64)
  (if (result i32)
   (ref.is_null
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (local.set $6
     (struct.get $type28 0
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $5)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $5)
      (local.get $6)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type28 0
         (local.get $4)
        )
        (block (result i64)
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $6
              (i64.sub
               (local.get $2)
               (local.get $3)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (local.get $3)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.get $6)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $3)
            (local.tee $5
             (i64.add
              (local.get $3)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $5)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (struct.get $type28 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function50
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $5)
         (local.get $4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call27) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (result (ref null $type28))
  (local $2 i64)
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function51
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (global.get $ready131)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global131)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type32))
  (local $2 (ref $type29))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready108)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global108)
   )
  )
  (struct.set $type32 1
   (local.tee $1
    (struct.new_default $type32)
   )
   (struct.new $type29
    (ref.func $function43)
    (struct.new $environment43
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type32 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type32 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call29
   (struct.get $type29 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type32 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type29 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type27)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global113
   (struct.new $type29
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global116
   (struct.new_default $type30)
  )
  (global.set $global107
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global108
   (struct.new_default $type30)
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

