(module
 (rec
  (type $type97 (sub (struct)))
  (type $type39 (sub (struct (field i32))))
  (type $type35 (sub (struct)))
  (type $type49 (sub (struct)))
  (type $type44 (sub (struct)))
  (type $call213 (func (param (ref $environment315) i64 (ref null $type54)) (result i64)))
  (type $type213 (struct (field (ref $environment315))))
  (type $environment315 (struct (field i64) (field (ref $type215))))
  (type $type215 (struct (field (mut i32)) (field (mut (ref null $type213)))))
  (type $9 (func (param (ref $environment310) (ref null $type30)) (result (ref $type32))))
  (type $environment310 (struct (field i64)))
  (type $11 (func (param i64) (result (ref null $type54))))
  (type $environment305 (struct (field i64) (field (ref $type16)) (field (ref $type211))))
  (type $type211 (struct (field (mut i32)) (field (mut (ref null $type15)))))
  (type $14 (func (result i64)))
  (type $environment295 (struct (field (ref $type206)) (field i64) (field (ref $type32)) (field (ref $type208))))
  (type $environment292 (struct (field (ref $type94))))
  (type $type208 (struct (field (mut i32)) (field (mut (ref null $type103)))))
  (type $call204 (func (param (ref $environment290) i64 (ref $type32) (ref null $type32) (ref $type104)) (result (ref $type104))))
  (type $environment284 (struct (field (ref $type84))))
  (type $environment285 (struct (field (ref $type84))))
  (type $21 (func (param i64 (ref $type84) (ref null $type32)) (result (ref null $type32))))
  (type $22 (func (param (ref $environment281) i32) (result i32)))
  (type $environment281 (struct (field (ref $type201)) (field (ref null $type110))))
  (type $type199 (struct (field (ref $environment280))))
  (type $type201 (struct (field (mut i32)) (field (mut (ref null $type199)))))
  (type $environment280 (struct (field (ref null $type30)) (field (ref $type201))))
  (type $environment276 (struct (field (ref $type109)) (field (ref null $type30))))
  (type $call195 (func (param (ref $environment274) i64 (ref null $type32) (ref $type109) i64 (ref null $type110)) (result (ref null $type110))))
  (type $call109 (func (param (ref struct) (ref null $type32) (ref null $type110)) (result (ref null $type110))))
  (type $environment278 (struct (field (ref null $type110))))
  (type $type110 (struct (field (ref $type94)) (field (ref null $type110))))
  (type $type195 (struct (field (ref $environment274))))
  (type $environment274 (struct (field (ref $type197))))
  (type $environment270 (struct (field (ref $type93)) (field (ref null $type30))))
  (type $type109 (struct (field (ref $call109)) (field (ref struct))))
  (type $type197 (struct (field (mut i32)) (field (mut (ref null $type195)))))
  (type $type204 (struct (field (ref $environment290))))
  (type $environment290 (struct (field i64) (field (ref $type103)) (field (ref $type93)) (field (ref $type93)) (field (ref $type206))))
  (type $environment268 (struct (field i64) (field (ref $type93))))
  (type $type93 (struct (field (ref $call93)) (field (ref struct))))
  (type $type206 (struct (field (mut i32)) (field (mut (ref null $type204)))))
  (type $call105 (func (param i64 i64) (result (ref null $type54))))
  (type $call186 (func (param (ref $environment260) (ref null $type32) i64) (result i64)))
  (type $type104 (struct (field i64) (field i64) (field (ref null $type54))))
  (type $type186 (struct (field (ref $environment260))))
  (type $type188 (struct (field (mut i32)) (field (mut (ref null $type186)))))
  (type $environment260 (struct (field (ref $type188))))
  (type $call103 (func (param (ref null $environment295) (ref null $type32) (ref $type104)) (result (ref $type104))))
  (type $environment256 (struct (field i64) (field (ref $type184))))
  (type $environment242 (struct (field i64) (field (ref $type182))))
  (type $type182 (struct (field (mut i32)) (field (mut (ref null $type43)))))
  (type $environment249 (struct (field i64) (field (ref $type47)) (field (ref $type61)) (field (ref $type184))))
  (type $environment240 (struct (field (ref $type46))))
  (type $type47 (struct (field (mut (ref $type44)))))
  (type $type184 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $environment231 (struct (field (ref $type33)) (field (ref $type12))))
  (type $type99 (sub $type97 (struct)))
  (type $environment228 (struct (field i64)))
  (type $environment226 (struct (field (ref $type33))))
  (type $environment224 (struct (field (ref $type33))))
  (type $environment222 (struct (field (ref $type33))))
  (type $environment220 (struct (field (ref $type33))))
  (type $environment218 (struct (field i64)))
  (type $type98 (sub $type97 (struct (field i64))))
  (type $type169 (struct (field (ref $environment208))))
  (type $type171 (struct (field (mut i32)) (field (mut (ref null $type169)))))
  (type $environment209 (struct (field (ref $type171)) (field i64) (field i64) (field i64) (field i64) (field i64) (field i64)))
  (type $environment208 (struct (field (ref $type171))))
  (type $69 (func (param (ref $environment209) i64) (result (ref $type97))))
  (type $environment186 (struct (field (ref $type60)) (field (ref $type60)) (field i64)))
  (type $71 (func (param (ref $environment177) i64 (ref null $type30)) (result i32)))
  (type $environment177 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type161)) (field (ref null $type32))))
  (type $type159 (struct (field (ref $environment176))))
  (type $type161 (struct (field (mut i32)) (field (mut (ref null $type159)))))
  (type $environment176 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type161))))
  (type $call94 (func (param (ref struct) (ref null $type30)) (result i32)))
  (type $type94 (struct (field (ref $call94)) (field (ref struct))))
  (type $environment174 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref null $type32))))
  (type $environment172 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type55))))
  (type $call93 (func (param (ref struct) (ref $type32)) (result (ref $type94))))
  (type $81 (func (param (ref $type60) (ref null $type30) (ref null $type30)) (result (ref null $type30))))
  (type $environment167 (struct (field (ref $type60)) (field (ref $type60)) (field i64)))
  (type $83 (func (param (ref $type33) (ref null $type30)) (result (ref null $type30))))
  (type $84 (func (param (ref $environment152) (ref null $type30)) (result (ref $type32))))
  (type $85 (func (param (ref $type57) (ref null $type32)) (result (ref null $type32))))
  (type $call57 (func (param structref (ref null $type30)) (result (ref null $type30))))
  (type $environment163 (struct (field i64)))
  (type $environment164 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref null $type30))))
  (type $environment159 (struct (field (ref $type60)) (field i64)))
  (type $environment152 (struct (field (ref $type57)) (field (ref null $type32))))
  (type $environment150 (struct))
  (type $type57 (struct (field (ref $call57)) (field structref)))
  (type $environment149 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type33)) (field (ref $type152)) (field (ref $type124))))
  (type $environment146 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type33)) (field (ref $type152))))
  (type $environment144 (struct (field (ref $type61)) (field (ref $type60)) (field (ref $type33)) (field (ref $type60)) (field (ref $type33))))
  (type $type152 (struct (field (mut i32)) (field (mut (ref null $type55)))))
  (type $environment142 (struct (field i64) (field (ref $type33)) (field (ref $type12)) (field (ref $type117))))
  (type $call55 (func (param structref (ref null $type32)) (result (ref null $type32))))
  (type $environment130 (struct (field (ref $type124))))
  (type $environment126 (struct (field (ref $type84)) (field (ref $type77)) (field (ref $type144)) (field (ref null $type32)) (field (ref null $type32)) (field (ref null $type30)) (field (ref null $type30)) (field (ref $type149))))
  (type $type149 (struct (field (mut i32)) (field (mut (ref null $type67)))))
  (type $call145 (func (param (ref $environment124) (ref null $type30) (ref null $type30) (ref null $type30) (ref null $type30)) (result i32)))
  (type $type145 (struct (field (ref $environment124))))
  (type $environment124 (struct (field (ref $type84)) (field (ref $type33)) (field (ref $type77)) (field (ref $type144)) (field (ref null $type32)) (field (ref null $type32)) (field (ref $type147))))
  (type $type142 (struct (field (ref $environment122))))
  (type $environment120 (struct (field (ref $type84))))
  (type $environment122 (struct (field (ref $type84)) (field (ref $type33)) (field (ref $type77)) (field (ref $type144))))
  (type $type147 (struct (field (mut i32)) (field (mut (ref null $type145)))))
  (type $type144 (struct (field (mut i32)) (field (mut (ref null $type142)))))
  (type $110 (func (param (ref $environment120) (ref null $type30) (ref $type33) (ref null $type32) (ref $type77)) (result i32)))
  (type $environment135 (struct (field (ref $type139)) (field (ref $type35)) (field (ref null $type32))))
  (type $environment117 (struct (field (ref $type139)) (field (ref $type35)) (field (ref null $type32))))
  (type $call135 (func (param (ref $environment115) (ref $type35) (ref null $type32) (ref null $type32)) (result i32)))
  (type $call132 (func (param (ref $environment103) i64 (ref null $type30) (ref null $type30)) (result i32)))
  (type $115 (func (param i64 (ref $type12) i32 i32 i32 i64) (result (ref $type12))))
  (type $environment104 (struct (field (ref $type12))))
  (type $type132 (struct (field (ref $environment103))))
  (type $environment103 (struct (field i64) (field i64) (field i64) (field (ref $type12)) (field (ref $type134))))
  (type $type12 (array (mut i64)))
  (type $type134 (struct (field (mut i32)) (field (mut (ref null $type132)))))
  (type $call80 (func (param (ref $environment98) (ref null $type30)) (result (ref $type33))))
  (type $call126 (func (param (ref $environment95) (ref null $type30) i64) (result i64)))
  (type $type135 (struct (field (ref $environment115))))
  (type $environment115 (struct (field (ref $type80)) (field (ref $type80)) (field (ref $type139))))
  (type $type80 (struct (field (ref $environment98))))
  (type $environment98 (struct (field (ref null $type30)) (field i64) (field i64) (field i64)))
  (type $call85 (func (param (ref null $environment112) i64) (result (ref null $type30))))
  (type $environment112 (struct (field i64) (field (ref $type138))))
  (type $type126 (struct (field (ref $environment95))))
  (type $type139 (struct (field (mut i32)) (field (mut (ref null $type135)))))
  (type $type138 (struct (field (mut i32)) (field (mut (ref null $type85)))))
  (type $type128 (struct (field (mut i32)) (field (mut (ref null $type126)))))
  (type $environment95 (struct (field (ref $type128))))
  (type $call84 (func (param structref (ref null $type30) (ref null $type32)) (result (ref null $type32))))
  (type $type42 (sub $type39 (struct (field i32))))
  (type $call122 (func (param (ref struct) (ref null $type32) (ref null $type32)) (result (ref null $type32))))
  (type $environment85 (struct (field (ref $type84)) (field (ref $type124))))
  (type $type84 (struct (field (ref $call84)) (field structref)))
  (type $type41 (sub $type39 (struct (field i32) (field (ref $type35)))))
  (type $type40 (sub $type39 (struct (field i32) (field (ref null $type30)))))
  (type $type122 (struct (field (ref $call122)) (field (ref struct))))
  (type $type124 (struct (field (mut i32)) (field (mut (ref null $type122)))))
  (type $call38 (func (param (ref $environment79) i64) (result (ref $type39))))
  (type $call34 (func (param (ref null $environment88) (ref $type35)) (result i32)))
  (type $type37 (sub $type35 (struct (field (ref $type38)))))
  (type $type38 (struct (field (ref $environment79))))
  (type $environment79 (struct (field (ref $type121)) (field (ref null $type32)) (field (ref null $type32))))
  (type $environment88 (struct (field (ref null $type32)) (field (ref $type125))))
  (type $type119 (struct (field (ref $environment78))))
  (type $environment78 (struct (field (ref $type121))))
  (type $type125 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $type121 (struct (field (mut i32)) (field (mut (ref null $type119)))))
  (type $call77 (func (param structref (ref null $type32)) (result i32)))
  (type $type117 (struct (field (mut i32)) (field (mut (ref null $type72)))))
  (type $environment58 (struct (field (ref $type117))))
  (type $call72 (func (param structref i64) (result i32)))
  (type $call70 (func (param (ref null $type54) (ref null $type54)) (result i32)))
  (type $type51 (sub $type49 (struct (field (ref $type16)))))
  (type $type50 (sub $type49 (struct (field (ref null $type32)))))
  (type $call69 (func (param (ref $type49) (ref $type49)) (result i32)))
  (type $type32 (struct (field (ref null $type30)) (field (ref null $type32))))
  (type $162 (func (param (ref null $type32) (ref null $type32)) (result i32)))
  (type $type30 (struct (field i64) (field (ref null $type30))))
  (type $call67 (func (param (ref null $environment126) (ref null $type30) (ref null $type30)) (result i32)))
  (type $environment48 (struct (field i64) (field (ref $type115))))
  (type $type115 (struct (field (mut i32)) (field (mut (ref null $type60)))))
  (type $call60 (func (param structref i64 i64) (result i64)))
  (type $call61 (func (param structref i64) (result i32)))
  (type $type46 (sub $type44 (struct (field i64) (field (ref $type47)))))
  (type $call43 (func (param (ref null $environment242) (ref $type44)) (result i32)))
  (type $call33 (func (param structref i64) (result i64)))
  (type $172 (func (param (ref $type16) (ref $type16) i32 i32 i64) (result i32)))
  (type $call15 (func (param (ref null $environment305) i64) (result (ref $type16))))
  (type $type18 (array (mut (ref null $type17))))
  (type $175 (func (param i32) (result (ref $type16))))
  (type $type54 (struct (field (ref $type49)) (field (ref null $type54))))
  (type $type113 (struct))
  (type $type112 (struct))
  (type $type111 (struct (field (mut i64))))
  (type $type108 (struct))
  (type $type107 (struct))
  (type $type106 (struct))
  (type $type105 (struct))
  (type $type103 (struct (field (ref $call103)) (field (ref null $environment295))))
  (type $type102 (struct))
  (type $type101 (struct))
  (type $type92 (struct))
  (type $type89 (struct))
  (type $type95 (struct))
  (type $type90 (struct))
  (type $type86 (struct))
  (type $type85 (struct (field (ref $call85)) (field (ref null $environment112))))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct (field (ref $environment120))))
  (type $type79 (struct))
  (type $type78 (struct))
  (type $type77 (struct (field (ref $call77)) (field structref)))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type74 (struct))
  (type $type73 (struct))
  (type $type72 (struct (field (ref $call72)) (field structref)))
  (type $type71 (struct))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct (field (ref $call67)) (field (ref null $environment126))))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type60 (struct (field (ref $call60)) (field structref)))
  (type $type61 (struct (field (ref $call61)) (field structref)))
  (type $type59 (struct))
  (type $type58 (struct))
  (type $type56 (struct))
  (type $type55 (struct (field (ref $call55)) (field structref)))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type48 (struct))
  (type $type43 (struct (field (ref $call43)) (field (ref null $environment242))))
  (type $type34 (struct (field (ref $call34)) (field (ref null $environment88))))
  (type $type33 (struct (field (ref $call33)) (field structref)))
  (type $type31 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type15 (struct (field (ref $call15)) (field (ref null $environment305))))
  (type $type11 (struct))
  (type $type5 (struct))
  (type $type45 (sub $type44 (struct)))
  (type $type36 (sub $type35 (struct)))
  (type $type16 (struct (field i32) (field i32) (field (ref $type17)) (field (ref null $type18))))
  (type $type17 (array (mut i32)))
 )
 (type $236 (func (param i64) (result i64)))
 (type $237 (func (param i32)))
 (type $238 (func (param i32) (result i64)))
 (type $239 (func))
 (import "benchmark" "write_character" (func $foreign0 (param i32)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign2 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign3 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type16) (struct.new $type16
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type17 37
   (i32.const 103)
   (i32.const 101)
   (i32.const 110)
   (i32.const 45)
   (i32.const 112)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 115)
   (i32.const 58)
   (i32.const 32)
   (i32.const 66)
   (i32.const 97)
   (i32.const 100)
   (i32.const 32)
   (i32.const 109)
   (i32.const 115)
   (i32.const 103)
   (i32.const 58)
   (i32.const 32)
   (i32.const 126)
   (i32.const 97)
   (i32.const 59)
   (i32.const 32)
   (i32.const 109)
   (i32.const 101)
   (i32.const 115)
   (i32.const 115)
   (i32.const 97)
   (i32.const 103)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type16) (struct.new $type16
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type17 3
   (i32.const 46)
   (i32.const 46)
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $empty36 (ref $type36) (struct.new_default $type36))
 (global $empty45 (ref $type45) (struct.new_default $type45))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $global210 (mut (ref null $type11)) (ref.null none))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $global101 (mut (ref null $type28)) (ref.null none))
 (global $global201 (mut (ref null $type29)) (ref.null none))
 (global $global456 (mut (ref null $type31)) (ref.null none))
 (global $global106 (mut (ref null $type33)) (ref.null none))
 (global $global191 (mut (ref null $type34)) (ref.null none))
 (global $global108 (mut (ref null $type43)) (ref.null none))
 (global $global113 (mut (ref null $type48)) (ref.null none))
 (global $global347 (mut (ref null $type31)) (ref.null none))
 (global $global235 (mut (ref null $type52)) (ref.null none))
 (global $global466 (mut (ref null $type53)) (ref.null none))
 (global $global265 (mut (ref null $type55)) (ref.null none))
 (global $global301 (mut (ref null $type56)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (global $global311 (mut (ref null $type58)) (ref.null none))
 (global $ready311 (mut i32) (i32.const 0))
 (global $global324 (mut (ref null $type59)) (ref.null none))
 (global $ready324 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type61)) (ref.null none))
 (global $global363 (mut (ref null $type61)) (ref.null none))
 (global $global120 (mut (ref null $type61)) (ref.null none))
 (global $global122 (mut (ref null $type60)) (ref.null none))
 (global $global198 (mut (ref null $type62)) (ref.null none))
 (global $global275 (mut (ref null $type63)) (ref.null none))
 (global $global223 (mut (ref null $type63)) (ref.null none))
 (global $global128 (mut (ref null $type64)) (ref.null none))
 (global $global131 (mut (ref null $type65)) (ref.null none))
 (global $global133 (mut (ref null $type66)) (ref.null none))
 (global $global136 (mut (ref null $type67)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type68)) (ref.null none))
 (global $ready139 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type69)) (ref.null none))
 (global $global145 (mut (ref null $type70)) (ref.null none))
 (global $ready145 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type71)) (ref.null none))
 (global $global152 (mut (ref null $type72)) (ref.null none))
 (global $ready152 (mut i32) (i32.const 0))
 (global $global154 (mut (ref null $type73)) (ref.null none))
 (global $global555 (mut (ref null $type60)) (ref.null none))
 (global $global156 (mut (ref null $type60)) (ref.null none))
 (global $global163 (mut (ref null $type60)) (ref.null none))
 (global $global430 (mut (ref null $type74)) (ref.null none))
 (global $global443 (mut (ref null $type75)) (ref.null none))
 (global $global445 (mut (ref null $type76)) (ref.null none))
 (global $global170 (mut (ref null $type77)) (ref.null none))
 (global $global195 (mut (ref null $type78)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global225 (mut (ref null $type79)) (ref.null none))
 (global $ready225 (mut i32) (i32.const 0))
 (global $global243 (mut (ref null $type81)) (ref.null none))
 (global $ready243 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type82)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type83)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (global $global231 (mut (ref null $type85)) (ref.null none))
 (global $ready231 (mut i32) (i32.const 0))
 (global $global279 (mut (ref null $type86)) (ref.null none))
 (global $global404 (mut (ref null $type90)) (ref.null none))
 (global $global378 (mut (ref null $type95)) (ref.null none))
 (global $ready378 (mut i32) (i32.const 0))
 (global $global285 (mut (ref null $type89)) (ref.null none))
 (global $global329 (mut (ref null $type92)) (ref.null none))
 (global $global402 (mut (ref null $type101)) (ref.null none))
 (global $global427 (mut (ref null $type33)) (ref.null none))
 (global $global448 (mut (ref null $type33)) (ref.null none))
 (global $global471 (mut (ref null $type102)) (ref.null none))
 (global $global453 (mut (ref null $type103)) (ref.null none))
 (global $global468 (mut (ref null $type105)) (ref.null none))
 (global $global520 (mut (ref null $type106)) (ref.null none))
 (global $ready520 (mut i32) (i32.const 0))
 (global $global504 (mut (ref null $type107)) (ref.null none))
 (global $ready504 (mut i32) (i32.const 0))
 (global $global482 (mut (ref null $type108)) (ref.null none))
 (global $ready482 (mut i32) (i32.const 0))
 (global $global532 (mut (ref null $type111)) (ref.null none))
 (global $global533 (mut (ref null $type5)) (ref.null none))
 (global $ready533 (mut i32) (i32.const 0))
 (global $global548 (mut (ref null $type85)) (ref.null none))
 (global $ready548 (mut i32) (i32.const 0))
 (global $global546 (mut (ref null $type112)) (ref.null none))
 (global $ready546 (mut i32) (i32.const 0))
 (global $global544 (mut (ref null $type113)) (ref.null none))
 (global $ready544 (mut i32) (i32.const 0))
 (global $global535 (mut (ref null $type15)) (ref.null none))
 (global $ready535 (mut i32) (i32.const 0))
 (global $global540 (mut i64) (i64.const 0))
 (global $global541 (mut i64) (i64.const 0))
 (global $global542 (mut i32) (i32.const 0))
 (global $global543 (mut (ref null $type54)) (ref.null none))
 (global $global553 (mut (ref null $type33)) (ref.null none))
 (global $ready553 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $175) (param $0 i32) (result (ref $type16))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type18))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type18
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type18
      (local.get $5)
      (local.get $2)
      (array.new_default $type17
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type16
   (i32.const 1)
   (local.get $0)
   (array.new_default $type17
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $function25 (type $call15) (param $0 (ref null $environment305)) (param $1 i64) (result (ref $type16))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function40 (type $172) (param $0 (ref $type16)) (param $1 (ref $type16)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type17
       (if (result (ref $type17))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type16 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type18
           (struct.get $type16 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type16 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type17
        (if (result (ref $type17))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (if
   (i64.lt_s
    (i64.and
     (local.get $1)
     (local.tee $2
      (i64.sub
       (i64.const 0)
       (local.get $1)
      )
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.get $2)
 )
 (func $function42 (type $call43) (param $0 (ref null $environment242)) (param $1 (ref $type44)) (result i32)
  (if (result i32)
   (ref.test (ref $type45)
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.cast (ref $type46)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function44 (type $call61) (param $0 structref) (param $1 i64) (result i32)
  (i32.const 1)
 )
 (func $function45 (type $call61) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (i64.and
    (local.get $1)
    (i64.const 1)
   )
  )
 )
 (func $function46 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type115))
  (local $4 (ref $type60))
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (struct.set $type115 1
     (local.tee $3
      (struct.new_default $type115)
     )
     (struct.new $type60
      (ref.func $function48)
      (struct.new $environment48
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type115 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type115 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call60
     (struct.get $type60 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type115 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $2)
     (i64.const 1)
     (struct.get $type60 0
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function48 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.tee $1
       (struct.get $environment48 0
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $1)
        )
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type115 0
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type60 1
      (struct.get $type115 1
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function52 (type $call67) (param $0 (ref null $environment126)) (param $1 (ref null $type30)) (param $2 (ref null $type30)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.is_null
     (local.get $2)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type30 0
         (local.get $1)
        )
        (struct.get $type30 0
         (local.get $2)
        )
       )
       (then
        (local.set $1
         (struct.get $type30 1
          (local.get $1)
         )
        )
        (local.set $2
         (struct.get $type30 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready136)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function52
         (struct.get $type67 1
          (global.get $global136)
         )
         (local.get $1)
         (local.get $2)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function53 (type $162) (param $0 (ref null $type32)) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref null $type30))
  (local $3 (ref null $type30))
  (local $scratch (ref null $type32))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (struct.get $type67 1
        (global.get $global136)
       )
      )
      (local.set $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (if (result i32)
       (if (result i32)
        (ref.is_null
         (local.tee $3
          (struct.get $type32 0
           (local.get $0)
          )
         )
        )
        (then
         (ref.is_null
          (local.get $2)
         )
        )
        (else
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i64.eq
             (struct.get $type30 0
              (local.get $3)
             )
             (struct.get $type30 0
              (local.get $2)
             )
            )
            (then
             (local.set $3
              (struct.get $type30 1
               (local.get $3)
              )
             )
             (local.set $2
              (struct.get $type30 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready136)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (struct.get $type67 1
               (global.get $global136)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.is_null
                (local.get $2)
               )
              )
              (else
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i64.eq
                   (struct.get $type30 0
                    (local.get $3)
                   )
                   (struct.get $type30 0
                    (local.get $2)
                   )
                  )
                  (then
                   (local.set $3
                    (struct.get $type30 1
                     (local.get $3)
                    )
                   )
                   (local.set $2
                    (struct.get $type30 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready136)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (struct.get $type67 1
                     (global.get $global136)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (ref.is_null
                      (local.get $2)
                     )
                    )
                    (else
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if (result i32)
                        (i64.eq
                         (struct.get $type30 0
                          (local.get $3)
                         )
                         (struct.get $type30 0
                          (local.get $2)
                         )
                        )
                        (then
                         (local.set $3
                          (struct.get $type30 1
                           (local.get $3)
                          )
                         )
                         (local.set $2
                          (struct.get $type30 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready136)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (struct.get $type67 1
                           (global.get $global136)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.is_null
                            (local.get $2)
                           )
                          )
                          (else
                           (if (result i32)
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (i64.eq
                               (struct.get $type30 0
                                (local.get $3)
                               )
                               (struct.get $type30 0
                                (local.get $2)
                               )
                              )
                              (then
                               (local.set $3
                                (struct.get $type30 1
                                 (local.get $3)
                                )
                               )
                               (local.set $2
                                (struct.get $type30 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready136)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (struct.get $type67 1
                                 (global.get $global136)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                )
                                (else
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (if (result i32)
                                    (i64.eq
                                     (struct.get $type30 0
                                      (local.get $3)
                                     )
                                     (struct.get $type30 0
                                      (local.get $2)
                                     )
                                    )
                                    (then
                                     (local.set $3
                                      (struct.get $type30 1
                                       (local.get $3)
                                      )
                                     )
                                     (local.set $2
                                      (struct.get $type30 1
                                       (local.get $2)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready136)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (struct.get $type67 1
                                       (global.get $global136)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                      )
                                      (else
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (if (result i32)
                                          (i64.eq
                                           (struct.get $type30 0
                                            (local.get $3)
                                           )
                                           (struct.get $type30 0
                                            (local.get $2)
                                           )
                                          )
                                          (then
                                           (local.set $3
                                            (struct.get $type30 1
                                             (local.get $3)
                                            )
                                           )
                                           (local.set $2
                                            (struct.get $type30 1
                                             (local.get $2)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready136)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (struct.get $type67 1
                                             (global.get $global136)
                                            )
                                           )
                                           (if (result i32)
                                            (ref.is_null
                                             (local.get $3)
                                            )
                                            (then
                                             (ref.is_null
                                              (local.get $2)
                                             )
                                            )
                                            (else
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (i32.const 0)
                                              )
                                              (else
                                               (if (result i32)
                                                (i64.eq
                                                 (struct.get $type30 0
                                                  (local.get $3)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $2)
                                                 )
                                                )
                                                (then
                                                 (local.set $3
                                                  (struct.get $type30 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (local.set $2
                                                  (struct.get $type30 1
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready136)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (struct.get $type67 1
                                                   (global.get $global136)
                                                  )
                                                 )
                                                 (if (result i32)
                                                  (ref.is_null
                                                   (local.get $3)
                                                  )
                                                  (then
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (else
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                    (then
                                                     (i32.const 0)
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (i64.eq
                                                       (struct.get $type30 0
                                                        (local.get $3)
                                                       )
                                                       (struct.get $type30 0
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (then
                                                       (local.set $3
                                                        (struct.get $type30 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (local.set $2
                                                        (struct.get $type30 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready136)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (struct.get $type67 1
                                                         (global.get $global136)
                                                        )
                                                       )
                                                       (if (result i32)
                                                        (ref.is_null
                                                         (local.get $3)
                                                        )
                                                        (then
                                                         (ref.is_null
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (else
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                          (then
                                                           (i32.const 0)
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (i64.eq
                                                             (struct.get $type30 0
                                                              (local.get $3)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                            (then
                                                             (local.set $3
                                                              (struct.get $type30 1
                                                               (local.get $3)
                                                              )
                                                             )
                                                             (local.set $2
                                                              (struct.get $type30 1
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready136)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (struct.get $type67 1
                                                               (global.get $global136)
                                                              )
                                                             )
                                                             (if (result i32)
                                                              (ref.is_null
                                                               (local.get $3)
                                                              )
                                                              (then
                                                               (ref.is_null
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (else
                                                               (if (result i32)
                                                                (ref.is_null
                                                                 (local.get $2)
                                                                )
                                                                (then
                                                                 (i32.const 0)
                                                                )
                                                                (else
                                                                 (if (result i32)
                                                                  (i64.eq
                                                                   (struct.get $type30 0
                                                                    (local.get $3)
                                                                   )
                                                                   (struct.get $type30 0
                                                                    (local.get $2)
                                                                   )
                                                                  )
                                                                  (then
                                                                   (local.set $3
                                                                    (struct.get $type30 1
                                                                     (local.get $3)
                                                                    )
                                                                   )
                                                                   (local.set $2
                                                                    (struct.get $type30 1
                                                                     (local.get $2)
                                                                    )
                                                                   )
                                                                   (if
                                                                    (i32.eqz
                                                                     (global.get $ready136)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (drop
                                                                    (struct.get $type67 1
                                                                     (global.get $global136)
                                                                    )
                                                                   )
                                                                   (if (result i32)
                                                                    (ref.is_null
                                                                     (local.get $3)
                                                                    )
                                                                    (then
                                                                     (ref.is_null
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                    (else
                                                                     (if (result i32)
                                                                      (ref.is_null
                                                                       (local.get $2)
                                                                      )
                                                                      (then
                                                                       (i32.const 0)
                                                                      )
                                                                      (else
                                                                       (if (result i32)
                                                                        (i64.eq
                                                                         (struct.get $type30 0
                                                                          (local.get $3)
                                                                         )
                                                                         (struct.get $type30 0
                                                                          (local.get $2)
                                                                         )
                                                                        )
                                                                        (then
                                                                         (local.set $3
                                                                          (struct.get $type30 1
                                                                           (local.get $3)
                                                                          )
                                                                         )
                                                                         (local.set $2
                                                                          (struct.get $type30 1
                                                                           (local.get $2)
                                                                          )
                                                                         )
                                                                         (if
                                                                          (i32.eqz
                                                                           (global.get $ready136)
                                                                          )
                                                                          (then
                                                                           (unreachable)
                                                                          )
                                                                         )
                                                                         (drop
                                                                          (struct.get $type67 1
                                                                           (global.get $global136)
                                                                          )
                                                                         )
                                                                         (if (result i32)
                                                                          (ref.is_null
                                                                           (local.get $3)
                                                                          )
                                                                          (then
                                                                           (ref.is_null
                                                                            (local.get $2)
                                                                           )
                                                                          )
                                                                          (else
                                                                           (if (result i32)
                                                                            (ref.is_null
                                                                             (local.get $2)
                                                                            )
                                                                            (then
                                                                             (i32.const 0)
                                                                            )
                                                                            (else
                                                                             (if (result i32)
                                                                              (i64.eq
                                                                               (struct.get $type30 0
                                                                                (local.get $3)
                                                                               )
                                                                               (struct.get $type30 0
                                                                                (local.get $2)
                                                                               )
                                                                              )
                                                                              (then
                                                                               (local.set $3
                                                                                (struct.get $type30 1
                                                                                 (local.get $3)
                                                                                )
                                                                               )
                                                                               (local.set $2
                                                                                (struct.get $type30 1
                                                                                 (local.get $2)
                                                                                )
                                                                               )
                                                                               (if
                                                                                (i32.eqz
                                                                                 (global.get $ready136)
                                                                                )
                                                                                (then
                                                                                 (unreachable)
                                                                                )
                                                                               )
                                                                               (drop
                                                                                (struct.get $type67 1
                                                                                 (global.get $global136)
                                                                                )
                                                                               )
                                                                               (if (result i32)
                                                                                (ref.is_null
                                                                                 (local.get $3)
                                                                                )
                                                                                (then
                                                                                 (ref.is_null
                                                                                  (local.get $2)
                                                                                 )
                                                                                )
                                                                                (else
                                                                                 (if (result i32)
                                                                                  (ref.is_null
                                                                                   (local.get $2)
                                                                                  )
                                                                                  (then
                                                                                   (i32.const 0)
                                                                                  )
                                                                                  (else
                                                                                   (if (result i32)
                                                                                    (i64.eq
                                                                                     (struct.get $type30 0
                                                                                      (local.get $3)
                                                                                     )
                                                                                     (struct.get $type30 0
                                                                                      (local.get $2)
                                                                                     )
                                                                                    )
                                                                                    (then
                                                                                     (local.set $3
                                                                                      (struct.get $type30 1
                                                                                       (local.get $3)
                                                                                      )
                                                                                     )
                                                                                     (local.set $2
                                                                                      (struct.get $type30 1
                                                                                       (local.get $2)
                                                                                      )
                                                                                     )
                                                                                     (if
                                                                                      (i32.eqz
                                                                                       (global.get $ready136)
                                                                                      )
                                                                                      (then
                                                                                       (unreachable)
                                                                                      )
                                                                                     )
                                                                                     (drop
                                                                                      (struct.get $type67 1
                                                                                       (global.get $global136)
                                                                                      )
                                                                                     )
                                                                                     (if (result i32)
                                                                                      (ref.is_null
                                                                                       (local.get $3)
                                                                                      )
                                                                                      (then
                                                                                       (ref.is_null
                                                                                        (local.get $2)
                                                                                       )
                                                                                      )
                                                                                      (else
                                                                                       (if (result i32)
                                                                                        (ref.is_null
                                                                                         (local.get $2)
                                                                                        )
                                                                                        (then
                                                                                         (i32.const 0)
                                                                                        )
                                                                                        (else
                                                                                         (if (result i32)
                                                                                          (i64.eq
                                                                                           (struct.get $type30 0
                                                                                            (local.get $3)
                                                                                           )
                                                                                           (struct.get $type30 0
                                                                                            (local.get $2)
                                                                                           )
                                                                                          )
                                                                                          (then
                                                                                           (local.set $3
                                                                                            (struct.get $type30 1
                                                                                             (local.get $3)
                                                                                            )
                                                                                           )
                                                                                           (local.set $2
                                                                                            (struct.get $type30 1
                                                                                             (local.get $2)
                                                                                            )
                                                                                           )
                                                                                           (if
                                                                                            (i32.eqz
                                                                                             (global.get $ready136)
                                                                                            )
                                                                                            (then
                                                                                             (unreachable)
                                                                                            )
                                                                                           )
                                                                                           (drop
                                                                                            (struct.get $type67 1
                                                                                             (global.get $global136)
                                                                                            )
                                                                                           )
                                                                                           (if (result i32)
                                                                                            (ref.is_null
                                                                                             (local.get $3)
                                                                                            )
                                                                                            (then
                                                                                             (ref.is_null
                                                                                              (local.get $2)
                                                                                             )
                                                                                            )
                                                                                            (else
                                                                                             (if (result i32)
                                                                                              (ref.is_null
                                                                                               (local.get $2)
                                                                                              )
                                                                                              (then
                                                                                               (i32.const 0)
                                                                                              )
                                                                                              (else
                                                                                               (if (result i32)
                                                                                                (i64.eq
                                                                                                 (struct.get $type30 0
                                                                                                  (local.get $3)
                                                                                                 )
                                                                                                 (struct.get $type30 0
                                                                                                  (local.get $2)
                                                                                                 )
                                                                                                )
                                                                                                (then
                                                                                                 (local.set $3
                                                                                                  (struct.get $type30 1
                                                                                                   (local.get $3)
                                                                                                  )
                                                                                                 )
                                                                                                 (local.set $2
                                                                                                  (struct.get $type30 1
                                                                                                   (local.get $2)
                                                                                                  )
                                                                                                 )
                                                                                                 (if
                                                                                                  (i32.eqz
                                                                                                   (global.get $ready136)
                                                                                                  )
                                                                                                  (then
                                                                                                   (unreachable)
                                                                                                  )
                                                                                                 )
                                                                                                 (call $function52
                                                                                                  (struct.get $type67 1
                                                                                                   (global.get $global136)
                                                                                                  )
                                                                                                  (local.get $3)
                                                                                                  (local.get $2)
                                                                                                 )
                                                                                                )
                                                                                                (else
                                                                                                 (i32.const 0)
                                                                                                )
                                                                                               )
                                                                                              )
                                                                                             )
                                                                                            )
                                                                                           )
                                                                                          )
                                                                                          (else
                                                                                           (i32.const 0)
                                                                                          )
                                                                                         )
                                                                                        )
                                                                                       )
                                                                                      )
                                                                                     )
                                                                                    )
                                                                                    (else
                                                                                     (i32.const 0)
                                                                                    )
                                                                                   )
                                                                                  )
                                                                                 )
                                                                                )
                                                                               )
                                                                              )
                                                                              (else
                                                                               (i32.const 0)
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                        (else
                                                                         (i32.const 0)
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                  (else
                                                                   (i32.const 0)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (else
                                     (i32.const 0)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function53
         (struct.get $type32 1
          (local.get $0)
         )
         (block (result (ref null $type32))
          (local.set $scratch
           (struct.get $type32 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready139)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $call69) (param $0 (ref $type49)) (param $1 (ref $type49)) (result i32)
  (local $2 (ref $type16))
  (local $3 (ref $type16))
  (local $4 (ref null $type32))
  (drop
   (ref.as_non_null
    (global.get $global113)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type50)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type50)
       (local.get $0)
      )
     )
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type51)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type50)
       (local.get $1)
      )
      (then
       (drop
        (ref.cast (ref $type50)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type51)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (ref.test (ref $type50)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function53
       (struct.get $type50 0
        (ref.cast (ref $type50)
         (local.get $0)
        )
       )
       (block (result (ref null $type32))
        (if
         (i32.eqz
          (ref.test (ref $type50)
           (local.get $1)
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global139)
         )
        )
        (struct.get $type50 0
         (ref.cast (ref $type50)
          (local.get $1)
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type50)
       (local.get $1)
      )
      (then
       (drop
        (ref.cast (ref $type50)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type51)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (ref.test (ref $type50)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type51 0
        (ref.cast (ref $type51)
         (local.get $0)
        )
       )
      )
      (if
       (ref.test (ref $type50)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global101)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type16 1
          (local.get $2)
         )
        )
        (i64.extend_i32_u
         (struct.get $type16 1
          (local.tee $3
           (struct.get $type51 0
            (ref.cast (ref $type51)
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function40
         (local.get $2)
         (local.get $3)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function55 (type $call70) (param $0 (ref null $type54)) (param $1 (ref null $type54)) (result i32)
  (local $scratch (ref null $type54))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global142)
       )
      )
      (if (result i32)
       (call $function54
        (struct.get $type54 0
         (local.get $0)
        )
        (struct.get $type54 0
         (local.get $1)
        )
       )
       (then
        (return_call $function55
         (struct.get $type54 1
          (local.get $0)
         )
         (block (result (ref null $type54))
          (local.set $scratch
           (struct.get $type54 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready145)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global145)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function58 (type $call72) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type16))
  (drop
   (ref.cast (ref $environment58)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (i64.const 37)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $environment58)
      (local.get $0)
     )
    )
    (local.set $4
     (global.get $string0)
    )
    (if
     (i64.ge_u
      (local.get $1)
      (i64.const 37)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type17
      (if (result (ref $type17))
       (i32.lt_u
        (local.tee $3
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type16 2
         (local.get $4)
        )
       )
       (else
        (unreachable)
       )
      )
      (i32.and
       (local.get $3)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type117 0
       (struct.get $environment58 0
        (ref.cast (ref $environment58)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function58
     (struct.get $type72 1
      (struct.get $type117 1
       (struct.get $environment58 0
        (ref.cast (ref $environment58)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function59 (type $call72) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready152)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function59
      (struct.get $type72 1
       (global.get $global152)
      )
      (i64.div_s
       (local.get $1)
       (i64.const 10)
      )
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $1
       (i64.add
        (local.tee $2
         (i64.rem_s
          (local.get $1)
          (i64.const 10)
         )
        )
        (i64.const 48)
       )
      )
      (i64.const 48)
     )
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $1)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $1)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign0
   (i32.wrap_i64
    (local.get $1)
   )
  )
  (i32.const 0)
 )
 (func $function61 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (drop
   (struct.get $type61 1
    (global.get $global118)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i64.div_s
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
     (then
      (local.set $4
       (i64.mul
        (local.get $2)
        (local.tee $3
         (i64.div_s
          (local.get $1)
          (local.get $2)
         )
        )
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $4)
           (local.get $2)
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (local.get $4)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.get $2)
       )
       (then
        (local.get $3)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $3)
            (local.tee $1
             (i64.add
              (local.get $3)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $1)
       )
      )
     )
     (else
      (local.set $4
       (i64.mul
        (local.get $2)
        (local.tee $3
         (i64.div_s
          (local.get $1)
          (local.get $2)
         )
        )
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $4)
           (local.get $2)
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (local.get $4)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (local.get $3)
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $3)
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $3)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function68 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (drop
   (struct.get $type61 1
    (global.get $global118)
   )
  )
  (if (result i64)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i64.rem_s
     (local.get $1)
     (local.get $2)
    )
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
     (then
      (local.set $4
       (i64.mul
        (local.get $2)
        (local.tee $3
         (i64.div_s
          (local.get $1)
          (local.get $2)
         )
        )
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $4)
           (local.get $2)
          )
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $1)
            (local.get $4)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.get $3)
       )
       (then
        (i64.const 0)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $1
             (i64.sub
              (local.get $3)
              (local.get $2)
             )
            )
            (local.get $3)
           )
           (i64.xor
            (local.get $2)
            (local.get $3)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $1)
       )
      )
     )
     (else
      (local.set $3
       (i64.mul
        (local.get $2)
        (local.tee $4
         (i64.div_s
          (local.get $1)
          (local.get $2)
         )
        )
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 0)
       )
       (then
        (if
         (i64.ne
          (i64.div_s
           (local.get $3)
           (local.get $2)
          )
          (local.get $4)
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $4
           (i64.sub
            (local.get $1)
            (local.get $3)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.get $4)
       )
       (then
        (i64.const 0)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $4)
            (local.tee $1
             (i64.add
              (local.get $2)
              (local.get $4)
             )
            )
           )
           (i64.xor
            (local.get $1)
            (local.get $2)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $1)
       )
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $type121))
  (local $3 (ref $type125))
  (local $4 (ref $environment78))
  (local $5 (ref $type34))
  (if
   (i32.eqz
    (global.get $ready172)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global172)
   )
  )
  (struct.set $type121 1
   (local.tee $2
    (struct.new_default $type121)
   )
   (struct.new $type119
    (struct.new $environment78
     (local.get $2)
    )
   )
  )
  (struct.set $type121 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type121 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type119 0
    (struct.get $type121 1
     (local.get $2)
    )
   )
  )
  (struct.set $type125 1
   (local.tee $3
    (struct.new_default $type125)
   )
   (struct.new $type34
    (ref.func $function88)
    (struct.new $environment88
     (local.get $1)
     (local.get $3)
    )
   )
  )
  (struct.set $type125 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type125 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call34
   (struct.get $type34 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type125 1
       (local.get $3)
      )
     )
    )
   )
   (if (result (ref $type35))
    (ref.is_null
     (local.get $1)
    )
    (then
     (global.get $empty36)
    )
    (else
     (struct.new $type37
      (struct.new $type38
       (struct.new $environment79
        (struct.get $environment78 0
         (local.get $4)
        )
        (local.get $1)
        (ref.null none)
       )
      )
     )
    )
   )
   (struct.get $type34 0
    (local.get $5)
   )
  )
 )
 (func $function79 (type $call38) (param $0 (ref $environment79)) (param $1 i64) (result (ref $type39))
  (local $2 (ref null $type32))
  (local $3 (ref null $type32))
  (local $4 (ref null $type32))
  (local $5 (ref $type124))
  (local $6 (ref $type121))
  (local $7 (ref $type121))
  (local $8 (ref $type117))
  (local $9 (ref $environment78))
  (local $10 (ref $type122))
  (local $11 (ref null $type30))
  (local $12 (ref $type72))
  (local $13 i64)
  (local.set $2
   (struct.get $environment79 1
    (local.get $0)
   )
  )
  (if (result (ref $type39))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.new $type40
     (i32.const 0)
     (struct.get $type32 0
      (local.get $2)
     )
    )
   )
   (else
    (local.set $7
     (struct.get $environment79 0
      (local.get $0)
     )
    )
    (local.set $3
     (struct.get $environment79 2
      (local.get $0)
     )
    )
    (if (result (ref $type39))
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (local.set $4
       (struct.get $type32 1
        (local.get $2)
       )
      )
      (local.set $11
       (struct.get $type32 0
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type121 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (struct.get $type119 0
        (struct.get $type121 1
         (local.get $7)
        )
       )
      )
      (struct.new $type41
       (i32.const 1)
       (if (result (ref $type35))
        (ref.is_null
         (local.get $4)
        )
        (then
         (global.get $empty36)
        )
        (else
         (struct.new $type37
          (struct.new $type38
           (struct.new $environment79
            (struct.get $environment78 0
             (local.get $9)
            )
            (local.get $4)
            (struct.new $type32
             (local.get $11)
             (local.get $3)
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type39))
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (local.set $2
         (struct.get $type32 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready181)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global181)
         )
        )
        (struct.set $type124 1
         (local.tee $5
          (struct.new_default $type124)
         )
         (struct.new $type122
          (ref.func $function85)
          (struct.new $environment85
           (struct.new $type84
            (ref.func $primitive0)
            (ref.null none)
           )
           (local.get $5)
          )
         )
        )
        (struct.set $type124 0
         (local.get $5)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type124 0
           (local.get $5)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (call_ref $call122
          (struct.get $type122 1
           (local.tee $10
            (ref.as_non_null
             (struct.get $type124 1
              (local.get $5)
             )
            )
           )
          )
          (local.get $3)
          (local.get $2)
          (struct.get $type122 0
           (local.get $10)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready172)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global172)
         )
        )
        (struct.set $type121 1
         (local.tee $6
          (struct.new_default $type121)
         )
         (struct.new $type119
          (struct.new $environment78
           (local.get $6)
          )
         )
        )
        (struct.set $type121 0
         (local.get $6)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type121 0
           (local.get $6)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $9
         (struct.get $type119 0
          (struct.get $type121 1
           (local.get $6)
          )
         )
        )
        (struct.new $type41
         (i32.const 1)
         (if (result (ref $type35))
          (ref.is_null
           (local.get $2)
          )
          (then
           (global.get $empty36)
          )
          (else
           (struct.new $type37
            (struct.new $type38
             (struct.new $environment79
              (struct.get $environment78 0
               (local.get $9)
              )
              (local.get $2)
              (ref.null none)
             )
            )
           )
          )
         )
        )
       )
       (else
        (if (result (ref $type42))
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (drop
           (struct.get $type32 0
            (local.get $2)
           )
          )
          (local.set $2
           (struct.get $type32 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready181)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global181)
           )
          )
          (struct.set $type124 1
           (local.tee $5
            (struct.new_default $type124)
           )
           (struct.new $type122
            (ref.func $function85)
            (struct.new $environment85
             (struct.new $type84
              (ref.func $primitive0)
              (ref.null none)
             )
             (local.get $5)
            )
           )
          )
          (struct.set $type124 0
           (local.get $5)
           (i32.const 1)
          )
          (if
           (i32.eqz
            (struct.get $type124 0
             (local.get $5)
            )
           )
           (then
            (unreachable)
           )
          )
          (drop
           (call_ref $call122
            (struct.get $type122 1
             (local.tee $10
              (ref.as_non_null
               (struct.get $type124 1
                (local.get $5)
               )
              )
             )
            )
            (local.get $3)
            (local.get $2)
            (struct.get $type122 0
             (local.get $10)
            )
           )
          )
          (struct.new $type42
           (i32.const 2)
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global154)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global148)
           )
          )
          (struct.set $type117 1
           (local.tee $8
            (struct.new_default $type117)
           )
           (struct.new $type72
            (ref.func $function58)
            (struct.new $environment58
             (local.get $8)
            )
           )
          )
          (struct.set $type117 0
           (local.get $8)
           (i32.const 1)
          )
          (if
           (i32.eqz
            (struct.get $type117 0
             (local.get $8)
            )
           )
           (then
            (unreachable)
           )
          )
          (drop
           (call_ref $call72
            (struct.get $type72 1
             (local.tee $12
              (ref.as_non_null
               (struct.get $type117 1
                (local.get $8)
               )
              )
             )
            )
            (i64.const 0)
            (struct.get $type72 0
             (local.get $12)
            )
           )
          )
          (if
           (i64.lt_s
            (local.get $1)
            (i64.const 0)
           )
           (then
            (call $foreign0
             (i32.const 45)
            )
            (drop
             (struct.get $type33 1
              (global.get $global106)
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (local.get $1)
               (local.tee $13
                (i64.sub
                 (i64.const 0)
                 (local.get $1)
                )
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (local.get $13)
            )
           )
          )
          (drop
           (call $function59
            (struct.get $type72 1
             (global.get $global152)
            )
            (local.get $1)
           )
          )
          (call $foreign0
           (i32.const 10)
          )
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function85 (type $call122) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $environment85))
  (local $4 (ref null $type32))
  (local $5 (ref $type84))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (local.set $1
     (call_ref $call84
      (struct.get $type84 1
       (local.tee $5
        (struct.get $environment85 0
         (local.tee $3
          (ref.cast (ref $environment85)
           (local.get $0)
          )
         )
        )
       )
      )
      (struct.get $type32 0
       (local.get $1)
      )
      (local.get $2)
      (struct.get $type84 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type124 0
       (struct.get $environment85 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (struct.get $type122 1
      (struct.get $type124 1
       (struct.get $environment85 1
        (local.get $3)
       )
      )
     )
     (local.get $4)
     (local.get $1)
    )
   )
  )
 )
 (func $function88 (type $call34) (param $0 (ref null $environment88)) (param $1 (ref $type35)) (result i32)
  (local $2 (ref null $type30))
  (local $3 (ref null $type30))
  (local $4 (ref $environment95))
  (local $5 (ref $type39))
  (local $6 (ref $type128))
  (local $7 (ref $type138))
  (local $8 (ref $type139))
  (local $9 (ref null $type32))
  (local $10 (ref $type35))
  (local $11 (ref $type85))
  (local $12 i64)
  (local $scratch (ref null $type32))
  (drop
   (struct.get $type34 1
    (global.get $global191)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type36)
     (local.get $1)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type37)
       (local.get $1)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (local.set $9
     (struct.get $type32 1
      (block (result (ref null $type32))
       (local.set $scratch
        (struct.get $environment88 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready195)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global195)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global198)
        )
       )
       (if
        (ref.test (ref $type36)
         (local.get $1)
        )
        (then
         (unreachable)
        )
       )
       (if
        (struct.get $type39 0
         (local.tee $5
          (call $function79
           (struct.get $type38 0
            (struct.get $type37 0
             (ref.cast (ref $type37)
              (local.get $1)
             )
            )
           )
           (i64.const 0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global201)
        )
       )
       (local.set $3
        (struct.get $type40 1
         (ref.cast (ref $type40)
          (local.get $5)
         )
        )
       )
       (struct.set $type128 1
        (local.tee $6
         (struct.new_default $type128)
        )
        (struct.new $type126
         (struct.new $environment95
          (local.get $6)
         )
        )
       )
       (struct.set $type128 0
        (local.get $6)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type128 0
          (local.get $6)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type126 0
         (struct.get $type128 1
          (local.get $6)
         )
        )
       )
       (local.set $12
        (if (result i64)
         (ref.is_null
          (local.get $3)
         )
         (then
          (i64.const 0)
         )
         (else
          (local.set $2
           (struct.get $type30 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (struct.get $type128 0
             (struct.get $environment95 0
              (local.get $4)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $4
           (struct.get $type126 0
            (struct.get $type128 1
             (struct.get $environment95 0
              (local.get $4)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i64.const 1)
           )
           (else
            (local.set $2
             (struct.get $type30 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (struct.get $type128 0
               (struct.get $environment95 0
                (local.get $4)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $4
             (struct.get $type126 0
              (struct.get $type128 1
               (struct.get $environment95 0
                (local.get $4)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i64.const 2)
             )
             (else
              (local.set $2
               (struct.get $type30 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type128 0
                 (struct.get $environment95 0
                  (local.get $4)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $4
               (struct.get $type126 0
                (struct.get $type128 1
                 (struct.get $environment95 0
                  (local.get $4)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i64.const 3)
               )
               (else
                (local.set $2
                 (struct.get $type30 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type128 0
                   (struct.get $environment95 0
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $4
                 (struct.get $type126 0
                  (struct.get $type128 1
                   (struct.get $environment95 0
                    (local.get $4)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i64.const 4)
                 )
                 (else
                  (local.set $2
                   (struct.get $type30 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type128 0
                     (struct.get $environment95 0
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $4
                   (struct.get $type126 0
                    (struct.get $type128 1
                     (struct.get $environment95 0
                      (local.get $4)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i64.const 5)
                   )
                   (else
                    (local.set $2
                     (struct.get $type30 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type128 0
                       (struct.get $environment95 0
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $4
                     (struct.get $type126 0
                      (struct.get $type128 1
                       (struct.get $environment95 0
                        (local.get $4)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (i64.const 6)
                     )
                     (else
                      (local.set $2
                       (struct.get $type30 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type128 0
                         (struct.get $environment95 0
                          (local.get $4)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $4
                       (struct.get $type126 0
                        (struct.get $type128 1
                         (struct.get $environment95 0
                          (local.get $4)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i64.const 7)
                       )
                       (else
                        (local.set $2
                         (struct.get $type30 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type128 0
                           (struct.get $environment95 0
                            (local.get $4)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $4
                         (struct.get $type126 0
                          (struct.get $type128 1
                           (struct.get $environment95 0
                            (local.get $4)
                           )
                          )
                         )
                        )
                        (if (result i64)
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (i64.const 8)
                         )
                         (else
                          (local.set $2
                           (struct.get $type30 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type128 0
                             (struct.get $environment95 0
                              (local.get $4)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $4
                           (struct.get $type126 0
                            (struct.get $type128 1
                             (struct.get $environment95 0
                              (local.get $4)
                             )
                            )
                           )
                          )
                          (if (result i64)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i64.const 9)
                           )
                           (else
                            (local.set $2
                             (struct.get $type30 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (struct.get $type128 0
                               (struct.get $environment95 0
                                (local.get $4)
                               )
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (local.set $4
                             (struct.get $type126 0
                              (struct.get $type128 1
                               (struct.get $environment95 0
                                (local.get $4)
                               )
                              )
                             )
                            )
                            (if (result i64)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i64.const 10)
                             )
                             (else
                              (local.set $2
                               (struct.get $type30 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type128 0
                                 (struct.get $environment95 0
                                  (local.get $4)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $4
                               (struct.get $type126 0
                                (struct.get $type128 1
                                 (struct.get $environment95 0
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                              (if (result i64)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i64.const 11)
                               )
                               (else
                                (local.set $2
                                 (struct.get $type30 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (struct.get $type128 0
                                   (struct.get $environment95 0
                                    (local.get $4)
                                   )
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (local.set $4
                                 (struct.get $type126 0
                                  (struct.get $type128 1
                                   (struct.get $environment95 0
                                    (local.get $4)
                                   )
                                  )
                                 )
                                )
                                (if (result i64)
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                 (then
                                  (i64.const 12)
                                 )
                                 (else
                                  (local.set $2
                                   (struct.get $type30 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (struct.get $type128 0
                                     (struct.get $environment95 0
                                      (local.get $4)
                                     )
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $function95
                                   (struct.get $type126 0
                                    (struct.get $type128 1
                                     (struct.get $environment95 0
                                      (local.get $4)
                                     )
                                    )
                                   )
                                   (local.get $2)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global223)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (ref.test (ref $type36)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type39 0
       (local.tee $5
        (call $function79
         (struct.get $type38 0
          (struct.get $type37 0
           (ref.cast (ref $type37)
            (local.get $1)
           )
          )
         )
         (i64.const 2)
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (struct.get $type41 1
      (ref.cast (ref $type41)
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready225)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global225)
     )
    )
    (if
     (i32.eqz
      (global.get $ready231)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type85 1
      (global.get $global231)
     )
    )
    (struct.set $type138 1
     (local.tee $7
      (struct.new_default $type138)
     )
     (struct.new $type85
      (ref.func $function112)
      (struct.new $environment112
       (local.get $12)
       (local.get $7)
      )
     )
    )
    (struct.set $type138 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type138 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call85
      (struct.get $type85 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type138 1
          (local.get $7)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type85 0
       (local.get $11)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (struct.set $type139 1
     (local.tee $8
      (struct.new_default $type139)
     )
     (struct.new $type135
      (struct.new $environment115
       (struct.new $type80
        (struct.new $environment98
         (local.get $3)
         (local.get $12)
         (i64.const 1)
         (i64.const -1)
        )
       )
       (struct.new $type80
        (struct.new $environment98
         (local.get $3)
         (local.get $12)
         (i64.const -1)
         (i64.const 1)
        )
       )
       (local.get $8)
      )
     )
    )
    (struct.set $type139 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type139 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function115
      (struct.get $type135 0
       (struct.get $type139 1
        (local.get $8)
       )
      )
      (local.get $10)
      (local.get $9)
      (struct.new $type32
       (local.get $2)
       (ref.null none)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global275)
       )
      )
      (if
       (ref.test (ref $type36)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type39 0
         (local.tee $5
          (call $function79
           (struct.get $type38 0
            (struct.get $type37 0
             (ref.cast (ref $type37)
              (local.get $1)
             )
            )
           )
           (i64.const 1)
          )
         )
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type41 1
        (ref.cast (ref $type41)
         (local.get $5)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type125 0
         (struct.get $environment88 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function88
       (struct.get $type34 1
        (struct.get $type125 1
         (struct.get $environment88 1
          (local.get $0)
         )
        )
       )
       (local.get $1)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 1)
   )
  )
 )
 (func $function89 (type $call34) (param $0 (ref null $environment88)) (param $1 (ref $type35)) (result i32)
  (if (result i32)
   (ref.test (ref $type36)
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $type37)
      (local.get $1)
     )
    )
    (i32.const 1)
   )
  )
 )
 (func $function95 (type $call126) (param $0 (ref $environment95)) (param $1 (ref null $type30)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type30 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type128 0
       (struct.get $environment95 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function95
     (struct.get $type126 0
      (struct.get $type128 1
       (struct.get $environment95 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function98 (type $call80) (param $0 (ref $environment98)) (param $1 (ref null $type30)) (result (ref $type33))
  (local $2 i64)
  (local $3 (ref $type134))
  (local $4 (ref $type12))
  (drop
   (ref.as_non_null
    (global.get $global210)
   )
  )
  (struct.set $type134 1
   (local.tee $3
    (struct.new_default $type134)
   )
   (struct.new $type132
    (struct.new $environment103
     (local.tee $2
      (struct.get $environment98 1
       (local.get $0)
      )
     )
     (struct.get $environment98 2
      (local.get $0)
     )
     (struct.get $environment98 3
      (local.get $0)
     )
     (local.tee $4
      (if (result (ref $type12))
       (i32.or
        (i64.lt_s
         (local.get $2)
         (i64.const 0)
        )
        (i64.gt_s
         (local.get $2)
         (i64.const 4294967295)
        )
       )
       (then
        (unreachable)
       )
       (else
        (if (result (ref $type12))
         (i64.eqz
          (local.get $2)
         )
         (then
          (array.new_fixed $type12 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global55)
           )
          )
          (if
           (i64.gt_u
            (local.get $2)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (call $function100
           (local.get $2)
           (array.new_default $type12
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (i32.const 1)
           (i32.const 0)
           (i32.const 1)
           (i64.const 1)
          )
         )
        )
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type134 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type134 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function103
    (struct.get $type132 0
     (struct.get $type134 1
      (local.get $3)
     )
    )
    (i64.const 0)
    (struct.get $environment98 0
     (local.get $0)
    )
    (local.get $1)
   )
  )
  (struct.new $type33
   (ref.func $function104)
   (struct.new $environment104
    (local.get $4)
   )
  )
 )
 (func $function100 (type $115) (param $0 i64) (param $1 (ref $type12)) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type12))
  (local $6 i64)
  (if (result (ref $type12))
   (i64.eq
    (local.get $0)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
     (i64.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function100
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function103 (type $call132) (param $0 (ref $environment103)) (param $1 i64) (param $2 (ref null $type30)) (param $3 (ref null $type30)) (result i32)
  (local $4 i64)
  (if (result i32)
   (i64.eq
    (struct.get $environment103 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $4
     (select
      (struct.get $environment103 1
       (local.get $0)
      )
      (struct.get $environment103 2
       (local.get $0)
      )
      (i64.eq
       (struct.get $type30 0
        (local.get $2)
       )
       (struct.get $type30 0
        (local.get $3)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment103 3
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type30 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.get $type30 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (struct.get $type134 0
       (struct.get $environment103 4
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function103
     (struct.get $type132 0
      (struct.get $type134 1
       (struct.get $environment103 4
        (local.get $0)
       )
      )
     )
     (local.get $4)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function104 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type12
   (struct.get $environment104 0
    (ref.cast (ref $environment104)
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function110 (type $call85) (param $0 (ref null $environment112)) (param $1 i64) (result (ref null $type30))
  (local $2 (ref $type138))
  (local $3 (ref $type85))
  (struct.set $type138 1
   (local.tee $2
    (struct.new_default $type138)
   )
   (struct.new $type85
    (ref.func $function112)
    (struct.new $environment112
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type138 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type138 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call85
   (struct.get $type85 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type138 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type85 0
    (local.get $3)
   )
  )
 )
 (func $function112 (type $call85) (param $0 (ref null $environment112)) (param $1 i64) (result (ref null $type30))
  (local $2 i64)
  (if (result (ref null $type30))
   (i64.eq
    (struct.get $environment112 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type138 0
       (struct.get $environment112 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (local.get $1)
     (call $function112
      (struct.get $type85 1
       (struct.get $type138 1
        (struct.get $environment112 1
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function115 (type $call135) (param $0 (ref $environment115)) (param $1 (ref $type35)) (param $2 (ref null $type32)) (param $3 (ref null $type32)) (result i32)
  (local $4 (ref $type39))
  (local $5 (ref null $type30))
  (local $6 (ref $type33))
  (local $7 (ref $type139))
  (local $8 i32)
  (drop
   (struct.get $type34 1
    (global.get $global191)
   )
  )
  (if (result i32)
   (local.tee $8
    (i32.eqz
     (if (result i32)
      (ref.test (ref $type36)
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type37)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
   )
   (then
    (local.get $8)
   )
   (else
    (local.set $5
     (struct.get $type32 0
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global198)
     )
    )
    (if
     (ref.test (ref $type36)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (struct.get $type39 0
      (local.tee $4
       (call $function79
        (struct.get $type38 0
         (struct.get $type37 0
          (ref.cast (ref $type37)
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $function98
      (struct.get $type80 0
       (struct.get $environment115 0
        (local.get $0)
       )
      )
      (struct.get $type40 1
       (ref.cast (ref $type40)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready243)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function120
      (struct.get $type81 0
       (global.get $global243)
      )
      (local.get $5)
      (local.get $6)
      (local.get $3)
      (struct.new $type77
       (ref.func $function117)
       (struct.new $environment117
        (local.tee $7
         (struct.get $environment115 2
          (local.get $0)
         )
        )
        (local.get $1)
        (local.get $2)
       )
      )
     )
     (then
      (local.set $5
       (struct.get $type32 0
        (local.get $2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global198)
       )
      )
      (if
       (ref.test (ref $type36)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (struct.get $type39 0
        (local.tee $4
         (call $function79
          (struct.get $type38 0
           (struct.get $type37 0
            (ref.cast (ref $type37)
             (local.get $1)
            )
           )
          )
          (i64.const 0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (call $function98
        (struct.get $type80 0
         (struct.get $environment115 1
          (local.get $0)
         )
        )
        (struct.get $type40 1
         (ref.cast (ref $type40)
          (local.get $4)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready243)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (call $function120
        (struct.get $type81 0
         (global.get $global243)
        )
        (local.get $5)
        (local.get $6)
        (local.get $3)
        (struct.new $type77
         (ref.func $function135)
         (struct.new $environment135
          (local.get $7)
          (local.get $1)
          (local.get $2)
         )
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global275)
         )
        )
        (if
         (ref.test (ref $type36)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.ne
          (struct.get $type39 0
           (local.tee $4
            (call $function79
             (struct.get $type38 0
              (struct.get $type37 0
               (ref.cast (ref $type37)
                (local.get $1)
               )
              )
             )
             (i64.const 1)
            )
           )
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (struct.get $type34 1
          (global.get $global191)
         )
        )
        (if (result i32)
         (local.tee $8
          (i32.eqz
           (if (result i32)
            (ref.test (ref $type36)
             (local.tee $1
              (struct.get $type41 1
               (ref.cast (ref $type41)
                (local.get $4)
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type37)
               (local.get $1)
              )
             )
             (i32.const 1)
            )
           )
          )
         )
         (then
          (local.get $8)
         )
         (else
          (if
           (i32.eqz
            (struct.get $type139 0
             (local.get $7)
            )
           )
           (then
            (unreachable)
           )
          )
          (return_call $function115
           (struct.get $type135 0
            (struct.get $type139 1
             (local.get $7)
            )
           )
           (local.get $1)
           (local.get $2)
           (local.get $3)
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function117 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $environment117))
  (local $3 (ref $type35))
  (local $4 (ref $type39))
  (local $5 (ref null $type32))
  (drop
   (ref.as_non_null
    (global.get $global223)
   )
  )
  (if
   (ref.test (ref $type36)
    (local.tee $3
     (struct.get $environment117 1
      (local.tee $2
       (ref.cast (ref $environment117)
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type39 0
     (local.tee $4
      (call $function79
       (struct.get $type38 0
        (struct.get $type37 0
         (ref.cast (ref $type37)
          (local.get $3)
         )
        )
       )
       (i64.const 2)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type41 1
    (ref.cast (ref $type41)
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type32 1
    (struct.get $environment117 2
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type139 0
     (struct.get $environment117 0
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function115
   (struct.get $type135 0
    (struct.get $type139 1
     (struct.get $environment117 0
      (local.get $2)
     )
    )
   )
   (local.get $3)
   (local.get $5)
   (local.get $1)
  )
 )
 (func $function118 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type32
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function120 (type $110) (param $0 (ref $environment120)) (param $1 (ref null $type30)) (param $2 (ref $type33)) (param $3 (ref null $type32)) (param $4 (ref $type77)) (result i32)
  (local $5 (ref $type144))
  (local $6 (ref $type147))
  (local $7 (ref $environment122))
  (local $8 (ref null $type30))
  (struct.set $type144 1
   (local.tee $5
    (struct.new_default $type144)
   )
   (struct.new $type142
    (struct.new $environment122
     (struct.get $environment120 0
      (local.get $0)
     )
     (local.get $2)
     (local.get $4)
     (local.get $5)
    )
   )
  )
  (struct.set $type144 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type144 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (struct.get $type32 0
    (local.get $3)
   )
  )
  (struct.set $type147 1
   (local.tee $6
    (struct.new_default $type147)
   )
   (struct.new $type145
    (struct.new $environment124
     (struct.get $environment122 0
      (local.tee $7
       (struct.get $type142 0
        (struct.get $type144 1
         (local.get $5)
        )
       )
      )
     )
     (struct.get $environment122 1
      (local.get $7)
     )
     (struct.get $environment122 2
      (local.get $7)
     )
     (struct.get $environment122 3
      (local.get $7)
     )
     (local.get $3)
     (ref.null none)
     (local.get $6)
    )
   )
  )
  (struct.set $type147 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type147 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function124
   (struct.get $type145 0
    (struct.get $type147 1
     (local.get $6)
    )
   )
   (local.get $8)
   (local.get $1)
   (ref.null none)
   (ref.null none)
  )
 )
 (func $function124 (type $call145) (param $0 (ref $environment124)) (param $1 (ref null $type30)) (param $2 (ref null $type30)) (param $3 (ref null $type30)) (param $4 (ref null $type30)) (result i32)
  (local $5 (ref $type149))
  (local $6 (ref $type147))
  (local $7 (ref $type67))
  (local $8 (ref $type33))
  (local $9 i64)
  (local $10 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.set $type149 1
     (local.tee $5
      (struct.new_default $type149)
     )
     (struct.new $type67
      (ref.func $function126)
      (struct.new $environment126
       (struct.get $environment124 0
        (local.get $0)
       )
       (struct.get $environment124 2
        (local.get $0)
       )
       (struct.get $environment124 3
        (local.get $0)
       )
       (struct.get $environment124 4
        (local.get $0)
       )
       (struct.get $environment124 5
        (local.get $0)
       )
       (local.get $3)
       (local.get $4)
       (local.get $5)
      )
     )
    )
    (struct.set $type149 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type149 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call67
     (struct.get $type67 1
      (local.tee $7
       (ref.as_non_null
        (struct.get $type149 1
         (local.get $5)
        )
       )
      )
     )
     (local.get $2)
     (local.get $4)
     (struct.get $type67 0
      (local.get $7)
     )
    )
   )
   (else
    (local.set $6
     (struct.get $environment124 6
      (local.get $0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.tee $10
       (call_ref $call33
        (struct.get $type33 1
         (local.tee $8
          (struct.get $environment124 1
           (local.get $0)
          )
         )
        )
        (local.tee $9
         (struct.get $type30 0
          (local.get $1)
         )
        )
        (struct.get $type33 0
         (local.get $8)
        )
       )
      )
      (i64.const 1)
     )
     (then
      (if (result i32)
       (i64.eq
        (struct.get $type30 0
         (local.get $2)
        )
        (i64.const 1)
       )
       (then
        (local.set $1
         (struct.get $type30 1
          (local.get $1)
         )
        )
        (local.set $2
         (struct.get $type30 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (struct.get $type147 0
           (local.get $6)
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function124
         (struct.get $type145 0
          (struct.get $type147 1
           (local.get $6)
          )
         )
         (local.get $1)
         (local.get $2)
         (struct.new $type30
          (local.get $9)
          (local.get $3)
         )
         (local.get $4)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $10)
        (i64.const -1)
       )
       (then
        (local.set $1
         (struct.get $type30 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type147 0
           (local.get $6)
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function124
         (struct.get $type145 0
          (struct.get $type147 1
           (local.get $6)
          )
         )
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (struct.new $type30
          (local.get $9)
          (local.get $4)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
   )
  )
 )
 (func $function126 (type $call67) (param $0 (ref null $environment126)) (param $1 (ref null $type30)) (param $2 (ref null $type30)) (result i32)
  (local $3 (ref null $type32))
  (local $4 (ref null $type32))
  (local $5 (ref $type124))
  (local $6 (ref $type147))
  (local $7 (ref $environment122))
  (local $8 (ref $type84))
  (local $9 (ref $type77))
  (local $10 (ref $type144))
  (local $11 (ref $type149))
  (local $12 (ref $call84))
  (local $13 (ref $type122))
  (local $14 i32)
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.set $2
     (struct.get $environment126 6
      (local.get $0)
     )
    )
    (local.set $3
     (call_ref $call84
      (struct.get $type84 1
       (local.tee $8
        (struct.get $environment126 0
         (local.get $0)
        )
       )
      )
      (struct.get $environment126 5
       (local.get $0)
      )
      (struct.get $environment126 4
       (local.get $0)
      )
      (local.tee $12
       (struct.get $type84 0
        (local.get $8)
       )
      )
     )
    )
    (local.set $3
     (call_ref $call84
      (struct.get $type84 1
       (local.get $8)
      )
      (local.get $2)
      (local.get $3)
      (local.get $12)
     )
    )
    (local.set $9
     (struct.get $environment126 1
      (local.get $0)
     )
    )
    (local.set $10
     (struct.get $environment126 2
      (local.get $0)
     )
    )
    (if
     (ref.is_null
      (local.tee $4
       (struct.get $type32 1
        (struct.get $environment126 3
         (local.get $0)
        )
       )
      )
     )
     (then
      (drop
       (struct.get $type55 1
        (global.get $global265)
       )
      )
      (struct.set $type124 1
       (local.tee $5
        (struct.new_default $type124)
       )
       (struct.new $type122
        (ref.func $function130)
        (struct.new $environment130
         (local.get $5)
        )
       )
      )
      (struct.set $type124 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type124 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call77
       (struct.get $type77 1
        (local.get $9)
       )
       (call_ref $call122
        (struct.get $type122 1
         (local.tee $13
          (ref.as_non_null
           (struct.get $type124 1
            (local.get $5)
           )
          )
         )
        )
        (local.get $3)
        (ref.null none)
        (struct.get $type122 0
         (local.get $13)
        )
       )
       (struct.get $type77 0
        (local.get $9)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (struct.get $type144 0
         (local.get $10)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type32 0
        (local.get $4)
       )
      )
      (struct.set $type147 1
       (local.tee $6
        (struct.new_default $type147)
       )
       (struct.new $type145
        (struct.new $environment124
         (struct.get $environment122 0
          (local.tee $7
           (struct.get $type142 0
            (struct.get $type144 1
             (local.get $10)
            )
           )
          )
         )
         (struct.get $environment122 1
          (local.get $7)
         )
         (struct.get $environment122 2
          (local.get $7)
         )
         (struct.get $environment122 3
          (local.get $7)
         )
         (local.get $4)
         (local.get $3)
         (local.get $6)
        )
       )
      )
      (struct.set $type147 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type147 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function124
       (struct.get $type145 0
        (struct.get $type147 1
         (local.get $6)
        )
       )
       (local.get $2)
       (local.get $1)
       (ref.null none)
       (ref.null none)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.set $11
     (struct.get $environment126 7
      (local.get $0)
     )
    )
    (if (result i32)
     (local.tee $14
      (i64.eq
       (struct.get $type30 0
        (local.get $1)
       )
       (i64.const 1)
      )
     )
     (then
      (local.get $14)
     )
     (else
      (local.set $1
       (struct.get $type30 1
        (local.get $1)
       )
      )
      (local.set $2
       (struct.get $type30 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type149 0
         (local.get $11)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function126
       (struct.get $type67 1
        (struct.get $type149 1
         (local.get $11)
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function128 (type $call55) (param $0 structref) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref $type124))
  (local $3 (ref $type122))
  (struct.set $type124 1
   (local.tee $2
    (struct.new_default $type124)
   )
   (struct.new $type122
    (ref.func $function130)
    (struct.new $environment130
     (local.get $2)
    )
   )
  )
  (struct.set $type124 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type124 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call122
   (struct.get $type122 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type124 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $1)
   (ref.null none)
   (struct.get $type122 0
    (local.get $3)
   )
  )
 )
 (func $function130 (type $call122) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref null $type32))
  (local $4 (ref null $type30))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type32 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type124 0
       (struct.get $environment130 0
        (ref.cast (ref $environment130)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function130
     (struct.get $type122 1
      (struct.get $type124 1
       (struct.get $environment130 0
        (ref.cast (ref $environment130)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (struct.new $type32
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function135 (type $call77) (param $0 structref) (param $1 (ref null $type32)) (result i32)
  (local $2 (ref $environment135))
  (local $3 (ref $type35))
  (local $4 (ref $type39))
  (local $5 (ref null $type32))
  (drop
   (ref.as_non_null
    (global.get $global223)
   )
  )
  (if
   (ref.test (ref $type36)
    (local.tee $3
     (struct.get $environment135 1
      (local.tee $2
       (ref.cast (ref $environment135)
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type39 0
     (local.tee $4
      (call $function79
       (struct.get $type38 0
        (struct.get $type37 0
         (ref.cast (ref $type37)
          (local.get $3)
         )
        )
       )
       (i64.const 2)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type41 1
    (ref.cast (ref $type41)
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type32 1
    (struct.get $environment135 2
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type139 0
     (struct.get $environment135 0
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function115
   (struct.get $type135 0
    (struct.get $type139 1
     (struct.get $environment135 0
      (local.get $2)
     )
    )
   )
   (local.get $3)
   (local.get $5)
   (local.get $1)
  )
 )
 (func $function142 (type $call72) (param $0 structref) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $environment142))
  (local $4 (ref $type12))
  (local $5 (ref $type33))
  (if (result i32)
   (i64.eq
    (struct.get $environment142 0
     (ref.cast (ref $environment142)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $environment142 2
      (local.tee $3
       (ref.cast (ref $environment142)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (local.set $2
       (call_ref $call33
        (struct.get $type33 1
         (local.tee $5
          (struct.get $environment142 1
           (local.get $3)
          )
         )
        )
        (local.get $1)
        (struct.get $type33 0
         (local.get $5)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type117 0
       (struct.get $environment142 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function142
     (struct.get $type72 1
      (struct.get $type117 1
       (struct.get $environment142 3
        (local.get $3)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function144 (type $call55) (param $0 structref) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref $type152))
  (local $3 (ref $environment144))
  (local $4 (ref $type55))
  (struct.set $type152 1
   (local.tee $2
    (struct.new_default $type152)
   )
   (struct.new $type55
    (ref.func $function146)
    (struct.new $environment146
     (struct.get $environment144 0
      (local.tee $3
       (ref.cast (ref $environment144)
        (local.get $0)
       )
      )
     )
     (struct.get $environment144 1
      (local.get $3)
     )
     (struct.get $environment144 2
      (local.get $3)
     )
     (struct.get $environment144 3
      (local.get $3)
     )
     (struct.get $environment144 4
      (local.get $3)
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type152 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type152 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call55
   (struct.get $type55 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type152 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $1)
   (struct.get $type55 0
    (local.get $4)
   )
  )
 )
 (func $function146 (type $call55) (param $0 structref) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref $environment146))
  (local $3 (ref $type124))
  (local $4 (ref $type122))
  (local $5 i32)
  (if (result nullref)
   (if (result i32)
    (local.tee $5
     (ref.is_null
      (local.get $1)
     )
    )
    (then
     (local.get $5)
    )
    (else
     (ref.is_null
      (struct.get $type32 0
       (local.get $1)
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (struct.set $type124 1
     (local.tee $3
      (struct.new_default $type124)
     )
     (struct.new $type122
      (ref.func $function149)
      (struct.new $environment149
       (struct.get $environment146 0
        (local.tee $2
         (ref.cast (ref $environment146)
          (local.get $0)
         )
        )
       )
       (struct.get $environment146 1
        (local.get $2)
       )
       (struct.get $environment146 2
        (local.get $2)
       )
       (struct.get $environment146 3
        (local.get $2)
       )
       (struct.get $environment146 4
        (local.get $2)
       )
       (struct.get $environment146 5
        (local.get $2)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type124 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type124 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call122
     (struct.get $type122 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type124 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $1)
     (ref.null none)
     (struct.get $type122 0
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function149 (type $call122) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref null $type30))
  (local $4 (ref null $type30))
  (local $5 (ref $type33))
  (local $6 (ref $type33))
  (local $7 (ref $type33))
  (local $8 (ref null $type32))
  (local $9 (ref $environment149))
  (local $10 (ref $type57))
  (local $11 (ref $type124))
  (local $12 (ref $type124))
  (local $13 (ref $type30))
  (local $14 (ref $type61))
  (local $15 (ref $type60))
  (local $16 (ref $type60))
  (local $17 (ref $type122))
  (local $18 (ref $type152))
  (local $19 i64)
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type152 0
       (struct.get $environment149 5
        (local.tee $9
         (ref.cast (ref $environment149)
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $function146
      (struct.get $type55 1
       (struct.get $type152 1
        (struct.get $environment149 5
         (local.get $9)
        )
       )
      )
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global301)
     )
    )
    (if (result (ref null $type32))
     (ref.is_null
      (local.get $1)
     )
     (then
      (ref.null none)
     )
     (else
      (local.set $2
       (struct.get $type32 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready301)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global301)
       )
      )
      (local.set $10
       (struct.new $type57
        (ref.func $function150)
        (struct.new_default $environment150)
       )
      )
      (struct.new $type32
       (struct.new $type30
        (i64.const 0)
        (struct.get $type32 0
         (local.get $1)
        )
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $2)
        )
        (then
         (ref.null none)
        )
        (else
         (local.set $1
          (struct.get $type32 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready301)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global301)
          )
         )
         (struct.new $type32
          (struct.new $type30
           (i64.const 0)
           (struct.get $type32 0
            (local.get $2)
           )
          )
          (if (result (ref null $type32))
           (ref.is_null
            (local.get $1)
           )
           (then
            (ref.null none)
           )
           (else
            (local.set $2
             (struct.get $type32 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (global.get $ready301)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global301)
             )
            )
            (struct.new $type32
             (struct.new $type30
              (i64.const 0)
              (struct.get $type32 0
               (local.get $1)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.get $2)
              )
              (then
               (ref.null none)
              )
              (else
               (local.set $1
                (struct.get $type32 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready301)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global301)
                )
               )
               (struct.new $type32
                (struct.new $type30
                 (i64.const 0)
                 (struct.get $type32 0
                  (local.get $2)
                 )
                )
                (if (result (ref null $type32))
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (ref.null none)
                 )
                 (else
                  (local.set $2
                   (struct.get $type32 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready301)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global301)
                   )
                  )
                  (struct.new $type32
                   (struct.new $type30
                    (i64.const 0)
                    (struct.get $type32 0
                     (local.get $1)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (local.set $1
                      (struct.get $type32 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready301)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global301)
                      )
                     )
                     (struct.new $type32
                      (struct.new $type30
                       (i64.const 0)
                       (struct.get $type32 0
                        (local.get $2)
                       )
                      )
                      (if (result (ref null $type32))
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (local.set $2
                         (struct.get $type32 1
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready301)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global301)
                         )
                        )
                        (struct.new $type32
                         (struct.new $type30
                          (i64.const 0)
                          (struct.get $type32 0
                           (local.get $1)
                          )
                         )
                         (if (result (ref null $type32))
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (local.set $1
                            (struct.get $type32 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready301)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global301)
                            )
                           )
                           (struct.new $type32
                            (struct.new $type30
                             (i64.const 0)
                             (struct.get $type32 0
                              (local.get $2)
                             )
                            )
                            (if (result (ref null $type32))
                             (ref.is_null
                              (local.get $1)
                             )
                             (then
                              (ref.null none)
                             )
                             (else
                              (local.set $2
                               (struct.get $type32 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready301)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global301)
                               )
                              )
                              (struct.new $type32
                               (struct.new $type30
                                (i64.const 0)
                                (struct.get $type32 0
                                 (local.get $1)
                                )
                               )
                               (if (result (ref null $type32))
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (local.set $1
                                  (struct.get $type32 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready301)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global301)
                                  )
                                 )
                                 (struct.new $type32
                                  (struct.new $type30
                                   (i64.const 0)
                                   (struct.get $type32 0
                                    (local.get $2)
                                   )
                                  )
                                  (if (result (ref null $type32))
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (local.set $2
                                     (struct.get $type32 1
                                      (local.get $1)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready301)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global301)
                                     )
                                    )
                                    (struct.new $type32
                                     (struct.new $type30
                                      (i64.const 0)
                                      (struct.get $type32 0
                                       (local.get $1)
                                      )
                                     )
                                     (if (result (ref null $type32))
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (local.set $8
                                        (struct.get $type32 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready301)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global301)
                                        )
                                       )
                                       (struct.new $type32
                                        (struct.new $type30
                                         (i64.const 0)
                                         (struct.get $type32 0
                                          (local.get $2)
                                         )
                                        )
                                        (if (result (ref null $type32))
                                         (ref.is_null
                                          (local.get $8)
                                         )
                                         (then
                                          (ref.null none)
                                         )
                                         (else
                                          (local.set $1
                                           (struct.get $type32 1
                                            (local.get $8)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready301)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global301)
                                           )
                                          )
                                          (struct.new $type32
                                           (struct.new $type30
                                            (i64.const 0)
                                            (struct.get $type32 0
                                             (local.get $8)
                                            )
                                           )
                                           (if (result (ref null $type32))
                                            (ref.is_null
                                             (local.get $1)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type32
                                              (struct.new $type30
                                               (i64.const 0)
                                               (struct.get $type32 0
                                                (local.get $1)
                                               )
                                              )
                                              (block (result (ref null $type32))
                                               (local.set $1
                                                (struct.get $type32 1
                                                 (local.get $1)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready301)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global301)
                                                )
                                               )
                                               (if (result (ref null $type32))
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (call $function152
                                                  (struct.new $environment152
                                                   (local.get $10)
                                                   (local.get $1)
                                                  )
                                                  (call $function150
                                                   (struct.get $type57 1
                                                    (local.get $10)
                                                   )
                                                   (struct.get $type32 0
                                                    (local.get $1)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (local.set $8
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (local.set $19
     (struct.get $type30 0
      (local.tee $3
       (struct.get $type32 0
        (local.get $1)
       )
      )
     )
    )
    (local.set $3
     (struct.get $type30 1
      (local.get $3)
     )
    )
    (if (result (ref $type32))
     (call_ref $call61
      (struct.get $type61 1
       (local.tee $14
        (struct.get $environment149 0
         (local.tee $9
          (ref.cast (ref $environment149)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $19)
      (struct.get $type61 0
       (local.get $14)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type124 0
         (local.tee $12
          (struct.get $environment149 6
           (local.get $9)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function149
       (struct.get $type122 1
        (struct.get $type124 1
         (local.get $12)
        )
       )
       (local.get $8)
       (struct.new $type32
        (local.get $3)
        (local.get $2)
       )
      )
     )
     (else
      (local.set $15
       (struct.get $environment149 1
        (local.get $9)
       )
      )
      (local.set $6
       (struct.get $environment149 2
        (local.get $9)
       )
      )
      (local.set $5
       (struct.new $type33
        (ref.func $function159)
        (struct.new $environment159
         (local.tee $16
          (struct.get $environment149 3
           (local.get $9)
          )
         )
         (call_ref $call33
          (struct.get $type33 1
           (local.tee $7
            (struct.get $environment149 4
             (local.get $9)
            )
           )
          )
          (local.get $19)
          (struct.get $type33 0
           (local.get $7)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global311)
       )
      )
      (local.set $4
       (if (result (ref null $type30))
        (ref.is_null
         (local.get $3)
        )
        (then
         (ref.null none)
        )
        (else
         (struct.new $type30
          (call_ref $call33
           (struct.get $type33 1
            (local.get $5)
           )
           (struct.get $type30 0
            (local.get $3)
           )
           (struct.get $type33 0
            (local.get $5)
           )
          )
          (block (result (ref null $type30))
           (local.set $3
            (struct.get $type30 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready311)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global311)
            )
           )
           (if (result (ref null $type30))
            (ref.is_null
             (local.get $3)
            )
            (then
             (ref.null none)
            )
            (else
             (struct.new $type30
              (call_ref $call33
               (struct.get $type33 1
                (local.get $5)
               )
               (struct.get $type30 0
                (local.get $3)
               )
               (struct.get $type33 0
                (local.get $5)
               )
              )
              (block (result (ref null $type30))
               (local.set $3
                (struct.get $type30 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready311)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global311)
                )
               )
               (if (result (ref null $type30))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (ref.null none)
                )
                (else
                 (struct.new $type30
                  (call_ref $call33
                   (struct.get $type33 1
                    (local.get $5)
                   )
                   (struct.get $type30 0
                    (local.get $3)
                   )
                   (struct.get $type33 0
                    (local.get $5)
                   )
                  )
                  (block (result (ref null $type30))
                   (local.set $3
                    (struct.get $type30 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready311)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global311)
                    )
                   )
                   (if (result (ref null $type30))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (struct.new $type30
                      (call_ref $call33
                       (struct.get $type33 1
                        (local.get $5)
                       )
                       (struct.get $type30 0
                        (local.get $3)
                       )
                       (struct.get $type33 0
                        (local.get $5)
                       )
                      )
                      (block (result (ref null $type30))
                       (local.set $3
                        (struct.get $type30 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready311)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global311)
                        )
                       )
                       (if (result (ref null $type30))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (struct.new $type30
                          (call_ref $call33
                           (struct.get $type33 1
                            (local.get $5)
                           )
                           (struct.get $type30 0
                            (local.get $3)
                           )
                           (struct.get $type33 0
                            (local.get $5)
                           )
                          )
                          (block (result (ref null $type30))
                           (local.set $3
                            (struct.get $type30 1
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready311)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global311)
                            )
                           )
                           (if (result (ref null $type30))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (struct.new $type30
                              (call_ref $call33
                               (struct.get $type33 1
                                (local.get $5)
                               )
                               (struct.get $type30 0
                                (local.get $3)
                               )
                               (struct.get $type33 0
                                (local.get $5)
                               )
                              )
                              (block (result (ref null $type30))
                               (local.set $3
                                (struct.get $type30 1
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready311)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global311)
                                )
                               )
                               (if (result (ref null $type30))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (struct.new $type30
                                  (call_ref $call33
                                   (struct.get $type33 1
                                    (local.get $5)
                                   )
                                   (struct.get $type30 0
                                    (local.get $3)
                                   )
                                   (struct.get $type33 0
                                    (local.get $5)
                                   )
                                  )
                                  (block (result (ref null $type30))
                                   (local.set $3
                                    (struct.get $type30 1
                                     (local.get $3)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready311)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global311)
                                    )
                                   )
                                   (if (result (ref null $type30))
                                    (ref.is_null
                                     (local.get $3)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (struct.new $type30
                                      (call_ref $call33
                                       (struct.get $type33 1
                                        (local.get $5)
                                       )
                                       (struct.get $type30 0
                                        (local.get $3)
                                       )
                                       (struct.get $type33 0
                                        (local.get $5)
                                       )
                                      )
                                      (block (result (ref null $type30))
                                       (local.set $3
                                        (struct.get $type30 1
                                         (local.get $3)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready311)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global311)
                                        )
                                       )
                                       (if (result (ref null $type30))
                                        (ref.is_null
                                         (local.get $3)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (struct.new $type30
                                          (call_ref $call33
                                           (struct.get $type33 1
                                            (local.get $5)
                                           )
                                           (struct.get $type30 0
                                            (local.get $3)
                                           )
                                           (struct.get $type33 0
                                            (local.get $5)
                                           )
                                          )
                                          (block (result (ref null $type30))
                                           (local.set $3
                                            (struct.get $type30 1
                                             (local.get $3)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready311)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global311)
                                            )
                                           )
                                           (if (result (ref null $type30))
                                            (ref.is_null
                                             (local.get $3)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (struct.new $type30
                                              (call_ref $call33
                                               (struct.get $type33 1
                                                (local.get $5)
                                               )
                                               (struct.get $type30 0
                                                (local.get $3)
                                               )
                                               (struct.get $type33 0
                                                (local.get $5)
                                               )
                                              )
                                              (block (result (ref null $type30))
                                               (local.set $3
                                                (struct.get $type30 1
                                                 (local.get $3)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready311)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global311)
                                                )
                                               )
                                               (if (result (ref null $type30))
                                                (ref.is_null
                                                 (local.get $3)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (struct.new $type30
                                                  (call_ref $call33
                                                   (struct.get $type33 1
                                                    (local.get $5)
                                                   )
                                                   (struct.get $type30 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type33 0
                                                    (local.get $5)
                                                   )
                                                  )
                                                  (block (result (ref null $type30))
                                                   (local.set $3
                                                    (struct.get $type30 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready311)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global311)
                                                    )
                                                   )
                                                   (if (result (ref null $type30))
                                                    (ref.is_null
                                                     (local.get $3)
                                                    )
                                                    (then
                                                     (ref.null none)
                                                    )
                                                    (else
                                                     (struct.new $type30
                                                      (call_ref $call33
                                                       (struct.get $type33 1
                                                        (local.get $5)
                                                       )
                                                       (struct.get $type30 0
                                                        (local.get $3)
                                                       )
                                                       (struct.get $type33 0
                                                        (local.get $5)
                                                       )
                                                      )
                                                      (block (result (ref null $type30))
                                                       (local.set $3
                                                        (struct.get $type30 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready311)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global311)
                                                        )
                                                       )
                                                       (if (result (ref null $type30))
                                                        (ref.is_null
                                                         (local.get $3)
                                                        )
                                                        (then
                                                         (ref.null none)
                                                        )
                                                        (else
                                                         (struct.new $type30
                                                          (call_ref $call33
                                                           (struct.get $type33 1
                                                            (local.get $5)
                                                           )
                                                           (struct.get $type30 0
                                                            (local.get $3)
                                                           )
                                                           (struct.get $type33 0
                                                            (local.get $5)
                                                           )
                                                          )
                                                          (block (result (ref null $type30))
                                                           (local.set $3
                                                            (struct.get $type30 1
                                                             (local.get $3)
                                                            )
                                                           )
                                                           (if
                                                            (i32.eqz
                                                             (global.get $ready311)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (drop
                                                            (ref.as_non_null
                                                             (global.get $global311)
                                                            )
                                                           )
                                                           (call $function160
                                                            (local.get $5)
                                                            (local.get $3)
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global181)
       )
      )
      (struct.set $type124 1
       (local.tee $11
        (struct.new_default $type124)
       )
       (struct.new $type122
        (ref.func $function85)
        (struct.new $environment85
         (struct.new $type84
          (ref.func $function164)
          (struct.new $environment164
           (local.get $14)
           (local.get $15)
           (local.get $6)
           (local.get $16)
           (local.get $4)
          )
         )
         (local.get $11)
        )
       )
      )
      (struct.set $type124 0
       (local.get $11)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type124 0
         (local.get $11)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (call_ref $call122
        (struct.get $type122 1
         (local.tee $17
          (ref.as_non_null
           (struct.get $type124 1
            (local.get $11)
           )
          )
         )
        )
        (local.get $8)
        (local.get $2)
        (struct.get $type122 0
         (local.get $17)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type152 0
         (local.tee $18
          (struct.get $environment149 5
           (local.get $9)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (call $function146
        (struct.get $type55 1
         (struct.get $type152 1
          (local.get $18)
         )
        )
        (local.get $1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global301)
       )
      )
      (struct.new $type32
       (struct.new $type30
        (i64.const 1)
        (local.get $4)
       )
       (if (result (ref null $type32))
        (ref.is_null
         (local.get $1)
        )
        (then
         (ref.null none)
        )
        (else
         (local.set $2
          (struct.get $type32 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready301)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global301)
          )
         )
         (local.set $10
          (struct.new $type57
           (ref.func $function163)
           (struct.new_default $environment163)
          )
         )
         (struct.new $type32
          (struct.new $type30
           (i64.const 0)
           (struct.get $type32 0
            (local.get $1)
           )
          )
          (if (result (ref null $type32))
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.null none)
           )
           (else
            (local.set $1
             (struct.get $type32 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready301)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global301)
             )
            )
            (struct.new $type32
             (struct.new $type30
              (i64.const 0)
              (struct.get $type32 0
               (local.get $2)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.get $1)
              )
              (then
               (ref.null none)
              )
              (else
               (local.set $2
                (struct.get $type32 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready301)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global301)
                )
               )
               (struct.new $type32
                (struct.new $type30
                 (i64.const 0)
                 (struct.get $type32 0
                  (local.get $1)
                 )
                )
                (if (result (ref null $type32))
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.null none)
                 )
                 (else
                  (local.set $1
                   (struct.get $type32 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready301)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global301)
                   )
                  )
                  (struct.new $type32
                   (struct.new $type30
                    (i64.const 0)
                    (struct.get $type32 0
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type32))
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (local.set $2
                      (struct.get $type32 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready301)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global301)
                      )
                     )
                     (struct.new $type32
                      (struct.new $type30
                       (i64.const 0)
                       (struct.get $type32 0
                        (local.get $1)
                       )
                      )
                      (if (result (ref null $type32))
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (local.set $1
                         (struct.get $type32 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready301)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global301)
                         )
                        )
                        (struct.new $type32
                         (struct.new $type30
                          (i64.const 0)
                          (struct.get $type32 0
                           (local.get $2)
                          )
                         )
                         (if (result (ref null $type32))
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (local.set $2
                            (struct.get $type32 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready301)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global301)
                            )
                           )
                           (struct.new $type32
                            (struct.new $type30
                             (i64.const 0)
                             (struct.get $type32 0
                              (local.get $1)
                             )
                            )
                            (if (result (ref null $type32))
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.null none)
                             )
                             (else
                              (local.set $1
                               (struct.get $type32 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready301)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global301)
                               )
                              )
                              (struct.new $type32
                               (struct.new $type30
                                (i64.const 0)
                                (struct.get $type32 0
                                 (local.get $2)
                                )
                               )
                               (if (result (ref null $type32))
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (local.set $2
                                  (struct.get $type32 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready301)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global301)
                                  )
                                 )
                                 (struct.new $type32
                                  (struct.new $type30
                                   (i64.const 0)
                                   (struct.get $type32 0
                                    (local.get $1)
                                   )
                                  )
                                  (if (result (ref null $type32))
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (local.set $8
                                     (struct.get $type32 1
                                      (local.get $2)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready301)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global301)
                                     )
                                    )
                                    (struct.new $type32
                                     (struct.new $type30
                                      (i64.const 0)
                                      (struct.get $type32 0
                                       (local.get $2)
                                      )
                                     )
                                     (if (result (ref null $type32))
                                      (ref.is_null
                                       (local.get $8)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (local.set $1
                                        (struct.get $type32 1
                                         (local.get $8)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready301)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global301)
                                        )
                                       )
                                       (struct.new $type32
                                        (struct.new $type30
                                         (i64.const 0)
                                         (struct.get $type32 0
                                          (local.get $8)
                                         )
                                        )
                                        (if (result (ref null $type32))
                                         (ref.is_null
                                          (local.get $1)
                                         )
                                         (then
                                          (ref.null none)
                                         )
                                         (else
                                          (struct.new $type32
                                           (struct.new $type30
                                            (i64.const 0)
                                            (struct.get $type32 0
                                             (local.get $1)
                                            )
                                           )
                                           (block (result (ref null $type32))
                                            (local.set $1
                                             (struct.get $type32 1
                                              (local.get $1)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready301)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global301)
                                             )
                                            )
                                            (if (result (ref null $type32))
                                             (ref.is_null
                                              (local.get $1)
                                             )
                                             (then
                                              (ref.null none)
                                             )
                                             (else
                                              (call $function152
                                               (struct.new $environment152
                                                (local.get $10)
                                                (local.get $1)
                                               )
                                               (call $function163
                                                (struct.get $type57 1
                                                 (local.get $10)
                                                )
                                                (struct.get $type32 0
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function150 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (drop
   (ref.cast (ref $environment150)
    (local.get $0)
   )
  )
  (struct.new $type30
   (i64.const 0)
   (local.get $1)
  )
 )
 (func $function151 (type $85) (param $0 (ref $type57)) (param $1 (ref null $type32)) (result (ref null $type32))
  (local $2 (ref null $type30))
  (if (result (ref null $type32))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type32
     (call_ref $call57
      (struct.get $type57 1
       (local.get $0)
      )
      (struct.get $type32 0
       (local.get $1)
      )
      (struct.get $type57 0
       (local.get $0)
      )
     )
     (block (result (ref null $type32))
      (local.set $1
       (struct.get $type32 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready301)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global301)
       )
      )
      (if (result (ref null $type32))
       (ref.is_null
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (struct.new $type32
         (call_ref $call57
          (struct.get $type57 1
           (local.get $0)
          )
          (struct.get $type32 0
           (local.get $1)
          )
          (struct.get $type57 0
           (local.get $0)
          )
         )
         (block (result (ref null $type32))
          (local.set $1
           (struct.get $type32 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready301)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global301)
           )
          )
          (if (result (ref null $type32))
           (ref.is_null
            (local.get $1)
           )
           (then
            (ref.null none)
           )
           (else
            (struct.new $type32
             (call_ref $call57
              (struct.get $type57 1
               (local.get $0)
              )
              (struct.get $type32 0
               (local.get $1)
              )
              (struct.get $type57 0
               (local.get $0)
              )
             )
             (block (result (ref null $type32))
              (local.set $1
               (struct.get $type32 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready301)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global301)
               )
              )
              (if (result (ref null $type32))
               (ref.is_null
                (local.get $1)
               )
               (then
                (ref.null none)
               )
               (else
                (struct.new $type32
                 (call_ref $call57
                  (struct.get $type57 1
                   (local.get $0)
                  )
                  (struct.get $type32 0
                   (local.get $1)
                  )
                  (struct.get $type57 0
                   (local.get $0)
                  )
                 )
                 (block (result (ref null $type32))
                  (local.set $1
                   (struct.get $type32 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready301)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global301)
                   )
                  )
                  (if (result (ref null $type32))
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (struct.new $type32
                     (call_ref $call57
                      (struct.get $type57 1
                       (local.get $0)
                      )
                      (struct.get $type32 0
                       (local.get $1)
                      )
                      (struct.get $type57 0
                       (local.get $0)
                      )
                     )
                     (block (result (ref null $type32))
                      (local.set $1
                       (struct.get $type32 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready301)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global301)
                       )
                      )
                      (if (result (ref null $type32))
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (struct.new $type32
                         (call_ref $call57
                          (struct.get $type57 1
                           (local.get $0)
                          )
                          (struct.get $type32 0
                           (local.get $1)
                          )
                          (struct.get $type57 0
                           (local.get $0)
                          )
                         )
                         (block (result (ref null $type32))
                          (local.set $1
                           (struct.get $type32 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready301)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global301)
                           )
                          )
                          (if (result (ref null $type32))
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (struct.new $type32
                             (call_ref $call57
                              (struct.get $type57 1
                               (local.get $0)
                              )
                              (struct.get $type32 0
                               (local.get $1)
                              )
                              (struct.get $type57 0
                               (local.get $0)
                              )
                             )
                             (block (result (ref null $type32))
                              (local.set $1
                               (struct.get $type32 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready301)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global301)
                               )
                              )
                              (if (result (ref null $type32))
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (struct.new $type32
                                 (call_ref $call57
                                  (struct.get $type57 1
                                   (local.get $0)
                                  )
                                  (struct.get $type32 0
                                   (local.get $1)
                                  )
                                  (struct.get $type57 0
                                   (local.get $0)
                                  )
                                 )
                                 (block (result (ref null $type32))
                                  (local.set $1
                                   (struct.get $type32 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready301)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global301)
                                   )
                                  )
                                  (if (result (ref null $type32))
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (struct.new $type32
                                     (call_ref $call57
                                      (struct.get $type57 1
                                       (local.get $0)
                                      )
                                      (struct.get $type32 0
                                       (local.get $1)
                                      )
                                      (struct.get $type57 0
                                       (local.get $0)
                                      )
                                     )
                                     (block (result (ref null $type32))
                                      (local.set $1
                                       (struct.get $type32 1
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready301)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global301)
                                       )
                                      )
                                      (if (result (ref null $type32))
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (ref.null none)
                                       )
                                       (else
                                        (struct.new $type32
                                         (call_ref $call57
                                          (struct.get $type57 1
                                           (local.get $0)
                                          )
                                          (struct.get $type32 0
                                           (local.get $1)
                                          )
                                          (struct.get $type57 0
                                           (local.get $0)
                                          )
                                         )
                                         (block (result (ref null $type32))
                                          (local.set $1
                                           (struct.get $type32 1
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready301)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global301)
                                           )
                                          )
                                          (if (result (ref null $type32))
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (ref.null none)
                                           )
                                           (else
                                            (struct.new $type32
                                             (call_ref $call57
                                              (struct.get $type57 1
                                               (local.get $0)
                                              )
                                              (struct.get $type32 0
                                               (local.get $1)
                                              )
                                              (struct.get $type57 0
                                               (local.get $0)
                                              )
                                             )
                                             (block (result (ref null $type32))
                                              (local.set $1
                                               (struct.get $type32 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready301)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global301)
                                               )
                                              )
                                              (if (result (ref null $type32))
                                               (ref.is_null
                                                (local.get $1)
                                               )
                                               (then
                                                (ref.null none)
                                               )
                                               (else
                                                (struct.new $type32
                                                 (call_ref $call57
                                                  (struct.get $type57 1
                                                   (local.get $0)
                                                  )
                                                  (struct.get $type32 0
                                                   (local.get $1)
                                                  )
                                                  (struct.get $type57 0
                                                   (local.get $0)
                                                  )
                                                 )
                                                 (block (result (ref null $type32))
                                                  (local.set $1
                                                   (struct.get $type32 1
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready301)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global301)
                                                   )
                                                  )
                                                  (if (result (ref null $type32))
                                                   (ref.is_null
                                                    (local.get $1)
                                                   )
                                                   (then
                                                    (ref.null none)
                                                   )
                                                   (else
                                                    (struct.new $type32
                                                     (call_ref $call57
                                                      (struct.get $type57 1
                                                       (local.get $0)
                                                      )
                                                      (struct.get $type32 0
                                                       (local.get $1)
                                                      )
                                                      (struct.get $type57 0
                                                       (local.get $0)
                                                      )
                                                     )
                                                     (block (result (ref null $type32))
                                                      (local.set $1
                                                       (struct.get $type32 1
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (global.get $ready301)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global301)
                                                       )
                                                      )
                                                      (if (result (ref null $type32))
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (ref.null none)
                                                       )
                                                       (else
                                                        (struct.new $type32
                                                         (call_ref $call57
                                                          (struct.get $type57 1
                                                           (local.get $0)
                                                          )
                                                          (struct.get $type32 0
                                                           (local.get $1)
                                                          )
                                                          (struct.get $type57 0
                                                           (local.get $0)
                                                          )
                                                         )
                                                         (block (result (ref null $type32))
                                                          (local.set $1
                                                           (struct.get $type32 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready301)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global301)
                                                           )
                                                          )
                                                          (if (result (ref null $type32))
                                                           (ref.is_null
                                                            (local.get $1)
                                                           )
                                                           (then
                                                            (ref.null none)
                                                           )
                                                           (else
                                                            (call $function152
                                                             (struct.new $environment152
                                                              (local.get $0)
                                                              (local.get $1)
                                                             )
                                                             (call_ref $call57
                                                              (struct.get $type57 1
                                                               (local.get $0)
                                                              )
                                                              (struct.get $type32 0
                                                               (local.get $1)
                                                              )
                                                              (struct.get $type57 0
                                                               (local.get $0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function152 (type $84) (param $0 (ref $environment152)) (param $1 (ref null $type30)) (result (ref $type32))
  (local $2 (ref null $type32))
  (local $3 (ref $type57))
  (local.set $2
   (struct.get $type32 1
    (struct.get $environment152 1
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $environment152 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (struct.new $type32
   (local.get $1)
   (if (result (ref null $type32))
    (ref.is_null
     (local.get $2)
    )
    (then
     (ref.null none)
    )
    (else
     (call $function152
      (struct.new $environment152
       (local.get $3)
       (local.get $2)
      )
      (call_ref $call57
       (struct.get $type57 1
        (local.get $3)
       )
       (struct.get $type32 0
        (local.get $2)
       )
       (struct.get $type57 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function159 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment159))
  (local $3 (ref $type60))
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment159 0
      (local.tee $2
       (ref.cast (ref $environment159)
        (local.get $0)
       )
      )
     )
    )
   )
   (struct.get $environment159 1
    (local.get $2)
   )
   (local.get $1)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function160 (type $83) (param $0 (ref $type33)) (param $1 (ref null $type30)) (result (ref null $type30))
  (local $2 i64)
  (if (result (ref null $type30))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type30
     (call_ref $call33
      (struct.get $type33 1
       (local.get $0)
      )
      (struct.get $type30 0
       (local.get $1)
      )
      (struct.get $type33 0
       (local.get $0)
      )
     )
     (block (result (ref null $type30))
      (local.set $1
       (struct.get $type30 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready311)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global311)
       )
      )
      (call $function160
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function163 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (drop
   (ref.cast (ref $environment163)
    (local.get $0)
   )
  )
  (struct.new $type30
   (i64.const 0)
   (local.get $1)
  )
 )
 (func $function164 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref null $type30))
  (local $4 (ref null $type30))
  (local $5 (ref $type60))
  (local $6 (ref $type60))
  (local $7 (ref $type60))
  (local $8 (ref $environment164))
  (local $9 (ref $type61))
  (local $10 (ref $type33))
  (local $11 i64)
  (local.set $4
   (struct.get $type30 1
    (local.get $1)
   )
  )
  (local.set $9
   (struct.get $environment164 0
    (local.tee $8
     (ref.cast (ref $environment164)
      (local.get $0)
     )
    )
   )
  )
  (local.set $6
   (struct.get $environment164 1
    (local.get $8)
   )
  )
  (local.set $10
   (struct.get $environment164 2
    (local.get $8)
   )
  )
  (local.set $7
   (struct.get $environment164 3
    (local.get $8)
   )
  )
  (local.set $3
   (struct.get $environment164 4
    (local.get $8)
   )
  )
  (struct.new $type32
   (if (result (ref null $type30))
    (call_ref $call61
     (struct.get $type61 1
      (local.get $9)
     )
     (local.tee $11
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (struct.get $type61 0
      (local.get $9)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (local.set $5
      (struct.new $type60
       (ref.func $function167)
       (struct.new $environment167
        (local.get $6)
        (local.get $7)
        (call_ref $call33
         (struct.get $type33 1
          (local.get $10)
         )
         (local.get $11)
         (struct.get $type33 0
          (local.get $10)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global324)
      )
     )
     (if (result (ref null $type30))
      (ref.is_null
       (local.get $4)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type30
        (call_ref $call60
         (struct.get $type60 1
          (local.get $5)
         )
         (struct.get $type30 0
          (local.get $4)
         )
         (struct.get $type30 0
          (local.get $3)
         )
         (struct.get $type60 0
          (local.get $5)
         )
        )
        (block (result (ref null $type30))
         (local.set $4
          (struct.get $type30 1
           (local.get $4)
          )
         )
         (local.set $1
          (struct.get $type30 1
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (global.get $ready324)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global324)
          )
         )
         (if (result (ref null $type30))
          (ref.is_null
           (local.get $4)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type30
            (call_ref $call60
             (struct.get $type60 1
              (local.get $5)
             )
             (struct.get $type30 0
              (local.get $4)
             )
             (struct.get $type30 0
              (local.get $1)
             )
             (struct.get $type60 0
              (local.get $5)
             )
            )
            (block (result (ref null $type30))
             (local.set $3
              (struct.get $type30 1
               (local.get $4)
              )
             )
             (local.set $1
              (struct.get $type30 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready324)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global324)
              )
             )
             (if (result (ref null $type30))
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type30
                (call_ref $call60
                 (struct.get $type60 1
                  (local.get $5)
                 )
                 (struct.get $type30 0
                  (local.get $3)
                 )
                 (struct.get $type30 0
                  (local.get $1)
                 )
                 (struct.get $type60 0
                  (local.get $5)
                 )
                )
                (block (result (ref null $type30))
                 (local.set $3
                  (struct.get $type30 1
                   (local.get $3)
                  )
                 )
                 (local.set $1
                  (struct.get $type30 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready324)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global324)
                  )
                 )
                 (if (result (ref null $type30))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type30
                    (call_ref $call60
                     (struct.get $type60 1
                      (local.get $5)
                     )
                     (struct.get $type30 0
                      (local.get $3)
                     )
                     (struct.get $type30 0
                      (local.get $1)
                     )
                     (struct.get $type60 0
                      (local.get $5)
                     )
                    )
                    (block (result (ref null $type30))
                     (local.set $3
                      (struct.get $type30 1
                       (local.get $3)
                      )
                     )
                     (local.set $1
                      (struct.get $type30 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready324)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global324)
                      )
                     )
                     (if (result (ref null $type30))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type30
                        (call_ref $call60
                         (struct.get $type60 1
                          (local.get $5)
                         )
                         (struct.get $type30 0
                          (local.get $3)
                         )
                         (struct.get $type30 0
                          (local.get $1)
                         )
                         (struct.get $type60 0
                          (local.get $5)
                         )
                        )
                        (block (result (ref null $type30))
                         (local.set $3
                          (struct.get $type30 1
                           (local.get $3)
                          )
                         )
                         (local.set $1
                          (struct.get $type30 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready324)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global324)
                          )
                         )
                         (if (result (ref null $type30))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type30
                            (call_ref $call60
                             (struct.get $type60 1
                              (local.get $5)
                             )
                             (struct.get $type30 0
                              (local.get $3)
                             )
                             (struct.get $type30 0
                              (local.get $1)
                             )
                             (struct.get $type60 0
                              (local.get $5)
                             )
                            )
                            (block (result (ref null $type30))
                             (local.set $3
                              (struct.get $type30 1
                               (local.get $3)
                              )
                             )
                             (local.set $1
                              (struct.get $type30 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready324)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global324)
                              )
                             )
                             (if (result (ref null $type30))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type30
                                (call_ref $call60
                                 (struct.get $type60 1
                                  (local.get $5)
                                 )
                                 (struct.get $type30 0
                                  (local.get $3)
                                 )
                                 (struct.get $type30 0
                                  (local.get $1)
                                 )
                                 (struct.get $type60 0
                                  (local.get $5)
                                 )
                                )
                                (block (result (ref null $type30))
                                 (local.set $3
                                  (struct.get $type30 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type30 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready324)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global324)
                                  )
                                 )
                                 (if (result (ref null $type30))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type30
                                    (call_ref $call60
                                     (struct.get $type60 1
                                      (local.get $5)
                                     )
                                     (struct.get $type30 0
                                      (local.get $3)
                                     )
                                     (struct.get $type30 0
                                      (local.get $1)
                                     )
                                     (struct.get $type60 0
                                      (local.get $5)
                                     )
                                    )
                                    (block (result (ref null $type30))
                                     (local.set $3
                                      (struct.get $type30 1
                                       (local.get $3)
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type30 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready324)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global324)
                                      )
                                     )
                                     (if (result (ref null $type30))
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type30
                                        (call_ref $call60
                                         (struct.get $type60 1
                                          (local.get $5)
                                         )
                                         (struct.get $type30 0
                                          (local.get $3)
                                         )
                                         (struct.get $type30 0
                                          (local.get $1)
                                         )
                                         (struct.get $type60 0
                                          (local.get $5)
                                         )
                                        )
                                        (block (result (ref null $type30))
                                         (local.set $3
                                          (struct.get $type30 1
                                           (local.get $3)
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type30 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready324)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global324)
                                          )
                                         )
                                         (if (result (ref null $type30))
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type30
                                            (call_ref $call60
                                             (struct.get $type60 1
                                              (local.get $5)
                                             )
                                             (struct.get $type30 0
                                              (local.get $3)
                                             )
                                             (struct.get $type30 0
                                              (local.get $1)
                                             )
                                             (struct.get $type60 0
                                              (local.get $5)
                                             )
                                            )
                                            (block (result (ref null $type30))
                                             (local.set $3
                                              (struct.get $type30 1
                                               (local.get $3)
                                              )
                                             )
                                             (local.set $1
                                              (struct.get $type30 1
                                               (local.get $1)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready324)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global324)
                                              )
                                             )
                                             (if (result (ref null $type30))
                                              (ref.is_null
                                               (local.get $3)
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (struct.new $type30
                                                (call_ref $call60
                                                 (struct.get $type60 1
                                                  (local.get $5)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $3)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $1)
                                                 )
                                                 (struct.get $type60 0
                                                  (local.get $5)
                                                 )
                                                )
                                                (block (result (ref null $type30))
                                                 (local.set $3
                                                  (struct.get $type30 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (local.set $1
                                                  (struct.get $type30 1
                                                   (local.get $1)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready324)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global324)
                                                  )
                                                 )
                                                 (if (result (ref null $type30))
                                                  (ref.is_null
                                                   (local.get $3)
                                                  )
                                                  (then
                                                   (ref.null none)
                                                  )
                                                  (else
                                                   (struct.new $type30
                                                    (call_ref $call60
                                                     (struct.get $type60 1
                                                      (local.get $5)
                                                     )
                                                     (struct.get $type30 0
                                                      (local.get $3)
                                                     )
                                                     (struct.get $type30 0
                                                      (local.get $1)
                                                     )
                                                     (struct.get $type60 0
                                                      (local.get $5)
                                                     )
                                                    )
                                                    (block (result (ref null $type30))
                                                     (local.set $4
                                                      (struct.get $type30 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (local.set $3
                                                      (struct.get $type30 1
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready324)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global324)
                                                      )
                                                     )
                                                     (if (result (ref null $type30))
                                                      (ref.is_null
                                                       (local.get $4)
                                                      )
                                                      (then
                                                       (ref.null none)
                                                      )
                                                      (else
                                                       (struct.new $type30
                                                        (call_ref $call60
                                                         (struct.get $type60 1
                                                          (local.get $5)
                                                         )
                                                         (struct.get $type30 0
                                                          (local.get $4)
                                                         )
                                                         (struct.get $type30 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type60 0
                                                          (local.get $5)
                                                         )
                                                        )
                                                        (block (result (ref null $type30))
                                                         (local.set $1
                                                          (struct.get $type30 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (local.set $4
                                                          (struct.get $type30 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready324)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global324)
                                                          )
                                                         )
                                                         (if (result (ref null $type30))
                                                          (ref.is_null
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (ref.null none)
                                                          )
                                                          (else
                                                           (struct.new $type30
                                                            (call_ref $call60
                                                             (struct.get $type60 1
                                                              (local.get $5)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $1)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $4)
                                                             )
                                                             (struct.get $type60 0
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (block (result (ref null $type30))
                                                             (local.set $3
                                                              (struct.get $type30 1
                                                               (local.get $1)
                                                              )
                                                             )
                                                             (local.set $1
                                                              (struct.get $type30 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready324)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global324)
                                                              )
                                                             )
                                                             (call $function168
                                                              (local.get $5)
                                                              (local.get $3)
                                                              (local.get $1)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (local.get $2)
  )
 )
 (func $function167 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type60))
  (local $4 (ref $environment167))
  (local.set $2
   (call_ref $call60
    (struct.get $type60 1
     (local.tee $3
      (struct.get $environment167 1
       (local.tee $4
        (ref.cast (ref $environment167)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $environment167 2
     (local.get $4)
    )
    (local.get $2)
    (struct.get $type60 0
     (local.get $3)
    )
   )
  )
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment167 0
      (local.get $4)
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function168 (type $81) (param $0 (ref $type60)) (param $1 (ref null $type30)) (param $2 (ref null $type30)) (result (ref null $type30))
  (local $3 i64)
  (if (result (ref null $type30))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type30
     (call_ref $call60
      (struct.get $type60 1
       (local.get $0)
      )
      (struct.get $type30 0
       (local.get $1)
      )
      (struct.get $type30 0
       (local.get $2)
      )
      (struct.get $type60 0
       (local.get $0)
      )
     )
     (block (result (ref null $type30))
      (local.set $1
       (struct.get $type30 1
        (local.get $1)
       )
      )
      (local.set $2
       (struct.get $type30 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready324)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global324)
       )
      )
      (call $function168
       (local.get $0)
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function172 (type $call93) (param $0 (ref struct)) (param $1 (ref $type32)) (result (ref $type94))
  (local $2 (ref $environment172))
  (local $3 (ref $type55))
  (local $4 (ref null $type32))
  (local.set $4
   (call_ref $call55
    (struct.get $type55 1
     (local.tee $3
      (struct.get $environment172 4
       (local.tee $2
        (ref.cast (ref $environment172)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type55 0
     (local.get $3)
    )
   )
  )
  (struct.new $type94
   (ref.func $function174)
   (struct.new $environment174
    (struct.get $environment172 0
     (local.get $2)
    )
    (struct.get $environment172 1
     (local.get $2)
    )
    (struct.get $environment172 2
     (local.get $2)
    )
    (struct.get $environment172 3
     (local.get $2)
    )
    (local.get $4)
   )
  )
 )
 (func $function174 (type $call94) (param $0 (ref struct)) (param $1 (ref null $type30)) (result i32)
  (local $2 (ref $environment176))
  (local $3 (ref $environment174))
  (local $4 (ref $type161))
  (local $5 (ref null $type32))
  (local.set $5
   (struct.get $environment174 4
    (local.tee $3
     (ref.cast (ref $environment174)
      (local.get $0)
     )
    )
   )
  )
  (struct.set $type161 1
   (local.tee $4
    (struct.new_default $type161)
   )
   (struct.new $type159
    (struct.new $environment176
     (struct.get $environment174 0
      (local.get $3)
     )
     (struct.get $environment174 1
      (local.get $3)
     )
     (struct.get $environment174 2
      (local.get $3)
     )
     (struct.get $environment174 3
      (local.get $3)
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type161 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type161 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type159 0
    (struct.get $type161 1
     (local.get $4)
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (return_call $function177
     (struct.new $environment177
      (struct.get $environment176 0
       (local.get $2)
      )
      (struct.get $environment176 1
       (local.get $2)
      )
      (struct.get $environment176 2
       (local.get $2)
      )
      (struct.get $environment176 3
       (local.get $2)
      )
      (struct.get $environment176 4
       (local.get $2)
      )
      (local.get $5)
     )
     (struct.get $type30 0
      (local.get $1)
     )
     (struct.get $type30 1
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function177 (type $71) (param $0 (ref $environment177)) (param $1 i64) (param $2 (ref null $type30)) (result i32)
  (local $3 (ref null $type30))
  (local $4 (ref null $type30))
  (local $5 (ref null $type32))
  (local $6 (ref null $type32))
  (local $7 (ref $type60))
  (local $8 (ref $environment176))
  (local $9 (ref $type61))
  (local $10 (ref $type57))
  (local $11 (ref $type161))
  (local $12 (ref $type33))
  (local $13 i32)
  (local $14 i64)
  (if (result i32)
   (call_ref $call61
    (struct.get $type61 1
     (local.tee $9
      (struct.get $environment177 0
       (local.get $0)
      )
     )
    )
    (local.get $1)
    (struct.get $type61 0
     (local.get $9)
    )
   )
   (then
    (if
     (i32.eqz
      (if (result i32)
       (local.tee $13
        (ref.is_null
         (local.tee $5
          (struct.get $environment177 5
           (local.get $0)
          )
         )
        )
       )
       (then
        (local.get $13)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global347)
         )
        )
        (call_ref $call61
         (struct.get $type61 1
          (local.get $9)
         )
         (struct.get $type30 0
          (struct.get $type32 0
           (local.get $5)
          )
         )
         (struct.get $type61 0
          (local.get $9)
         )
        )
       )
      )
     )
     (then
      (local.set $5
       (struct.get $type32 1
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global301)
     )
    )
    (local.set $6
     (if (result (ref null $type32))
      (ref.is_null
       (local.get $5)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type32
        (struct.get $type30 1
         (struct.get $type32 0
          (local.get $5)
         )
        )
        (block (result (ref null $type32))
         (local.set $5
          (struct.get $type32 1
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready301)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global301)
          )
         )
         (local.set $10
          (struct.new $type57
           (ref.func $primitive1)
           (ref.null none)
          )
         )
         (if (result (ref null $type32))
          (ref.is_null
           (local.get $5)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type32
            (struct.get $type30 1
             (struct.get $type32 0
              (local.get $5)
             )
            )
            (block (result (ref null $type32))
             (local.set $5
              (struct.get $type32 1
               (local.get $5)
              )
             )
             (if
              (i32.eqz
               (global.get $ready301)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global301)
              )
             )
             (if (result (ref null $type32))
              (ref.is_null
               (local.get $5)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type32
                (struct.get $type30 1
                 (struct.get $type32 0
                  (local.get $5)
                 )
                )
                (block (result (ref null $type32))
                 (local.set $5
                  (struct.get $type32 1
                   (local.get $5)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready301)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global301)
                  )
                 )
                 (if (result (ref null $type32))
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type32
                    (struct.get $type30 1
                     (struct.get $type32 0
                      (local.get $5)
                     )
                    )
                    (block (result (ref null $type32))
                     (local.set $5
                      (struct.get $type32 1
                       (local.get $5)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready301)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global301)
                      )
                     )
                     (if (result (ref null $type32))
                      (ref.is_null
                       (local.get $5)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type32
                        (struct.get $type30 1
                         (struct.get $type32 0
                          (local.get $5)
                         )
                        )
                        (block (result (ref null $type32))
                         (local.set $5
                          (struct.get $type32 1
                           (local.get $5)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready301)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global301)
                          )
                         )
                         (if (result (ref null $type32))
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type32
                            (struct.get $type30 1
                             (struct.get $type32 0
                              (local.get $5)
                             )
                            )
                            (block (result (ref null $type32))
                             (local.set $5
                              (struct.get $type32 1
                               (local.get $5)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready301)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global301)
                              )
                             )
                             (if (result (ref null $type32))
                              (ref.is_null
                               (local.get $5)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type32
                                (struct.get $type30 1
                                 (struct.get $type32 0
                                  (local.get $5)
                                 )
                                )
                                (block (result (ref null $type32))
                                 (local.set $5
                                  (struct.get $type32 1
                                   (local.get $5)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready301)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global301)
                                  )
                                 )
                                 (if (result (ref null $type32))
                                  (ref.is_null
                                   (local.get $5)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type32
                                    (struct.get $type30 1
                                     (struct.get $type32 0
                                      (local.get $5)
                                     )
                                    )
                                    (block (result (ref null $type32))
                                     (local.set $5
                                      (struct.get $type32 1
                                       (local.get $5)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready301)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global301)
                                      )
                                     )
                                     (if (result (ref null $type32))
                                      (ref.is_null
                                       (local.get $5)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type32
                                        (struct.get $type30 1
                                         (struct.get $type32 0
                                          (local.get $5)
                                         )
                                        )
                                        (block (result (ref null $type32))
                                         (local.set $5
                                          (struct.get $type32 1
                                           (local.get $5)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready301)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global301)
                                          )
                                         )
                                         (if (result (ref null $type32))
                                          (ref.is_null
                                           (local.get $5)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type32
                                            (struct.get $type30 1
                                             (struct.get $type32 0
                                              (local.get $5)
                                             )
                                            )
                                            (block (result (ref null $type32))
                                             (local.set $5
                                              (struct.get $type32 1
                                               (local.get $5)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready301)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global301)
                                              )
                                             )
                                             (if (result (ref null $type32))
                                              (ref.is_null
                                               (local.get $5)
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (struct.new $type32
                                                (struct.get $type30 1
                                                 (struct.get $type32 0
                                                  (local.get $5)
                                                 )
                                                )
                                                (block (result (ref null $type32))
                                                 (local.set $5
                                                  (struct.get $type32 1
                                                   (local.get $5)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready301)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global301)
                                                  )
                                                 )
                                                 (if (result (ref null $type32))
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                  (then
                                                   (ref.null none)
                                                  )
                                                  (else
                                                   (struct.new $type32
                                                    (struct.get $type30 1
                                                     (struct.get $type32 0
                                                      (local.get $5)
                                                     )
                                                    )
                                                    (block (result (ref null $type32))
                                                     (local.set $5
                                                      (struct.get $type32 1
                                                       (local.get $5)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready301)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global301)
                                                      )
                                                     )
                                                     (if (result (ref null $type32))
                                                      (ref.is_null
                                                       (local.get $5)
                                                      )
                                                      (then
                                                       (ref.null none)
                                                      )
                                                      (else
                                                       (struct.new $type32
                                                        (struct.get $type30 1
                                                         (struct.get $type32 0
                                                          (local.get $5)
                                                         )
                                                        )
                                                        (block (result (ref null $type32))
                                                         (local.set $5
                                                          (struct.get $type32 1
                                                           (local.get $5)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready301)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global301)
                                                          )
                                                         )
                                                         (if (result (ref null $type32))
                                                          (ref.is_null
                                                           (local.get $5)
                                                          )
                                                          (then
                                                           (ref.null none)
                                                          )
                                                          (else
                                                           (struct.new $type32
                                                            (struct.get $type30 1
                                                             (struct.get $type32 0
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (block (result (ref null $type32))
                                                             (local.set $5
                                                              (struct.get $type32 1
                                                               (local.get $5)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready301)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global301)
                                                              )
                                                             )
                                                             (if (result (ref null $type32))
                                                              (ref.is_null
                                                               (local.get $5)
                                                              )
                                                              (then
                                                               (ref.null none)
                                                              )
                                                              (else
                                                               (call $function152
                                                                (struct.new $environment152
                                                                 (local.get $10)
                                                                 (local.get $5)
                                                                )
                                                                (call $primitive1
                                                                 (ref.null none)
                                                                 (struct.get $type32 0
                                                                  (local.get $5)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type161 0
       (struct.get $environment177 4
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $type159 0
      (struct.get $type161 1
       (struct.get $environment177 4
        (local.get $0)
       )
      )
     )
    )
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function177
       (struct.new $environment177
        (struct.get $environment176 0
         (local.get $8)
        )
        (struct.get $environment176 1
         (local.get $8)
        )
        (struct.get $environment176 2
         (local.get $8)
        )
        (struct.get $environment176 3
         (local.get $8)
        )
        (struct.get $environment176 4
         (local.get $8)
        )
        (local.get $6)
       )
       (struct.get $type30 0
        (local.get $2)
       )
       (struct.get $type30 1
        (local.get $2)
       )
      )
     )
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (struct.get $environment177 5
       (local.get $0)
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $14
       (struct.get $type30 0
        (local.tee $3
         (struct.get $type32 0
          (local.tee $5
           (struct.get $environment177 5
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (local.set $3
       (struct.get $type30 1
        (local.get $3)
       )
      )
      (local.set $5
       (struct.get $type32 1
        (local.get $5)
       )
      )
      (if (result i32)
       (call_ref $call61
        (struct.get $type61 1
         (local.tee $9
          (struct.get $environment177 0
           (local.get $0)
          )
         )
        )
        (local.get $14)
        (struct.get $type61 0
         (local.get $9)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (local.set $11
         (struct.get $environment177 4
          (local.get $0)
         )
        )
        (local.set $7
         (struct.new $type60
          (ref.func $function186)
          (struct.new $environment186
           (struct.get $environment177 1
            (local.get $0)
           )
           (struct.get $environment177 3
            (local.get $0)
           )
           (call_ref $call33
            (struct.get $type33 1
             (local.tee $12
              (struct.get $environment177 2
               (local.get $0)
              )
             )
            )
            (local.get $1)
            (struct.get $type33 0
             (local.get $12)
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global324)
         )
        )
        (local.set $4
         (if (result (ref null $type30))
          (ref.is_null
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type30
            (call_ref $call60
             (struct.get $type60 1
              (local.get $7)
             )
             (struct.get $type30 0
              (local.get $2)
             )
             (struct.get $type30 0
              (local.get $3)
             )
             (struct.get $type60 0
              (local.get $7)
             )
            )
            (block (result (ref null $type30))
             (local.set $2
              (struct.get $type30 1
               (local.get $2)
              )
             )
             (local.set $3
              (struct.get $type30 1
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (global.get $ready324)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global324)
              )
             )
             (if (result (ref null $type30))
              (ref.is_null
               (local.get $2)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type30
                (call_ref $call60
                 (struct.get $type60 1
                  (local.get $7)
                 )
                 (struct.get $type30 0
                  (local.get $2)
                 )
                 (struct.get $type30 0
                  (local.get $3)
                 )
                 (struct.get $type60 0
                  (local.get $7)
                 )
                )
                (block (result (ref null $type30))
                 (local.set $2
                  (struct.get $type30 1
                   (local.get $2)
                  )
                 )
                 (local.set $3
                  (struct.get $type30 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready324)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global324)
                  )
                 )
                 (if (result (ref null $type30))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type30
                    (call_ref $call60
                     (struct.get $type60 1
                      (local.get $7)
                     )
                     (struct.get $type30 0
                      (local.get $2)
                     )
                     (struct.get $type30 0
                      (local.get $3)
                     )
                     (struct.get $type60 0
                      (local.get $7)
                     )
                    )
                    (block (result (ref null $type30))
                     (local.set $2
                      (struct.get $type30 1
                       (local.get $2)
                      )
                     )
                     (local.set $3
                      (struct.get $type30 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready324)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global324)
                      )
                     )
                     (if (result (ref null $type30))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type30
                        (call_ref $call60
                         (struct.get $type60 1
                          (local.get $7)
                         )
                         (struct.get $type30 0
                          (local.get $2)
                         )
                         (struct.get $type30 0
                          (local.get $3)
                         )
                         (struct.get $type60 0
                          (local.get $7)
                         )
                        )
                        (block (result (ref null $type30))
                         (local.set $2
                          (struct.get $type30 1
                           (local.get $2)
                          )
                         )
                         (local.set $3
                          (struct.get $type30 1
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready324)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global324)
                          )
                         )
                         (if (result (ref null $type30))
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type30
                            (call_ref $call60
                             (struct.get $type60 1
                              (local.get $7)
                             )
                             (struct.get $type30 0
                              (local.get $2)
                             )
                             (struct.get $type30 0
                              (local.get $3)
                             )
                             (struct.get $type60 0
                              (local.get $7)
                             )
                            )
                            (block (result (ref null $type30))
                             (local.set $2
                              (struct.get $type30 1
                               (local.get $2)
                              )
                             )
                             (local.set $3
                              (struct.get $type30 1
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready324)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global324)
                              )
                             )
                             (if (result (ref null $type30))
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type30
                                (call_ref $call60
                                 (struct.get $type60 1
                                  (local.get $7)
                                 )
                                 (struct.get $type30 0
                                  (local.get $2)
                                 )
                                 (struct.get $type30 0
                                  (local.get $3)
                                 )
                                 (struct.get $type60 0
                                  (local.get $7)
                                 )
                                )
                                (block (result (ref null $type30))
                                 (local.set $2
                                  (struct.get $type30 1
                                   (local.get $2)
                                  )
                                 )
                                 (local.set $3
                                  (struct.get $type30 1
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready324)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global324)
                                  )
                                 )
                                 (if (result (ref null $type30))
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type30
                                    (call_ref $call60
                                     (struct.get $type60 1
                                      (local.get $7)
                                     )
                                     (struct.get $type30 0
                                      (local.get $2)
                                     )
                                     (struct.get $type30 0
                                      (local.get $3)
                                     )
                                     (struct.get $type60 0
                                      (local.get $7)
                                     )
                                    )
                                    (block (result (ref null $type30))
                                     (local.set $2
                                      (struct.get $type30 1
                                       (local.get $2)
                                      )
                                     )
                                     (local.set $3
                                      (struct.get $type30 1
                                       (local.get $3)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready324)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global324)
                                      )
                                     )
                                     (if (result (ref null $type30))
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type30
                                        (call_ref $call60
                                         (struct.get $type60 1
                                          (local.get $7)
                                         )
                                         (struct.get $type30 0
                                          (local.get $2)
                                         )
                                         (struct.get $type30 0
                                          (local.get $3)
                                         )
                                         (struct.get $type60 0
                                          (local.get $7)
                                         )
                                        )
                                        (block (result (ref null $type30))
                                         (local.set $2
                                          (struct.get $type30 1
                                           (local.get $2)
                                          )
                                         )
                                         (local.set $3
                                          (struct.get $type30 1
                                           (local.get $3)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready324)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global324)
                                          )
                                         )
                                         (if (result (ref null $type30))
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type30
                                            (call_ref $call60
                                             (struct.get $type60 1
                                              (local.get $7)
                                             )
                                             (struct.get $type30 0
                                              (local.get $2)
                                             )
                                             (struct.get $type30 0
                                              (local.get $3)
                                             )
                                             (struct.get $type60 0
                                              (local.get $7)
                                             )
                                            )
                                            (block (result (ref null $type30))
                                             (local.set $2
                                              (struct.get $type30 1
                                               (local.get $2)
                                              )
                                             )
                                             (local.set $3
                                              (struct.get $type30 1
                                               (local.get $3)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready324)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global324)
                                              )
                                             )
                                             (if (result (ref null $type30))
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (struct.new $type30
                                                (call_ref $call60
                                                 (struct.get $type60 1
                                                  (local.get $7)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $2)
                                                 )
                                                 (struct.get $type30 0
                                                  (local.get $3)
                                                 )
                                                 (struct.get $type60 0
                                                  (local.get $7)
                                                 )
                                                )
                                                (block (result (ref null $type30))
                                                 (local.set $2
                                                  (struct.get $type30 1
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (local.set $3
                                                  (struct.get $type30 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready324)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global324)
                                                  )
                                                 )
                                                 (if (result (ref null $type30))
                                                  (ref.is_null
                                                   (local.get $2)
                                                  )
                                                  (then
                                                   (ref.null none)
                                                  )
                                                  (else
                                                   (struct.new $type30
                                                    (call_ref $call60
                                                     (struct.get $type60 1
                                                      (local.get $7)
                                                     )
                                                     (struct.get $type30 0
                                                      (local.get $2)
                                                     )
                                                     (struct.get $type30 0
                                                      (local.get $3)
                                                     )
                                                     (struct.get $type60 0
                                                      (local.get $7)
                                                     )
                                                    )
                                                    (block (result (ref null $type30))
                                                     (local.set $2
                                                      (struct.get $type30 1
                                                       (local.get $2)
                                                      )
                                                     )
                                                     (local.set $3
                                                      (struct.get $type30 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready324)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global324)
                                                      )
                                                     )
                                                     (if (result (ref null $type30))
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (ref.null none)
                                                      )
                                                      (else
                                                       (struct.new $type30
                                                        (call_ref $call60
                                                         (struct.get $type60 1
                                                          (local.get $7)
                                                         )
                                                         (struct.get $type30 0
                                                          (local.get $2)
                                                         )
                                                         (struct.get $type30 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type60 0
                                                          (local.get $7)
                                                         )
                                                        )
                                                        (block (result (ref null $type30))
                                                         (local.set $2
                                                          (struct.get $type30 1
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (local.set $3
                                                          (struct.get $type30 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready324)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global324)
                                                          )
                                                         )
                                                         (if (result (ref null $type30))
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                          (then
                                                           (ref.null none)
                                                          )
                                                          (else
                                                           (struct.new $type30
                                                            (call_ref $call60
                                                             (struct.get $type60 1
                                                              (local.get $7)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $2)
                                                             )
                                                             (struct.get $type30 0
                                                              (local.get $3)
                                                             )
                                                             (struct.get $type60 0
                                                              (local.get $7)
                                                             )
                                                            )
                                                            (block (result (ref null $type30))
                                                             (local.set $2
                                                              (struct.get $type30 1
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (local.set $3
                                                              (struct.get $type30 1
                                                               (local.get $3)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready324)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global324)
                                                              )
                                                             )
                                                             (call $function168
                                                              (local.get $7)
                                                              (local.get $2)
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global301)
         )
        )
        (local.set $6
         (call $function151
          (struct.new $type57
           (ref.func $primitive1)
           (ref.null none)
          )
          (local.get $5)
         )
        )
        (if
         (i32.eqz
          (struct.get $type161 0
           (local.get $11)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (struct.get $type159 0
          (struct.get $type161 1
           (local.get $11)
          )
         )
        )
        (if (result i32)
         (ref.is_null
          (local.get $4)
         )
         (then
          (i32.const 1)
         )
         (else
          (return_call $function177
           (struct.new $environment177
            (struct.get $environment176 0
             (local.get $8)
            )
            (struct.get $environment176 1
             (local.get $8)
            )
            (struct.get $environment176 2
             (local.get $8)
            )
            (struct.get $environment176 3
             (local.get $8)
            )
            (struct.get $environment176 4
             (local.get $8)
            )
            (local.get $6)
           )
           (struct.get $type30 0
            (local.get $4)
           )
           (struct.get $type30 1
            (local.get $4)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function186 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type60))
  (local $4 (ref $environment186))
  (local.set $2
   (call_ref $call60
    (struct.get $type60 1
     (local.tee $3
      (struct.get $environment186 1
       (local.tee $4
        (ref.cast (ref $environment186)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $environment186 2
     (local.get $4)
    )
    (local.get $2)
    (struct.get $type60 0
     (local.get $3)
    )
   )
  )
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $3
     (struct.get $environment186 0
      (local.get $4)
     )
    )
   )
   (local.get $1)
   (local.get $2)
   (struct.get $type60 0
    (local.get $3)
   )
  )
 )
 (func $function192 (type $call61) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function209 (type $69) (param $0 (ref $environment209)) (param $1 i64) (result (ref $type97))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $environment208))
  (local.set $3
   (i64.mul
    (local.tee $4
     (struct.get $environment209 4
      (local.get $0)
     )
    )
    (local.get $1)
   )
  )
  (if
   (i64.ne
    (local.get $4)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $3)
       (local.get $4)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $4
       (i64.sub
        (local.tee $2
         (struct.get $environment209 1
          (local.get $0)
         )
        )
        (local.get $3)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (i64.mul
    (local.tee $2
     (struct.get $environment209 5
      (local.get $0)
     )
    )
    (local.get $1)
   )
  )
  (if
   (i64.ne
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $3)
       (local.get $2)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $5
       (i64.sub
        (local.tee $2
         (struct.get $environment209 2
          (local.get $0)
         )
        )
        (local.get $3)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (i64.mul
    (local.tee $2
     (struct.get $environment209 6
      (local.get $0)
     )
    )
    (local.get $1)
   )
  )
  (if
   (i64.ne
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $3)
       (local.get $2)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (local.set $2
   (i64.sub
    (local.tee $1
     (struct.get $environment209 3
      (local.get $0)
     )
    )
    (local.get $3)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
     (i64.xor
      (local.get $1)
      (local.get $3)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type171 0
     (struct.get $environment209 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type169 0
    (struct.get $type171 1
     (struct.get $environment209 0
      (local.get $0)
     )
    )
   )
  )
  (local.set $1
   (struct.get $environment209 5
    (local.get $0)
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global363)
   )
  )
  (if (result (ref $type98))
   (i64.eqz
    (local.get $4)
   )
   (then
    (struct.new $type98
     (local.get $1)
    )
   )
   (else
    (return_call $function209
     (struct.new $environment209
      (struct.get $environment208 0
       (local.get $6)
      )
      (local.tee $3
       (struct.get $environment209 4
        (local.get $0)
       )
      )
      (local.get $1)
      (struct.get $environment209 6
       (local.get $0)
      )
      (local.get $4)
      (local.get $5)
      (local.get $2)
     )
     (call $function61
      (struct.get $type60 1
       (global.get $global156)
      )
      (local.get $3)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function218 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (return_call $function68
   (struct.get $type60 1
    (global.get $global163)
   )
   (local.get $1)
   (struct.get $environment218 0
    (ref.cast (ref $environment218)
     (local.get $0)
    )
   )
  )
 )
 (func $function220 (type $call61) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type33))
  (local $scratch i64)
  (i64.eqz
   (block (result i64)
    (local.set $scratch
     (call_ref $call33
      (struct.get $type33 1
       (local.tee $2
        (struct.get $environment220 0
         (ref.cast (ref $environment220)
          (local.get $0)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type33 0
       (local.get $2)
      )
     )
    )
    (drop
     (struct.get $type61 1
      (global.get $global363)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function222 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 (ref $type33))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.tee $3
       (i64.add
        (local.get $1)
        (local.get $2)
       )
      )
     )
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $4
     (struct.get $environment222 0
      (ref.cast (ref $environment222)
       (local.get $0)
      )
     )
    )
   )
   (local.get $3)
   (struct.get $type33 0
    (local.get $4)
   )
  )
 )
 (func $function224 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 (ref $type33))
  (drop
   (struct.get $type33 1
    (global.get $global106)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (local.get $1)
     (local.tee $2
      (i64.sub
       (i64.const 0)
       (local.get $1)
      )
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $3
     (struct.get $environment224 0
      (ref.cast (ref $environment224)
       (local.get $0)
      )
     )
    )
   )
   (local.get $2)
   (struct.get $type33 0
    (local.get $3)
   )
  )
 )
 (func $function226 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 (ref $type33))
  (local.set $3
   (i64.mul
    (local.get $1)
    (local.get $2)
   )
  )
  (if
   (i64.ne
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $3)
       (local.get $2)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $4
     (struct.get $environment226 0
      (ref.cast (ref $environment226)
       (local.get $0)
      )
     )
    )
   )
   (local.get $3)
   (struct.get $type33 0
    (local.get $4)
   )
  )
 )
 (func $function228 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 (ref $type171))
  (local $4 (ref $environment208))
  (local $5 (ref $type97))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.tee $2
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $environment228 0
    (ref.cast (ref $environment228)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready378)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if
   (ref.test (ref $type99)
    (local.tee $5
     (if (result (ref $type97))
      (i64.ge_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (if (result (ref $type97))
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (struct.set $type171 1
          (local.tee $3
           (struct.new_default $type171)
          )
          (struct.new $type169
           (struct.new $environment208
            (local.get $3)
           )
          )
         )
         (struct.set $type171 0
          (local.get $3)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type171 0
            (local.get $3)
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type169 0
           (struct.get $type171 1
            (local.get $3)
           )
          )
         )
         (drop
          (struct.get $type61 1
           (global.get $global363)
          )
         )
         (if (result (ref $type97))
          (i64.eqz
           (local.get $1)
          )
          (then
           (struct.new $type98
            (i64.const 1)
           )
          )
          (else
           (call $function209
            (struct.new $environment209
             (struct.get $environment208 0
              (local.get $4)
             )
             (local.get $2)
             (i64.const 1)
             (i64.const 0)
             (local.get $1)
             (i64.const 0)
             (i64.const 1)
            )
            (call $function61
             (struct.get $type60 1
              (global.get $global156)
             )
             (local.get $2)
             (local.get $1)
            )
           )
          )
         )
        )
        (else
         (drop
          (struct.get $type33 1
           (global.get $global106)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (local.get $1)
            (i64.sub
             (i64.const 0)
             (local.get $1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (struct.new_default $type99)
        )
       )
      )
      (else
       (drop
        (struct.get $type33 1
         (global.get $global106)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (local.get $2)
          (i64.sub
           (i64.const 0)
           (local.get $2)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.new_default $type99)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type98 0
   (ref.cast (ref $type98)
    (local.get $5)
   )
  )
 )
 (func $function231 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 (ref $environment231))
  (local $4 (ref $type33))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $1
       (call_ref $call33
        (struct.get $type33 1
         (local.tee $4
          (struct.get $environment231 0
           (local.tee $3
            (ref.cast (ref $environment231)
             (local.get $0)
            )
           )
          )
         )
        )
        (local.get $1)
        (struct.get $type33 0
         (local.get $4)
        )
       )
      )
      (local.tee $2
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type12
   (struct.get $environment231 1
    (local.get $3)
   )
   (i32.wrap_i64
    (local.get $2)
   )
  )
 )
 (func $function236 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type184))
  (local $3 (ref $type46))
  (local $4 (ref $type47))
  (local $5 (ref $type33))
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global430)
   )
  )
  (local.set $4
   (struct.new $type47
    (local.tee $3
     (struct.new $type46
      (i64.const 2)
      (struct.new $type47
       (global.get $empty45)
      )
     )
    )
   )
  )
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 2)
   )
   (then
    (i64.const 2)
   )
   (else
    (struct.set $type184 1
     (local.tee $2
      (struct.new_default $type184)
     )
     (struct.new $type33
      (ref.func $function249)
      (struct.new $environment249
       (local.get $1)
       (local.get $4)
       (struct.new $type61
        (ref.func $function240)
        (struct.new $environment240
         (local.get $3)
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type184 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type184 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call33
     (struct.get $type33 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type184 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 3)
     (struct.get $type33 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function240 (type $call61) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $type182))
  (local $3 (ref $type46))
  (local $4 (ref $type43))
  (local.set $3
   (struct.get $environment240 0
    (ref.cast (ref $environment240)
     (local.get $0)
    )
   )
  )
  (struct.set $type182 1
   (local.tee $2
    (struct.new_default $type182)
   )
   (struct.new $type43
    (ref.func $function242)
    (struct.new $environment242
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type182 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type182 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call43
   (struct.get $type43 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type182 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $3)
   (struct.get $type43 0
    (local.get $4)
   )
  )
 )
 (func $function242 (type $call43) (param $0 (ref null $environment242)) (param $1 (ref $type44)) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type182))
  (local $7 (ref $type46))
  (local $scratch i64)
  (local.set $3
   (struct.get $environment242 0
    (local.get $0)
   )
  )
  (local.set $6
   (struct.get $environment242 1
    (local.get $0)
   )
  )
  (drop
   (struct.get $type43 1
    (global.get $global108)
   )
  )
  (if (result i32)
   (local.tee $5
    (if (result i32)
     (ref.test (ref $type45)
      (local.get $1)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (i64.mul
      (local.tee $2
       (struct.get $type46 0
        (local.tee $7
         (ref.cast (ref $type46)
          (local.get $1)
         )
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.ne
      (local.get $2)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $4)
         (local.get $2)
        )
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if (result i32)
     (local.tee $5
      (i64.lt_s
       (local.get $3)
       (local.get $4)
      )
     )
     (then
      (local.get $5)
     )
     (else
      (if (result i32)
       (i64.eqz
        (block (result i64)
         (local.set $scratch
          (call $function68
           (struct.get $type60 1
            (global.get $global163)
           )
           (local.get $3)
           (local.get $2)
          )
         )
         (drop
          (struct.get $type61 1
           (global.get $global363)
          )
         )
         (local.get $scratch)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global131)
         )
        )
        (if
         (i32.eqz
          (struct.get $type182 0
           (local.get $6)
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function242
         (struct.get $type43 1
          (struct.get $type182 1
           (local.get $6)
          )
         )
         (struct.get $type47 0
          (struct.get $type46 1
           (local.get $7)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function249 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment249))
  (local $3 (ref $type61))
  (local $4 (ref $type47))
  (local $5 (ref $type44))
  (local $6 (ref $type46))
  (local $7 (ref $type184))
  (local $8 i64)
  (if (result i64)
   (call_ref $call61
    (struct.get $type61 1
     (local.tee $3
      (struct.get $environment249 2
       (local.tee $2
        (ref.cast (ref $environment249)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type61 0
     (local.get $3)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global443)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (if
     (ref.test (ref $type45)
      (local.tee $5
       (struct.get $type47 0
        (local.tee $4
         (struct.get $environment249 1
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type47 0
     (struct.get $type46 1
      (ref.cast (ref $type46)
       (local.get $5)
      )
     )
     (local.tee $6
      (struct.new $type46
       (local.get $1)
       (struct.new $type47
        (global.get $empty45)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global445)
     )
    )
    (struct.set $type47 0
     (local.get $4)
     (local.get $6)
    )
    (if (result i64)
     (i64.lt_s
      (struct.get $environment249 0
       (local.get $2)
      )
      (local.get $1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $8
           (i64.add
            (local.get $1)
            (i64.const 2)
           )
          )
         )
         (i64.xor
          (local.get $8)
          (i64.const 2)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type184 0
         (local.tee $7
          (struct.get $environment249 3
           (local.get $2)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function249
       (struct.get $type33 1
        (struct.get $type184 1
         (local.get $7)
        )
       )
       (local.get $8)
      )
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $8
         (i64.add
          (local.get $1)
          (i64.const 2)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type184 0
       (struct.get $environment249 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function249
     (struct.get $type33 1
      (struct.get $type184 1
       (struct.get $environment249 3
        (local.get $2)
       )
      )
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function253 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type115))
  (local $5 (ref $type184))
  (local $6 (ref $type60))
  (local $7 (ref $type33))
  (local.set $2
   (call $function61
    (struct.get $type60 1
     (global.get $global156)
    )
    (local.get $1)
    (i64.const 2)
   )
  )
  (drop
   (struct.get $type60 1
    (global.get $global122)
   )
  )
  (local.set $2
   (if (result i64)
    (i64.lt_s
     (local.get $2)
     (i64.const 0)
    )
    (then
     (unreachable)
    )
    (else
     (struct.set $type115 1
      (local.tee $4
       (struct.new_default $type115)
      )
      (struct.new $type60
       (ref.func $function48)
       (struct.new $environment48
        (local.get $1)
        (local.get $4)
       )
      )
     )
     (struct.set $type115 0
      (local.get $4)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type115 0
        (local.get $4)
       )
      )
      (then
       (unreachable)
      )
     )
     (call_ref $call60
      (struct.get $type60 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type115 1
          (local.get $4)
         )
        )
       )
      )
      (local.get $2)
      (i64.const 1)
      (struct.get $type60 0
       (local.get $6)
      )
     )
    )
   )
  )
  (drop
   (struct.get $type61 1
    (global.get $global120)
   )
  )
  (if (result i64)
   (i64.eqz
    (i64.and
     (local.get $1)
     (i64.const 1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (struct.set $type184 1
     (local.tee $5
      (struct.new_default $type184)
     )
     (struct.new $type33
      (ref.func $function256)
      (struct.new $environment256
       (local.get $1)
       (local.get $5)
      )
     )
    )
    (struct.set $type184 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type184 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.tee $1
       (call_ref $call33
        (struct.get $type33 1
         (local.tee $7
          (ref.as_non_null
           (struct.get $type184 1
            (local.get $5)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type33 0
         (local.get $7)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $1)
        )
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function256 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local.set $2
   (i64.mul
    (local.get $1)
    (local.get $1)
   )
  )
  (if
   (i64.ne
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.ne
      (i64.div_s
       (local.get $2)
       (local.get $1)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
   )
  )
  (if (result i64)
   (i64.le_s
    (struct.get $environment256 0
     (ref.cast (ref $environment256)
      (local.get $0)
     )
    )
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type184 0
       (struct.get $environment256 1
        (ref.cast (ref $environment256)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function256
     (struct.get $type33 1
      (struct.get $type184 1
       (struct.get $environment256 1
        (ref.cast (ref $environment256)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function257 (type $call103) (param $0 (ref null $environment295)) (param $1 (ref null $type32)) (param $2 (ref $type104)) (result (ref $type104))
  (local $3 (ref $environment260))
  (local $4 (ref null $type32))
  (local $5 (ref $type188))
  (local $6 (ref null $type54))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global456)
   )
  )
  (struct.set $type188 1
   (local.tee $5
    (struct.new_default $type188)
   )
   (struct.new $type186
    (struct.new $environment260
     (local.get $5)
    )
   )
  )
  (struct.set $type188 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type188 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type186 0
    (struct.get $type188 1
     (local.get $5)
    )
   )
  )
  (if (result (ref $type104))
   (i64.gt_s
    (local.tee $8
     (struct.get $type104 0
      (local.get $2)
     )
    )
    (local.tee $7
     (if (result i64)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $4
        (struct.get $type32 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type188 0
          (struct.get $environment260 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type186 0
         (struct.get $type188 1
          (struct.get $environment260 0
           (local.get $3)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $4
          (struct.get $type32 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type188 0
            (struct.get $environment260 0
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $3
          (struct.get $type186 0
           (struct.get $type188 1
            (struct.get $environment260 0
             (local.get $3)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $4)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $4
            (struct.get $type32 1
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (struct.get $type188 0
              (struct.get $environment260 0
               (local.get $3)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (struct.get $type186 0
             (struct.get $type188 1
              (struct.get $environment260 0
               (local.get $3)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $4
              (struct.get $type32 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type188 0
                (struct.get $environment260 0
                 (local.get $3)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (struct.get $type186 0
               (struct.get $type188 1
                (struct.get $environment260 0
                 (local.get $3)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $4
                (struct.get $type32 1
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type188 0
                  (struct.get $environment260 0
                   (local.get $3)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $3
                (struct.get $type186 0
                 (struct.get $type188 1
                  (struct.get $environment260 0
                   (local.get $3)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $4
                  (struct.get $type32 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type188 0
                    (struct.get $environment260 0
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $3
                  (struct.get $type186 0
                   (struct.get $type188 1
                    (struct.get $environment260 0
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $4
                    (struct.get $type32 1
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type188 0
                      (struct.get $environment260 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $3
                    (struct.get $type186 0
                     (struct.get $type188 1
                      (struct.get $environment260 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $4
                      (struct.get $type32 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type188 0
                        (struct.get $environment260 0
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $3
                      (struct.get $type186 0
                       (struct.get $type188 1
                        (struct.get $environment260 0
                         (local.get $3)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $4
                        (struct.get $type32 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type188 0
                          (struct.get $environment260 0
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $3
                        (struct.get $type186 0
                         (struct.get $type188 1
                          (struct.get $environment260 0
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $4
                          (struct.get $type32 1
                           (local.get $4)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type188 0
                            (struct.get $environment260 0
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $3
                          (struct.get $type186 0
                           (struct.get $type188 1
                            (struct.get $environment260 0
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $4
                            (struct.get $type32 1
                             (local.get $4)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type188 0
                              (struct.get $environment260 0
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $3
                            (struct.get $type186 0
                             (struct.get $type188 1
                              (struct.get $environment260 0
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $4
                              (struct.get $type32 1
                               (local.get $4)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type188 0
                                (struct.get $environment260 0
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $3
                              (struct.get $type186 0
                               (struct.get $type188 1
                                (struct.get $environment260 0
                                 (local.get $3)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $4
                                (struct.get $type32 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type188 0
                                  (struct.get $environment260 0
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $3
                                (struct.get $type186 0
                                 (struct.get $type188 1
                                  (struct.get $environment260 0
                                   (local.get $3)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $4
                                  (struct.get $type32 1
                                   (local.get $4)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type188 0
                                    (struct.get $environment260 0
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function260
                                  (struct.get $type186 0
                                   (struct.get $type188 1
                                    (struct.get $environment260 0
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (local.get $4)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if (result (ref $type104))
     (i64.eq
      (local.get $7)
      (local.get $8)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $7
           (i64.add
            (local.tee $9
             (struct.get $type104 1
              (local.get $2)
             )
            )
            (i64.const 1)
           )
          )
          (local.get $9)
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.get $type104 2
        (local.get $2)
       )
      )
      (struct.new $type104
       (local.get $8)
       (local.get $7)
       (if (result (ref null $type54))
        (i64.lt_s
         (local.get $7)
         (i64.const 3000)
        )
        (then
         (struct.new $type54
          (struct.new $type50
           (local.get $1)
          )
          (local.get $6)
         )
        )
        (else
         (if (result (ref null $type54))
          (i64.eq
           (local.get $7)
           (i64.const 3000)
          )
          (then
           (struct.new $type54
            (struct.new $type51
             (global.get $string1)
            )
            (local.get $6)
           )
          )
          (else
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global466)
       )
      )
      (struct.new $type104
       (local.get $7)
       (i64.const 1)
       (struct.new $type54
        (struct.new $type50
         (local.get $1)
        )
        (ref.null none)
       )
      )
     )
    )
   )
  )
 )
 (func $function260 (type $call186) (param $0 (ref $environment260)) (param $1 (ref null $type32)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type188 0
       (struct.get $environment260 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function260
     (struct.get $type186 0
      (struct.get $type188 1
       (struct.get $environment260 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function265 (type $call105) (param $0 i64) (param $1 i64) (result (ref null $type54))
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type117))
  (local $5 (ref null $type32))
  (local $6 (ref null $type32))
  (local $7 (ref $type124))
  (local $8 (ref $type206))
  (local $9 (ref $type33))
  (local $10 (ref $type33))
  (local $11 (ref $type103))
  (local $12 (ref $type12))
  (local $13 (ref $type72))
  (local $14 (ref $type122))
  (local $15 (ref $type32))
  (local $16 (ref $type61))
  (local $17 (ref $type60))
  (local $18 (ref $type60))
  (local $19 (ref $type93))
  (drop
   (ref.as_non_null
    (global.get $global471)
   )
  )
  (local.set $11
   (ref.as_non_null
    (global.get $global453)
   )
  )
  (local.set $2
   (call $function253
    (struct.get $type33 1
     (global.get $global448)
    )
    (local.get $1)
   )
  )
  (local.set $3
   (call $function236
    (struct.get $type33 1
     (global.get $global427)
    )
    (local.get $2)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global402)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global404)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global329)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $2
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
      (local.get $3)
     )
     (i64.xor
      (local.get $3)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global279)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global210)
   )
  )
  (struct.set $type117 1
   (local.tee $4
    (struct.new_default $type117)
   )
   (struct.new $type72
    (ref.func $function142)
    (struct.new $environment142
     (local.get $2)
     (struct.new $type33
      (ref.func $function228)
      (struct.new $environment228
       (local.get $3)
      )
     )
     (local.tee $12
      (if (result (ref $type12))
       (i32.or
        (i64.lt_s
         (local.get $2)
         (i64.const 0)
        )
        (i64.gt_s
         (local.get $2)
         (i64.const 4294967295)
        )
       )
       (then
        (unreachable)
       )
       (else
        (if (result (ref $type12))
         (i64.eqz
          (local.get $2)
         )
         (then
          (array.new_fixed $type12 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global55)
           )
          )
          (if
           (i64.gt_u
            (local.get $2)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (call $function100
           (local.get $2)
           (array.new_default $type12
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (i32.const 1)
           (i32.const 0)
           (i32.const 1)
           (i64.const 1)
          )
         )
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
  (struct.set $type117 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type117 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call72
    (struct.get $type72 1
     (local.tee $13
      (ref.as_non_null
       (struct.get $type117 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type72 0
     (local.get $13)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global285)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $2
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
      (local.get $0)
     )
     (i64.xor
      (local.get $0)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready504)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global504)
   )
  )
  (local.set $5
   (call $function283
    (local.get $2)
    (struct.new $type84
     (ref.func $primitive0)
     (ref.null none)
    )
    (ref.null none)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (struct.set $type124 1
   (local.tee $7
    (struct.new_default $type124)
   )
   (struct.new $type122
    (ref.func $function85)
    (struct.new $environment85
     (struct.new $type84
      (ref.func $function286)
      (ref.null none)
     )
     (local.get $7)
    )
   )
  )
  (struct.set $type124 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type124 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call_ref $call122
    (struct.get $type122 1
     (local.tee $14
      (ref.as_non_null
       (struct.get $type124 1
        (local.get $7)
       )
      )
     )
    )
    (local.get $5)
    (ref.null none)
    (struct.get $type122 0
     (local.get $14)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (local.set $6
   (struct.get $type32 1
    (local.get $5)
   )
  )
  (local.set $15
   (struct.new $type32
    (struct.get $type32 0
     (local.get $5)
    )
    (ref.null none)
   )
  )
  (struct.set $type206 1
   (local.tee $8
    (struct.new_default $type206)
   )
   (struct.new $type204
    (struct.new $environment290
     (local.get $1)
     (local.get $11)
     (local.tee $19
      (struct.new $type93
       (ref.func $function172)
       (struct.new $environment172
        (local.tee $16
         (struct.new $type61
          (ref.func $function220)
          (struct.new $environment220
           (local.tee $9
            (struct.new $type33
             (ref.func $function218)
             (struct.new $environment218
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (local.tee $17
         (struct.new $type60
          (ref.func $function222)
          (struct.new $environment222
           (local.get $9)
          )
         )
        )
        (local.tee $10
         (struct.new $type33
          (ref.func $function224)
          (struct.new $environment224
           (local.get $9)
          )
         )
        )
        (local.tee $18
         (struct.new $type60
          (ref.func $function226)
          (struct.new $environment226
           (local.get $9)
          )
         )
        )
        (struct.new $type55
         (ref.func $function144)
         (struct.new $environment144
          (local.get $16)
          (local.get $17)
          (local.get $10)
          (local.get $18)
          (struct.new $type33
           (ref.func $function231)
           (struct.new $environment231
            (local.get $9)
            (local.get $12)
           )
          )
         )
        )
       )
      )
     )
     (struct.new $type93
      (ref.func $function268)
      (struct.new $environment268
       (local.get $1)
       (local.get $19)
      )
     )
     (local.get $8)
    )
   )
  )
  (struct.set $type206 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type206 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type104 2
   (call $function290
    (struct.get $type204 0
     (struct.get $type206 1
      (local.get $8)
     )
    )
    (i64.const 1)
    (local.get $15)
    (local.get $6)
    (struct.new $type104
     (i64.const -1)
     (i64.const -1)
     (ref.null none)
    )
   )
  )
 )
 (func $function268 (type $call93) (param $0 (ref struct)) (param $1 (ref $type32)) (result (ref $type94))
  (local $2 (ref $environment260))
  (local $3 (ref null $type32))
  (local $4 (ref null $type32))
  (local $5 (ref $type188))
  (local $6 (ref $type197))
  (local $7 (ref $environment268))
  (local $8 (ref $type109))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $10
       (i64.sub
        (local.tee $9
         (struct.get $environment268 0
          (local.tee $7
           (ref.cast (ref $environment268)
            (local.get $0)
           )
          )
         )
        )
        (i64.const 2)
       )
      )
      (local.get $9)
     )
     (i64.xor
      (local.get $9)
      (i64.const 2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready482)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global482)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global456)
   )
  )
  (struct.set $type188 1
   (local.tee $5
    (struct.new_default $type188)
   )
   (struct.new $type186
    (struct.new $environment260
     (local.get $5)
    )
   )
  )
  (struct.set $type188 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type188 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type186 0
    (struct.get $type188 1
     (local.get $5)
    )
   )
  )
  (local.set $8
   (struct.new $type109
    (ref.func $function270)
    (struct.new $environment270
     (struct.get $environment268 1
      (local.get $7)
     )
     (struct.get $type32 0
      (local.get $1)
     )
    )
   )
  )
  (struct.new $type94
   (ref.func $function278)
   (struct.new $environment278
    (if (result (ref null $type110))
     (i64.gt_s
      (local.get $10)
      (local.tee $9
       (if (result i64)
        (ref.is_null
         (local.tee $4
          (struct.get $type32 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 0)
        )
        (else
         (local.set $3
          (struct.get $type32 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type188 0
            (struct.get $environment260 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type186 0
           (struct.get $type188 1
            (struct.get $environment260 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 1)
          )
          (else
           (local.set $3
            (struct.get $type32 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type188 0
              (struct.get $environment260 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type186 0
             (struct.get $type188 1
              (struct.get $environment260 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 2)
            )
            (else
             (local.set $3
              (struct.get $type32 1
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type188 0
                (struct.get $environment260 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type186 0
               (struct.get $type188 1
                (struct.get $environment260 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 3)
              )
              (else
               (local.set $3
                (struct.get $type32 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type188 0
                  (struct.get $environment260 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type186 0
                 (struct.get $type188 1
                  (struct.get $environment260 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 4)
                )
                (else
                 (local.set $3
                  (struct.get $type32 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type188 0
                    (struct.get $environment260 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type186 0
                   (struct.get $type188 1
                    (struct.get $environment260 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type32 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type188 0
                      (struct.get $environment260 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type186 0
                     (struct.get $type188 1
                      (struct.get $environment260 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (local.set $3
                      (struct.get $type32 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type188 0
                        (struct.get $environment260 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $2
                      (struct.get $type186 0
                       (struct.get $type188 1
                        (struct.get $environment260 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (local.set $3
                        (struct.get $type32 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type188 0
                          (struct.get $environment260 0
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $2
                        (struct.get $type186 0
                         (struct.get $type188 1
                          (struct.get $environment260 0
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (local.set $3
                          (struct.get $type32 1
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type188 0
                            (struct.get $environment260 0
                             (local.get $2)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $2
                          (struct.get $type186 0
                           (struct.get $type188 1
                            (struct.get $environment260 0
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 9)
                          )
                          (else
                           (local.set $3
                            (struct.get $type32 1
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type188 0
                              (struct.get $environment260 0
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (struct.get $type186 0
                             (struct.get $type188 1
                              (struct.get $environment260 0
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 10)
                            )
                            (else
                             (local.set $3
                              (struct.get $type32 1
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type188 0
                                (struct.get $environment260 0
                                 (local.get $2)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $2
                              (struct.get $type186 0
                               (struct.get $type188 1
                                (struct.get $environment260 0
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 11)
                              )
                              (else
                               (local.set $3
                                (struct.get $type32 1
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type188 0
                                  (struct.get $environment260 0
                                   (local.get $2)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $2
                                (struct.get $type186 0
                                 (struct.get $type188 1
                                  (struct.get $environment260 0
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 12)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type32 1
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type188 0
                                    (struct.get $environment260 0
                                     (local.get $2)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function260
                                  (struct.get $type186 0
                                   (struct.get $type188 1
                                    (struct.get $environment260 0
                                     (local.get $2)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 13)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (ref.null none)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $11
           (i64.sub
            (local.get $9)
            (local.get $10)
           )
          )
          (local.get $9)
         )
         (i64.xor
          (local.get $9)
          (local.get $10)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type197 1
       (local.tee $6
        (struct.new_default $type197)
       )
       (struct.new $type195
        (struct.new $environment274
         (local.get $6)
        )
       )
      )
      (struct.set $type197 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type197 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function274
       (struct.get $type195 0
        (struct.get $type197 1
         (local.get $6)
        )
       )
       (local.get $10)
       (local.get $4)
       (local.get $8)
       (local.get $11)
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function270 (type $call109) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type110)) (result (ref null $type110))
  (local $3 (ref $environment270))
  (local $4 (ref $type93))
  (struct.new $type110
   (call_ref $call93
    (struct.get $type93 1
     (local.tee $4
      (struct.get $environment270 0
       (local.tee $3
        (ref.cast (ref $environment270)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.new $type32
     (struct.get $environment270 1
      (local.get $3)
     )
     (local.get $1)
    )
    (struct.get $type93 0
     (local.get $4)
    )
   )
   (local.get $2)
  )
 )
 (func $function274 (type $call195) (param $0 (ref $environment274)) (param $1 i64) (param $2 (ref null $type32)) (param $3 (ref $type109)) (param $4 i64) (param $5 (ref null $type110)) (result (ref null $type110))
  (local $6 (ref $type197))
  (local $7 (ref null $type30))
  (local $8 i64)
  (local $9 i64)
  (drop
   (struct.get $type61 1
    (global.get $global363)
   )
  )
  (if
   (i64.eqz
    (local.get $4)
   )
   (then
    (return_call_ref $call109
     (struct.get $type109 1
      (local.get $3)
     )
     (local.get $2)
     (local.get $5)
     (struct.get $type109 0
      (local.get $3)
     )
    )
   )
   (else
    (drop
     (struct.get $type61 1
      (global.get $global363)
     )
    )
    (if
     (i64.eqz
      (local.get $1)
     )
     (then
      (return_call_ref $call109
       (struct.get $type109 1
        (local.get $3)
       )
       (ref.null none)
       (local.get $5)
       (struct.get $type109 0
        (local.get $3)
       )
      )
     )
     (else
      (local.set $7
       (struct.get $type32 0
        (local.get $2)
       )
      )
      (local.set $2
       (struct.get $type32 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $8
           (i64.sub
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $9
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type197 0
         (local.tee $6
          (struct.get $environment274 0
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (call $function274
        (struct.get $type195 0
         (struct.get $type197 1
          (local.get $6)
         )
        )
        (local.get $9)
        (local.get $2)
        (struct.new $type109
         (ref.func $function276)
         (struct.new $environment276
          (local.get $3)
          (local.get $7)
         )
        )
        (local.get $4)
        (local.get $5)
       )
      )
      (if
       (i32.eqz
        (struct.get $type197 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function274
       (struct.get $type195 0
        (struct.get $type197 1
         (local.get $6)
        )
       )
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $8)
       (local.get $5)
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function276 (type $call109) (param $0 (ref struct)) (param $1 (ref null $type32)) (param $2 (ref null $type110)) (result (ref null $type110))
  (local $3 (ref $environment276))
  (local $4 (ref $type109))
  (return_call_ref $call109
   (struct.get $type109 1
    (local.tee $4
     (struct.get $environment276 0
      (local.tee $3
       (ref.cast (ref $environment276)
        (local.get $0)
       )
      )
     )
    )
   )
   (struct.new $type32
    (struct.get $environment276 1
     (local.get $3)
    )
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type109 0
    (local.get $4)
   )
  )
 )
 (func $function278 (type $call94) (param $0 (ref struct)) (param $1 (ref null $type30)) (result i32)
  (local $2 (ref null $type110))
  (local $3 (ref $environment280))
  (local $4 (ref $type94))
  (local $5 (ref $type201))
  (local $6 (ref $type201))
  (local $7 i32)
  (local.set $2
   (struct.get $environment278 0
    (ref.cast (ref $environment278)
     (local.get $0)
    )
   )
  )
  (struct.set $type201 1
   (local.tee $6
    (struct.new_default $type201)
   )
   (struct.new $type199
    (struct.new $environment280
     (local.get $1)
     (local.get $6)
    )
   )
  )
  (struct.set $type201 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type201 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type199 0
    (struct.get $type201 1
     (local.get $6)
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $7
      (call_ref $call94
       (struct.get $type94 1
        (local.tee $4
         (struct.get $type110 0
          (local.get $2)
         )
        )
       )
       (struct.get $environment280 0
        (local.get $3)
       )
       (struct.get $type94 0
        (local.get $4)
       )
      )
     )
     (then
      (local.get $7)
     )
     (else
      (local.set $2
       (struct.get $type110 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type201 0
         (local.tee $5
          (struct.get $environment280 1
           (local.get $3)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type199 0
        (struct.get $type201 1
         (local.get $5)
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $7
          (call_ref $call94
           (struct.get $type94 1
            (local.tee $4
             (struct.get $type110 0
              (local.get $2)
             )
            )
           )
           (struct.get $environment280 0
            (local.get $3)
           )
           (struct.get $type94 0
            (local.get $4)
           )
          )
         )
         (then
          (local.get $7)
         )
         (else
          (local.set $2
           (struct.get $type110 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type201 0
             (local.tee $5
              (struct.get $environment280 1
               (local.get $3)
              )
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type199 0
            (struct.get $type201 1
             (local.get $5)
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $7
              (call_ref $call94
               (struct.get $type94 1
                (local.tee $4
                 (struct.get $type110 0
                  (local.get $2)
                 )
                )
               )
               (struct.get $environment280 0
                (local.get $3)
               )
               (struct.get $type94 0
                (local.get $4)
               )
              )
             )
             (then
              (local.get $7)
             )
             (else
              (local.set $2
               (struct.get $type110 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type201 0
                 (local.tee $5
                  (struct.get $environment280 1
                   (local.get $3)
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type199 0
                (struct.get $type201 1
                 (local.get $5)
                )
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $7
                  (call_ref $call94
                   (struct.get $type94 1
                    (local.tee $4
                     (struct.get $type110 0
                      (local.get $2)
                     )
                    )
                   )
                   (struct.get $environment280 0
                    (local.get $3)
                   )
                   (struct.get $type94 0
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (local.set $2
                   (struct.get $type110 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type201 0
                     (local.tee $5
                      (struct.get $environment280 1
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type199 0
                    (struct.get $type201 1
                     (local.get $5)
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $7
                      (call_ref $call94
                       (struct.get $type94 1
                        (local.tee $4
                         (struct.get $type110 0
                          (local.get $2)
                         )
                        )
                       )
                       (struct.get $environment280 0
                        (local.get $3)
                       )
                       (struct.get $type94 0
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (local.set $2
                       (struct.get $type110 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type201 0
                         (local.tee $5
                          (struct.get $environment280 1
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type199 0
                        (struct.get $type201 1
                         (local.get $5)
                        )
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $7
                          (call_ref $call94
                           (struct.get $type94 1
                            (local.tee $4
                             (struct.get $type110 0
                              (local.get $2)
                             )
                            )
                           )
                           (struct.get $environment280 0
                            (local.get $3)
                           )
                           (struct.get $type94 0
                            (local.get $4)
                           )
                          )
                         )
                         (then
                          (local.get $7)
                         )
                         (else
                          (local.set $2
                           (struct.get $type110 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type201 0
                             (local.tee $5
                              (struct.get $environment280 1
                               (local.get $3)
                              )
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $3
                           (struct.get $type199 0
                            (struct.get $type201 1
                             (local.get $5)
                            )
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $7
                              (call_ref $call94
                               (struct.get $type94 1
                                (local.tee $4
                                 (struct.get $type110 0
                                  (local.get $2)
                                 )
                                )
                               )
                               (struct.get $environment280 0
                                (local.get $3)
                               )
                               (struct.get $type94 0
                                (local.get $4)
                               )
                              )
                             )
                             (then
                              (local.get $7)
                             )
                             (else
                              (local.set $2
                               (struct.get $type110 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type201 0
                                 (local.tee $5
                                  (struct.get $environment280 1
                                   (local.get $3)
                                  )
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $3
                               (struct.get $type199 0
                                (struct.get $type201 1
                                 (local.get $5)
                                )
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $7
                                  (call_ref $call94
                                   (struct.get $type94 1
                                    (local.tee $4
                                     (struct.get $type110 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (struct.get $environment280 0
                                    (local.get $3)
                                   )
                                   (struct.get $type94 0
                                    (local.get $4)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $7)
                                 )
                                 (else
                                  (local.set $2
                                   (struct.get $type110 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (struct.get $type201 0
                                     (local.tee $5
                                      (struct.get $environment280 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $3
                                   (struct.get $type199 0
                                    (struct.get $type201 1
                                     (local.get $5)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $7
                                      (call_ref $call94
                                       (struct.get $type94 1
                                        (local.tee $4
                                         (struct.get $type110 0
                                          (local.get $2)
                                         )
                                        )
                                       )
                                       (struct.get $environment280 0
                                        (local.get $3)
                                       )
                                       (struct.get $type94 0
                                        (local.get $4)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $7)
                                     )
                                     (else
                                      (local.set $2
                                       (struct.get $type110 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type201 0
                                         (local.tee $5
                                          (struct.get $environment280 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (local.set $3
                                       (struct.get $type199 0
                                        (struct.get $type201 1
                                         (local.get $5)
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if (result i32)
                                         (local.tee $7
                                          (call_ref $call94
                                           (struct.get $type94 1
                                            (local.tee $4
                                             (struct.get $type110 0
                                              (local.get $2)
                                             )
                                            )
                                           )
                                           (struct.get $environment280 0
                                            (local.get $3)
                                           )
                                           (struct.get $type94 0
                                            (local.get $4)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $7)
                                         )
                                         (else
                                          (local.set $2
                                           (struct.get $type110 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (struct.get $type201 0
                                             (local.tee $5
                                              (struct.get $environment280 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $3
                                           (struct.get $type199 0
                                            (struct.get $type201 1
                                             (local.get $5)
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (local.tee $7
                                              (call_ref $call94
                                               (struct.get $type94 1
                                                (local.tee $4
                                                 (struct.get $type110 0
                                                  (local.get $2)
                                                 )
                                                )
                                               )
                                               (struct.get $environment280 0
                                                (local.get $3)
                                               )
                                               (struct.get $type94 0
                                                (local.get $4)
                                               )
                                              )
                                             )
                                             (then
                                              (local.get $7)
                                             )
                                             (else
                                              (local.set $2
                                               (struct.get $type110 1
                                                (local.get $2)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (struct.get $type201 0
                                                 (local.tee $5
                                                  (struct.get $environment280 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (local.set $3
                                               (struct.get $type199 0
                                                (struct.get $type201 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (local.tee $7
                                                  (call_ref $call94
                                                   (struct.get $type94 1
                                                    (local.tee $4
                                                     (struct.get $type110 0
                                                      (local.get $2)
                                                     )
                                                    )
                                                   )
                                                   (struct.get $environment280 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type94 0
                                                    (local.get $4)
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (local.get $7)
                                                 )
                                                 (else
                                                  (local.set $2
                                                   (struct.get $type110 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (struct.get $type201 0
                                                     (local.tee $5
                                                      (struct.get $environment280 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (local.set $3
                                                   (struct.get $type199 0
                                                    (struct.get $type201 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (local.tee $7
                                                      (call_ref $call94
                                                       (struct.get $type94 1
                                                        (local.tee $4
                                                         (struct.get $type110 0
                                                          (local.get $2)
                                                         )
                                                        )
                                                       )
                                                       (struct.get $environment280 0
                                                        (local.get $3)
                                                       )
                                                       (struct.get $type94 0
                                                        (local.get $4)
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (local.get $7)
                                                     )
                                                     (else
                                                      (local.set $2
                                                       (struct.get $type110 1
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (struct.get $type201 0
                                                         (local.tee $5
                                                          (struct.get $environment280 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (local.set $3
                                                       (struct.get $type199 0
                                                        (struct.get $type201 1
                                                         (local.get $5)
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $2)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (local.tee $7
                                                          (call_ref $call94
                                                           (struct.get $type94 1
                                                            (local.tee $4
                                                             (struct.get $type110 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                           )
                                                           (struct.get $environment280 0
                                                            (local.get $3)
                                                           )
                                                           (struct.get $type94 0
                                                            (local.get $4)
                                                           )
                                                          )
                                                         )
                                                         (then
                                                          (local.get $7)
                                                         )
                                                         (else
                                                          (local.set $2
                                                           (struct.get $type110 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (struct.get $type201 0
                                                             (local.tee $5
                                                              (struct.get $environment280 1
                                                               (local.get $3)
                                                              )
                                                             )
                                                            )
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (local.set $3
                                                           (struct.get $type199 0
                                                            (struct.get $type201 1
                                                             (local.get $5)
                                                            )
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (return_call $function281
                                                             (struct.new $environment281
                                                              (struct.get $environment280 1
                                                               (local.get $3)
                                                              )
                                                              (local.get $2)
                                                             )
                                                             (call_ref $call94
                                                              (struct.get $type94 1
                                                               (local.tee $4
                                                                (struct.get $type110 0
                                                                 (local.get $2)
                                                                )
                                                               )
                                                              )
                                                              (struct.get $environment280 0
                                                               (local.get $3)
                                                              )
                                                              (struct.get $type94 0
                                                               (local.get $4)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function281 (type $22) (param $0 (ref $environment281)) (param $1 i32) (result i32)
  (local $2 (ref null $type110))
  (local $3 (ref $environment280))
  (local $4 (ref $type94))
  (if (result i32)
   (local.get $1)
   (then
    (local.get $1)
   )
   (else
    (local.set $2
     (struct.get $type110 1
      (struct.get $environment281 1
       (local.get $0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type201 0
       (struct.get $environment281 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type199 0
      (struct.get $type201 1
       (struct.get $environment281 0
        (local.get $0)
       )
      )
     )
    )
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 0)
     )
     (else
      (return_call $function281
       (struct.new $environment281
        (struct.get $environment280 1
         (local.get $3)
        )
        (local.get $2)
       )
       (call_ref $call94
        (struct.get $type94 1
         (local.tee $4
          (struct.get $type110 0
           (local.get $2)
          )
         )
        )
        (struct.get $environment280 0
         (local.get $3)
        )
        (struct.get $type94 0
         (local.get $4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function283 (type $21) (param $0 i64) (param $1 (ref $type84)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 i64)
  (local $4 i64)
  (drop
   (struct.get $type61 1
    (global.get $global363)
   )
  )
  (if
   (i64.eqz
    (local.get $0)
   )
   (then
    (return_call_ref $call84
     (struct.get $type84 1
      (local.get $1)
     )
     (ref.null none)
     (local.get $2)
     (struct.get $type84 0
      (local.get $1)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready504)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global504)
     )
    )
    (local.set $2
     (call $function283
      (local.get $4)
      (struct.new $type84
       (ref.func $function285)
       (struct.new $environment285
        (local.get $1)
       )
      )
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready504)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global504)
     )
    )
    (return_call $function283
     (local.get $3)
     (struct.new $type84
      (ref.func $function284)
      (struct.new $environment284
       (local.get $1)
      )
     )
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function284 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type84))
  (return_call_ref $call84
   (struct.get $type84 1
    (local.tee $3
     (struct.get $environment284 0
      (ref.cast (ref $environment284)
       (local.get $0)
      )
     )
    )
   )
   (struct.new $type30
    (i64.const -1)
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type84 0
    (local.get $3)
   )
  )
 )
 (func $function285 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type84))
  (return_call_ref $call84
   (struct.get $type84 1
    (local.tee $3
     (struct.get $environment285 0
      (ref.cast (ref $environment285)
       (local.get $0)
      )
     )
    )
   )
   (struct.new $type30
    (i64.const 1)
    (local.get $1)
   )
   (local.get $2)
   (struct.get $type84 0
    (local.get $3)
   )
  )
 )
 (func $function286 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (struct.new $type32
   (struct.new $type30
    (i64.const 1)
    (local.get $1)
   )
   (local.get $2)
  )
 )
 (func $function290 (type $call204) (param $0 (ref $environment290)) (param $1 i64) (param $2 (ref $type32)) (param $3 (ref null $type32)) (param $4 (ref $type104)) (result (ref $type104))
  (local $5 (ref $type124))
  (local $6 (ref $type122))
  (local $7 (ref $type208))
  (local $8 (ref $type93))
  (local $9 (ref $type103))
  (local $10 (ref $type94))
  (local.set $10
   (if (result (ref $type94))
    (i64.gt_s
     (struct.get $environment290 0
      (local.get $0)
     )
     (local.get $1)
    )
    (then
     (call_ref $call93
      (struct.get $type93 1
       (local.tee $8
        (struct.get $environment290 2
         (local.get $0)
        )
       )
      )
      (local.get $2)
      (struct.get $type93 0
       (local.get $8)
      )
     )
    )
    (else
     (call_ref $call93
      (struct.get $type93 1
       (local.tee $8
        (struct.get $environment290 3
         (local.get $0)
        )
       )
      )
      (local.get $2)
      (struct.get $type93 0
       (local.get $8)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready520)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global520)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (struct.set $type124 1
   (local.tee $5
    (struct.new_default $type124)
   )
   (struct.new $type122
    (ref.func $function85)
    (struct.new $environment85
     (struct.new $type84
      (ref.func $function292)
      (struct.new $environment292
       (local.get $10)
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type124 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type124 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (call_ref $call122
    (struct.get $type122 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type124 1
        (local.get $5)
       )
      )
     )
    )
    (local.get $3)
    (ref.null none)
    (struct.get $type122 0
     (local.get $6)
    )
   )
  )
  (drop
   (struct.get $type55 1
    (global.get $global265)
   )
  )
  (struct.set $type124 1
   (local.tee $5
    (struct.new_default $type124)
   )
   (struct.new $type122
    (ref.func $function130)
    (struct.new $environment130
     (local.get $5)
    )
   )
  )
  (struct.set $type124 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type124 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.is_null
    (local.tee $3
     (call_ref $call122
      (struct.get $type122 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type124 1
          (local.get $5)
         )
        )
       )
      )
      (local.get $3)
      (ref.null none)
      (struct.get $type122 0
       (local.get $6)
      )
     )
    )
   )
   (then
    (drop
     (struct.get $type55 1
      (global.get $global265)
     )
    )
    (struct.set $type124 1
     (local.tee $5
      (struct.new_default $type124)
     )
     (struct.new $type122
      (ref.func $function130)
      (struct.new $environment130
       (local.get $5)
      )
     )
    )
    (struct.set $type124 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type124 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call103
     (struct.get $type103 1
      (local.tee $9
       (struct.get $environment290 1
        (local.get $0)
       )
      )
     )
     (call_ref $call122
      (struct.get $type122 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type124 1
          (local.get $5)
         )
        )
       )
      )
      (local.get $2)
      (ref.null none)
      (struct.get $type122 0
       (local.get $6)
      )
     )
     (local.get $4)
     (struct.get $type103 0
      (local.get $9)
     )
    )
   )
   (else
    (struct.set $type208 1
     (local.tee $7
      (struct.new_default $type208)
     )
     (struct.new $type103
      (ref.func $function295)
      (struct.new $environment295
       (struct.get $environment290 4
        (local.get $0)
       )
       (local.get $1)
       (local.get $2)
       (local.get $7)
      )
     )
    )
    (struct.set $type208 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call103
     (struct.get $type103 1
      (local.tee $9
       (ref.as_non_null
        (struct.get $type208 1
         (local.get $7)
        )
       )
      )
     )
     (local.get $3)
     (local.get $4)
     (struct.get $type103 0
      (local.get $9)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function292 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (local $3 (ref $type94))
  (if (result (ref null $type32))
   (call_ref $call94
    (struct.get $type94 1
     (local.tee $3
      (struct.get $environment292 0
       (ref.cast (ref $environment292)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type94 0
     (local.get $3)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type32
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function295 (type $call103) (param $0 (ref null $environment295)) (param $1 (ref null $type32)) (param $2 (ref $type104)) (result (ref $type104))
  (local $3 (ref $type124))
  (local $4 (ref $type208))
  (local $5 (ref $type206))
  (local $6 (ref null $type32))
  (local $7 (ref $type32))
  (local $8 (ref $type122))
  (local $9 i64)
  (local $10 i64)
  (if (result (ref $type104))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $environment295 3
      (local.get $0)
     )
    )
    (local.set $5
     (struct.get $environment295 0
      (local.get $0)
     )
    )
    (local.set $9
     (struct.get $environment295 1
      (local.get $0)
     )
    )
    (local.set $6
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (local.set $7
     (struct.new $type32
      (struct.get $type32 0
       (local.get $1)
      )
      (struct.get $environment295 2
       (local.get $0)
      )
     )
    )
    (drop
     (struct.get $type55 1
      (global.get $global265)
     )
    )
    (struct.set $type124 1
     (local.tee $3
      (struct.new_default $type124)
     )
     (struct.new $type122
      (ref.func $function130)
      (struct.new $environment130
       (local.get $3)
      )
     )
    )
    (struct.set $type124 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type124 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call122
      (struct.get $type122 1
       (local.tee $8
        (ref.as_non_null
         (struct.get $type124 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $7)
      (ref.null none)
      (struct.get $type122 0
       (local.get $8)
      )
     )
    )
    (if
     (call $function75
      (struct.get $type77 1
       (global.get $global170)
      )
      (local.get $1)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $9)
          (local.tee $10
           (i64.add
            (local.get $9)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $10)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type206 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (call $function290
        (struct.get $type204 0
         (struct.get $type206 1
          (local.get $5)
         )
        )
        (local.get $10)
        (local.get $7)
        (local.get $6)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type208 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function295
     (struct.get $type103 1
      (struct.get $type208 1
       (local.get $4)
      )
     )
     (local.get $6)
     (local.get $2)
    )
   )
  )
 )
 (func $function300 (type $14) (result i64)
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type111))
  (local $scratch i64)
  (local.set $scratch
   (call $foreign1
    (struct.get $type111 0
     (global.get $global532)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $0
       (i64.add
        (local.tee $2
         (struct.get $type111 0
          (local.tee $3
           (ref.as_non_null
            (global.get $global532)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 1)
     )
     (i64.xor
      (local.get $0)
      (local.get $2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type111 0
   (local.get $3)
   (local.get $0)
  )
  (local.get $scratch)
 )
 (func $function302 (type $call15) (param $0 (ref null $environment305)) (param $1 i64) (result (ref $type16))
  (local $2 (ref $type211))
  (local $3 (ref $type15))
  (drop
   (struct.get $type15 1
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type211 1
   (local.tee $2
    (struct.new_default $type211)
   )
   (struct.new $type15
    (ref.func $function305)
    (struct.new $environment305
     (local.get $1)
     (call $string-new
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type211 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type211 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call15
   (struct.get $type15 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type211 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type15 0
    (local.get $3)
   )
  )
 )
 (func $function305 (type $call15) (param $0 (ref null $environment305)) (param $1 i64) (result (ref $type16))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type16))
  (local $7 (ref $type111))
  (if (result (ref $type16))
   (i64.eq
    (struct.get $environment305 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $environment305 1
     (local.get $0)
    )
   )
   (else
    (local.set $6
     (struct.get $environment305 1
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global533)
     )
    )
    (local.set $2
     (call $foreign1
      (struct.get $type111 0
       (global.get $global532)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.tee $4
           (struct.get $type111 0
            (local.tee $7
             (ref.as_non_null
              (global.get $global532)
             )
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 1)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type111 0
     (local.get $7)
     (local.get $3)
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $2)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $2)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (local.get $6)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 2
        (local.get $6)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 3
          (local.get $6)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type211 0
       (struct.get $environment305 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function305
     (struct.get $type15 1
      (struct.get $type211 1
       (struct.get $environment305 2
        (local.get $0)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function306 (type $11) (param $0 i64) (result (ref null $type54))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type111))
  (local $6 (ref $type211))
  (local $7 (ref $type15))
  (local $8 (ref $type49))
  (local $scratch i64)
  (if (result (ref null $type54))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global533)
     )
    )
    (struct.new $type54
     (if (result (ref $type49))
      (i64.eqz
       (block (result i64)
        (local.set $scratch
         (call $foreign1
          (struct.get $type111 0
           (global.get $global532)
          )
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $1
             (i64.add
              (local.tee $3
               (struct.get $type111 0
                (local.tee $5
                 (ref.as_non_null
                  (global.get $global532)
                 )
                )
               )
              )
              (i64.const 1)
             )
            )
            (i64.const 1)
           )
           (i64.xor
            (local.get $1)
            (local.get $3)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type111 0
         (local.get $5)
         (local.get $1)
        )
        (local.get $scratch)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global533)
        )
       )
       (local.set $2
        (call $foreign1
         (struct.get $type111 0
          (global.get $global532)
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $1
            (i64.add
             (local.tee $3
              (struct.get $type111 0
               (local.tee $5
                (ref.as_non_null
                 (global.get $global532)
                )
               )
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 1)
          )
          (i64.xor
           (local.get $1)
           (local.get $3)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type111 0
        (local.get $5)
        (local.get $1)
       )
       (drop
        (ref.as_non_null
         (global.get $global546)
        )
       )
       (struct.new $type50
        (if (result (ref null $type32))
         (i64.eqz
          (local.get $2)
         )
         (then
          (ref.null none)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global533)
           )
          )
          (local.set $1
           (call $foreign1
            (struct.get $type111 0
             (global.get $global532)
            )
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $3
               (i64.add
                (local.tee $4
                 (struct.get $type111 0
                  (local.tee $5
                   (ref.as_non_null
                    (global.get $global532)
                   )
                  )
                 )
                )
                (i64.const 1)
               )
              )
              (i64.const 1)
             )
             (i64.xor
              (local.get $3)
              (local.get $4)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (struct.set $type111 0
           (local.get $5)
           (local.get $3)
          )
          (drop
           (struct.get $type85 1
            (global.get $global548)
           )
          )
          (call $function310
           (struct.new $environment310
            (local.get $2)
           )
           (if (result (ref null $type30))
            (i64.eqz
             (local.get $1)
            )
            (then
             (ref.null none)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global533)
              )
             )
             (struct.new $type30
              (call $foreign1
               (struct.get $type111 0
                (global.get $global532)
               )
              )
              (block (result (ref null $type30))
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $2
                    (i64.add
                     (local.tee $4
                      (struct.get $type111 0
                       (local.tee $5
                        (ref.as_non_null
                         (global.get $global532)
                        )
                       )
                      )
                     )
                     (i64.const 1)
                    )
                   )
                   (i64.const 1)
                  )
                  (i64.xor
                   (local.get $2)
                   (local.get $4)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (struct.set $type111 0
                (local.get $5)
                (local.get $2)
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $2
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (local.get $1)
                  )
                  (i64.xor
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready548)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (struct.get $type85 1
                 (global.get $global548)
                )
               )
               (if (result (ref null $type30))
                (i64.eqz
                 (local.get $2)
                )
                (then
                 (ref.null none)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global533)
                  )
                 )
                 (struct.new $type30
                  (call $foreign1
                   (struct.get $type111 0
                    (global.get $global532)
                   )
                  )
                  (block (result (ref null $type30))
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $1
                        (i64.add
                         (local.tee $4
                          (struct.get $type111 0
                           (local.tee $5
                            (ref.as_non_null
                             (global.get $global532)
                            )
                           )
                          )
                         )
                         (i64.const 1)
                        )
                       )
                       (i64.const 1)
                      )
                      (i64.xor
                       (local.get $1)
                       (local.get $4)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (struct.set $type111 0
                    (local.get $5)
                    (local.get $1)
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $1
                        (i64.sub
                         (local.get $2)
                         (i64.const 1)
                        )
                       )
                       (local.get $2)
                      )
                      (i64.xor
                       (local.get $2)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready548)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (struct.get $type85 1
                     (global.get $global548)
                    )
                   )
                   (if (result (ref null $type30))
                    (i64.eqz
                     (local.get $1)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global533)
                      )
                     )
                     (struct.new $type30
                      (call $foreign1
                       (struct.get $type111 0
                        (global.get $global532)
                       )
                      )
                      (block (result (ref null $type30))
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $2
                            (i64.add
                             (local.tee $4
                              (struct.get $type111 0
                               (local.tee $5
                                (ref.as_non_null
                                 (global.get $global532)
                                )
                               )
                              )
                             )
                             (i64.const 1)
                            )
                           )
                           (i64.const 1)
                          )
                          (i64.xor
                           (local.get $2)
                           (local.get $4)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.set $type111 0
                        (local.get $5)
                        (local.get $2)
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $2
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (local.get $1)
                          )
                          (i64.xor
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready548)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (struct.get $type85 1
                         (global.get $global548)
                        )
                       )
                       (if (result (ref null $type30))
                        (i64.eqz
                         (local.get $2)
                        )
                        (then
                         (ref.null none)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global533)
                          )
                         )
                         (struct.new $type30
                          (call $foreign1
                           (struct.get $type111 0
                            (global.get $global532)
                           )
                          )
                          (block (result (ref null $type30))
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.tee $1
                                (i64.add
                                 (local.tee $4
                                  (struct.get $type111 0
                                   (local.tee $5
                                    (ref.as_non_null
                                     (global.get $global532)
                                    )
                                   )
                                  )
                                 )
                                 (i64.const 1)
                                )
                               )
                               (i64.const 1)
                              )
                              (i64.xor
                               (local.get $1)
                               (local.get $4)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (struct.set $type111 0
                            (local.get $5)
                            (local.get $1)
                           )
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.tee $1
                                (i64.sub
                                 (local.get $2)
                                 (i64.const 1)
                                )
                               )
                               (local.get $2)
                              )
                              (i64.xor
                               (local.get $2)
                               (i64.const 1)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready548)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (struct.get $type85 1
                             (global.get $global548)
                            )
                           )
                           (if (result (ref null $type30))
                            (i64.eqz
                             (local.get $1)
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global533)
                              )
                             )
                             (struct.new $type30
                              (call $foreign1
                               (struct.get $type111 0
                                (global.get $global532)
                               )
                              )
                              (block (result (ref null $type30))
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.tee $2
                                    (i64.add
                                     (local.tee $4
                                      (struct.get $type111 0
                                       (local.tee $5
                                        (ref.as_non_null
                                         (global.get $global532)
                                        )
                                       )
                                      )
                                     )
                                     (i64.const 1)
                                    )
                                   )
                                   (i64.const 1)
                                  )
                                  (i64.xor
                                   (local.get $2)
                                   (local.get $4)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (struct.set $type111 0
                                (local.get $5)
                                (local.get $2)
                               )
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.tee $2
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                   (local.get $1)
                                  )
                                  (i64.xor
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready548)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (struct.get $type85 1
                                 (global.get $global548)
                                )
                               )
                               (if (result (ref null $type30))
                                (i64.eqz
                                 (local.get $2)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global533)
                                  )
                                 )
                                 (struct.new $type30
                                  (call $foreign1
                                   (struct.get $type111 0
                                    (global.get $global532)
                                   )
                                  )
                                  (block (result (ref null $type30))
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.tee $1
                                        (i64.add
                                         (local.tee $4
                                          (struct.get $type111 0
                                           (local.tee $5
                                            (ref.as_non_null
                                             (global.get $global532)
                                            )
                                           )
                                          )
                                         )
                                         (i64.const 1)
                                        )
                                       )
                                       (i64.const 1)
                                      )
                                      (i64.xor
                                       (local.get $1)
                                       (local.get $4)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (struct.set $type111 0
                                    (local.get $5)
                                    (local.get $1)
                                   )
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.tee $1
                                        (i64.sub
                                         (local.get $2)
                                         (i64.const 1)
                                        )
                                       )
                                       (local.get $2)
                                      )
                                      (i64.xor
                                       (local.get $2)
                                       (i64.const 1)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready548)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (struct.get $type85 1
                                     (global.get $global548)
                                    )
                                   )
                                   (if (result (ref null $type30))
                                    (i64.eqz
                                     (local.get $1)
                                    )
                                    (then
                                     (ref.null none)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global533)
                                      )
                                     )
                                     (struct.new $type30
                                      (call $foreign1
                                       (struct.get $type111 0
                                        (global.get $global532)
                                       )
                                      )
                                      (block (result (ref null $type30))
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.tee $2
                                            (i64.add
                                             (local.tee $4
                                              (struct.get $type111 0
                                               (local.tee $5
                                                (ref.as_non_null
                                                 (global.get $global532)
                                                )
                                               )
                                              )
                                             )
                                             (i64.const 1)
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (i64.xor
                                           (local.get $2)
                                           (local.get $4)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (struct.set $type111 0
                                        (local.get $5)
                                        (local.get $2)
                                       )
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.tee $2
                                            (i64.sub
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                           (local.get $1)
                                          )
                                          (i64.xor
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready548)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (struct.get $type85 1
                                         (global.get $global548)
                                        )
                                       )
                                       (if (result (ref null $type30))
                                        (i64.eqz
                                         (local.get $2)
                                        )
                                        (then
                                         (ref.null none)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global533)
                                          )
                                         )
                                         (struct.new $type30
                                          (call $foreign1
                                           (struct.get $type111 0
                                            (global.get $global532)
                                           )
                                          )
                                          (block (result (ref null $type30))
                                           (if
                                            (i64.lt_s
                                             (i64.and
                                              (i64.xor
                                               (local.tee $1
                                                (i64.add
                                                 (local.tee $4
                                                  (struct.get $type111 0
                                                   (local.tee $5
                                                    (ref.as_non_null
                                                     (global.get $global532)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (i64.const 1)
                                                )
                                               )
                                               (i64.const 1)
                                              )
                                              (i64.xor
                                               (local.get $1)
                                               (local.get $4)
                                              )
                                             )
                                             (i64.const 0)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (struct.set $type111 0
                                            (local.get $5)
                                            (local.get $1)
                                           )
                                           (if
                                            (i64.lt_s
                                             (i64.and
                                              (i64.xor
                                               (local.tee $1
                                                (i64.sub
                                                 (local.get $2)
                                                 (i64.const 1)
                                                )
                                               )
                                               (local.get $2)
                                              )
                                              (i64.xor
                                               (local.get $2)
                                               (i64.const 1)
                                              )
                                             )
                                             (i64.const 0)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready548)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (struct.get $type85 1
                                             (global.get $global548)
                                            )
                                           )
                                           (if (result (ref null $type30))
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (ref.null none)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global533)
                                              )
                                             )
                                             (struct.new $type30
                                              (call $foreign1
                                               (struct.get $type111 0
                                                (global.get $global532)
                                               )
                                              )
                                              (block (result (ref null $type30))
                                               (if
                                                (i64.lt_s
                                                 (i64.and
                                                  (i64.xor
                                                   (local.tee $2
                                                    (i64.add
                                                     (local.tee $4
                                                      (struct.get $type111 0
                                                       (local.tee $5
                                                        (ref.as_non_null
                                                         (global.get $global532)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (i64.const 1)
                                                    )
                                                   )
                                                   (i64.const 1)
                                                  )
                                                  (i64.xor
                                                   (local.get $2)
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 0)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.set $type111 0
                                                (local.get $5)
                                                (local.get $2)
                                               )
                                               (if
                                                (i64.lt_s
                                                 (i64.and
                                                  (i64.xor
                                                   (local.tee $2
                                                    (i64.sub
                                                     (local.get $1)
                                                     (i64.const 1)
                                                    )
                                                   )
                                                   (local.get $1)
                                                  )
                                                  (i64.xor
                                                   (local.get $1)
                                                   (i64.const 1)
                                                  )
                                                 )
                                                 (i64.const 0)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready548)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (struct.get $type85 1
                                                 (global.get $global548)
                                                )
                                               )
                                               (if (result (ref null $type30))
                                                (i64.eqz
                                                 (local.get $2)
                                                )
                                                (then
                                                 (ref.null none)
                                                )
                                                (else
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global533)
                                                  )
                                                 )
                                                 (struct.new $type30
                                                  (call $foreign1
                                                   (struct.get $type111 0
                                                    (global.get $global532)
                                                   )
                                                  )
                                                  (block (result (ref null $type30))
                                                   (if
                                                    (i64.lt_s
                                                     (i64.and
                                                      (i64.xor
                                                       (local.tee $1
                                                        (i64.add
                                                         (local.tee $4
                                                          (struct.get $type111 0
                                                           (local.tee $5
                                                            (ref.as_non_null
                                                             (global.get $global532)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (i64.const 1)
                                                        )
                                                       )
                                                       (i64.const 1)
                                                      )
                                                      (i64.xor
                                                       (local.get $1)
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 0)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (struct.set $type111 0
                                                    (local.get $5)
                                                    (local.get $1)
                                                   )
                                                   (if
                                                    (i64.lt_s
                                                     (i64.and
                                                      (i64.xor
                                                       (local.tee $1
                                                        (i64.sub
                                                         (local.get $2)
                                                         (i64.const 1)
                                                        )
                                                       )
                                                       (local.get $2)
                                                      )
                                                      (i64.xor
                                                       (local.get $2)
                                                       (i64.const 1)
                                                      )
                                                     )
                                                     (i64.const 0)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready548)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (struct.get $type85 1
                                                     (global.get $global548)
                                                    )
                                                   )
                                                   (if (result (ref null $type30))
                                                    (i64.eqz
                                                     (local.get $1)
                                                    )
                                                    (then
                                                     (ref.null none)
                                                    )
                                                    (else
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global533)
                                                      )
                                                     )
                                                     (struct.new $type30
                                                      (call $foreign1
                                                       (struct.get $type111 0
                                                        (global.get $global532)
                                                       )
                                                      )
                                                      (block (result (ref null $type30))
                                                       (if
                                                        (i64.lt_s
                                                         (i64.and
                                                          (i64.xor
                                                           (local.tee $2
                                                            (i64.add
                                                             (local.tee $4
                                                              (struct.get $type111 0
                                                               (local.tee $5
                                                                (ref.as_non_null
                                                                 (global.get $global532)
                                                                )
                                                               )
                                                              )
                                                             )
                                                             (i64.const 1)
                                                            )
                                                           )
                                                           (i64.const 1)
                                                          )
                                                          (i64.xor
                                                           (local.get $2)
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 0)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (struct.set $type111 0
                                                        (local.get $5)
                                                        (local.get $2)
                                                       )
                                                       (if
                                                        (i64.lt_s
                                                         (i64.and
                                                          (i64.xor
                                                           (local.tee $2
                                                            (i64.sub
                                                             (local.get $1)
                                                             (i64.const 1)
                                                            )
                                                           )
                                                           (local.get $1)
                                                          )
                                                          (i64.xor
                                                           (local.get $1)
                                                           (i64.const 1)
                                                          )
                                                         )
                                                         (i64.const 0)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready548)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (struct.get $type85 1
                                                         (global.get $global548)
                                                        )
                                                       )
                                                       (if (result (ref null $type30))
                                                        (i64.eqz
                                                         (local.get $2)
                                                        )
                                                        (then
                                                         (ref.null none)
                                                        )
                                                        (else
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global533)
                                                          )
                                                         )
                                                         (struct.new $type30
                                                          (call $foreign1
                                                           (struct.get $type111 0
                                                            (global.get $global532)
                                                           )
                                                          )
                                                          (block (result (ref null $type30))
                                                           (if
                                                            (i64.lt_s
                                                             (i64.and
                                                              (i64.xor
                                                               (local.tee $1
                                                                (i64.add
                                                                 (local.tee $3
                                                                  (struct.get $type111 0
                                                                   (local.tee $5
                                                                    (ref.as_non_null
                                                                     (global.get $global532)
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                 (i64.const 1)
                                                                )
                                                               )
                                                               (i64.const 1)
                                                              )
                                                              (i64.xor
                                                               (local.get $1)
                                                               (local.get $3)
                                                              )
                                                             )
                                                             (i64.const 0)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (struct.set $type111 0
                                                            (local.get $5)
                                                            (local.get $1)
                                                           )
                                                           (if
                                                            (i64.lt_s
                                                             (i64.and
                                                              (i64.xor
                                                               (local.tee $3
                                                                (i64.sub
                                                                 (local.get $2)
                                                                 (i64.const 1)
                                                                )
                                                               )
                                                               (local.get $2)
                                                              )
                                                              (i64.xor
                                                               (local.get $2)
                                                               (i64.const 1)
                                                              )
                                                             )
                                                             (i64.const 0)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (if
                                                            (i32.eqz
                                                             (global.get $ready548)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (drop
                                                            (struct.get $type85 1
                                                             (global.get $global548)
                                                            )
                                                           )
                                                           (if (result (ref null $type30))
                                                            (i64.eqz
                                                             (local.get $3)
                                                            )
                                                            (then
                                                             (ref.null none)
                                                            )
                                                            (else
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global533)
                                                              )
                                                             )
                                                             (struct.new $type30
                                                              (call $foreign1
                                                               (struct.get $type111 0
                                                                (global.get $global532)
                                                               )
                                                              )
                                                              (block (result (ref null $type30))
                                                               (if
                                                                (i64.lt_s
                                                                 (i64.and
                                                                  (i64.xor
                                                                   (local.tee $1
                                                                    (i64.add
                                                                     (local.tee $4
                                                                      (struct.get $type111 0
                                                                       (local.tee $5
                                                                        (ref.as_non_null
                                                                         (global.get $global532)
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                     (i64.const 1)
                                                                    )
                                                                   )
                                                                   (i64.const 1)
                                                                  )
                                                                  (i64.xor
                                                                   (local.get $1)
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 0)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (struct.set $type111 0
                                                                (local.get $5)
                                                                (local.get $1)
                                                               )
                                                               (if
                                                                (i64.lt_s
                                                                 (i64.and
                                                                  (i64.xor
                                                                   (local.tee $1
                                                                    (i64.sub
                                                                     (local.get $3)
                                                                     (i64.const 1)
                                                                    )
                                                                   )
                                                                   (local.get $3)
                                                                  )
                                                                  (i64.xor
                                                                   (local.get $3)
                                                                   (i64.const 1)
                                                                  )
                                                                 )
                                                                 (i64.const 0)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (if
                                                                (i32.eqz
                                                                 (global.get $ready548)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (drop
                                                                (struct.get $type85 1
                                                                 (global.get $global548)
                                                                )
                                                               )
                                                               (if (result (ref null $type30))
                                                                (i64.eqz
                                                                 (local.get $1)
                                                                )
                                                                (then
                                                                 (ref.null none)
                                                                )
                                                                (else
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global533)
                                                                  )
                                                                 )
                                                                 (struct.new $type30
                                                                  (call $function300)
                                                                  (block (result (ref null $type30))
                                                                   (if
                                                                    (i64.lt_s
                                                                     (i64.and
                                                                      (i64.xor
                                                                       (local.tee $3
                                                                        (i64.sub
                                                                         (local.get $1)
                                                                         (i64.const 1)
                                                                        )
                                                                       )
                                                                       (local.get $1)
                                                                      )
                                                                      (i64.xor
                                                                       (local.get $1)
                                                                       (i64.const 1)
                                                                      )
                                                                     )
                                                                     (i64.const 0)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (if
                                                                    (i32.eqz
                                                                     (global.get $ready548)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (call $function308
                                                                    (struct.get $type85 1
                                                                     (global.get $global548)
                                                                    )
                                                                    (local.get $3)
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global533)
        )
       )
       (local.set $1
        (call $foreign1
         (struct.get $type111 0
          (global.get $global532)
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $2
            (i64.add
             (local.tee $3
              (struct.get $type111 0
               (local.tee $5
                (ref.as_non_null
                 (global.get $global532)
                )
               )
              )
             )
             (i64.const 1)
            )
           )
           (i64.const 1)
          )
          (i64.xor
           (local.get $2)
           (local.get $3)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type111 0
        (local.get $5)
        (local.get $2)
       )
       (if
        (i32.eqz
         (global.get $ready535)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type15 1
         (global.get $global535)
        )
       )
       (drop
        (struct.get $type15 1
         (global.get $global61)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type211 1
        (local.tee $6
         (struct.new_default $type211)
        )
        (struct.new $type15
         (ref.func $function305)
         (struct.new $environment305
          (local.get $1)
          (call $string-new
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (local.get $6)
         )
        )
       )
       (struct.set $type211 0
        (local.get $6)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type211 0
          (local.get $6)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type51
        (call_ref $call15
         (struct.get $type15 1
          (local.tee $7
           (ref.as_non_null
            (struct.get $type211 1
             (local.get $6)
            )
           )
          )
         )
         (i64.const 0)
         (struct.get $type15 0
          (local.get $7)
         )
        )
       )
      )
     )
     (block (result (ref null $type54))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready544)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global544)
       )
      )
      (call $function306
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function308 (type $call85) (param $0 (ref null $environment112)) (param $1 i64) (result (ref null $type30))
  (local $2 i64)
  (local $3 i64)
  (if (result (ref null $type30))
   (i64.eqz
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global533)
     )
    )
    (struct.new $type30
     (call $function300)
     (block (result (ref null $type30))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready548)
       )
       (then
        (unreachable)
       )
      )
      (call $function308
       (struct.get $type85 1
        (global.get $global548)
       )
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function310 (type $9) (param $0 (ref $environment310)) (param $1 (ref null $type30)) (result (ref $type32))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type111))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.sub
        (local.tee $2
         (struct.get $environment310 0
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready546)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global546)
   )
  )
  (struct.new $type32
   (local.get $1)
   (if (result (ref null $type32))
    (i64.eqz
     (local.get $3)
    )
    (then
     (ref.null none)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global533)
      )
     )
     (local.set $2
      (call $foreign1
       (struct.get $type111 0
        (global.get $global532)
       )
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $4
          (i64.add
           (local.tee $5
            (struct.get $type111 0
             (local.tee $6
              (ref.as_non_null
               (global.get $global532)
              )
             )
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 1)
        )
        (i64.xor
         (local.get $4)
         (local.get $5)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (struct.set $type111 0
      (local.get $6)
      (local.get $4)
     )
     (drop
      (struct.get $type85 1
       (global.get $global548)
      )
     )
     (call $function310
      (struct.new $environment310
       (local.get $3)
      )
      (if (result (ref null $type30))
       (i64.eqz
        (local.get $2)
       )
       (then
        (ref.null none)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global533)
         )
        )
        (struct.new $type30
         (call $foreign1
          (struct.get $type111 0
           (global.get $global532)
          )
         )
         (block (result (ref null $type30))
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $3
               (i64.add
                (local.tee $5
                 (struct.get $type111 0
                  (local.tee $6
                   (ref.as_non_null
                    (global.get $global532)
                   )
                  )
                 )
                )
                (i64.const 1)
               )
              )
              (i64.const 1)
             )
             (i64.xor
              (local.get $3)
              (local.get $5)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (struct.set $type111 0
           (local.get $6)
           (local.get $3)
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $3
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
              (local.get $2)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready548)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (struct.get $type85 1
            (global.get $global548)
           )
          )
          (if (result (ref null $type30))
           (i64.eqz
            (local.get $3)
           )
           (then
            (ref.null none)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global533)
             )
            )
            (struct.new $type30
             (call $foreign1
              (struct.get $type111 0
               (global.get $global532)
              )
             )
             (block (result (ref null $type30))
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $2
                   (i64.add
                    (local.tee $5
                     (struct.get $type111 0
                      (local.tee $6
                       (ref.as_non_null
                        (global.get $global532)
                       )
                      )
                     )
                    )
                    (i64.const 1)
                   )
                  )
                  (i64.const 1)
                 )
                 (i64.xor
                  (local.get $2)
                  (local.get $5)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (struct.set $type111 0
               (local.get $6)
               (local.get $2)
              )
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $2
                   (i64.sub
                    (local.get $3)
                    (i64.const 1)
                   )
                  )
                  (local.get $3)
                 )
                 (i64.xor
                  (local.get $3)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready548)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (struct.get $type85 1
                (global.get $global548)
               )
              )
              (if (result (ref null $type30))
               (i64.eqz
                (local.get $2)
               )
               (then
                (ref.null none)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global533)
                 )
                )
                (struct.new $type30
                 (call $foreign1
                  (struct.get $type111 0
                   (global.get $global532)
                  )
                 )
                 (block (result (ref null $type30))
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $3
                       (i64.add
                        (local.tee $5
                         (struct.get $type111 0
                          (local.tee $6
                           (ref.as_non_null
                            (global.get $global532)
                           )
                          )
                         )
                        )
                        (i64.const 1)
                       )
                      )
                      (i64.const 1)
                     )
                     (i64.xor
                      (local.get $3)
                      (local.get $5)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.set $type111 0
                   (local.get $6)
                   (local.get $3)
                  )
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $3
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (local.get $2)
                     )
                     (i64.xor
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready548)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (struct.get $type85 1
                    (global.get $global548)
                   )
                  )
                  (if (result (ref null $type30))
                   (i64.eqz
                    (local.get $3)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global533)
                     )
                    )
                    (struct.new $type30
                     (call $foreign1
                      (struct.get $type111 0
                       (global.get $global532)
                      )
                     )
                     (block (result (ref null $type30))
                      (if
                       (i64.lt_s
                        (i64.and
                         (i64.xor
                          (local.tee $2
                           (i64.add
                            (local.tee $5
                             (struct.get $type111 0
                              (local.tee $6
                               (ref.as_non_null
                                (global.get $global532)
                               )
                              )
                             )
                            )
                            (i64.const 1)
                           )
                          )
                          (i64.const 1)
                         )
                         (i64.xor
                          (local.get $2)
                          (local.get $5)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (struct.set $type111 0
                       (local.get $6)
                       (local.get $2)
                      )
                      (if
                       (i64.lt_s
                        (i64.and
                         (i64.xor
                          (local.tee $2
                           (i64.sub
                            (local.get $3)
                            (i64.const 1)
                           )
                          )
                          (local.get $3)
                         )
                         (i64.xor
                          (local.get $3)
                          (i64.const 1)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready548)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (struct.get $type85 1
                        (global.get $global548)
                       )
                      )
                      (if (result (ref null $type30))
                       (i64.eqz
                        (local.get $2)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global533)
                         )
                        )
                        (struct.new $type30
                         (call $foreign1
                          (struct.get $type111 0
                           (global.get $global532)
                          )
                         )
                         (block (result (ref null $type30))
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $3
                               (i64.add
                                (local.tee $5
                                 (struct.get $type111 0
                                  (local.tee $6
                                   (ref.as_non_null
                                    (global.get $global532)
                                   )
                                  )
                                 )
                                )
                                (i64.const 1)
                               )
                              )
                              (i64.const 1)
                             )
                             (i64.xor
                              (local.get $3)
                              (local.get $5)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.set $type111 0
                           (local.get $6)
                           (local.get $3)
                          )
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $3
                               (i64.sub
                                (local.get $2)
                                (i64.const 1)
                               )
                              )
                              (local.get $2)
                             )
                             (i64.xor
                              (local.get $2)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready548)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (struct.get $type85 1
                            (global.get $global548)
                           )
                          )
                          (if (result (ref null $type30))
                           (i64.eqz
                            (local.get $3)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global533)
                             )
                            )
                            (struct.new $type30
                             (call $foreign1
                              (struct.get $type111 0
                               (global.get $global532)
                              )
                             )
                             (block (result (ref null $type30))
                              (if
                               (i64.lt_s
                                (i64.and
                                 (i64.xor
                                  (local.tee $2
                                   (i64.add
                                    (local.tee $5
                                     (struct.get $type111 0
                                      (local.tee $6
                                       (ref.as_non_null
                                        (global.get $global532)
                                       )
                                      )
                                     )
                                    )
                                    (i64.const 1)
                                   )
                                  )
                                  (i64.const 1)
                                 )
                                 (i64.xor
                                  (local.get $2)
                                  (local.get $5)
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (struct.set $type111 0
                               (local.get $6)
                               (local.get $2)
                              )
                              (if
                               (i64.lt_s
                                (i64.and
                                 (i64.xor
                                  (local.tee $2
                                   (i64.sub
                                    (local.get $3)
                                    (i64.const 1)
                                   )
                                  )
                                  (local.get $3)
                                 )
                                 (i64.xor
                                  (local.get $3)
                                  (i64.const 1)
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready548)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (struct.get $type85 1
                                (global.get $global548)
                               )
                              )
                              (if (result (ref null $type30))
                               (i64.eqz
                                (local.get $2)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global533)
                                 )
                                )
                                (struct.new $type30
                                 (call $foreign1
                                  (struct.get $type111 0
                                   (global.get $global532)
                                  )
                                 )
                                 (block (result (ref null $type30))
                                  (if
                                   (i64.lt_s
                                    (i64.and
                                     (i64.xor
                                      (local.tee $3
                                       (i64.add
                                        (local.tee $5
                                         (struct.get $type111 0
                                          (local.tee $6
                                           (ref.as_non_null
                                            (global.get $global532)
                                           )
                                          )
                                         )
                                        )
                                        (i64.const 1)
                                       )
                                      )
                                      (i64.const 1)
                                     )
                                     (i64.xor
                                      (local.get $3)
                                      (local.get $5)
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.set $type111 0
                                   (local.get $6)
                                   (local.get $3)
                                  )
                                  (if
                                   (i64.lt_s
                                    (i64.and
                                     (i64.xor
                                      (local.tee $3
                                       (i64.sub
                                        (local.get $2)
                                        (i64.const 1)
                                       )
                                      )
                                      (local.get $2)
                                     )
                                     (i64.xor
                                      (local.get $2)
                                      (i64.const 1)
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready548)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (struct.get $type85 1
                                    (global.get $global548)
                                   )
                                  )
                                  (if (result (ref null $type30))
                                   (i64.eqz
                                    (local.get $3)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global533)
                                     )
                                    )
                                    (struct.new $type30
                                     (call $foreign1
                                      (struct.get $type111 0
                                       (global.get $global532)
                                      )
                                     )
                                     (block (result (ref null $type30))
                                      (if
                                       (i64.lt_s
                                        (i64.and
                                         (i64.xor
                                          (local.tee $2
                                           (i64.add
                                            (local.tee $5
                                             (struct.get $type111 0
                                              (local.tee $6
                                               (ref.as_non_null
                                                (global.get $global532)
                                               )
                                              )
                                             )
                                            )
                                            (i64.const 1)
                                           )
                                          )
                                          (i64.const 1)
                                         )
                                         (i64.xor
                                          (local.get $2)
                                          (local.get $5)
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (struct.set $type111 0
                                       (local.get $6)
                                       (local.get $2)
                                      )
                                      (if
                                       (i64.lt_s
                                        (i64.and
                                         (i64.xor
                                          (local.tee $2
                                           (i64.sub
                                            (local.get $3)
                                            (i64.const 1)
                                           )
                                          )
                                          (local.get $3)
                                         )
                                         (i64.xor
                                          (local.get $3)
                                          (i64.const 1)
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready548)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (struct.get $type85 1
                                        (global.get $global548)
                                       )
                                      )
                                      (if (result (ref null $type30))
                                       (i64.eqz
                                        (local.get $2)
                                       )
                                       (then
                                        (ref.null none)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global533)
                                         )
                                        )
                                        (struct.new $type30
                                         (call $foreign1
                                          (struct.get $type111 0
                                           (global.get $global532)
                                          )
                                         )
                                         (block (result (ref null $type30))
                                          (if
                                           (i64.lt_s
                                            (i64.and
                                             (i64.xor
                                              (local.tee $3
                                               (i64.add
                                                (local.tee $5
                                                 (struct.get $type111 0
                                                  (local.tee $6
                                                   (ref.as_non_null
                                                    (global.get $global532)
                                                   )
                                                  )
                                                 )
                                                )
                                                (i64.const 1)
                                               )
                                              )
                                              (i64.const 1)
                                             )
                                             (i64.xor
                                              (local.get $3)
                                              (local.get $5)
                                             )
                                            )
                                            (i64.const 0)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (struct.set $type111 0
                                           (local.get $6)
                                           (local.get $3)
                                          )
                                          (if
                                           (i64.lt_s
                                            (i64.and
                                             (i64.xor
                                              (local.tee $3
                                               (i64.sub
                                                (local.get $2)
                                                (i64.const 1)
                                               )
                                              )
                                              (local.get $2)
                                             )
                                             (i64.xor
                                              (local.get $2)
                                              (i64.const 1)
                                             )
                                            )
                                            (i64.const 0)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready548)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (struct.get $type85 1
                                            (global.get $global548)
                                           )
                                          )
                                          (if (result (ref null $type30))
                                           (i64.eqz
                                            (local.get $3)
                                           )
                                           (then
                                            (ref.null none)
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global533)
                                             )
                                            )
                                            (struct.new $type30
                                             (call $foreign1
                                              (struct.get $type111 0
                                               (global.get $global532)
                                              )
                                             )
                                             (block (result (ref null $type30))
                                              (if
                                               (i64.lt_s
                                                (i64.and
                                                 (i64.xor
                                                  (local.tee $2
                                                   (i64.add
                                                    (local.tee $5
                                                     (struct.get $type111 0
                                                      (local.tee $6
                                                       (ref.as_non_null
                                                        (global.get $global532)
                                                       )
                                                      )
                                                     )
                                                    )
                                                    (i64.const 1)
                                                   )
                                                  )
                                                  (i64.const 1)
                                                 )
                                                 (i64.xor
                                                  (local.get $2)
                                                  (local.get $5)
                                                 )
                                                )
                                                (i64.const 0)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.set $type111 0
                                               (local.get $6)
                                               (local.get $2)
                                              )
                                              (if
                                               (i64.lt_s
                                                (i64.and
                                                 (i64.xor
                                                  (local.tee $2
                                                   (i64.sub
                                                    (local.get $3)
                                                    (i64.const 1)
                                                   )
                                                  )
                                                  (local.get $3)
                                                 )
                                                 (i64.xor
                                                  (local.get $3)
                                                  (i64.const 1)
                                                 )
                                                )
                                                (i64.const 0)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready548)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (struct.get $type85 1
                                                (global.get $global548)
                                               )
                                              )
                                              (if (result (ref null $type30))
                                               (i64.eqz
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.null none)
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global533)
                                                 )
                                                )
                                                (struct.new $type30
                                                 (call $foreign1
                                                  (struct.get $type111 0
                                                   (global.get $global532)
                                                  )
                                                 )
                                                 (block (result (ref null $type30))
                                                  (if
                                                   (i64.lt_s
                                                    (i64.and
                                                     (i64.xor
                                                      (local.tee $3
                                                       (i64.add
                                                        (local.tee $5
                                                         (struct.get $type111 0
                                                          (local.tee $6
                                                           (ref.as_non_null
                                                            (global.get $global532)
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (i64.const 1)
                                                       )
                                                      )
                                                      (i64.const 1)
                                                     )
                                                     (i64.xor
                                                      (local.get $3)
                                                      (local.get $5)
                                                     )
                                                    )
                                                    (i64.const 0)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (struct.set $type111 0
                                                   (local.get $6)
                                                   (local.get $3)
                                                  )
                                                  (if
                                                   (i64.lt_s
                                                    (i64.and
                                                     (i64.xor
                                                      (local.tee $3
                                                       (i64.sub
                                                        (local.get $2)
                                                        (i64.const 1)
                                                       )
                                                      )
                                                      (local.get $2)
                                                     )
                                                     (i64.xor
                                                      (local.get $2)
                                                      (i64.const 1)
                                                     )
                                                    )
                                                    (i64.const 0)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready548)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (struct.get $type85 1
                                                    (global.get $global548)
                                                   )
                                                  )
                                                  (if (result (ref null $type30))
                                                   (i64.eqz
                                                    (local.get $3)
                                                   )
                                                   (then
                                                    (ref.null none)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global533)
                                                     )
                                                    )
                                                    (struct.new $type30
                                                     (call $foreign1
                                                      (struct.get $type111 0
                                                       (global.get $global532)
                                                      )
                                                     )
                                                     (block (result (ref null $type30))
                                                      (if
                                                       (i64.lt_s
                                                        (i64.and
                                                         (i64.xor
                                                          (local.tee $2
                                                           (i64.add
                                                            (local.tee $4
                                                             (struct.get $type111 0
                                                              (local.tee $6
                                                               (ref.as_non_null
                                                                (global.get $global532)
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (i64.const 1)
                                                           )
                                                          )
                                                          (i64.const 1)
                                                         )
                                                         (i64.xor
                                                          (local.get $2)
                                                          (local.get $4)
                                                         )
                                                        )
                                                        (i64.const 0)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (struct.set $type111 0
                                                       (local.get $6)
                                                       (local.get $2)
                                                      )
                                                      (if
                                                       (i64.lt_s
                                                        (i64.and
                                                         (i64.xor
                                                          (local.tee $4
                                                           (i64.sub
                                                            (local.get $3)
                                                            (i64.const 1)
                                                           )
                                                          )
                                                          (local.get $3)
                                                         )
                                                         (i64.xor
                                                          (local.get $3)
                                                          (i64.const 1)
                                                         )
                                                        )
                                                        (i64.const 0)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (if
                                                       (i32.eqz
                                                        (global.get $ready548)
                                                       )
                                                       (then
                                                        (unreachable)
                                                       )
                                                      )
                                                      (drop
                                                       (struct.get $type85 1
                                                        (global.get $global548)
                                                       )
                                                      )
                                                      (if (result (ref null $type30))
                                                       (i64.eqz
                                                        (local.get $4)
                                                       )
                                                       (then
                                                        (ref.null none)
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global533)
                                                         )
                                                        )
                                                        (struct.new $type30
                                                         (call $foreign1
                                                          (struct.get $type111 0
                                                           (global.get $global532)
                                                          )
                                                         )
                                                         (block (result (ref null $type30))
                                                          (if
                                                           (i64.lt_s
                                                            (i64.and
                                                             (i64.xor
                                                              (local.tee $2
                                                               (i64.add
                                                                (local.tee $5
                                                                 (struct.get $type111 0
                                                                  (local.tee $6
                                                                   (ref.as_non_null
                                                                    (global.get $global532)
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                                (i64.const 1)
                                                               )
                                                              )
                                                              (i64.const 1)
                                                             )
                                                             (i64.xor
                                                              (local.get $2)
                                                              (local.get $5)
                                                             )
                                                            )
                                                            (i64.const 0)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (struct.set $type111 0
                                                           (local.get $6)
                                                           (local.get $2)
                                                          )
                                                          (if
                                                           (i64.lt_s
                                                            (i64.and
                                                             (i64.xor
                                                              (local.tee $2
                                                               (i64.sub
                                                                (local.get $4)
                                                                (i64.const 1)
                                                               )
                                                              )
                                                              (local.get $4)
                                                             )
                                                             (i64.xor
                                                              (local.get $4)
                                                              (i64.const 1)
                                                             )
                                                            )
                                                            (i64.const 0)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready548)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (struct.get $type85 1
                                                            (global.get $global548)
                                                           )
                                                          )
                                                          (if (result (ref null $type30))
                                                           (i64.eqz
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.null none)
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global533)
                                                             )
                                                            )
                                                            (struct.new $type30
                                                             (call $function300)
                                                             (block (result (ref null $type30))
                                                              (if
                                                               (i64.lt_s
                                                                (i64.and
                                                                 (i64.xor
                                                                  (local.tee $4
                                                                   (i64.sub
                                                                    (local.get $2)
                                                                    (i64.const 1)
                                                                   )
                                                                  )
                                                                  (local.get $2)
                                                                 )
                                                                 (i64.xor
                                                                  (local.get $2)
                                                                  (i64.const 1)
                                                                 )
                                                                )
                                                                (i64.const 0)
                                                               )
                                                               (then
                                                                (unreachable)
                                                               )
                                                              )
                                                              (if
                                                               (i32.eqz
                                                                (global.get $ready548)
                                                               )
                                                               (then
                                                                (unreachable)
                                                               )
                                                              )
                                                              (call $function308
                                                               (struct.get $type85 1
                                                                (global.get $global548)
                                                               )
                                                               (local.get $4)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function312 (type $call33) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type215))
  (local $3 (ref null $type54))
  (local $4 i64)
  (local $5 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (i64.extend_i32_u
     (i32.ne
      (global.get $global542)
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (struct.get $type60 1
      (global.get $global555)
     )
    )
    (local.set $3
     (call $function265
      (call $foreign2
       (global.get $global540)
      )
      (block (result i64)
       (drop
        (struct.get $type60 1
         (global.get $global555)
        )
       )
       (local.set $scratch
        (call $foreign2
         (global.get $global541)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global468)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (struct.set $type215 1
     (local.tee $2
      (struct.new_default $type215)
     )
     (struct.new $type213
      (struct.new $environment315
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type215 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type215 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function315
     (struct.get $type213 0
      (struct.get $type215 1
       (local.get $2)
      )
     )
     (i64.const 1)
     (local.get $3)
    )
   )
  )
 )
 (func $function313 (type $call60) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign2
   (local.get $2)
  )
 )
 (func $function315 (type $call213) (param $0 (ref $environment315)) (param $1 i64) (param $2 (ref null $type54)) (result i64)
  (local $3 (ref null $type54))
  (local $4 (ref null $type54))
  (local $5 i64)
  (local $6 i64)
  (local $scratch i64)
  (local $scratch_8 (ref null $type54))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment315 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type60 1
      (global.get $global555)
     )
    )
    (local.set $2
     (call $function265
      (call $foreign2
       (global.get $global540)
      )
      (block (result i64)
       (drop
        (struct.get $type60 1
         (global.get $global555)
        )
       )
       (local.set $scratch
        (call $foreign2
         (global.get $global541)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global468)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type215 0
       (struct.get $environment315 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function315
     (struct.get $type213 0
      (struct.get $type215 1
       (struct.get $environment315 1
        (local.get $0)
       )
      )
     )
     (local.get $5)
     (local.get $2)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (global.get $global542)
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global145)
         )
        )
        (local.set $4
         (global.get $global543)
        )
        (if (result i32)
         (ref.is_null
          (local.get $2)
         )
         (then
          (ref.is_null
           (local.get $4)
          )
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.get $4)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global142)
             )
            )
            (if (result i32)
             (call $function54
              (struct.get $type54 0
               (local.get $2)
              )
              (struct.get $type54 0
               (local.get $4)
              )
             )
             (then
              (local.set $3
               (struct.get $type54 1
                (local.get $2)
               )
              )
              (local.set $2
               (struct.get $type54 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (global.get $ready145)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global145)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $3)
               )
               (then
                (ref.is_null
                 (local.get $2)
                )
               )
               (else
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global142)
                   )
                  )
                  (if (result i32)
                   (call $function54
                    (struct.get $type54 0
                     (local.get $3)
                    )
                    (struct.get $type54 0
                     (local.get $2)
                    )
                   )
                   (then
                    (local.set $3
                     (struct.get $type54 1
                      (local.get $3)
                     )
                    )
                    (local.set $2
                     (struct.get $type54 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready145)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global145)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (ref.is_null
                       (local.get $2)
                      )
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global142)
                         )
                        )
                        (if (result i32)
                         (call $function54
                          (struct.get $type54 0
                           (local.get $3)
                          )
                          (struct.get $type54 0
                           (local.get $2)
                          )
                         )
                         (then
                          (local.set $3
                           (struct.get $type54 1
                            (local.get $3)
                           )
                          )
                          (local.set $2
                           (struct.get $type54 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready145)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global145)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $3)
                           )
                           (then
                            (ref.is_null
                             (local.get $2)
                            )
                           )
                           (else
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global142)
                               )
                              )
                              (if (result i32)
                               (call $function54
                                (struct.get $type54 0
                                 (local.get $3)
                                )
                                (struct.get $type54 0
                                 (local.get $2)
                                )
                               )
                               (then
                                (local.set $3
                                 (struct.get $type54 1
                                  (local.get $3)
                                 )
                                )
                                (local.set $2
                                 (struct.get $type54 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready145)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global145)
                                 )
                                )
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $3)
                                 )
                                 (then
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global142)
                                     )
                                    )
                                    (if (result i32)
                                     (call $function54
                                      (struct.get $type54 0
                                       (local.get $3)
                                      )
                                      (struct.get $type54 0
                                       (local.get $2)
                                      )
                                     )
                                     (then
                                      (local.set $3
                                       (struct.get $type54 1
                                        (local.get $3)
                                       )
                                      )
                                      (local.set $2
                                       (struct.get $type54 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready145)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global145)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $3)
                                       )
                                       (then
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                       )
                                       (else
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global142)
                                           )
                                          )
                                          (if (result i32)
                                           (call $function54
                                            (struct.get $type54 0
                                             (local.get $3)
                                            )
                                            (struct.get $type54 0
                                             (local.get $2)
                                            )
                                           )
                                           (then
                                            (local.set $3
                                             (struct.get $type54 1
                                              (local.get $3)
                                             )
                                            )
                                            (local.set $2
                                             (struct.get $type54 1
                                              (local.get $2)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready145)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global145)
                                             )
                                            )
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $3)
                                             )
                                             (then
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                             )
                                             (else
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global142)
                                                 )
                                                )
                                                (if (result i32)
                                                 (call $function54
                                                  (struct.get $type54 0
                                                   (local.get $3)
                                                  )
                                                  (struct.get $type54 0
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (then
                                                  (local.set $3
                                                   (struct.get $type54 1
                                                    (local.get $3)
                                                   )
                                                  )
                                                  (local.set $2
                                                   (struct.get $type54 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready145)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global145)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $3)
                                                   )
                                                   (then
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global142)
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (call $function54
                                                        (struct.get $type54 0
                                                         (local.get $3)
                                                        )
                                                        (struct.get $type54 0
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (then
                                                        (local.set $3
                                                         (struct.get $type54 1
                                                          (local.get $3)
                                                         )
                                                        )
                                                        (local.set $2
                                                         (struct.get $type54 1
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (if
                                                         (i32.eqz
                                                          (global.get $ready145)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global145)
                                                         )
                                                        )
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $3)
                                                         )
                                                         (then
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (else
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global142)
                                                             )
                                                            )
                                                            (if (result i32)
                                                             (call $function54
                                                              (struct.get $type54 0
                                                               (local.get $3)
                                                              )
                                                              (struct.get $type54 0
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (then
                                                              (local.set $3
                                                               (struct.get $type54 1
                                                                (local.get $3)
                                                               )
                                                              )
                                                              (local.set $2
                                                               (struct.get $type54 1
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (if
                                                               (i32.eqz
                                                                (global.get $ready145)
                                                               )
                                                               (then
                                                                (unreachable)
                                                               )
                                                              )
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global145)
                                                               )
                                                              )
                                                              (if (result i32)
                                                               (ref.is_null
                                                                (local.get $3)
                                                               )
                                                               (then
                                                                (ref.is_null
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (else
                                                                (if (result i32)
                                                                 (ref.is_null
                                                                  (local.get $2)
                                                                 )
                                                                 (then
                                                                  (i32.const 0)
                                                                 )
                                                                 (else
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global142)
                                                                   )
                                                                  )
                                                                  (if (result i32)
                                                                   (call $function54
                                                                    (struct.get $type54 0
                                                                     (local.get $3)
                                                                    )
                                                                    (struct.get $type54 0
                                                                     (local.get $2)
                                                                    )
                                                                   )
                                                                   (then
                                                                    (local.set $3
                                                                     (struct.get $type54 1
                                                                      (local.get $3)
                                                                     )
                                                                    )
                                                                    (local.set $2
                                                                     (struct.get $type54 1
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                    (if
                                                                     (i32.eqz
                                                                      (global.get $ready145)
                                                                     )
                                                                     (then
                                                                      (unreachable)
                                                                     )
                                                                    )
                                                                    (drop
                                                                     (ref.as_non_null
                                                                      (global.get $global145)
                                                                     )
                                                                    )
                                                                    (if (result i32)
                                                                     (ref.is_null
                                                                      (local.get $3)
                                                                     )
                                                                     (then
                                                                      (ref.is_null
                                                                       (local.get $2)
                                                                      )
                                                                     )
                                                                     (else
                                                                      (if (result i32)
                                                                       (ref.is_null
                                                                        (local.get $2)
                                                                       )
                                                                       (then
                                                                        (i32.const 0)
                                                                       )
                                                                       (else
                                                                        (drop
                                                                         (ref.as_non_null
                                                                          (global.get $global142)
                                                                         )
                                                                        )
                                                                        (if (result i32)
                                                                         (call $function54
                                                                          (struct.get $type54 0
                                                                           (local.get $3)
                                                                          )
                                                                          (struct.get $type54 0
                                                                           (local.get $2)
                                                                          )
                                                                         )
                                                                         (then
                                                                          (local.set $3
                                                                           (struct.get $type54 1
                                                                            (local.get $3)
                                                                           )
                                                                          )
                                                                          (local.set $2
                                                                           (struct.get $type54 1
                                                                            (local.get $2)
                                                                           )
                                                                          )
                                                                          (if
                                                                           (i32.eqz
                                                                            (global.get $ready145)
                                                                           )
                                                                           (then
                                                                            (unreachable)
                                                                           )
                                                                          )
                                                                          (drop
                                                                           (ref.as_non_null
                                                                            (global.get $global145)
                                                                           )
                                                                          )
                                                                          (if (result i32)
                                                                           (ref.is_null
                                                                            (local.get $3)
                                                                           )
                                                                           (then
                                                                            (ref.is_null
                                                                             (local.get $2)
                                                                            )
                                                                           )
                                                                           (else
                                                                            (if (result i32)
                                                                             (ref.is_null
                                                                              (local.get $2)
                                                                             )
                                                                             (then
                                                                              (i32.const 0)
                                                                             )
                                                                             (else
                                                                              (drop
                                                                               (ref.as_non_null
                                                                                (global.get $global142)
                                                                               )
                                                                              )
                                                                              (if (result i32)
                                                                               (call $function54
                                                                                (struct.get $type54 0
                                                                                 (local.get $3)
                                                                                )
                                                                                (struct.get $type54 0
                                                                                 (local.get $2)
                                                                                )
                                                                               )
                                                                               (then
                                                                                (local.set $3
                                                                                 (struct.get $type54 1
                                                                                  (local.get $3)
                                                                                 )
                                                                                )
                                                                                (local.set $2
                                                                                 (struct.get $type54 1
                                                                                  (local.get $2)
                                                                                 )
                                                                                )
                                                                                (if
                                                                                 (i32.eqz
                                                                                  (global.get $ready145)
                                                                                 )
                                                                                 (then
                                                                                  (unreachable)
                                                                                 )
                                                                                )
                                                                                (drop
                                                                                 (ref.as_non_null
                                                                                  (global.get $global145)
                                                                                 )
                                                                                )
                                                                                (if (result i32)
                                                                                 (ref.is_null
                                                                                  (local.get $3)
                                                                                 )
                                                                                 (then
                                                                                  (ref.is_null
                                                                                   (local.get $2)
                                                                                  )
                                                                                 )
                                                                                 (else
                                                                                  (if (result i32)
                                                                                   (ref.is_null
                                                                                    (local.get $2)
                                                                                   )
                                                                                   (then
                                                                                    (i32.const 0)
                                                                                   )
                                                                                   (else
                                                                                    (drop
                                                                                     (ref.as_non_null
                                                                                      (global.get $global142)
                                                                                     )
                                                                                    )
                                                                                    (if (result i32)
                                                                                     (call $function54
                                                                                      (struct.get $type54 0
                                                                                       (local.get $3)
                                                                                      )
                                                                                      (struct.get $type54 0
                                                                                       (local.get $2)
                                                                                      )
                                                                                     )
                                                                                     (then
                                                                                      (local.set $3
                                                                                       (struct.get $type54 1
                                                                                        (local.get $3)
                                                                                       )
                                                                                      )
                                                                                      (local.set $2
                                                                                       (struct.get $type54 1
                                                                                        (local.get $2)
                                                                                       )
                                                                                      )
                                                                                      (if
                                                                                       (i32.eqz
                                                                                        (global.get $ready145)
                                                                                       )
                                                                                       (then
                                                                                        (unreachable)
                                                                                       )
                                                                                      )
                                                                                      (drop
                                                                                       (ref.as_non_null
                                                                                        (global.get $global145)
                                                                                       )
                                                                                      )
                                                                                      (if (result i32)
                                                                                       (ref.is_null
                                                                                        (local.get $3)
                                                                                       )
                                                                                       (then
                                                                                        (ref.is_null
                                                                                         (local.get $2)
                                                                                        )
                                                                                       )
                                                                                       (else
                                                                                        (if (result i32)
                                                                                         (ref.is_null
                                                                                          (local.get $2)
                                                                                         )
                                                                                         (then
                                                                                          (i32.const 0)
                                                                                         )
                                                                                         (else
                                                                                          (drop
                                                                                           (ref.as_non_null
                                                                                            (global.get $global142)
                                                                                           )
                                                                                          )
                                                                                          (if (result i32)
                                                                                           (call $function54
                                                                                            (struct.get $type54 0
                                                                                             (local.get $3)
                                                                                            )
                                                                                            (struct.get $type54 0
                                                                                             (local.get $2)
                                                                                            )
                                                                                           )
                                                                                           (then
                                                                                            (local.set $3
                                                                                             (struct.get $type54 1
                                                                                              (local.get $3)
                                                                                             )
                                                                                            )
                                                                                            (local.set $2
                                                                                             (struct.get $type54 1
                                                                                              (local.get $2)
                                                                                             )
                                                                                            )
                                                                                            (if
                                                                                             (i32.eqz
                                                                                              (global.get $ready145)
                                                                                             )
                                                                                             (then
                                                                                              (unreachable)
                                                                                             )
                                                                                            )
                                                                                            (drop
                                                                                             (ref.as_non_null
                                                                                              (global.get $global145)
                                                                                             )
                                                                                            )
                                                                                            (if (result i32)
                                                                                             (ref.is_null
                                                                                              (local.get $3)
                                                                                             )
                                                                                             (then
                                                                                              (ref.is_null
                                                                                               (local.get $2)
                                                                                              )
                                                                                             )
                                                                                             (else
                                                                                              (if (result i32)
                                                                                               (ref.is_null
                                                                                                (local.get $2)
                                                                                               )
                                                                                               (then
                                                                                                (i32.const 0)
                                                                                               )
                                                                                               (else
                                                                                                (drop
                                                                                                 (ref.as_non_null
                                                                                                  (global.get $global142)
                                                                                                 )
                                                                                                )
                                                                                                (if (result i32)
                                                                                                 (call $function54
                                                                                                  (struct.get $type54 0
                                                                                                   (local.get $3)
                                                                                                  )
                                                                                                  (struct.get $type54 0
                                                                                                   (local.get $2)
                                                                                                  )
                                                                                                 )
                                                                                                 (then
                                                                                                  (call $function55
                                                                                                   (struct.get $type54 1
                                                                                                    (local.get $3)
                                                                                                   )
                                                                                                   (block (result (ref null $type54))
                                                                                                    (local.set $scratch_8
                                                                                                     (struct.get $type54 1
                                                                                                      (local.get $2)
                                                                                                     )
                                                                                                    )
                                                                                                    (if
                                                                                                     (i32.eqz
                                                                                                      (global.get $ready145)
                                                                                                     )
                                                                                                     (then
                                                                                                      (unreachable)
                                                                                                     )
                                                                                                    )
                                                                                                    (drop
                                                                                                     (ref.as_non_null
                                                                                                      (global.get $global145)
                                                                                                     )
                                                                                                    )
                                                                                                    (local.get $scratch_8)
                                                                                                   )
                                                                                                  )
                                                                                                 )
                                                                                                 (else
                                                                                                  (i32.const 0)
                                                                                                 )
                                                                                                )
                                                                                               )
                                                                                              )
                                                                                             )
                                                                                            )
                                                                                           )
                                                                                           (else
                                                                                            (i32.const 0)
                                                                                           )
                                                                                          )
                                                                                         )
                                                                                        )
                                                                                       )
                                                                                      )
                                                                                     )
                                                                                     (else
                                                                                      (i32.const 0)
                                                                                     )
                                                                                    )
                                                                                   )
                                                                                  )
                                                                                 )
                                                                                )
                                                                               )
                                                                               (else
                                                                                (i32.const 0)
                                                                               )
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                         (else
                                                                          (i32.const 0)
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                   (else
                                                                    (i32.const 0)
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                             (else
                                                              (i32.const 0)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (else
                                                        (i32.const 0)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (i32.const 0)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (else
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $primitive0 (type $call84) (param $0 structref) (param $1 (ref null $type30)) (param $2 (ref null $type32)) (result (ref null $type32))
  (struct.new $type32
   (local.get $1)
   (local.get $2)
  )
 )
 (func $primitive1 (type $call57) (param $0 structref) (param $1 (ref null $type30)) (result (ref null $type30))
  (struct.get $type30 1
   (local.get $1)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready553)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function312
   (struct.get $type33 1
    (global.get $global553)
   )
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type111))
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $global210
   (struct.new_default $type11)
  )
  (global.set $global61
   (struct.new $type15
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $global101
   (struct.new_default $type28)
  )
  (global.set $global201
   (struct.new_default $type29)
  )
  (global.set $global456
   (struct.new_default $type31)
  )
  (global.set $global106
   (struct.new $type33
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $global191
   (struct.new $type34
    (ref.func $function89)
    (ref.null none)
   )
  )
  (global.set $global108
   (struct.new $type43
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $global113
   (struct.new_default $type48)
  )
  (global.set $global347
   (struct.new_default $type31)
  )
  (global.set $global235
   (struct.new_default $type52)
  )
  (global.set $global466
   (struct.new_default $type53)
  )
  (global.set $global265
   (struct.new $type55
    (ref.func $function128)
    (ref.null none)
   )
  )
  (global.set $global301
   (struct.new_default $type56)
  )
  (global.set $ready301
   (i32.const 1)
  )
  (global.set $global311
   (struct.new_default $type58)
  )
  (global.set $ready311
   (i32.const 1)
  )
  (global.set $global324
   (struct.new_default $type59)
  )
  (global.set $ready324
   (i32.const 1)
  )
  (global.set $global118
   (struct.new $type61
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $global363
   (struct.new $type61
    (ref.func $function192)
    (ref.null none)
   )
  )
  (global.set $global120
   (struct.new $type61
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $global122
   (struct.new $type60
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $global198
   (struct.new_default $type62)
  )
  (global.set $global275
   (struct.new_default $type63)
  )
  (global.set $global223
   (struct.new_default $type63)
  )
  (global.set $global128
   (struct.new_default $type64)
  )
  (global.set $global131
   (struct.new_default $type65)
  )
  (global.set $global133
   (struct.new_default $type66)
  )
  (global.set $global136
   (struct.new $type67
    (ref.func $function52)
    (ref.null none)
   )
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type68)
  )
  (global.set $ready139
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type69)
  )
  (global.set $global145
   (struct.new_default $type70)
  )
  (global.set $ready145
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type71)
  )
  (global.set $global152
   (struct.new $type72
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready152
   (i32.const 1)
  )
  (global.set $global154
   (struct.new_default $type73)
  )
  (global.set $global555
   (struct.new $type60
    (ref.func $function313)
    (ref.null none)
   )
  )
  (global.set $global156
   (struct.new $type60
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $global163
   (struct.new $type60
    (ref.func $function68)
    (ref.null none)
   )
  )
  (global.set $global430
   (struct.new_default $type74)
  )
  (global.set $global443
   (struct.new_default $type75)
  )
  (global.set $global445
   (struct.new_default $type76)
  )
  (global.set $global170
   (struct.new $type77
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $global195
   (struct.new_default $type78)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global225
   (struct.new_default $type79)
  )
  (global.set $ready225
   (i32.const 1)
  )
  (global.set $global243
   (struct.new $type81
    (struct.new $environment120
     (struct.new $type84
      (ref.func $function118)
      (ref.null none)
     )
    )
   )
  )
  (global.set $ready243
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type82)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type83)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $global231
   (struct.new $type85
    (ref.func $function110)
    (ref.null none)
   )
  )
  (global.set $ready231
   (i32.const 1)
  )
  (global.set $global279
   (struct.new_default $type86)
  )
  (global.set $global404
   (struct.new_default $type90)
  )
  (global.set $global378
   (struct.new_default $type95)
  )
  (global.set $ready378
   (i32.const 1)
  )
  (global.set $global285
   (struct.new_default $type89)
  )
  (global.set $global329
   (struct.new_default $type92)
  )
  (global.set $global402
   (struct.new_default $type101)
  )
  (global.set $global427
   (struct.new $type33
    (ref.func $function236)
    (ref.null none)
   )
  )
  (global.set $global448
   (struct.new $type33
    (ref.func $function253)
    (ref.null none)
   )
  )
  (global.set $global471
   (struct.new_default $type102)
  )
  (global.set $global453
   (struct.new $type103
    (ref.func $function257)
    (ref.null none)
   )
  )
  (global.set $global468
   (struct.new_default $type105)
  )
  (global.set $global520
   (struct.new_default $type106)
  )
  (global.set $ready520
   (i32.const 1)
  )
  (global.set $global504
   (struct.new_default $type107)
  )
  (global.set $ready504
   (i32.const 1)
  )
  (global.set $global482
   (struct.new_default $type108)
  )
  (global.set $ready482
   (i32.const 1)
  )
  (global.set $global532
   (struct.new_default $type111)
  )
  (global.set $global533
   (struct.new_default $type5)
  )
  (global.set $ready533
   (i32.const 1)
  )
  (global.set $global548
   (struct.new $type85
    (ref.func $function308)
    (ref.null none)
   )
  )
  (global.set $ready548
   (i32.const 1)
  )
  (global.set $global546
   (struct.new_default $type112)
  )
  (global.set $ready546
   (i32.const 1)
  )
  (global.set $global544
   (struct.new_default $type113)
  )
  (global.set $ready544
   (i32.const 1)
  )
  (global.set $global535
   (struct.new $type15
    (ref.func $function302)
    (ref.null none)
   )
  )
  (global.set $ready535
   (i32.const 1)
  )
  (global.set $global540
   (call $foreign3
    (i32.const 0)
   )
  )
  (global.set $global541
   (call $foreign3
    (i32.const 1)
   )
  )
  (global.set $global542
   (i64.eq
    (call $foreign3
     (i32.const 2)
    )
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready533)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global533)
   )
  )
  (global.set $global543
   (call $function306
    (block (result i64)
     (local.set $scratch
      (call $foreign1
       (struct.get $type111 0
        (global.get $global532)
       )
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $0
          (i64.add
           (local.tee $2
            (struct.get $type111 0
             (local.tee $3
              (ref.as_non_null
               (global.get $global532)
              )
             )
            )
           )
           (i64.const 1)
          )
         )
         (i64.const 1)
        )
        (i64.xor
         (local.get $0)
         (local.get $2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (struct.set $type111 0
      (local.get $3)
      (local.get $0)
     )
     (if
      (i32.eqz
       (global.get $ready544)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global544)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (global.set $global553
   (struct.new $type33
    (ref.func $function312)
    (ref.null none)
   )
  )
  (global.set $ready553
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

