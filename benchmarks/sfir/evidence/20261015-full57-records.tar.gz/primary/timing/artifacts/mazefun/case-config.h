#define OBSERVE_BARRIERS 0
#ifndef BENCHMARK_CASE_CONFIG
#define BENCHMARK_CASE_CONFIG
#include <stdint.h>
static const int64_t input_integers[] = {11, 11};
static const double input_reals[] = {11, 11};
static const int64_t vector_integers[] = {0};
static const double vector_reals[] = {0};
static const int64_t expected_integers[] = {2, 11, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 11, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 11, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 11, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 11, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 11, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 11, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 11, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 11, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1};
static const double expected_reals[] = {2, 11, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 11, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 11, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 11, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 11, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 11, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 11, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 11, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 11, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 11, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1};
static const int64_t vector_sizes[] = {0, 0};
static const int64_t vector_offsets[] = {0, 0};
static const int64_t configured_count = 10000;
static const int64_t expected_size = 134;
static const int64_t expected_setup = 0;
static const int64_t expected_barriers = 20000;
static const int64_t expected_setup_closed = -1;
static const int64_t expected_worker_closed = -1;
static const int64_t expected_result = 1;
static const double expected_tolerance = 0;
#define FLOAT_RESULT 0
#define CONFIGURED_COUNT 0
static const char *diagnostic_text[] = {""};
static const char *diagnostic_prefix[] = {""};
static const char *diagnostic_suffix[] = {""};
static const uint32_t path_characters[] = {0};
static const int64_t path_sizes[] = {0};
static const int64_t path_offsets[] = {0};
#define PATH_ARGUMENTS -1
#endif
