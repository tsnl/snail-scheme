(module
 (rec
  (type $type35 (sub (struct (field i32))))
  (type $type29 (sub (struct)))
  (type $type109 (struct (field (ref $environment131))))
  (type $type111 (struct (field (mut i32)) (field (mut (ref null $type109)))))
  (type $environment131 (struct (field i64) (field (ref $type111))))
  (type $call109 (func (param (ref $environment131) i64 (ref $type35)) (result i64)))
  (type $6 (func (param (ref $environment127) i32) (result (ref $type40))))
  (type $environment127 (struct (field i64)))
  (type $8 (func (param i64) (result (ref null $type39))))
  (type $9 (func (param (ref $type54) (ref null $type33)) (result (ref null $type39))))
  (type $10 (func (param (ref $environment118) i32) (result (ref $type40))))
  (type $environment118 (struct (field (ref $type34)) (field (ref null $type28))))
  (type $call54 (func (param (ref $environment116) (ref null $type28)) (result (ref null $type40))))
  (type $13 (func (param (ref $type61) i32 i32 (ref null $type33) (ref null $type28)) (result (ref null $type33))))
  (type $call70 (func (param (ref null $type33) i64 (ref null $type28)) (result (ref $type33))))
  (type $call69 (func (param (ref null $type28) i64 (ref $type29)) (result (ref $type28))))
  (type $16 (func (param (ref null $type33) i64 i64 (ref $type29)) (result (ref $type33))))
  (type $environment106 (struct (field (ref $type29)) (field (ref $type29))))
  (type $18 (func (param (ref $environment104) i64 i64) (result (ref null $type33))))
  (type $environment104 (struct (field (ref null $type33)) (field (ref $type31)) (field (ref $type29)) (field (ref $type29))))
  (type $20 (func (param (ref $environment99) (ref $type29)) (result (ref $type28))))
  (type $call68 (func (param (ref null $type33) i64) (result (ref null $type28))))
  (type $call75 (func (param (ref null $type33) i64 i64) (result (ref $type29))))
  (type $23 (func (param (ref $environment91) i64 i64) (result (ref null $type28))))
  (type $call102 (func (param (ref $environment89) (ref null $type33) i64) (result i64)))
  (type $type102 (struct (field (ref $environment89))))
  (type $type104 (struct (field (mut i32)) (field (mut (ref null $type102)))))
  (type $environment89 (struct (field (ref $type104))))
  (type $call32 (func (param (ref null $type33)) (result i64)))
  (type $call61 (func (param (ref struct) (ref null $type33) (ref $type29)) (result (ref null $type33))))
  (type $environment100 (struct (field (ref $type31))))
  (type $environment99 (struct (field (ref $type51)) (field (ref null $type28))))
  (type $environment97 (struct (field (ref null $type33))))
  (type $environment91 (struct (field (ref $type29)) (field (ref null $type33))))
  (type $type51 (struct (field (ref $environment97))))
  (type $type61 (struct (field (ref $call61)) (field (ref struct))))
  (type $call84 (func (param (ref $type29) (ref null $type33)) (result (ref null $type33))))
  (type $call85 (func (param (ref null $type28) (ref null $type33)) (result (ref null $type33))))
  (type $call71 (func (param (ref null $type28) i64) (result (ref null $type28))))
  (type $call67 (func (param (ref null $type28) i64) (result (ref $type29))))
  (type $call95 (func (param (ref $environment77) (ref null $type28) i64) (result i64)))
  (type $call27 (func (param (ref null $type28)) (result i64)))
  (type $42 (func (param (ref null $type28) i64) (result (ref null $type28))))
  (type $43 (func (param (ref $type48) (ref null $type28) i32 i32 (ref null $type33)) (result (ref null $type28))))
  (type $call48 (func (param (ref null $type28) (ref null $type28)) (result (ref null $type28))))
  (type $environment65 (struct (field i64)))
  (type $46 (func (param i64 (ref $type65) i32 i32 i64) (result (ref null $type33))))
  (type $47 (func (param i64 (ref $type63) i32 i32 i64) (result (ref null $type28))))
  (type $environment59 (struct (field i64)))
  (type $type63 (struct (field (ref $environment59))))
  (type $call74 (func (param i64 i64) (result (ref $type29))))
  (type $type95 (struct (field (ref $environment77))))
  (type $environment64 (struct (field i64)))
  (type $environment58 (struct (field i64) (field (ref $type74))))
  (type $type74 (struct))
  (type $environment116 (struct (field (ref $type34))))
  (type $type54 (struct (field (ref $environment116))))
  (type $type97 (struct (field (mut i32)) (field (mut (ref null $type95)))))
  (type $environment77 (struct (field (ref $type97))))
  (type $call65 (func (param (ref struct) i64) (result (ref null $type28))))
  (type $type65 (struct (field (ref $call65)) (field (ref struct))))
  (type $type33 (struct (field (ref null $type28)) (field (ref null $type33))))
  (type $call82 (func (param i64 i64) (result (ref $type35))))
  (type $call72 (func (param (ref null $type28)) (result i32)))
  (type $type38 (sub $type35 (struct (field i32) (field (ref null $type39)))))
  (type $call57 (func (param (ref $type35) (ref $type35)) (result i32)))
  (type $type39 (struct (field (ref null $type40)) (field (ref null $type39))))
  (type $call56 (func (param (ref null $type39) (ref null $type39)) (result i32)))
  (type $type40 (struct (field i32) (field (ref null $type40))))
  (type $call55 (func (param (ref null $type40) (ref null $type40)) (result i32)))
  (type $type28 (struct (field (ref $type29)) (field (ref null $type28))))
  (type $call46 (func (param (ref $type29) (ref null $type28)) (result i32)))
  (type $call45 (func (param (ref $type29) (ref $type29)) (result i32)))
  (type $type31 (sub $type29 (struct (field i64) (field i64))))
  (type $call34 (func (param (ref $type29)) (result i32)))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type5 (struct))
  (type $type89 (struct (field (mut i64))))
  (type $type88 (struct))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct))
  (type $type80 (struct))
  (type $type79 (struct))
  (type $type77 (struct))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type73 (struct))
  (type $type72 (struct))
  (type $type71 (struct))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type60 (struct))
  (type $type59 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct (field nullref)))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type27 (struct))
  (type $type41 (sub $type35 (struct (field i32))))
  (type $type37 (sub $type35 (struct (field i32))))
  (type $type36 (sub $type35 (struct (field i32))))
  (type $type30 (sub $type29 (struct)))
 )
 (type $127 (func (param i64) (result i64)))
 (type $128 (func (param i32) (result i64)))
 (type $129 (func))
 (import "benchmark" "expected_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty30 (ref $type30) (struct.new_default $type30))
 (global $empty36 (ref $type36) (struct.new $type36
  (i32.const 0)
 ))
 (global $empty37 (ref $type37) (struct.new $type37
  (i32.const 1)
 ))
 (global $empty41 (ref $type41) (struct.new $type41
  (i32.const 3)
 ))
 (global $global194 (mut (ref null $type27)) (ref.null none))
 (global $global220 (mut (ref null $type32)) (ref.null none))
 (global $global106 (mut (ref null $type30)) (ref.null none))
 (global $global107 (mut (ref null $type34)) (ref.null none))
 (global $global112 (mut (ref null $type36)) (ref.null none))
 (global $global113 (mut (ref null $type37)) (ref.null none))
 (global $global114 (mut (ref null $type41)) (ref.null none))
 (global $global115 (mut (ref null $type42)) (ref.null none))
 (global $global119 (mut (ref null $type43)) (ref.null none))
 (global $global122 (mut (ref null $type44)) (ref.null none))
 (global $global124 (mut (ref null $type44)) (ref.null none))
 (global $global126 (mut (ref null $type45)) (ref.null none))
 (global $global129 (mut (ref null $type46)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global173 (mut (ref null $type47)) (ref.null none))
 (global $global177 (mut (ref null $type48)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global237 (mut (ref null $type49)) (ref.null none))
 (global $global244 (mut (ref null $type50)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global297 (mut (ref null $type52)) (ref.null none))
 (global $ready297 (mut i32) (i32.const 0))
 (global $global301 (mut (ref null $type53)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type55)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type56)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type57)) (ref.null none))
 (global $global324 (mut (ref null $type58)) (ref.null none))
 (global $global180 (mut (ref null $type59)) (ref.null none))
 (global $global279 (mut (ref null $type60)) (ref.null none))
 (global $global159 (mut (ref null $type62)) (ref.null none))
 (global $global165 (mut (ref null $type64)) (ref.null none))
 (global $global175 (mut (ref null $type66)) (ref.null none))
 (global $global200 (mut (ref null $type67)) (ref.null none))
 (global $ready200 (mut i32) (i32.const 0))
 (global $global234 (mut (ref null $type68)) (ref.null none))
 (global $ready234 (mut i32) (i32.const 0))
 (global $global271 (mut (ref null $type69)) (ref.null none))
 (global $ready271 (mut i32) (i32.const 0))
 (global $global275 (mut (ref null $type70)) (ref.null none))
 (global $ready275 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type71)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type72)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type73)) (ref.null none))
 (global $global230 (mut (ref null $type75)) (ref.null none))
 (global $global266 (mut (ref null $type76)) (ref.null none))
 (global $global218 (mut (ref null $type77)) (ref.null none))
 (global $global293 (mut (ref null $type79)) (ref.null none))
 (global $global146 (mut (ref null $type80)) (ref.null none))
 (global $global188 (mut (ref null $type81)) (ref.null none))
 (global $global190 (mut (ref null $type71)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type82)) (ref.null none))
 (global $global291 (mut (ref null $type83)) (ref.null none))
 (global $ready291 (mut i32) (i32.const 0))
 (global $global286 (mut (ref null $type84)) (ref.null none))
 (global $global206 (mut (ref null $type85)) (ref.null none))
 (global $ready206 (mut i32) (i32.const 0))
 (global $global210 (mut (ref null $type84)) (ref.null none))
 (global $ready210 (mut i32) (i32.const 0))
 (global $global250 (mut (ref null $type86)) (ref.null none))
 (global $ready250 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type87)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type88)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global305 (mut (ref null $type89)) (ref.null none))
 (global $global306 (mut (ref null $type5)) (ref.null none))
 (global $global312 (mut (ref null $type90)) (ref.null none))
 (global $ready312 (mut i32) (i32.const 0))
 (global $global310 (mut (ref null $type91)) (ref.null none))
 (global $ready310 (mut i32) (i32.const 0))
 (global $global308 (mut (ref null $type92)) (ref.null none))
 (global $ready308 (mut i32) (i32.const 0))
 (global $global316 (mut i64) (i64.const 0))
 (global $global317 (mut i64) (i64.const 0))
 (global $global318 (mut (ref null $type35)) (ref.null none))
 (global $global319 (mut (ref null $type80)) (ref.null none))
 (global $ready319 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call34) (param $0 (ref $type29)) (result i32)
  (if (result i32)
   (ref.test (ref $type30)
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.cast (ref $type31)
      (local.get $0)
     )
    )
    (i32.const 1)
   )
  )
 )
 (func $function46 (type $call45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i32)
  (local $2 i64)
  (drop
   (ref.as_non_null
    (global.get $global107)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type30)
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (ref.cast (ref $type31)
       (local.get $0)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global107)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type30)
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type30)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type31 0
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
      (if
       (ref.test (ref $type30)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (i64.eq
        (struct.get $type31 0
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
        (local.get $2)
       )
       (then
        (if
         (ref.test (ref $type30)
          (local.get $0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
        )
        (if
         (ref.test (ref $type30)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (i64.eq
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
         (local.get $2)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global107)
     )
    )
    (i32.eqz
     (if (result i32)
      (ref.test (ref $type30)
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call46) (param $0 (ref $type29)) (param $1 (ref null $type28)) (result i32)
  (local $2 i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if (result i32)
     (local.tee $2
      (call $function46
       (local.get $0)
       (struct.get $type28 0
        (local.get $1)
       )
      )
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready129)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global129)
       )
      )
      (return_call $function47
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function49 (type $call55) (param $0 (ref null $type40)) (param $1 (ref null $type40)) (result i32)
  (local $2 i32)
  (local $scratch (ref null $type40))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (if (result i32)
       (select
        (local.tee $2
         (struct.get $type40 0
          (local.get $1)
         )
        )
        (i32.eqz
         (local.get $2)
        )
        (struct.get $type40 0
         (local.get $0)
        )
       )
       (then
        (return_call $function49
         (struct.get $type40 1
          (local.get $0)
         )
         (block (result (ref null $type40))
          (local.set $scratch
           (struct.get $type40 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready133)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global133)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function50 (type $call56) (param $0 (ref null $type39)) (param $1 (ref null $type39)) (result i32)
  (local $2 (ref null $type40))
  (local $3 (ref null $type40))
  (local $4 i32)
  (local $scratch (ref null $type40))
  (local $scratch_6 (ref null $type39))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global133)
       )
      )
      (local.set $2
       (struct.get $type39 0
        (local.get $1)
       )
      )
      (if (result i32)
       (if (result i32)
        (ref.is_null
         (local.tee $3
          (struct.get $type39 0
           (local.get $0)
          )
         )
        )
        (then
         (ref.is_null
          (local.get $2)
         )
        )
        (else
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global119)
            )
           )
           (if (result i32)
            (select
             (local.tee $4
              (struct.get $type40 0
               (local.get $2)
              )
             )
             (i32.eqz
              (local.get $4)
             )
             (struct.get $type40 0
              (local.get $3)
             )
            )
            (then
             (local.set $3
              (struct.get $type40 1
               (local.get $3)
              )
             )
             (local.set $2
              (struct.get $type40 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready133)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global133)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.is_null
                (local.get $2)
               )
              )
              (else
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global119)
                  )
                 )
                 (if (result i32)
                  (select
                   (local.tee $4
                    (struct.get $type40 0
                     (local.get $2)
                    )
                   )
                   (i32.eqz
                    (local.get $4)
                   )
                   (struct.get $type40 0
                    (local.get $3)
                   )
                  )
                  (then
                   (local.set $3
                    (struct.get $type40 1
                     (local.get $3)
                    )
                   )
                   (local.set $2
                    (struct.get $type40 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready133)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global133)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (ref.is_null
                      (local.get $2)
                     )
                    )
                    (else
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global119)
                        )
                       )
                       (if (result i32)
                        (select
                         (local.tee $4
                          (struct.get $type40 0
                           (local.get $2)
                          )
                         )
                         (i32.eqz
                          (local.get $4)
                         )
                         (struct.get $type40 0
                          (local.get $3)
                         )
                        )
                        (then
                         (local.set $3
                          (struct.get $type40 1
                           (local.get $3)
                          )
                         )
                         (local.set $2
                          (struct.get $type40 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready133)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global133)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.is_null
                            (local.get $2)
                           )
                          )
                          (else
                           (if (result i32)
                            (ref.is_null
                             (local.get $2)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global119)
                              )
                             )
                             (if (result i32)
                              (select
                               (local.tee $4
                                (struct.get $type40 0
                                 (local.get $2)
                                )
                               )
                               (i32.eqz
                                (local.get $4)
                               )
                               (struct.get $type40 0
                                (local.get $3)
                               )
                              )
                              (then
                               (local.set $3
                                (struct.get $type40 1
                                 (local.get $3)
                                )
                               )
                               (local.set $2
                                (struct.get $type40 1
                                 (local.get $2)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready133)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global133)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                )
                                (else
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global119)
                                    )
                                   )
                                   (if (result i32)
                                    (select
                                     (local.tee $4
                                      (struct.get $type40 0
                                       (local.get $2)
                                      )
                                     )
                                     (i32.eqz
                                      (local.get $4)
                                     )
                                     (struct.get $type40 0
                                      (local.get $3)
                                     )
                                    )
                                    (then
                                     (local.set $3
                                      (struct.get $type40 1
                                       (local.get $3)
                                      )
                                     )
                                     (local.set $2
                                      (struct.get $type40 1
                                       (local.get $2)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready133)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global133)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                      )
                                      (else
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global119)
                                          )
                                         )
                                         (if (result i32)
                                          (select
                                           (local.tee $4
                                            (struct.get $type40 0
                                             (local.get $2)
                                            )
                                           )
                                           (i32.eqz
                                            (local.get $4)
                                           )
                                           (struct.get $type40 0
                                            (local.get $3)
                                           )
                                          )
                                          (then
                                           (local.set $3
                                            (struct.get $type40 1
                                             (local.get $3)
                                            )
                                           )
                                           (local.set $2
                                            (struct.get $type40 1
                                             (local.get $2)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready133)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global133)
                                            )
                                           )
                                           (if (result i32)
                                            (ref.is_null
                                             (local.get $3)
                                            )
                                            (then
                                             (ref.is_null
                                              (local.get $2)
                                             )
                                            )
                                            (else
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (i32.const 0)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global119)
                                                )
                                               )
                                               (if (result i32)
                                                (select
                                                 (local.tee $4
                                                  (struct.get $type40 0
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i32.eqz
                                                  (local.get $4)
                                                 )
                                                 (struct.get $type40 0
                                                  (local.get $3)
                                                 )
                                                )
                                                (then
                                                 (local.set $3
                                                  (struct.get $type40 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (local.set $2
                                                  (struct.get $type40 1
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready133)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global133)
                                                  )
                                                 )
                                                 (if (result i32)
                                                  (ref.is_null
                                                   (local.get $3)
                                                  )
                                                  (then
                                                   (ref.is_null
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (else
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                    (then
                                                     (i32.const 0)
                                                    )
                                                    (else
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global119)
                                                      )
                                                     )
                                                     (if (result i32)
                                                      (select
                                                       (local.tee $4
                                                        (struct.get $type40 0
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (i32.eqz
                                                        (local.get $4)
                                                       )
                                                       (struct.get $type40 0
                                                        (local.get $3)
                                                       )
                                                      )
                                                      (then
                                                       (local.set $3
                                                        (struct.get $type40 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (local.set $2
                                                        (struct.get $type40 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready133)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global133)
                                                        )
                                                       )
                                                       (if (result i32)
                                                        (ref.is_null
                                                         (local.get $3)
                                                        )
                                                        (then
                                                         (ref.is_null
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (else
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                          (then
                                                           (i32.const 0)
                                                          )
                                                          (else
                                                           (drop
                                                            (ref.as_non_null
                                                             (global.get $global119)
                                                            )
                                                           )
                                                           (if (result i32)
                                                            (select
                                                             (local.tee $4
                                                              (struct.get $type40 0
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (i32.eqz
                                                              (local.get $4)
                                                             )
                                                             (struct.get $type40 0
                                                              (local.get $3)
                                                             )
                                                            )
                                                            (then
                                                             (call $function49
                                                              (struct.get $type40 1
                                                               (local.get $3)
                                                              )
                                                              (block (result (ref null $type40))
                                                               (local.set $scratch
                                                                (struct.get $type40 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if
                                                                (i32.eqz
                                                                 (global.get $ready133)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global133)
                                                                )
                                                               )
                                                               (local.get $scratch)
                                                              )
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (else
                                     (i32.const 0)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function50
         (struct.get $type39 1
          (local.get $0)
         )
         (block (result (ref null $type39))
          (local.set $scratch_6
           (struct.get $type39 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready136)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global136)
           )
          )
          (local.get $scratch_6)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call57) (param $0 (ref $type35)) (param $1 (ref $type35)) (result i32)
  (local $2 (ref null $type40))
  (local $3 (ref null $type40))
  (local $4 (ref null $type39))
  (local $5 (ref null $type39))
  (local $6 i32)
  (local $scratch (ref null $type40))
  (local $scratch_8 (ref null $type39))
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if (result i32)
   (i64.eq
    (if (result i64)
     (local.tee $6
      (struct.get $type35 0
       (local.get $0)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $6)
        (i32.const 1)
       )
       (then
        (i64.const 1)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type35 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (drop
           (ref.cast (ref $type38)
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (else
          (i64.const 3)
         )
        )
       )
      )
     )
     (else
      (i64.const 0)
     )
    )
    (if (result i64)
     (local.tee $6
      (struct.get $type35 0
       (local.get $1)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $6)
        (i32.const 1)
       )
       (then
        (i64.const 1)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type35 0
           (local.get $1)
          )
          (i32.const 2)
         )
         (then
          (drop
           (ref.cast (ref $type38)
            (local.get $1)
           )
          )
          (i64.const 2)
         )
         (else
          (i64.const 3)
         )
        )
       )
      )
     )
     (else
      (i64.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if (result i32)
     (i64.eq
      (if (result i64)
       (local.tee $6
        (struct.get $type35 0
         (local.get $0)
        )
       )
       (then
        (if (result i64)
         (i32.eq
          (local.get $6)
          (i32.const 1)
         )
         (then
          (i64.const 1)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type35 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type38)
              (local.get $0)
             )
            )
            (i64.const 2)
           )
           (else
            (i64.const 3)
           )
          )
         )
        )
       )
       (else
        (i64.const 0)
       )
      )
      (i64.const 2)
     )
     (then
      (if
       (i32.ne
        (struct.get $type35 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type38 1
        (ref.cast (ref $type38)
         (local.get $0)
        )
       )
      )
      (if
       (i32.ne
        (struct.get $type35 0
         (local.get $1)
        )
        (i32.const 2)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global136)
       )
      )
      (local.set $4
       (struct.get $type38 1
        (ref.cast (ref $type38)
         (local.get $1)
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $5)
       )
       (then
        (ref.is_null
         (local.get $4)
        )
       )
       (else
        (if (result i32)
         (ref.is_null
          (local.get $4)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global133)
           )
          )
          (local.set $2
           (struct.get $type39 0
            (local.get $4)
           )
          )
          (if (result i32)
           (if (result i32)
            (ref.is_null
             (local.tee $3
              (struct.get $type39 0
               (local.get $5)
              )
             )
            )
            (then
             (ref.is_null
              (local.get $2)
             )
            )
            (else
             (if (result i32)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global119)
                )
               )
               (if (result i32)
                (select
                 (local.tee $6
                  (struct.get $type40 0
                   (local.get $2)
                  )
                 )
                 (i32.eqz
                  (local.get $6)
                 )
                 (struct.get $type40 0
                  (local.get $3)
                 )
                )
                (then
                 (local.set $3
                  (struct.get $type40 1
                   (local.get $3)
                  )
                 )
                 (local.set $2
                  (struct.get $type40 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready133)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global133)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.is_null
                    (local.get $2)
                   )
                  )
                  (else
                   (if (result i32)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global119)
                      )
                     )
                     (if (result i32)
                      (select
                       (local.tee $6
                        (struct.get $type40 0
                         (local.get $2)
                        )
                       )
                       (i32.eqz
                        (local.get $6)
                       )
                       (struct.get $type40 0
                        (local.get $3)
                       )
                      )
                      (then
                       (local.set $3
                        (struct.get $type40 1
                         (local.get $3)
                        )
                       )
                       (local.set $2
                        (struct.get $type40 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready133)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global133)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (ref.is_null
                          (local.get $2)
                         )
                        )
                        (else
                         (if (result i32)
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global119)
                            )
                           )
                           (if (result i32)
                            (select
                             (local.tee $6
                              (struct.get $type40 0
                               (local.get $2)
                              )
                             )
                             (i32.eqz
                              (local.get $6)
                             )
                             (struct.get $type40 0
                              (local.get $3)
                             )
                            )
                            (then
                             (local.set $3
                              (struct.get $type40 1
                               (local.get $3)
                              )
                             )
                             (local.set $2
                              (struct.get $type40 1
                               (local.get $2)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready133)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global133)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.is_null
                                (local.get $2)
                               )
                              )
                              (else
                               (if (result i32)
                                (ref.is_null
                                 (local.get $2)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global119)
                                  )
                                 )
                                 (if (result i32)
                                  (select
                                   (local.tee $6
                                    (struct.get $type40 0
                                     (local.get $2)
                                    )
                                   )
                                   (i32.eqz
                                    (local.get $6)
                                   )
                                   (struct.get $type40 0
                                    (local.get $3)
                                   )
                                  )
                                  (then
                                   (local.set $3
                                    (struct.get $type40 1
                                     (local.get $3)
                                    )
                                   )
                                   (local.set $2
                                    (struct.get $type40 1
                                     (local.get $2)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready133)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global133)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $3)
                                    )
                                    (then
                                     (ref.is_null
                                      (local.get $2)
                                     )
                                    )
                                    (else
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global119)
                                        )
                                       )
                                       (if (result i32)
                                        (select
                                         (local.tee $6
                                          (struct.get $type40 0
                                           (local.get $2)
                                          )
                                         )
                                         (i32.eqz
                                          (local.get $6)
                                         )
                                         (struct.get $type40 0
                                          (local.get $3)
                                         )
                                        )
                                        (then
                                         (local.set $3
                                          (struct.get $type40 1
                                           (local.get $3)
                                          )
                                         )
                                         (local.set $2
                                          (struct.get $type40 1
                                           (local.get $2)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready133)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global133)
                                          )
                                         )
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                          )
                                          (else
                                           (if (result i32)
                                            (ref.is_null
                                             (local.get $2)
                                            )
                                            (then
                                             (i32.const 0)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global119)
                                              )
                                             )
                                             (if (result i32)
                                              (select
                                               (local.tee $6
                                                (struct.get $type40 0
                                                 (local.get $2)
                                                )
                                               )
                                               (i32.eqz
                                                (local.get $6)
                                               )
                                               (struct.get $type40 0
                                                (local.get $3)
                                               )
                                              )
                                              (then
                                               (local.set $3
                                                (struct.get $type40 1
                                                 (local.get $3)
                                                )
                                               )
                                               (local.set $2
                                                (struct.get $type40 1
                                                 (local.get $2)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready133)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global133)
                                                )
                                               )
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $3)
                                                )
                                                (then
                                                 (ref.is_null
                                                  (local.get $2)
                                                 )
                                                )
                                                (else
                                                 (if (result i32)
                                                  (ref.is_null
                                                   (local.get $2)
                                                  )
                                                  (then
                                                   (i32.const 0)
                                                  )
                                                  (else
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global119)
                                                    )
                                                   )
                                                   (if (result i32)
                                                    (select
                                                     (local.tee $6
                                                      (struct.get $type40 0
                                                       (local.get $2)
                                                      )
                                                     )
                                                     (i32.eqz
                                                      (local.get $6)
                                                     )
                                                     (struct.get $type40 0
                                                      (local.get $3)
                                                     )
                                                    )
                                                    (then
                                                     (local.set $3
                                                      (struct.get $type40 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (local.set $2
                                                      (struct.get $type40 1
                                                       (local.get $2)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready133)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global133)
                                                      )
                                                     )
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $3)
                                                      )
                                                      (then
                                                       (ref.is_null
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (ref.is_null
                                                         (local.get $2)
                                                        )
                                                        (then
                                                         (i32.const 0)
                                                        )
                                                        (else
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global119)
                                                          )
                                                         )
                                                         (if (result i32)
                                                          (select
                                                           (local.tee $6
                                                            (struct.get $type40 0
                                                             (local.get $2)
                                                            )
                                                           )
                                                           (i32.eqz
                                                            (local.get $6)
                                                           )
                                                           (struct.get $type40 0
                                                            (local.get $3)
                                                           )
                                                          )
                                                          (then
                                                           (local.set $3
                                                            (struct.get $type40 1
                                                             (local.get $3)
                                                            )
                                                           )
                                                           (local.set $2
                                                            (struct.get $type40 1
                                                             (local.get $2)
                                                            )
                                                           )
                                                           (if
                                                            (i32.eqz
                                                             (global.get $ready133)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (drop
                                                            (ref.as_non_null
                                                             (global.get $global133)
                                                            )
                                                           )
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $3)
                                                            )
                                                            (then
                                                             (ref.is_null
                                                              (local.get $2)
                                                             )
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (ref.is_null
                                                               (local.get $2)
                                                              )
                                                              (then
                                                               (i32.const 0)
                                                              )
                                                              (else
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global119)
                                                                )
                                                               )
                                                               (if (result i32)
                                                                (select
                                                                 (local.tee $6
                                                                  (struct.get $type40 0
                                                                   (local.get $2)
                                                                  )
                                                                 )
                                                                 (i32.eqz
                                                                  (local.get $6)
                                                                 )
                                                                 (struct.get $type40 0
                                                                  (local.get $3)
                                                                 )
                                                                )
                                                                (then
                                                                 (call $function49
                                                                  (struct.get $type40 1
                                                                   (local.get $3)
                                                                  )
                                                                  (block (result (ref null $type40))
                                                                   (local.set $scratch
                                                                    (struct.get $type40 1
                                                                     (local.get $2)
                                                                    )
                                                                   )
                                                                   (if
                                                                    (i32.eqz
                                                                     (global.get $ready133)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (drop
                                                                    (ref.as_non_null
                                                                     (global.get $global133)
                                                                    )
                                                                   )
                                                                   (local.get $scratch)
                                                                  )
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (else
                                   (i32.const 0)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                            (else
                             (i32.const 0)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
             )
            )
           )
           (then
            (return_call $function50
             (struct.get $type39 1
              (local.get $5)
             )
             (block (result (ref null $type39))
              (local.set $scratch_8
               (struct.get $type39 1
                (local.get $4)
               )
              )
              (if
               (i32.eqz
                (global.get $ready136)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global136)
               )
              )
              (local.get $scratch_8)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (i64.ne
       (if (result i64)
        (local.tee $6
         (struct.get $type35 0
          (local.get $0)
         )
        )
        (then
         (if (result i64)
          (i32.eq
           (local.get $6)
           (i32.const 1)
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (i32.eq
             (struct.get $type35 0
              (local.get $0)
             )
             (i32.const 2)
            )
            (then
             (drop
              (ref.cast (ref $type38)
               (local.get $0)
              )
             )
             (i64.const 2)
            )
            (else
             (i64.const 3)
            )
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
       (i64.const 3)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function52 (type $call72) (param $0 (ref null $type28)) (result i32)
  (local $1 (ref null $type28))
  (local $2 (ref $type29))
  (local $3 i32)
  (local $scratch (ref null $type28))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global129)
     )
    )
    (local.set $2
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (if (result i32)
     (local.tee $3
      (if (result i32)
       (ref.is_null
        (local.tee $1
         (struct.get $type28 1
          (local.get $0)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (if (result i32)
         (local.tee $3
          (call $function46
           (local.get $2)
           (struct.get $type28 0
            (local.get $1)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready129)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global129)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global126)
             )
            )
            (if (result i32)
             (local.tee $3
              (call $function46
               (local.get $2)
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready129)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global129)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global126)
                 )
                )
                (if (result i32)
                 (local.tee $3
                  (call $function46
                   (local.get $2)
                   (struct.get $type28 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready129)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global129)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global126)
                     )
                    )
                    (if (result i32)
                     (local.tee $3
                      (call $function46
                       (local.get $2)
                       (struct.get $type28 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (local.set $1
                       (struct.get $type28 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready129)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global129)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global126)
                         )
                        )
                        (if (result i32)
                         (local.tee $3
                          (call $function46
                           (local.get $2)
                           (struct.get $type28 0
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (local.get $3)
                         )
                         (else
                          (local.set $1
                           (struct.get $type28 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready129)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global129)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global126)
                             )
                            )
                            (if (result i32)
                             (local.tee $3
                              (call $function46
                               (local.get $2)
                               (struct.get $type28 0
                                (local.get $1)
                               )
                              )
                             )
                             (then
                              (local.get $3)
                             )
                             (else
                              (local.set $1
                               (struct.get $type28 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready129)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global129)
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global126)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $3
                                  (call $function46
                                   (local.get $2)
                                   (struct.get $type28 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $3)
                                 )
                                 (else
                                  (local.set $1
                                   (struct.get $type28 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready129)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global129)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global126)
                                     )
                                    )
                                    (if (result i32)
                                     (local.tee $3
                                      (call $function46
                                       (local.get $2)
                                       (struct.get $type28 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $3)
                                     )
                                     (else
                                      (local.set $1
                                       (struct.get $type28 1
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready129)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global129)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global126)
                                         )
                                        )
                                        (if (result i32)
                                         (local.tee $3
                                          (call $function46
                                           (local.get $2)
                                           (struct.get $type28 0
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $3)
                                         )
                                         (else
                                          (local.set $1
                                           (struct.get $type28 1
                                            (local.get $1)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready129)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global129)
                                           )
                                          )
                                          (call $function47
                                           (local.get $2)
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (return_call $function52
       (block (result (ref null $type28))
        (local.set $scratch
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready142)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global142)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function55 (type $call82) (param $0 i64) (param $1 i64) (result (ref $type35))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 (ref null $type33))
  (local $6 (ref null $type33))
  (local $7 (ref null $type33))
  (local $8 (ref $type29))
  (local $9 (ref $type29))
  (local $10 (ref $environment77))
  (local $11 (ref $call65))
  (local $12 (ref null $type40))
  (local $13 (ref struct))
  (local $14 (ref $type54))
  (local $15 (ref $type65))
  (local $16 (ref $type97))
  (local $17 (ref $type48))
  (local $18 i64)
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref $type35))
   (i32.and
    (i32.wrap_i64
     (i64.and
      (local.get $1)
      (i64.const 1)
     )
    )
    (i32.wrap_i64
     (i64.and
      (local.get $0)
      (i64.const 1)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global153)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global165)
     )
    )
    (local.set $7
     (if (result (ref null $type33))
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (struct.new $type33
        (call_ref $call65
         (struct.get $type65 1
          (local.tee $15
           (struct.new $type65
            (ref.func $function58)
            (struct.new $environment58
             (local.get $1)
             (struct.new_default $type74)
            )
           )
          )
         )
         (i64.const 0)
         (local.tee $11
          (struct.get $type65 0
           (local.get $15)
          )
         )
        )
        (if (result (ref null $type33))
         (i64.gt_s
          (local.get $0)
          (i64.const 1)
         )
         (then
          (struct.new $type33
           (call_ref $call65
            (local.tee $13
             (struct.get $type65 1
              (local.get $15)
             )
            )
            (i64.const 1)
            (local.get $11)
           )
           (if (result (ref null $type33))
            (i64.gt_s
             (local.get $0)
             (i64.const 2)
            )
            (then
             (struct.new $type33
              (call_ref $call65
               (local.get $13)
               (i64.const 2)
               (local.get $11)
              )
              (if (result (ref null $type33))
               (i64.gt_s
                (local.get $0)
                (i64.const 3)
               )
               (then
                (struct.new $type33
                 (call_ref $call65
                  (local.get $13)
                  (i64.const 3)
                  (local.get $11)
                 )
                 (if (result (ref null $type33))
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 4)
                  )
                  (then
                   (struct.new $type33
                    (call_ref $call65
                     (local.get $13)
                     (i64.const 4)
                     (local.get $11)
                    )
                    (if (result (ref null $type33))
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 5)
                     )
                     (then
                      (struct.new $type33
                       (call_ref $call65
                        (local.get $13)
                        (i64.const 5)
                        (local.get $11)
                       )
                       (if (result (ref null $type33))
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 6)
                        )
                        (then
                         (struct.new $type33
                          (call_ref $call65
                           (local.get $13)
                           (i64.const 6)
                           (local.get $11)
                          )
                          (if (result (ref null $type33))
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 7)
                           )
                           (then
                            (struct.new $type33
                             (call_ref $call65
                              (local.get $13)
                              (i64.const 7)
                              (local.get $11)
                             )
                             (call $function63
                              (local.get $0)
                              (local.get $15)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 8)
                             )
                            )
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         )
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      )
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   )
                  )
                  (else
                   (ref.null none)
                  )
                 )
                )
               )
               (else
                (ref.null none)
               )
              )
             )
            )
            (else
             (ref.null none)
            )
           )
          )
         )
         (else
          (ref.null none)
         )
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global165)
     )
    )
    (local.set $6
     (if (result (ref null $type33))
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (struct.new $type33
        (call_ref $call65
         (struct.get $type65 1
          (local.tee $15
           (struct.new $type65
            (ref.func $function64)
            (struct.new $environment64
             (local.get $1)
            )
           )
          )
         )
         (i64.const 0)
         (local.tee $11
          (struct.get $type65 0
           (local.get $15)
          )
         )
        )
        (if (result (ref null $type33))
         (i64.gt_s
          (local.get $0)
          (i64.const 1)
         )
         (then
          (struct.new $type33
           (call_ref $call65
            (local.tee $13
             (struct.get $type65 1
              (local.get $15)
             )
            )
            (i64.const 1)
            (local.get $11)
           )
           (if (result (ref null $type33))
            (i64.gt_s
             (local.get $0)
             (i64.const 2)
            )
            (then
             (struct.new $type33
              (call_ref $call65
               (local.get $13)
               (i64.const 2)
               (local.get $11)
              )
              (if (result (ref null $type33))
               (i64.gt_s
                (local.get $0)
                (i64.const 3)
               )
               (then
                (struct.new $type33
                 (call_ref $call65
                  (local.get $13)
                  (i64.const 3)
                  (local.get $11)
                 )
                 (if (result (ref null $type33))
                  (i64.gt_s
                   (local.get $0)
                   (i64.const 4)
                  )
                  (then
                   (struct.new $type33
                    (call_ref $call65
                     (local.get $13)
                     (i64.const 4)
                     (local.get $11)
                    )
                    (if (result (ref null $type33))
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 5)
                     )
                     (then
                      (struct.new $type33
                       (call_ref $call65
                        (local.get $13)
                        (i64.const 5)
                        (local.get $11)
                       )
                       (if (result (ref null $type33))
                        (i64.gt_s
                         (local.get $0)
                         (i64.const 6)
                        )
                        (then
                         (struct.new $type33
                          (call_ref $call65
                           (local.get $13)
                           (i64.const 6)
                           (local.get $11)
                          )
                          (if (result (ref null $type33))
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 7)
                           )
                           (then
                            (struct.new $type33
                             (call_ref $call65
                              (local.get $13)
                              (i64.const 7)
                              (local.get $11)
                             )
                             (if (result (ref null $type33))
                              (i64.gt_s
                               (local.get $0)
                               (i64.const 8)
                              )
                              (then
                               (struct.new $type33
                                (call_ref $call65
                                 (local.get $13)
                                 (i64.const 8)
                                 (local.get $11)
                                )
                                (call $function63
                                 (local.get $0)
                                 (local.get $15)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 9)
                                )
                               )
                              )
                              (else
                               (ref.null none)
                              )
                             )
                            )
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         )
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      )
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   )
                  )
                  (else
                   (ref.null none)
                  )
                 )
                )
               )
               (else
                (ref.null none)
               )
              )
             )
            )
            (else
             (ref.null none)
            )
           )
          )
         )
         (else
          (ref.null none)
         )
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global175)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global180)
     )
    )
    (local.set $17
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (local.set $3
     (if (result (ref null $type28))
      (ref.is_null
       (local.get $6)
      )
      (then
       (ref.null none)
      )
      (else
       (local.set $3
        (struct.get $type33 0
         (local.get $6)
        )
       )
       (local.set $2
        (call $function70
         (local.get $17)
         (ref.null none)
         (i32.const 0)
         (i32.const 1)
         (struct.get $type33 1
          (local.get $6)
         )
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $3)
        )
        (then
         (local.get $2)
        )
        (else
         (struct.new $type28
          (struct.get $type28 0
           (local.get $3)
          )
          (block (result (ref null $type28))
           (local.set $3
            (struct.get $type28 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready177)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global177)
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $2)
            )
            (else
             (struct.new $type28
              (struct.get $type28 0
               (local.get $3)
              )
              (block (result (ref null $type28))
               (local.set $3
                (struct.get $type28 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready177)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global177)
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $2)
                )
                (else
                 (struct.new $type28
                  (struct.get $type28 0
                   (local.get $3)
                  )
                  (block (result (ref null $type28))
                   (local.set $3
                    (struct.get $type28 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready177)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global177)
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (struct.new $type28
                      (struct.get $type28 0
                       (local.get $3)
                      )
                      (block (result (ref null $type28))
                       (local.set $3
                        (struct.get $type28 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready177)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global177)
                        )
                       )
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (struct.new $type28
                          (struct.get $type28 0
                           (local.get $3)
                          )
                          (block (result (ref null $type28))
                           (local.set $3
                            (struct.get $type28 1
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready177)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global177)
                            )
                           )
                           (if (result (ref null $type28))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $2)
                            )
                            (else
                             (struct.new $type28
                              (struct.get $type28 0
                               (local.get $3)
                              )
                              (block (result (ref null $type28))
                               (local.set $3
                                (struct.get $type28 1
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready177)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global177)
                                )
                               )
                               (if (result (ref null $type28))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $2)
                                )
                                (else
                                 (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $3)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $3
                                    (struct.get $type28 1
                                     (local.get $3)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready177)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global177)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (ref.is_null
                                     (local.get $3)
                                    )
                                    (then
                                     (local.get $2)
                                    )
                                    (else
                                     (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $3)
                                      )
                                      (call $function68
                                       (struct.get $type28 1
                                        (local.get $3)
                                       )
                                       (block (result (ref null $type28))
                                        (if
                                         (i32.eqz
                                          (global.get $ready177)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global177)
                                         )
                                        )
                                        (local.get $2)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (local.set $4
     (if (result (ref null $type28))
      (ref.is_null
       (local.get $3)
      )
      (then
       (ref.null none)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global146)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global194)
        )
       )
       (struct.set $type97 1
        (local.tee $16
         (struct.new_default $type97)
        )
        (struct.new $type95
         (struct.new $environment77
          (local.get $16)
         )
        )
       )
       (struct.set $type97 0
        (local.get $16)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type97 0
          (local.get $16)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $10
        (struct.get $type95 0
         (struct.get $type97 1
          (local.get $16)
         )
        )
       )
       (local.set $18
        (i64.rem_s
         (i64.const 12751)
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 0)
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type97 0
              (struct.get $environment77 0
               (local.get $10)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (struct.get $type95 0
             (struct.get $type97 1
              (struct.get $environment77 0
               (local.get $10)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i64.const 1)
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (struct.get $type97 0
                (struct.get $environment77 0
                 (local.get $10)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $10
              (struct.get $type95 0
               (struct.get $type97 1
                (struct.get $environment77 0
                 (local.get $10)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i64.const 2)
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type97 0
                  (struct.get $environment77 0
                   (local.get $10)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $10
                (struct.get $type95 0
                 (struct.get $type97 1
                  (struct.get $environment77 0
                   (local.get $10)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i64.const 3)
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type97 0
                    (struct.get $environment77 0
                     (local.get $10)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $10
                  (struct.get $type95 0
                   (struct.get $type97 1
                    (struct.get $environment77 0
                     (local.get $10)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type97 0
                      (struct.get $environment77 0
                       (local.get $10)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $10
                    (struct.get $type95 0
                     (struct.get $type97 1
                      (struct.get $environment77 0
                       (local.get $10)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type97 0
                        (struct.get $environment77 0
                         (local.get $10)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $10
                      (struct.get $type95 0
                       (struct.get $type97 1
                        (struct.get $environment77 0
                         (local.get $10)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (local.set $2
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type97 0
                          (struct.get $environment77 0
                           (local.get $10)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function77
                        (struct.get $type95 0
                         (struct.get $type97 1
                          (struct.get $environment77 0
                           (local.get $10)
                          )
                         )
                        )
                        (local.get $2)
                        (i64.const 7)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global200)
        )
       )
       (struct.new $type28
        (if (result (ref $type29))
         (i64.eqz
          (local.get $18)
         )
         (then
          (struct.get $type28 0
           (local.get $3)
          )
         )
         (else
          (local.set $2
           (struct.get $type28 1
            (local.get $3)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $1
               (i64.sub
                (local.get $18)
                (i64.const 1)
               )
              )
              (local.get $18)
             )
             (i64.xor
              (local.get $18)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready200)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global200)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.get $1)
           )
           (then
            (struct.get $type28 0
             (local.get $2)
            )
           )
           (else
            (local.set $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $0
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (local.get $1)
               )
               (i64.xor
                (local.get $1)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready200)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global200)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.get $0)
             )
             (then
              (struct.get $type28 0
               (local.get $2)
              )
             )
             (else
              (local.set $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $1
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                  (local.get $0)
                 )
                 (i64.xor
                  (local.get $0)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready200)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global200)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.get $1)
               )
               (then
                (struct.get $type28 0
                 (local.get $2)
                )
               )
               (else
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (if
                 (i64.lt_s
                  (i64.and
                   (i64.xor
                    (local.tee $0
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (local.get $1)
                   )
                   (i64.xor
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready200)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global200)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.get $0)
                 )
                 (then
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                 (else
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $1
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                      (local.get $0)
                     )
                     (i64.xor
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready200)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global200)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.get $1)
                   )
                   (then
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                   (else
                    (local.set $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $0
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (local.get $1)
                       )
                       (i64.xor
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready200)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global200)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (local.get $0)
                     )
                     (then
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                     (else
                      (call $function79
                       (struct.get $type28 1
                        (local.get $2)
                       )
                       (block (result i64)
                        (if
                         (i64.lt_s
                          (i64.and
                           (i64.xor
                            (local.tee $1
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                            (local.get $0)
                           )
                           (i64.xor
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready200)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global200)
                         )
                        )
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (block (result (ref null $type28))
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (call $function73
          (if (result (ref null $type28))
           (i64.eqz
            (local.get $18)
           )
           (then
            (struct.get $type28 1
             (local.get $3)
            )
           )
           (else
            (struct.new $type28
             (struct.get $type28 0
              (local.get $3)
             )
             (block (result (ref null $type28))
              (local.set $2
               (struct.get $type28 1
                (local.get $3)
               )
              )
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $1
                   (i64.sub
                    (local.get $18)
                    (i64.const 1)
                   )
                  )
                  (local.get $18)
                 )
                 (i64.xor
                  (local.get $18)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready203)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global203)
               )
              )
              (if (result (ref null $type28))
               (i64.eqz
                (local.get $1)
               )
               (then
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (else
                (struct.new $type28
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (block (result (ref null $type28))
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $0
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (local.get $1)
                     )
                     (i64.xor
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready203)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global203)
                   )
                  )
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $0)
                   )
                   (then
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (else
                    (struct.new $type28
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (block (result (ref null $type28))
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i64.lt_s
                        (i64.and
                         (i64.xor
                          (local.tee $1
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                          (local.get $0)
                         )
                         (i64.xor
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready203)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global203)
                       )
                      )
                      (if (result (ref null $type28))
                       (i64.eqz
                        (local.get $1)
                       )
                       (then
                        (struct.get $type28 1
                         (local.get $2)
                        )
                       )
                       (else
                        (struct.new $type28
                         (struct.get $type28 0
                          (local.get $2)
                         )
                         (block (result (ref null $type28))
                          (local.set $2
                           (struct.get $type28 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $0
                               (i64.sub
                                (local.get $1)
                                (i64.const 1)
                               )
                              )
                              (local.get $1)
                             )
                             (i64.xor
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready203)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global203)
                           )
                          )
                          (if (result (ref null $type28))
                           (i64.eqz
                            (local.get $0)
                           )
                           (then
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           )
                           (else
                            (struct.new $type28
                             (struct.get $type28 0
                              (local.get $2)
                             )
                             (block (result (ref null $type28))
                              (local.set $2
                               (struct.get $type28 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i64.lt_s
                                (i64.and
                                 (i64.xor
                                  (local.tee $1
                                   (i64.sub
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                  )
                                  (local.get $0)
                                 )
                                 (i64.xor
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready203)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global203)
                               )
                              )
                              (if (result (ref null $type28))
                               (i64.eqz
                                (local.get $1)
                               )
                               (then
                                (struct.get $type28 1
                                 (local.get $2)
                                )
                               )
                               (else
                                (struct.new $type28
                                 (struct.get $type28 0
                                  (local.get $2)
                                 )
                                 (block (result (ref null $type28))
                                  (local.set $2
                                   (struct.get $type28 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i64.lt_s
                                    (i64.and
                                     (i64.xor
                                      (local.tee $0
                                       (i64.sub
                                        (local.get $1)
                                        (i64.const 1)
                                       )
                                      )
                                      (local.get $1)
                                     )
                                     (i64.xor
                                      (local.get $1)
                                      (i64.const 1)
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready203)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global203)
                                   )
                                  )
                                  (if (result (ref null $type28))
                                   (i64.eqz
                                    (local.get $0)
                                   )
                                   (then
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                   )
                                   (else
                                    (struct.new $type28
                                     (struct.get $type28 0
                                      (local.get $2)
                                     )
                                     (call $function80
                                      (struct.get $type28 1
                                       (local.get $2)
                                      )
                                      (block (result i64)
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.tee $1
                                            (i64.sub
                                             (local.get $0)
                                             (i64.const 1)
                                            )
                                           )
                                           (local.get $0)
                                          )
                                          (i64.xor
                                           (local.get $0)
                                           (i64.const 1)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready203)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global203)
                                        )
                                       )
                                       (local.get $1)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready190)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global190)
            )
           )
           (i64.const 12751)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready206)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global206)
     )
    )
    (local.set $5
     (if (result (ref null $type33))
      (ref.is_null
       (local.get $4)
      )
      (then
       (local.get $7)
      )
      (else
       (local.set $5
        (call $function83
         (struct.get $type28 0
          (local.get $4)
         )
         (block (result (ref null $type33))
          (local.set $2
           (struct.get $type28 1
            (local.get $4)
           )
          )
          (if
           (i32.eqz
            (global.get $ready210)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global210)
           )
          )
          (local.get $7)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready206)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global206)
        )
       )
       (if (result (ref null $type33))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $5)
        )
        (else
         (local.set $5
          (call $function83
           (struct.get $type28 0
            (local.get $2)
           )
           (block (result (ref null $type33))
            (local.set $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready210)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global210)
             )
            )
            (local.get $5)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready206)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global206)
          )
         )
         (if (result (ref null $type33))
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $5
            (call $function83
             (struct.get $type28 0
              (local.get $2)
             )
             (block (result (ref null $type33))
              (local.set $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready210)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global210)
               )
              )
              (local.get $5)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready206)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global206)
            )
           )
           (if (result (ref null $type33))
            (ref.is_null
             (local.get $2)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $5
              (call $function83
               (struct.get $type28 0
                (local.get $2)
               )
               (block (result (ref null $type33))
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready210)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global210)
                 )
                )
                (local.get $5)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready206)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global206)
              )
             )
             (if (result (ref null $type33))
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $5
                (call $function83
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (block (result (ref null $type33))
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready210)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global210)
                   )
                  )
                  (local.get $5)
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready206)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global206)
                )
               )
               (if (result (ref null $type33))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $5
                  (call $function83
                   (struct.get $type28 0
                    (local.get $2)
                   )
                   (block (result (ref null $type33))
                    (local.set $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready210)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global210)
                     )
                    )
                    (local.get $5)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready206)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global206)
                  )
                 )
                 (if (result (ref null $type33))
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $5
                    (call $function83
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (block (result (ref null $type33))
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready210)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global210)
                       )
                      )
                      (local.get $5)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready206)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global206)
                    )
                   )
                   (if (result (ref null $type33))
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $5
                      (call $function83
                       (struct.get $type28 0
                        (local.get $2)
                       )
                       (block (result (ref null $type33))
                        (local.set $2
                         (struct.get $type28 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready210)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global210)
                         )
                        )
                        (local.get $5)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready206)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global206)
                      )
                     )
                     (if (result (ref null $type33))
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $5
                        (call $function83
                         (struct.get $type28 0
                          (local.get $2)
                         )
                         (block (result (ref null $type33))
                          (local.set $2
                           (struct.get $type28 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready210)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global210)
                           )
                          )
                          (local.get $5)
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready206)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global206)
                        )
                       )
                       (call $function81
                        (local.get $2)
                        (local.get $5)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready291)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global291)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global293)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global301)
     )
    )
    (local.set $14
     (struct.new $type54
      (struct.new $environment116
       (ref.as_non_null
        (global.get $global107)
       )
      )
     )
    )
    (struct.new $type38
     (i32.const 2)
     (if (result (ref null $type39))
      (ref.is_null
       (local.get $5)
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type39
        (call $function116
         (struct.get $type54 0
          (local.get $14)
         )
         (struct.get $type33 0
          (local.get $5)
         )
        )
        (block (result (ref null $type39))
         (local.set $5
          (struct.get $type33 1
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready301)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global301)
          )
         )
         (if (result (ref null $type39))
          (ref.is_null
           (local.get $5)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type39
            (call $function116
             (struct.get $type54 0
              (local.get $14)
             )
             (struct.get $type33 0
              (local.get $5)
             )
            )
            (block (result (ref null $type39))
             (local.set $5
              (struct.get $type33 1
               (local.get $5)
              )
             )
             (if
              (i32.eqz
               (global.get $ready301)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global301)
              )
             )
             (if (result (ref null $type39))
              (ref.is_null
               (local.get $5)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type39
                (call $function116
                 (struct.get $type54 0
                  (local.get $14)
                 )
                 (struct.get $type33 0
                  (local.get $5)
                 )
                )
                (block (result (ref null $type39))
                 (local.set $5
                  (struct.get $type33 1
                   (local.get $5)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready301)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global301)
                  )
                 )
                 (if (result (ref null $type39))
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type39
                    (call $function116
                     (struct.get $type54 0
                      (local.get $14)
                     )
                     (struct.get $type33 0
                      (local.get $5)
                     )
                    )
                    (block (result (ref null $type39))
                     (local.set $5
                      (struct.get $type33 1
                       (local.get $5)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready301)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global301)
                      )
                     )
                     (if (result (ref null $type39))
                      (ref.is_null
                       (local.get $5)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type39
                        (call $function116
                         (struct.get $type54 0
                          (local.get $14)
                         )
                         (struct.get $type33 0
                          (local.get $5)
                         )
                        )
                        (block (result (ref null $type39))
                         (local.set $5
                          (struct.get $type33 1
                           (local.get $5)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready301)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global301)
                          )
                         )
                         (if (result (ref null $type39))
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type39
                            (call $function116
                             (struct.get $type54 0
                              (local.get $14)
                             )
                             (struct.get $type33 0
                              (local.get $5)
                             )
                            )
                            (block (result (ref null $type39))
                             (local.set $5
                              (struct.get $type33 1
                               (local.get $5)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready301)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global301)
                              )
                             )
                             (if (result (ref null $type39))
                              (ref.is_null
                               (local.get $5)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type39
                                (call $function116
                                 (struct.get $type54 0
                                  (local.get $14)
                                 )
                                 (struct.get $type33 0
                                  (local.get $5)
                                 )
                                )
                                (block (result (ref null $type39))
                                 (local.set $5
                                  (struct.get $type33 1
                                   (local.get $5)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready301)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global301)
                                  )
                                 )
                                 (if (result (ref null $type39))
                                  (ref.is_null
                                   (local.get $5)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type39
                                    (call $function116
                                     (struct.get $type54 0
                                      (local.get $14)
                                     )
                                     (struct.get $type33 0
                                      (local.get $5)
                                     )
                                    )
                                    (block (result (ref null $type39))
                                     (local.set $5
                                      (struct.get $type33 1
                                       (local.get $5)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready301)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global301)
                                      )
                                     )
                                     (call $function119
                                      (local.get $14)
                                      (local.get $5)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (ref.as_non_null
     (global.get $global113)
    )
   )
  )
 )
 (func $function56 (type $call74) (param $0 i64) (param $1 i64) (result (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.or
     (i64.and
      (local.get $1)
      (i64.const 1)
     )
     (i64.and
      (local.get $0)
      (i64.const 1)
     )
    )
   )
   (then
    (struct.new $type31
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (ref.as_non_null
     (global.get $global106)
    )
   )
  )
 )
 (func $function58 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 i64)
  (local $3 (ref $type63))
  (drop
   (ref.as_non_null
    (global.get $global159)
   )
  )
  (if (result (ref null $type28))
   (i64.gt_s
    (local.tee $2
     (struct.get $environment58 0
      (ref.cast (ref $environment58)
       (local.get $0)
      )
     )
    )
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (struct.new $type28
     (if (result (ref $type29))
      (i64.eqz
       (i64.and
        (local.tee $1
         (struct.get $environment59 0
          (struct.get $type63 0
           (local.tee $3
            (struct.new $type63
             (struct.new $environment59
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (then
       (struct.new $type31
        (local.get $1)
        (i64.const 0)
       )
      )
      (else
       (ref.as_non_null
        (global.get $global106)
       )
      )
     )
     (if (result (ref null $type28))
      (i64.gt_s
       (local.get $2)
       (i64.const 1)
      )
      (then
       (local.set $1
        (struct.get $environment59 0
         (struct.get $type63 0
          (local.get $3)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (struct.new $type28
        (ref.as_non_null
         (global.get $global106)
        )
        (if (result (ref null $type28))
         (i64.gt_s
          (local.get $2)
          (i64.const 2)
         )
         (then
          (struct.new $type28
           (if (result (ref $type29))
            (i64.eqz
             (i64.and
              (local.get $1)
              (i64.const 1)
             )
            )
            (then
             (struct.new $type31
              (local.get $1)
              (i64.const 2)
             )
            )
            (else
             (ref.as_non_null
              (global.get $global106)
             )
            )
           )
           (if (result (ref null $type28))
            (i64.gt_s
             (local.get $2)
             (i64.const 3)
            )
            (then
             (local.set $1
              (struct.get $environment59 0
               (struct.get $type63 0
                (local.get $3)
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (struct.new $type28
              (ref.as_non_null
               (global.get $global106)
              )
              (if (result (ref null $type28))
               (i64.gt_s
                (local.get $2)
                (i64.const 4)
               )
               (then
                (struct.new $type28
                 (if (result (ref $type29))
                  (i64.eqz
                   (i64.and
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (then
                   (struct.new $type31
                    (local.get $1)
                    (i64.const 4)
                   )
                  )
                  (else
                   (ref.as_non_null
                    (global.get $global106)
                   )
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.gt_s
                   (local.get $2)
                   (i64.const 5)
                  )
                  (then
                   (local.set $1
                    (struct.get $environment59 0
                     (struct.get $type63 0
                      (local.get $3)
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global122)
                    )
                   )
                   (struct.new $type28
                    (ref.as_non_null
                     (global.get $global106)
                    )
                    (if (result (ref null $type28))
                     (i64.gt_s
                      (local.get $2)
                      (i64.const 6)
                     )
                     (then
                      (struct.new $type28
                       (if (result (ref $type29))
                        (i64.eqz
                         (i64.and
                          (local.get $1)
                          (i64.const 1)
                         )
                        )
                        (then
                         (struct.new $type31
                          (local.get $1)
                          (i64.const 6)
                         )
                        )
                        (else
                         (ref.as_non_null
                          (global.get $global106)
                         )
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.gt_s
                         (local.get $2)
                         (i64.const 7)
                        )
                        (then
                         (local.set $1
                          (struct.get $environment59 0
                           (struct.get $type63 0
                            (local.get $3)
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global122)
                          )
                         )
                         (struct.new $type28
                          (ref.as_non_null
                           (global.get $global106)
                          )
                          (if (result (ref null $type28))
                           (i64.gt_s
                            (local.get $2)
                            (i64.const 8)
                           )
                           (then
                            (struct.new $type28
                             (call $function56
                              (local.get $1)
                              (i64.const 8)
                             )
                             (call $function61
                              (local.get $2)
                              (local.get $3)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 9)
                             )
                            )
                           )
                           (else
                            (ref.null none)
                           )
                          )
                         )
                        )
                        (else
                         (ref.null none)
                        )
                       )
                      )
                     )
                     (else
                      (ref.null none)
                     )
                    )
                   )
                  )
                  (else
                   (ref.null none)
                  )
                 )
                )
               )
               (else
                (ref.null none)
               )
              )
             )
            )
            (else
             (ref.null none)
            )
           )
          )
         )
         (else
          (ref.null none)
         )
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function61 (type $47) (param $0 i64) (param $1 (ref $type63)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref null $type28))
  (local $5 i64)
  (local $6 (ref $type29))
  (if (result (ref null $type28))
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (struct.new $type28
     (call $function56
      (struct.get $environment59 0
       (struct.get $type63 0
        (local.get $1)
       )
      )
      (local.get $4)
     )
     (block (result (ref null $type28))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $5
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (call $function61
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $5)
      )
     )
    )
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function63 (type $46) (param $0 i64) (param $1 (ref $type65)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref null $type33))
  (local $5 i64)
  (local $6 (ref null $type28))
  (if (result (ref null $type33))
   (i64.gt_s
    (local.get $0)
    (local.get $4)
   )
   (then
    (struct.new $type33
     (call_ref $call65
      (struct.get $type65 1
       (local.get $1)
      )
      (local.get $4)
      (struct.get $type65 0
       (local.get $1)
      )
     )
     (block (result (ref null $type33))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $5
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (call $function63
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $5)
      )
     )
    )
   )
   (else
    (ref.null none)
   )
  )
 )
 (func $function64 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref $type29))
  (local $5 (ref $call65))
  (local $6 (ref $type65))
  (local $7 (ref null $type33))
  (local $8 (ref $type48))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global165)
   )
  )
  (local.set $7
   (if (result (ref null $type33))
    (i64.gt_s
     (local.tee $9
      (struct.get $environment64 0
       (ref.cast (ref $environment64)
        (local.get $0)
       )
      )
     )
     (i64.const 0)
    )
    (then
     (struct.new $type33
      (call_ref $call65
       (struct.get $type65 1
        (local.tee $6
         (struct.new $type65
          (ref.func $function65)
          (struct.new $environment65
           (local.get $1)
          )
         )
        )
       )
       (i64.const 0)
       (local.tee $5
        (struct.get $type65 0
         (local.get $6)
        )
       )
      )
      (if (result (ref null $type33))
       (i64.gt_s
        (local.get $9)
        (i64.const 1)
       )
       (then
        (struct.new $type33
         (call_ref $call65
          (local.tee $0
           (struct.get $type65 1
            (local.get $6)
           )
          )
          (i64.const 1)
          (local.get $5)
         )
         (if (result (ref null $type33))
          (i64.gt_s
           (local.get $9)
           (i64.const 2)
          )
          (then
           (struct.new $type33
            (call_ref $call65
             (local.get $0)
             (i64.const 2)
             (local.get $5)
            )
            (if (result (ref null $type33))
             (i64.gt_s
              (local.get $9)
              (i64.const 3)
             )
             (then
              (struct.new $type33
               (call_ref $call65
                (local.get $0)
                (i64.const 3)
                (local.get $5)
               )
               (if (result (ref null $type33))
                (i64.gt_s
                 (local.get $9)
                 (i64.const 4)
                )
                (then
                 (struct.new $type33
                  (call_ref $call65
                   (local.get $0)
                   (i64.const 4)
                   (local.get $5)
                  )
                  (if (result (ref null $type33))
                   (i64.gt_s
                    (local.get $9)
                    (i64.const 5)
                   )
                   (then
                    (struct.new $type33
                     (call_ref $call65
                      (local.get $0)
                      (i64.const 5)
                      (local.get $5)
                     )
                     (if (result (ref null $type33))
                      (i64.gt_s
                       (local.get $9)
                       (i64.const 6)
                      )
                      (then
                       (struct.new $type33
                        (call_ref $call65
                         (local.get $0)
                         (i64.const 6)
                         (local.get $5)
                        )
                        (if (result (ref null $type33))
                         (i64.gt_s
                          (local.get $9)
                          (i64.const 7)
                         )
                         (then
                          (struct.new $type33
                           (call_ref $call65
                            (local.get $0)
                            (i64.const 7)
                            (local.get $5)
                           )
                           (if (result (ref null $type33))
                            (i64.gt_s
                             (local.get $9)
                             (i64.const 8)
                            )
                            (then
                             (struct.new $type33
                              (call_ref $call65
                               (local.get $0)
                               (i64.const 8)
                               (local.get $5)
                              )
                              (call $function63
                               (local.get $9)
                               (local.get $6)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.const 9)
                              )
                             )
                            )
                            (else
                             (ref.null none)
                            )
                           )
                          )
                         )
                         (else
                          (ref.null none)
                         )
                        )
                       )
                      )
                      (else
                       (ref.null none)
                      )
                     )
                    )
                   )
                   (else
                    (ref.null none)
                   )
                  )
                 )
                )
                (else
                 (ref.null none)
                )
               )
              )
             )
             (else
              (ref.null none)
             )
            )
           )
          )
          (else
           (ref.null none)
          )
         )
        )
       )
       (else
        (ref.null none)
       )
      )
     )
    )
    (else
     (ref.null none)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global180)
   )
  )
  (local.set $8
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $7)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $2
     (struct.get $type33 0
      (local.get $7)
     )
    )
    (local.set $3
     (call $function70
      (local.get $8)
      (ref.null none)
      (i32.const 0)
      (i32.const 1)
      (struct.get $type33 1
       (local.get $7)
      )
     )
    )
    (if (result (ref null $type28))
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (struct.new $type28
       (struct.get $type28 0
        (local.get $2)
       )
       (block (result (ref null $type28))
        (local.set $2
         (struct.get $type28 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready177)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global177)
         )
        )
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $2)
         )
         (then
          (local.get $3)
         )
         (else
          (struct.new $type28
           (struct.get $type28 0
            (local.get $2)
           )
           (block (result (ref null $type28))
            (local.set $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready177)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global177)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $2)
             )
             (then
              (local.get $3)
             )
             (else
              (struct.new $type28
               (struct.get $type28 0
                (local.get $2)
               )
               (block (result (ref null $type28))
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready177)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global177)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (struct.new $type28
                   (struct.get $type28 0
                    (local.get $2)
                   )
                   (block (result (ref null $type28))
                    (local.set $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready177)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global177)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (struct.new $type28
                       (struct.get $type28 0
                        (local.get $2)
                       )
                       (block (result (ref null $type28))
                        (local.set $2
                         (struct.get $type28 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready177)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global177)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (local.get $3)
                         )
                         (else
                          (struct.new $type28
                           (struct.get $type28 0
                            (local.get $2)
                           )
                           (block (result (ref null $type28))
                            (local.set $2
                             (struct.get $type28 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready177)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global177)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (local.get $3)
                             )
                             (else
                              (struct.new $type28
                               (struct.get $type28 0
                                (local.get $2)
                               )
                               (block (result (ref null $type28))
                                (local.set $2
                                 (struct.get $type28 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready177)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global177)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                 (then
                                  (local.get $3)
                                 )
                                 (else
                                  (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $2)
                                   )
                                   (call $function68
                                    (struct.get $type28 1
                                     (local.get $2)
                                    )
                                    (block (result (ref null $type28))
                                     (if
                                      (i32.eqz
                                       (global.get $ready177)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global177)
                                      )
                                     )
                                     (local.get $3)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call65) (param $0 (ref struct)) (param $1 i64) (result (ref null $type28))
  (local $2 i32)
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global119)
   )
  )
  (if (result (ref null $type28))
   (select
    (local.tee $2
     (i64.eqz
      (i64.and
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (i32.eqz
     (local.get $2)
    )
    (i64.eqz
     (i64.and
      (struct.get $environment65 0
       (ref.cast (ref $environment65)
        (local.get $0)
       )
      )
      (i64.const 1)
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global173)
     )
    )
    (struct.new $type28
     (struct.new $type31
      (struct.get $environment65 0
       (ref.cast (ref $environment65)
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (ref.null none)
    )
   )
  )
 )
 (func $function68 (type $call48) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (result (ref null $type28))
  (local $2 (ref $type29))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function68
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result (ref null $type28))
       (if
        (i32.eqz
         (global.get $ready177)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function70 (type $43) (param $0 (ref $type48)) (param $1 (ref null $type28)) (param $2 i32) (param $3 i32) (param $4 (ref null $type33)) (result (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref $type29))
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $5
     (struct.get $type33 0
      (local.get $4)
     )
    )
    (local.set $4
     (struct.get $type33 1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call $function70
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $3)
      (local.get $4)
     )
    )
    (if (result (ref null $type28))
     (ref.is_null
      (local.get $5)
     )
     (then
      (local.get $1)
     )
     (else
      (struct.new $type28
       (struct.get $type28 0
        (local.get $5)
       )
       (block (result (ref null $type28))
        (local.set $5
         (struct.get $type28 1
          (local.get $5)
         )
        )
        (if
         (i32.eqz
          (global.get $ready177)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global177)
         )
        )
        (if (result (ref null $type28))
         (ref.is_null
          (local.get $5)
         )
         (then
          (local.get $1)
         )
         (else
          (struct.new $type28
           (struct.get $type28 0
            (local.get $5)
           )
           (block (result (ref null $type28))
            (local.set $5
             (struct.get $type28 1
              (local.get $5)
             )
            )
            (if
             (i32.eqz
              (global.get $ready177)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global177)
             )
            )
            (if (result (ref null $type28))
             (ref.is_null
              (local.get $5)
             )
             (then
              (local.get $1)
             )
             (else
              (struct.new $type28
               (struct.get $type28 0
                (local.get $5)
               )
               (block (result (ref null $type28))
                (local.set $5
                 (struct.get $type28 1
                  (local.get $5)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready177)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global177)
                 )
                )
                (if (result (ref null $type28))
                 (ref.is_null
                  (local.get $5)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (struct.new $type28
                   (struct.get $type28 0
                    (local.get $5)
                   )
                   (block (result (ref null $type28))
                    (local.set $5
                     (struct.get $type28 1
                      (local.get $5)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready177)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global177)
                     )
                    )
                    (if (result (ref null $type28))
                     (ref.is_null
                      (local.get $5)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (struct.new $type28
                       (struct.get $type28 0
                        (local.get $5)
                       )
                       (block (result (ref null $type28))
                        (local.set $5
                         (struct.get $type28 1
                          (local.get $5)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready177)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global177)
                         )
                        )
                        (if (result (ref null $type28))
                         (ref.is_null
                          (local.get $5)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (struct.new $type28
                           (struct.get $type28 0
                            (local.get $5)
                           )
                           (block (result (ref null $type28))
                            (local.set $5
                             (struct.get $type28 1
                              (local.get $5)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready177)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global177)
                             )
                            )
                            (if (result (ref null $type28))
                             (ref.is_null
                              (local.get $5)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (struct.new $type28
                               (struct.get $type28 0
                                (local.get $5)
                               )
                               (block (result (ref null $type28))
                                (local.set $5
                                 (struct.get $type28 1
                                  (local.get $5)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready177)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global177)
                                 )
                                )
                                (if (result (ref null $type28))
                                 (ref.is_null
                                  (local.get $5)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (struct.new $type28
                                   (struct.get $type28 0
                                    (local.get $5)
                                   )
                                   (block (result (ref null $type28))
                                    (local.set $5
                                     (struct.get $type28 1
                                      (local.get $5)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready177)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global177)
                                     )
                                    )
                                    (if (result (ref null $type28))
                                     (ref.is_null
                                      (local.get $5)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (struct.new $type28
                                       (struct.get $type28 0
                                        (local.get $5)
                                       )
                                       (call $function68
                                        (struct.get $type28 1
                                         (local.get $5)
                                        )
                                        (block (result (ref null $type28))
                                         (if
                                          (i32.eqz
                                           (global.get $ready177)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global177)
                                          )
                                         )
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function73 (type $42) (param $0 (ref null $type28)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref null $type28))
  (local $3 (ref $environment77))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type97))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global146)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global194)
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.div_s
       (local.tee $7
        (i64.mul
         (local.get $1)
         (i64.const 3581)
        )
       )
       (i64.const 3581)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $1
         (i64.add
          (local.get $7)
          (i64.const 12751)
         )
        )
       )
       (i64.xor
        (local.get $1)
        (i64.const 12751)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type97 1
     (local.tee $6
      (struct.new_default $type97)
     )
     (struct.new $type95
      (struct.new $environment77
       (local.get $6)
      )
     )
    )
    (struct.set $type97 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type95 0
      (struct.get $type97 1
       (local.get $6)
      )
     )
    )
    (local.set $7
     (i64.rem_s
      (local.tee $9
       (i64.rem_s
        (local.get $1)
        (i64.const 131072)
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i64.const 0)
       )
       (else
        (local.set $2
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (struct.get $type97 0
           (struct.get $environment77 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type95 0
          (struct.get $type97 1
           (struct.get $environment77 0
            (local.get $3)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $2)
         )
         (then
          (i64.const 1)
         )
         (else
          (local.set $2
           (struct.get $type28 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type97 0
             (struct.get $environment77 0
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type95 0
            (struct.get $type97 1
             (struct.get $environment77 0
              (local.get $3)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i64.const 2)
           )
           (else
            (local.set $2
             (struct.get $type28 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (struct.get $type97 0
               (struct.get $environment77 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type95 0
              (struct.get $type97 1
               (struct.get $environment77 0
                (local.get $3)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $2)
             )
             (then
              (i64.const 3)
             )
             (else
              (local.set $2
               (struct.get $type28 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type97 0
                 (struct.get $environment77 0
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type95 0
                (struct.get $type97 1
                 (struct.get $environment77 0
                  (local.get $3)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i64.const 4)
               )
               (else
                (local.set $2
                 (struct.get $type28 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type97 0
                   (struct.get $environment77 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type95 0
                  (struct.get $type97 1
                   (struct.get $environment77 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i64.const 5)
                 )
                 (else
                  (local.set $2
                   (struct.get $type28 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type97 0
                     (struct.get $environment77 0
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type95 0
                    (struct.get $type97 1
                     (struct.get $environment77 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i64.const 6)
                   )
                   (else
                    (local.set $2
                     (struct.get $type28 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type97 0
                       (struct.get $environment77 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type95 0
                      (struct.get $type97 1
                       (struct.get $environment77 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (i64.const 7)
                     )
                     (else
                      (local.set $2
                       (struct.get $type28 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type97 0
                         (struct.get $environment77 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $function77
                       (struct.get $type95 0
                        (struct.get $type97 1
                         (struct.get $environment77 0
                          (local.get $3)
                         )
                        )
                       )
                       (local.get $2)
                       (i64.const 8)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global200)
     )
    )
    (struct.new $type28
     (if (result (ref $type29))
      (i64.eqz
       (local.get $7)
      )
      (then
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (else
       (local.set $2
        (struct.get $type28 1
         (local.get $0)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $1
            (i64.sub
             (local.get $7)
             (i64.const 1)
            )
           )
           (local.get $7)
          )
          (i64.xor
           (local.get $7)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready200)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global200)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (local.get $1)
        )
        (then
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (else
         (local.set $2
          (struct.get $type28 1
           (local.get $2)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $8
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (local.get $1)
            )
            (i64.xor
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (global.get $ready200)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global200)
          )
         )
         (if (result (ref $type29))
          (i64.eqz
           (local.get $8)
          )
          (then
           (struct.get $type28 0
            (local.get $2)
           )
          )
          (else
           (local.set $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $8)
                 (i64.const 1)
                )
               )
               (local.get $8)
              )
              (i64.xor
               (local.get $8)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready200)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global200)
            )
           )
           (if (result (ref $type29))
            (i64.eqz
             (local.get $1)
            )
            (then
             (struct.get $type28 0
              (local.get $2)
             )
            )
            (else
             (local.set $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $8
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (local.get $1)
                )
                (i64.xor
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (global.get $ready200)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global200)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (local.get $8)
              )
              (then
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (else
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $1
                    (i64.sub
                     (local.get $8)
                     (i64.const 1)
                    )
                   )
                   (local.get $8)
                  )
                  (i64.xor
                   (local.get $8)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready200)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global200)
                )
               )
               (if (result (ref $type29))
                (i64.eqz
                 (local.get $1)
                )
                (then
                 (struct.get $type28 0
                  (local.get $2)
                 )
                )
                (else
                 (local.set $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $8
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (local.get $1)
                    )
                    (i64.xor
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready200)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global200)
                  )
                 )
                 (if (result (ref $type29))
                  (i64.eqz
                   (local.get $8)
                  )
                  (then
                   (struct.get $type28 0
                    (local.get $2)
                   )
                  )
                  (else
                   (local.set $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $1
                        (i64.sub
                         (local.get $8)
                         (i64.const 1)
                        )
                       )
                       (local.get $8)
                      )
                      (i64.xor
                       (local.get $8)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready200)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global200)
                    )
                   )
                   (if (result (ref $type29))
                    (i64.eqz
                     (local.get $1)
                    )
                    (then
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (else
                     (call $function79
                      (struct.get $type28 1
                       (local.get $2)
                      )
                      (block (result i64)
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $8
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (local.get $1)
                          )
                          (i64.xor
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready200)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global200)
                        )
                       )
                       (local.get $8)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (block (result (ref null $type28))
      (drop
       (ref.as_non_null
        (global.get $global203)
       )
      )
      (call $function73
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $7)
        )
        (then
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (else
         (struct.new $type28
          (struct.get $type28 0
           (local.get $0)
          )
          (block (result (ref null $type28))
           (local.set $0
            (struct.get $type28 1
             (local.get $0)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $7)
                 (i64.const 1)
                )
               )
               (local.get $7)
              )
              (i64.xor
               (local.get $7)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready203)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global203)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.get $1)
            )
            (then
             (struct.get $type28 1
              (local.get $0)
             )
            )
            (else
             (struct.new $type28
              (struct.get $type28 0
               (local.get $0)
              )
              (block (result (ref null $type28))
               (local.set $0
                (struct.get $type28 1
                 (local.get $0)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $7
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (local.get $1)
                  )
                  (i64.xor
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready203)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global203)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $7)
                )
                (then
                 (struct.get $type28 1
                  (local.get $0)
                 )
                )
                (else
                 (struct.new $type28
                  (struct.get $type28 0
                   (local.get $0)
                  )
                  (block (result (ref null $type28))
                   (local.set $0
                    (struct.get $type28 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $1
                        (i64.sub
                         (local.get $7)
                         (i64.const 1)
                        )
                       )
                       (local.get $7)
                      )
                      (i64.xor
                       (local.get $7)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready203)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global203)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.get $1)
                    )
                    (then
                     (struct.get $type28 1
                      (local.get $0)
                     )
                    )
                    (else
                     (struct.new $type28
                      (struct.get $type28 0
                       (local.get $0)
                      )
                      (block (result (ref null $type28))
                       (local.set $0
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $7
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (local.get $1)
                          )
                          (i64.xor
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready203)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global203)
                        )
                       )
                       (if (result (ref null $type28))
                        (i64.eqz
                         (local.get $7)
                        )
                        (then
                         (struct.get $type28 1
                          (local.get $0)
                         )
                        )
                        (else
                         (struct.new $type28
                          (struct.get $type28 0
                           (local.get $0)
                          )
                          (block (result (ref null $type28))
                           (local.set $0
                            (struct.get $type28 1
                             (local.get $0)
                            )
                           )
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.tee $1
                                (i64.sub
                                 (local.get $7)
                                 (i64.const 1)
                                )
                               )
                               (local.get $7)
                              )
                              (i64.xor
                               (local.get $7)
                               (i64.const 1)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready203)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global203)
                            )
                           )
                           (if (result (ref null $type28))
                            (i64.eqz
                             (local.get $1)
                            )
                            (then
                             (struct.get $type28 1
                              (local.get $0)
                             )
                            )
                            (else
                             (struct.new $type28
                              (struct.get $type28 0
                               (local.get $0)
                              )
                              (block (result (ref null $type28))
                               (local.set $0
                                (struct.get $type28 1
                                 (local.get $0)
                                )
                               )
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.tee $7
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                   (local.get $1)
                                  )
                                  (i64.xor
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready203)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global203)
                                )
                               )
                               (if (result (ref null $type28))
                                (i64.eqz
                                 (local.get $7)
                                )
                                (then
                                 (struct.get $type28 1
                                  (local.get $0)
                                 )
                                )
                                (else
                                 (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $0)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $0
                                    (struct.get $type28 1
                                     (local.get $0)
                                    )
                                   )
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.tee $1
                                        (i64.sub
                                         (local.get $7)
                                         (i64.const 1)
                                        )
                                       )
                                       (local.get $7)
                                      )
                                      (i64.xor
                                       (local.get $7)
                                       (i64.const 1)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready203)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global203)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (i64.eqz
                                     (local.get $1)
                                    )
                                    (then
                                     (struct.get $type28 1
                                      (local.get $0)
                                     )
                                    )
                                    (else
                                     (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $0)
                                      )
                                      (call $function80
                                       (struct.get $type28 1
                                        (local.get $0)
                                       )
                                       (block (result i64)
                                        (if
                                         (i64.lt_s
                                          (i64.and
                                           (i64.xor
                                            (local.tee $7
                                             (i64.sub
                                              (local.get $1)
                                              (i64.const 1)
                                             )
                                            )
                                            (local.get $1)
                                           )
                                           (i64.xor
                                            (local.get $1)
                                            (i64.const 1)
                                           )
                                          )
                                          (i64.const 0)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready203)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global203)
                                         )
                                        )
                                        (local.get $7)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (global.get $ready190)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global190)
         )
        )
        (local.get $9)
       )
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call27) (param $0 (ref null $type28)) (result i64)
  (local $1 (ref $environment77))
  (local $2 (ref $type97))
  (struct.set $type97 1
   (local.tee $2
    (struct.new_default $type97)
   )
   (struct.new $type95
    (struct.new $environment77
     (local.get $2)
    )
   )
  )
  (struct.set $type97 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type97 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type95 0
    (struct.get $type97 1
     (local.get $2)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $0
     (struct.get $type28 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (struct.get $environment77 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type95 0
      (struct.get $type97 1
       (struct.get $environment77 0
        (local.get $1)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $0
       (struct.get $type28 1
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type97 0
         (struct.get $environment77 0
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type95 0
        (struct.get $type97 1
         (struct.get $environment77 0
          (local.get $1)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $0
         (struct.get $type28 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (struct.get $type97 0
           (struct.get $environment77 0
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type95 0
          (struct.get $type97 1
           (struct.get $environment77 0
            (local.get $1)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $0)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $0
           (struct.get $type28 1
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (struct.get $type97 0
             (struct.get $environment77 0
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type95 0
            (struct.get $type97 1
             (struct.get $environment77 0
              (local.get $1)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $0
             (struct.get $type28 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type97 0
               (struct.get $environment77 0
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (struct.get $type95 0
              (struct.get $type97 1
               (struct.get $environment77 0
                (local.get $1)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $0)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $0
               (struct.get $type28 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (struct.get $type97 0
                 (struct.get $environment77 0
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $1
               (struct.get $type95 0
                (struct.get $type97 1
                 (struct.get $environment77 0
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $0
                 (struct.get $type28 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type97 0
                   (struct.get $environment77 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type95 0
                  (struct.get $type97 1
                   (struct.get $environment77 0
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $0
                   (struct.get $type28 1
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type97 0
                     (struct.get $environment77 0
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type95 0
                    (struct.get $type97 1
                     (struct.get $environment77 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $0
                     (struct.get $type28 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type97 0
                       (struct.get $environment77 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function77
                     (struct.get $type95 0
                      (struct.get $type97 1
                       (struct.get $environment77 0
                        (local.get $1)
                       )
                      )
                     )
                     (local.get $0)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function77 (type $call95) (param $0 (ref $environment77)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (struct.get $environment77 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (struct.get $type95 0
      (struct.get $type97 1
       (struct.get $environment77 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function79 (type $call67) (param $0 (ref null $type28)) (param $1 i64) (result (ref $type29))
  (local $2 i64)
  (if (result (ref $type29))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type28 0
     (local.get $0)
    )
   )
   (else
    (return_call $function79
     (struct.get $type28 1
      (local.get $0)
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready200)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global200)
       )
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function80 (type $call71) (param $0 (ref null $type28)) (param $1 i64) (result (ref null $type28))
  (local $2 (ref $type29))
  (local $3 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type28 1
     (local.get $0)
    )
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function80
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $3
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (local.get $1)
          )
          (i64.xor
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready203)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global203)
        )
       )
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function81 (type $call85) (param $0 (ref null $type28)) (param $1 (ref null $type33)) (result (ref null $type33))
  (local $2 (ref $type29))
  (if (result (ref null $type33))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $1
     (call $function83
      (struct.get $type28 0
       (local.get $0)
      )
      (block (result (ref null $type33))
       (local.set $0
        (struct.get $type28 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready210)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global210)
        )
       )
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready206)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global206)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function83 (type $call84) (param $0 (ref $type29)) (param $1 (ref null $type33)) (result (ref null $type33))
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 (ref $type61))
  (local $6 (ref $type31))
  (local $7 (ref $type31))
  (local $8 (ref $type51))
  (local $scratch (ref null $type28))
  (if
   (ref.test (ref $type30)
    (local.get $0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (ref.cast (ref $type31)
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global218)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (local.set $3
   (call $function91
    (struct.new $environment91
     (local.get $6)
     (local.get $1)
    )
    (call $function87
     (local.get $1)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global194)
      )
     )
     (call $function75
      (struct.get $type33 0
       (local.get $1)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global244)
   )
  )
  (local.set $8
   (struct.new $type51
    (struct.new $environment97
     (local.get $1)
    )
   )
  )
  (if (result (ref null $type33))
   (call $function52
    (block (result (ref null $type28))
     (local.set $scratch
      (if (result (ref null $type28))
       (ref.is_null
        (local.get $3)
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (ref.test (ref $type30)
          (local.tee $0
           (struct.get $type28 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global230)
         )
        )
        (call $function99
         (struct.new $environment99
          (local.get $8)
          (local.get $3)
         )
         (call $function93
          (struct.get $environment97 0
           (struct.get $type51 0
            (local.get $8)
           )
          )
          (struct.get $type31 0
           (local.tee $7
            (ref.cast (ref $type31)
             (local.get $0)
            )
           )
          )
          (struct.get $type31 1
           (local.get $7)
          )
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global142)
      )
     )
     (local.get $scratch)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global279)
     )
    )
    (if
     (i32.eqz
      (ref.is_null
       (local.get $3)
      )
     )
     (then
      (local.set $1
       (call_ref $call61
        (struct.get $type61 1
         (local.tee $5
          (struct.new $type61
           (ref.func $function100)
           (struct.new $environment100
            (local.get $6)
           )
          )
         )
        )
        (local.get $1)
        (struct.get $type28 0
         (local.get $3)
        )
        (struct.get $type61 0
         (local.get $5)
        )
       )
      )
      (local.set $1
       (if (result (ref null $type33))
        (ref.is_null
         (local.tee $2
          (struct.get $type28 1
           (local.get $3)
          )
         )
        )
        (then
         (local.get $1)
        )
        (else
         (local.set $1
          (call_ref $call61
           (struct.get $type61 1
            (local.get $5)
           )
           (local.get $1)
           (struct.get $type28 0
            (local.get $2)
           )
           (struct.get $type61 0
            (local.get $5)
           )
          )
         )
         (if (result (ref null $type33))
          (ref.is_null
           (local.tee $2
            (struct.get $type28 1
             (local.get $2)
            )
           )
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $1
            (call_ref $call61
             (struct.get $type61 1
              (local.get $5)
             )
             (local.get $1)
             (struct.get $type28 0
              (local.get $2)
             )
             (struct.get $type61 0
              (local.get $5)
             )
            )
           )
           (if (result (ref null $type33))
            (ref.is_null
             (local.tee $2
              (struct.get $type28 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $1)
            )
            (else
             (local.set $1
              (call_ref $call61
               (struct.get $type61 1
                (local.get $5)
               )
               (local.get $1)
               (struct.get $type28 0
                (local.get $2)
               )
               (struct.get $type61 0
                (local.get $5)
               )
              )
             )
             (if (result (ref null $type33))
              (ref.is_null
               (local.tee $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $1
                (call_ref $call61
                 (struct.get $type61 1
                  (local.get $5)
                 )
                 (local.get $1)
                 (struct.get $type28 0
                  (local.get $2)
                 )
                 (struct.get $type61 0
                  (local.get $5)
                 )
                )
               )
               (if (result (ref null $type33))
                (ref.is_null
                 (local.tee $2
                  (struct.get $type28 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (local.get $1)
                )
                (else
                 (local.set $1
                  (call_ref $call61
                   (struct.get $type61 1
                    (local.get $5)
                   )
                   (local.get $1)
                   (struct.get $type28 0
                    (local.get $2)
                   )
                   (struct.get $type61 0
                    (local.get $5)
                   )
                  )
                 )
                 (if (result (ref null $type33))
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type28 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $1
                    (call_ref $call61
                     (struct.get $type61 1
                      (local.get $5)
                     )
                     (local.get $1)
                     (struct.get $type28 0
                      (local.get $2)
                     )
                     (struct.get $type61 0
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref null $type33))
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (local.get $1)
                    )
                    (else
                     (call $function111
                      (local.get $5)
                      (i32.const 0)
                      (i32.const 1)
                      (call_ref $call61
                       (struct.get $type61 1
                        (local.get $5)
                       )
                       (local.get $1)
                       (struct.get $type28 0
                        (local.get $2)
                       )
                       (struct.get $type61 0
                        (local.get $5)
                       )
                      )
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global286)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global266)
     )
    )
    (return_call $function107
     (local.get $1)
     (struct.get $type31 0
      (local.get $6)
     )
     (struct.get $type31 1
      (local.get $6)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function87 (type $call32) (param $0 (ref null $type33)) (result i64)
  (local $1 (ref $environment89))
  (local $2 (ref $type104))
  (struct.set $type104 1
   (local.tee $2
    (struct.new_default $type104)
   )
   (struct.new $type102
    (struct.new $environment89
     (local.get $2)
    )
   )
  )
  (struct.set $type104 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type104 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type102 0
    (struct.get $type104 1
     (local.get $2)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $0
     (struct.get $type33 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type104 0
       (struct.get $environment89 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type102 0
      (struct.get $type104 1
       (struct.get $environment89 0
        (local.get $1)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $0
       (struct.get $type33 1
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type104 0
         (struct.get $environment89 0
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type102 0
        (struct.get $type104 1
         (struct.get $environment89 0
          (local.get $1)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $0
         (struct.get $type33 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (struct.get $type104 0
           (struct.get $environment89 0
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type102 0
          (struct.get $type104 1
           (struct.get $environment89 0
            (local.get $1)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $0)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $0
           (struct.get $type33 1
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (struct.get $type104 0
             (struct.get $environment89 0
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type102 0
            (struct.get $type104 1
             (struct.get $environment89 0
              (local.get $1)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $0
             (struct.get $type33 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type104 0
               (struct.get $environment89 0
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (struct.get $type102 0
              (struct.get $type104 1
               (struct.get $environment89 0
                (local.get $1)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $0)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $0
               (struct.get $type33 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (struct.get $type104 0
                 (struct.get $environment89 0
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $1
               (struct.get $type102 0
                (struct.get $type104 1
                 (struct.get $environment89 0
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $0
                 (struct.get $type33 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type104 0
                   (struct.get $environment89 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type102 0
                  (struct.get $type104 1
                   (struct.get $environment89 0
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $0
                   (struct.get $type33 1
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type104 0
                     (struct.get $environment89 0
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type102 0
                    (struct.get $type104 1
                     (struct.get $environment89 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $0
                     (struct.get $type33 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type104 0
                       (struct.get $environment89 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $1
                     (struct.get $type102 0
                      (struct.get $type104 1
                       (struct.get $environment89 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $0)
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (local.set $0
                       (struct.get $type33 1
                        (local.get $0)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type104 0
                         (struct.get $environment89 0
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function89
                       (struct.get $type102 0
                        (struct.get $type104 1
                         (struct.get $environment89 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $0)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function89 (type $call102) (param $0 (ref $environment89)) (param $1 (ref null $type33)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type33 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type104 0
       (struct.get $environment89 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (struct.get $type102 0
      (struct.get $type104 1
       (struct.get $environment89 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function91 (type $23) (param $0 (ref $environment91)) (param $1 i64) (param $2 i64) (result (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref null $type28))
  (local $7 (ref null $type28))
  (local $8 (ref $type29))
  (local $9 (ref null $type33))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (ref.test (ref $type30)
    (local.tee $8
     (struct.get $environment91 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $10
   (struct.get $type31 0
    (ref.cast (ref $type31)
     (local.get $8)
    )
   )
  )
  (if
   (ref.test (ref $type30)
    (local.tee $8
     (struct.get $environment91 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $9
   (struct.get $environment91 1
    (local.get $0)
   )
  )
  (local.set $11
   (struct.get $type31 1
    (ref.cast (ref $type31)
     (local.get $8)
    )
   )
  )
  (local.set $5
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (local.get $10)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $12
           (i64.sub
            (local.get $10)
            (i64.const 1)
           )
          )
          (local.get $10)
         )
         (i64.xor
          (local.get $10)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global230)
       )
      )
      (local.set $8
       (call $function93
        (local.get $9)
        (local.get $12)
        (local.get $11)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global107)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $8)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $8)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $12
          (i64.sub
           (local.get $10)
           (i64.const 1)
          )
         )
         (local.get $10)
        )
        (i64.xor
         (local.get $10)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global173)
      )
     )
     (struct.new $type28
      (struct.new $type31
       (local.get $12)
       (local.get $11)
      )
      (ref.null none)
     )
    )
    (else
     (ref.null none)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $12
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (local.get $1)
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (if (result (ref null $type28))
    (if (result i32)
     (i64.lt_s
      (local.get $10)
      (local.get $12)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.get $10)
            (i64.const 1)
           )
          )
          (local.get $10)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global230)
       )
      )
      (local.set $8
       (call $function93
        (local.get $9)
        (local.get $1)
        (local.get $11)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global107)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $8)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $8)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $1
          (i64.add
           (local.get $10)
           (i64.const 1)
          )
         )
         (local.get $10)
        )
        (i64.xor
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global173)
      )
     )
     (struct.new $type28
      (struct.new $type31
       (local.get $1)
       (local.get $11)
      )
      (ref.null none)
     )
    )
    (else
     (ref.null none)
    )
   )
  )
  (local.set $7
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $11)
            (i64.const 1)
           )
          )
          (local.get $11)
         )
         (i64.xor
          (local.get $11)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global230)
       )
      )
      (local.set $8
       (call $function93
        (local.get $9)
        (local.get $10)
        (local.get $1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global107)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $8)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $8)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $1
          (i64.sub
           (local.get $11)
           (i64.const 1)
          )
         )
         (local.get $11)
        )
        (i64.xor
         (local.get $11)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global173)
      )
     )
     (struct.new $type28
      (struct.new $type31
       (local.get $10)
       (local.get $1)
      )
      (ref.null none)
     )
    )
    (else
     (ref.null none)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $1
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (if (result (ref null $type28))
    (if (result i32)
     (i64.gt_s
      (local.get $1)
      (local.get $11)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.get $11)
            (i64.const 1)
           )
          )
          (local.get $11)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global230)
       )
      )
      (local.set $8
       (call $function93
        (local.get $9)
        (local.get $10)
        (local.get $1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global107)
       )
      )
      (if (result i32)
       (ref.test (ref $type30)
        (local.get $8)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.cast (ref $type31)
          (local.get $8)
         )
        )
        (i32.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $11)
         (local.tee $1
          (i64.add
           (local.get $11)
           (i64.const 1)
          )
         )
        )
        (i64.xor
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global173)
      )
     )
     (struct.new $type28
      (struct.new $type31
       (local.get $10)
       (local.get $1)
      )
      (ref.null none)
     )
    )
    (else
     (ref.null none)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global237)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $7)
    )
   )
   (then
    (local.set $4
     (struct.new $type28
      (struct.get $type28 0
       (local.get $7)
      )
      (block (result (ref null $type28))
       (local.set $3
        (struct.get $type28 1
         (local.get $7)
        )
       )
       (if
        (i32.eqz
         (global.get $ready177)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $3)
        )
        (then
         (local.get $4)
        )
        (else
         (struct.new $type28
          (struct.get $type28 0
           (local.get $3)
          )
          (block (result (ref null $type28))
           (local.set $3
            (struct.get $type28 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready177)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global177)
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $4)
            )
            (else
             (struct.new $type28
              (struct.get $type28 0
               (local.get $3)
              )
              (block (result (ref null $type28))
               (local.set $3
                (struct.get $type28 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready177)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global177)
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $4)
                )
                (else
                 (struct.new $type28
                  (struct.get $type28 0
                   (local.get $3)
                  )
                  (block (result (ref null $type28))
                   (local.set $3
                    (struct.get $type28 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready177)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global177)
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (struct.new $type28
                      (struct.get $type28 0
                       (local.get $3)
                      )
                      (block (result (ref null $type28))
                       (local.set $3
                        (struct.get $type28 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready177)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global177)
                        )
                       )
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $4)
                        )
                        (else
                         (struct.new $type28
                          (struct.get $type28 0
                           (local.get $3)
                          )
                          (block (result (ref null $type28))
                           (local.set $3
                            (struct.get $type28 1
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready177)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global177)
                            )
                           )
                           (if (result (ref null $type28))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $4)
                            )
                            (else
                             (struct.new $type28
                              (struct.get $type28 0
                               (local.get $3)
                              )
                              (block (result (ref null $type28))
                               (local.set $3
                                (struct.get $type28 1
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready177)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global177)
                                )
                               )
                               (if (result (ref null $type28))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $4)
                                )
                                (else
                                 (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $3)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $3
                                    (struct.get $type28 1
                                     (local.get $3)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready177)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global177)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (ref.is_null
                                     (local.get $3)
                                    )
                                    (then
                                     (local.get $4)
                                    )
                                    (else
                                     (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $3)
                                      )
                                      (call $function68
                                       (struct.get $type28 1
                                        (local.get $3)
                                       )
                                       (block (result (ref null $type28))
                                        (if
                                         (i32.eqz
                                          (global.get $ready177)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global177)
                                         )
                                        )
                                        (local.get $4)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (if
   (i32.eqz
    (ref.is_null
     (local.get $6)
    )
   )
   (then
    (local.set $4
     (struct.new $type28
      (struct.get $type28 0
       (local.get $6)
      )
      (block (result (ref null $type28))
       (local.set $3
        (struct.get $type28 1
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready177)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (if (result (ref null $type28))
        (ref.is_null
         (local.get $3)
        )
        (then
         (local.get $4)
        )
        (else
         (struct.new $type28
          (struct.get $type28 0
           (local.get $3)
          )
          (block (result (ref null $type28))
           (local.set $3
            (struct.get $type28 1
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (global.get $ready177)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global177)
            )
           )
           (if (result (ref null $type28))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $4)
            )
            (else
             (struct.new $type28
              (struct.get $type28 0
               (local.get $3)
              )
              (block (result (ref null $type28))
               (local.set $3
                (struct.get $type28 1
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready177)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global177)
                )
               )
               (if (result (ref null $type28))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $4)
                )
                (else
                 (struct.new $type28
                  (struct.get $type28 0
                   (local.get $3)
                  )
                  (block (result (ref null $type28))
                   (local.set $3
                    (struct.get $type28 1
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready177)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global177)
                    )
                   )
                   (if (result (ref null $type28))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (struct.new $type28
                      (struct.get $type28 0
                       (local.get $3)
                      )
                      (block (result (ref null $type28))
                       (local.set $3
                        (struct.get $type28 1
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready177)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global177)
                        )
                       )
                       (if (result (ref null $type28))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $4)
                        )
                        (else
                         (struct.new $type28
                          (struct.get $type28 0
                           (local.get $3)
                          )
                          (block (result (ref null $type28))
                           (local.set $3
                            (struct.get $type28 1
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready177)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global177)
                            )
                           )
                           (if (result (ref null $type28))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $4)
                            )
                            (else
                             (struct.new $type28
                              (struct.get $type28 0
                               (local.get $3)
                              )
                              (block (result (ref null $type28))
                               (local.set $3
                                (struct.get $type28 1
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready177)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global177)
                                )
                               )
                               (if (result (ref null $type28))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $4)
                                )
                                (else
                                 (struct.new $type28
                                  (struct.get $type28 0
                                   (local.get $3)
                                  )
                                  (block (result (ref null $type28))
                                   (local.set $3
                                    (struct.get $type28 1
                                     (local.get $3)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready177)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global177)
                                    )
                                   )
                                   (if (result (ref null $type28))
                                    (ref.is_null
                                     (local.get $3)
                                    )
                                    (then
                                     (local.get $4)
                                    )
                                    (else
                                     (struct.new $type28
                                      (struct.get $type28 0
                                       (local.get $3)
                                      )
                                      (call $function68
                                       (struct.get $type28 1
                                        (local.get $3)
                                       )
                                       (block (result (ref null $type28))
                                        (if
                                         (i32.eqz
                                          (global.get $ready177)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global177)
                                         )
                                        )
                                        (local.get $4)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global177)
   )
  )
  (if (result (ref null $type28))
   (ref.is_null
    (local.get $5)
   )
   (then
    (local.get $4)
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $5)
     )
     (block (result (ref null $type28))
      (local.set $3
       (struct.get $type28 1
        (local.get $5)
       )
      )
      (if
       (i32.eqz
        (global.get $ready177)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global177)
       )
      )
      (if (result (ref null $type28))
       (ref.is_null
        (local.get $3)
       )
       (then
        (local.get $4)
       )
       (else
        (struct.new $type28
         (struct.get $type28 0
          (local.get $3)
         )
         (block (result (ref null $type28))
          (local.set $3
           (struct.get $type28 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (global.get $ready177)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global177)
           )
          )
          (if (result (ref null $type28))
           (ref.is_null
            (local.get $3)
           )
           (then
            (local.get $4)
           )
           (else
            (struct.new $type28
             (struct.get $type28 0
              (local.get $3)
             )
             (block (result (ref null $type28))
              (local.set $3
               (struct.get $type28 1
                (local.get $3)
               )
              )
              (if
               (i32.eqz
                (global.get $ready177)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global177)
               )
              )
              (if (result (ref null $type28))
               (ref.is_null
                (local.get $3)
               )
               (then
                (local.get $4)
               )
               (else
                (struct.new $type28
                 (struct.get $type28 0
                  (local.get $3)
                 )
                 (block (result (ref null $type28))
                  (local.set $3
                   (struct.get $type28 1
                    (local.get $3)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready177)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global177)
                   )
                  )
                  (if (result (ref null $type28))
                   (ref.is_null
                    (local.get $3)
                   )
                   (then
                    (local.get $4)
                   )
                   (else
                    (struct.new $type28
                     (struct.get $type28 0
                      (local.get $3)
                     )
                     (block (result (ref null $type28))
                      (local.set $3
                       (struct.get $type28 1
                        (local.get $3)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready177)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global177)
                       )
                      )
                      (if (result (ref null $type28))
                       (ref.is_null
                        (local.get $3)
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (struct.new $type28
                         (struct.get $type28 0
                          (local.get $3)
                         )
                         (block (result (ref null $type28))
                          (local.set $3
                           (struct.get $type28 1
                            (local.get $3)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready177)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global177)
                           )
                          )
                          (if (result (ref null $type28))
                           (ref.is_null
                            (local.get $3)
                           )
                           (then
                            (local.get $4)
                           )
                           (else
                            (struct.new $type28
                             (struct.get $type28 0
                              (local.get $3)
                             )
                             (block (result (ref null $type28))
                              (local.set $3
                               (struct.get $type28 1
                                (local.get $3)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready177)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global177)
                               )
                              )
                              (if (result (ref null $type28))
                               (ref.is_null
                                (local.get $3)
                               )
                               (then
                                (local.get $4)
                               )
                               (else
                                (struct.new $type28
                                 (struct.get $type28 0
                                  (local.get $3)
                                 )
                                 (block (result (ref null $type28))
                                  (local.set $3
                                   (struct.get $type28 1
                                    (local.get $3)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready177)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global177)
                                   )
                                  )
                                  (if (result (ref null $type28))
                                   (ref.is_null
                                    (local.get $3)
                                   )
                                   (then
                                    (local.get $4)
                                   )
                                   (else
                                    (struct.new $type28
                                     (struct.get $type28 0
                                      (local.get $3)
                                     )
                                     (call $function68
                                      (struct.get $type28 1
                                       (local.get $3)
                                      )
                                      (block (result (ref null $type28))
                                       (if
                                        (i32.eqz
                                         (global.get $ready177)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global177)
                                        )
                                       )
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function93 (type $call75) (param $0 (ref null $type33)) (param $1 i64) (param $2 i64) (result (ref $type29))
  (local $3 (ref null $type28))
  (local $4 i64)
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global234)
   )
  )
  (local.set $3
   (if (result (ref null $type28))
    (i64.eqz
     (local.get $1)
    )
    (then
     (struct.get $type33 0
      (local.get $0)
     )
    )
    (else
     (local.set $0
      (struct.get $type33 1
       (local.get $0)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $4
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (local.get $1)
        )
        (i64.xor
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (global.get $ready234)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global234)
      )
     )
     (if (result (ref null $type28))
      (i64.eqz
       (local.get $4)
      )
      (then
       (struct.get $type33 0
        (local.get $0)
       )
      )
      (else
       (local.set $0
        (struct.get $type33 1
         (local.get $0)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $1
            (i64.sub
             (local.get $4)
             (i64.const 1)
            )
           )
           (local.get $4)
          )
          (i64.xor
           (local.get $4)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready234)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global234)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $1)
        )
        (then
         (struct.get $type33 0
          (local.get $0)
         )
        )
        (else
         (local.set $0
          (struct.get $type33 1
           (local.get $0)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $4
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (local.get $1)
            )
            (i64.xor
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (global.get $ready234)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global234)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $4)
          )
          (then
           (struct.get $type33 0
            (local.get $0)
           )
          )
          (else
           (local.set $0
            (struct.get $type33 1
             (local.get $0)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $1
                (i64.sub
                 (local.get $4)
                 (i64.const 1)
                )
               )
               (local.get $4)
              )
              (i64.xor
               (local.get $4)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (global.get $ready234)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global234)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.get $1)
            )
            (then
             (struct.get $type33 0
              (local.get $0)
             )
            )
            (else
             (local.set $0
              (struct.get $type33 1
               (local.get $0)
              )
             )
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $4
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (local.get $1)
                )
                (i64.xor
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (global.get $ready234)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global234)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.get $4)
              )
              (then
               (struct.get $type33 0
                (local.get $0)
               )
              )
              (else
               (local.set $0
                (struct.get $type33 1
                 (local.get $0)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $1
                    (i64.sub
                     (local.get $4)
                     (i64.const 1)
                    )
                   )
                   (local.get $4)
                  )
                  (i64.xor
                   (local.get $4)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready234)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global234)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $1)
                )
                (then
                 (struct.get $type33 0
                  (local.get $0)
                 )
                )
                (else
                 (local.set $0
                  (struct.get $type33 1
                   (local.get $0)
                  )
                 )
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $4
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (local.get $1)
                    )
                    (i64.xor
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready234)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global234)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.get $4)
                  )
                  (then
                   (struct.get $type33 0
                    (local.get $0)
                   )
                  )
                  (else
                   (local.set $0
                    (struct.get $type33 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $5
                        (i64.sub
                         (local.get $4)
                         (i64.const 1)
                        )
                       )
                       (local.get $4)
                      )
                      (i64.xor
                       (local.get $4)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready234)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global234)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.get $5)
                    )
                    (then
                     (struct.get $type33 0
                      (local.get $0)
                     )
                    )
                    (else
                     (local.set $0
                      (struct.get $type33 1
                       (local.get $0)
                      )
                     )
                     (if
                      (i64.lt_s
                       (i64.and
                        (i64.xor
                         (local.tee $1
                          (i64.sub
                           (local.get $5)
                           (i64.const 1)
                          )
                         )
                         (local.get $5)
                        )
                        (i64.xor
                         (local.get $5)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready234)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global234)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $1)
                      )
                      (then
                       (struct.get $type33 0
                        (local.get $0)
                       )
                      )
                      (else
                       (call $function94
                        (struct.get $type33 1
                         (local.get $0)
                        )
                        (block (result i64)
                         (if
                          (i64.lt_s
                           (i64.and
                            (i64.xor
                             (local.tee $4
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                             (local.get $1)
                            )
                            (i64.xor
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (i64.const 0)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready234)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global234)
                          )
                         )
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global200)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (local.get $2)
   )
   (then
    (struct.get $type28 0
     (local.get $3)
    )
   )
   (else
    (local.set $3
     (struct.get $type28 1
      (local.get $3)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready200)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global200)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (local.get $1)
     )
     (then
      (struct.get $type28 0
       (local.get $3)
      )
     )
     (else
      (local.set $3
       (struct.get $type28 1
        (local.get $3)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready200)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global200)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (local.get $2)
       )
       (then
        (struct.get $type28 0
         (local.get $3)
        )
       )
       (else
        (local.set $3
         (struct.get $type28 1
          (local.get $3)
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $1
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready200)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global200)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (local.get $1)
         )
         (then
          (struct.get $type28 0
           (local.get $3)
          )
         )
         (else
          (local.set $3
           (struct.get $type28 1
            (local.get $3)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready200)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global200)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.get $2)
           )
           (then
            (struct.get $type28 0
             (local.get $3)
            )
           )
           (else
            (local.set $3
             (struct.get $type28 1
              (local.get $3)
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $1
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
                (local.get $2)
               )
               (i64.xor
                (local.get $2)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready200)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global200)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.get $1)
             )
             (then
              (struct.get $type28 0
               (local.get $3)
              )
             )
             (else
              (local.set $3
               (struct.get $type28 1
                (local.get $3)
               )
              )
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $2
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                  (local.get $1)
                 )
                 (i64.xor
                  (local.get $1)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready200)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global200)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.get $2)
               )
               (then
                (struct.get $type28 0
                 (local.get $3)
                )
               )
               (else
                (local.set $3
                 (struct.get $type28 1
                  (local.get $3)
                 )
                )
                (if
                 (i64.lt_s
                  (i64.and
                   (i64.xor
                    (local.tee $1
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                    (local.get $2)
                   )
                   (i64.xor
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready200)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global200)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.get $1)
                 )
                 (then
                  (struct.get $type28 0
                   (local.get $3)
                  )
                 )
                 (else
                  (local.set $3
                   (struct.get $type28 1
                    (local.get $3)
                   )
                  )
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $2
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                      (local.get $1)
                     )
                     (i64.xor
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready200)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global200)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.get $2)
                   )
                   (then
                    (struct.get $type28 0
                     (local.get $3)
                    )
                   )
                   (else
                    (local.set $3
                     (struct.get $type28 1
                      (local.get $3)
                     )
                    )
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $1
                         (i64.sub
                          (local.get $2)
                          (i64.const 1)
                         )
                        )
                        (local.get $2)
                       )
                       (i64.xor
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready200)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global200)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (local.get $1)
                     )
                     (then
                      (struct.get $type28 0
                       (local.get $3)
                      )
                     )
                     (else
                      (return_call $function79
                       (struct.get $type28 1
                        (local.get $3)
                       )
                       (block (result i64)
                        (if
                         (i64.lt_s
                          (i64.and
                           (i64.xor
                            (local.tee $2
                             (i64.sub
                              (local.get $1)
                              (i64.const 1)
                             )
                            )
                            (local.get $1)
                           )
                           (i64.xor
                            (local.get $1)
                            (i64.const 1)
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready200)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global200)
                         )
                        )
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function94 (type $call68) (param $0 (ref null $type33)) (param $1 i64) (result (ref null $type28))
  (local $2 i64)
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type33 0
     (local.get $0)
    )
   )
   (else
    (return_call $function94
     (struct.get $type33 1
      (local.get $0)
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready234)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global234)
       )
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function99 (type $20) (param $0 (ref $environment99)) (param $1 (ref $type29)) (result (ref $type28))
  (local $2 (ref null $type28))
  (local $3 (ref $type51))
  (local $4 (ref $type31))
  (local.set $2
   (struct.get $type28 1
    (struct.get $environment99 1
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready244)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global244)
   )
  )
  (struct.new $type28
   (local.get $1)
   (if (result (ref null $type28))
    (ref.is_null
     (local.get $2)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (ref.test (ref $type30)
       (local.tee $1
        (struct.get $type28 0
         (local.get $2)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global230)
      )
     )
     (call $function99
      (struct.new $environment99
       (local.tee $3
        (struct.get $environment99 0
         (local.get $0)
        )
       )
       (local.get $2)
      )
      (call $function93
       (struct.get $environment97 0
        (struct.get $type51 0
         (local.get $3)
        )
       )
       (struct.get $type31 0
        (local.tee $4
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
       )
       (struct.get $type31 1
        (local.get $4)
       )
      )
     )
    )
   )
  )
 )
 (func $function100 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 (ref $type29)) (result (ref null $type33))
  (local $3 (ref $type31))
  (local $4 (ref $type31))
  (local.set $4
   (struct.get $environment100 0
    (ref.cast (ref $environment100)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready250)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global250)
   )
  )
  (if
   (ref.test (ref $type30)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global230)
   )
  )
  (local.set $2
   (call $function93
    (local.get $1)
    (struct.get $type31 0
     (local.tee $3
      (ref.cast (ref $type31)
       (local.get $2)
      )
     )
    )
    (struct.get $type31 1
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready256)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global256)
   )
  )
  (return_call $function104
   (struct.new $environment104
    (local.get $1)
    (local.get $3)
    (local.get $4)
    (local.get $2)
   )
   (struct.get $type31 0
    (local.get $3)
   )
   (struct.get $type31 1
    (local.get $3)
   )
  )
 )
 (func $function104 (type $18) (param $0 (ref $environment104)) (param $1 i64) (param $2 i64) (result (ref null $type33))
  (local $3 (ref null $type33))
  (local $4 (ref null $type28))
  (local $5 (ref null $type28))
  (local $6 (ref $type61))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type33))
  (drop
   (ref.as_non_null
    (global.get $global230)
   )
  )
  (if (result (ref null $type33))
   (call $function46
    (call $function93
     (local.tee $3
      (struct.get $environment104 0
       (local.get $0)
      )
     )
     (local.get $1)
     (local.get $2)
    )
    (block (result (ref $type29))
     (drop
      (ref.as_non_null
       (global.get $global126)
      )
     )
     (local.tee $7
      (struct.get $environment104 3
       (local.get $0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global266)
     )
    )
    (local.set $9
     (call $function107
      (local.get $3)
      (local.get $1)
      (local.get $2)
      (local.tee $8
       (struct.get $environment104 2
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready215)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global215)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global218)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global220)
     )
    )
    (local.set $5
     (call $function91
      (struct.new $environment91
       (struct.get $environment104 1
        (local.get $0)
       )
       (local.get $3)
      )
      (call $function87
       (local.get $3)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global194)
        )
       )
       (call $function75
        (struct.get $type33 0
         (local.get $3)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global279)
     )
    )
    (if (result (ref null $type33))
     (ref.is_null
      (local.get $5)
     )
     (then
      (local.get $9)
     )
     (else
      (local.set $3
       (call_ref $call61
        (struct.get $type61 1
         (local.tee $6
          (struct.new $type61
           (ref.func $function106)
           (struct.new $environment106
            (local.get $8)
            (local.get $7)
           )
          )
         )
        )
        (local.get $9)
        (struct.get $type28 0
         (local.get $5)
        )
        (struct.get $type61 0
         (local.get $6)
        )
       )
      )
      (if (result (ref null $type33))
       (ref.is_null
        (local.tee $4
         (struct.get $type28 1
          (local.get $5)
         )
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $3
         (call_ref $call61
          (struct.get $type61 1
           (local.get $6)
          )
          (local.get $3)
          (struct.get $type28 0
           (local.get $4)
          )
          (struct.get $type61 0
           (local.get $6)
          )
         )
        )
        (if (result (ref null $type33))
         (ref.is_null
          (local.tee $4
           (struct.get $type28 1
            (local.get $4)
           )
          )
         )
         (then
          (local.get $3)
         )
         (else
          (local.set $3
           (call_ref $call61
            (struct.get $type61 1
             (local.get $6)
            )
            (local.get $3)
            (struct.get $type28 0
             (local.get $4)
            )
            (struct.get $type61 0
             (local.get $6)
            )
           )
          )
          (if (result (ref null $type33))
           (ref.is_null
            (local.tee $4
             (struct.get $type28 1
              (local.get $4)
             )
            )
           )
           (then
            (local.get $3)
           )
           (else
            (local.set $3
             (call_ref $call61
              (struct.get $type61 1
               (local.get $6)
              )
              (local.get $3)
              (struct.get $type28 0
               (local.get $4)
              )
              (struct.get $type61 0
               (local.get $6)
              )
             )
            )
            (if (result (ref null $type33))
             (ref.is_null
              (local.tee $4
               (struct.get $type28 1
                (local.get $4)
               )
              )
             )
             (then
              (local.get $3)
             )
             (else
              (local.set $3
               (call_ref $call61
                (struct.get $type61 1
                 (local.get $6)
                )
                (local.get $3)
                (struct.get $type28 0
                 (local.get $4)
                )
                (struct.get $type61 0
                 (local.get $6)
                )
               )
              )
              (if (result (ref null $type33))
               (ref.is_null
                (local.tee $4
                 (struct.get $type28 1
                  (local.get $4)
                 )
                )
               )
               (then
                (local.get $3)
               )
               (else
                (local.set $3
                 (call_ref $call61
                  (struct.get $type61 1
                   (local.get $6)
                  )
                  (local.get $3)
                  (struct.get $type28 0
                   (local.get $4)
                  )
                  (struct.get $type61 0
                   (local.get $6)
                  )
                 )
                )
                (if (result (ref null $type33))
                 (ref.is_null
                  (local.tee $4
                   (struct.get $type28 1
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (local.set $3
                   (call_ref $call61
                    (struct.get $type61 1
                     (local.get $6)
                    )
                    (local.get $3)
                    (struct.get $type28 0
                     (local.get $4)
                    )
                    (struct.get $type61 0
                     (local.get $6)
                    )
                   )
                  )
                  (if (result (ref null $type33))
                   (ref.is_null
                    (local.tee $4
                     (struct.get $type28 1
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (return_call $function111
                     (local.get $6)
                     (i32.const 0)
                     (i32.const 1)
                     (call_ref $call61
                      (struct.get $type61 1
                       (local.get $6)
                      )
                      (local.get $3)
                      (struct.get $type28 0
                       (local.get $4)
                      )
                      (struct.get $type61 0
                       (local.get $6)
                      )
                     )
                     (struct.get $type28 1
                      (local.get $4)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (local.get $3)
   )
  )
 )
 (func $function106 (type $call61) (param $0 (ref struct)) (param $1 (ref null $type33)) (param $2 (ref $type29)) (result (ref null $type33))
  (local $3 (ref $type31))
  (local $4 (ref $environment106))
  (local $5 (ref $type29))
  (local $6 i64)
  (local.set $5
   (struct.get $environment106 0
    (local.tee $4
     (ref.cast (ref $environment106)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready256)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global256)
   )
  )
  (if
   (ref.test (ref $type30)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type31 0
    (local.tee $3
     (ref.cast (ref $type31)
      (local.get $2)
     )
    )
   )
  )
  (return_call $function104
   (struct.new $environment104
    (local.get $1)
    (local.get $3)
    (local.get $5)
    (struct.get $environment106 1
     (local.get $4)
    )
   )
   (local.get $6)
   (struct.get $type31 1
    (local.get $3)
   )
  )
 )
 (func $function107 (type $16) (param $0 (ref null $type33)) (param $1 i64) (param $2 i64) (param $3 (ref $type29)) (result (ref $type33))
  (local $4 (ref null $type33))
  (local $5 (ref null $type28))
  (local $6 (ref $type28))
  (local $7 i64)
  (local $8 i64)
  (drop
   (ref.as_non_null
    (global.get $global234)
   )
  )
  (local.set $6
   (call $function108
    (if (result (ref null $type28))
     (i64.eqz
      (local.get $1)
     )
     (then
      (struct.get $type33 0
       (local.get $0)
      )
     )
     (else
      (local.set $4
       (struct.get $type33 1
        (local.get $0)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $7
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready234)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global234)
       )
      )
      (if (result (ref null $type28))
       (i64.eqz
        (local.get $7)
       )
       (then
        (struct.get $type33 0
         (local.get $4)
        )
       )
       (else
        (local.set $4
         (struct.get $type33 1
          (local.get $4)
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $8
             (i64.sub
              (local.get $7)
              (i64.const 1)
             )
            )
            (local.get $7)
           )
           (i64.xor
            (local.get $7)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready234)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global234)
         )
        )
        (if (result (ref null $type28))
         (i64.eqz
          (local.get $8)
         )
         (then
          (struct.get $type33 0
           (local.get $4)
          )
         )
         (else
          (local.set $4
           (struct.get $type33 1
            (local.get $4)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $7
               (i64.sub
                (local.get $8)
                (i64.const 1)
               )
              )
              (local.get $8)
             )
             (i64.xor
              (local.get $8)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready234)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global234)
           )
          )
          (if (result (ref null $type28))
           (i64.eqz
            (local.get $7)
           )
           (then
            (struct.get $type33 0
             (local.get $4)
            )
           )
           (else
            (local.set $4
             (struct.get $type33 1
              (local.get $4)
             )
            )
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.tee $8
                 (i64.sub
                  (local.get $7)
                  (i64.const 1)
                 )
                )
                (local.get $7)
               )
               (i64.xor
                (local.get $7)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.eqz
              (global.get $ready234)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global234)
             )
            )
            (if (result (ref null $type28))
             (i64.eqz
              (local.get $8)
             )
             (then
              (struct.get $type33 0
               (local.get $4)
              )
             )
             (else
              (local.set $4
               (struct.get $type33 1
                (local.get $4)
               )
              )
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $7
                   (i64.sub
                    (local.get $8)
                    (i64.const 1)
                   )
                  )
                  (local.get $8)
                 )
                 (i64.xor
                  (local.get $8)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.eqz
                (global.get $ready234)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global234)
               )
              )
              (if (result (ref null $type28))
               (i64.eqz
                (local.get $7)
               )
               (then
                (struct.get $type33 0
                 (local.get $4)
                )
               )
               (else
                (local.set $4
                 (struct.get $type33 1
                  (local.get $4)
                 )
                )
                (if
                 (i64.lt_s
                  (i64.and
                   (i64.xor
                    (local.tee $8
                     (i64.sub
                      (local.get $7)
                      (i64.const 1)
                     )
                    )
                    (local.get $7)
                   )
                   (i64.xor
                    (local.get $7)
                    (i64.const 1)
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready234)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global234)
                 )
                )
                (if (result (ref null $type28))
                 (i64.eqz
                  (local.get $8)
                 )
                 (then
                  (struct.get $type33 0
                   (local.get $4)
                  )
                 )
                 (else
                  (local.set $4
                   (struct.get $type33 1
                    (local.get $4)
                   )
                  )
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $7
                       (i64.sub
                        (local.get $8)
                        (i64.const 1)
                       )
                      )
                      (local.get $8)
                     )
                     (i64.xor
                      (local.get $8)
                      (i64.const 1)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready234)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global234)
                   )
                  )
                  (if (result (ref null $type28))
                   (i64.eqz
                    (local.get $7)
                   )
                   (then
                    (struct.get $type33 0
                     (local.get $4)
                    )
                   )
                   (else
                    (local.set $4
                     (struct.get $type33 1
                      (local.get $4)
                     )
                    )
                    (if
                     (i64.lt_s
                      (i64.and
                       (i64.xor
                        (local.tee $8
                         (i64.sub
                          (local.get $7)
                          (i64.const 1)
                         )
                        )
                        (local.get $7)
                       )
                       (i64.xor
                        (local.get $7)
                        (i64.const 1)
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready234)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global234)
                     )
                    )
                    (if (result (ref null $type28))
                     (i64.eqz
                      (local.get $8)
                     )
                     (then
                      (struct.get $type33 0
                       (local.get $4)
                      )
                     )
                     (else
                      (local.set $4
                       (struct.get $type33 1
                        (local.get $4)
                       )
                      )
                      (if
                       (i64.lt_s
                        (i64.and
                         (i64.xor
                          (local.tee $7
                           (i64.sub
                            (local.get $8)
                            (i64.const 1)
                           )
                          )
                          (local.get $8)
                         )
                         (i64.xor
                          (local.get $8)
                          (i64.const 1)
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready234)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global234)
                       )
                      )
                      (if (result (ref null $type28))
                       (i64.eqz
                        (local.get $7)
                       )
                       (then
                        (struct.get $type33 0
                         (local.get $4)
                        )
                       )
                       (else
                        (call $function94
                         (struct.get $type33 1
                          (local.get $4)
                         )
                         (block (result i64)
                          (if
                           (i64.lt_s
                            (i64.and
                             (i64.xor
                              (local.tee $8
                               (i64.sub
                                (local.get $7)
                                (i64.const 1)
                               )
                              )
                              (local.get $7)
                             )
                             (i64.xor
                              (local.get $7)
                              (i64.const 1)
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready234)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global234)
                           )
                          )
                          (local.get $8)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global271)
      )
     )
     (local.get $2)
    )
    (local.get $3)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global275)
   )
  )
  (return_call $function109
   (local.get $0)
   (local.get $1)
   (local.get $6)
  )
 )
 (func $function108 (type $call69) (param $0 (ref null $type28)) (param $1 i64) (param $2 (ref $type29)) (result (ref $type28))
  (local $3 (ref $type29))
  (local $4 i64)
  (if (result (ref $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.new $type28
     (local.get $2)
     (struct.get $type28 1
      (local.get $0)
     )
    )
   )
   (else
    (struct.new $type28
     (struct.get $type28 0
      (local.get $0)
     )
     (call $function108
      (struct.get $type28 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $4
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (local.get $1)
          )
          (i64.xor
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready271)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global271)
        )
       )
       (local.get $4)
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function109 (type $call70) (param $0 (ref null $type33)) (param $1 i64) (param $2 (ref null $type28)) (result (ref $type33))
  (local $3 (ref null $type28))
  (local $4 i64)
  (if (result (ref $type33))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.new $type33
     (local.get $2)
     (struct.get $type33 1
      (local.get $0)
     )
    )
   )
   (else
    (struct.new $type33
     (struct.get $type33 0
      (local.get $0)
     )
     (call $function109
      (struct.get $type33 1
       (local.get $0)
      )
      (block (result i64)
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $4
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (local.get $1)
          )
          (i64.xor
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready275)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global275)
        )
       )
       (local.get $4)
      )
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function111 (type $13) (param $0 (ref $type61)) (param $1 i32) (param $2 i32) (param $3 (ref null $type33)) (param $4 (ref null $type28)) (result (ref null $type33))
  (if (result (ref null $type33))
   (ref.is_null
    (local.get $4)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $3
     (call_ref $call61
      (struct.get $type61 1
       (local.get $0)
      )
      (local.get $3)
      (struct.get $type28 0
       (local.get $4)
      )
      (struct.get $type61 0
       (local.get $0)
      )
     )
    )
    (local.set $4
     (struct.get $type28 1
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function116 (type $call54) (param $0 (ref $environment116)) (param $1 (ref null $type28)) (result (ref null $type40))
  (local $2 (ref $type29))
  (local $3 (ref $type34))
  (local $4 i32)
  (drop
   (ref.as_non_null
    (global.get $global297)
   )
  )
  (if (result (ref null $type40))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type40
     (if (result i32)
      (ref.test (ref $type30)
       (local.tee $2
        (struct.get $type28 0
         (local.get $1)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type31)
         (local.get $2)
        )
       )
       (i32.const 1)
      )
     )
     (block (result (ref null $type40))
      (local.set $1
       (struct.get $type28 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready297)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $environment116 0
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global297)
       )
      )
      (if (result (ref null $type40))
       (ref.is_null
        (local.get $1)
       )
       (then
        (ref.null none)
       )
       (else
        (struct.new $type40
         (if (result i32)
          (ref.test (ref $type30)
           (local.tee $2
            (struct.get $type28 0
             (local.get $1)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type31)
             (local.get $2)
            )
           )
           (i32.const 1)
          )
         )
         (block (result (ref null $type40))
          (local.set $1
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready297)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global297)
           )
          )
          (if (result (ref null $type40))
           (ref.is_null
            (local.get $1)
           )
           (then
            (ref.null none)
           )
           (else
            (struct.new $type40
             (if (result i32)
              (ref.test (ref $type30)
               (local.tee $2
                (struct.get $type28 0
                 (local.get $1)
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.cast (ref $type31)
                 (local.get $2)
                )
               )
               (i32.const 1)
              )
             )
             (block (result (ref null $type40))
              (local.set $1
               (struct.get $type28 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready297)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global297)
               )
              )
              (if (result (ref null $type40))
               (ref.is_null
                (local.get $1)
               )
               (then
                (ref.null none)
               )
               (else
                (struct.new $type40
                 (if (result i32)
                  (ref.test (ref $type30)
                   (local.tee $2
                    (struct.get $type28 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type31)
                     (local.get $2)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (block (result (ref null $type40))
                  (local.set $1
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready297)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global297)
                   )
                  )
                  (if (result (ref null $type40))
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (struct.new $type40
                     (if (result i32)
                      (ref.test (ref $type30)
                       (local.tee $2
                        (struct.get $type28 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.cast (ref $type31)
                         (local.get $2)
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (block (result (ref null $type40))
                      (local.set $1
                       (struct.get $type28 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready297)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global297)
                       )
                      )
                      (if (result (ref null $type40))
                       (ref.is_null
                        (local.get $1)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (struct.new $type40
                         (if (result i32)
                          (ref.test (ref $type30)
                           (local.tee $2
                            (struct.get $type28 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type31)
                             (local.get $2)
                            )
                           )
                           (i32.const 1)
                          )
                         )
                         (block (result (ref null $type40))
                          (local.set $1
                           (struct.get $type28 1
                            (local.get $1)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready297)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global297)
                           )
                          )
                          (if (result (ref null $type40))
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (ref.null none)
                           )
                           (else
                            (struct.new $type40
                             (if (result i32)
                              (ref.test (ref $type30)
                               (local.tee $2
                                (struct.get $type28 0
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (ref.cast (ref $type31)
                                 (local.get $2)
                                )
                               )
                               (i32.const 1)
                              )
                             )
                             (block (result (ref null $type40))
                              (local.set $1
                               (struct.get $type28 1
                                (local.get $1)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready297)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global297)
                               )
                              )
                              (if (result (ref null $type40))
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (struct.new $type40
                                 (if (result i32)
                                  (ref.test (ref $type30)
                                   (local.tee $2
                                    (struct.get $type28 0
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (drop
                                    (ref.cast (ref $type31)
                                     (local.get $2)
                                    )
                                   )
                                   (i32.const 1)
                                  )
                                 )
                                 (block (result (ref null $type40))
                                  (local.set $1
                                   (struct.get $type28 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready297)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global297)
                                   )
                                  )
                                  (if (result (ref null $type40))
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                   (then
                                    (ref.null none)
                                   )
                                   (else
                                    (struct.new $type40
                                     (if (result i32)
                                      (ref.test (ref $type30)
                                       (local.tee $2
                                        (struct.get $type28 0
                                         (local.get $1)
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (drop
                                        (ref.cast (ref $type31)
                                         (local.get $2)
                                        )
                                       )
                                       (i32.const 1)
                                      )
                                     )
                                     (block (result (ref null $type40))
                                      (local.set $1
                                       (struct.get $type28 1
                                        (local.get $1)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready297)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global297)
                                       )
                                      )
                                      (if (result (ref null $type40))
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (ref.null none)
                                       )
                                       (else
                                        (call $function118
                                         (struct.new $environment118
                                          (local.get $3)
                                          (local.get $1)
                                         )
                                         (call $function41
                                          (struct.get $type28 0
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function118 (type $10) (param $0 (ref $environment118)) (param $1 i32) (result (ref $type40))
  (local $2 (ref null $type28))
  (local $3 (ref $type34))
  (local.set $2
   (struct.get $type28 1
    (struct.get $environment118 1
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready297)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $environment118 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global297)
   )
  )
  (struct.new $type40
   (local.get $1)
   (if (result (ref null $type40))
    (ref.is_null
     (local.get $2)
    )
    (then
     (ref.null none)
    )
    (else
     (call $function118
      (struct.new $environment118
       (local.get $3)
       (local.get $2)
      )
      (call $function41
       (struct.get $type28 0
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function119 (type $9) (param $0 (ref $type54)) (param $1 (ref null $type33)) (result (ref null $type39))
  (local $2 (ref null $type40))
  (if (result (ref null $type39))
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type39
     (call $function116
      (struct.get $type54 0
       (local.get $0)
      )
      (struct.get $type33 0
       (local.get $1)
      )
     )
     (block (result (ref null $type39))
      (local.set $1
       (struct.get $type33 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready301)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global301)
       )
      )
      (call $function119
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function125 (type $8) (param $0 i64) (result (ref null $type39))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type89))
  (local $5 (ref null $type40))
  (if (result (ref null $type39))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global306)
     )
    )
    (local.set $1
     (call $foreign0
      (struct.get $type89 0
       (global.get $global305)
      )
     )
    )
    (local.set $2
     (i64.add
      (local.tee $3
       (struct.get $type89 0
        (local.tee $4
         (ref.as_non_null
          (global.get $global305)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type89 0
     (local.get $4)
     (local.get $2)
    )
    (drop
     (ref.as_non_null
      (global.get $global312)
     )
    )
    (struct.new $type39
     (if (result (ref null $type40))
      (i64.eqz
       (local.get $1)
      )
      (then
       (ref.null none)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global306)
        )
       )
       (call $function127
        (struct.new $environment127
         (local.get $1)
        )
        (i64.eq
         (call $foreign0
          (struct.get $type89 0
           (global.get $global305)
          )
         )
         (block (result i64)
          (local.set $1
           (i64.add
            (local.tee $3
             (struct.get $type89 0
              (local.tee $4
               (ref.as_non_null
                (global.get $global305)
               )
              )
             )
            )
            (i64.const 1)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $1)
              (local.get $3)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (struct.set $type89 0
           (local.get $4)
           (local.get $1)
          )
          (i64.const 1)
         )
        )
       )
      )
     )
     (block (result (ref null $type39))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready310)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global310)
       )
      )
      (call $function125
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function127 (type $6) (param $0 (ref $environment127)) (param $1 i32) (result (ref $type40))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type89))
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.sub
        (local.tee $2
         (struct.get $environment127 0
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready312)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global312)
   )
  )
  (struct.new $type40
   (local.get $1)
   (if (result (ref null $type40))
    (i64.eqz
     (local.get $3)
    )
    (then
     (ref.null none)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global306)
      )
     )
     (call $function127
      (struct.new $environment127
       (local.get $3)
      )
      (i64.eq
       (call $foreign0
        (struct.get $type89 0
         (global.get $global305)
        )
       )
       (block (result i64)
        (local.set $2
         (i64.add
          (local.tee $4
           (struct.get $type89 0
            (local.tee $5
             (ref.as_non_null
              (global.get $global305)
             )
            )
           )
          )
          (i64.const 1)
         )
        )
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $2)
            (local.get $4)
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type89 0
         (local.get $5)
         (local.get $2)
        )
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function131 (type $call109) (param $0 (ref $environment131)) (param $1 i64) (param $2 (ref $type35)) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment131 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global324)
     )
    )
    (local.set $2
     (call $function55
      (call $foreign1
       (global.get $global316)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global324)
        )
       )
       (local.set $scratch
        (call $foreign1
         (global.get $global317)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global148)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type111 0
       (struct.get $environment131 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function131
     (struct.get $type109 0
      (struct.get $type111 1
       (struct.get $environment131 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (call $function51
       (local.get $2)
       (ref.as_non_null
        (global.get $global318)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type111))
  (local $2 (ref $type36))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready319)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type111 1
   (local.tee $1
    (struct.new_default $type111)
   )
   (struct.new $type109
    (struct.new $environment131
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type111 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type111 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function131
   (struct.get $type109 0
    (struct.get $type111 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (local.get $2)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type89))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global194
   (struct.new_default $type27)
  )
  (global.set $global220
   (struct.new_default $type32)
  )
  (global.set $global106
   (global.get $empty30)
  )
  (global.set $global107
   (struct.new_default $type34)
  )
  (global.set $global112
   (global.get $empty36)
  )
  (global.set $global113
   (global.get $empty37)
  )
  (global.set $global114
   (global.get $empty41)
  )
  (global.set $global115
   (struct.new_default $type42)
  )
  (global.set $global119
   (struct.new_default $type43)
  )
  (global.set $global122
   (struct.new_default $type44)
  )
  (global.set $global124
   (struct.new_default $type44)
  )
  (global.set $global126
   (struct.new_default $type45)
  )
  (global.set $global129
   (struct.new_default $type46)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global173
   (struct.new_default $type47)
  )
  (global.set $global177
   (struct.new_default $type48)
  )
  (global.set $ready177
   (i32.const 1)
  )
  (global.set $global237
   (struct.new_default $type49)
  )
  (global.set $global244
   (struct.new_default $type50)
  )
  (global.set $ready244
   (i32.const 1)
  )
  (global.set $global297
   (struct.new_default $type52)
  )
  (global.set $ready297
   (i32.const 1)
  )
  (global.set $global301
   (struct.new_default $type53)
  )
  (global.set $ready301
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type55)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type56)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type57)
  )
  (global.set $global324
   (struct.new_default $type58)
  )
  (global.set $global180
   (struct.new_default $type59)
  )
  (global.set $global279
   (struct.new_default $type60)
  )
  (global.set $global159
   (struct.new_default $type62)
  )
  (global.set $global165
   (struct.new_default $type64)
  )
  (global.set $global175
   (struct.new_default $type66)
  )
  (global.set $global200
   (struct.new_default $type67)
  )
  (global.set $ready200
   (i32.const 1)
  )
  (global.set $global234
   (struct.new_default $type68)
  )
  (global.set $ready234
   (i32.const 1)
  )
  (global.set $global271
   (struct.new_default $type69)
  )
  (global.set $ready271
   (i32.const 1)
  )
  (global.set $global275
   (struct.new_default $type70)
  )
  (global.set $ready275
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type71)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type72)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type73)
  )
  (global.set $global230
   (struct.new_default $type75)
  )
  (global.set $global266
   (struct.new_default $type76)
  )
  (global.set $global218
   (struct.new_default $type77)
  )
  (global.set $global293
   (struct.new_default $type79)
  )
  (global.set $global146
   (struct.new_default $type80)
  )
  (global.set $global188
   (struct.new_default $type81)
  )
  (global.set $global190
   (struct.new_default $type71)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type82)
  )
  (global.set $global291
   (struct.new_default $type83)
  )
  (global.set $ready291
   (i32.const 1)
  )
  (global.set $global286
   (struct.new_default $type84)
  )
  (global.set $global206
   (struct.new_default $type85)
  )
  (global.set $ready206
   (i32.const 1)
  )
  (global.set $global210
   (struct.new_default $type84)
  )
  (global.set $ready210
   (i32.const 1)
  )
  (global.set $global250
   (struct.new_default $type86)
  )
  (global.set $ready250
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type87)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $global215
   (struct.new_default $type88)
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global305
   (struct.new_default $type89)
  )
  (global.set $global306
   (struct.new_default $type5)
  )
  (global.set $global312
   (struct.new_default $type90)
  )
  (global.set $ready312
   (i32.const 1)
  )
  (global.set $global310
   (struct.new_default $type91)
  )
  (global.set $ready310
   (i32.const 1)
  )
  (global.set $global308
   (struct.new_default $type92)
  )
  (global.set $ready308
   (i32.const 1)
  )
  (global.set $global316
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $global317
   (call $foreign2
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (local.set $0
   (call $foreign0
    (struct.get $type89 0
     (global.get $global305)
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $1
       (i64.add
        (local.tee $2
         (struct.get $type89 0
          (local.tee $3
           (ref.as_non_null
            (global.get $global305)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type89 0
   (local.get $3)
   (local.get $1)
  )
  (global.set $global318
   (if (result (ref $type35))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (else
     (if (result (ref $type35))
      (i64.eq
       (local.get $0)
       (i64.const 1)
      )
      (then
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (else
       (if (result (ref $type35))
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global306)
          )
         )
         (local.set $1
          (call $foreign0
           (struct.get $type89 0
            (global.get $global305)
           )
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $0
              (i64.add
               (local.tee $2
                (struct.get $type89 0
                 (local.tee $3
                  (ref.as_non_null
                   (global.get $global305)
                  )
                 )
                )
               )
               (i64.const 1)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $0)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type89 0
          (local.get $3)
          (local.get $0)
         )
         (drop
          (ref.as_non_null
           (global.get $global310)
          )
         )
         (struct.new $type38
          (i32.const 2)
          (call $function125
           (local.get $1)
          )
         )
        )
        (else
         (ref.as_non_null
          (global.get $global114)
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $global319
   (struct.new_default $type80)
  )
  (global.set $ready319
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

