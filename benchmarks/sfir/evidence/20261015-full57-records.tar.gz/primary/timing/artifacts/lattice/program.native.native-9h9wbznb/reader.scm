(module
 (rec
  (type $type96 (sub (struct)))
  (type $type90 (sub (struct)))
  (type $type84 (sub (struct)))
  (type $type78 (sub (struct)))
  (type $type73 (sub (struct)))
  (type $type67 (sub (struct)))
  (type $type61 (sub (struct)))
  (type $type50 (sub (struct)))
  (type $type44 (sub (struct)))
  (type $type33 (sub (struct)))
  (type $type39 (sub (struct)))
  (type $type55 (sub (struct)))
  (type $type28 (sub (struct)))
  (type $environment359 (struct (field i64) (field (ref $type282))))
  (type $type282 (struct (field (mut i32)) (field (mut (ref null $type157)))))
  (type $environment355 (struct (field (ref $type163)) (field (ref $type44))))
  (type $environment354 (struct (field (ref $type163)) (field (ref $type44))))
  (type $17 (func (param (ref $type188) (ref $type189) i32 i32 (ref $type55) (ref $type96)) (result (ref $type55))))
  (type $call188 (func (param (ref struct) (ref $type95)) (result i32)))
  (type $type98 (sub $type96 (struct (field (ref $type95)) (field (ref $type99)))))
  (type $type99 (struct (field (ref $type96))))
  (type $type95 (struct (field (ref $type44)) (field (ref $type44))))
  (type $environment353 (struct (field (ref $type163)) (field (ref $type55)) (field (ref $type55))))
  (type $environment351 (struct (field (ref $type44)) (field (ref $type163))))
  (type $type189 (struct))
  (type $type188 (struct (field (ref $call188)) (field (ref struct))))
  (type $environment345 (struct (field (ref $type44)) (field (ref $type163))))
  (type $environment341 (struct (field (ref $type203)) (field (ref $type203)) (field (ref $type96)) (field (ref $type227)) (field (ref $type141)) (field (ref $type44)) (field (ref $type55))))
  (type $call226 (func (param (ref $type203) (ref $type203) (ref $type96) (ref $type55) (ref $type227) (ref $type141)) (result i64)))
  (type $environment334 (struct (field (ref $type161)) (field (ref $type33))))
  (type $environment333 (struct (field (ref $type161)) (field (ref $type33))))
  (type $31 (func (param (ref $type185) (ref $type186) i32 i32 (ref $type44) (ref $type90)) (result (ref $type44))))
  (type $call185 (func (param (ref struct) (ref $type89)) (result i32)))
  (type $type92 (sub $type90 (struct (field (ref $type89)) (field (ref $type93)))))
  (type $type93 (struct (field (ref $type90))))
  (type $type89 (struct (field (ref $type44)) (field (ref $type33))))
  (type $environment332 (struct (field (ref $type161)) (field (ref $type44)) (field (ref $type44))))
  (type $environment330 (struct (field (ref $type44)) (field (ref $type163))))
  (type $type186 (struct))
  (type $type185 (struct (field (ref $call185)) (field (ref struct))))
  (type $environment324 (struct (field (ref $type44)) (field (ref $type163))))
  (type $environment320 (struct (field (ref $type203)) (field (ref $type201)) (field (ref $type90)) (field (ref $type225)) (field (ref $type141)) (field (ref $type44)) (field (ref $type55))))
  (type $42 (func (param (ref $environment319) (ref $type44) (ref $type55)) (result i64)))
  (type $call148 (func (param (ref $type149) (ref $type55)) (result (ref $type28))))
  (type $44 (func (param (ref $type102) i32 i32 (ref $type55) (ref $type55)) (result (ref $type55))))
  (type $45 (func (param (ref $environment307) (ref $type55)) (result i32)))
  (type $environment308 (struct (field (ref $type163)) (field (ref $type44))))
  (type $environment307 (struct (field (ref $type102)) (field (ref $type248)) (field (ref $type57))))
  (type $environment303 (struct (field (ref $type163)) (field (ref $type44))))
  (type $49 (func (param (ref $environment296) (ref $type55)) (result (ref $type55))))
  (type $environment296 (struct (field (ref $type248)) (field (ref $type57)) (field (ref $type55))))
  (type $51 (func (param (ref $type182) (ref $type183) i32 i32 (ref $type55) (ref $type84)) (result (ref $type55))))
  (type $call182 (func (param (ref struct) (ref $type83)) (result i32)))
  (type $type86 (sub $type84 (struct (field (ref $type83)) (field (ref $type87)))))
  (type $type87 (struct (field (ref $type84))))
  (type $type83 (struct (field (ref $type33)) (field (ref $type44))))
  (type $call149 (func (param (ref struct) (ref $type44)) (result i64)))
  (type $environment302 (struct (field (ref $type163)) (field (ref $type55)) (field (ref $type55))))
  (type $environment300 (struct (field (ref $type33)) (field (ref $type161))))
  (type $type183 (struct))
  (type $type182 (struct (field (ref $call182)) (field (ref struct))))
  (type $environment289 (struct (field (ref $type33)) (field (ref $type161))))
  (type $environment285 (struct (field (ref $type201)) (field (ref $type203)) (field (ref $type84)) (field (ref $type223)) (field (ref $type141)) (field (ref $type33)) (field (ref $type44))))
  (type $type149 (struct (field (ref $call149)) (field (ref struct))))
  (type $call222 (func (param (ref $type201) (ref $type203) (ref $type84) (ref $type44) (ref $type223) (ref $type141)) (result i64)))
  (type $call163 (func (param (ref $environment274) (ref $type44) (ref $type44)) (result i64)))
  (type $environment272 (struct (field (ref $type161)) (field i64) (field (ref $type248)) (field (ref $type44)) (field (ref $type46))))
  (type $67 (func (param (ref $environment272) i64) (result i64)))
  (type $68 (func (param (ref $environment267) (ref $type55)) (result (ref $type80))))
  (type $call147 (func (param (ref $environment265) (ref $type33)) (result (ref $type55))))
  (type $environment267 (struct (field (ref $type147)) (field (ref $type46))))
  (type $environment265 (struct (field (ref $type201)) (field (ref $type201)) (field (ref $type73)) (field (ref $type221)) (field (ref $type155)) (field (ref $type33)) (field (ref $type44))))
  (type $type147 (struct (field (ref $environment265))))
  (type $73 (func (param (ref $environment264) (ref $type33) (ref $type44)) (result (ref $type55))))
  (type $74 (func (param (ref $type55) (ref $type55)) (result (ref $type55))))
  (type $type81 (struct (field (ref $type78))))
  (type $type80 (sub $type78 (struct (field (ref $type55)) (field (ref $type81)))))
  (type $call155 (func (param (ref $type78)) (result (ref $type55))))
  (type $environment257 (struct (field (ref $type145)) (field (ref $type75))))
  (type $79 (func (param (ref $environment257) (ref $type33)) (result (ref $type46))))
  (type $type163 (struct (field (ref $environment274))))
  (type $environment274 (struct (field (ref $type161)) (field (ref $type272))))
  (type $environment264 (struct (field (ref $type201)) (field (ref $type201)) (field (ref $type73)) (field (ref $type221)) (field (ref $type155))))
  (type $type221 (struct))
  (type $type272 (struct (field (mut i32)) (field (mut (ref null $type163)))))
  (type $call230 (func (param (ref $type201) (ref $type201)) (result (ref $type203))))
  (type $call142 (func (param (ref $type143) (ref $type44)) (result (ref $type28))))
  (type $87 (func (param (ref $type103) i32 i32 (ref $type44) (ref $type44)) (result (ref $type44))))
  (type $88 (func (param (ref $environment246) (ref $type44)) (result i32)))
  (type $environment247 (struct (field (ref $type161)) (field (ref $type33))))
  (type $environment246 (struct (field (ref $type103)) (field (ref $type248)) (field (ref $type46))))
  (type $environment242 (struct (field (ref $type161)) (field (ref $type33))))
  (type $92 (func (param (ref $environment235) (ref $type44)) (result (ref $type44))))
  (type $environment235 (struct (field (ref $type248)) (field (ref $type46)) (field (ref $type44))))
  (type $94 (func (param (ref $type180) (ref $type145) i32 i32 (ref $type44) (ref $type73)) (result (ref $type44))))
  (type $call180 (func (param (ref struct) (ref $type72)) (result i32)))
  (type $type75 (sub $type73 (struct (field (ref $type72)) (field (ref $type76)))))
  (type $type76 (struct (field (ref $type73))))
  (type $type72 (struct (field (ref $type33)) (field (ref $type33))))
  (type $call143 (func (param (ref struct) (ref $type33)) (result i64)))
  (type $environment241 (struct (field (ref $type161)) (field (ref $type44)) (field (ref $type44))))
  (type $environment239 (struct (field (ref $type33)) (field (ref $type161))))
  (type $type145 (struct))
  (type $type180 (struct (field (ref $call180)) (field (ref struct))))
  (type $environment228 (struct (field (ref $type33)) (field (ref $type161))))
  (type $environment224 (struct (field (ref $type201)) (field (ref $type201)) (field (ref $type73)) (field (ref $type219)) (field (ref $type141)) (field (ref $type33)) (field (ref $type44))))
  (type $type143 (struct (field (ref $call143)) (field (ref struct))))
  (type $call218 (func (param (ref $type201) (ref $type201) (ref $type73) (ref $type44) (ref $type219) (ref $type141)) (result i64)))
  (type $environment217 (struct (field (ref $type157)) (field i64)))
  (type $environment216 (struct (field (ref $type157)) (field i64)))
  (type $110 (func (param (ref $type177) (ref $type178) i32 i32 (ref $type28) (ref $type67)) (result (ref $type28))))
  (type $call177 (func (param (ref struct) (ref $type66)) (result i32)))
  (type $type69 (sub $type67 (struct (field (ref $type66)) (field (ref $type70)))))
  (type $type70 (struct (field (ref $type67))))
  (type $type66 (struct (field (ref $type28)) (field i64)))
  (type $environment215 (struct (field (ref $type157)) (field (ref $type28)) (field (ref $type28))))
  (type $environment213 (struct (field (ref $type28)) (field (ref $type159))))
  (type $type178 (struct))
  (type $type177 (struct (field (ref $call177)) (field (ref struct))))
  (type $environment207 (struct (field (ref $type28)) (field (ref $type159))))
  (type $environment203 (struct (field (ref $type197)) (field (ref $type195)) (field (ref $type67)) (field (ref $type217)) (field (ref $type141)) (field (ref $type28)) (field (ref $type33))))
  (type $call216 (func (param (ref $type197) (ref $type195) (ref $type67) (ref $type33) (ref $type217) (ref $type141)) (result i64)))
  (type $environment198 (struct (field (ref $type159)) (field (ref $type28))))
  (type $environment197 (struct (field (ref $type159)) (field (ref $type28))))
  (type $124 (func (param (ref $type174) (ref $type175) i32 i32 (ref $type33) (ref $type61)) (result (ref $type33))))
  (type $call174 (func (param (ref struct) (ref $type60)) (result i32)))
  (type $type63 (sub $type61 (struct (field (ref $type60)) (field (ref $type64)))))
  (type $type64 (struct (field (ref $type61))))
  (type $type60 (struct (field i64) (field (ref $type28))))
  (type $environment196 (struct (field (ref $type159)) (field (ref $type33)) (field (ref $type33))))
  (type $environment194 (struct (field i64) (field (ref $type157))))
  (type $type175 (struct))
  (type $type174 (struct (field (ref $call174)) (field (ref struct))))
  (type $environment188 (struct (field i64) (field (ref $type157))))
  (type $environment184 (struct (field (ref $type195)) (field (ref $type197)) (field (ref $type61)) (field (ref $type215)) (field (ref $type141)) (field i64) (field (ref $type28))))
  (type $call214 (func (param (ref $type195) (ref $type197) (ref $type61) (ref $type28) (ref $type215) (ref $type141)) (result i64)))
  (type $call140 (func (param (ref $type141) (ref $type33)) (result (ref $type28))))
  (type $environment177 (struct (field (ref $type197)) (field (ref $type197)) (field (ref $type50)) (field (ref $type213)) (field (ref $type141)) (field (ref $type28)) (field (ref $type33))))
  (type $call212 (func (param (ref $type197) (ref $type197) (ref $type50) (ref $type33) (ref $type213) (ref $type141)) (result i64)))
  (type $call138 (func (param (ref $type139) (ref $type28)) (result (ref $type28))))
  (type $environment170 (struct (field (ref $type195)) (field (ref $type195)) (field (ref $type39)) (field (ref $type211)) (field (ref $type141)) (field i64) (field (ref $type28))))
  (type $call210 (func (param (ref $type195) (ref $type195) (ref $type39) (ref $type28) (ref $type211) (ref $type141)) (result i64)))
  (type $call161 (func (param (ref $environment158) (ref $type33) (ref $type33)) (result i64)))
  (type $environment156 (struct (field (ref $type159)) (field i64) (field (ref $type248)) (field (ref $type33)) (field (ref $type35))))
  (type $144 (func (param (ref $environment156) i64) (result i64)))
  (type $call136 (func (param (ref $type137) (ref $type33)) (result (ref $type55))))
  (type $146 (func (param (ref $type100) i32 i32 (ref $type33) (ref $type33)) (result (ref $type33))))
  (type $147 (func (param (ref $environment145) (ref $type33)) (result i32)))
  (type $environment146 (struct (field (ref $type159)) (field (ref $type28))))
  (type $environment145 (struct (field (ref $type100)) (field (ref $type248)) (field (ref $type35))))
  (type $environment141 (struct (field (ref $type159)) (field (ref $type28))))
  (type $151 (func (param (ref $environment135) (ref $type33)) (result (ref $type33))))
  (type $environment135 (struct (field (ref $type248)) (field (ref $type35)) (field (ref $type33))))
  (type $153 (func (param (ref $type172) (ref $type135) i32 i32 (ref $type33) (ref $type50)) (result (ref $type33))))
  (type $call172 (func (param (ref struct) (ref $type49)) (result i32)))
  (type $type137 (struct (field (ref $environment125))))
  (type $environment125 (struct (field (ref $type197)) (field (ref $type197)) (field (ref $type50)) (field (ref $type209)) (field (ref $type154)) (field (ref $type28)) (field (ref $type33))))
  (type $environment140 (struct (field (ref $type159)) (field (ref $type33)) (field (ref $type33))))
  (type $environment138 (struct (field (ref $type28)) (field (ref $type159))))
  (type $type172 (struct (field (ref $call172)) (field (ref struct))))
  (type $environment129 (struct (field (ref $type28)) (field (ref $type159))))
  (type $call208 (func (param (ref $type197) (ref $type197) (ref $type50) (ref $type33) (ref $type209) (ref $type154)) (result (ref $type44))))
  (type $162 (func (param (ref $type44) (ref $type44)) (result (ref $type44))))
  (type $call154 (func (param (ref $type55)) (result (ref $type44))))
  (type $type49 (struct (field (ref $type28)) (field (ref $type28))))
  (type $type53 (struct (field (ref $type50))))
  (type $environment116 (struct (field (ref $type135)) (field (ref $type52))))
  (type $type135 (struct))
  (type $type52 (sub $type50 (struct (field (ref $type49)) (field (ref $type53)))))
  (type $169 (func (param (ref $environment116) (ref $type28)) (result (ref $type35))))
  (type $call159 (func (param (ref $environment105) (ref $type28) (ref $type28)) (result i64)))
  (type $environment103 (struct (field (ref $type157)) (field i64) (field (ref $type248)) (field (ref $type28)) (field (ref $type30))))
  (type $172 (func (param (ref $environment103) i64) (result i64)))
  (type $call43 (func (param (ref $type33) (ref $type44)) (result (ref $type46))))
  (type $174 (func (param (ref $environment98) (ref $type33)) (result (ref $type46))))
  (type $175 (func (param (ref $type165) i32 i32 (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $176 (func (param (ref $environment92) (ref $type28)) (result i32)))
  (type $environment93 (struct (field (ref $type157)) (field i64)))
  (type $environment92 (struct (field (ref $type165)) (field (ref $type248)) (field (ref $type30))))
  (type $environment88 (struct (field (ref $type157)) (field i64)))
  (type $call165 (func (param (ref struct) i64) (result i32)))
  (type $181 (func (param (ref $environment82) (ref $type28)) (result (ref $type28))))
  (type $environment82 (struct (field (ref $type248)) (field (ref $type30)) (field (ref $type28))))
  (type $type248 (struct))
  (type $184 (func (param (ref $type170) (ref $type131) i32 i32 (ref $type28) (ref $type39)) (result (ref $type28))))
  (type $call170 (func (param (ref struct) (ref $type38)) (result i32)))
  (type $type165 (struct (field (ref $call165)) (field (ref struct))))
  (type $environment87 (struct (field (ref $type157)) (field (ref $type28)) (field (ref $type28))))
  (type $environment85 (struct (field i64) (field (ref $type157))))
  (type $type170 (struct (field (ref $call170)) (field (ref struct))))
  (type $environment76 (struct (field i64) (field (ref $type157))))
  (type $191 (func (param (ref $environment75) (ref $type157) (ref $type157)) (result (ref $type28))))
  (type $call133 (func (param (ref $environment72) i64) (result (ref $type33))))
  (type $environment98 (struct (field (ref $type133)) (field (ref $type30))))
  (type $environment72 (struct (field (ref $type195)) (field (ref $type195)) (field (ref $type39)) (field (ref $type207)) (field (ref $type153)) (field i64) (field (ref $type28))))
  (type $environment75 (struct (field (ref $type195)) (field (ref $type39)) (field i64)))
  (type $type133 (struct (field (ref $environment72))))
  (type $197 (func (param (ref $environment71) i64 (ref $type28)) (result (ref $type33))))
  (type $198 (func (param (ref $type35)) (result (ref $type33))))
  (type $call103 (func (param structref (ref $type33)) (result i32)))
  (type $200 (func (param (ref $type33) (ref $type33)) (result (ref $type33))))
  (type $201 (func (param (ref $type46)) (result (ref $type44))))
  (type $call102 (func (param structref (ref $type44)) (result i32)))
  (type $type47 (struct (field (mut (ref $type44)))))
  (type $type46 (sub $type44 (struct (field (ref $type33)) (field (ref $type47)))))
  (type $call153 (func (param (ref $type44)) (result (ref $type33))))
  (type $type35 (sub $type33 (struct (field (ref $type28)) (field (ref $type36)))))
  (type $type36 (struct (field (mut (ref $type33)))))
  (type $call32 (func (param (ref $type28) (ref $type33)) (result (ref $type35))))
  (type $type38 (struct (field i64) (field i64)))
  (type $type42 (struct (field (ref $type39))))
  (type $environment60 (struct (field (ref $type131)) (field (ref $type41))))
  (type $type131 (struct))
  (type $type41 (sub $type39 (struct (field (ref $type38)) (field (ref $type42)))))
  (type $214 (func (param (ref $environment60) i64) (result (ref $type30))))
  (type $call157 (func (param (ref null $environment359) i64 i64) (result i64)))
  (type $type227 (struct))
  (type $type58 (struct (field (mut (ref $type55)))))
  (type $environment319 (struct (field (ref $type203)) (field (ref $type201)) (field (ref $type90)) (field (ref $type225)) (field (ref $type141))))
  (type $type225 (struct))
  (type $type223 (struct))
  (type $type219 (struct))
  (type $type217 (struct))
  (type $type215 (struct))
  (type $type213 (struct))
  (type $type211 (struct))
  (type $type161 (struct (field (ref $environment158))))
  (type $environment158 (struct (field (ref $type159)) (field (ref $type258))))
  (type $type209 (struct))
  (type $type159 (struct (field (ref $environment105))))
  (type $environment105 (struct (field (ref $type157)) (field (ref $type250))))
  (type $environment71 (struct (field (ref $type195)) (field (ref $type195)) (field (ref $type39)) (field (ref $type207)) (field (ref $type153))))
  (type $type207 (struct))
  (type $type57 (sub $type55 (struct (field (ref $type44)) (field (ref $type58)))))
  (type $type258 (struct (field (mut i32)) (field (mut (ref null $type161)))))
  (type $type250 (struct (field (mut i32)) (field (mut (ref null $type159)))))
  (type $type203 (struct (field (ref $type55)) (field (ref $type163))))
  (type $type195 (struct (field (ref $type30)) (field (ref $type157))))
  (type $type201 (struct (field (ref $type44)) (field (ref $type161))))
  (type $type197 (struct (field (ref $type33)) (field (ref $type159))))
  (type $call139 (func (param structref i64) (result i64)))
  (type $call141 (func (param structref (ref $type28)) (result i64)))
  (type $call100 (func (param structref (ref $type28)) (result i32)))
  (type $type31 (struct (field (mut (ref $type28)))))
  (type $call156 (func (param i64 (ref $type28)) (result i32)))
  (type $type238 (struct))
  (type $type237 (struct))
  (type $type236 (struct))
  (type $type235 (struct))
  (type $type234 (struct))
  (type $type233 (struct))
  (type $type231 (struct))
  (type $type229 (struct))
  (type $type228 (struct))
  (type $type205 (struct))
  (type $type204 (struct))
  (type $type202 (struct))
  (type $type199 (struct))
  (type $type198 (struct))
  (type $type162 (struct))
  (type $type160 (struct))
  (type $type158 (struct))
  (type $type129 (struct))
  (type $type128 (struct))
  (type $type127 (struct))
  (type $type126 (struct))
  (type $type125 (struct))
  (type $type124 (struct))
  (type $type123 (struct))
  (type $type120 (struct))
  (type $type119 (struct))
  (type $type112 (struct))
  (type $type111 (struct))
  (type $type110 (struct))
  (type $type107 (struct))
  (type $type106 (struct))
  (type $type94 (struct))
  (type $type88 (struct))
  (type $type82 (struct))
  (type $type77 (struct))
  (type $type65 (struct))
  (type $type59 (struct))
  (type $type139 (struct (field (ref $call139)) (field structref)))
  (type $type232 (struct))
  (type $type226 (struct))
  (type $type224 (struct))
  (type $type222 (struct))
  (type $type220 (struct))
  (type $type218 (struct))
  (type $type216 (struct))
  (type $type214 (struct))
  (type $type210 (struct))
  (type $type208 (struct))
  (type $type206 (struct))
  (type $type200 (struct))
  (type $type196 (struct))
  (type $type194 (struct))
  (type $type187 (struct))
  (type $type184 (struct))
  (type $type181 (struct))
  (type $type176 (struct))
  (type $type173 (struct))
  (type $type169 (struct))
  (type $type168 (struct))
  (type $type164 (struct))
  (type $type157 (struct (field (ref $call157)) (field (ref null $environment359))))
  (type $type155 (struct (field (ref $call155))))
  (type $type154 (struct (field (ref $call154))))
  (type $type153 (struct (field (ref $call153))))
  (type $type152 (struct))
  (type $type146 (struct))
  (type $type136 (struct))
  (type $type134 (struct))
  (type $type132 (struct))
  (type $type130 (struct))
  (type $type122 (struct))
  (type $type121 (struct))
  (type $type117 (struct))
  (type $type114 (struct))
  (type $type109 (struct))
  (type $type71 (struct))
  (type $type48 (struct))
  (type $type37 (struct))
  (type $type230 (struct))
  (type $type212 (struct))
  (type $type167 (struct))
  (type $type166 (struct))
  (type $type148 (struct))
  (type $type144 (struct))
  (type $type142 (struct))
  (type $type140 (struct))
  (type $type138 (struct))
  (type $type104 (struct))
  (type $type101 (struct))
  (type $type193 (struct))
  (type $type192 (struct))
  (type $type191 (struct))
  (type $type190 (struct))
  (type $type179 (struct))
  (type $type171 (struct))
  (type $type108 (struct))
  (type $type151 (struct))
  (type $type150 (struct))
  (type $type54 (struct))
  (type $type30 (sub $type28 (struct (field i64) (field (ref $type31)))))
  (type $type141 (struct (field (ref $call141)) (field structref)))
  (type $type32 (struct))
  (type $type43 (struct))
  (type $type27 (struct))
  (type $type156 (struct))
  (type $type118 (struct))
  (type $type105 (struct))
  (type $type100 (struct (field (ref $call100)) (field structref)))
  (type $type113 (struct))
  (type $type103 (struct (field (ref $call103)) (field structref)))
  (type $type116 (struct))
  (type $type102 (struct (field (ref $call102)) (field structref)))
  (type $type115 (struct))
  (type $type97 (sub $type96 (struct)))
  (type $type91 (sub $type90 (struct)))
  (type $type85 (sub $type84 (struct)))
  (type $type68 (sub $type67 (struct)))
  (type $type62 (sub $type61 (struct)))
  (type $type79 (sub $type78 (struct)))
  (type $type74 (sub $type73 (struct)))
  (type $type40 (sub $type39 (struct)))
  (type $type51 (sub $type50 (struct)))
  (type $type56 (sub $type55 (struct)))
  (type $type34 (sub $type33 (struct)))
  (type $type45 (sub $type44 (struct)))
  (type $type29 (sub $type28 (struct)))
 )
 (type $371 (func (param i64) (result i64)))
 (type $372 (func (param i32) (result i64)))
 (type $373 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $global162 (mut (ref null $type115)) (ref.null none))
 (global $global157 (mut (ref null $type102)) (ref.null none))
 (global $global172 (mut (ref null $type116)) (ref.null none))
 (global $global167 (mut (ref null $type103)) (ref.null none))
 (global $global115 (mut (ref null $type113)) (ref.null none))
 (global $global109 (mut (ref null $type100)) (ref.null none))
 (global $empty29 (ref $type29) (struct.new_default $type29))
 (global $empty45 (ref $type45) (struct.new_default $type45))
 (global $empty34 (ref $type34) (struct.new_default $type34))
 (global $global276 (mut (ref null $type105)) (ref.null none))
 (global $global281 (mut (ref null $type118)) (ref.null none))
 (global $global106 (mut (ref null $type156)) (ref.null none))
 (global $empty56 (ref $type56) (struct.new_default $type56))
 (global $global118 (mut (ref null $type27)) (ref.null none))
 (global $global235 (mut (ref null $type43)) (ref.null none))
 (global $global151 (mut (ref null $type32)) (ref.null none))
 (global $global123 (mut (ref null $type141)) (ref.null none))
 (global $ready123 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type30)) (ref.null none))
 (global $global122 (mut (ref null $type30)) (ref.null none))
 (global $global347 (mut (ref null $type54)) (ref.null none))
 (global $global164 (mut (ref null $type150)) (ref.null none))
 (global $global283 (mut (ref null $type151)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $ready283 (mut i32) (i32.const 0))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global532 (mut (ref null $type108)) (ref.null none))
 (global $global307 (mut (ref null $type171)) (ref.null none))
 (global $global525 (mut (ref null $type179)) (ref.null none))
 (global $global217 (mut (ref null $type190)) (ref.null none))
 (global $global329 (mut (ref null $type191)) (ref.null none))
 (global $global554 (mut (ref null $type192)) (ref.null none))
 (global $global685 (mut (ref null $type193)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type101)) (ref.null none))
 (global $global265 (mut (ref null $type104)) (ref.null none))
 (global $global384 (mut (ref null $type138)) (ref.null none))
 (global $global402 (mut (ref null $type140)) (ref.null none))
 (global $global568 (mut (ref null $type142)) (ref.null none))
 (global $global577 (mut (ref null $type144)) (ref.null none))
 (global $global699 (mut (ref null $type148)) (ref.null none))
 (global $global336 (mut (ref null $type166)) (ref.null none))
 (global $global561 (mut (ref null $type167)) (ref.null none))
 (global $global202 (mut (ref null $type113)) (ref.null none))
 (global $global314 (mut (ref null $type116)) (ref.null none))
 (global $global537 (mut (ref null $type115)) (ref.null none))
 (global $global668 (mut (ref null $type118)) (ref.null none))
 (global $global392 (mut (ref null $type212)) (ref.null none))
 (global $global573 (mut (ref null $type230)) (ref.null none))
 (global $empty51 (ref $type51) (struct.new_default $type51))
 (global $global184 (mut (ref null $type37)) (ref.null none))
 (global $global296 (mut (ref null $type48)) (ref.null none))
 (global $global514 (mut (ref null $type71)) (ref.null none))
 (global $global584 (mut (ref null $type109)) (ref.null none))
 (global $global149 (mut (ref null $type114)) (ref.null none))
 (global $global271 (mut (ref null $type117)) (ref.null none))
 (global $global547 (mut (ref null $type121)) (ref.null none))
 (global $global589 (mut (ref null $type122)) (ref.null none))
 (global $global140 (mut (ref null $type130)) (ref.null none))
 (global $global231 (mut (ref null $type132)) (ref.null none))
 (global $global262 (mut (ref null $type134)) (ref.null none))
 (global $global343 (mut (ref null $type136)) (ref.null none))
 (global $global604 (mut (ref null $type146)) (ref.null none))
 (global $global591 (mut (ref null $type152)) (ref.null none))
 (global $global155 (mut (ref null $type153)) (ref.null none))
 (global $global274 (mut (ref null $type154)) (ref.null none))
 (global $global582 (mut (ref null $type155)) (ref.null none))
 (global $global802 (mut (ref null $type157)) (ref.null none))
 (global $global224 (mut (ref null $type164)) (ref.null none))
 (global $global692 (mut (ref null $type168)) (ref.null none))
 (global $global195 (mut (ref null $type169)) (ref.null none))
 (global $global431 (mut (ref null $type173)) (ref.null none))
 (global $global477 (mut (ref null $type176)) (ref.null none))
 (global $global656 (mut (ref null $type181)) (ref.null none))
 (global $global730 (mut (ref null $type184)) (ref.null none))
 (global $global778 (mut (ref null $type187)) (ref.null none))
 (global $global187 (mut (ref null $type194)) (ref.null none))
 (global $global299 (mut (ref null $type196)) (ref.null none))
 (global $global517 (mut (ref null $type200)) (ref.null none))
 (global $global174 (mut (ref null $type206)) (ref.null none))
 (global $global286 (mut (ref null $type208)) (ref.null none))
 (global $global374 (mut (ref null $type210)) (ref.null none))
 (global $global410 (mut (ref null $type214)) (ref.null none))
 (global $global456 (mut (ref null $type216)) (ref.null none))
 (global $global504 (mut (ref null $type218)) (ref.null none))
 (global $global594 (mut (ref null $type220)) (ref.null none))
 (global $global635 (mut (ref null $type222)) (ref.null none))
 (global $global709 (mut (ref null $type224)) (ref.null none))
 (global $global757 (mut (ref null $type226)) (ref.null none))
 (global $global388 (mut (ref null $type232)) (ref.null none))
 (global $global125 (mut (ref null $type139)) (ref.null none))
 (global $global799 (mut i64) (i64.const 0))
 (global $empty40 (ref $type40) (struct.new_default $type40))
 (global $empty74 (ref $type74) (struct.new_default $type74))
 (global $empty79 (ref $type79) (struct.new_default $type79))
 (global $global420 (mut (ref null $type59)) (ref.null none))
 (global $global466 (mut (ref null $type65)) (ref.null none))
 (global $global608 (mut (ref null $type77)) (ref.null none))
 (global $global645 (mut (ref null $type82)) (ref.null none))
 (global $global719 (mut (ref null $type88)) (ref.null none))
 (global $global767 (mut (ref null $type94)) (ref.null none))
 (global $global438 (mut (ref null $type106)) (ref.null none))
 (global $global484 (mut (ref null $type107)) (ref.null none))
 (global $global663 (mut (ref null $type110)) (ref.null none))
 (global $global737 (mut (ref null $type111)) (ref.null none))
 (global $global785 (mut (ref null $type112)) (ref.null none))
 (global $global444 (mut (ref null $type119)) (ref.null none))
 (global $global490 (mut (ref null $type120)) (ref.null none))
 (global $global678 (mut (ref null $type123)) (ref.null none))
 (global $global743 (mut (ref null $type124)) (ref.null none))
 (global $global791 (mut (ref null $type125)) (ref.null none))
 (global $global208 (mut (ref null $type126)) (ref.null none))
 (global $global320 (mut (ref null $type127)) (ref.null none))
 (global $global543 (mut (ref null $type128)) (ref.null none))
 (global $global674 (mut (ref null $type129)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $ready231 (mut i32) (i32.const 0))
 (global $ready262 (mut i32) (i32.const 0))
 (global $ready343 (mut i32) (i32.const 0))
 (global $ready384 (mut i32) (i32.const 0))
 (global $ready402 (mut i32) (i32.const 0))
 (global $ready568 (mut i32) (i32.const 0))
 (global $ready577 (mut i32) (i32.const 0))
 (global $ready604 (mut i32) (i32.const 0))
 (global $ready699 (mut i32) (i32.const 0))
 (global $ready591 (mut i32) (i32.const 0))
 (global $ready155 (mut i32) (i32.const 0))
 (global $ready274 (mut i32) (i32.const 0))
 (global $ready582 (mut i32) (i32.const 0))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type30)) (ref.null none))
 (global $global238 (mut (ref null $type158)) (ref.null none))
 (global $global350 (mut (ref null $type160)) (ref.null none))
 (global $global611 (mut (ref null $type162)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $ready314 (mut i32) (i32.const 0))
 (global $ready537 (mut i32) (i32.const 0))
 (global $ready668 (mut i32) (i32.const 0))
 (global $global423 (mut (ref null $type198)) (ref.null none))
 (global $global469 (mut (ref null $type199)) (ref.null none))
 (global $global648 (mut (ref null $type202)) (ref.null none))
 (global $global722 (mut (ref null $type204)) (ref.null none))
 (global $global770 (mut (ref null $type205)) (ref.null none))
 (global $ready174 (mut i32) (i32.const 0))
 (global $ready286 (mut i32) (i32.const 0))
 (global $ready374 (mut i32) (i32.const 0))
 (global $ready392 (mut i32) (i32.const 0))
 (global $ready410 (mut i32) (i32.const 0))
 (global $ready456 (mut i32) (i32.const 0))
 (global $ready504 (mut i32) (i32.const 0))
 (global $ready594 (mut i32) (i32.const 0))
 (global $ready635 (mut i32) (i32.const 0))
 (global $ready709 (mut i32) (i32.const 0))
 (global $ready757 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type228)) (ref.null none))
 (global $global258 (mut (ref null $type229)) (ref.null none))
 (global $global370 (mut (ref null $type231)) (ref.null none))
 (global $global406 (mut (ref null $type233)) (ref.null none))
 (global $global452 (mut (ref null $type234)) (ref.null none))
 (global $global500 (mut (ref null $type235)) (ref.null none))
 (global $global631 (mut (ref null $type236)) (ref.null none))
 (global $global705 (mut (ref null $type237)) (ref.null none))
 (global $global753 (mut (ref null $type238)) (ref.null none))
 (global $global800 (mut (ref null $type139)) (ref.null none))
 (global $ready800 (mut i32) (i32.const 0))
 (global $empty62 (ref $type62) (struct.new_default $type62))
 (global $empty68 (ref $type68) (struct.new_default $type68))
 (global $empty85 (ref $type85) (struct.new_default $type85))
 (global $empty91 (ref $type91) (struct.new_default $type91))
 (global $empty97 (ref $type97) (struct.new_default $type97))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call156) (param $0 i64) (param $1 (ref $type28)) (result i32)
  (local $2 i32)
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (local.tee $2
      (i64.eq
       (struct.get $type30 0
        (ref.cast (ref $type30)
         (local.get $1)
        )
       )
       (local.get $0)
      )
     )
     (then
      (local.get $2)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type31 0
        (struct.get $type30 1
         (ref.cast (ref $type30)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready106)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (return_call $function41
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function42 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (if (result i32)
   (ref.test (ref $type29)
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.cast (ref $type30)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function46 (type $call141) (param $0 structref) (param $1 (ref $type28)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type30))
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type30 0
      (local.tee $5
       (ref.cast (ref $type30)
        (local.get $1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (i32.eqz
      (global.get $ready123)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.tee $4
           (call $function46
            (struct.get $type141 1
             (global.get $global123)
            )
            (struct.get $type31 0
             (struct.get $type30 1
              (local.get $5)
             )
            )
           )
          )
          (local.get $2)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function47 (type $call139) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type197))
  (local $3 (ref $type201))
  (local $4 (ref $type195))
  (local $5 (ref $type203))
  (local $6 (ref $type250))
  (local $7 (ref $type258))
  (local $8 (ref $type55))
  (local $9 (ref $type30))
  (local $10 (ref $type141))
  (local $11 (ref $type57))
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global174)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (local.set $9
   (struct.get $type195 0
    (local.tee $4
     (struct.new $type195
      (ref.as_non_null
       (global.get $global117)
      )
      (struct.new $type157
       (ref.func $function48)
       (ref.null none)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (local.set $2
   (struct.new $type197
    (call $function71
     (struct.new $environment71
      (local.get $4)
      (local.get $4)
      (global.get $empty40)
      (struct.new_default $type207)
      (struct.new $type153
       (ref.func $function63)
      )
     )
     (struct.get $type30 0
      (local.get $9)
     )
     (struct.get $type31 0
      (struct.get $type30 1
       (local.get $9)
      )
     )
    )
    (block (result (ref $type159))
     (drop
      (ref.as_non_null
       (global.get $global238)
      )
     )
     (struct.set $type250 1
      (local.tee $6
       (struct.new_default $type250)
      )
      (struct.new $type159
       (struct.new $environment105
        (struct.get $type195 1
         (local.get $4)
        )
        (local.get $6)
       )
      )
     )
     (struct.set $type250 0
      (local.get $6)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type250 0
        (local.get $6)
       )
      )
      (then
       (unreachable)
      )
     )
     (ref.as_non_null
      (struct.get $type250 1
       (local.get $6)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global286)
   )
  )
  (local.set $3
   (struct.new $type201
    (call $function123
     (local.get $2)
     (local.get $2)
     (global.get $empty51)
     (struct.get $type197 0
      (local.get $2)
     )
     (struct.new_default $type209)
     (struct.new $type154
      (ref.func $function118)
     )
    )
    (block (result (ref $type161))
     (drop
      (ref.as_non_null
       (global.get $global350)
      )
     )
     (struct.set $type258 1
      (local.tee $7
       (struct.new_default $type258)
      )
      (struct.new $type161
       (struct.new $environment158
        (struct.get $type197 1
         (local.get $2)
        )
        (local.get $7)
       )
      )
     )
     (struct.set $type258 0
      (local.get $7)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type258 0
        (local.get $7)
       )
      )
      (then
       (unreachable)
      )
     )
     (ref.as_non_null
      (struct.get $type258 1
       (local.get $7)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global370)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global374)
   )
  )
  (drop
   (call $function168
    (local.get $4)
    (local.get $4)
    (global.get $empty40)
    (struct.get $type195 0
     (local.get $4)
    )
    (struct.new_default $type211)
    (ref.as_non_null
     (global.get $global123)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global388)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global392)
   )
  )
  (drop
   (call $function175
    (local.get $2)
    (local.get $2)
    (global.get $empty51)
    (struct.get $type197 0
     (local.get $2)
    )
    (struct.new_default $type213)
    (ref.as_non_null
     (global.get $global123)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global406)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global410)
   )
  )
  (drop
   (call $function182
    (local.get $4)
    (local.get $2)
    (global.get $empty62)
    (struct.get $type195 0
     (local.get $4)
    )
    (struct.new_default $type215)
    (ref.as_non_null
     (global.get $global123)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global452)
   )
  )
  (if
   (i32.eqz
    (global.get $ready123)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global456)
   )
  )
  (drop
   (call $function201
    (local.get $2)
    (local.get $4)
    (global.get $empty68)
    (struct.get $type197 0
     (local.get $2)
    )
    (struct.new_default $type217)
    (ref.as_non_null
     (global.get $global123)
    )
   )
  )
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 33)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global388)
     )
    )
    (if
     (i32.eqz
      (global.get $ready123)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global392)
     )
    )
    (return_call $function175
     (local.get $2)
     (local.get $2)
     (global.get $empty51)
     (struct.get $type197 0
      (local.get $2)
     )
     (struct.new_default $type213)
     (ref.as_non_null
      (global.get $global123)
     )
    )
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 44)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global500)
       )
      )
      (if
       (i32.eqz
        (global.get $ready123)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global504)
       )
      )
      (return_call $function222
       (local.get $3)
       (local.get $3)
       (global.get $empty74)
       (struct.get $type201 0
        (local.get $3)
       )
       (struct.new_default $type219)
       (ref.as_non_null
        (global.get $global123)
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $1)
        (i64.const 45)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global573)
         )
        )
        (local.set $5
         (call $function254
          (local.get $3)
          (local.get $3)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global631)
         )
        )
        (if
         (i32.eqz
          (global.get $ready123)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global635)
         )
        )
        (return_call $function283
         (local.get $3)
         (local.get $5)
         (global.get $empty85)
         (struct.get $type201 0
          (local.get $3)
         )
         (struct.new_default $type223)
         (ref.as_non_null
          (global.get $global123)
         )
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $1)
          (i64.const 54)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global573)
           )
          )
          (local.set $5
           (call $function254
            (local.get $3)
            (local.get $3)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global705)
           )
          )
          (if
           (i32.eqz
            (global.get $ready123)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global709)
           )
          )
          (local.set $10
           (ref.as_non_null
            (global.get $global123)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global276)
           )
          )
          (if (result i64)
           (if (result i32)
            (ref.test (ref $type56)
             (local.tee $8
              (struct.get $type203 0
               (local.get $5)
              )
             )
            )
            (then
             (i32.const 1)
            )
            (else
             (drop
              (ref.cast (ref $type57)
               (local.get $8)
              )
             )
             (i32.const 0)
            )
           )
           (then
            (i64.const 1)
           )
           (else
            (if
             (ref.test (ref $type56)
              (local.get $8)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global281)
             )
            )
            (return_call $function319
             (struct.new $environment319
              (local.get $5)
              (local.get $3)
              (global.get $empty91)
              (struct.new_default $type225)
              (local.get $10)
             )
             (struct.get $type57 0
              (local.tee $11
               (ref.cast (ref $type57)
                (local.get $8)
               )
              )
             )
             (struct.get $type58 0
              (struct.get $type57 1
               (local.get $11)
              )
             )
            )
           )
          )
         )
         (else
          (if
           (i64.eq
            (local.get $1)
            (i64.const 55)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global573)
             )
            )
            (local.set $5
             (call $function254
              (local.get $3)
              (local.get $3)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global753)
             )
            )
            (if
             (i32.eqz
              (global.get $ready123)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global757)
             )
            )
            (return_call $function339
             (local.get $5)
             (local.get $5)
             (global.get $empty97)
             (struct.get $type203 0
              (local.get $5)
             )
             (struct.new_default $type227)
             (ref.as_non_null
              (global.get $global123)
             )
            )
           )
           (else
            (unreachable)
           )
          )
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function48 (type $call157) (param $0 (ref null $environment359)) (param $1 i64) (param $2 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result i64)
     (i64.eqz
      (local.get $2)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $2)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (if (result i64)
       (i64.eqz
        (local.get $2)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (i64.const 1)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
  )
 )
 (func $function60 (type $214) (param $0 (ref $environment60)) (param $1 i64) (result (ref $type30))
  (local $2 (ref $type39))
  (local $3 (ref $type131))
  (local $4 (ref $type41))
  (local $5 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (if
   (i32.eqz
    (global.get $ready140)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (local.set $3
   (struct.get $environment60 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (local.set $5
   (if (result (ref $type28))
    (if (result i32)
     (ref.test (ref $type40)
      (local.tee $2
       (struct.get $type42 0
        (struct.get $type41 1
         (struct.get $environment60 1
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type41)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty29)
    )
    (else
     (if
      (ref.test (ref $type40)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function60
      (struct.new $environment60
       (local.get $3)
       (local.tee $4
        (ref.cast (ref $type41)
         (local.get $2)
        )
       )
      )
      (struct.get $type38 1
       (struct.get $type41 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (struct.new $type30
   (local.get $1)
   (struct.new $type31
    (local.get $5)
   )
  )
 )
 (func $function62 (type $call32) (param $0 (ref $type28)) (param $1 (ref $type33)) (result (ref $type35))
  (struct.new $type35
   (local.get $0)
   (struct.new $type36
    (local.get $1)
   )
  )
 )
 (func $function63 (type $call153) (param $0 (ref $type44)) (result (ref $type33))
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (return_call $function64
   (local.get $0)
  )
 )
 (func $function64 (type $call153) (param $0 (ref $type44)) (result (ref $type33))
  (local $1 (ref $type33))
  (local $2 (ref $type33))
  (local $3 (ref $type35))
  (local $4 (ref $type44))
  (local $5 (ref $type46))
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type28))
  (local $12 (ref $type28))
  (local $13 (ref $type28))
  (local $14 (ref $type28))
  (local $15 (ref $type28))
  (local $16 (ref $type28))
  (local $17 (ref $type28))
  (local $18 (ref $type28))
  (local $19 (ref $type28))
  (local $20 (ref $type28))
  (local $scratch (ref $type33))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result (ref $type33))
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty34)
   )
   (else
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (ref.test (ref $type45)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type33))
     (if (result i32)
      (ref.test (ref $type45)
       (local.tee $4
        (struct.get $type47 0
         (struct.get $type46 1
          (ref.cast (ref $type46)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (if
       (ref.test (ref $type45)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type46 0
       (ref.cast (ref $type46)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (ref.test (ref $type45)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type46 0
        (local.tee $5
         (ref.cast (ref $type46)
          (local.get $0)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (local.set $2
       (call $function64
        (struct.get $type47 0
         (struct.get $type46 1
          (local.get $5)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global164)
       )
      )
      (drop
       (struct.get $type103 1
        (global.get $global167)
       )
      )
      (if (result (ref $type33))
       (if (result i32)
        (ref.test (ref $type34)
         (local.get $1)
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (ref.test (ref $type34)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type35
         (struct.get $type35 0
          (local.tee $3
           (ref.cast (ref $type35)
            (local.get $1)
           )
          )
         )
         (block (result (ref (exact $type36)))
          (drop
           (ref.as_non_null
            (global.get $global172)
           )
          )
          (if
           (i32.eqz
            (global.get $ready164)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global164)
           )
          )
          (drop
           (struct.get $type103 1
            (global.get $global167)
           )
          )
          (if
           (i32.eqz
            (if (result i32)
             (ref.test (ref $type34)
              (local.tee $1
               (struct.get $type36 0
                (struct.get $type35 1
                 (local.get $3)
                )
               )
              )
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.cast (ref $type35)
                (local.get $1)
               )
              )
              (i32.const 0)
             )
            )
           )
           (then
            (if
             (ref.test (ref $type34)
              (local.get $1)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.new $type35
              (struct.get $type35 0
               (local.tee $3
                (ref.cast (ref $type35)
                 (local.get $1)
                )
               )
              )
              (block (result (ref (exact $type36)))
               (drop
                (ref.as_non_null
                 (global.get $global172)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready164)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global164)
                )
               )
               (drop
                (struct.get $type103 1
                 (global.get $global167)
                )
               )
               (if
                (i32.eqz
                 (if (result i32)
                  (ref.test (ref $type34)
                   (local.tee $1
                    (struct.get $type36 0
                     (struct.get $type35 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type35)
                     (local.get $1)
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
                (then
                 (if
                  (ref.test (ref $type34)
                   (local.get $1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.new $type35
                   (struct.get $type35 0
                    (local.tee $3
                     (ref.cast (ref $type35)
                      (local.get $1)
                     )
                    )
                   )
                   (block (result (ref (exact $type36)))
                    (drop
                     (ref.as_non_null
                      (global.get $global172)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready164)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global164)
                     )
                    )
                    (drop
                     (struct.get $type103 1
                      (global.get $global167)
                     )
                    )
                    (if
                     (i32.eqz
                      (if (result i32)
                       (ref.test (ref $type34)
                        (local.tee $1
                         (struct.get $type36 0
                          (struct.get $type35 1
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type35)
                          (local.get $1)
                         )
                        )
                        (i32.const 0)
                       )
                      )
                     )
                     (then
                      (if
                       (ref.test (ref $type34)
                        (local.get $1)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (struct.new $type35
                        (struct.get $type35 0
                         (local.tee $3
                          (ref.cast (ref $type35)
                           (local.get $1)
                          )
                         )
                        )
                        (block (result (ref (exact $type36)))
                         (drop
                          (ref.as_non_null
                           (global.get $global172)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready164)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global164)
                          )
                         )
                         (drop
                          (struct.get $type103 1
                           (global.get $global167)
                          )
                         )
                         (if
                          (i32.eqz
                           (if (result i32)
                            (ref.test (ref $type34)
                             (local.tee $1
                              (struct.get $type36 0
                               (struct.get $type35 1
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (then
                             (i32.const 1)
                            )
                            (else
                             (drop
                              (ref.cast (ref $type35)
                               (local.get $1)
                              )
                             )
                             (i32.const 0)
                            )
                           )
                          )
                          (then
                           (if
                            (ref.test (ref $type34)
                             (local.get $1)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (struct.new $type35
                             (struct.get $type35 0
                              (local.tee $3
                               (ref.cast (ref $type35)
                                (local.get $1)
                               )
                              )
                             )
                             (block (result (ref (exact $type36)))
                              (drop
                               (ref.as_non_null
                                (global.get $global172)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready164)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global164)
                               )
                              )
                              (drop
                               (struct.get $type103 1
                                (global.get $global167)
                               )
                              )
                              (if
                               (i32.eqz
                                (if (result i32)
                                 (ref.test (ref $type34)
                                  (local.tee $1
                                   (struct.get $type36 0
                                    (struct.get $type35 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.cast (ref $type35)
                                    (local.get $1)
                                   )
                                  )
                                  (i32.const 0)
                                 )
                                )
                               )
                               (then
                                (if
                                 (ref.test (ref $type34)
                                  (local.get $1)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (local.set $2
                                 (struct.new $type35
                                  (struct.get $type35 0
                                   (local.tee $3
                                    (ref.cast (ref $type35)
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (block (result (ref (exact $type36)))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global172)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready164)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global164)
                                    )
                                   )
                                   (drop
                                    (struct.get $type103 1
                                     (global.get $global167)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (if (result i32)
                                      (ref.test (ref $type34)
                                       (local.tee $1
                                        (struct.get $type36 0
                                         (struct.get $type35 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.cast (ref $type35)
                                         (local.get $1)
                                        )
                                       )
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                    (then
                                     (if
                                      (ref.test (ref $type34)
                                       (local.get $1)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (local.set $2
                                      (struct.new $type35
                                       (struct.get $type35 0
                                        (local.tee $3
                                         (ref.cast (ref $type35)
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (block (result (ref (exact $type36)))
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global172)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready164)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global164)
                                         )
                                        )
                                        (drop
                                         (struct.get $type103 1
                                          (global.get $global167)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (if (result i32)
                                           (ref.test (ref $type34)
                                            (local.tee $1
                                             (struct.get $type36 0
                                              (struct.get $type35 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i32.const 1)
                                           )
                                           (else
                                            (drop
                                             (ref.cast (ref $type35)
                                              (local.get $1)
                                             )
                                            )
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                         (then
                                          (if
                                           (ref.test (ref $type34)
                                            (local.get $1)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $2
                                           (struct.new $type35
                                            (struct.get $type35 0
                                             (local.tee $3
                                              (ref.cast (ref $type35)
                                               (local.get $1)
                                              )
                                             )
                                            )
                                            (block (result (ref (exact $type36)))
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global172)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready164)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global164)
                                              )
                                             )
                                             (drop
                                              (struct.get $type103 1
                                               (global.get $global167)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (if (result i32)
                                                (ref.test (ref $type34)
                                                 (local.tee $1
                                                  (struct.get $type36 0
                                                   (struct.get $type35 1
                                                    (local.get $3)
                                                   )
                                                  )
                                                 )
                                                )
                                                (then
                                                 (i32.const 1)
                                                )
                                                (else
                                                 (drop
                                                  (ref.cast (ref $type35)
                                                   (local.get $1)
                                                  )
                                                 )
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (if
                                                (ref.test (ref $type34)
                                                 (local.get $1)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (local.set $2
                                                (struct.new $type35
                                                 (struct.get $type35 0
                                                  (local.tee $3
                                                   (ref.cast (ref $type35)
                                                    (local.get $1)
                                                   )
                                                  )
                                                 )
                                                 (block (result (ref (exact $type36)))
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global172)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready164)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global164)
                                                   )
                                                  )
                                                  (drop
                                                   (struct.get $type103 1
                                                    (global.get $global167)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (if (result i32)
                                                     (ref.test (ref $type34)
                                                      (local.tee $1
                                                       (struct.get $type36 0
                                                        (struct.get $type35 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (i32.const 1)
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.cast (ref $type35)
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (i32.const 0)
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (if
                                                     (ref.test (ref $type34)
                                                      (local.get $1)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (local.set $2
                                                     (struct.new $type35
                                                      (struct.get $type35 0
                                                       (local.tee $3
                                                        (ref.cast (ref $type35)
                                                         (local.get $1)
                                                        )
                                                       )
                                                      )
                                                      (block (result (ref (exact $type36)))
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global172)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready164)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global164)
                                                        )
                                                       )
                                                       (drop
                                                        (struct.get $type103 1
                                                         (global.get $global167)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (if (result i32)
                                                          (ref.test (ref $type34)
                                                           (local.tee $1
                                                            (struct.get $type36 0
                                                             (struct.get $type35 1
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (then
                                                           (i32.const 1)
                                                          )
                                                          (else
                                                           (drop
                                                            (ref.cast (ref $type35)
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (i32.const 0)
                                                          )
                                                         )
                                                        )
                                                        (then
                                                         (if
                                                          (ref.test (ref $type34)
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.new $type35
                                                           (struct.get $type35 0
                                                            (local.tee $3
                                                             (ref.cast (ref $type35)
                                                              (local.get $1)
                                                             )
                                                            )
                                                           )
                                                           (block (result (ref (exact $type36)))
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global172)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (global.get $ready164)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global164)
                                                             )
                                                            )
                                                            (drop
                                                             (struct.get $type103 1
                                                              (global.get $global167)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (if (result i32)
                                                               (ref.test (ref $type34)
                                                                (local.tee $1
                                                                 (struct.get $type36 0
                                                                  (struct.get $type35 1
                                                                   (local.get $3)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                               (then
                                                                (i32.const 1)
                                                               )
                                                               (else
                                                                (drop
                                                                 (ref.cast (ref $type35)
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                             (then
                                                              (if
                                                               (ref.test (ref $type34)
                                                                (local.get $1)
                                                               )
                                                               (then
                                                                (unreachable)
                                                               )
                                                              )
                                                              (local.set $2
                                                               (struct.new $type35
                                                                (struct.get $type35 0
                                                                 (local.tee $3
                                                                  (ref.cast (ref $type35)
                                                                   (local.get $1)
                                                                  )
                                                                 )
                                                                )
                                                                (block (result (ref (exact $type36)))
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global172)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (global.get $ready164)
                                                                  )
                                                                  (then
                                                                   (unreachable)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global164)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (struct.get $type103 1
                                                                   (global.get $global167)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (if (result i32)
                                                                    (ref.test (ref $type34)
                                                                     (local.tee $1
                                                                      (struct.get $type36 0
                                                                       (struct.get $type35 1
                                                                        (local.get $3)
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                    (then
                                                                     (i32.const 1)
                                                                    )
                                                                    (else
                                                                     (drop
                                                                      (ref.cast (ref $type35)
                                                                       (local.get $1)
                                                                      )
                                                                     )
                                                                     (i32.const 0)
                                                                    )
                                                                   )
                                                                  )
                                                                  (then
                                                                   (if
                                                                    (ref.test (ref $type34)
                                                                     (local.get $1)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (local.set $2
                                                                    (struct.new $type35
                                                                     (struct.get $type35 0
                                                                      (local.tee $3
                                                                       (ref.cast (ref $type35)
                                                                        (local.get $1)
                                                                       )
                                                                      )
                                                                     )
                                                                     (block (result (ref (exact $type36)))
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global172)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (global.get $ready164)
                                                                       )
                                                                       (then
                                                                        (unreachable)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global164)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (struct.get $type103 1
                                                                        (global.get $global167)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (if (result i32)
                                                                         (ref.test (ref $type34)
                                                                          (local.tee $1
                                                                           (struct.get $type36 0
                                                                            (struct.get $type35 1
                                                                             (local.get $3)
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                         (then
                                                                          (i32.const 1)
                                                                         )
                                                                         (else
                                                                          (drop
                                                                           (ref.cast (ref $type35)
                                                                            (local.get $1)
                                                                           )
                                                                          )
                                                                          (i32.const 0)
                                                                         )
                                                                        )
                                                                       )
                                                                       (then
                                                                        (if
                                                                         (ref.test (ref $type34)
                                                                          (local.get $1)
                                                                         )
                                                                         (then
                                                                          (unreachable)
                                                                         )
                                                                        )
                                                                        (local.set $2
                                                                         (struct.new $type35
                                                                          (struct.get $type35 0
                                                                           (local.tee $3
                                                                            (ref.cast (ref $type35)
                                                                             (local.get $1)
                                                                            )
                                                                           )
                                                                          )
                                                                          (block (result (ref (exact $type36)))
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global172)
                                                                            )
                                                                           )
                                                                           (local.set $1
                                                                            (struct.get $type36 0
                                                                             (struct.get $type35 1
                                                                              (local.get $3)
                                                                             )
                                                                            )
                                                                           )
                                                                           (if
                                                                            (i32.eqz
                                                                             (global.get $ready164)
                                                                            )
                                                                            (then
                                                                             (unreachable)
                                                                            )
                                                                           )
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global164)
                                                                            )
                                                                           )
                                                                           (if
                                                                            (i32.eqz
                                                                             (call $function68
                                                                              (struct.get $type103 1
                                                                               (global.get $global167)
                                                                              )
                                                                              (local.get $1)
                                                                             )
                                                                            )
                                                                            (then
                                                                             (if
                                                                              (ref.test (ref $type34)
                                                                               (local.get $1)
                                                                              )
                                                                              (then
                                                                               (unreachable)
                                                                              )
                                                                             )
                                                                             (local.set $2
                                                                              (call $function62
                                                                               (struct.get $type35 0
                                                                                (local.tee $3
                                                                                 (ref.cast (ref $type35)
                                                                                  (local.get $1)
                                                                                 )
                                                                                )
                                                                               )
                                                                               (block (result (ref $type33))
                                                                                (drop
                                                                                 (ref.as_non_null
                                                                                  (global.get $global172)
                                                                                 )
                                                                                )
                                                                                (local.set $scratch
                                                                                 (call $function67
                                                                                  (call $function69
                                                                                   (local.get $3)
                                                                                  )
                                                                                  (block (result (ref $type33))
                                                                                   (if
                                                                                    (i32.eqz
                                                                                     (global.get $ready164)
                                                                                    )
                                                                                    (then
                                                                                     (unreachable)
                                                                                    )
                                                                                   )
                                                                                   (drop
                                                                                    (ref.as_non_null
                                                                                     (global.get $global164)
                                                                                    )
                                                                                   )
                                                                                   (local.get $2)
                                                                                  )
                                                                                 )
                                                                                )
                                                                                (drop
                                                                                 (ref.as_non_null
                                                                                  (global.get $global151)
                                                                                 )
                                                                                )
                                                                                (local.get $scratch)
                                                                               )
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global151)
                                                                            )
                                                                           )
                                                                           (struct.new $type36
                                                                            (local.get $2)
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global151)
                                                                       )
                                                                      )
                                                                      (struct.new $type36
                                                                       (local.get $2)
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global151)
                                                                  )
                                                                 )
                                                                 (struct.new $type36
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global151)
                                                             )
                                                            )
                                                            (struct.new $type36
                                                             (local.get $2)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global151)
                                                        )
                                                       )
                                                       (struct.new $type36
                                                        (local.get $2)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global151)
                                                   )
                                                  )
                                                  (struct.new $type36
                                                   (local.get $2)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global151)
                                              )
                                             )
                                             (struct.new $type36
                                              (local.get $2)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global151)
                                         )
                                        )
                                        (struct.new $type36
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global151)
                                    )
                                   )
                                   (struct.new $type36
                                    (local.get $2)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global151)
                               )
                              )
                              (struct.new $type36
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global151)
                          )
                         )
                         (struct.new $type36
                          (local.get $2)
                         )
                        )
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global151)
                     )
                    )
                    (struct.new $type36
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global151)
                )
               )
               (struct.new $type36
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global151)
           )
          )
          (struct.new $type36
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (if (result i32)
   (ref.test (ref $type45)
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.cast (ref $type46)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function66 (type $201) (param $0 (ref $type46)) (result (ref $type44))
  (struct.get $type47 0
   (struct.get $type46 1
    (local.get $0)
   )
  )
 )
 (func $function67 (type $200) (param $0 (ref $type33)) (param $1 (ref $type33)) (result (ref $type33))
  (local $2 (ref $type35))
  (local $3 (ref $type28))
  (local $scratch (ref $type33))
  (if (result (ref $type33))
   (call $function68
    (struct.get $type103 1
     (global.get $global167)
    )
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function62
     (struct.get $type35 0
      (local.tee $2
       (ref.cast (ref $type35)
        (local.get $0)
       )
      )
     )
     (block (result (ref $type33))
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (local.set $scratch
       (call $function67
        (call $function69
         (local.get $2)
        )
        (block (result (ref $type33))
         (if
          (i32.eqz
           (global.get $ready164)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global164)
          )
         )
         (local.get $1)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function68 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (if (result i32)
   (ref.test (ref $type34)
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.cast (ref $type35)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function69 (type $198) (param $0 (ref $type35)) (result (ref $type33))
  (struct.get $type36 0
   (struct.get $type35 1
    (local.get $0)
   )
  )
 )
 (func $function71 (type $197) (param $0 (ref $environment71)) (param $1 i64) (param $2 (ref $type28)) (result (ref $type33))
  (local $3 (ref $type28))
  (local $4 (ref $type195))
  (local $5 (ref $type195))
  (local $6 (ref $type133))
  (local $7 (ref $type39))
  (local $8 (ref $type153))
  (local $9 (ref $type30))
  (drop
   (ref.as_non_null
    (global.get $global187)
   )
  )
  (local.set $3
   (call $function75
    (struct.new $environment75
     (local.tee $4
      (struct.get $environment71 1
       (local.get $0)
      )
     )
     (local.tee $7
      (struct.get $environment71 2
       (local.get $0)
      )
     )
     (local.get $1)
    )
    (struct.get $type195 1
     (local.tee $5
      (struct.get $environment71 0
       (local.get $0)
      )
     )
    )
    (struct.get $type195 1
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global231)
   )
  )
  (local.set $6
   (struct.new $type133
    (struct.new $environment72
     (local.get $5)
     (local.get $4)
     (local.get $7)
     (struct.get $environment71 3
      (local.get $0)
     )
     (local.tee $8
      (struct.get $environment71 4
       (local.get $0)
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (return_call_ref $call153
   (if (result (ref $type44))
    (if (result i32)
     (ref.test (ref $type29)
      (local.get $3)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $3)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty45)
    )
    (else
     (if
      (ref.test (ref $type29)
       (local.get $3)
      )
      (then
       (unreachable)
      )
     )
     (call $function98
      (struct.new $environment98
       (local.get $6)
       (local.tee $9
        (ref.cast (ref $type30)
         (local.get $3)
        )
       )
      )
      (call $function72
       (struct.get $type133 0
        (local.get $6)
       )
       (struct.get $type30 0
        (local.get $9)
       )
      )
     )
    )
   )
   (struct.get $type153 0
    (local.get $8)
   )
  )
 )
 (func $function72 (type $call133) (param $0 (ref $environment72)) (param $1 i64) (result (ref $type33))
  (local $2 (ref $type41))
  (local $3 (ref $type28))
  (local $4 (ref $type30))
  (local $5 (ref $type30))
  (drop
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (if
   (i32.eqz
    (global.get $ready174)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global174)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (local.set $2
   (struct.new $type41
    (struct.new $type38
     (struct.get $environment72 5
      (local.get $0)
     )
     (local.get $1)
    )
    (struct.new $type42
     (struct.get $environment72 2
      (local.get $0)
     )
    )
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (ref.test (ref $type29)
     (local.tee $3
      (struct.get $environment72 6
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global143)
     )
    )
    (struct.new $type35
     (call $function60
      (struct.new $environment60
       (struct.new_default $type131)
       (local.get $2)
      )
      (struct.get $type38 1
       (struct.get $type41 0
        (local.get $2)
       )
      )
     )
     (block (result (ref (exact $type36)))
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (struct.new $type36
       (global.get $empty34)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (return_call $function71
     (struct.new $environment71
      (struct.get $environment72 0
       (local.get $0)
      )
      (struct.get $environment72 1
       (local.get $0)
      )
      (local.get $2)
      (struct.get $environment72 3
       (local.get $0)
      )
      (struct.get $environment72 4
       (local.get $0)
      )
     )
     (struct.get $type30 0
      (local.tee $5
       (ref.cast (ref $type30)
        (local.get $3)
       )
      )
     )
     (struct.get $type31 0
      (struct.get $type30 1
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function75 (type $191) (param $0 (ref $environment75)) (param $1 (ref $type157)) (param $2 (ref $type157)) (result (ref $type28))
  (local $3 i64)
  (local $4 (ref $type39))
  (local $5 (ref $type28))
  (local $6 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (local.set $5
   (call $function78
    (struct.new $type170
     (ref.func $function76)
     (struct.new $environment76
      (local.tee $3
       (struct.get $environment75 2
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (struct.new_default $type131)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty29)
    (local.tee $4
     (struct.get $environment75 1
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (local.set $6
   (call $function78
    (struct.new $type170
     (ref.func $function85)
     (struct.new $environment85
      (local.get $3)
      (local.get $1)
     )
    )
    (struct.new_default $type131)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty29)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global224)
   )
  )
  (return_call $function95
   (struct.new $type165
    (ref.func $function87)
    (struct.new $environment87
     (local.get $2)
     (local.get $5)
     (local.get $6)
    )
   )
   (i32.const 0)
   (i32.const 1)
   (global.get $empty29)
   (struct.get $type195 0
    (struct.get $environment75 0
     (local.get $0)
    )
   )
  )
 )
 (func $function76 (type $call170) (param $0 (ref struct)) (param $1 (ref $type38)) (result i32)
  (local $2 (ref $environment76))
  (local $3 (ref $type157))
  (i64.eqz
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment76 1
       (local.tee $2
        (ref.cast (ref $environment76)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $type38 0
     (local.get $1)
    )
    (struct.get $environment76 0
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
  )
 )
 (func $function78 (type $184) (param $0 (ref $type170)) (param $1 (ref $type131)) (param $2 i32) (param $3 i32) (param $4 (ref $type28)) (param $5 (ref $type39)) (result (ref $type28))
  (local $6 (ref $type30))
  (local $7 (ref $type38))
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (ref.test (ref $type40)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type41)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result (ref $type29))
     (if (result i32)
      (ref.test (ref $type29)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty29)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (struct.new $environment82
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type30)
          (local.get $4)
         )
        )
        (global.get $empty29)
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type40)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call170
      (struct.get $type170 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type41 0
        (ref.cast (ref $type41)
         (local.get $5)
        )
       )
      )
      (struct.get $type170 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (local.set $4
       (struct.new $type30
        (struct.get $type38 1
         (local.get $7)
        )
        (struct.new $type31
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global149)
     )
    )
    (if
     (ref.test (ref $type40)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type42 0
      (struct.get $type41 1
       (ref.cast (ref $type41)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function78
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function82 (type $181) (param $0 (ref $environment82)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type30))
  (drop
   (ref.as_non_null
    (global.get $global208)
   )
  )
  (local.set $2
   (struct.get $environment82 1
    (local.get $0)
   )
  )
  (struct.set $type31 0
   (struct.get $type30 1
    (local.get $2)
   )
   (struct.get $environment82 2
    (local.get $0)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result (ref $type30))
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function82
     (struct.new $environment82
      (struct.get $environment82 0
       (local.get $0)
      )
      (local.tee $2
       (ref.cast (ref $type30)
        (local.get $1)
       )
      )
      (struct.get $environment82 1
       (local.get $0)
      )
     )
     (struct.get $type31 0
      (struct.get $type30 1
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function85 (type $call170) (param $0 (ref struct)) (param $1 (ref $type38)) (result i32)
  (local $2 (ref $environment85))
  (local $3 (ref $type157))
  (i64.eq
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment85 1
       (local.tee $2
        (ref.cast (ref $environment85)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $type38 0
     (local.get $1)
    )
    (struct.get $environment85 0
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (i64.const 2)
  )
 )
 (func $function87 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment87))
  (local $4 (ref $type30))
  (local $5 (ref $type165))
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (local.set $5
   (struct.new $type165
    (ref.func $function88)
    (struct.new $environment88
     (struct.get $environment87 0
      (local.tee $3
       (ref.cast (ref $environment87)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type29)
      (local.tee $2
       (struct.get $environment87 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global115)
      )
     )
     (if
      (ref.test (ref $type29)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function92
      (struct.new $environment92
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
      )
      (struct.get $type31 0
       (struct.get $type30 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global217)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type29)
       (local.tee $2
        (struct.get $environment87 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function92
       (struct.new $environment92
        (struct.new $type165
         (ref.func $function93)
         (struct.new $environment93
          (struct.get $environment87 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type30)
          (local.get $2)
         )
        )
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function88 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment88))
  (local $3 (ref $type157))
  (return_call $function41
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment88 0
       (local.tee $2
        (ref.cast (ref $environment88)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment88 1
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function92 (type $176) (param $0 (ref $environment92)) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $type30))
  (local $3 (ref $type165))
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $2
     (struct.get $environment92 2
      (local.get $0)
     )
    )
    (return_call_ref $call165
     (struct.get $type165 1
      (local.tee $3
       (struct.get $environment92 0
        (local.get $0)
       )
      )
     )
     (struct.get $type30 0
      (local.get $2)
     )
     (struct.get $type165 0
      (local.get $3)
     )
    )
   )
   (else
    (local.set $2
     (struct.get $environment92 2
      (local.get $0)
     )
    )
    (if (result i32)
     (call_ref $call165
      (struct.get $type165 1
       (local.tee $3
        (struct.get $environment92 0
         (local.get $0)
        )
       )
      )
      (struct.get $type30 0
       (local.get $2)
      )
      (struct.get $type165 0
       (local.get $3)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function92
       (struct.new $environment92
        (struct.get $environment92 0
         (local.get $0)
        )
        (struct.get $environment92 1
         (local.get $0)
        )
        (local.tee $2
         (ref.cast (ref $type30)
          (local.get $1)
         )
        )
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $2)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function93 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment93))
  (local $3 (ref $type157))
  (return_call $function41
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment93 0
       (local.tee $2
        (ref.cast (ref $environment93)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment93 1
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function95 (type $175) (param $0 (ref $type165)) (param $1 i32) (param $2 i32) (param $3 (ref $type28)) (param $4 (ref $type28)) (result (ref $type28))
  (local $5 (ref $type30))
  (local $6 i64)
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready202)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result (ref $type29))
     (if (result i32)
      (ref.test (ref $type29)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty29)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (struct.new $environment82
        (struct.new_default $type248)
        (local.tee $5
         (ref.cast (ref $type30)
          (local.get $3)
         )
        )
        (global.get $empty29)
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call165
      (struct.get $type165 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type30 0
        (ref.cast (ref $type30)
         (local.get $4)
        )
       )
      )
      (struct.get $type165 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (local.set $3
       (struct.new $type30
        (local.get $6)
        (struct.new $type31
         (local.get $3)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type29)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type31 0
      (struct.get $type30 1
       (ref.cast (ref $type30)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function95
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function98 (type $174) (param $0 (ref $environment98)) (param $1 (ref $type33)) (result (ref $type46))
  (local $2 (ref $type28))
  (local $3 (ref $type133))
  (local $4 (ref $type30))
  (local $5 (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (if
   (i32.eqz
    (global.get $ready231)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $environment98 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global231)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (local.set $5
   (if (result (ref $type44))
    (if (result i32)
     (ref.test (ref $type29)
      (local.tee $2
       (struct.get $type31 0
        (struct.get $type30 1
         (struct.get $environment98 1
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty45)
    )
    (else
     (if
      (ref.test (ref $type29)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function98
      (struct.new $environment98
       (local.get $3)
       (local.tee $4
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
      )
      (call $function72
       (struct.get $type133 0
        (local.get $3)
       )
       (struct.get $type30 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (struct.new $type46
   (local.get $1)
   (struct.new $type47
    (local.get $5)
   )
  )
 )
 (func $function99 (type $call43) (param $0 (ref $type33)) (param $1 (ref $type44)) (result (ref $type46))
  (struct.new $type46
   (local.get $0)
   (struct.new $type47
    (local.get $1)
   )
  )
 )
 (func $function103 (type $172) (param $0 (ref $environment103)) (param $1 i64) (result i64)
  (local $2 (ref $type28))
  (local $3 (ref $type28))
  (local $4 (ref $type157))
  (local $5 (ref $type30))
  (local $6 i32)
  (local $7 i64)
  (if (result i64)
   (select
    (local.tee $6
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.eq
     (struct.get $environment103 1
      (local.get $0)
     )
     (local.get $1)
    )
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (if
     (ref.test (ref $type29)
      (local.tee $2
       (struct.get $environment103 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (local.set $1
     (struct.get $environment103 1
      (local.get $0)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result i64)
     (if (result i32)
      (ref.test (ref $type29)
       (local.tee $2
        (struct.get $type31 0
         (struct.get $type30 1
          (ref.cast (ref $type30)
           (local.get $2)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $3
       (struct.get $type31 0
        (struct.get $type30 1
         (struct.get $environment103 4
          (local.get $0)
         )
        )
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (struct.get $type30 0
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function103
       (struct.new $environment103
        (local.tee $4
         (struct.get $environment103 0
          (local.get $0)
         )
        )
        (local.get $1)
        (struct.get $environment103 2
         (local.get $0)
        )
        (local.get $2)
        (local.tee $5
         (ref.cast (ref $type30)
          (local.get $3)
         )
        )
       )
       (call_ref $call157
        (struct.get $type157 1
         (local.get $4)
        )
        (local.get $7)
        (struct.get $type30 0
         (local.get $5)
        )
        (struct.get $type157 0
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 3)
   )
  )
 )
 (func $function105 (type $call159) (param $0 (ref $environment105)) (param $1 (ref $type28)) (param $2 (ref $type28)) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type157))
  (local $7 (ref $type30))
  (local $8 (ref $type248))
  (local $9 (ref $type250))
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type30 0
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
    )
    (if
     (ref.test (ref $type29)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (select
      (local.tee $5
       (i64.eqz
        (local.tee $3
         (call_ref $call157
          (struct.get $type157 1
           (local.tee $6
            (struct.get $environment105 0
             (local.get $0)
            )
           )
          )
          (local.get $3)
          (struct.get $type30 0
           (local.tee $7
            (ref.cast (ref $type30)
             (local.get $2)
            )
           )
          )
          (struct.get $type157 0
           (local.get $6)
          )
         )
        )
       )
      )
      (i64.eq
       (local.get $3)
       (i64.const 2)
      )
      (local.get $5)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (drop
       (struct.get $type100 1
        (global.get $global109)
       )
      )
      (if (result i64)
       (if (result i32)
        (ref.test (ref $type29)
         (local.tee $1
          (struct.get $type31 0
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $1)
            )
           )
          )
         )
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type30)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $8
         (struct.new_default $type248)
        )
        (if
         (ref.test (ref $type29)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (struct.get $type30 0
          (ref.cast (ref $type30)
           (local.get $1)
          )
         )
        )
        (if
         (ref.test (ref $type29)
          (local.tee $2
           (struct.get $type31 0
            (struct.get $type30 1
             (local.get $7)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function103
         (struct.new $environment103
          (local.get $6)
          (local.get $3)
          (local.get $8)
          (local.get $1)
          (local.tee $7
           (ref.cast (ref $type30)
            (local.get $2)
           )
          )
         )
         (call_ref $call157
          (struct.get $type157 1
           (local.get $6)
          )
          (local.get $4)
          (struct.get $type30 0
           (local.get $7)
          )
          (struct.get $type157 0
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global115)
         )
        )
        (if
         (ref.test (ref $type29)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type31 0
          (struct.get $type30 1
           (ref.cast (ref $type30)
            (local.get $1)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global115)
         )
        )
        (if
         (i32.eqz
          (struct.get $type250 0
           (local.tee $9
            (struct.get $environment105 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function105
         (struct.get $type159 0
          (struct.get $type250 1
           (local.get $9)
          )
         )
         (local.get $1)
         (struct.get $type31 0
          (struct.get $type30 1
           (local.get $7)
          )
         )
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function116 (type $169) (param $0 (ref $environment116)) (param $1 (ref $type28)) (result (ref $type35))
  (local $2 (ref $type50))
  (local $3 (ref $type135))
  (local $4 (ref $type52))
  (local $5 (ref $type33))
  (drop
   (ref.as_non_null
    (global.get $global271)
   )
  )
  (if
   (i32.eqz
    (global.get $ready262)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global262)
   )
  )
  (local.set $3
   (struct.get $environment116 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (local.set $5
   (if (result (ref $type33))
    (if (result i32)
     (ref.test (ref $type51)
      (local.tee $2
       (struct.get $type53 0
        (struct.get $type52 1
         (struct.get $environment116 1
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type52)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty34)
    )
    (else
     (if
      (ref.test (ref $type51)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function116
      (struct.new $environment116
       (local.get $3)
       (local.tee $4
        (ref.cast (ref $type52)
         (local.get $2)
        )
       )
      )
      (struct.get $type49 1
       (struct.get $type52 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (struct.new $type35
   (local.get $1)
   (struct.new $type36
    (local.get $5)
   )
  )
 )
 (func $function118 (type $call154) (param $0 (ref $type55)) (result (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global274)
   )
  )
  (return_call $function119
   (local.get $0)
  )
 )
 (func $function119 (type $call154) (param $0 (ref $type55)) (result (ref $type44))
  (local $1 (ref $type44))
  (local $2 (ref $type44))
  (local $3 (ref $type46))
  (local $4 (ref $type55))
  (local $5 (ref $type57))
  (local $6 (ref $type33))
  (local $7 (ref $type33))
  (local $8 (ref $type33))
  (local $9 (ref $type33))
  (local $10 (ref $type33))
  (local $11 (ref $type33))
  (local $12 (ref $type33))
  (local $13 (ref $type33))
  (local $14 (ref $type33))
  (local $15 (ref $type33))
  (local $16 (ref $type33))
  (local $17 (ref $type33))
  (local $18 (ref $type33))
  (local $19 (ref $type33))
  (local $20 (ref $type33))
  (local $scratch (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result (ref $type44))
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty45)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (if
     (ref.test (ref $type56)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type44))
     (if (result i32)
      (ref.test (ref $type56)
       (local.tee $4
        (struct.get $type58 0
         (struct.get $type57 1
          (ref.cast (ref $type57)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (if
       (ref.test (ref $type56)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type57 0
       (ref.cast (ref $type57)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (ref.test (ref $type56)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type57 0
        (local.tee $5
         (ref.cast (ref $type57)
          (local.get $0)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (i32.eqz
        (global.get $ready274)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global274)
       )
      )
      (local.set $2
       (call $function119
        (struct.get $type58 0
         (struct.get $type57 1
          (local.get $5)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global283)
       )
      )
      (drop
       (struct.get $type102 1
        (global.get $global157)
       )
      )
      (if (result (ref $type44))
       (if (result i32)
        (ref.test (ref $type45)
         (local.get $1)
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type46)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (ref.test (ref $type45)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type46
         (struct.get $type46 0
          (local.tee $3
           (ref.cast (ref $type46)
            (local.get $1)
           )
          )
         )
         (block (result (ref (exact $type47)))
          (drop
           (ref.as_non_null
            (global.get $global162)
           )
          )
          (if
           (i32.eqz
            (global.get $ready283)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global283)
           )
          )
          (drop
           (struct.get $type102 1
            (global.get $global157)
           )
          )
          (if
           (i32.eqz
            (if (result i32)
             (ref.test (ref $type45)
              (local.tee $1
               (struct.get $type47 0
                (struct.get $type46 1
                 (local.get $3)
                )
               )
              )
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.cast (ref $type46)
                (local.get $1)
               )
              )
              (i32.const 0)
             )
            )
           )
           (then
            (if
             (ref.test (ref $type45)
              (local.get $1)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.new $type46
              (struct.get $type46 0
               (local.tee $3
                (ref.cast (ref $type46)
                 (local.get $1)
                )
               )
              )
              (block (result (ref (exact $type47)))
               (drop
                (ref.as_non_null
                 (global.get $global162)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready283)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global283)
                )
               )
               (drop
                (struct.get $type102 1
                 (global.get $global157)
                )
               )
               (if
                (i32.eqz
                 (if (result i32)
                  (ref.test (ref $type45)
                   (local.tee $1
                    (struct.get $type47 0
                     (struct.get $type46 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type46)
                     (local.get $1)
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
                (then
                 (if
                  (ref.test (ref $type45)
                   (local.get $1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.new $type46
                   (struct.get $type46 0
                    (local.tee $3
                     (ref.cast (ref $type46)
                      (local.get $1)
                     )
                    )
                   )
                   (block (result (ref (exact $type47)))
                    (drop
                     (ref.as_non_null
                      (global.get $global162)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready283)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global283)
                     )
                    )
                    (drop
                     (struct.get $type102 1
                      (global.get $global157)
                     )
                    )
                    (if
                     (i32.eqz
                      (if (result i32)
                       (ref.test (ref $type45)
                        (local.tee $1
                         (struct.get $type47 0
                          (struct.get $type46 1
                           (local.get $3)
                          )
                         )
                        )
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type46)
                          (local.get $1)
                         )
                        )
                        (i32.const 0)
                       )
                      )
                     )
                     (then
                      (if
                       (ref.test (ref $type45)
                        (local.get $1)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $2
                       (struct.new $type46
                        (struct.get $type46 0
                         (local.tee $3
                          (ref.cast (ref $type46)
                           (local.get $1)
                          )
                         )
                        )
                        (block (result (ref (exact $type47)))
                         (drop
                          (ref.as_non_null
                           (global.get $global162)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready283)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global283)
                          )
                         )
                         (drop
                          (struct.get $type102 1
                           (global.get $global157)
                          )
                         )
                         (if
                          (i32.eqz
                           (if (result i32)
                            (ref.test (ref $type45)
                             (local.tee $1
                              (struct.get $type47 0
                               (struct.get $type46 1
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (then
                             (i32.const 1)
                            )
                            (else
                             (drop
                              (ref.cast (ref $type46)
                               (local.get $1)
                              )
                             )
                             (i32.const 0)
                            )
                           )
                          )
                          (then
                           (if
                            (ref.test (ref $type45)
                             (local.get $1)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (struct.new $type46
                             (struct.get $type46 0
                              (local.tee $3
                               (ref.cast (ref $type46)
                                (local.get $1)
                               )
                              )
                             )
                             (block (result (ref (exact $type47)))
                              (drop
                               (ref.as_non_null
                                (global.get $global162)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready283)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global283)
                               )
                              )
                              (drop
                               (struct.get $type102 1
                                (global.get $global157)
                               )
                              )
                              (if
                               (i32.eqz
                                (if (result i32)
                                 (ref.test (ref $type45)
                                  (local.tee $1
                                   (struct.get $type47 0
                                    (struct.get $type46 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.cast (ref $type46)
                                    (local.get $1)
                                   )
                                  )
                                  (i32.const 0)
                                 )
                                )
                               )
                               (then
                                (if
                                 (ref.test (ref $type45)
                                  (local.get $1)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (local.set $2
                                 (struct.new $type46
                                  (struct.get $type46 0
                                   (local.tee $3
                                    (ref.cast (ref $type46)
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (block (result (ref (exact $type47)))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global162)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready283)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global283)
                                    )
                                   )
                                   (drop
                                    (struct.get $type102 1
                                     (global.get $global157)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (if (result i32)
                                      (ref.test (ref $type45)
                                       (local.tee $1
                                        (struct.get $type47 0
                                         (struct.get $type46 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.cast (ref $type46)
                                         (local.get $1)
                                        )
                                       )
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                    (then
                                     (if
                                      (ref.test (ref $type45)
                                       (local.get $1)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (local.set $2
                                      (struct.new $type46
                                       (struct.get $type46 0
                                        (local.tee $3
                                         (ref.cast (ref $type46)
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (block (result (ref (exact $type47)))
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global162)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready283)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global283)
                                         )
                                        )
                                        (drop
                                         (struct.get $type102 1
                                          (global.get $global157)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (if (result i32)
                                           (ref.test (ref $type45)
                                            (local.tee $1
                                             (struct.get $type47 0
                                              (struct.get $type46 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i32.const 1)
                                           )
                                           (else
                                            (drop
                                             (ref.cast (ref $type46)
                                              (local.get $1)
                                             )
                                            )
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                         (then
                                          (if
                                           (ref.test (ref $type45)
                                            (local.get $1)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (local.set $2
                                           (struct.new $type46
                                            (struct.get $type46 0
                                             (local.tee $3
                                              (ref.cast (ref $type46)
                                               (local.get $1)
                                              )
                                             )
                                            )
                                            (block (result (ref (exact $type47)))
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global162)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready283)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global283)
                                              )
                                             )
                                             (drop
                                              (struct.get $type102 1
                                               (global.get $global157)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (if (result i32)
                                                (ref.test (ref $type45)
                                                 (local.tee $1
                                                  (struct.get $type47 0
                                                   (struct.get $type46 1
                                                    (local.get $3)
                                                   )
                                                  )
                                                 )
                                                )
                                                (then
                                                 (i32.const 1)
                                                )
                                                (else
                                                 (drop
                                                  (ref.cast (ref $type46)
                                                   (local.get $1)
                                                  )
                                                 )
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (if
                                                (ref.test (ref $type45)
                                                 (local.get $1)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (local.set $2
                                                (struct.new $type46
                                                 (struct.get $type46 0
                                                  (local.tee $3
                                                   (ref.cast (ref $type46)
                                                    (local.get $1)
                                                   )
                                                  )
                                                 )
                                                 (block (result (ref (exact $type47)))
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global162)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready283)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global283)
                                                   )
                                                  )
                                                  (drop
                                                   (struct.get $type102 1
                                                    (global.get $global157)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (if (result i32)
                                                     (ref.test (ref $type45)
                                                      (local.tee $1
                                                       (struct.get $type47 0
                                                        (struct.get $type46 1
                                                         (local.get $3)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (then
                                                      (i32.const 1)
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.cast (ref $type46)
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (i32.const 0)
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (if
                                                     (ref.test (ref $type45)
                                                      (local.get $1)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (local.set $2
                                                     (struct.new $type46
                                                      (struct.get $type46 0
                                                       (local.tee $3
                                                        (ref.cast (ref $type46)
                                                         (local.get $1)
                                                        )
                                                       )
                                                      )
                                                      (block (result (ref (exact $type47)))
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global162)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (global.get $ready283)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global283)
                                                        )
                                                       )
                                                       (drop
                                                        (struct.get $type102 1
                                                         (global.get $global157)
                                                        )
                                                       )
                                                       (if
                                                        (i32.eqz
                                                         (if (result i32)
                                                          (ref.test (ref $type45)
                                                           (local.tee $1
                                                            (struct.get $type47 0
                                                             (struct.get $type46 1
                                                              (local.get $3)
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (then
                                                           (i32.const 1)
                                                          )
                                                          (else
                                                           (drop
                                                            (ref.cast (ref $type46)
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (i32.const 0)
                                                          )
                                                         )
                                                        )
                                                        (then
                                                         (if
                                                          (ref.test (ref $type45)
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.new $type46
                                                           (struct.get $type46 0
                                                            (local.tee $3
                                                             (ref.cast (ref $type46)
                                                              (local.get $1)
                                                             )
                                                            )
                                                           )
                                                           (block (result (ref (exact $type47)))
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global162)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (global.get $ready283)
                                                             )
                                                             (then
                                                              (unreachable)
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global283)
                                                             )
                                                            )
                                                            (drop
                                                             (struct.get $type102 1
                                                              (global.get $global157)
                                                             )
                                                            )
                                                            (if
                                                             (i32.eqz
                                                              (if (result i32)
                                                               (ref.test (ref $type45)
                                                                (local.tee $1
                                                                 (struct.get $type47 0
                                                                  (struct.get $type46 1
                                                                   (local.get $3)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                               (then
                                                                (i32.const 1)
                                                               )
                                                               (else
                                                                (drop
                                                                 (ref.cast (ref $type46)
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                             (then
                                                              (if
                                                               (ref.test (ref $type45)
                                                                (local.get $1)
                                                               )
                                                               (then
                                                                (unreachable)
                                                               )
                                                              )
                                                              (local.set $2
                                                               (struct.new $type46
                                                                (struct.get $type46 0
                                                                 (local.tee $3
                                                                  (ref.cast (ref $type46)
                                                                   (local.get $1)
                                                                  )
                                                                 )
                                                                )
                                                                (block (result (ref (exact $type47)))
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global162)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (global.get $ready283)
                                                                  )
                                                                  (then
                                                                   (unreachable)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global283)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (struct.get $type102 1
                                                                   (global.get $global157)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (if (result i32)
                                                                    (ref.test (ref $type45)
                                                                     (local.tee $1
                                                                      (struct.get $type47 0
                                                                       (struct.get $type46 1
                                                                        (local.get $3)
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                    (then
                                                                     (i32.const 1)
                                                                    )
                                                                    (else
                                                                     (drop
                                                                      (ref.cast (ref $type46)
                                                                       (local.get $1)
                                                                      )
                                                                     )
                                                                     (i32.const 0)
                                                                    )
                                                                   )
                                                                  )
                                                                  (then
                                                                   (if
                                                                    (ref.test (ref $type45)
                                                                     (local.get $1)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (local.set $2
                                                                    (struct.new $type46
                                                                     (struct.get $type46 0
                                                                      (local.tee $3
                                                                       (ref.cast (ref $type46)
                                                                        (local.get $1)
                                                                       )
                                                                      )
                                                                     )
                                                                     (block (result (ref (exact $type47)))
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global162)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (global.get $ready283)
                                                                       )
                                                                       (then
                                                                        (unreachable)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global283)
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (struct.get $type102 1
                                                                        (global.get $global157)
                                                                       )
                                                                      )
                                                                      (if
                                                                       (i32.eqz
                                                                        (if (result i32)
                                                                         (ref.test (ref $type45)
                                                                          (local.tee $1
                                                                           (struct.get $type47 0
                                                                            (struct.get $type46 1
                                                                             (local.get $3)
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                         (then
                                                                          (i32.const 1)
                                                                         )
                                                                         (else
                                                                          (drop
                                                                           (ref.cast (ref $type46)
                                                                            (local.get $1)
                                                                           )
                                                                          )
                                                                          (i32.const 0)
                                                                         )
                                                                        )
                                                                       )
                                                                       (then
                                                                        (if
                                                                         (ref.test (ref $type45)
                                                                          (local.get $1)
                                                                         )
                                                                         (then
                                                                          (unreachable)
                                                                         )
                                                                        )
                                                                        (local.set $2
                                                                         (struct.new $type46
                                                                          (struct.get $type46 0
                                                                           (local.tee $3
                                                                            (ref.cast (ref $type46)
                                                                             (local.get $1)
                                                                            )
                                                                           )
                                                                          )
                                                                          (block (result (ref (exact $type47)))
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global162)
                                                                            )
                                                                           )
                                                                           (local.set $1
                                                                            (struct.get $type47 0
                                                                             (struct.get $type46 1
                                                                              (local.get $3)
                                                                             )
                                                                            )
                                                                           )
                                                                           (if
                                                                            (i32.eqz
                                                                             (global.get $ready283)
                                                                            )
                                                                            (then
                                                                             (unreachable)
                                                                            )
                                                                           )
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global283)
                                                                            )
                                                                           )
                                                                           (if
                                                                            (i32.eqz
                                                                             (call $function65
                                                                              (struct.get $type102 1
                                                                               (global.get $global157)
                                                                              )
                                                                              (local.get $1)
                                                                             )
                                                                            )
                                                                            (then
                                                                             (if
                                                                              (ref.test (ref $type45)
                                                                               (local.get $1)
                                                                              )
                                                                              (then
                                                                               (unreachable)
                                                                              )
                                                                             )
                                                                             (local.set $2
                                                                              (call $function99
                                                                               (struct.get $type46 0
                                                                                (local.tee $3
                                                                                 (ref.cast (ref $type46)
                                                                                  (local.get $1)
                                                                                 )
                                                                                )
                                                                               )
                                                                               (block (result (ref $type44))
                                                                                (drop
                                                                                 (ref.as_non_null
                                                                                  (global.get $global162)
                                                                                 )
                                                                                )
                                                                                (local.set $scratch
                                                                                 (call $function122
                                                                                  (call $function66
                                                                                   (local.get $3)
                                                                                  )
                                                                                  (block (result (ref $type44))
                                                                                   (if
                                                                                    (i32.eqz
                                                                                     (global.get $ready283)
                                                                                    )
                                                                                    (then
                                                                                     (unreachable)
                                                                                    )
                                                                                   )
                                                                                   (drop
                                                                                    (ref.as_non_null
                                                                                     (global.get $global283)
                                                                                    )
                                                                                   )
                                                                                   (local.get $2)
                                                                                  )
                                                                                 )
                                                                                )
                                                                                (drop
                                                                                 (ref.as_non_null
                                                                                  (global.get $global235)
                                                                                 )
                                                                                )
                                                                                (local.get $scratch)
                                                                               )
                                                                              )
                                                                             )
                                                                            )
                                                                           )
                                                                           (drop
                                                                            (ref.as_non_null
                                                                             (global.get $global235)
                                                                            )
                                                                           )
                                                                           (struct.new $type47
                                                                            (local.get $2)
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                      (drop
                                                                       (ref.as_non_null
                                                                        (global.get $global235)
                                                                       )
                                                                      )
                                                                      (struct.new $type47
                                                                       (local.get $2)
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global235)
                                                                  )
                                                                 )
                                                                 (struct.new $type47
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global235)
                                                             )
                                                            )
                                                            (struct.new $type47
                                                             (local.get $2)
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global235)
                                                        )
                                                       )
                                                       (struct.new $type47
                                                        (local.get $2)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global235)
                                                   )
                                                  )
                                                  (struct.new $type47
                                                   (local.get $2)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global235)
                                              )
                                             )
                                             (struct.new $type47
                                              (local.get $2)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global235)
                                         )
                                        )
                                        (struct.new $type47
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global235)
                                    )
                                   )
                                   (struct.new $type47
                                    (local.get $2)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global235)
                               )
                              )
                              (struct.new $type47
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global235)
                          )
                         )
                         (struct.new $type47
                          (local.get $2)
                         )
                        )
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global235)
                     )
                    )
                    (struct.new $type47
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global235)
                )
               )
               (struct.new $type47
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global235)
           )
          )
          (struct.new $type47
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function122 (type $162) (param $0 (ref $type44)) (param $1 (ref $type44)) (result (ref $type44))
  (local $2 (ref $type46))
  (local $3 (ref $type33))
  (local $scratch (ref $type44))
  (if (result (ref $type44))
   (call $function65
    (struct.get $type102 1
     (global.get $global157)
    )
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (struct.get $type46 0
      (local.tee $2
       (ref.cast (ref $type46)
        (local.get $0)
       )
      )
     )
     (block (result (ref $type44))
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (local.set $scratch
       (call $function122
        (call $function66
         (local.get $2)
        )
        (block (result (ref $type44))
         (if
          (i32.eqz
           (global.get $ready283)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global283)
          )
         )
         (local.get $1)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function123 (type $call208) (param $0 (ref $type197)) (param $1 (ref $type197)) (param $2 (ref $type50)) (param $3 (ref $type33)) (param $4 (ref $type209)) (param $5 (ref $type154)) (result (ref $type44))
  (local $6 (ref $type28))
  (local $7 (ref $type33))
  (local $8 (ref $type33))
  (local $9 (ref $type135))
  (local $10 (ref $type52))
  (local $11 (ref $type35))
  (local $12 (ref $type159))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result (ref $type46))
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global262)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global265)
     )
    )
    (local.set $9
     (struct.new_default $type135)
    )
    (struct.new $type46
     (if (result (ref $type33))
      (if (result i32)
       (ref.test (ref $type51)
        (local.get $2)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type52)
          (local.get $2)
         )
        )
        (i32.const 0)
       )
      )
      (then
       (global.get $empty34)
      )
      (else
       (if
        (ref.test (ref $type51)
         (local.get $2)
        )
        (then
         (unreachable)
        )
       )
       (call $function116
        (struct.new $environment116
         (local.get $9)
         (local.tee $10
          (ref.cast (ref $type52)
           (local.get $2)
          )
         )
        )
        (struct.get $type49 1
         (struct.get $type52 0
          (local.get $10)
         )
        )
       )
      )
     )
     (block (result (ref (exact $type47)))
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (struct.new $type47
       (global.get $empty45)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type35 0
      (local.tee $11
       (ref.cast (ref $type35)
        (local.get $3)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (local.set $3
     (struct.get $type36 0
      (struct.get $type35 1
       (local.get $11)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global299)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global307)
     )
    )
    (local.set $7
     (call $function131
      (struct.new $type172
       (ref.func $function129)
       (struct.new $environment129
        (local.get $6)
        (local.tee $12
         (struct.get $type197 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type135)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global307)
     )
    )
    (local.set $8
     (call $function131
      (struct.new $type172
       (ref.func $function138)
       (struct.new $environment138
        (local.get $6)
        (local.get $12)
       )
      )
      (struct.new_default $type135)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (local.set $7
     (call $function148
      (struct.new $type100
       (ref.func $function140)
       (struct.new $environment140
        (struct.get $type197 1
         (local.get $1)
        )
        (local.get $7)
        (local.get $8)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (struct.get $type197 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (return_call_ref $call154
     (call $function150
      (struct.new $type137
       (struct.new $environment125
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (local.get $3)
       )
      )
      (local.get $7)
     )
     (struct.get $type154 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function129 (type $call172) (param $0 (ref struct)) (param $1 (ref $type49)) (result i32)
  (local $2 (ref $environment129))
  (i64.eqz
   (call $function105
    (struct.get $type159 0
     (struct.get $environment129 1
      (local.tee $2
       (ref.cast (ref $environment129)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type49 0
     (local.get $1)
    )
    (struct.get $environment129 0
     (local.get $2)
    )
   )
  )
 )
 (func $function131 (type $153) (param $0 (ref $type172)) (param $1 (ref $type135)) (param $2 i32) (param $3 i32) (param $4 (ref $type33)) (param $5 (ref $type50)) (result (ref $type33))
  (local $6 (ref $type35))
  (local $7 (ref $type49))
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (if (result (ref $type34))
   (if (result i32)
    (ref.test (ref $type51)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type52)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global314)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result (ref $type34))
     (if (result i32)
      (ref.test (ref $type34)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty34)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function135
       (struct.new $environment135
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type35)
          (local.get $4)
         )
        )
        (global.get $empty34)
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type51)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call172
      (struct.get $type172 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type52 0
        (ref.cast (ref $type52)
         (local.get $5)
        )
       )
      )
      (struct.get $type172 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (local.set $4
       (struct.new $type35
        (struct.get $type49 1
         (local.get $7)
        )
        (struct.new $type36
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global271)
     )
    )
    (if
     (ref.test (ref $type51)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type53 0
      (struct.get $type52 1
       (ref.cast (ref $type52)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function131
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function135 (type $151) (param $0 (ref $environment135)) (param $1 (ref $type33)) (result (ref $type33))
  (local $2 (ref $type35))
  (drop
   (ref.as_non_null
    (global.get $global320)
   )
  )
  (local.set $2
   (struct.get $environment135 1
    (local.get $0)
   )
  )
  (struct.set $type36 0
   (struct.get $type35 1
    (local.get $2)
   )
   (struct.get $environment135 2
    (local.get $0)
   )
  )
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (if
     (ref.test (ref $type34)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function135
     (struct.new $environment135
      (struct.get $environment135 0
       (local.get $0)
      )
      (local.tee $2
       (ref.cast (ref $type35)
        (local.get $1)
       )
      )
      (struct.get $environment135 1
       (local.get $0)
      )
     )
     (struct.get $type36 0
      (struct.get $type35 1
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function138 (type $call172) (param $0 (ref struct)) (param $1 (ref $type49)) (result i32)
  (local $2 (ref $environment138))
  (i64.eq
   (call $function105
    (struct.get $type159 0
     (struct.get $environment138 1
      (local.tee $2
       (ref.cast (ref $environment138)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type49 0
     (local.get $1)
    )
    (struct.get $environment138 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function140 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $type33))
  (local $3 (ref $environment140))
  (local $4 (ref $type35))
  (local $5 (ref $type100))
  (drop
   (ref.as_non_null
    (global.get $global329)
   )
  )
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (local.set $5
   (struct.new $type100
    (ref.func $function141)
    (struct.new $environment141
     (struct.get $environment140 0
      (local.tee $3
       (ref.cast (ref $environment140)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type34)
      (local.tee $2
       (struct.get $environment140 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type35)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global172)
      )
     )
     (if
      (ref.test (ref $type34)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function145
      (struct.new $environment145
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
      )
      (struct.get $type36 0
       (struct.get $type35 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global329)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type34)
       (local.tee $2
        (struct.get $environment140 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function145
       (struct.new $environment145
        (struct.new $type100
         (ref.func $function146)
         (struct.new $environment146
          (struct.get $environment140 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type35)
          (local.get $2)
         )
        )
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function141 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $environment141))
  (local $3 i64)
  (return_call $function41
   (call $function105
    (struct.get $type159 0
     (struct.get $environment141 0
      (local.tee $2
       (ref.cast (ref $environment141)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment141 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function145 (type $147) (param $0 (ref $environment145)) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $type35))
  (local $3 (ref $type100))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $2
     (struct.get $environment145 2
      (local.get $0)
     )
    )
    (return_call_ref $call100
     (struct.get $type100 1
      (local.tee $3
       (struct.get $environment145 0
        (local.get $0)
       )
      )
     )
     (struct.get $type35 0
      (local.get $2)
     )
     (struct.get $type100 0
      (local.get $3)
     )
    )
   )
   (else
    (local.set $2
     (struct.get $environment145 2
      (local.get $0)
     )
    )
    (if (result i32)
     (call_ref $call100
      (struct.get $type100 1
       (local.tee $3
        (struct.get $environment145 0
         (local.get $0)
        )
       )
      )
      (struct.get $type35 0
       (local.get $2)
      )
      (struct.get $type100 0
       (local.get $3)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function145
       (struct.new $environment145
        (struct.get $environment145 0
         (local.get $0)
        )
        (struct.get $environment145 1
         (local.get $0)
        )
        (local.tee $2
         (ref.cast (ref $type35)
          (local.get $1)
         )
        )
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $2)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function146 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $environment146))
  (local $3 i64)
  (return_call $function41
   (call $function105
    (struct.get $type159 0
     (struct.get $environment146 0
      (local.tee $2
       (ref.cast (ref $environment146)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment146 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function148 (type $146) (param $0 (ref $type100)) (param $1 i32) (param $2 i32) (param $3 (ref $type33)) (param $4 (ref $type33)) (result (ref $type33))
  (local $5 (ref $type35))
  (local $6 (ref $type28))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result (ref $type34))
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready314)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global314)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result (ref $type34))
     (if (result i32)
      (ref.test (ref $type34)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty34)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function135
       (struct.new $environment135
        (struct.new_default $type248)
        (local.tee $5
         (ref.cast (ref $type35)
          (local.get $3)
         )
        )
        (global.get $empty34)
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call100
      (struct.get $type100 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type35 0
        (ref.cast (ref $type35)
         (local.get $4)
        )
       )
      )
      (struct.get $type100 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (local.set $3
       (struct.new $type35
        (local.get $6)
        (struct.new $type36
         (local.get $3)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (if
     (ref.test (ref $type34)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type36 0
      (struct.get $type35 1
       (ref.cast (ref $type35)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function148
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function150 (type $call136) (param $0 (ref $type137)) (param $1 (ref $type33)) (result (ref $type55))
  (local $2 (ref $environment125))
  (local $3 (ref $type35))
  (local $4 (ref $type28))
  (local $5 (ref $type44))
  (local $6 (ref $type55))
  (local $scratch (ref $type55))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result (ref $type55))
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty56)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type35 0
      (local.tee $3
       (ref.cast (ref $type35)
        (local.get $1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global296)
     )
    )
    (if
     (i32.eqz
      (global.get $ready286)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global286)
     )
    )
    (struct.new $type57
     (call $function123
      (struct.get $environment125 0
       (local.tee $2
        (struct.get $type137 0
         (local.get $0)
        )
       )
      )
      (struct.get $environment125 1
       (local.get $2)
      )
      (struct.new $type52
       (struct.new $type49
        (struct.get $environment125 5
         (local.get $2)
        )
        (local.get $4)
       )
       (struct.new $type53
        (struct.get $environment125 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment125 6
       (local.get $2)
      )
      (struct.get $environment125 3
       (local.get $2)
      )
      (struct.get $environment125 4
       (local.get $2)
      )
     )
     (block (result (ref (exact $type58)))
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (i32.eqz
        (global.get $ready343)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global343)
       )
      )
      (struct.new $type58
       (block (result (ref $type55))
        (local.set $scratch
         (call $function150
          (local.get $0)
          (struct.get $type36 0
           (struct.get $type35 1
            (local.get $3)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global347)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function156 (type $144) (param $0 (ref $environment156)) (param $1 i64) (result i64)
  (local $2 (ref $type33))
  (local $3 (ref $type33))
  (local $4 (ref $type28))
  (local $5 (ref $type159))
  (local $6 (ref $type35))
  (local $7 i32)
  (if (result i64)
   (select
    (local.tee $7
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.eq
     (struct.get $environment156 1
      (local.get $0)
     )
     (local.get $1)
    )
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (if
     (ref.test (ref $type34)
      (local.tee $2
       (struct.get $environment156 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (local.set $1
     (struct.get $environment156 1
      (local.get $0)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result i64)
     (if (result i32)
      (ref.test (ref $type34)
       (local.tee $2
        (struct.get $type36 0
         (struct.get $type35 1
          (ref.cast (ref $type35)
           (local.get $2)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $3
       (struct.get $type36 0
        (struct.get $type35 1
         (struct.get $environment156 4
          (local.get $0)
         )
        )
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type35 0
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function156
       (struct.new $environment156
        (local.tee $5
         (struct.get $environment156 0
          (local.get $0)
         )
        )
        (local.get $1)
        (struct.get $environment156 2
         (local.get $0)
        )
        (local.get $2)
        (local.tee $6
         (ref.cast (ref $type35)
          (local.get $3)
         )
        )
       )
       (call $function105
        (struct.get $type159 0
         (local.get $5)
        )
        (local.get $4)
        (struct.get $type35 0
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 3)
   )
  )
 )
 (func $function158 (type $call161) (param $0 (ref $environment158)) (param $1 (ref $type33)) (param $2 (ref $type33)) (result i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type35))
  (local $6 (ref $type28))
  (local $7 (ref $type159))
  (local $8 (ref $type248))
  (local $9 (ref $type258))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type35 0
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
    )
    (if
     (ref.test (ref $type34)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (select
      (local.tee $4
       (i64.eqz
        (local.tee $3
         (call $function105
          (struct.get $type159 0
           (local.tee $7
            (struct.get $environment158 0
             (local.get $0)
            )
           )
          )
          (local.get $6)
          (struct.get $type35 0
           (local.tee $5
            (ref.cast (ref $type35)
             (local.get $2)
            )
           )
          )
         )
        )
       )
      )
      (i64.eq
       (local.get $3)
       (i64.const 2)
      )
      (local.get $4)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (drop
       (struct.get $type103 1
        (global.get $global167)
       )
      )
      (if (result i64)
       (if (result i32)
        (ref.test (ref $type34)
         (local.tee $1
          (struct.get $type36 0
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
         )
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $8
         (struct.new_default $type248)
        )
        (if
         (ref.test (ref $type34)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.get $type35 0
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
        )
        (if
         (ref.test (ref $type34)
          (local.tee $2
           (struct.get $type36 0
            (struct.get $type35 1
             (local.get $5)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function156
         (struct.new $environment156
          (local.get $7)
          (local.get $3)
          (local.get $8)
          (local.get $1)
          (local.tee $5
           (ref.cast (ref $type35)
            (local.get $2)
           )
          )
         )
         (call $function105
          (struct.get $type159 0
           (local.get $7)
          )
          (local.get $6)
          (struct.get $type35 0
           (local.get $5)
          )
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global172)
         )
        )
        (if
         (ref.test (ref $type34)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type36 0
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $1)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global172)
         )
        )
        (if
         (i32.eqz
          (struct.get $type258 0
           (local.tee $9
            (struct.get $environment158 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function158
         (struct.get $type161 0
          (struct.get $type258 1
           (local.get $9)
          )
         )
         (local.get $1)
         (struct.get $type36 0
          (struct.get $type35 1
           (local.get $5)
          )
         )
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function168 (type $call210) (param $0 (ref $type195)) (param $1 (ref $type195)) (param $2 (ref $type39)) (param $3 (ref $type28)) (param $4 (ref $type211)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type30))
  (local $7 (ref $type139))
  (local $8 i64)
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (local.set $7
     (struct.new $type139
      (ref.func $function170)
      (struct.new $environment170
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $8
        (struct.get $type30 0
         (local.tee $6
          (ref.cast (ref $type30)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $6)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global187)
     )
    )
    (local.set $3
     (call $function75
      (struct.new $environment75
       (local.get $1)
       (local.get $2)
       (local.get $8)
      )
      (struct.get $type195 1
       (local.get $0)
      )
      (struct.get $type195 1
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global384)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function171
      (local.get $7)
      (local.get $3)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function170 (type $call139) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment170))
  (local $3 (ref $type195))
  (return_call $function168
   (struct.get $environment170 0
    (local.tee $2
     (ref.cast (ref $environment170)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type195))
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (i32.eqz
      (global.get $ready374)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global374)
     )
    )
    (struct.get $environment170 1
     (local.get $2)
    )
   )
   (struct.new $type41
    (struct.new $type38
     (struct.get $environment170 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type42
     (struct.get $environment170 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment170 6
    (local.get $2)
   )
   (struct.get $environment170 3
    (local.get $2)
   )
   (struct.get $environment170 4
    (local.get $2)
   )
  )
 )
 (func $function171 (type $call138) (param $0 (ref $type139)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type30))
  (local $3 i64)
  (local $scratch (ref $type28))
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty29)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (call_ref $call139
      (struct.get $type139 1
       (local.get $0)
      )
      (struct.get $type30 0
       (local.tee $2
        (ref.cast (ref $type30)
         (local.get $1)
        )
       )
      )
      (struct.get $type139 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (i32.eqz
        (global.get $ready384)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global384)
       )
      )
      (struct.new $type31
       (block (result (ref $type28))
        (local.set $scratch
         (call $function171
          (local.get $0)
          (struct.get $type31 0
           (struct.get $type30 1
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function175 (type $call212) (param $0 (ref $type197)) (param $1 (ref $type197)) (param $2 (ref $type50)) (param $3 (ref $type33)) (param $4 (ref $type213)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type28))
  (local $7 (ref $type35))
  (local $8 (ref $type141))
  (local $9 (ref $type159))
  (local $10 (ref $type33))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (local.set $8
     (struct.new $type141
      (ref.func $function177)
      (struct.new $environment177
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $6
        (struct.get $type35 0
         (local.tee $7
          (ref.cast (ref $type35)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $7)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global299)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global307)
     )
    )
    (local.set $3
     (call $function131
      (struct.new $type172
       (ref.func $function129)
       (struct.new $environment129
        (local.get $6)
        (local.tee $9
         (struct.get $type197 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type135)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global307)
     )
    )
    (local.set $10
     (call $function131
      (struct.new $type172
       (ref.func $function138)
       (struct.new $environment138
        (local.get $6)
        (local.get $9)
       )
      )
      (struct.new_default $type135)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (local.set $3
     (call $function148
      (struct.new $type100
       (ref.func $function140)
       (struct.new $environment140
        (struct.get $type197 1
         (local.get $1)
        )
        (local.get $3)
        (local.get $10)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (struct.get $type197 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global402)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function178
      (local.get $8)
      (local.get $3)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function177 (type $call141) (param $0 structref) (param $1 (ref $type28)) (result i64)
  (local $2 (ref $environment177))
  (local $3 (ref $type197))
  (return_call $function175
   (struct.get $environment177 0
    (local.tee $2
     (ref.cast (ref $environment177)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type197))
    (drop
     (ref.as_non_null
      (global.get $global296)
     )
    )
    (if
     (i32.eqz
      (global.get $ready392)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global392)
     )
    )
    (struct.get $environment177 1
     (local.get $2)
    )
   )
   (struct.new $type52
    (struct.new $type49
     (struct.get $environment177 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type53
     (struct.get $environment177 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment177 6
    (local.get $2)
   )
   (struct.get $environment177 3
    (local.get $2)
   )
   (struct.get $environment177 4
    (local.get $2)
   )
  )
 )
 (func $function178 (type $call140) (param $0 (ref $type141)) (param $1 (ref $type33)) (result (ref $type28))
  (local $2 (ref $type35))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty29)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (call_ref $call141
      (struct.get $type141 1
       (local.get $0)
      )
      (struct.get $type35 0
       (local.tee $2
        (ref.cast (ref $type35)
         (local.get $1)
        )
       )
      )
      (struct.get $type141 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (i32.eqz
        (global.get $ready402)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global402)
       )
      )
      (struct.new $type31
       (block (result (ref $type28))
        (local.set $scratch
         (call $function178
          (local.get $0)
          (struct.get $type36 0
           (struct.get $type35 1
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function182 (type $call214) (param $0 (ref $type195)) (param $1 (ref $type197)) (param $2 (ref $type61)) (param $3 (ref $type28)) (param $4 (ref $type215)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type33))
  (local $7 (ref $type33))
  (local $8 (ref $type30))
  (local $9 (ref $type141))
  (local $10 (ref $type157))
  (local $11 i64)
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type29)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type30)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type29)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (local.set $9
     (struct.new $type141
      (ref.func $function184)
      (struct.new $environment184
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $11
        (struct.get $type30 0
         (local.tee $8
          (ref.cast (ref $type30)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global423)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global431)
     )
    )
    (local.set $6
     (call $function190
      (struct.new $type174
       (ref.func $function188)
       (struct.new $environment188
        (local.get $11)
        (local.tee $10
         (struct.get $type195 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type175)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global431)
     )
    )
    (local.set $7
     (call $function190
      (struct.new $type174
       (ref.func $function194)
       (struct.new $environment194
        (local.get $11)
        (local.get $10)
       )
      )
      (struct.new_default $type175)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (local.set $6
     (call $function148
      (struct.new $type100
       (ref.func $function196)
       (struct.new $environment196
        (struct.get $type197 1
         (local.get $1)
        )
        (local.get $6)
        (local.get $7)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty34)
      (struct.get $type197 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global402)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function178
      (local.get $9)
      (local.get $6)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function184 (type $call141) (param $0 structref) (param $1 (ref $type28)) (result i64)
  (local $2 (ref $environment184))
  (local $3 (ref $type195))
  (return_call $function182
   (struct.get $environment184 0
    (local.tee $2
     (ref.cast (ref $environment184)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type197))
    (drop
     (ref.as_non_null
      (global.get $global420)
     )
    )
    (if
     (i32.eqz
      (global.get $ready410)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global410)
     )
    )
    (struct.get $environment184 1
     (local.get $2)
    )
   )
   (struct.new $type63
    (struct.new $type60
     (struct.get $environment184 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type64
     (struct.get $environment184 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment184 6
    (local.get $2)
   )
   (struct.get $environment184 3
    (local.get $2)
   )
   (struct.get $environment184 4
    (local.get $2)
   )
  )
 )
 (func $function188 (type $call174) (param $0 (ref struct)) (param $1 (ref $type60)) (result i32)
  (local $2 (ref $environment188))
  (local $3 (ref $type157))
  (i64.eqz
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment188 1
       (local.tee $2
        (ref.cast (ref $environment188)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $type60 0
     (local.get $1)
    )
    (struct.get $environment188 0
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
  )
 )
 (func $function190 (type $124) (param $0 (ref $type174)) (param $1 (ref $type175)) (param $2 i32) (param $3 i32) (param $4 (ref $type33)) (param $5 (ref $type61)) (result (ref $type33))
  (local $6 (ref $type35))
  (local $7 (ref $type60))
  (drop
   (ref.as_non_null
    (global.get $global438)
   )
  )
  (if (result (ref $type34))
   (if (result i32)
    (ref.test (ref $type62)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type63)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global314)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result (ref $type34))
     (if (result i32)
      (ref.test (ref $type34)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty34)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function135
       (struct.new $environment135
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type35)
          (local.get $4)
         )
        )
        (global.get $empty34)
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type62)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call174
      (struct.get $type174 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type63 0
        (ref.cast (ref $type63)
         (local.get $5)
        )
       )
      )
      (struct.get $type174 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global151)
       )
      )
      (local.set $4
       (struct.new $type35
        (struct.get $type60 1
         (local.get $7)
        )
        (struct.new $type36
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global444)
     )
    )
    (if
     (ref.test (ref $type62)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type64 0
      (struct.get $type63 1
       (ref.cast (ref $type63)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function190
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function194 (type $call174) (param $0 (ref struct)) (param $1 (ref $type60)) (result i32)
  (local $2 (ref $environment194))
  (local $3 (ref $type157))
  (i64.eq
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment194 1
       (local.tee $2
        (ref.cast (ref $environment194)
         (local.get $0)
        )
       )
      )
     )
    )
    (struct.get $type60 0
     (local.get $1)
    )
    (struct.get $environment194 0
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (i64.const 2)
  )
 )
 (func $function196 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $type33))
  (local $3 (ref $environment196))
  (local $4 (ref $type35))
  (local $5 (ref $type100))
  (drop
   (ref.as_non_null
    (global.get $global329)
   )
  )
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (local.set $5
   (struct.new $type100
    (ref.func $function197)
    (struct.new $environment197
     (struct.get $environment196 0
      (local.tee $3
       (ref.cast (ref $environment196)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type34)
      (local.tee $2
       (struct.get $environment196 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type35)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global172)
      )
     )
     (if
      (ref.test (ref $type34)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function145
      (struct.new $environment145
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
      )
      (struct.get $type36 0
       (struct.get $type35 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global329)
     )
    )
    (drop
     (struct.get $type103 1
      (global.get $global167)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type34)
       (local.tee $2
        (struct.get $environment196 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (ref.test (ref $type34)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function145
       (struct.new $environment145
        (struct.new $type100
         (ref.func $function198)
         (struct.new $environment198
          (struct.get $environment196 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type35)
          (local.get $2)
         )
        )
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function197 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $environment197))
  (local $3 i64)
  (return_call $function41
   (call $function105
    (struct.get $type159 0
     (struct.get $environment197 0
      (local.tee $2
       (ref.cast (ref $environment197)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment197 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function198 (type $call100) (param $0 structref) (param $1 (ref $type28)) (result i32)
  (local $2 (ref $environment198))
  (local $3 i64)
  (return_call $function41
   (call $function105
    (struct.get $type159 0
     (struct.get $environment198 0
      (local.tee $2
       (ref.cast (ref $environment198)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment198 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function201 (type $call216) (param $0 (ref $type197)) (param $1 (ref $type195)) (param $2 (ref $type67)) (param $3 (ref $type33)) (param $4 (ref $type217)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type35))
  (local $9 (ref $type139))
  (local $10 (ref $type159))
  (drop
   (struct.get $type103 1
    (global.get $global167)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type34)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type35)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type34)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global172)
     )
    )
    (local.set $9
     (struct.new $type139
      (ref.func $function203)
      (struct.new $environment203
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $6
        (struct.get $type35 0
         (local.tee $8
          (ref.cast (ref $type35)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type36 0
        (struct.get $type35 1
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global469)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global477)
     )
    )
    (local.set $7
     (call $function209
      (struct.new $type177
       (ref.func $function207)
       (struct.new $environment207
        (local.get $6)
        (local.tee $10
         (struct.get $type197 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type178)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty29)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global477)
     )
    )
    (local.set $6
     (call $function209
      (struct.new $type177
       (ref.func $function213)
       (struct.new $environment213
        (local.get $6)
        (local.get $10)
       )
      )
      (struct.new_default $type178)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty29)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global224)
     )
    )
    (local.set $6
     (call $function95
      (struct.new $type165
       (ref.func $function215)
       (struct.new $environment215
        (struct.get $type195 1
         (local.get $1)
        )
        (local.get $7)
        (local.get $6)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty29)
      (struct.get $type195 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global384)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function171
      (local.get $9)
      (local.get $6)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function203 (type $call139) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment203))
  (local $3 (ref $type197))
  (return_call $function201
   (struct.get $environment203 0
    (local.tee $2
     (ref.cast (ref $environment203)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type195))
    (drop
     (ref.as_non_null
      (global.get $global466)
     )
    )
    (if
     (i32.eqz
      (global.get $ready456)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global456)
     )
    )
    (struct.get $environment203 1
     (local.get $2)
    )
   )
   (struct.new $type69
    (struct.new $type66
     (struct.get $environment203 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type70
     (struct.get $environment203 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment203 6
    (local.get $2)
   )
   (struct.get $environment203 3
    (local.get $2)
   )
   (struct.get $environment203 4
    (local.get $2)
   )
  )
 )
 (func $function207 (type $call177) (param $0 (ref struct)) (param $1 (ref $type66)) (result i32)
  (local $2 (ref $environment207))
  (i64.eqz
   (call $function105
    (struct.get $type159 0
     (struct.get $environment207 1
      (local.tee $2
       (ref.cast (ref $environment207)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type66 0
     (local.get $1)
    )
    (struct.get $environment207 0
     (local.get $2)
    )
   )
  )
 )
 (func $function209 (type $110) (param $0 (ref $type177)) (param $1 (ref $type178)) (param $2 i32) (param $3 i32) (param $4 (ref $type28)) (param $5 (ref $type67)) (result (ref $type28))
  (local $6 (ref $type30))
  (local $7 (ref $type66))
  (drop
   (ref.as_non_null
    (global.get $global484)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (ref.test (ref $type68)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type69)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global202)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result (ref $type29))
     (if (result i32)
      (ref.test (ref $type29)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty29)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function82
       (struct.new $environment82
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type30)
          (local.get $4)
         )
        )
        (global.get $empty29)
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type68)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call177
      (struct.get $type177 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type69 0
        (ref.cast (ref $type69)
         (local.get $5)
        )
       )
      )
      (struct.get $type177 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (local.set $4
       (struct.new $type30
        (struct.get $type66 1
         (local.get $7)
        )
        (struct.new $type31
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global490)
     )
    )
    (if
     (ref.test (ref $type68)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type70 0
      (struct.get $type69 1
       (ref.cast (ref $type69)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function209
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function213 (type $call177) (param $0 (ref struct)) (param $1 (ref $type66)) (result i32)
  (local $2 (ref $environment213))
  (i64.eq
   (call $function105
    (struct.get $type159 0
     (struct.get $environment213 1
      (local.tee $2
       (ref.cast (ref $environment213)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type66 0
     (local.get $1)
    )
    (struct.get $environment213 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function215 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type28))
  (local $3 (ref $environment215))
  (local $4 (ref $type30))
  (local $5 (ref $type165))
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global109)
   )
  )
  (local.set $5
   (struct.new $type165
    (ref.func $function216)
    (struct.new $environment216
     (struct.get $environment215 0
      (local.tee $3
       (ref.cast (ref $environment215)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type29)
      (local.tee $2
       (struct.get $environment215 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global115)
      )
     )
     (if
      (ref.test (ref $type29)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function92
      (struct.new $environment92
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
      )
      (struct.get $type31 0
       (struct.get $type30 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global217)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global109)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type29)
       (local.tee $2
        (struct.get $environment215 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type30)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global115)
       )
      )
      (if
       (ref.test (ref $type29)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function92
       (struct.new $environment92
        (struct.new $type165
         (ref.func $function217)
         (struct.new $environment217
          (struct.get $environment215 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type30)
          (local.get $2)
         )
        )
       )
       (struct.get $type31 0
        (struct.get $type30 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function216 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment216))
  (local $3 (ref $type157))
  (return_call $function41
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment216 0
       (local.tee $2
        (ref.cast (ref $environment216)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment216 1
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function217 (type $call165) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment217))
  (local $3 (ref $type157))
  (return_call $function41
   (call_ref $call157
    (struct.get $type157 1
     (local.tee $3
      (struct.get $environment217 0
       (local.tee $2
        (ref.cast (ref $environment217)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment217 1
     (local.get $2)
    )
    (struct.get $type157 0
     (local.get $3)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function222 (type $call218) (param $0 (ref $type201)) (param $1 (ref $type201)) (param $2 (ref $type73)) (param $3 (ref $type44)) (param $4 (ref $type219)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type33))
  (local $7 (ref $type46))
  (local $8 (ref $type143))
  (local $9 (ref $type161))
  (local $10 (ref $type44))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (local.set $8
     (struct.new $type143
      (ref.func $function224)
      (struct.new $environment224
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $6
        (struct.get $type46 0
         (local.tee $7
          (ref.cast (ref $type46)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $7)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global517)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global525)
     )
    )
    (local.set $3
     (call $function230
      (struct.new $type180
       (ref.func $function228)
       (struct.new $environment228
        (local.get $6)
        (local.tee $9
         (struct.get $type201 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type145)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty45)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global525)
     )
    )
    (local.set $10
     (call $function230
      (struct.new $type180
       (ref.func $function239)
       (struct.new $environment239
        (local.get $6)
        (local.get $9)
       )
      )
      (struct.new_default $type145)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty45)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global561)
     )
    )
    (local.set $3
     (call $function249
      (struct.new $type103
       (ref.func $function241)
       (struct.new $environment241
        (struct.get $type201 1
         (local.get $1)
        )
        (local.get $3)
        (local.get $10)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty45)
      (struct.get $type201 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global568)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function251
      (local.get $8)
      (local.get $3)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function224 (type $call143) (param $0 (ref struct)) (param $1 (ref $type33)) (result i64)
  (local $2 (ref $environment224))
  (local $3 (ref $type201))
  (return_call $function222
   (struct.get $environment224 0
    (local.tee $2
     (ref.cast (ref $environment224)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type201))
    (drop
     (ref.as_non_null
      (global.get $global514)
     )
    )
    (if
     (i32.eqz
      (global.get $ready504)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global504)
     )
    )
    (struct.get $environment224 1
     (local.get $2)
    )
   )
   (struct.new $type75
    (struct.new $type72
     (struct.get $environment224 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type76
     (struct.get $environment224 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment224 6
    (local.get $2)
   )
   (struct.get $environment224 3
    (local.get $2)
   )
   (struct.get $environment224 4
    (local.get $2)
   )
  )
 )
 (func $function228 (type $call180) (param $0 (ref struct)) (param $1 (ref $type72)) (result i32)
  (local $2 (ref $environment228))
  (i64.eqz
   (call $function158
    (struct.get $type161 0
     (struct.get $environment228 1
      (local.tee $2
       (ref.cast (ref $environment228)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type72 0
     (local.get $1)
    )
    (struct.get $environment228 0
     (local.get $2)
    )
   )
  )
 )
 (func $function230 (type $94) (param $0 (ref $type180)) (param $1 (ref $type145)) (param $2 i32) (param $3 i32) (param $4 (ref $type44)) (param $5 (ref $type73)) (result (ref $type44))
  (local $6 (ref $type46))
  (local $7 (ref $type72))
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result (ref $type45))
   (if (result i32)
    (ref.test (ref $type74)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type75)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result (ref $type45))
     (if (result i32)
      (ref.test (ref $type45)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty45)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function235
       (struct.new $environment235
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type46)
          (local.get $4)
         )
        )
        (global.get $empty45)
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type74)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call180
      (struct.get $type180 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type75 0
        (ref.cast (ref $type75)
         (local.get $5)
        )
       )
      )
      (struct.get $type180 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (local.set $4
       (struct.new $type46
        (struct.get $type72 1
         (local.get $7)
        )
        (struct.new $type47
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global547)
     )
    )
    (if
     (ref.test (ref $type74)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type76 0
      (struct.get $type75 1
       (ref.cast (ref $type75)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function230
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function235 (type $92) (param $0 (ref $environment235)) (param $1 (ref $type44)) (result (ref $type44))
  (local $2 (ref $type46))
  (drop
   (ref.as_non_null
    (global.get $global543)
   )
  )
  (local.set $2
   (struct.get $environment235 1
    (local.get $0)
   )
  )
  (struct.set $type47 0
   (struct.get $type46 1
    (local.get $2)
   )
   (struct.get $environment235 2
    (local.get $0)
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result (ref $type46))
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (ref.test (ref $type45)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function235
     (struct.new $environment235
      (struct.get $environment235 0
       (local.get $0)
      )
      (local.tee $2
       (ref.cast (ref $type46)
        (local.get $1)
       )
      )
      (struct.get $environment235 1
       (local.get $0)
      )
     )
     (struct.get $type47 0
      (struct.get $type46 1
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function239 (type $call180) (param $0 (ref struct)) (param $1 (ref $type72)) (result i32)
  (local $2 (ref $environment239))
  (i64.eq
   (call $function158
    (struct.get $type161 0
     (struct.get $environment239 1
      (local.tee $2
       (ref.cast (ref $environment239)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type72 0
     (local.get $1)
    )
    (struct.get $environment239 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function241 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $type44))
  (local $3 (ref $environment241))
  (local $4 (ref $type46))
  (local $5 (ref $type103))
  (drop
   (ref.as_non_null
    (global.get $global554)
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (local.set $5
   (struct.new $type103
    (ref.func $function242)
    (struct.new $environment242
     (struct.get $environment241 0
      (local.tee $3
       (ref.cast (ref $environment241)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type45)
      (local.tee $2
       (struct.get $environment241 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global162)
      )
     )
     (if
      (ref.test (ref $type45)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function246
      (struct.new $environment246
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
      )
      (struct.get $type47 0
       (struct.get $type46 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global554)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type45)
       (local.tee $2
        (struct.get $environment241 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function246
       (struct.new $environment246
        (struct.new $type103
         (ref.func $function247)
         (struct.new $environment247
          (struct.get $environment241 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type46)
          (local.get $2)
         )
        )
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function242 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $environment242))
  (local $3 i64)
  (return_call $function41
   (call $function158
    (struct.get $type161 0
     (struct.get $environment242 0
      (local.tee $2
       (ref.cast (ref $environment242)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment242 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function246 (type $88) (param $0 (ref $environment246)) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $type46))
  (local $3 (ref $type103))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $2
     (struct.get $environment246 2
      (local.get $0)
     )
    )
    (return_call_ref $call103
     (struct.get $type103 1
      (local.tee $3
       (struct.get $environment246 0
        (local.get $0)
       )
      )
     )
     (struct.get $type46 0
      (local.get $2)
     )
     (struct.get $type103 0
      (local.get $3)
     )
    )
   )
   (else
    (local.set $2
     (struct.get $environment246 2
      (local.get $0)
     )
    )
    (if (result i32)
     (call_ref $call103
      (struct.get $type103 1
       (local.tee $3
        (struct.get $environment246 0
         (local.get $0)
        )
       )
      )
      (struct.get $type46 0
       (local.get $2)
      )
      (struct.get $type103 0
       (local.get $3)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function246
       (struct.new $environment246
        (struct.get $environment246 0
         (local.get $0)
        )
        (struct.get $environment246 1
         (local.get $0)
        )
        (local.tee $2
         (ref.cast (ref $type46)
          (local.get $1)
         )
        )
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $2)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function247 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $environment247))
  (local $3 i64)
  (return_call $function41
   (call $function158
    (struct.get $type161 0
     (struct.get $environment247 0
      (local.tee $2
       (ref.cast (ref $environment247)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment247 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function249 (type $87) (param $0 (ref $type103)) (param $1 i32) (param $2 i32) (param $3 (ref $type44)) (param $4 (ref $type44)) (result (ref $type44))
  (local $5 (ref $type46))
  (local $6 (ref $type33))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result (ref $type45))
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready537)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result (ref $type45))
     (if (result i32)
      (ref.test (ref $type45)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty45)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function235
       (struct.new $environment235
        (struct.new_default $type248)
        (local.tee $5
         (ref.cast (ref $type46)
          (local.get $3)
         )
        )
        (global.get $empty45)
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call103
      (struct.get $type103 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type46 0
        (ref.cast (ref $type46)
         (local.get $4)
        )
       )
      )
      (struct.get $type103 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (local.set $3
       (struct.new $type46
        (local.get $6)
        (struct.new $type47
         (local.get $3)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (ref.test (ref $type45)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type47 0
      (struct.get $type46 1
       (ref.cast (ref $type46)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function249
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function251 (type $call142) (param $0 (ref $type143)) (param $1 (ref $type44)) (result (ref $type28))
  (local $2 (ref $type46))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty29)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (call_ref $call143
      (struct.get $type143 1
       (local.get $0)
      )
      (struct.get $type46 0
       (local.tee $2
        (ref.cast (ref $type46)
         (local.get $1)
        )
       )
      )
      (struct.get $type143 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (i32.eqz
        (global.get $ready568)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global568)
       )
      )
      (struct.new $type31
       (block (result (ref $type28))
        (local.set $scratch
         (call $function251
          (local.get $0)
          (struct.get $type47 0
           (struct.get $type46 1
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function254 (type $call230) (param $0 (ref $type201)) (param $1 (ref $type201)) (result (ref $type203))
  (local $2 (ref $type272))
  (local $3 (ref $type44))
  (local $4 (ref $type74))
  (local $5 (ref $type46))
  (drop
   (ref.as_non_null
    (global.get $global594)
   )
  )
  (local.set $4
   (global.get $empty74)
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (struct.new $type203
   (if (result (ref $type55))
    (if (result i32)
     (ref.test (ref $type45)
      (local.tee $3
       (struct.get $type201 0
        (local.get $0)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $3)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global577)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global532)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global347)
      )
     )
     (struct.new $type57
      (global.get $empty45)
      (struct.new $type58
       (global.get $empty56)
      )
     )
    )
    (else
     (if
      (ref.test (ref $type45)
       (local.get $3)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global162)
      )
     )
     (call $function264
      (struct.new $environment264
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (struct.new_default $type221)
       (struct.new $type155
        (ref.func $function258)
       )
      )
      (struct.get $type46 0
       (local.tee $5
        (ref.cast (ref $type46)
         (local.get $3)
        )
       )
      )
      (struct.get $type47 0
       (struct.get $type46 1
        (local.get $5)
       )
      )
     )
    )
   )
   (block (result (ref $type163))
    (drop
     (ref.as_non_null
      (global.get $global611)
     )
    )
    (struct.set $type272 1
     (local.tee $2
      (struct.new_default $type272)
     )
     (struct.new $type163
      (struct.new $environment274
       (struct.get $type201 1
        (local.get $1)
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type272 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type272 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (struct.get $type272 1
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function257 (type $79) (param $0 (ref $environment257)) (param $1 (ref $type33)) (result (ref $type46))
  (local $2 (ref $type73))
  (local $3 (ref $type145))
  (local $4 (ref $type75))
  (local $5 (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global547)
   )
  )
  (if
   (i32.eqz
    (global.get $ready577)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global577)
   )
  )
  (local.set $3
   (struct.get $environment257 0
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (local.set $5
   (if (result (ref $type44))
    (if (result i32)
     (ref.test (ref $type74)
      (local.tee $2
       (struct.get $type76 0
        (struct.get $type75 1
         (struct.get $environment257 1
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type75)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty45)
    )
    (else
     (if
      (ref.test (ref $type74)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function257
      (struct.new $environment257
       (local.get $3)
       (local.tee $4
        (ref.cast (ref $type75)
         (local.get $2)
        )
       )
      )
      (struct.get $type72 1
       (struct.get $type75 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (struct.new $type46
   (local.get $1)
   (struct.new $type47
    (local.get $5)
   )
  )
 )
 (func $function258 (type $call155) (param $0 (ref $type78)) (result (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global582)
   )
  )
  (return_call $function259
   (local.get $0)
  )
 )
 (func $function259 (type $call155) (param $0 (ref $type78)) (result (ref $type55))
  (local $1 (ref $type78))
  (local $2 (ref $type80))
  (local $3 (ref $type55))
  (local $4 (ref $type55))
  (local $scratch (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global584)
   )
  )
  (if (result (ref $type55))
   (if (result i32)
    (ref.test (ref $type79)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type80)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty56)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global589)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global584)
     )
    )
    (if
     (ref.test (ref $type79)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type55))
     (if (result i32)
      (ref.test (ref $type79)
       (local.tee $1
        (struct.get $type81 0
         (struct.get $type80 1
          (ref.cast (ref $type80)
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type80)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (if
       (ref.test (ref $type79)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type80 0
       (ref.cast (ref $type80)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (ref.test (ref $type79)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function262
       (struct.get $type80 0
        (local.tee $2
         (ref.cast (ref $type80)
          (local.get $0)
         )
        )
       )
       (block (result (ref $type55))
        (drop
         (ref.as_non_null
          (global.get $global589)
         )
        )
        (if
         (i32.eqz
          (global.get $ready582)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global582)
         )
        )
        (local.set $scratch
         (call $function259
          (struct.get $type81 0
           (struct.get $type80 1
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global591)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function262 (type $74) (param $0 (ref $type55)) (param $1 (ref $type55)) (result (ref $type55))
  (local $2 (ref $type57))
  (local $3 (ref $type44))
  (local $scratch (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result (ref $type55))
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type56)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type57
     (struct.get $type57 0
      (local.tee $2
       (ref.cast (ref $type57)
        (local.get $0)
       )
      )
     )
     (block (result (ref (exact $type58)))
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (i32.eqz
        (global.get $ready591)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global591)
       )
      )
      (struct.new $type58
       (block (result (ref $type55))
        (local.set $scratch
         (call $function262
          (struct.get $type58 0
           (struct.get $type57 1
            (local.get $2)
           )
          )
          (local.get $1)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global347)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function264 (type $73) (param $0 (ref $environment264)) (param $1 (ref $type33)) (param $2 (ref $type44)) (result (ref $type55))
  (local $3 (ref $type44))
  (local $4 (ref $type44))
  (local $5 (ref $type73))
  (local $6 (ref $type201))
  (local $7 (ref $type201))
  (local $8 (ref $type147))
  (local $9 (ref $type161))
  (local $10 (ref $type155))
  (local $11 (ref $type46))
  (drop
   (ref.as_non_null
    (global.get $global517)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $3
   (call $function230
    (struct.new $type180
     (ref.func $function228)
     (struct.new $environment228
      (local.get $1)
      (local.tee $9
       (struct.get $type201 1
        (local.tee $7
         (struct.get $environment264 0
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (struct.new_default $type145)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (local.tee $5
     (struct.get $environment264 2
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (local.set $4
   (call $function230
    (struct.new $type180
     (ref.func $function239)
     (struct.new $environment239
      (local.get $1)
      (local.get $9)
     )
    )
    (struct.new_default $type145)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (local.get $5)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global561)
   )
  )
  (local.set $3
   (call $function249
    (struct.new $type103
     (ref.func $function241)
     (struct.new $environment241
      (struct.get $type201 1
       (local.tee $6
        (struct.get $environment264 1
         (local.get $0)
        )
       )
      )
      (local.get $3)
      (local.get $4)
     )
    )
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (struct.get $type201 0
     (local.get $6)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global604)
   )
  )
  (local.set $8
   (struct.new $type147
    (struct.new $environment265
     (local.get $7)
     (local.get $6)
     (local.get $5)
     (struct.get $environment264 3
      (local.get $0)
     )
     (local.tee $10
      (struct.get $environment264 4
       (local.get $0)
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (return_call_ref $call155
   (if (result (ref $type78))
    (if (result i32)
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $3)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty79)
    )
    (else
     (if
      (ref.test (ref $type45)
       (local.get $3)
      )
      (then
       (unreachable)
      )
     )
     (call $function267
      (struct.new $environment267
       (local.get $8)
       (local.tee $11
        (ref.cast (ref $type46)
         (local.get $3)
        )
       )
      )
      (call $function265
       (struct.get $type147 0
        (local.get $8)
       )
       (struct.get $type46 0
        (local.get $11)
       )
      )
     )
    )
   )
   (struct.get $type155 0
    (local.get $10)
   )
  )
 )
 (func $function265 (type $call147) (param $0 (ref $environment265)) (param $1 (ref $type33)) (result (ref $type55))
  (local $2 (ref $type75))
  (local $3 (ref $type44))
  (local $4 (ref $type46))
  (local $5 (ref $type46))
  (drop
   (ref.as_non_null
    (global.get $global514)
   )
  )
  (if
   (i32.eqz
    (global.get $ready594)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global594)
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (local.set $2
   (struct.new $type75
    (struct.new $type72
     (struct.get $environment265 5
      (local.get $0)
     )
     (local.get $1)
    )
    (struct.new $type76
     (struct.get $environment265 2
      (local.get $0)
     )
    )
   )
  )
  (if (result (ref $type57))
   (if (result i32)
    (ref.test (ref $type45)
     (local.tee $3
      (struct.get $environment265 6
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global577)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global532)
     )
    )
    (struct.new $type57
     (call $function257
      (struct.new $environment257
       (struct.new_default $type145)
       (local.get $2)
      )
      (struct.get $type72 1
       (struct.get $type75 0
        (local.get $2)
       )
      )
     )
     (block (result (ref (exact $type58)))
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (struct.new $type58
       (global.get $empty56)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (return_call $function264
     (struct.new $environment264
      (struct.get $environment265 0
       (local.get $0)
      )
      (struct.get $environment265 1
       (local.get $0)
      )
      (local.get $2)
      (struct.get $environment265 3
       (local.get $0)
      )
      (struct.get $environment265 4
       (local.get $0)
      )
     )
     (struct.get $type46 0
      (local.tee $5
       (ref.cast (ref $type46)
        (local.get $3)
       )
      )
     )
     (struct.get $type47 0
      (struct.get $type46 1
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function267 (type $68) (param $0 (ref $environment267)) (param $1 (ref $type55)) (result (ref $type80))
  (local $2 (ref $type44))
  (local $3 (ref $type147))
  (local $4 (ref $type46))
  (local $5 (ref $type78))
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (if
   (i32.eqz
    (global.get $ready604)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global604)
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (local.set $5
   (if (result (ref $type78))
    (if (result i32)
     (ref.test (ref $type45)
      (local.tee $2
       (struct.get $type47 0
        (struct.get $type46 1
         (struct.get $environment267 1
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (global.get $empty79)
    )
    (else
     (if
      (ref.test (ref $type45)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function267
      (struct.new $environment267
       (local.tee $3
        (struct.get $environment267 0
         (local.get $0)
        )
       )
       (local.tee $4
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
      )
      (call $function265
       (struct.get $type147 0
        (local.get $3)
       )
       (struct.get $type46 0
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global608)
   )
  )
  (struct.new $type80
   (local.get $1)
   (struct.new $type81
    (local.get $5)
   )
  )
 )
 (func $function272 (type $67) (param $0 (ref $environment272)) (param $1 i64) (result i64)
  (local $2 (ref $type44))
  (local $3 (ref $type44))
  (local $4 (ref $type33))
  (local $5 (ref $type161))
  (local $6 (ref $type46))
  (local $7 i32)
  (if (result i64)
   (select
    (local.tee $7
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.eq
     (struct.get $environment272 1
      (local.get $0)
     )
     (local.get $1)
    )
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (ref.test (ref $type45)
      (local.tee $2
       (struct.get $environment272 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (local.set $1
     (struct.get $environment272 1
      (local.get $0)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result i64)
     (if (result i32)
      (ref.test (ref $type45)
       (local.tee $2
        (struct.get $type47 0
         (struct.get $type46 1
          (ref.cast (ref $type46)
           (local.get $2)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $3
       (struct.get $type47 0
        (struct.get $type46 1
         (struct.get $environment272 4
          (local.get $0)
         )
        )
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type46 0
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function272
       (struct.new $environment272
        (local.tee $5
         (struct.get $environment272 0
          (local.get $0)
         )
        )
        (local.get $1)
        (struct.get $environment272 2
         (local.get $0)
        )
        (local.get $2)
        (local.tee $6
         (ref.cast (ref $type46)
          (local.get $3)
         )
        )
       )
       (call $function158
        (struct.get $type161 0
         (local.get $5)
        )
        (local.get $4)
        (struct.get $type46 0
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 3)
   )
  )
 )
 (func $function274 (type $call163) (param $0 (ref $environment274)) (param $1 (ref $type44)) (param $2 (ref $type44)) (result i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type46))
  (local $6 (ref $type33))
  (local $7 (ref $type161))
  (local $8 (ref $type248))
  (local $9 (ref $type272))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type46 0
      (ref.cast (ref $type46)
       (local.get $1)
      )
     )
    )
    (if
     (ref.test (ref $type45)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (select
      (local.tee $4
       (i64.eqz
        (local.tee $3
         (call $function158
          (struct.get $type161 0
           (local.tee $7
            (struct.get $environment274 0
             (local.get $0)
            )
           )
          )
          (local.get $6)
          (struct.get $type46 0
           (local.tee $5
            (ref.cast (ref $type46)
             (local.get $2)
            )
           )
          )
         )
        )
       )
      )
      (i64.eq
       (local.get $3)
       (i64.const 2)
      )
      (local.get $4)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (drop
       (struct.get $type102 1
        (global.get $global157)
       )
      )
      (if (result i64)
       (if (result i32)
        (ref.test (ref $type45)
         (local.tee $1
          (struct.get $type47 0
           (struct.get $type46 1
            (ref.cast (ref $type46)
             (local.get $1)
            )
           )
          )
         )
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type46)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (local.get $3)
       )
       (else
        (local.set $8
         (struct.new_default $type248)
        )
        (if
         (ref.test (ref $type45)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.get $type46 0
          (ref.cast (ref $type46)
           (local.get $1)
          )
         )
        )
        (if
         (ref.test (ref $type45)
          (local.tee $2
           (struct.get $type47 0
            (struct.get $type46 1
             (local.get $5)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function272
         (struct.new $environment272
          (local.get $7)
          (local.get $3)
          (local.get $8)
          (local.get $1)
          (local.tee $5
           (ref.cast (ref $type46)
            (local.get $2)
           )
          )
         )
         (call $function158
          (struct.get $type161 0
           (local.get $7)
          )
          (local.get $6)
          (struct.get $type46 0
           (local.get $5)
          )
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global162)
         )
        )
        (if
         (ref.test (ref $type45)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type47 0
          (struct.get $type46 1
           (ref.cast (ref $type46)
            (local.get $1)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global162)
         )
        )
        (if
         (i32.eqz
          (struct.get $type272 0
           (local.tee $9
            (struct.get $environment274 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function274
         (struct.get $type163 0
          (struct.get $type272 1
           (local.get $9)
          )
         )
         (local.get $1)
         (struct.get $type47 0
          (struct.get $type46 1
           (local.get $5)
          )
         )
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function283 (type $call222) (param $0 (ref $type201)) (param $1 (ref $type203)) (param $2 (ref $type84)) (param $3 (ref $type44)) (param $4 (ref $type223)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type55))
  (local $7 (ref $type55))
  (local $8 (ref $type33))
  (local $9 (ref $type46))
  (local $10 (ref $type149))
  (local $11 (ref $type161))
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type45)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type46)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type45)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (local.set $10
     (struct.new $type149
      (ref.func $function285)
      (struct.new $environment285
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $8
        (struct.get $type46 0
         (local.tee $9
          (ref.cast (ref $type46)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $9)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global648)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global656)
     )
    )
    (local.set $6
     (call $function291
      (struct.new $type182
       (ref.func $function289)
       (struct.new $environment289
        (local.get $8)
        (local.tee $11
         (struct.get $type201 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type183)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global656)
     )
    )
    (local.set $7
     (call $function291
      (struct.new $type182
       (ref.func $function300)
       (struct.new $environment300
        (local.get $8)
        (local.get $11)
       )
      )
      (struct.new_default $type183)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global692)
     )
    )
    (local.set $6
     (call $function310
      (struct.new $type102
       (ref.func $function302)
       (struct.new $environment302
        (struct.get $type203 1
         (local.get $1)
        )
        (local.get $6)
        (local.get $7)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (struct.get $type203 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global699)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function312
      (local.get $10)
      (local.get $6)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function285 (type $call149) (param $0 (ref struct)) (param $1 (ref $type44)) (result i64)
  (local $2 (ref $environment285))
  (local $3 (ref $type201))
  (return_call $function283
   (struct.get $environment285 0
    (local.tee $2
     (ref.cast (ref $environment285)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type203))
    (drop
     (ref.as_non_null
      (global.get $global645)
     )
    )
    (if
     (i32.eqz
      (global.get $ready635)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global635)
     )
    )
    (struct.get $environment285 1
     (local.get $2)
    )
   )
   (struct.new $type86
    (struct.new $type83
     (struct.get $environment285 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type87
     (struct.get $environment285 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment285 6
    (local.get $2)
   )
   (struct.get $environment285 3
    (local.get $2)
   )
   (struct.get $environment285 4
    (local.get $2)
   )
  )
 )
 (func $function289 (type $call182) (param $0 (ref struct)) (param $1 (ref $type83)) (result i32)
  (local $2 (ref $environment289))
  (i64.eqz
   (call $function158
    (struct.get $type161 0
     (struct.get $environment289 1
      (local.tee $2
       (ref.cast (ref $environment289)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type83 0
     (local.get $1)
    )
    (struct.get $environment289 0
     (local.get $2)
    )
   )
  )
 )
 (func $function291 (type $51) (param $0 (ref $type182)) (param $1 (ref $type183)) (param $2 i32) (param $3 i32) (param $4 (ref $type55)) (param $5 (ref $type84)) (result (ref $type55))
  (local $6 (ref $type57))
  (local $7 (ref $type83))
  (drop
   (ref.as_non_null
    (global.get $global663)
   )
  )
  (if (result (ref $type56))
   (if (result i32)
    (ref.test (ref $type85)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type86)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global668)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (if (result (ref $type56))
     (if (result i32)
      (ref.test (ref $type56)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty56)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function296
       (struct.new $environment296
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type57)
          (local.get $4)
         )
        )
        (global.get $empty56)
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type85)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call182
      (struct.get $type182 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type86 0
        (ref.cast (ref $type86)
         (local.get $5)
        )
       )
      )
      (struct.get $type182 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (local.set $4
       (struct.new $type57
        (struct.get $type83 1
         (local.get $7)
        )
        (struct.new $type58
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global678)
     )
    )
    (if
     (ref.test (ref $type85)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type87 0
      (struct.get $type86 1
       (ref.cast (ref $type86)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function291
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function296 (type $49) (param $0 (ref $environment296)) (param $1 (ref $type55)) (result (ref $type55))
  (local $2 (ref $type57))
  (drop
   (ref.as_non_null
    (global.get $global674)
   )
  )
  (local.set $2
   (struct.get $environment296 1
    (local.get $0)
   )
  )
  (struct.set $type58 0
   (struct.get $type57 1
    (local.get $2)
   )
   (struct.get $environment296 2
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result (ref $type57))
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (if
     (ref.test (ref $type56)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function296
     (struct.new $environment296
      (struct.get $environment296 0
       (local.get $0)
      )
      (local.tee $2
       (ref.cast (ref $type57)
        (local.get $1)
       )
      )
      (struct.get $environment296 1
       (local.get $0)
      )
     )
     (struct.get $type58 0
      (struct.get $type57 1
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function300 (type $call182) (param $0 (ref struct)) (param $1 (ref $type83)) (result i32)
  (local $2 (ref $environment300))
  (i64.eq
   (call $function158
    (struct.get $type161 0
     (struct.get $environment300 1
      (local.tee $2
       (ref.cast (ref $environment300)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type83 0
     (local.get $1)
    )
    (struct.get $environment300 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function302 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $environment302))
  (local $4 (ref $type57))
  (local $5 (ref $type102))
  (drop
   (ref.as_non_null
    (global.get $global685)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (local.set $5
   (struct.new $type102
    (ref.func $function303)
    (struct.new $environment303
     (struct.get $environment302 0
      (local.tee $3
       (ref.cast (ref $environment302)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type56)
      (local.tee $2
       (struct.get $environment302 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type57)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global281)
      )
     )
     (if
      (ref.test (ref $type56)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function307
      (struct.new $environment307
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
      )
      (struct.get $type58 0
       (struct.get $type57 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global685)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type56)
       (local.tee $2
        (struct.get $environment302 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function307
       (struct.new $environment307
        (struct.new $type102
         (ref.func $function308)
         (struct.new $environment308
          (struct.get $environment302 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type57)
          (local.get $2)
         )
        )
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function303 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $environment303))
  (local $3 i64)
  (return_call $function41
   (call $function274
    (struct.get $type163 0
     (struct.get $environment303 0
      (local.tee $2
       (ref.cast (ref $environment303)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment303 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function307 (type $45) (param $0 (ref $environment307)) (param $1 (ref $type55)) (result i32)
  (local $2 (ref $type57))
  (local $3 (ref $type102))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $2
     (struct.get $environment307 2
      (local.get $0)
     )
    )
    (return_call_ref $call102
     (struct.get $type102 1
      (local.tee $3
       (struct.get $environment307 0
        (local.get $0)
       )
      )
     )
     (struct.get $type57 0
      (local.get $2)
     )
     (struct.get $type102 0
      (local.get $3)
     )
    )
   )
   (else
    (local.set $2
     (struct.get $environment307 2
      (local.get $0)
     )
    )
    (if (result i32)
     (call_ref $call102
      (struct.get $type102 1
       (local.tee $3
        (struct.get $environment307 0
         (local.get $0)
        )
       )
      )
      (struct.get $type57 0
       (local.get $2)
      )
      (struct.get $type102 0
       (local.get $3)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function307
       (struct.new $environment307
        (struct.get $environment307 0
         (local.get $0)
        )
        (struct.get $environment307 1
         (local.get $0)
        )
        (local.tee $2
         (ref.cast (ref $type57)
          (local.get $1)
         )
        )
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $2)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function308 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $environment308))
  (local $3 i64)
  (return_call $function41
   (call $function274
    (struct.get $type163 0
     (struct.get $environment308 0
      (local.tee $2
       (ref.cast (ref $environment308)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment308 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function310 (type $44) (param $0 (ref $type102)) (param $1 i32) (param $2 i32) (param $3 (ref $type55)) (param $4 (ref $type55)) (result (ref $type55))
  (local $5 (ref $type57))
  (local $6 (ref $type44))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result (ref $type56))
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready668)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global668)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (if (result (ref $type56))
     (if (result i32)
      (ref.test (ref $type56)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty56)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function296
       (struct.new $environment296
        (struct.new_default $type248)
        (local.tee $5
         (ref.cast (ref $type57)
          (local.get $3)
         )
        )
        (global.get $empty56)
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type56)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call102
      (struct.get $type102 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type57 0
        (ref.cast (ref $type57)
         (local.get $4)
        )
       )
      )
      (struct.get $type102 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (local.set $3
       (struct.new $type57
        (local.get $6)
        (struct.new $type58
         (local.get $3)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (if
     (ref.test (ref $type56)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type58 0
      (struct.get $type57 1
       (ref.cast (ref $type57)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function310
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function312 (type $call148) (param $0 (ref $type149)) (param $1 (ref $type55)) (result (ref $type28))
  (local $2 (ref $type57))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (global.get $empty29)
   )
   (else
    (if
     (ref.test (ref $type56)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type30
     (call_ref $call149
      (struct.get $type149 1
       (local.get $0)
      )
      (struct.get $type57 0
       (local.tee $2
        (ref.cast (ref $type57)
         (local.get $1)
        )
       )
      )
      (struct.get $type149 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (i32.eqz
        (global.get $ready699)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global699)
       )
      )
      (struct.new $type31
       (block (result (ref $type28))
        (local.set $scratch
         (call $function312
          (local.get $0)
          (struct.get $type58 0
           (struct.get $type57 1
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function319 (type $42) (param $0 (ref $environment319)) (param $1 (ref $type44)) (param $2 (ref $type55)) (result i64)
  (local $3 (ref $type201))
  (local $4 (ref $type90))
  (local $5 (ref $type141))
  (local $6 (ref $type203))
  (local $7 (ref $type143))
  (local $8 (ref $type163))
  (local $9 (ref $type44))
  (local.set $7
   (struct.new $type143
    (ref.func $function320)
    (struct.new $environment320
     (local.tee $6
      (struct.get $environment319 0
       (local.get $0)
      )
     )
     (local.tee $3
      (struct.get $environment319 1
       (local.get $0)
      )
     )
     (local.tee $4
      (struct.get $environment319 2
       (local.get $0)
      )
     )
     (struct.get $environment319 3
      (local.get $0)
     )
     (local.tee $5
      (struct.get $environment319 4
       (local.get $0)
      )
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global722)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global730)
   )
  )
  (local.set $9
   (call $function326
    (struct.new $type185
     (ref.func $function324)
     (struct.new $environment324
      (local.get $1)
      (local.tee $8
       (struct.get $type203 1
        (local.get $6)
       )
      )
     )
    )
    (struct.new_default $type186)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global730)
   )
  )
  (local.set $1
   (call $function326
    (struct.new $type185
     (ref.func $function330)
     (struct.new $environment330
      (local.get $1)
      (local.get $8)
     )
    )
    (struct.new_default $type186)
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global561)
   )
  )
  (local.set $1
   (call $function249
    (struct.new $type103
     (ref.func $function332)
     (struct.new $environment332
      (struct.get $type201 1
       (local.get $3)
      )
      (local.get $9)
      (local.get $1)
     )
    )
    (i32.const 0)
    (i32.const 1)
    (global.get $empty45)
    (struct.get $type201 0
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global568)
   )
  )
  (return_call_ref $call141
   (struct.get $type141 1
    (local.get $5)
   )
   (call $function251
    (local.get $7)
    (local.get $1)
   )
   (struct.get $type141 0
    (local.get $5)
   )
  )
 )
 (func $function320 (type $call143) (param $0 (ref struct)) (param $1 (ref $type33)) (result i64)
  (local $2 (ref $environment320))
  (local $3 (ref $type55))
  (local $4 (ref $type203))
  (local $5 (ref $type57))
  (local.set $4
   (struct.get $environment320 0
    (local.tee $2
     (ref.cast (ref $environment320)
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global719)
   )
  )
  (if
   (i32.eqz
    (global.get $ready709)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global709)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type56)
     (local.tee $3
      (struct.get $environment320 6
       (local.get $2)
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type56)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (return_call $function319
     (struct.new $environment319
      (local.get $4)
      (struct.get $environment320 1
       (local.get $2)
      )
      (struct.new $type92
       (struct.new $type89
        (struct.get $environment320 5
         (local.get $2)
        )
        (local.get $1)
       )
       (struct.new $type93
        (struct.get $environment320 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment320 3
       (local.get $2)
      )
      (struct.get $environment320 4
       (local.get $2)
      )
     )
     (struct.get $type57 0
      (local.tee $5
       (ref.cast (ref $type57)
        (local.get $3)
       )
      )
     )
     (struct.get $type58 0
      (struct.get $type57 1
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function324 (type $call185) (param $0 (ref struct)) (param $1 (ref $type89)) (result i32)
  (local $2 (ref $environment324))
  (i64.eqz
   (call $function274
    (struct.get $type163 0
     (struct.get $environment324 1
      (local.tee $2
       (ref.cast (ref $environment324)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type89 0
     (local.get $1)
    )
    (struct.get $environment324 0
     (local.get $2)
    )
   )
  )
 )
 (func $function326 (type $31) (param $0 (ref $type185)) (param $1 (ref $type186)) (param $2 i32) (param $3 i32) (param $4 (ref $type44)) (param $5 (ref $type90)) (result (ref $type44))
  (local $6 (ref $type46))
  (local $7 (ref $type89))
  (drop
   (ref.as_non_null
    (global.get $global737)
   )
  )
  (if (result (ref $type45))
   (if (result i32)
    (ref.test (ref $type91)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type92)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global537)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result (ref $type45))
     (if (result i32)
      (ref.test (ref $type45)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty45)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function235
       (struct.new $environment235
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type46)
          (local.get $4)
         )
        )
        (global.get $empty45)
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type91)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call185
      (struct.get $type185 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type92 0
        (ref.cast (ref $type92)
         (local.get $5)
        )
       )
      )
      (struct.get $type185 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (local.set $4
       (struct.new $type46
        (struct.get $type89 1
         (local.get $7)
        )
        (struct.new $type47
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global743)
     )
    )
    (if
     (ref.test (ref $type91)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type93 0
      (struct.get $type92 1
       (ref.cast (ref $type92)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function326
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function330 (type $call185) (param $0 (ref struct)) (param $1 (ref $type89)) (result i32)
  (local $2 (ref $environment330))
  (i64.eq
   (call $function274
    (struct.get $type163 0
     (struct.get $environment330 1
      (local.tee $2
       (ref.cast (ref $environment330)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type89 0
     (local.get $1)
    )
    (struct.get $environment330 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function332 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $type44))
  (local $3 (ref $environment332))
  (local $4 (ref $type46))
  (local $5 (ref $type103))
  (drop
   (ref.as_non_null
    (global.get $global554)
   )
  )
  (drop
   (struct.get $type102 1
    (global.get $global157)
   )
  )
  (local.set $5
   (struct.new $type103
    (ref.func $function333)
    (struct.new $environment333
     (struct.get $environment332 0
      (local.tee $3
       (ref.cast (ref $environment332)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type45)
      (local.tee $2
       (struct.get $environment332 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type46)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global162)
      )
     )
     (if
      (ref.test (ref $type45)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function246
      (struct.new $environment246
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
      )
      (struct.get $type47 0
       (struct.get $type46 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global554)
     )
    )
    (drop
     (struct.get $type102 1
      (global.get $global157)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type45)
       (local.tee $2
        (struct.get $environment332 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type46)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global162)
       )
      )
      (if
       (ref.test (ref $type45)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function246
       (struct.new $environment246
        (struct.new $type103
         (ref.func $function334)
         (struct.new $environment334
          (struct.get $environment332 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type46)
          (local.get $2)
         )
        )
       )
       (struct.get $type47 0
        (struct.get $type46 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function333 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $environment333))
  (local $3 i64)
  (return_call $function41
   (call $function158
    (struct.get $type161 0
     (struct.get $environment333 0
      (local.tee $2
       (ref.cast (ref $environment333)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment333 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function334 (type $call103) (param $0 structref) (param $1 (ref $type33)) (result i32)
  (local $2 (ref $environment334))
  (local $3 i64)
  (return_call $function41
   (call $function158
    (struct.get $type161 0
     (struct.get $environment334 0
      (local.tee $2
       (ref.cast (ref $environment334)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment334 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function339 (type $call226) (param $0 (ref $type203)) (param $1 (ref $type203)) (param $2 (ref $type96)) (param $3 (ref $type55)) (param $4 (ref $type227)) (param $5 (ref $type141)) (result i64)
  (local $6 (ref $type44))
  (local $7 (ref $type57))
  (local $8 (ref $type149))
  (local $9 (ref $type163))
  (local $10 (ref $type55))
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type56)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type57)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type56)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global281)
     )
    )
    (local.set $8
     (struct.new $type149
      (ref.func $function341)
      (struct.new $environment341
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.tee $6
        (struct.get $type57 0
         (local.tee $7
          (ref.cast (ref $type57)
           (local.get $3)
          )
         )
        )
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $7)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global770)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global778)
     )
    )
    (local.set $3
     (call $function347
      (struct.new $type188
       (ref.func $function345)
       (struct.new $environment345
        (local.get $6)
        (local.tee $9
         (struct.get $type203 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type189)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global778)
     )
    )
    (local.set $10
     (call $function347
      (struct.new $type188
       (ref.func $function351)
       (struct.new $environment351
        (local.get $6)
        (local.get $9)
       )
      )
      (struct.new_default $type189)
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global692)
     )
    )
    (local.set $3
     (call $function310
      (struct.new $type102
       (ref.func $function353)
       (struct.new $environment353
        (struct.get $type203 1
         (local.get $1)
        )
        (local.get $3)
        (local.get $10)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (global.get $empty56)
      (struct.get $type203 0
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global699)
     )
    )
    (return_call_ref $call141
     (struct.get $type141 1
      (local.get $5)
     )
     (call $function312
      (local.get $8)
      (local.get $3)
     )
     (struct.get $type141 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function341 (type $call149) (param $0 (ref struct)) (param $1 (ref $type44)) (result i64)
  (local $2 (ref $environment341))
  (local $3 (ref $type203))
  (return_call $function339
   (struct.get $environment341 0
    (local.tee $2
     (ref.cast (ref $environment341)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type203))
    (drop
     (ref.as_non_null
      (global.get $global767)
     )
    )
    (if
     (i32.eqz
      (global.get $ready757)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global757)
     )
    )
    (struct.get $environment341 1
     (local.get $2)
    )
   )
   (struct.new $type98
    (struct.new $type95
     (struct.get $environment341 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type99
     (struct.get $environment341 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment341 6
    (local.get $2)
   )
   (struct.get $environment341 3
    (local.get $2)
   )
   (struct.get $environment341 4
    (local.get $2)
   )
  )
 )
 (func $function345 (type $call188) (param $0 (ref struct)) (param $1 (ref $type95)) (result i32)
  (local $2 (ref $environment345))
  (i64.eqz
   (call $function274
    (struct.get $type163 0
     (struct.get $environment345 1
      (local.tee $2
       (ref.cast (ref $environment345)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type95 0
     (local.get $1)
    )
    (struct.get $environment345 0
     (local.get $2)
    )
   )
  )
 )
 (func $function347 (type $17) (param $0 (ref $type188)) (param $1 (ref $type189)) (param $2 i32) (param $3 i32) (param $4 (ref $type55)) (param $5 (ref $type96)) (result (ref $type55))
  (local $6 (ref $type57))
  (local $7 (ref $type95))
  (drop
   (ref.as_non_null
    (global.get $global785)
   )
  )
  (if (result (ref $type56))
   (if (result i32)
    (ref.test (ref $type97)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type98)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global668)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (if (result (ref $type56))
     (if (result i32)
      (ref.test (ref $type56)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (global.get $empty56)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function296
       (struct.new $environment296
        (struct.new_default $type248)
        (local.tee $6
         (ref.cast (ref $type57)
          (local.get $4)
         )
        )
        (global.get $empty56)
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type97)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call188
      (struct.get $type188 1
       (local.get $0)
      )
      (local.tee $7
       (struct.get $type98 0
        (ref.cast (ref $type98)
         (local.get $5)
        )
       )
      )
      (struct.get $type188 0
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (local.set $4
       (struct.new $type57
        (struct.get $type95 1
         (local.get $7)
        )
        (struct.new $type58
         (local.get $4)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global791)
     )
    )
    (if
     (ref.test (ref $type97)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type99 0
      (struct.get $type98 1
       (ref.cast (ref $type98)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function347
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function351 (type $call188) (param $0 (ref struct)) (param $1 (ref $type95)) (result i32)
  (local $2 (ref $environment351))
  (i64.eq
   (call $function274
    (struct.get $type163 0
     (struct.get $environment351 1
      (local.tee $2
       (ref.cast (ref $environment351)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type95 0
     (local.get $1)
    )
    (struct.get $environment351 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function353 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $type55))
  (local $3 (ref $environment353))
  (local $4 (ref $type57))
  (local $5 (ref $type102))
  (drop
   (ref.as_non_null
    (global.get $global685)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global276)
   )
  )
  (local.set $5
   (struct.new $type102
    (ref.func $function354)
    (struct.new $environment354
     (struct.get $environment353 0
      (local.tee $3
       (ref.cast (ref $environment353)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type56)
      (local.tee $2
       (struct.get $environment353 1
        (local.get $3)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type57)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global281)
      )
     )
     (if
      (ref.test (ref $type56)
       (local.get $2)
      )
      (then
       (unreachable)
      )
     )
     (call $function307
      (struct.new $environment307
       (local.get $5)
       (struct.new_default $type248)
       (local.tee $4
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
      )
      (struct.get $type58 0
       (struct.get $type57 1
        (local.get $4)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global685)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global276)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type56)
       (local.tee $2
        (struct.get $environment353 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type57)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global281)
       )
      )
      (if
       (ref.test (ref $type56)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function307
       (struct.new $environment307
        (struct.new $type102
         (ref.func $function355)
         (struct.new $environment355
          (struct.get $environment353 0
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (struct.new_default $type248)
        (local.tee $4
         (ref.cast (ref $type57)
          (local.get $2)
         )
        )
       )
       (struct.get $type58 0
        (struct.get $type57 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function354 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $environment354))
  (local $3 i64)
  (return_call $function41
   (call $function274
    (struct.get $type163 0
     (struct.get $environment354 0
      (local.tee $2
       (ref.cast (ref $environment354)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment354 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global121)
    )
   )
  )
 )
 (func $function355 (type $call102) (param $0 structref) (param $1 (ref $type44)) (result i32)
  (local $2 (ref $environment355))
  (local $3 i64)
  (return_call $function41
   (call $function274
    (struct.get $type163 0
     (struct.get $environment355 0
      (local.tee $2
       (ref.cast (ref $environment355)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment355 1
     (local.get $2)
    )
   )
   (block (result (ref $type30))
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (ref.as_non_null
     (global.get $global122)
    )
   )
  )
 )
 (func $function356 (type $call139) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type282))
  (local $3 (ref $type157))
  (local $4 i64)
  (if
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (struct.get $type157 1
      (global.get $global802)
     )
    )
    (local.set $4
     (call $foreign0
      (global.get $global799)
     )
    )
    (local.set $4
     (call $function47
      (struct.get $type139 1
       (global.get $global125)
      )
      (local.get $4)
     )
    )
    (struct.set $type282 1
     (local.tee $2
      (struct.new_default $type282)
     )
     (struct.new $type157
      (ref.func $function359)
      (struct.new $environment359
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type282 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type282 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call157
     (struct.get $type157 1
      (local.tee $3
       (ref.as_non_null
        (struct.get $type282 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 1)
     (local.get $4)
     (struct.get $type157 0
      (local.get $3)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function357 (type $call157) (param $0 (ref null $environment359)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function359 (type $call157) (param $0 (ref null $environment359)) (param $1 i64) (param $2 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment359 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type157 1
      (global.get $global802)
     )
    )
    (drop
     (struct.get $environment359 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global799)
     )
    )
    (local.set $1
     (call $function47
      (struct.get $type139 1
       (global.get $global125)
      )
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type282 0
       (struct.get $environment359 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function359
     (struct.get $type157 1
      (struct.get $type282 1
       (struct.get $environment359 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready800)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function356
   (struct.get $type139 1
    (global.get $global800)
   )
   (local.get $0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type27)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global151
   (struct.new_default $type32)
  )
  (global.set $global184
   (struct.new_default $type37)
  )
  (global.set $global235
   (struct.new_default $type43)
  )
  (global.set $global296
   (struct.new_default $type48)
  )
  (global.set $global347
   (struct.new_default $type54)
  )
  (global.set $global420
   (struct.new_default $type59)
  )
  (global.set $global466
   (struct.new_default $type65)
  )
  (global.set $global514
   (struct.new_default $type71)
  )
  (global.set $global608
   (struct.new_default $type77)
  )
  (global.set $global645
   (struct.new_default $type82)
  )
  (global.set $global719
   (struct.new_default $type88)
  )
  (global.set $global767
   (struct.new_default $type94)
  )
  (global.set $global109
   (struct.new $type100
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $global143
   (struct.new_default $type101)
  )
  (global.set $global157
   (struct.new $type102
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $global167
   (struct.new $type103
    (ref.func $function68)
    (ref.null none)
   )
  )
  (global.set $global265
   (struct.new_default $type104)
  )
  (global.set $global276
   (struct.new_default $type105)
  )
  (global.set $global438
   (struct.new_default $type106)
  )
  (global.set $global484
   (struct.new_default $type107)
  )
  (global.set $global532
   (struct.new_default $type108)
  )
  (global.set $global584
   (struct.new_default $type109)
  )
  (global.set $global663
   (struct.new_default $type110)
  )
  (global.set $global737
   (struct.new_default $type111)
  )
  (global.set $global785
   (struct.new_default $type112)
  )
  (global.set $global115
   (struct.new_default $type113)
  )
  (global.set $global149
   (struct.new_default $type114)
  )
  (global.set $global162
   (struct.new_default $type115)
  )
  (global.set $global172
   (struct.new_default $type116)
  )
  (global.set $global271
   (struct.new_default $type117)
  )
  (global.set $global281
   (struct.new_default $type118)
  )
  (global.set $global444
   (struct.new_default $type119)
  )
  (global.set $global490
   (struct.new_default $type120)
  )
  (global.set $global547
   (struct.new_default $type121)
  )
  (global.set $global589
   (struct.new_default $type122)
  )
  (global.set $global678
   (struct.new_default $type123)
  )
  (global.set $global743
   (struct.new_default $type124)
  )
  (global.set $global791
   (struct.new_default $type125)
  )
  (global.set $global208
   (struct.new_default $type126)
  )
  (global.set $global320
   (struct.new_default $type127)
  )
  (global.set $global543
   (struct.new_default $type128)
  )
  (global.set $global674
   (struct.new_default $type129)
  )
  (global.set $global140
   (struct.new_default $type130)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global231
   (struct.new_default $type132)
  )
  (global.set $ready231
   (i32.const 1)
  )
  (global.set $global262
   (struct.new_default $type134)
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global343
   (struct.new_default $type136)
  )
  (global.set $ready343
   (i32.const 1)
  )
  (global.set $global384
   (struct.new_default $type138)
  )
  (global.set $ready384
   (i32.const 1)
  )
  (global.set $global402
   (struct.new_default $type140)
  )
  (global.set $ready402
   (i32.const 1)
  )
  (global.set $global568
   (struct.new_default $type142)
  )
  (global.set $ready568
   (i32.const 1)
  )
  (global.set $global577
   (struct.new_default $type144)
  )
  (global.set $ready577
   (i32.const 1)
  )
  (global.set $global604
   (struct.new_default $type146)
  )
  (global.set $ready604
   (i32.const 1)
  )
  (global.set $global699
   (struct.new_default $type148)
  )
  (global.set $ready699
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type150)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global283
   (struct.new_default $type151)
  )
  (global.set $ready283
   (i32.const 1)
  )
  (global.set $global591
   (struct.new_default $type152)
  )
  (global.set $ready591
   (i32.const 1)
  )
  (global.set $global155
   (struct.new $type153
    (ref.func $function64)
   )
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global274
   (struct.new $type154
    (ref.func $function119)
   )
  )
  (global.set $ready274
   (i32.const 1)
  )
  (global.set $global582
   (struct.new $type155
    (ref.func $function259)
   )
  )
  (global.set $ready582
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type156)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (global.set $global117
   (struct.new $type30
    (i64.const 0)
    (struct.new $type31
     (struct.new $type30
      (i64.const 1)
      (struct.new $type31
       (global.get $empty29)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (global.set $global121
   (struct.new $type30
    (i64.const 0)
    (struct.new $type31
     (struct.new $type30
      (i64.const 1)
      (struct.new $type31
       (global.get $empty29)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (global.set $global122
   (struct.new $type30
    (i64.const 2)
    (struct.new $type31
     (struct.new $type30
      (i64.const 1)
      (struct.new $type31
       (global.get $empty29)
      )
     )
    )
   )
  )
  (global.set $global802
   (struct.new $type157
    (ref.func $function357)
    (ref.null none)
   )
  )
  (global.set $global238
   (struct.new_default $type158)
  )
  (global.set $global350
   (struct.new_default $type160)
  )
  (global.set $global611
   (struct.new_default $type162)
  )
  (global.set $global224
   (struct.new_default $type164)
  )
  (global.set $global336
   (struct.new_default $type166)
  )
  (global.set $global561
   (struct.new_default $type167)
  )
  (global.set $global692
   (struct.new_default $type168)
  )
  (global.set $global202
   (struct.new_default $type113)
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global314
   (struct.new_default $type116)
  )
  (global.set $ready314
   (i32.const 1)
  )
  (global.set $global537
   (struct.new_default $type115)
  )
  (global.set $ready537
   (i32.const 1)
  )
  (global.set $global668
   (struct.new_default $type118)
  )
  (global.set $ready668
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type169)
  )
  (global.set $global307
   (struct.new_default $type171)
  )
  (global.set $global431
   (struct.new_default $type173)
  )
  (global.set $global477
   (struct.new_default $type176)
  )
  (global.set $global525
   (struct.new_default $type179)
  )
  (global.set $global656
   (struct.new_default $type181)
  )
  (global.set $global730
   (struct.new_default $type184)
  )
  (global.set $global778
   (struct.new_default $type187)
  )
  (global.set $global217
   (struct.new_default $type190)
  )
  (global.set $global329
   (struct.new_default $type191)
  )
  (global.set $global554
   (struct.new_default $type192)
  )
  (global.set $global685
   (struct.new_default $type193)
  )
  (global.set $global187
   (struct.new_default $type194)
  )
  (global.set $global299
   (struct.new_default $type196)
  )
  (global.set $global423
   (struct.new_default $type198)
  )
  (global.set $global469
   (struct.new_default $type199)
  )
  (global.set $global517
   (struct.new_default $type200)
  )
  (global.set $global648
   (struct.new_default $type202)
  )
  (global.set $global722
   (struct.new_default $type204)
  )
  (global.set $global770
   (struct.new_default $type205)
  )
  (global.set $global174
   (struct.new_default $type206)
  )
  (global.set $ready174
   (i32.const 1)
  )
  (global.set $global286
   (struct.new_default $type208)
  )
  (global.set $ready286
   (i32.const 1)
  )
  (global.set $global374
   (struct.new_default $type210)
  )
  (global.set $ready374
   (i32.const 1)
  )
  (global.set $global392
   (struct.new_default $type212)
  )
  (global.set $ready392
   (i32.const 1)
  )
  (global.set $global410
   (struct.new_default $type214)
  )
  (global.set $ready410
   (i32.const 1)
  )
  (global.set $global456
   (struct.new_default $type216)
  )
  (global.set $ready456
   (i32.const 1)
  )
  (global.set $global504
   (struct.new_default $type218)
  )
  (global.set $ready504
   (i32.const 1)
  )
  (global.set $global594
   (struct.new_default $type220)
  )
  (global.set $ready594
   (i32.const 1)
  )
  (global.set $global635
   (struct.new_default $type222)
  )
  (global.set $ready635
   (i32.const 1)
  )
  (global.set $global709
   (struct.new_default $type224)
  )
  (global.set $ready709
   (i32.const 1)
  )
  (global.set $global757
   (struct.new_default $type226)
  )
  (global.set $ready757
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type228)
  )
  (global.set $global258
   (struct.new_default $type229)
  )
  (global.set $global573
   (struct.new_default $type230)
  )
  (global.set $global370
   (struct.new_default $type231)
  )
  (global.set $global388
   (struct.new_default $type232)
  )
  (global.set $global406
   (struct.new_default $type233)
  )
  (global.set $global452
   (struct.new_default $type234)
  )
  (global.set $global500
   (struct.new_default $type235)
  )
  (global.set $global631
   (struct.new_default $type236)
  )
  (global.set $global705
   (struct.new_default $type237)
  )
  (global.set $global753
   (struct.new_default $type238)
  )
  (global.set $global123
   (struct.new $type141
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready123
   (i32.const 1)
  )
  (global.set $global125
   (struct.new $type139
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $global799
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global800
   (struct.new $type139
    (ref.func $function356)
    (ref.null none)
   )
  )
  (global.set $ready800
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

