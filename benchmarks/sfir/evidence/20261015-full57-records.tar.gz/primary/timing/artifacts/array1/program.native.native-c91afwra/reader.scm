(module
 (rec
  (type $environment57 (struct (field i64) (field (ref $type37))))
  (type $environment53 (struct (field i64) (field (ref $type37))))
  (type $type37 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $call27 (func (param structref i64 i64) (result i64)))
  (type $environment49 (struct (field (ref $type29)) (field (ref $type29)) (field (ref $type34))))
  (type $environment43 (struct (field i64) (field (ref $type32)) (field (ref $type34))))
  (type $type32 (struct (field (ref $type29))))
  (type $type29 (array (mut i64)))
  (type $type34 (struct (field (mut i32)) (field (mut (ref null $type28)))))
  (type $call28 (func (param structref i64) (result (ref $type29))))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type28 (struct (field (ref $call28)) (field structref)))
  (type $type27 (struct (field (ref $call27)) (field structref)))
 )
 (type $14 (func (param i64) (result i64)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type27)) (ref.null none))
 (global $global106 (mut (ref null $type28)) (ref.null none))
 (global $global111 (mut (ref null $type30)) (ref.null none))
 (global $global117 (mut (ref null $type31)) (ref.null none))
 (global $global129 (mut (ref null $type27)) (ref.null none))
 (global $global119 (mut i64) (i64.const 0))
 (global $global120 (mut i64) (i64.const 0))
 (global $global121 (mut (ref null $type31)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call28) (param $0 structref) (param $1 i64) (result (ref $type29))
  (local $2 (ref $type34))
  (local $3 (ref $type28))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 1
   (local.tee $2
    (struct.new_default $type34)
   )
   (struct.new $type28
    (ref.func $function43)
    (struct.new $environment43
     (local.get $1)
     (struct.new $type32
      (array.new_default $type29
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type34 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type34 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call28
   (struct.get $type28 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type34 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type28 0
    (local.get $3)
   )
  )
 )
 (func $function43 (type $call28) (param $0 structref) (param $1 i64) (result (ref $type29))
  (local $2 (ref $environment43))
  (local $3 i64)
  (if (result (ref $type29))
   (i64.le_s
    (struct.get $environment43 0
     (local.tee $2
      (ref.cast (ref $environment43)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type32 0
     (struct.get $environment43 1
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type32 0
      (struct.get $environment43 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment43 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type28 1
      (struct.get $type34 1
       (struct.get $environment43 2
        (local.get $2)
       )
      )
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function49 (type $call28) (param $0 structref) (param $1 i64) (result (ref $type29))
  (local $2 (ref $environment49))
  (local $3 (ref $type29))
  (local $4 i64)
  (if (result (ref $type29))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.get $environment49 1
     (ref.cast (ref $environment49)
      (local.get $0)
     )
    )
   )
   (else
    (array.set $type29
     (struct.get $environment49 1
      (local.tee $2
       (ref.cast (ref $environment49)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type29
        (struct.get $environment49 0
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment49 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (struct.get $type28 1
      (struct.get $type34 1
       (struct.get $environment49 2
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function53 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type37))
  (local $4 (ref $type27))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment53 0
     (ref.cast (ref $environment53)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global126)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global119)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global126)
     )
    )
    (local.set $5
     (call $foreign0
      (global.get $global120)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global129)
     )
    )
    (struct.set $type37 1
     (local.tee $3
      (struct.new_default $type37)
     )
     (struct.new $type27
      (ref.func $function57)
      (struct.new $environment57
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type37 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call27
      (struct.get $type27 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type37 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (i64.const 0)
      (struct.get $type27 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment53 1
        (ref.cast (ref $environment53)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function53
     (struct.get $type27 1
      (struct.get $type37 1
       (struct.get $environment53 1
        (ref.cast (ref $environment53)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function54 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function55 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type37))
  (local $4 (ref $type27))
  (struct.set $type37 1
   (local.tee $3
    (struct.new_default $type37)
   )
   (struct.new $type27
    (ref.func $function57)
    (struct.new $environment57
     (local.get $2)
     (local.get $3)
    )
   )
  )
  (struct.set $type37 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $4
     (ref.as_non_null
      (struct.get $type37 1
       (local.get $3)
      )
     )
    )
   )
   (local.get $1)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $4)
   )
  )
 )
 (func $function57 (type $call27) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type34))
  (local $4 (ref $type28))
  (local $5 (ref $environment57))
  (local $6 (ref $type29))
  (if (result i64)
   (i64.gt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (drop
     (struct.get $type28 1
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (struct.get $environment57 0
        (local.tee $5
         (ref.cast (ref $environment57)
          (local.get $0)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 1
     (local.tee $3
      (struct.new_default $type34)
     )
     (struct.new $type28
      (ref.func $function43)
      (struct.new $environment43
       (local.get $1)
       (struct.new $type32
        (array.new_default $type29
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type34 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type34 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type28 0
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 1
     (local.tee $3
      (struct.new_default $type34)
     )
     (struct.new $type28
      (ref.func $function49)
      (struct.new $environment49
       (local.get $6)
       (array.new_default $type29
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type34 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (i64.extend_i32_u
      (array.len
       (call_ref $call28
        (struct.get $type28 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type34 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
        (struct.get $type28 0
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment57 1
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (struct.get $type27 1
      (struct.get $type37 1
       (struct.get $environment57 1
        (local.get $5)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type37))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (struct.set $type37 1
   (local.tee $1
    (struct.new_default $type37)
   )
   (struct.new $type27
    (ref.func $function53)
    (struct.new $environment53
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type37 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type37 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global126
   (struct.new $type27
    (ref.func $function54)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new $type28
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $global111
   (struct.new_default $type30)
  )
  (global.set $global117
   (struct.new_default $type31)
  )
  (global.set $global129
   (struct.new $type27
    (ref.func $function55)
    (ref.null none)
   )
  )
  (global.set $global119
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global120
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global121
   (struct.new_default $type31)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

