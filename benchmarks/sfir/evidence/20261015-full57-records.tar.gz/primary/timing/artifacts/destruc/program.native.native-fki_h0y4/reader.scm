(module
 (rec
  (type $type36 (sub (struct)))
  (type $type27 (sub (struct)))
  (type $type31 (sub (struct)))
  (type $type90 (struct (field (ref $environment94))))
  (type $type92 (struct (field (mut i32)) (field (mut (ref null $type90)))))
  (type $environment94 (struct (field i64) (field (ref $type92))))
  (type $call90 (func (param (ref $environment94) i64 (ref $type36)) (result i64)))
  (type $7 (func (param (ref $environment89) (ref $type27)) (result (ref $type55))))
  (type $environment89 (struct (field i64)))
  (type $9 (func (param i64) (result (ref null $type57))))
  (type $call62 (func (result (ref $type27))))
  (type $call85 (func (param (ref $environment72) (ref $type31) i64) (result i64)))
  (type $environment80 (struct (field i64) (field (ref $type79))))
  (type $environment75 (struct (field i64) (field (ref $type79))))
  (type $type85 (struct (field (ref $environment72))))
  (type $environment72 (struct (field (ref $type87))))
  (type $type87 (struct (field (mut i32)) (field (mut (ref null $type85)))))
  (type $call72 (func (param (ref $environment69) (ref $type36) (ref $type36)) (result i32)))
  (type $call59 (func (param (ref null $environment66) (ref $type31) (ref $type31)) (result (ref $type31))))
  (type $environment66 (struct (field (ref $type33)) (field (ref $type31)) (field (ref $type81))))
  (type $call77 (func (param (ref struct) i64 (ref $type31)) (result (ref $type31))))
  (type $environment63 (struct (field (ref $type79))))
  (type $type77 (struct (field (ref $call77)) (field (ref struct))))
  (type $type81 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $type79 (struct (field (mut i32)) (field (mut (ref null $type77)))))
  (type $call74 (func (param (ref $environment59) (ref $type36)) (result i32)))
  (type $type72 (struct (field (ref $environment69))))
  (type $environment69 (struct (field i64) (field (ref $type82))))
  (type $type74 (struct (field (ref $environment59))))
  (type $environment59 (struct (field i64) (field (ref $type76))))
  (type $type82 (struct (field (mut i32)) (field (mut (ref null $type72)))))
  (type $type76 (struct (field (mut i32)) (field (mut (ref null $type74)))))
  (type $call69 (func (param (ref $environment57) i64) (result (ref $type36))))
  (type $33 (func (param (ref $type38)) (result (ref $type38))))
  (type $call66 (func (param (ref $environment53) i64 (ref $type38)) (result (ref $type36))))
  (type $type69 (struct (field (ref $environment57))))
  (type $environment57 (struct (field i64) (field (ref $type36)) (field (ref $type71))))
  (type $type66 (struct (field (ref $environment53))))
  (type $type71 (struct (field (mut i32)) (field (mut (ref null $type69)))))
  (type $type68 (struct (field (mut i32)) (field (mut (ref null $type66)))))
  (type $environment53 (struct (field (ref $type68))))
  (type $call60 (func (param i64 i64) (result (ref $type36))))
  (type $type39 (struct (field (ref $type36))))
  (type $type38 (sub $type36 (struct (field (ref $type35)) (field (ref $type39)))))
  (type $call56 (func (param (ref $type36) (ref null $type57)) (result i32)))
  (type $type35 (struct (field (mut (ref $type31)))))
  (type $type29 (sub $type27 (struct (field i64))))
  (type $type34 (struct (field (mut (ref $type27)))))
  (type $type55 (struct (field (ref $type27)) (field (ref null $type55))))
  (type $type33 (sub $type31 (struct (field (ref $type34)) (field (ref $type35)))))
  (type $call54 (func (param (ref $type31) (ref null $type55)) (result i32)))
  (type $type65 (struct))
  (type $type57 (struct (field (ref null $type55)) (field (ref null $type57))))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type5 (struct))
  (type $type61 (struct (field (mut i64))))
  (type $type60 (struct))
  (type $type59 (struct (field (ref $call59)) (field (ref null $environment66))))
  (type $type58 (struct))
  (type $type56 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type30 (struct))
  (type $type37 (sub $type36 (struct)))
  (type $type32 (sub $type31 (struct)))
  (type $type28 (sub $type27 (struct)))
 )
 (type $81 (func (param i64) (result i64)))
 (type $82 (func (param i32) (result i64)))
 (type $83 (func))
 (import "benchmark" "expected_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "hide_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty28 (ref $type28) (struct.new_default $type28))
 (global $empty32 (ref $type32) (struct.new_default $type32))
 (global $empty37 (ref $type37) (struct.new_default $type37))
 (global $global106 (mut (ref null $type28)) (ref.null none))
 (global $global144 (mut (ref null $type30)) (ref.null none))
 (global $global152 (mut (ref null $type40)) (ref.null none))
 (global $global117 (mut (ref null $type41)) (ref.null none))
 (global $global129 (mut (ref null $type42)) (ref.null none))
 (global $global122 (mut (ref null $type43)) (ref.null none))
 (global $global134 (mut (ref null $type44)) (ref.null none))
 (global $global124 (mut (ref null $type45)) (ref.null none))
 (global $global136 (mut (ref null $type46)) (ref.null none))
 (global $global155 (mut (ref null $type47)) (ref.null none))
 (global $global183 (mut (ref null $type48)) (ref.null none))
 (global $global167 (mut (ref null $type49)) (ref.null none))
 (global $global107 (mut (ref null $type50)) (ref.null none))
 (global $global190 (mut (ref null $type51)) (ref.null none))
 (global $global173 (mut (ref null $type52)) (ref.null none))
 (global $global111 (mut (ref null $type53)) (ref.null none))
 (global $global114 (mut (ref null $type54)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type56)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global209 (mut (ref null $type58)) (ref.null none))
 (global $global161 (mut (ref null $type59)) (ref.null none))
 (global $global138 (mut (ref null $type60)) (ref.null none))
 (global $global193 (mut (ref null $type61)) (ref.null none))
 (global $global194 (mut (ref null $type5)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global196 (mut (ref null $type62)) (ref.null none))
 (global $global203 (mut (ref null $type63)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global201 (mut (ref null $type64)) (ref.null none))
 (global $ready201 (mut i32) (i32.const 0))
 (global $global197 (mut i64) (i64.const 0))
 (global $global198 (mut i64) (i64.const 0))
 (global $global199 (mut i32) (i32.const 0))
 (global $global200 (mut (ref null $type57)) (ref.null none))
 (global $global207 (mut (ref null $type65)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function43 (type $call54) (param $0 (ref $type31)) (param $1 (ref null $type55)) (result i32)
  (local $2 (ref $type27))
  (local $3 (ref $type27))
  (local $4 (ref $type33))
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global111)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type55 0
        (local.get $1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global107)
       )
      )
      (if (result i32)
       (if (result i32)
        (if (result i32)
         (ref.test (ref $type28)
          (local.tee $3
           (struct.get $type34 0
            (struct.get $type33 0
             (local.tee $4
              (ref.cast (ref $type33)
               (local.get $0)
              )
             )
            )
           )
          )
         )
         (then
          (i32.const 1)
         )
         (else
          (drop
           (ref.cast (ref $type29)
            (local.get $3)
           )
          )
          (i32.const 0)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global107)
          )
         )
         (if (result i32)
          (ref.test (ref $type28)
           (local.get $2)
          )
          (then
           (i32.const 1)
          )
          (else
           (drop
            (ref.cast (ref $type29)
             (local.get $2)
            )
           )
           (i32.const 0)
          )
         )
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global107)
          )
         )
         (if (result i32)
          (if (result i32)
           (ref.test (ref $type28)
            (local.get $2)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.cast (ref $type29)
              (local.get $2)
             )
            )
            (i32.const 0)
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (ref.test (ref $type28)
             (local.get $3)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type29 0
             (ref.cast (ref $type29)
              (local.get $3)
             )
            )
           )
           (if
            (ref.test (ref $type28)
             (local.get $2)
            )
            (then
             (unreachable)
            )
           )
           (i64.eq
            (struct.get $type29 0
             (ref.cast (ref $type29)
              (local.get $2)
             )
            )
            (local.get $5)
           )
          )
         )
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global124)
         )
        )
        (local.set $1
         (struct.get $type55 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready114)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global114)
         )
        )
        (return_call $function43
         (struct.get $type35 0
          (struct.get $type33 1
           (local.get $4)
          )
         )
         (local.get $1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call56) (param $0 (ref $type36)) (param $1 (ref null $type57)) (result i32)
  (local $2 (ref $type38))
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type37)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type38)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global114)
       )
      )
      (if
       (ref.test (ref $type37)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (call $function43
        (struct.get $type35 0
         (struct.get $type38 0
          (local.tee $2
           (ref.cast (ref $type38)
            (local.get $0)
           )
          )
         )
        )
        (struct.get $type57 0
         (local.get $1)
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global136)
         )
        )
        (local.set $1
         (struct.get $type57 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready126)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (return_call $function47
         (struct.get $type39 0
          (struct.get $type38 1
           (local.get $2)
          )
         )
         (local.get $1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $call60) (param $0 i64) (param $1 i64) (result (ref $type36))
  (local $2 (ref $environment53))
  (local $3 (ref $type68))
  (local $4 (ref $type71))
  (local $5 (ref $type38))
  (struct.set $type68 1
   (local.tee $3
    (struct.new_default $type68)
   )
   (struct.new $type66
    (struct.new $environment53
     (local.get $3)
    )
   )
  )
  (struct.set $type68 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (local.get $3)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global144)
   )
  )
  (local.set $5
   (struct.new $type38
    (struct.new $type35
     (global.get $empty32)
    )
    (struct.new $type39
     (struct.new $type38
      (struct.new $type35
       (global.get $empty32)
      )
      (struct.new $type39
       (struct.new $type38
        (struct.new $type35
         (global.get $empty32)
        )
        (struct.new $type39
         (struct.new $type38
          (struct.new $type35
           (global.get $empty32)
          )
          (struct.new $type39
           (struct.new $type38
            (struct.new $type35
             (global.get $empty32)
            )
            (struct.new $type39
             (struct.new $type38
              (struct.new $type35
               (global.get $empty32)
              )
              (struct.new $type39
               (struct.new $type38
                (struct.new $type35
                 (global.get $empty32)
                )
                (struct.new $type39
                 (struct.new $type38
                  (struct.new $type35
                   (global.get $empty32)
                  )
                  (struct.new $type39
                   (struct.new $type38
                    (struct.new $type35
                     (global.get $empty32)
                    )
                    (struct.new $type39
                     (struct.new $type38
                      (struct.new $type35
                       (global.get $empty32)
                      )
                      (struct.new $type39
                       (global.get $empty37)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type68 0
     (struct.get $environment53 0
      (local.tee $2
       (struct.get $type66 0
        (struct.get $type68 1
         (struct.get $environment53 0
          (local.get $2)
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type66 0
    (struct.get $type68 1
     (struct.get $environment53 0
      (local.get $2)
     )
    )
   )
  )
  (struct.set $type71 1
   (local.tee $4
    (struct.new_default $type71)
   )
   (struct.new $type69
    (struct.new $environment57
     (local.get $1)
     (local.get $5)
     (local.get $4)
    )
   )
  )
  (struct.set $type71 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type71 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function57
   (struct.get $type69 0
    (struct.get $type71 1
     (local.get $4)
    )
   )
   (local.get $0)
  )
 )
 (func $function57 (type $call69) (param $0 (ref $environment57)) (param $1 i64) (result (ref $type36))
  (local $2 (ref $type36))
  (local $3 (ref $type36))
  (local $4 (ref $type76))
  (local $5 (ref $type82))
  (local $6 (ref $type31))
  (local $7 i64)
  (if (result (ref $type36))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $environment57 1
     (local.get $0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.tee $2
       (struct.get $environment57 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (if (result i32)
       (ref.test (ref $type32)
        (local.tee $6
         (struct.get $type35 0
          (struct.get $type38 0
           (ref.cast (ref $type38)
            (local.get $2)
           )
          )
         )
        )
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type33)
          (local.get $6)
         )
        )
        (i32.const 0)
       )
      )
      (then
       (struct.set $type76 1
        (local.tee $4
         (struct.new_default $type76)
        )
        (struct.new $type74
         (struct.new $environment59
          (struct.get $environment57 0
           (local.get $0)
          )
          (local.get $4)
         )
        )
       )
       (struct.set $type76 0
        (local.get $4)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type76 0
          (local.get $4)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function59
        (struct.get $type74 0
         (struct.get $type76 1
          (local.get $4)
         )
        )
        (local.get $2)
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global136)
        )
       )
       (if
        (ref.test (ref $type37)
         (local.tee $2
          (struct.get $environment57 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type39 0
         (struct.get $type38 1
          (ref.cast (ref $type38)
           (local.get $2)
          )
         )
        )
       )
       (struct.set $type82 1
        (local.tee $5
         (struct.new_default $type82)
        )
        (struct.new $type72
         (struct.new $environment69
          (local.get $1)
          (local.get $5)
         )
        )
       )
       (struct.set $type82 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type82 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function69
        (struct.get $type72 0
         (struct.get $type82 1
          (local.get $5)
         )
        )
        (local.get $2)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type71 0
       (struct.get $environment57 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (struct.get $type69 0
      (struct.get $type71 1
       (struct.get $environment57 2
        (local.get $0)
       )
      )
     )
     (local.get $7)
    )
   )
  )
 )
 (func $function59 (type $call74) (param $0 (ref $environment59)) (param $1 (ref $type36)) (result i32)
  (local $2 (ref $type31))
  (local $3 (ref $type31))
  (local $4 (ref $type79))
  (local $5 (ref $type81))
  (local $6 (ref $type33))
  (local $7 (ref $type77))
  (local $8 (ref $type59))
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type37)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type38)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (ref.test (ref $type32)
       (local.tee $2
        (struct.get $type35 0
         (struct.get $type38 0
          (ref.cast (ref $type38)
           (local.get $1)
          )
         )
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global152)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (if
       (ref.test (ref $type37)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type35 0
       (struct.get $type38 0
        (ref.cast (ref $type38)
         (local.get $1)
        )
       )
       (struct.new $type33
        (struct.new $type34
         (ref.as_non_null
          (global.get $global106)
         )
        )
        (struct.new $type35
         (global.get $empty32)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type35 0
      (struct.get $type38 0
       (ref.cast (ref $type38)
        (local.get $1)
       )
      )
     )
    )
    (struct.set $type79 1
     (local.tee $4
      (struct.new_default $type79)
     )
     (struct.new $type77
      (ref.func $function63)
      (struct.new $environment63
       (local.get $4)
      )
     )
    )
    (struct.set $type79 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call_ref $call77
      (struct.get $type77 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type79 1
          (local.get $4)
         )
        )
       )
      )
      (struct.get $environment59 0
       (local.get $0)
      )
      (global.get $empty32)
      (struct.get $type77 0
       (local.get $7)
      )
     )
    )
    (drop
     (struct.get $type59 1
      (global.get $global161)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (drop
     (if (result (ref $type31))
      (if (result i32)
       (ref.test (ref $type32)
        (local.get $2)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type33)
          (local.get $2)
         )
        )
        (i32.const 0)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global124)
        )
       )
       (if
        (ref.test (ref $type32)
         (local.get $2)
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type35 0
         (struct.get $type33 1
          (local.tee $6
           (ref.cast (ref $type33)
            (local.get $2)
           )
          )
         )
        )
       )
       (struct.set $type81 1
        (local.tee $5
         (struct.new_default $type81)
        )
        (struct.new $type59
         (ref.func $function66)
         (struct.new $environment66
          (local.get $6)
          (local.get $3)
          (local.get $5)
         )
        )
       )
       (struct.set $type81 0
        (local.get $5)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type81 0
          (local.get $5)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call59
        (struct.get $type59 1
         (local.tee $8
          (ref.as_non_null
           (struct.get $type81 1
            (local.get $5)
           )
          )
         )
        )
        (local.get $6)
        (local.get $2)
        (struct.get $type59 0
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type39 0
      (struct.get $type38 1
       (ref.cast (ref $type38)
        (local.get $1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type76 0
       (struct.get $environment59 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type74 0
      (struct.get $type76 1
       (struct.get $environment59 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $function63 (type $call77) (param $0 (ref struct)) (param $1 i64) (param $2 (ref $type31)) (result (ref $type31))
  (local $3 i64)
  (local $4 (ref $type33))
  (if (result (ref $type31))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (local.set $4
     (struct.new $type33
      (struct.new $type34
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (struct.new $type35
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (struct.get $environment63 0
        (ref.cast (ref $environment63)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (struct.get $type77 1
      (struct.get $type79 1
       (struct.get $environment63 0
        (ref.cast (ref $environment63)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function64 (type $call59) (param $0 (ref null $environment66)) (param $1 (ref $type31)) (param $2 (ref $type31)) (result (ref $type31))
  (local $3 (ref $type81))
  (local $4 (ref $type33))
  (local $5 (ref $type59))
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if (result (ref $type31))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type35 0
      (struct.get $type33 1
       (local.tee $4
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
      )
     )
    )
    (struct.set $type81 1
     (local.tee $3
      (struct.new_default $type81)
     )
     (struct.new $type59
      (ref.func $function66)
      (struct.new $environment66
       (local.get $4)
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.set $type81 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call59
     (struct.get $type59 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type81 1
         (local.get $3)
        )
       )
      )
     )
     (local.get $4)
     (local.get $1)
     (struct.get $type59 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function66 (type $call59) (param $0 (ref null $environment66)) (param $1 (ref $type31)) (param $2 (ref $type31)) (result (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if (result (ref $type33))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $2)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (local.set $2
     (struct.get $environment66 1
      (local.get $0)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type35 0
     (struct.get $type33 1
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (struct.get $environment66 0
     (local.get $0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type35 0
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type81 0
       (struct.get $environment66 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (struct.get $type59 1
      (struct.get $type81 1
       (struct.get $environment66 2
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
  )
 )
 (func $function69 (type $call72) (param $0 (ref $environment69)) (param $1 (ref $type36)) (param $2 (ref $type36)) (result i32)
  (local $3 (ref $type31))
  (local $4 (ref $type31))
  (local $5 (ref $type87))
  (local $6 (ref $type79))
  (local $7 (ref $type38))
  (local $8 (ref $type77))
  (local $9 i64)
  (local $10 i64)
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type37)
     (local.get $2)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type38)
       (local.get $2)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global173)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type35 0
      (struct.get $type38 0
       (ref.cast (ref $type38)
        (local.get $1)
       )
      )
     )
    )
    (struct.set $type87 1
     (local.tee $5
      (struct.new_default $type87)
     )
     (struct.new $type85
      (struct.new $environment72
       (local.get $5)
      )
     )
    )
    (struct.set $type87 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type87 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (struct.get $environment69 0
      (local.get $0)
     )
    )
    (local.set $4
     (if (result (ref $type31))
      (i64.eqz
       (local.tee $9
        (i64.div_s
         (call $function72
          (struct.get $type85 0
           (struct.get $type87 1
            (local.get $5)
           )
          )
          (local.get $3)
          (i64.const 0)
         )
         (i64.const 2)
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global155)
        )
       )
       (if
        (ref.test (ref $type37)
         (local.get $1)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type35 0
        (struct.get $type38 0
         (local.tee $7
          (ref.cast (ref $type38)
           (local.get $1)
          )
         )
        )
        (global.get $empty32)
       )
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (struct.get $type35 0
        (struct.get $type38 0
         (local.get $7)
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (if
        (ref.test (ref $type37)
         (local.get $1)
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type35 0
         (struct.get $type38 0
          (ref.cast (ref $type38)
           (local.get $1)
          )
         )
        )
       )
       (struct.set $type79 1
        (local.tee $6
         (struct.new_default $type79)
        )
        (struct.new $type77
         (ref.func $function75)
         (struct.new $environment75
          (local.get $10)
          (local.get $6)
         )
        )
       )
       (struct.set $type79 0
        (local.get $6)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type79 0
          (local.get $6)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call77
        (struct.get $type77 1
         (local.tee $8
          (ref.as_non_null
           (struct.get $type79 1
            (local.get $6)
           )
          )
         )
        )
        (local.get $9)
        (local.get $3)
        (struct.get $type77 0
         (local.get $8)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global173)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type35 0
      (struct.get $type38 0
       (local.tee $7
        (ref.cast (ref $type38)
         (local.get $2)
        )
       )
      )
     )
    )
    (struct.set $type87 1
     (local.tee $5
      (struct.new_default $type87)
     )
     (struct.new $type85
      (struct.new $environment72
       (local.get $5)
      )
     )
    )
    (struct.set $type87 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type87 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.div_s
      (call $function72
       (struct.get $type85 0
        (struct.get $type87 1
         (local.get $5)
        )
       )
       (local.get $3)
       (i64.const 0)
      )
      (i64.const 2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (local.set $3
     (struct.get $type35 0
      (struct.get $type38 0
       (local.get $7)
      )
     )
    )
    (struct.set $type79 1
     (local.tee $6
      (struct.new_default $type79)
     )
     (struct.new $type77
      (ref.func $function80)
      (struct.new $environment80
       (local.get $10)
       (local.get $6)
      )
     )
    )
    (struct.set $type79 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call_ref $call77
      (struct.get $type77 1
       (local.tee $8
        (ref.as_non_null
         (struct.get $type79 1
          (local.get $6)
         )
        )
       )
      )
      (local.get $9)
      (local.get $3)
      (struct.get $type77 0
       (local.get $8)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type35 0
     (struct.get $type33 1
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
     (local.get $4)
    )
    (drop
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (if
     (ref.test (ref $type37)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type39 0
      (struct.get $type38 1
       (ref.cast (ref $type38)
        (local.get $1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global136)
     )
    )
    (if
     (i32.eqz
      (struct.get $type82 0
       (struct.get $environment69 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (struct.get $type72 0
      (struct.get $type82 1
       (struct.get $environment69 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (struct.get $type39 0
      (struct.get $type38 1
       (local.get $7)
      )
     )
    )
   )
  )
 )
 (func $function72 (type $call85) (param $0 (ref $environment72)) (param $1 (ref $type31)) (param $2 i64) (result i64)
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type35 0
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $1)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type87 0
       (struct.get $environment72 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function72
     (struct.get $type85 0
      (struct.get $type87 1
       (struct.get $environment72 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function75 (type $call77) (param $0 (ref struct)) (param $1 i64) (param $2 (ref $type31)) (result (ref $type31))
  (local $3 (ref $type33))
  (local $4 (ref $type29))
  (local $5 i64)
  (local $scratch (ref $type31))
  (if (result (ref $type31))
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (struct.get $type35 0
      (struct.get $type33 1
       (local.tee $3
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (struct.set $type35 0
     (struct.get $type33 1
      (local.get $3)
     )
     (global.get $empty32)
    )
    (local.get $scratch)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (local.set $4
     (struct.new $type29
      (struct.get $environment75 0
       (ref.cast (ref $environment75)
        (local.get $0)
       )
      )
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 0
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $2)
      )
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type35 0
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (struct.get $type77 1
      (struct.get $type79 1
       (struct.get $environment75 1
        (ref.cast (ref $environment75)
         (local.get $0)
        )
       )
      )
     )
     (local.get $5)
     (local.get $2)
    )
   )
  )
 )
 (func $function80 (type $call77) (param $0 (ref struct)) (param $1 i64) (param $2 (ref $type31)) (result (ref $type31))
  (local $3 (ref $type29))
  (local $4 i64)
  (drop
   (ref.as_non_null
    (global.get $global190)
   )
  )
  (if (result (ref $type31))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (local.set $3
     (struct.new $type29
      (struct.get $environment80 0
       (ref.cast (ref $environment80)
        (local.get $0)
       )
      )
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type34 0
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $2)
      )
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type35 0
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type79 0
       (struct.get $environment80 1
        (ref.cast (ref $environment80)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function80
     (struct.get $type77 1
      (struct.get $type79 1
       (struct.get $environment80 1
        (ref.cast (ref $environment80)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function86 (type $call62) (result (ref $type27))
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type61))
  (local $scratch i64)
  (local $scratch_5 i64)
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (if (result (ref $type27))
   (i64.eqz
    (block (result i64)
     (local.set $scratch
      (call $foreign0
       (struct.get $type61 0
        (global.get $global193)
       )
      )
     )
     (local.set $0
      (i64.add
       (local.tee $2
        (struct.get $type61 0
         (local.tee $3
          (ref.as_non_null
           (global.get $global193)
          )
         )
        )
       )
       (i64.const 1)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $0)
         (local.get $2)
        )
        (i64.xor
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (struct.set $type61 0
      (local.get $3)
      (local.get $0)
     )
     (local.get $scratch)
    )
   )
   (then
    (ref.as_non_null
     (global.get $global106)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global194)
     )
    )
    (struct.new $type29
     (block (result i64)
      (local.set $scratch_5
       (call $foreign0
        (struct.get $type61 0
         (global.get $global193)
        )
       )
      )
      (local.set $0
       (i64.add
        (local.tee $2
         (struct.get $type61 0
          (local.tee $3
           (ref.as_non_null
            (global.get $global193)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $0)
          (local.get $2)
         )
         (i64.xor
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type61 0
       (local.get $3)
       (local.get $0)
      )
      (local.get $scratch_5)
     )
    )
   )
  )
 )
 (func $function87 (type $9) (param $0 i64) (result (ref null $type57))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type27))
  (local $5 (ref $type61))
  (local $6 (ref null $type55))
  (if (result (ref null $type57))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global194)
     )
    )
    (local.set $1
     (call $foreign0
      (struct.get $type61 0
       (global.get $global193)
      )
     )
    )
    (local.set $2
     (i64.add
      (local.tee $3
       (struct.get $type61 0
        (local.tee $5
         (ref.as_non_null
          (global.get $global193)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type61 0
     (local.get $5)
     (local.get $2)
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (struct.new $type57
     (if (result (ref null $type55))
      (i64.eqz
       (local.get $1)
      )
      (then
       (ref.null none)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global196)
        )
       )
       (struct.new $type55
        (call $function86)
        (block (result (ref null $type55))
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $2
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (local.get $1)
            )
            (i64.xor
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (global.get $ready203)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global203)
          )
         )
         (if (result (ref null $type55))
          (i64.eqz
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global196)
            )
           )
           (struct.new $type55
            (call $function86)
            (block (result (ref null $type55))
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $1
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (local.get $2)
                )
                (i64.xor
                 (local.get $2)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (global.get $ready203)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if (result (ref null $type55))
              (i64.eqz
               (local.get $1)
              )
              (then
               (ref.null none)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global196)
                )
               )
               (struct.new $type55
                (call $function86)
                (block (result (ref null $type55))
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $2
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (local.get $1)
                    )
                    (i64.xor
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready203)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global203)
                  )
                 )
                 (if (result (ref null $type55))
                  (i64.eqz
                   (local.get $2)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global196)
                    )
                   )
                   (struct.new $type55
                    (call $function86)
                    (block (result (ref null $type55))
                     (if
                      (i64.lt_s
                       (i64.and
                        (i64.xor
                         (local.tee $1
                          (i64.sub
                           (local.get $2)
                           (i64.const 1)
                          )
                         )
                         (local.get $2)
                        )
                        (i64.xor
                         (local.get $2)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready203)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global203)
                      )
                     )
                     (if (result (ref null $type55))
                      (i64.eqz
                       (local.get $1)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global196)
                        )
                       )
                       (struct.new $type55
                        (call $function86)
                        (block (result (ref null $type55))
                         (if
                          (i64.lt_s
                           (i64.and
                            (i64.xor
                             (local.get $1)
                             (local.tee $2
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                            )
                            (i64.xor
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (i64.const 0)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready203)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global203)
                          )
                         )
                         (if (result (ref null $type55))
                          (i64.eqz
                           (local.get $2)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global196)
                            )
                           )
                           (struct.new $type55
                            (call $function86)
                            (block (result (ref null $type55))
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.get $2)
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $2)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (i64.xor
                                 (local.get $2)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready203)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global203)
                              )
                             )
                             (if (result (ref null $type55))
                              (i64.eqz
                               (local.get $1)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global196)
                                )
                               )
                               (struct.new $type55
                                (call $function86)
                                (block (result (ref null $type55))
                                 (if
                                  (i64.lt_s
                                   (i64.and
                                    (i64.xor
                                     (local.get $1)
                                     (local.tee $2
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                    (i64.xor
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                   (i64.const 0)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready203)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global203)
                                  )
                                 )
                                 (if (result (ref null $type55))
                                  (i64.eqz
                                   (local.get $2)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global196)
                                    )
                                   )
                                   (struct.new $type55
                                    (call $function86)
                                    (block (result (ref null $type55))
                                     (if
                                      (i64.lt_s
                                       (i64.and
                                        (i64.xor
                                         (local.get $2)
                                         (local.tee $1
                                          (i64.sub
                                           (local.get $2)
                                           (i64.const 1)
                                          )
                                         )
                                        )
                                        (i64.xor
                                         (local.get $2)
                                         (i64.const 1)
                                        )
                                       )
                                       (i64.const 0)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready203)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global203)
                                      )
                                     )
                                     (if (result (ref null $type55))
                                      (i64.eqz
                                       (local.get $1)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global196)
                                        )
                                       )
                                       (struct.new $type55
                                        (call $function86)
                                        (block (result (ref null $type55))
                                         (if
                                          (i64.lt_s
                                           (i64.and
                                            (i64.xor
                                             (local.get $1)
                                             (local.tee $2
                                              (i64.sub
                                               (local.get $1)
                                               (i64.const 1)
                                              )
                                             )
                                            )
                                            (i64.xor
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                           (i64.const 0)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready203)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global203)
                                          )
                                         )
                                         (if (result (ref null $type55))
                                          (i64.eqz
                                           (local.get $2)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global196)
                                            )
                                           )
                                           (struct.new $type55
                                            (call $function86)
                                            (block (result (ref null $type55))
                                             (if
                                              (i64.lt_s
                                               (i64.and
                                                (i64.xor
                                                 (local.get $2)
                                                 (local.tee $1
                                                  (i64.sub
                                                   (local.get $2)
                                                   (i64.const 1)
                                                  )
                                                 )
                                                )
                                                (i64.xor
                                                 (local.get $2)
                                                 (i64.const 1)
                                                )
                                               )
                                               (i64.const 0)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready203)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global203)
                                              )
                                             )
                                             (if (result (ref null $type55))
                                              (i64.eqz
                                               (local.get $1)
                                              )
                                              (then
                                               (ref.null none)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global196)
                                                )
                                               )
                                               (struct.new $type55
                                                (call $function86)
                                                (block (result (ref null $type55))
                                                 (if
                                                  (i64.lt_s
                                                   (i64.and
                                                    (i64.xor
                                                     (local.get $1)
                                                     (local.tee $2
                                                      (i64.sub
                                                       (local.get $1)
                                                       (i64.const 1)
                                                      )
                                                     )
                                                    )
                                                    (i64.xor
                                                     (local.get $1)
                                                     (i64.const 1)
                                                    )
                                                   )
                                                   (i64.const 0)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready203)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global203)
                                                  )
                                                 )
                                                 (if (result (ref null $type55))
                                                  (i64.eqz
                                                   (local.get $2)
                                                  )
                                                  (then
                                                   (ref.null none)
                                                  )
                                                  (else
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global196)
                                                    )
                                                   )
                                                   (struct.new $type55
                                                    (call $function86)
                                                    (block (result (ref null $type55))
                                                     (if
                                                      (i64.lt_s
                                                       (i64.and
                                                        (i64.xor
                                                         (local.get $2)
                                                         (local.tee $3
                                                          (i64.sub
                                                           (local.get $2)
                                                           (i64.const 1)
                                                          )
                                                         )
                                                        )
                                                        (i64.xor
                                                         (local.get $2)
                                                         (i64.const 1)
                                                        )
                                                       )
                                                       (i64.const 0)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready203)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global203)
                                                      )
                                                     )
                                                     (if (result (ref null $type55))
                                                      (i64.eqz
                                                       (local.get $3)
                                                      )
                                                      (then
                                                       (ref.null none)
                                                      )
                                                      (else
                                                       (drop
                                                        (ref.as_non_null
                                                         (global.get $global196)
                                                        )
                                                       )
                                                       (struct.new $type55
                                                        (call $function86)
                                                        (block (result (ref null $type55))
                                                         (if
                                                          (i64.lt_s
                                                           (i64.and
                                                            (i64.xor
                                                             (local.get $3)
                                                             (local.tee $1
                                                              (i64.sub
                                                               (local.get $3)
                                                               (i64.const 1)
                                                              )
                                                             )
                                                            )
                                                            (i64.xor
                                                             (local.get $3)
                                                             (i64.const 1)
                                                            )
                                                           )
                                                           (i64.const 0)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready203)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global203)
                                                          )
                                                         )
                                                         (if (result (ref null $type55))
                                                          (i64.eqz
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (ref.null none)
                                                          )
                                                          (else
                                                           (drop
                                                            (ref.as_non_null
                                                             (global.get $global196)
                                                            )
                                                           )
                                                           (struct.new $type55
                                                            (call $function86)
                                                            (block (result (ref null $type55))
                                                             (if
                                                              (i64.lt_s
                                                               (i64.and
                                                                (i64.xor
                                                                 (local.get $1)
                                                                 (local.tee $2
                                                                  (i64.sub
                                                                   (local.get $1)
                                                                   (i64.const 1)
                                                                  )
                                                                 )
                                                                )
                                                                (i64.xor
                                                                 (local.get $1)
                                                                 (i64.const 1)
                                                                )
                                                               )
                                                               (i64.const 0)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (if
                                                              (i32.eqz
                                                               (global.get $ready203)
                                                              )
                                                              (then
                                                               (unreachable)
                                                              )
                                                             )
                                                             (drop
                                                              (ref.as_non_null
                                                               (global.get $global203)
                                                              )
                                                             )
                                                             (if (result (ref null $type55))
                                                              (i64.eqz
                                                               (local.get $2)
                                                              )
                                                              (then
                                                               (ref.null none)
                                                              )
                                                              (else
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global196)
                                                                )
                                                               )
                                                               (call $function89
                                                                (struct.new $environment89
                                                                 (local.get $2)
                                                                )
                                                                (call $function86)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (block (result (ref null $type57))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready201)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global201)
       )
      )
      (call $function87
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function89 (type $7) (param $0 (ref $environment89)) (param $1 (ref $type27)) (result (ref $type55))
  (local $2 i64)
  (local $3 i64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $3
       (i64.sub
        (local.tee $2
         (struct.get $environment89 0
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (local.get $2)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready203)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global203)
   )
  )
  (struct.new $type55
   (local.get $1)
   (if (result (ref null $type55))
    (i64.eqz
     (local.get $3)
    )
    (then
     (ref.null none)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global196)
      )
     )
     (call $function89
      (struct.new $environment89
       (local.get $3)
      )
      (call $function86)
     )
    )
   )
  )
 )
 (func $function94 (type $call90) (param $0 (ref $environment94)) (param $1 i64) (param $2 (ref $type36)) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment94 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (local.set $2
     (call $function51
      (call $foreign1
       (global.get $global197)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global209)
        )
       )
       (local.set $scratch
        (call $foreign1
         (global.get $global198)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type92 0
       (struct.get $environment94 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function94
     (struct.get $type90 0
      (struct.get $type92 1
       (struct.get $environment94 1
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (global.get $global199)
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (call $function47
         (local.get $2)
         (global.get $global200)
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type92))
  (local $2 (ref $type36))
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready207)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global207)
   )
  )
  (if (result i64)
   (i64.le_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i64.extend_i32_u
     (i32.ne
      (global.get $global199)
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (local.set $2
     (call $function51
      (call $foreign1
       (global.get $global197)
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global209)
        )
       )
       (local.set $scratch
        (call $foreign1
         (global.get $global198)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global138)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (struct.set $type92 1
     (local.tee $1
      (struct.new_default $type92)
     )
     (struct.new $type90
      (struct.new $environment94
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (struct.set $type92 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type92 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function94
     (struct.get $type90 0
      (struct.get $type92 1
       (local.get $1)
      )
     )
     (i64.const 1)
     (local.get $2)
    )
   )
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref $type61))
  (local $scratch i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (global.get $empty28)
  )
  (global.set $global144
   (struct.new_default $type30)
  )
  (global.set $global152
   (struct.new_default $type40)
  )
  (global.set $global117
   (struct.new_default $type41)
  )
  (global.set $global129
   (struct.new_default $type42)
  )
  (global.set $global122
   (struct.new_default $type43)
  )
  (global.set $global134
   (struct.new_default $type44)
  )
  (global.set $global124
   (struct.new_default $type45)
  )
  (global.set $global136
   (struct.new_default $type46)
  )
  (global.set $global155
   (struct.new_default $type47)
  )
  (global.set $global183
   (struct.new_default $type48)
  )
  (global.set $global167
   (struct.new_default $type49)
  )
  (global.set $global107
   (struct.new_default $type50)
  )
  (global.set $global190
   (struct.new_default $type51)
  )
  (global.set $global173
   (struct.new_default $type52)
  )
  (global.set $global111
   (struct.new_default $type53)
  )
  (global.set $global114
   (struct.new_default $type54)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type56)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global209
   (struct.new_default $type58)
  )
  (global.set $global161
   (struct.new $type59
    (ref.func $function64)
    (ref.null none)
   )
  )
  (global.set $global138
   (struct.new_default $type60)
  )
  (global.set $global193
   (struct.new_default $type61)
  )
  (global.set $global194
   (struct.new_default $type5)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global196
   (struct.new_default $type62)
  )
  (global.set $global203
   (struct.new_default $type63)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global201
   (struct.new_default $type64)
  )
  (global.set $ready201
   (i32.const 1)
  )
  (global.set $global197
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $global198
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $global199
   (i64.eq
    (call $foreign2
     (i32.const 2)
    )
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready194)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global194)
   )
  )
  (global.set $global200
   (call $function87
    (block (result i64)
     (local.set $scratch
      (call $foreign0
       (struct.get $type61 0
        (global.get $global193)
       )
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $0
          (i64.add
           (local.tee $2
            (struct.get $type61 0
             (local.tee $3
              (ref.as_non_null
               (global.get $global193)
              )
             )
            )
           )
           (i64.const 1)
          )
         )
         (local.get $2)
        )
        (i64.xor
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (struct.set $type61 0
      (local.get $3)
      (local.get $0)
     )
     (if
      (i32.eqz
       (global.get $ready201)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global201)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (global.set $global207
   (struct.new_default $type65)
  )
  (global.set $ready207
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

