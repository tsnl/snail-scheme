#define OBSERVE_BARRIERS 0
#ifndef BENCHMARK_CASE_CONFIG
#define BENCHMARK_CASE_CONFIG
#include <stdint.h>
static const int64_t input_integers[] = {600, 50, 0};
static const double input_reals[] = {600, 50, 0};
static const int64_t vector_integers[] = {0};
static const double vector_reals[] = {0};
static const int64_t expected_integers[] = {10, 3, 1, 1, 1, 1, 1, 2, 3, 1, 1, 1, 1, 1, 1, 4, 1, 1, 1, 1, 1, 1, 1, 2, 4, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 21, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 3};
static const double expected_reals[] = {10, 3, 1, 1, 1, 1, 1, 2, 3, 1, 1, 1, 1, 1, 1, 4, 1, 1, 1, 1, 1, 1, 1, 2, 4, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 21, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 3};
static const int64_t vector_sizes[] = {0, 0, 0};
static const int64_t vector_offsets[] = {0, 0, 0};
static const int64_t configured_count = 4000;
static const int64_t expected_size = 131;
static const int64_t expected_setup = 0;
static const int64_t expected_barriers = 8000;
static const int64_t expected_setup_closed = -1;
static const int64_t expected_worker_closed = -1;
static const int64_t expected_result = 1;
static const double expected_tolerance = 0;
#define FLOAT_RESULT 0
#define CONFIGURED_COUNT 0
static const char *diagnostic_text[] = {""};
static const char *diagnostic_prefix[] = {""};
static const char *diagnostic_suffix[] = {""};
static const uint32_t path_characters[] = {0};
static const int64_t path_sizes[] = {0};
static const int64_t path_offsets[] = {0};
#define PATH_ARGUMENTS -1
#endif
