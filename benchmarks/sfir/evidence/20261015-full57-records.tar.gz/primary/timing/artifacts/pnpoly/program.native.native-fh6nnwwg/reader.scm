(module
 (rec
  (type $call47 (func (param (ref $environment60) i32 i64 i64) (result i32)))
  (type $1 (func (param (ref null $type13) i32 i32 i32 (ref null $type12) i64) (result (ref $type13))))
  (type $2 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $3 (func (param (ref $type13) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
  (type $type42 (struct (field (ref $environment48))))
  (type $type44 (struct (field (mut i32)) (field (mut (ref null $type42)))))
  (type $type47 (struct (field (ref $environment60))))
  (type $environment60 (struct (field (ref $type13)) (field (ref $type13)) (field f64) (field f64) (field (ref $type49))))
  (type $environment48 (struct (field i64) (field (ref $type44))))
  (type $type12 (struct (field f64) (field (ref null $type12))))
  (type $type49 (struct (field (mut i32)) (field (mut (ref null $type47)))))
  (type $call42 (func (param (ref $environment48) i64 i64) (result i64)))
  (type $type39 (struct (field (ref $environment45))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type39)))))
  (type $environment45 (struct (field i32) (field i64) (field (ref $type13)) (field (ref $type41))))
  (type $call39 (func (param (ref $environment45) i64) (result i32)))
  (type $type36 (struct))
  (type $type13 (array (mut f64)))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type11 (struct))
 )
 (type $25 (func (param i32) (result i64)))
 (type $26 (func (param i32 i64) (result f64)))
 (type $27 (func (result i32)))
 (type $28 (func (param i64) (result i64)))
 (type $29 (func))
 (import "benchmark" "vector_length" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "barrier" (func $foreign2 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type11)) (ref.null none))
 (global $global133 (mut (ref null $type16)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type17)) (ref.null none))
 (global $global106 (mut (ref null $type32)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type33)) (ref.null none))
 (global $global144 (mut (ref null $type34)) (ref.null none))
 (global $global122 (mut (ref null $type35)) (ref.null none))
 (global $global112 (mut (ref null $type13)) (ref.null none))
 (global $global113 (mut (ref null $type13)) (ref.null none))
 (global $global114 (mut (ref null $type36)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function45 (type $call39) (param $0 (ref $environment45)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 f64)
  (if (result i32)
   (i64.gt_s
    (struct.get $environment45 1
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (local.set $3
     (call $foreign1
      (struct.get $environment45 0
       (local.get $0)
      )
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (struct.get $environment45 2
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment45 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type39 0
      (struct.get $type41 1
       (struct.get $environment45 3
        (local.get $0)
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function48 (type $call42) (param $0 (ref $environment48)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type49))
  (local $4 (ref null $type12))
  (local $5 (ref null $type12))
  (local $6 (ref $type13))
  (local $7 (ref $type13))
  (local $8 (ref $type13))
  (local $9 (ref $type13))
  (local $10 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment48 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $10
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (local.set $8
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i32.eqz
      (call $foreign2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (local.set $9
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (if
     (i32.eqz
      (call $foreign2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (local.set $5
     (call $function52
      (local.get $8)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $8)
       )
      )
      (ref.null none)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (local.set $6
     (if (result (ref $type13))
      (ref.is_null
       (local.get $5)
      )
      (then
       (array.new_fixed $type13 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready133)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global133)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (if (result i64)
           (ref.is_null
            (local.get $5)
           )
           (then
            (i64.const 0)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $4
               (struct.get $type12 1
                (local.get $5)
               )
              )
             )
             (then
              (i64.const 1)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $4
                 (struct.get $type12 1
                  (local.get $4)
                 )
                )
               )
               (then
                (i64.const 2)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $4
                   (struct.get $type12 1
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (i64.const 3)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $4
                     (struct.get $type12 1
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (i64.const 4)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $4
                       (struct.get $type12 1
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (i64.const 5)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $4
                         (struct.get $type12 1
                          (local.get $4)
                         )
                        )
                       )
                       (then
                        (i64.const 6)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $4
                           (struct.get $type12 1
                            (local.get $4)
                           )
                          )
                         )
                         (then
                          (i64.const 7)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $4
                             (struct.get $type12 1
                              (local.get $4)
                             )
                            )
                           )
                           (then
                            (i64.const 8)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $4
                               (struct.get $type12 1
                                (local.get $4)
                               )
                              )
                             )
                             (then
                              (i64.const 9)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $4
                                 (struct.get $type12 1
                                  (local.get $4)
                                 )
                                )
                               )
                               (then
                                (i64.const 10)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $4
                                   (struct.get $type12 1
                                    (local.get $4)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 11)
                                 )
                                 (else
                                  (if (result i64)
                                   (ref.is_null
                                    (local.tee $4
                                     (struct.get $type12 1
                                      (local.get $4)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 12)
                                   )
                                   (else
                                    (call $function55
                                     (i32.const 0)
                                     (i32.const 1)
                                     (struct.get $type12 1
                                      (local.get $4)
                                     )
                                     (i64.const 13)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (call $function56
        (array.new $type13
         (struct.get $type12 0
          (local.get $5)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (i64.const 0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (local.set $5
     (call $function52
      (local.get $9)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $9)
       )
      )
      (ref.null none)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (local.set $7
     (if (result (ref $type13))
      (ref.is_null
       (local.get $5)
      )
      (then
       (array.new_fixed $type13 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready133)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global133)
        )
       )
       (if
        (i64.gt_u
         (local.tee $1
          (if (result i64)
           (ref.is_null
            (local.get $5)
           )
           (then
            (i64.const 0)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $4
               (struct.get $type12 1
                (local.get $5)
               )
              )
             )
             (then
              (i64.const 1)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $4
                 (struct.get $type12 1
                  (local.get $4)
                 )
                )
               )
               (then
                (i64.const 2)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $4
                   (struct.get $type12 1
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (i64.const 3)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $4
                     (struct.get $type12 1
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (i64.const 4)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $4
                       (struct.get $type12 1
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (i64.const 5)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $4
                         (struct.get $type12 1
                          (local.get $4)
                         )
                        )
                       )
                       (then
                        (i64.const 6)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $4
                           (struct.get $type12 1
                            (local.get $4)
                           )
                          )
                         )
                         (then
                          (i64.const 7)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $4
                             (struct.get $type12 1
                              (local.get $4)
                             )
                            )
                           )
                           (then
                            (i64.const 8)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $4
                               (struct.get $type12 1
                                (local.get $4)
                               )
                              )
                             )
                             (then
                              (i64.const 9)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $4
                                 (struct.get $type12 1
                                  (local.get $4)
                                 )
                                )
                               )
                               (then
                                (i64.const 10)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $4
                                   (struct.get $type12 1
                                    (local.get $4)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 11)
                                 )
                                 (else
                                  (if (result i64)
                                   (ref.is_null
                                    (local.tee $4
                                     (struct.get $type12 1
                                      (local.get $4)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 12)
                                   )
                                   (else
                                    (call $function55
                                     (i32.const 0)
                                     (i32.const 1)
                                     (struct.get $type12 1
                                      (local.get $4)
                                     )
                                     (i64.const 13)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (call $function56
        (array.new $type13
         (struct.get $type12 0
          (local.get $5)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (local.get $5)
        (i64.const 0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.5)
       (f64.const 0.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (i64.extend_i32_u
      (i32.ne
       (call $function60
        (struct.get $type47 0
         (struct.get $type49 1
          (local.get $3)
         )
        )
        (i32.const 0)
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $6)
          )
         )
         (i64.const 1)
        )
        (i64.const 0)
       )
       (i32.const 0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.5)
       (f64.const 1.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -0.5)
       (f64.const 1.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.75)
       (f64.const 2.25)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.0)
       (f64.const 2.01)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -0.5)
       (f64.const 2.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -1.0)
       (f64.const -0.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -1.5)
       (f64.const 0.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -2.25)
       (f64.const -1.0)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.5)
       (f64.const -0.25)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const 0.5)
       (f64.const -1.25)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.set $type49 1
     (local.tee $3
      (struct.new_default $type49)
     )
     (struct.new $type47
      (struct.new $environment60
       (local.get $6)
       (local.get $7)
       (f64.const -0.5)
       (f64.const -2.5)
       (local.get $3)
      )
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call $function60
      (struct.get $type47 0
       (struct.get $type49 1
        (local.get $3)
       )
      )
      (i32.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $6)
        )
       )
       (i64.const 1)
      )
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.add
            (local.tee $2
             (local.get $1)
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment48 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type42 0
      (struct.get $type44 1
       (struct.get $environment48 1
        (local.get $0)
       )
      )
     )
     (local.get $10)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function52 (type $3) (param $0 (ref $type13)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref null $type12)) (result (ref null $type12))
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (array.get $type13
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (struct.new $type12
      (local.get $7)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function55 (type $2) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function55
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function56 (type $1) (param $0 (ref null $type13)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type13))
  (local $6 i64)
  (local $7 f64)
  (if (result (ref $type13))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type13
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function60 (type $call47) (param $0 (ref $environment60)) (param $1 i32) (param $2 i64) (param $3 i64) (result i32)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 i32)
  (local $11 (ref $type13))
  (local $12 (ref $type13))
  (local $13 (ref $type13))
  (if (result i32)
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (struct.get $environment60 0
      (local.get $0)
     )
    )
    (local.set $9
     (struct.get $environment60 2
      (local.get $0)
     )
    )
    (local.set $7
     (local.tee $4
      (struct.get $environment60 3
       (local.get $0)
      )
     )
    )
    (if
     (if (result i32)
      (local.tee $10
       (if (result i32)
        (if (result i32)
         (local.tee $10
          (f64.gt
           (array.get $type13
            (local.tee $11
             (struct.get $environment60 1
              (local.get $0)
             )
            )
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (local.get $4)
          )
         )
         (then
          (local.get $10)
         )
         (else
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (f64.le
           (array.get $type13
            (local.get $11)
            (i32.wrap_i64
             (local.get $3)
            )
           )
           (local.get $4)
          )
         )
        )
        (then
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if (result i32)
          (local.tee $10
           (f64.lt
            (struct.get $environment60 3
             (local.get $0)
            )
            (array.get $type13
             (local.tee $13
              (struct.get $environment60 1
               (local.get $0)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (then
           (local.get $10)
          )
          (else
           (if
            (i64.gt_u
             (local.get $2)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (f64.le
            (array.get $type13
             (local.get $13)
             (i32.wrap_i64
              (local.get $2)
             )
            )
            (local.get $4)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (then
       (local.get $10)
      )
      (else
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $8
        (array.get $type13
         (local.get $12)
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (if
        (i64.gt_u
         (local.get $3)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (f64.sub
         (local.tee $5
          (array.get $type13
           (local.get $12)
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (local.tee $6
          (array.get $type13
           (local.get $12)
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
       (if
        (i32.and
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $5)
           )
           (f64.const inf)
          )
          (f64.lt
           (f64.abs
            (local.get $6)
           )
           (f64.const inf)
          )
         )
         (f64.eq
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (f64.sub
         (local.get $7)
         (local.tee $6
          (array.get $type13
           (local.get $11)
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
       (if
        (i32.and
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $7)
           )
           (f64.const inf)
          )
          (f64.lt
           (f64.abs
            (local.get $6)
           )
           (f64.const inf)
          )
         )
         (f64.eq
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $4)
           )
           (f64.const inf)
          )
          (f64.lt
           (f64.abs
            (local.get $5)
           )
           (f64.const inf)
          )
         )
         (f64.eq
          (f64.abs
           (local.tee $5
            (f64.mul
             (local.get $4)
             (local.get $5)
            )
           )
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $3)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (f64.sub
         (local.tee $7
          (array.get $type13
           (local.get $11)
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (local.tee $6
          (array.get $type13
           (local.get $11)
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
       (if
        (i32.and
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $7)
           )
           (f64.const inf)
          )
          (f64.lt
           (f64.abs
            (local.get $6)
           )
           (f64.const inf)
          )
         )
         (f64.eq
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i32.and
          (i32.and
           (f64.lt
            (f64.abs
             (local.get $5)
            )
            (f64.const inf)
           )
           (f64.lt
            (f64.abs
             (local.get $4)
            )
            (f64.const inf)
           )
          )
          (f64.eq
           (f64.abs
            (local.tee $5
             (f64.div
              (local.get $5)
              (local.get $4)
             )
            )
           )
           (f64.const inf)
          )
         )
         (f64.ne
          (local.get $4)
          (f64.const 0.0)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $8)
           )
           (f64.const inf)
          )
          (f64.lt
           (f64.abs
            (local.get $5)
           )
           (f64.const inf)
          )
         )
         (f64.eq
          (f64.abs
           (local.tee $4
            (f64.add
             (local.get $8)
             (local.get $5)
            )
           )
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (f64.le
        (local.get $4)
        (local.get $9)
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type49 0
         (struct.get $environment60 4
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function60
       (struct.get $type47 0
        (struct.get $type49 1
         (struct.get $environment60 4
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (local.get $3)
       (local.get $2)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type49 0
         (struct.get $environment60 4
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function60
       (struct.get $type47 0
        (struct.get $type49 1
         (struct.get $environment60 4
          (local.get $0)
         )
        )
       )
       (i32.eqz
        (local.get $1)
       )
       (local.get $3)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type44))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (struct.set $type44 1
   (local.tee $1
    (struct.new_default $type44)
   )
   (struct.new $type42
    (struct.new $environment48
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type44 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type44 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function48
   (struct.get $type42 0
    (struct.get $type44 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (local $0 (ref $type41))
  (local $1 (ref $type13))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type11)
  )
  (global.set $global133
   (struct.new_default $type16)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type17)
  )
  (global.set $global106
   (struct.new_default $type32)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type33)
  )
  (global.set $global144
   (struct.new_default $type34)
  )
  (global.set $global122
   (struct.new_default $type35)
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if
   (i64.gt_u
    (local.tee $2
     (call $foreign0
      (i32.const 0)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type41 1
   (local.tee $0
    (struct.new_default $type41)
   )
   (struct.new $type39
    (struct.new $environment45
     (i32.const 0)
     (local.get $2)
     (local.tee $1
      (array.new_default $type13
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type41 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type41 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function45
    (struct.get $type39 0
     (struct.get $type41 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (global.set $global112
   (local.get $1)
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if
   (i64.gt_u
    (local.tee $2
     (call $foreign0
      (i32.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type41 1
   (local.tee $0
    (struct.new_default $type41)
   )
   (struct.new $type39
    (struct.new $environment45
     (i32.const 1)
     (local.get $2)
     (local.tee $1
      (array.new_default $type13
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type41 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type41 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function45
    (struct.get $type39 0
     (struct.get $type41 1
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (global.set $global113
   (local.get $1)
  )
  (global.set $global114
   (struct.new_default $type36)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

