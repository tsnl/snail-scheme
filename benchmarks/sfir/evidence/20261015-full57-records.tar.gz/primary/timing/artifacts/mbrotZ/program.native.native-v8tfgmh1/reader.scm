(module
 (rec
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type31)))))
  (type $environment69 (struct (field i64) (field (ref $type47))))
  (type $call31 (func (param (ref null $environment69) i64 i64) (result i64)))
  (type $3 (func (param (ref $environment62) f64) (result i64)))
  (type $environment62 (struct (field (ref $type28)) (field (ref $type45)) (field (ref $type28)) (field i64)))
  (type $type43 (struct (field (ref $environment61))))
  (type $environment61 (struct (field (ref $type28)) (field (ref $type45))))
  (type $type45 (struct (field (mut i32)) (field (mut (ref null $type43)))))
  (type $environment52 (struct (field (ref $type34)) (field (ref $type28)) (field (ref $type40)) (field i64) (field (ref $type40))))
  (type $environment50 (struct (field (ref $type34)) (field (ref $type28)) (field i64) (field (ref $type40))))
  (type $type38 (struct (field (ref $call38)) (field (ref struct))))
  (type $type40 (struct (field (mut i32)) (field (mut (ref null $type38)))))
  (type $type34 (array (mut (ref $type30))))
  (type $environment47 (struct (field i64) (field (ref $type34)) (field (ref $type40))))
  (type $call38 (func (param (ref struct) i64) (result i32)))
  (type $15 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $type35 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct (field (ref $call31)) (field (ref null $environment69))))
  (type $type30 (array (mut i64)))
  (type $type28 (struct (field f64) (field f64)))
  (type $type29 (struct))
  (type $type27 (struct))
 )
 (type $24 (func (param i64) (result i64)))
 (type $25 (func (param i32) (result i64)))
 (type $26 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global139 (mut (ref null $type29)) (ref.null none))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $global116 (mut (ref null $type28)) (ref.null none))
 (global $global117 (mut (ref null $type30)) (ref.null none))
 (global $global156 (mut (ref null $type31)) (ref.null none))
 (global $global132 (mut (ref null $type32)) (ref.null none))
 (global $global123 (mut (ref null $type33)) (ref.null none))
 (global $global118 (mut (ref null $type35)) (ref.null none))
 (global $global150 (mut i64) (i64.const 0))
 (global $global151 (mut (ref null $type35)) (ref.null none))
 (global $ready151 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $15) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local.set $4
   (f64.add
    (local.tee $2
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (local.tee $3
     (struct.get $type28 0
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $4)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (f64.add
    (local.tee $3
     (struct.get $type28 1
      (local.get $0)
     )
    )
    (local.tee $5
     (struct.get $type28 1
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type28
   (local.get $4)
   (local.get $2)
  )
 )
 (func $function47 (type $call38) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment47))
  (local $3 (ref $type34))
  (local $4 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (array.set $type34
     (struct.get $environment47 1
      (local.tee $2
       (ref.cast (ref $environment47)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment47 0
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (array.new_default $type30
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (struct.get $environment47 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (struct.get $type38 1
      (struct.get $type40 1
       (struct.get $environment47 2
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function50 (type $call38) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type40))
  (local $3 (ref $environment50))
  (local $4 (ref $type38))
  (local $5 i64)
  (local $6 i64)
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.set $6
     (i64.sub
      (local.tee $5
       (struct.get $environment50 2
        (ref.cast (ref $environment50)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.get $6)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type40 1
     (local.tee $2
      (struct.new_default $type40)
     )
     (struct.new $type38
      (ref.func $function52)
      (struct.new $environment52
       (struct.get $environment50 0
        (local.tee $3
         (ref.cast (ref $environment50)
          (local.get $0)
         )
        )
       )
       (struct.get $environment50 1
        (local.get $3)
       )
       (struct.get $environment50 3
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type40 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call38
     (struct.get $type38 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type40 1
         (local.get $2)
        )
       )
      )
     )
     (local.get $6)
     (struct.get $type38 0
      (local.get $4)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function52 (type $call38) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $environment52))
  (local $8 (ref $type45))
  (local $9 (ref $type28))
  (local $10 (ref $type30))
  (local $11 (ref $environment61))
  (if
   (i64.ge_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type30
     (array.get $type34
      (struct.get $environment52 0
       (local.tee $7
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (block (result i32)
      (drop
       (ref.as_non_null
        (global.get $global132)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global139)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (local.set $5
       (f64.convert_i64_s
        (local.tee $2
         (struct.get $environment52 3
          (local.get $7)
         )
        )
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $6
           (f64.mul
            (local.tee $4
             (f64.convert_i64_s
              (local.get $1)
             )
            )
            (f64.const 0.005)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.mul
            (local.get $5)
            (f64.const 0.005)
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $5)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type45 1
       (local.tee $8
        (struct.new_default $type45)
       )
       (struct.new $type43
        (struct.new $environment61
         (local.tee $9
          (call $function41
           (struct.get $environment52 1
            (local.get $7)
           )
           (struct.new $type28
            (local.get $6)
            (local.get $4)
           )
          )
         )
         (local.get $8)
        )
       )
      )
      (struct.set $type45 0
       (local.get $8)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type45 0
         (local.get $8)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function62
        (struct.new $environment62
         (struct.get $environment61 0
          (local.tee $11
           (struct.get $type43 0
            (struct.get $type45 1
             (local.get $8)
            )
           )
          )
         )
         (struct.get $environment61 1
          (local.get $11)
         )
         (local.get $9)
         (i64.const 0)
        )
        (struct.get $type28 0
         (local.get $9)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (local.get $3)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (struct.get $environment52 4
        (local.get $7)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type38 1
      (struct.get $type40 1
       (struct.get $environment52 4
        (local.get $7)
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (local.set $2
     (i64.sub
      (local.tee $1
       (struct.get $environment52 3
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (struct.get $environment52 2
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function50
     (struct.get $type38 1
      (struct.get $type40 1
       (struct.get $environment52 2
        (ref.cast (ref $environment52)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (unreachable)
 )
 (func $function62 (type $3) (param $0 (ref $environment62)) (param $1 f64) (result i64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $environment61))
  (local $10 (ref $type45))
  (local.set $2
   (struct.get $type28 1
    (local.tee $7
     (struct.get $environment62 2
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.get $1)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $1)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.get $2)
        (local.get $2)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.add
        (local.get $3)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $environment62 3
    (local.get $0)
   )
  )
  (if (result i64)
   (f64.gt
    (local.get $1)
    (f64.const 16.0)
   )
   (then
    (local.get $6)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.tee $1
          (struct.get $type28 0
           (local.get $7)
          )
         )
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.mul
          (local.get $1)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.tee $2
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.mul
          (local.get $2)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.sub
          (local.get $3)
          (local.get $4)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.mul
          (local.get $1)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.mul
          (local.get $2)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $1)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $1
         (f64.add
          (local.get $3)
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (call $function41
      (struct.new $type28
       (local.get $4)
       (local.get $1)
      )
      (struct.get $environment62 0
       (local.get $0)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $5
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type45 0
       (local.tee $10
        (struct.get $environment62 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.get $type43 0
      (struct.get $type45 1
       (local.get $10)
      )
     )
    )
    (if (result i64)
     (i64.eq
      (local.get $5)
      (i64.const 64)
     )
     (then
      (local.get $5)
     )
     (else
      (return_call $function62
       (struct.new $environment62
        (struct.get $environment61 0
         (local.get $9)
        )
        (struct.get $environment61 1
         (local.get $9)
        )
        (local.get $8)
        (local.get $5)
       )
       (struct.get $type28 0
        (local.get $8)
       )
      )
     )
    )
   )
  )
 )
 (func $function69 (type $call31) (param $0 (ref null $environment69)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type40))
  (local $4 (ref $type34))
  (local $5 (ref $type38))
  (local $6 (ref $type28))
  (local $7 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment69 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type31 1
      (global.get $global156)
     )
    )
    (drop
     (struct.get $environment69 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global150)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.new $type34
      (ref.as_non_null
       (global.get $global117)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $7
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type40 1
     (local.tee $3
      (struct.new_default $type40)
     )
     (struct.new $type38
      (ref.func $function47)
      (struct.new $environment47
       (local.get $1)
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (struct.set $type40 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call38
      (struct.get $type38 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type40 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $7)
      (struct.get $type38 0
       (local.get $5)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global123)
     )
    )
    (local.set $6
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type40 1
     (local.tee $3
      (struct.new_default $type40)
     )
     (struct.new $type38
      (ref.func $function50)
      (struct.new $environment50
       (local.get $4)
       (local.get $6)
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type40 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call38
      (struct.get $type38 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type40 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $7)
      (struct.get $type38 0
       (local.get $5)
      )
     )
    )
    (local.set $1
     (array.get $type30
      (array.get $type34
       (local.get $4)
       (i32.const 0)
      )
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment69 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (struct.get $type31 1
      (struct.get $type47 1
       (struct.get $environment69 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function70 (type $call31) (param $0 (ref null $environment69)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type47))
  (local $2 (ref $type31))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready151)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global151)
   )
  )
  (if
   (i64.le_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (struct.set $type47 1
     (local.tee $1
      (struct.new_default $type47)
     )
     (struct.new $type31
      (ref.func $function69)
      (struct.new $environment69
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (struct.set $type47 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call31
     (struct.get $type31 1
      (local.tee $2
       (ref.as_non_null
        (struct.get $type47 1
         (local.get $1)
        )
       )
      )
     )
     (i64.const 0)
     (i64.const 0)
     (struct.get $type31 0
      (local.get $2)
     )
    )
   )
  )
  (unreachable)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global139
   (struct.new_default $type29)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $global116
   (struct.new $type28
    (f64.const -1.0)
    (f64.const -0.5)
   )
  )
  (global.set $global117
   (array.new_default $type30
    (i32.const 0)
   )
  )
  (global.set $global156
   (struct.new $type31
    (ref.func $function70)
    (ref.null none)
   )
  )
  (global.set $global132
   (struct.new_default $type32)
  )
  (global.set $global123
   (struct.new_default $type33)
  )
  (global.set $global118
   (struct.new_default $type35)
  )
  (global.set $global150
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global151
   (struct.new_default $type35)
  )
  (global.set $ready151
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

