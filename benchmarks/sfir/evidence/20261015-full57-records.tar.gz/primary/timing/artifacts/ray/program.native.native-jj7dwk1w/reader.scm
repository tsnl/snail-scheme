(module
 (rec
  (type $type64 (sub (struct)))
  (type $type60 (sub (struct)))
  (type $type69 (sub (struct)))
  (type $type120 (struct (field (mut i32)) (field (mut (ref null $type74)))))
  (type $environment136 (struct (field i64) (field (ref $type120))))
  (type $call74 (func (param (ref null $environment136) i64 i64) (result i64)))
  (type $type13 (struct (field (ref $environment132))))
  (type $type118 (struct (field (mut i32)) (field (mut (ref null $type13)))))
  (type $environment132 (struct (field i64) (field (ref $type14)) (field (ref $type118))))
  (type $call13 (func (param (ref $environment132) i64) (result (ref $type14))))
  (type $environment123 (struct (field (ref $type99))))
  (type $environment125 (struct (field i64) (field (ref $type99))))
  (type $type66 (sub $type64 (struct (field (ref $type67)))))
  (type $type62 (sub $type60 (struct (field f64))))
  (type $14 (func (param (ref $environment97) (ref $type72)) (result (ref $type69))))
  (type $environment97 (struct (field (ref $type67)) (field (ref $type67)) (field (ref $type104)) (field (ref null $type81)) (field (ref $type69)) (field f64)))
  (type $type102 (struct (field (ref $environment96))))
  (type $type72 (struct (field f64) (field f64) (field (ref $type67))))
  (type $type71 (sub $type69 (struct (field (ref $type72)) (field (ref $type67)))))
  (type $environment96 (struct (field (ref $type67)) (field (ref $type67)) (field (ref $type104))))
  (type $type81 (struct (field (ref $type72)) (field (ref null $type81))))
  (type $type104 (struct (field (mut i32)) (field (mut (ref null $type102)))))
  (type $environment90 (struct (field i64) (field (ref $type27)) (field i64) (field i64) (field (ref $type99))))
  (type $type97 (struct (field (ref $call97)) (field (ref struct))))
  (type $environment88 (struct (field i64) (field (ref $type27)) (field i64) (field (ref $type99))))
  (type $type99 (struct (field (mut i32)) (field (mut (ref null $type97)))))
  (type $call97 (func (param (ref struct) i64) (result i32)))
  (type $27 (func (param f64 f64 f64) (result (ref $type67))))
  (type $call76 (func (param f64 f64 f64) (result f64)))
  (type $call58 (func (param i64 (ref $type27)) (result i32)))
  (type $type28 (struct (field (mut i32))))
  (type $type27 (struct (field (ref $type28))))
  (type $32 (func (param (ref $type14) (ref $type27) i64 i32 i32 i32 i64) (result i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $34 (func (param (ref $type14) i64 i32 i32 i32 i64) (result i32)))
  (type $type94 (struct))
  (type $type93 (struct))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type89 (struct))
  (type $type88 (struct))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type67 (struct (field f64) (field f64) (field f64)))
  (type $type80 (struct (field (mut (ref null $type81)))))
  (type $type79 (struct))
  (type $type78 (struct))
  (type $type77 (struct))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type74 (struct (field (ref $call74)) (field (ref null $environment136))))
  (type $type73 (struct))
  (type $type68 (struct))
  (type $type63 (struct))
  (type $type59 (struct))
  (type $type58 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type37 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type70 (sub $type69 (struct)))
  (type $type65 (sub $type64 (struct)))
  (type $type61 (sub $type60 (struct)))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $74 (func (result i32)))
 (type $75 (func))
 (type $76 (func (param i32)))
 (type $77 (func (param i64) (result i64)))
 (type $78 (func (param i32 i32)))
 (type $79 (func (result i64)))
 (type $80 (func (param i64) (result i32)))
 (type $81 (func (param i32) (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign9 (param i32 i32)))
 (import "snail.library" "snail:io/check-output" (func $foreign10 (param i32)))
 (import "benchmark" "path_length" (func $foreign11 (result i64)))
 (import "benchmark" "path_character" (func $foreign12 (param i64) (result i32)))
 (import "benchmark" "barrier" (func $foreign13 (result i32)))
 (import "benchmark" "hide_i64" (func $foreign14 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign15 (param i32) (result i64)))
 (import "snail.library" "snail:io/standard-input" (func $foreign16 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign17 (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 32)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type15 1
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 80)
   (i32.const 50)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $empty61 (ref $type61) (struct.new_default $type61))
 (global $empty65 (ref $type65) (struct.new_default $type65))
 (global $empty70 (ref $type70) (struct.new_default $type70))
 (global $global113 (mut (ref null $type33)) (ref.null none))
 (global $global118 (mut (ref null $type34)) (ref.null none))
 (global $global120 (mut (ref null $type33)) (ref.null none))
 (global $global122 (mut (ref null $type35)) (ref.null none))
 (global $global126 (mut (ref null $type37)) (ref.null none))
 (global $global128 (mut (ref null $type39)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global286 (mut (ref null $type40)) (ref.null none))
 (global $global164 (mut (ref null $type55)) (ref.null none))
 (global $global167 (mut (ref null $type56)) (ref.null none))
 (global $global173 (mut (ref null $type37)) (ref.null none))
 (global $global180 (mut (ref null $type58)) (ref.null none))
 (global $global183 (mut (ref null $type58)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global187 (mut (ref null $type59)) (ref.null none))
 (global $global191 (mut (ref null $type63)) (ref.null none))
 (global $global195 (mut (ref null $type68)) (ref.null none))
 (global $global200 (mut (ref null $type73)) (ref.null none))
 (global $global203 (mut (ref null $type73)) (ref.null none))
 (global $global324 (mut (ref null $type74)) (ref.null none))
 (global $global206 (mut (ref null $type75)) (ref.null none))
 (global $global208 (mut (ref null $type76)) (ref.null none))
 (global $global212 (mut (ref null $type77)) (ref.null none))
 (global $global217 (mut (ref null $type78)) (ref.null none))
 (global $global220 (mut (ref null $type79)) (ref.null none))
 (global $global228 (mut (ref null $type80)) (ref.null none))
 (global $global229 (mut (ref null $type67)) (ref.null none))
 (global $global230 (mut (ref null $type82)) (ref.null none))
 (global $global239 (mut (ref null $type83)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global243 (mut (ref null $type78)) (ref.null none))
 (global $ready243 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type84)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global272 (mut (ref null $type85)) (ref.null none))
 (global $ready272 (mut i32) (i32.const 0))
 (global $global291 (mut (ref null $type86)) (ref.null none))
 (global $global284 (mut (ref null $type87)) (ref.null none))
 (global $ready284 (mut i32) (i32.const 0))
 (global $global254 (mut (ref null $type88)) (ref.null none))
 (global $ready254 (mut i32) (i32.const 0))
 (global $global258 (mut (ref null $type88)) (ref.null none))
 (global $ready258 (mut i32) (i32.const 0))
 (global $global276 (mut (ref null $type89)) (ref.null none))
 (global $ready276 (mut i32) (i32.const 0))
 (global $global279 (mut (ref null $type89)) (ref.null none))
 (global $ready279 (mut i32) (i32.const 0))
 (global $global298 (mut (ref null $type90)) (ref.null none))
 (global $global305 (mut (ref null $type91)) (ref.null none))
 (global $global308 (mut (ref null $type92)) (ref.null none))
 (global $ready308 (mut i32) (i32.const 0))
 (global $global313 (mut i64) (i64.const 0))
 (global $global314 (mut (ref null $type14)) (ref.null none))
 (global $global315 (mut i64) (i64.const 0))
 (global $global316 (mut (ref null $type93)) (ref.null none))
 (global $global319 (mut (ref null $type94)) (ref.null none))
 (global $ready319 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function45 (type $34) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (local $7 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
    )
   )
  )
 )
 (func $function64 (type $32) (param $0 (ref $type14)) (param $1 (ref $type27)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (local $7 i32)
  (local $8 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (call $foreign9
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $1)
      )
     )
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $7
         (i32.wrap_i64
          (local.get $6)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $7)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $7)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $8
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $8)
    )
   )
  )
 )
 (func $function69 (type $call58) (param $0 i64) (param $1 (ref $type27)) (result i32)
  (local $2 i64)
  (if
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (call $foreign9
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $1)
      )
     )
     (i32.const 45)
    )
   )
  )
  (if
   (i64.gt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (local.get $0)
       (local.tee $2
        (i64.sub
         (i64.const 0)
         (local.get $0)
        )
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (local.get $2)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (return_call $function70
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function70 (type $call58) (param $0 i64) (param $1 (ref $type27)) (result i32)
  (local $2 i64)
  (if
   (i64.ne
    (local.tee $2
     (i64.div_s
      (local.get $0)
      (i64.const 10)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global183)
     )
    )
    (drop
     (call $function70
      (local.get $2)
      (local.get $1)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $0
       (i64.sub
        (i64.const 48)
        (local.tee $2
         (i64.rem_s
          (local.get $0)
          (i64.const 10)
         )
        )
       )
      )
      (i64.const 48)
     )
     (i64.xor
      (local.get $2)
      (i64.const 48)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (call $foreign9
   (struct.get $type28 0
    (struct.get $type27 0
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $0)
   )
  )
  (i32.const 0)
 )
 (func $function77 (type $call76) (param $0 f64) (param $1 f64) (param $2 f64) (result f64)
  (local $3 i32)
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $3
      (f64.lt
       (f64.abs
        (local.get $0)
       )
       (f64.const inf)
      )
     )
     (local.get $3)
    )
    (f64.eq
     (f64.abs
      (local.tee $0
       (f64.mul
        (local.get $0)
        (local.get $0)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $3
      (f64.lt
       (f64.abs
        (local.get $1)
       )
       (f64.const inf)
      )
     )
     (local.get $3)
    )
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.get $1)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $0)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $0
       (f64.add
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $3
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (local.get $3)
    )
    (f64.eq
     (f64.abs
      (local.tee $1
       (f64.mul
        (local.get $2)
        (local.get $2)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $0)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $1)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $0
       (f64.add
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (f64.sqrt
   (local.get $0)
  )
 )
 (func $function78 (type $27) (param $0 f64) (param $1 f64) (param $2 f64) (result (ref $type67))
  (local $3 f64)
  (local $4 f64)
  (drop
   (ref.as_non_null
    (global.get $global208)
   )
  )
  (local.set $4
   (f64.div
    (local.get $0)
    (local.tee $3
     (call $function77
      (local.get $0)
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $0)
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (f64.eq
      (f64.abs
       (local.get $4)
      )
      (f64.const inf)
     )
    )
    (f64.ne
     (local.get $3)
     (f64.const 0.0)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $1)
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (f64.eq
      (f64.abs
       (local.tee $0
        (f64.div
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (f64.const inf)
     )
    )
    (f64.ne
     (local.get $3)
     (f64.const 0.0)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (i32.and
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (f64.eq
      (f64.abs
       (local.tee $1
        (f64.div
         (local.get $2)
         (local.get $3)
        )
       )
      )
      (f64.const inf)
     )
    )
    (f64.ne
     (local.get $3)
     (f64.const 0.0)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type67
   (local.get $4)
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function88 (type $call97) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type99))
  (local $3 (ref $environment88))
  (local $4 (ref $type97))
  (local $5 i64)
  (if (result i32)
   (i64.eq
    (struct.get $environment88 2
     (ref.cast (ref $environment88)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type99 1
     (local.tee $2
      (struct.new_default $type99)
     )
     (struct.new $type97
      (ref.func $function90)
      (struct.new $environment90
       (struct.get $environment88 0
        (local.tee $3
         (ref.cast (ref $environment88)
          (local.get $0)
         )
        )
       )
       (struct.get $environment88 1
        (local.get $3)
       )
       (struct.get $environment88 2
        (local.get $3)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type99 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call97
      (struct.get $type97 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type99 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type97 0
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (struct.get $environment88 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function88
     (struct.get $type97 1
      (struct.get $type99 1
       (struct.get $environment88 3
        (local.get $3)
       )
      )
     )
     (local.get $5)
    )
   )
  )
 )
 (func $function90 (type $call97) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 i64)
  (local $8 (ref $environment90))
  (local $9 (ref $type67))
  (local $10 (ref $type67))
  (local $11 (ref $type67))
  (local $12 (ref $type67))
  (local $13 (ref $type104))
  (local $14 (ref $type69))
  (local $15 (ref null $type81))
  (local $16 (ref $environment96))
  (local $17 (ref $type70))
  (local $18 (ref $type71))
  (local $19 (ref $type72))
  (local $20 (ref $type27))
  (local $scratch (ref $type72))
  (if (result i32)
   (i64.eq
    (struct.get $environment90 2
     (ref.cast (ref $environment90)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (f64.div
      (local.tee $4
       (f64.convert_i64_s
        (local.get $1)
       )
      )
      (local.tee $3
       (f64.convert_i64_s
        (struct.get $environment90 0
         (ref.cast (ref $environment90)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (i32.and
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $3)
         )
         (f64.const inf)
        )
       )
       (f64.eq
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $3)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.add
          (local.get $2)
          (f64.const -50.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (f64.div
      (local.tee $5
       (f64.convert_i64_s
        (struct.get $environment90 3
         (local.tee $8
          (ref.cast (ref $environment90)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.tee $4
       (f64.convert_i64_s
        (struct.get $environment90 0
         (local.get $8)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (i32.and
        (f64.lt
         (f64.abs
          (local.get $5)
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (f64.eq
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $4)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.add
          (local.get $2)
          (f64.const -50.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready239)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (local.set $2
     (f64.sub
      (local.get $3)
      (local.tee $5
       (struct.get $type67 0
        (global.get $global229)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (f64.sub
      (local.get $4)
      (local.tee $5
       (struct.get $type67 1
        (global.get $global229)
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $5
         (f64.sub
          (f64.const -0.0)
          (local.tee $4
           (struct.get $type67 2
            (global.get $global229)
           )
          )
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $4)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global212)
     )
    )
    (local.set $9
     (call $function78
      (local.get $2)
      (local.get $3)
      (local.get $5)
     )
    )
    (local.set $10
     (ref.as_non_null
      (global.get $global229)
     )
    )
    (if
     (i32.eqz
      (global.get $ready243)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global243)
     )
    )
    (if
     (i32.eqz
      (global.get $ready246)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global246)
     )
    )
    (local.set $15
     (struct.get $type80 0
      (global.get $global228)
     )
    )
    (struct.set $type104 1
     (local.tee $13
      (struct.new_default $type104)
     )
     (struct.new $type102
      (struct.new $environment96
       (local.get $10)
       (local.get $9)
       (local.get $13)
      )
     )
    )
    (struct.set $type104 0
     (local.get $13)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type104 0
       (local.get $13)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $16
     (struct.get $type102 0
      (struct.get $type104 1
       (local.get $13)
      )
     )
    )
    (local.set $17
     (global.get $empty70)
    )
    (local.set $14
     (if (result (ref $type69))
      (ref.is_null
       (local.get $15)
      )
      (then
       (local.get $17)
      )
      (else
       (call $function97
        (struct.new $environment97
         (struct.get $environment96 0
          (local.get $16)
         )
         (struct.get $environment96 1
          (local.get $16)
         )
         (struct.get $environment96 2
          (local.get $16)
         )
         (local.get $15)
         (local.get $17)
         (f64.const 1.e+308)
        )
        (struct.get $type81 0
         (local.get $15)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global195)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.mul
          (local.tee $2
           (if (result f64)
            (if (result i32)
             (ref.test (ref $type70)
              (local.get $14)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (ref.cast (ref $type71)
                (local.get $14)
               )
              )
              (i32.const 1)
             )
            )
            (then
             (if
              (ref.test (ref $type70)
               (local.get $14)
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (f64.sub
               (local.tee $3
                (struct.get $type67 0
                 (local.tee $11
                  (struct.get $type72 2
                   (block (result (ref $type72))
                    (local.set $scratch
                     (struct.get $type71 0
                      (local.tee $18
                       (ref.cast (ref $type71)
                        (local.get $14)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready272)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global272)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready276)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global276)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready279)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global279)
                     )
                    )
                    (local.get $scratch)
                   )
                  )
                 )
                )
               )
               (local.tee $4
                (struct.get $type67 0
                 (local.tee $12
                  (struct.get $type71 1
                   (local.get $18)
                  )
                 )
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $2)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (f64.sub
               (local.tee $4
                (struct.get $type67 1
                 (local.get $11)
                )
               )
               (local.tee $5
                (struct.get $type67 1
                 (local.get $12)
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $5)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $3)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (f64.sub
               (local.tee $5
                (struct.get $type67 2
                 (local.get $11)
                )
               )
               (local.tee $6
                (struct.get $type67 2
                 (local.get $12)
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $5)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $6)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $4)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global212)
              )
             )
             (local.set $2
              (f64.mul
               (local.tee $5
                (struct.get $type67 0
                 (local.get $9)
                )
               )
               (local.tee $3
                (struct.get $type67 0
                 (local.tee $10
                  (call $function78
                   (local.get $2)
                   (local.get $3)
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $5)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $2)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (f64.mul
               (local.tee $4
                (struct.get $type67 1
                 (local.get $9)
                )
               )
               (local.tee $5
                (struct.get $type67 1
                 (local.get $10)
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $5)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $3)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $2)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.tee $3
                  (f64.add
                   (local.get $2)
                   (local.get $3)
                  )
                 )
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (f64.mul
               (local.tee $4
                (struct.get $type67 2
                 (local.get $9)
                )
               )
               (local.tee $5
                (struct.get $type67 2
                 (local.get $10)
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $5)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $2)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $2)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.tee $2
                  (f64.add
                   (local.get $3)
                   (local.get $2)
                  )
                 )
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global203)
              )
             )
             (if
              (i32.eqz
               (global.get $ready284)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global284)
              )
             )
             (local.set $2
              (f64.mul
               (local.tee $3
                (select
                 (f64.const 0.0)
                 (local.get $2)
                 (f64.lt
                  (local.get $2)
                  (f64.const 0.0)
                 )
                )
               )
               (local.tee $4
                (struct.get $type72 0
                 (struct.get $type71 0
                  (local.get $18)
                 )
                )
               )
              )
             )
             (if
              (i32.and
               (i32.and
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
               )
               (f64.eq
                (f64.abs
                 (local.get $2)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.get $2)
            )
            (else
             (f64.const 0.0)
            )
           )
          )
          (f64.const 255.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global180)
     )
    )
    (drop
     (call $function69
      (i64.trunc_f64_s
       (f64.nearest
        (local.get $3)
       )
      )
      (local.tee $20
       (struct.get $environment90 1
        (local.get $8)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global173)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (call $foreign9
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $20)
      )
     )
     (i32.const 10)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $7
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (struct.get $environment90 4
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (struct.get $type97 1
      (struct.get $type99 1
       (struct.get $environment90 4
        (local.get $8)
       )
      )
     )
     (local.get $7)
    )
   )
  )
 )
 (func $function97 (type $14) (param $0 (ref $environment97)) (param $1 (ref $type72)) (result (ref $type69))
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 i32)
  (local $12 (ref $type67))
  (local $13 (ref $type67))
  (local $14 (ref null $type81))
  (local $15 (ref $type104))
  (local $16 (ref null $environment96))
  (local $17 (ref $type69))
  (local $18 (ref $type60))
  (local $19 (ref $type64))
  (local $20 (ref $environment96))
  (local $21 (ref $type71))
  (if
   (i32.eqz
    (global.get $ready254)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global254)
   )
  )
  (if
   (i32.eqz
    (global.get $ready258)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.tee $9
         (local.tee $2
          (struct.get $type67 0
           (local.tee $12
            (struct.get $environment97 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.mul
        (local.get $2)
        (local.get $2)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.tee $7
         (struct.get $type67 1
          (local.get $12)
         )
        )
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $6
       (f64.mul
        (local.get $7)
        (local.get $7)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $6)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.add
        (local.get $2)
        (local.get $6)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.tee $6
         (struct.get $type67 2
          (local.get $12)
         )
        )
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $4
       (f64.mul
        (local.get $6)
        (local.get $6)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $4)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $4
       (f64.add
        (local.get $2)
        (local.get $4)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (f64.sub
    (local.tee $3
     (struct.get $type67 0
      (local.tee $12
       (struct.get $environment97 0
        (local.get $0)
       )
      )
     )
    )
    (local.tee $5
     (struct.get $type67 0
      (local.tee $13
       (struct.get $type72 2
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $9)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.get $2)
        (local.get $9)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (f64.sub
    (local.tee $5
     (struct.get $type67 1
      (local.get $12)
     )
    )
    (local.tee $8
     (struct.get $type67 1
      (local.get $13)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $7)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.mul
        (local.get $2)
        (local.get $7)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.add
        (local.get $3)
        (local.get $2)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (f64.sub
    (local.tee $5
     (struct.get $type67 2
      (local.get $12)
     )
    )
    (local.tee $8
     (struct.get $type67 2
      (local.get $13)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $2)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $6)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.mul
        (local.get $2)
        (local.get $6)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $2)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.add
        (local.get $3)
        (local.get $2)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $2
       (f64.add
        (local.get $3)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (f64.sub
    (local.tee $5
     (struct.get $type67 0
      (local.get $12)
     )
    )
    (local.tee $8
     (struct.get $type67 0
      (local.get $13)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $5
       (f64.mul
        (local.get $3)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (f64.sub
    (local.tee $8
     (struct.get $type67 1
      (local.get $12)
     )
    )
    (local.tee $10
     (struct.get $type67 1
      (local.get $13)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $10)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.get $3)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $5
       (f64.add
        (local.get $5)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (f64.sub
    (local.tee $8
     (struct.get $type67 2
      (local.get $12)
     )
    )
    (local.tee $10
     (struct.get $type67 2
      (local.get $13)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $10)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.get $3)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.get $3)
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.mul
        (local.get $3)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $5)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.add
        (local.get $5)
        (local.get $3)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (if
   (i32.and
    (i32.and
     (local.tee $11
      (f64.lt
       (f64.abs
        (local.tee $5
         (struct.get $type72 1
          (local.get $1)
         )
        )
       )
       (f64.const inf)
      )
     )
     (local.get $11)
    )
    (f64.eq
     (f64.abs
      (local.tee $5
       (f64.mul
        (local.get $5)
        (local.get $5)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (f64.eq
     (f64.abs
      (local.tee $8
       (f64.sub
        (f64.const -0.0)
        (local.get $5)
       )
      )
     )
     (f64.const inf)
    )
    (f64.lt
     (f64.abs
      (local.get $5)
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i32.and
     (f64.lt
      (f64.abs
       (local.get $3)
      )
      (f64.const inf)
     )
     (f64.lt
      (f64.abs
       (local.get $8)
      )
      (f64.const inf)
     )
    )
    (f64.eq
     (f64.abs
      (local.tee $3
       (f64.add
        (local.get $3)
        (local.get $8)
       )
      )
     )
     (f64.const inf)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $15
   (struct.get $environment97 2
    (local.get $0)
   )
  )
  (local.set $14
   (struct.get $environment97 3
    (local.get $0)
   )
  )
  (local.set $17
   (struct.get $environment97 4
    (local.get $0)
   )
  )
  (local.set $8
   (struct.get $environment97 5
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global220)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global191)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global187)
   )
  )
  (block $block
   (return
    (if (result (ref $type69))
     (if (result i32)
      (ref.test (ref $type65)
       (local.tee $19
        (if (result (ref $type64))
         (if (result i32)
          (ref.test (ref $type61)
           (local.tee $18
            (if (result (ref $type60))
             (f64.eq
              (local.get $4)
              (f64.const 0.0)
             )
             (then
              (if
               (i32.and
                (f64.eq
                 (f64.abs
                  (local.tee $4
                   (f64.sub
                    (f64.const -0.0)
                    (local.get $3)
                   )
                  )
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $3)
                 )
                 (f64.const inf)
                )
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i32.and
                 (i32.and
                  (f64.lt
                   (f64.abs
                    (local.get $4)
                   )
                   (f64.const inf)
                  )
                  (f64.lt
                   (f64.abs
                    (local.get $2)
                   )
                   (f64.const inf)
                  )
                 )
                 (f64.eq
                  (f64.abs
                   (local.tee $4
                    (f64.div
                     (local.get $4)
                     (local.get $2)
                    )
                   )
                  )
                  (f64.const inf)
                 )
                )
                (f64.ne
                 (local.get $2)
                 (f64.const 0.0)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type62
               (local.get $4)
              )
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global206)
               )
              )
              (if
               (i32.and
                (i32.and
                 (local.tee $11
                  (f64.lt
                   (f64.abs
                    (local.get $2)
                   )
                   (f64.const inf)
                  )
                 )
                 (local.get $11)
                )
                (f64.eq
                 (f64.abs
                  (local.tee $5
                   (f64.mul
                    (local.get $2)
                    (local.get $2)
                   )
                  )
                 )
                 (f64.const inf)
                )
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (f64.eq
                 (f64.abs
                  (local.tee $10
                   (f64.mul
                    (local.get $4)
                    (f64.const 4.0)
                   )
                  )
                 )
                 (f64.const inf)
                )
                (f64.lt
                 (f64.abs
                  (local.get $4)
                 )
                 (f64.const inf)
                )
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i32.and
                 (f64.lt
                  (f64.abs
                   (local.get $10)
                  )
                  (f64.const inf)
                 )
                 (f64.lt
                  (f64.abs
                   (local.get $3)
                  )
                  (f64.const inf)
                 )
                )
                (f64.eq
                 (f64.abs
                  (local.tee $3
                   (f64.mul
                    (local.get $10)
                    (local.get $3)
                   )
                  )
                 )
                 (f64.const inf)
                )
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i32.and
                 (f64.lt
                  (f64.abs
                   (local.get $5)
                  )
                  (f64.const inf)
                 )
                 (f64.lt
                  (f64.abs
                   (local.get $3)
                  )
                  (f64.const inf)
                 )
                )
                (f64.eq
                 (f64.abs
                  (local.tee $5
                   (f64.sub
                    (local.get $5)
                    (local.get $3)
                   )
                  )
                 )
                 (f64.const inf)
                )
               )
               (then
                (unreachable)
               )
              )
              (if (result (ref $type60))
               (f64.lt
                (local.get $5)
                (f64.const 0.0)
               )
               (then
                (global.get $empty61)
               )
               (else
                (if
                 (i32.and
                  (f64.eq
                   (f64.abs
                    (local.tee $3
                     (f64.sub
                      (f64.const -0.0)
                      (local.get $2)
                     )
                    )
                   )
                   (f64.const inf)
                  )
                  (f64.lt
                   (f64.abs
                    (local.get $2)
                   )
                   (f64.const inf)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (f64.eq
                   (f64.abs
                    (local.tee $2
                     (f64.add
                      (local.get $4)
                      (local.get $4)
                     )
                    )
                   )
                   (f64.const inf)
                  )
                  (f64.lt
                   (f64.abs
                    (local.get $4)
                   )
                   (f64.const inf)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i32.and
                   (f64.lt
                    (f64.abs
                     (local.get $3)
                    )
                    (f64.const inf)
                   )
                   (f64.lt
                    (f64.abs
                     (local.tee $5
                      (f64.sqrt
                       (local.get $5)
                      )
                     )
                    )
                    (f64.const inf)
                   )
                  )
                  (f64.eq
                   (f64.abs
                    (local.tee $4
                     (f64.add
                      (local.get $3)
                      (local.get $5)
                     )
                    )
                   )
                   (f64.const inf)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i32.and
                   (i32.and
                    (f64.lt
                     (f64.abs
                      (local.get $4)
                     )
                     (f64.const inf)
                    )
                    (f64.lt
                     (f64.abs
                      (local.get $2)
                     )
                     (f64.const inf)
                    )
                   )
                   (f64.eq
                    (f64.abs
                     (local.tee $4
                      (f64.div
                       (local.get $4)
                       (local.get $2)
                      )
                     )
                    )
                    (f64.const inf)
                   )
                  )
                  (f64.ne
                   (local.get $2)
                   (f64.const 0.0)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i32.and
                   (f64.lt
                    (f64.abs
                     (local.get $3)
                    )
                    (f64.const inf)
                   )
                   (f64.lt
                    (f64.abs
                     (local.get $5)
                    )
                    (f64.const inf)
                   )
                  )
                  (f64.eq
                   (f64.abs
                    (local.tee $3
                     (f64.sub
                      (local.get $3)
                      (local.get $5)
                     )
                    )
                   )
                   (f64.const inf)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i32.and
                   (i32.and
                    (f64.lt
                     (f64.abs
                      (local.get $3)
                     )
                     (f64.const inf)
                    )
                    (f64.lt
                     (f64.abs
                      (local.get $2)
                     )
                     (f64.const inf)
                    )
                   )
                   (f64.eq
                    (f64.abs
                     (local.tee $3
                      (f64.div
                       (local.get $3)
                       (local.get $2)
                      )
                     )
                    )
                    (f64.const inf)
                   )
                  )
                  (f64.ne
                   (local.get $2)
                   (f64.const 0.0)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global200)
                 )
                )
                (struct.new $type62
                 (select
                  (select
                   (local.get $4)
                   (local.get $3)
                   (f64.gt
                    (local.get $3)
                    (local.get $4)
                   )
                  )
                  (local.get $4)
                  (f64.eq
                   (local.get $4)
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type62)
             (local.get $18)
            )
           )
           (i32.const 1)
          )
         )
         (then
          (if
           (ref.test (ref $type61)
            (local.get $18)
           )
           (then
            (unreachable)
           )
          )
          (local.set $4
           (f64.mul
            (local.tee $2
             (struct.get $type62 0
              (ref.cast (ref $type62)
               (local.get $18)
              )
             )
            )
            (local.get $9)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.get $2)
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $9)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.get $4)
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.tee $9
                (struct.get $type67 0
                 (local.get $12)
                )
               )
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $4)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.tee $4
               (f64.add
                (local.get $9)
                (local.get $4)
               )
              )
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.get $2)
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $7)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.tee $7
               (f64.mul
                (local.get $2)
                (local.get $7)
               )
              )
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.tee $9
                (struct.get $type67 1
                 (local.get $12)
                )
               )
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $7)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.tee $7
               (f64.add
                (local.get $9)
                (local.get $7)
               )
              )
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.get $2)
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $6)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.tee $2
               (f64.mul
                (local.get $2)
                (local.get $6)
               )
              )
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.tee $6
                (struct.get $type67 2
                 (local.get $12)
                )
               )
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $2)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.tee $2
               (f64.add
                (local.get $6)
                (local.get $2)
               )
              )
             )
             (f64.const inf)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type66
           (struct.new $type67
            (local.get $4)
            (local.get $7)
            (local.get $2)
           )
          )
         )
         (else
          (global.get $empty65)
         )
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.cast (ref $type66)
         (local.get $19)
        )
       )
       (i32.const 1)
      )
     )
     (then
      (if
       (ref.test (ref $type65)
        (local.get $19)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global217)
       )
      )
      (local.set $2
       (f64.sub
        (local.tee $7
         (struct.get $type67 0
          (local.tee $13
           (struct.get $type66 0
            (ref.cast (ref $type66)
             (local.get $19)
            )
           )
          )
         )
        )
        (local.tee $6
         (struct.get $type67 0
          (local.get $12)
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $7)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $6)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $2)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (f64.sub
        (local.tee $6
         (struct.get $type67 1
          (local.get $13)
         )
        )
        (local.tee $4
         (struct.get $type67 1
          (local.get $12)
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $6)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $7)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (f64.sub
        (local.tee $4
         (struct.get $type67 2
          (local.get $13)
         )
        )
        (local.tee $9
         (struct.get $type67 2
          (local.get $12)
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $9)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $6)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global208)
       )
      )
      (if (result (ref $type69))
       (f64.gt
        (local.get $8)
        (local.tee $2
         (call $function77
          (local.get $2)
          (local.get $7)
          (local.get $6)
         )
        )
       )
       (then
        (local.set $14
         (struct.get $type81 1
          (local.get $14)
         )
        )
        (if
         (i32.eqz
          (struct.get $type104 0
           (local.get $15)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $20
         (struct.get $type102 0
          (struct.get $type104 1
           (local.get $15)
          )
         )
        )
        (local.set $21
         (struct.new $type71
          (local.get $1)
          (local.get $13)
         )
        )
        (if (result (ref $type71))
         (ref.is_null
          (local.get $14)
         )
         (then
          (local.get $21)
         )
         (else
          (return_call $function97
           (struct.new $environment97
            (struct.get $environment96 0
             (local.get $20)
            )
            (struct.get $environment96 1
             (local.get $20)
            )
            (struct.get $environment96 2
             (local.get $20)
            )
            (local.get $14)
            (local.get $21)
            (local.get $2)
           )
           (struct.get $type81 0
            (local.get $14)
           )
          )
         )
        )
       )
       (else
        (local.set $14
         (struct.get $type81 1
          (local.get $14)
         )
        )
        (if
         (i32.eqz
          (struct.get $type104 0
           (local.get $15)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $16
         (struct.get $type102 0
          (struct.get $type104 1
           (local.get $15)
          )
         )
        )
        (br_if $block
         (i32.eqz
          (ref.is_null
           (local.get $14)
          )
         )
        )
        (local.get $17)
       )
      )
     )
     (else
      (local.set $14
       (struct.get $type81 1
        (local.get $14)
       )
      )
      (if
       (i32.eqz
        (struct.get $type104 0
         (local.get $15)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $16
       (struct.get $type102 0
        (struct.get $type104 1
         (local.get $15)
        )
       )
      )
      (br_if $block
       (i32.eqz
        (ref.is_null
         (local.get $14)
        )
       )
      )
      (local.get $17)
     )
    )
   )
  )
  (return_call $function97
   (struct.new $environment97
    (struct.get $environment96 0
     (local.get $16)
    )
    (struct.get $environment96 1
     (local.get $16)
    )
    (struct.get $environment96 2
     (local.get $16)
    )
    (local.get $14)
    (local.get $17)
    (local.get $8)
   )
   (struct.get $type81 0
    (local.get $14)
   )
  )
 )
 (func $function123 (type $call97) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type99))
  (local $3 (ref $type97))
  (local $4 i64)
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 2)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type99 1
     (local.tee $2
      (struct.new_default $type99)
     )
     (struct.new $type97
      (ref.func $function125)
      (struct.new $environment125
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type99 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call97
      (struct.get $type97 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type99 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 2)
      (struct.get $type97 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (struct.get $environment123 0
        (ref.cast (ref $environment123)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function123
     (struct.get $type97 1
      (struct.get $type99 1
       (struct.get $environment123 0
        (ref.cast (ref $environment123)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function125 (type $call97) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 i64)
  (local $6 (ref $type80))
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 7)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $3
         (f64.mul
          (local.tee $2
           (f64.convert_i64_s
            (struct.get $environment125 0
             (ref.cast (ref $environment125)
              (local.get $0)
             )
            )
           )
          )
          (f64.const 200.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $4
         (f64.mul
          (local.tee $2
           (f64.convert_i64_s
            (local.get $1)
           )
          )
          (f64.const -400.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global291)
     )
    )
    (struct.set $type80 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global228)
      )
     )
     (struct.new $type81
      (struct.new $type72
       (f64.const 0.75)
       (f64.const 40.0)
       (struct.new $type67
        (local.get $3)
        (f64.const 300.0)
        (local.get $4)
       )
      )
      (struct.get $type80 0
       (local.get $6)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (struct.get $environment125 1
        (ref.cast (ref $environment125)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function125
     (struct.get $type97 1
      (struct.get $type99 1
       (struct.get $environment125 1
        (ref.cast (ref $environment125)
         (local.get $0)
        )
       )
      )
     )
     (local.get $5)
    )
   )
  )
 )
 (func $function132 (type $call13) (param $0 (ref $environment132)) (param $1 i64) (result (ref $type14))
  (local $2 (ref $type14))
  (local $3 i32)
  (local $4 i32)
  (local $5 i64)
  (if (result (ref $type14))
   (i64.eq
    (struct.get $environment132 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (struct.get $environment132 1
     (local.get $0)
    )
   )
   (else
    (local.set $4
     (call $foreign12
      (local.get $1)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.tee $2
        (struct.get $environment132 1
         (local.get $0)
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $3
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $3)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $3)
      (i32.const 8191)
     )
     (local.get $4)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $5
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type118 0
       (struct.get $environment132 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function132
     (struct.get $type13 0
      (struct.get $type118 1
       (struct.get $environment132 2
        (local.get $0)
       )
      )
     )
     (local.get $5)
    )
   )
  )
 )
 (func $function136 (type $call74) (param $0 (ref null $environment136)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type27))
  (local $4 (ref $type99))
  (local $5 (ref $type14))
  (local $6 (ref $type80))
  (local $7 (ref $type97))
  (local $8 (ref $type28))
  (local $9 i32)
  (local $10 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment136 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $10
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type74 1
      (global.get $global324)
     )
    )
    (drop
     (struct.get $environment136 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign14
      (global.get $global313)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global314)
     )
    )
    (if
     (i32.eqz
      (call $foreign13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global305)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global298)
     )
    )
    (struct.set $type80 0
     (global.get $global228)
     (ref.null none)
    )
    (drop
     (ref.as_non_null
      (global.get $global291)
     )
    )
    (struct.set $type80 0
     (local.tee $6
      (ref.as_non_null
       (global.get $global228)
      )
     )
     (struct.new $type81
      (struct.new $type72
       (f64.const 0.8)
       (f64.const 200.0)
       (struct.new $type67
        (f64.const 0.0)
        (f64.const -300.0)
        (f64.const -1200.0)
       )
      )
      (struct.get $type80 0
       (local.get $6)
      )
     )
    )
    (struct.set $type80 0
     (local.get $6)
     (struct.new $type81
      (struct.new $type72
       (f64.const 0.7)
       (f64.const 200.0)
       (struct.new $type67
        (f64.const -80.0)
        (f64.const -150.0)
        (f64.const -1200.0)
       )
      )
      (struct.get $type80 0
       (local.get $6)
      )
     )
    )
    (struct.set $type80 0
     (local.get $6)
     (struct.new $type81
      (struct.new $type72
       (f64.const 0.9)
       (f64.const 200.0)
       (struct.new $type67
        (f64.const 70.0)
        (f64.const -100.0)
        (f64.const -1200.0)
       )
      )
      (struct.get $type80 0
       (local.get $6)
      )
     )
    )
    (struct.set $type99 1
     (local.tee $4
      (struct.new_default $type99)
     )
     (struct.new $type97
      (ref.func $function123)
      (struct.new $environment123
       (local.get $4)
      )
     )
    )
    (struct.set $type99 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call97
      (struct.get $type97 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type99 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const -2)
      (struct.get $type97 0
       (local.get $7)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global230)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $5)
      (local.tee $2
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $5)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eq
      (call $foreign2)
      (i32.const 1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global120)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (call $foreign0)
      (drop
       (call $function45
        (local.get $5)
        (local.get $2)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (call $foreign3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global286)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $5)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $3
     (struct.new $type27
      (struct.new $type28
       (call $foreign4)
      )
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.tee $2
        (i64.mul
         (local.get $1)
         (i64.const 100)
        )
       )
       (i64.const 100)
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (call $foreign10
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $3)
      )
     )
    )
    (drop
     (call $function64
      (global.get $string2)
      (local.get $3)
      (i64.const 3)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global180)
     )
    )
    (drop
     (call $function69
      (local.get $2)
      (local.get $3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (call $foreign10
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $3)
      )
     )
    )
    (drop
     (call $function64
      (global.get $string1)
      (local.get $3)
      (i64.const 1)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global180)
     )
    )
    (drop
     (call $function69
      (local.get $2)
      (local.get $3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global167)
     )
    )
    (call $foreign10
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $3)
      )
     )
    )
    (drop
     (call $function64
      (global.get $string0)
      (local.get $3)
      (i64.const 4)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global173)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (call $foreign9
     (struct.get $type28 0
      (struct.get $type27 0
       (local.get $3)
      )
     )
     (i32.const 10)
    )
    (struct.set $type99 1
     (local.tee $4
      (struct.new_default $type99)
     )
     (struct.new $type97
      (ref.func $function88)
      (struct.new $environment88
       (local.get $1)
       (local.get $3)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (struct.set $type99 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type99 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call97
      (struct.get $type97 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type99 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type97 0
       (local.get $7)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $9
         (struct.get $type28 0
          (local.tee $8
           (struct.get $type27 0
            (local.get $3)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $9)
          (i32.const -3)
         )
         (i32.eq
          (local.get $9)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type28 0
       (local.get $8)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $9)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type120 0
       (struct.get $environment136 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function136
     (struct.get $type74 1
      (struct.get $type120 1
       (struct.get $environment136 1
        (local.get $0)
       )
      )
     )
     (local.get $10)
     (i64.const 1)
    )
   )
   (else
    (i64.extend_i32_u
     (i64.eq
      (global.get $global315)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function137 (type $call74) (param $0 (ref null $environment136)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign14
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type120))
  (local $2 (ref $type74))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready319)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global319)
   )
  )
  (struct.set $type120 1
   (local.tee $1
    (struct.new_default $type120)
   )
   (struct.new $type74
    (ref.func $function136)
    (struct.new $environment136
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type120 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type120 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call74
   (struct.get $type74 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type120 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type74 0
    (local.get $2)
   )
  )
 )
 (func $main
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i64)
  (local $6 (ref $type118))
  (local $7 (ref null $type16))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (drop
   (call $foreign17)
  )
  (drop
   (call $foreign16)
  )
  (global.set $global113
   (struct.new_default $type33)
  )
  (global.set $global118
   (struct.new_default $type34)
  )
  (global.set $global120
   (struct.new_default $type33)
  )
  (global.set $global122
   (struct.new_default $type35)
  )
  (global.set $global126
   (struct.new_default $type37)
  )
  (global.set $global128
   (struct.new_default $type39)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global286
   (struct.new_default $type40)
  )
  (global.set $global164
   (struct.new_default $type55)
  )
  (global.set $global167
   (struct.new_default $type56)
  )
  (global.set $global173
   (struct.new_default $type37)
  )
  (global.set $global180
   (struct.new_default $type58)
  )
  (global.set $global183
   (struct.new_default $type58)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global187
   (struct.new_default $type59)
  )
  (global.set $global191
   (struct.new_default $type63)
  )
  (global.set $global195
   (struct.new_default $type68)
  )
  (global.set $global200
   (struct.new_default $type73)
  )
  (global.set $global203
   (struct.new_default $type73)
  )
  (global.set $global324
   (struct.new $type74
    (ref.func $function137)
    (ref.null none)
   )
  )
  (global.set $global206
   (struct.new_default $type75)
  )
  (global.set $global208
   (struct.new_default $type76)
  )
  (global.set $global212
   (struct.new_default $type77)
  )
  (global.set $global217
   (struct.new_default $type78)
  )
  (global.set $global220
   (struct.new_default $type79)
  )
  (global.set $global228
   (struct.new_default $type80)
  )
  (global.set $global229
   (struct.new $type67
    (f64.const 0.0)
    (f64.const 0.0)
    (f64.const 200.0)
   )
  )
  (global.set $global230
   (struct.new_default $type82)
  )
  (global.set $global239
   (struct.new_default $type83)
  )
  (global.set $ready239
   (i32.const 1)
  )
  (global.set $global243
   (struct.new_default $type78)
  )
  (global.set $ready243
   (i32.const 1)
  )
  (global.set $global246
   (struct.new_default $type84)
  )
  (global.set $ready246
   (i32.const 1)
  )
  (global.set $global272
   (struct.new_default $type85)
  )
  (global.set $ready272
   (i32.const 1)
  )
  (global.set $global291
   (struct.new_default $type86)
  )
  (global.set $global284
   (struct.new_default $type87)
  )
  (global.set $ready284
   (i32.const 1)
  )
  (global.set $global254
   (struct.new_default $type88)
  )
  (global.set $ready254
   (i32.const 1)
  )
  (global.set $global258
   (struct.new_default $type88)
  )
  (global.set $ready258
   (i32.const 1)
  )
  (global.set $global276
   (struct.new_default $type89)
  )
  (global.set $ready276
   (i32.const 1)
  )
  (global.set $global279
   (struct.new_default $type89)
  )
  (global.set $ready279
   (i32.const 1)
  )
  (global.set $global298
   (struct.new_default $type90)
  )
  (global.set $global305
   (struct.new_default $type91)
  )
  (global.set $global308
   (struct.new_default $type92)
  )
  (global.set $ready308
   (i32.const 1)
  )
  (global.set $global313
   (call $foreign15
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready308)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (if
   (i64.gt_u
    (local.tee $5
     (call $foreign11)
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $1
    (i32.sub
     (local.tee $0
      (i32.wrap_i64
       (local.get $5)
      )
     )
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $7
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $7)
      (local.get $2)
      (array.new $type15
       (i32.const 32)
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.set $type118 1
   (local.tee $6
    (struct.new_default $type118)
   )
   (struct.new $type13
    (struct.new $environment132
     (local.get $5)
     (struct.new $type14
      (i32.const 1)
      (local.get $0)
      (array.new $type15
       (i32.const 32)
       (local.get $3)
      )
      (local.get $7)
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type118 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type118 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global314
   (call $function132
    (struct.get $type13 0
     (struct.get $type118 1
      (local.get $6)
     )
    )
    (i64.const 0)
   )
  )
  (global.set $global315
   (call $foreign15
    (i32.const 1)
   )
  )
  (global.set $global316
   (struct.new_default $type93)
  )
  (global.set $global319
   (struct.new_default $type94)
  )
  (global.set $ready319
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

