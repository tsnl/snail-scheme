(module
 (rec
  (type $environment51 (struct (field i64) (field (ref $type34))))
  (type $environment48 (struct (field i64) (field (ref $type34))))
  (type $type34 (struct (field (mut i32)) (field (mut (ref null $type30)))))
  (type $call27 (func (param (ref null $environment44) i64 i64) (result i64)))
  (type $environment44 (struct (field i64) (field (ref $type32))))
  (type $type32 (struct (field (mut i32)) (field (mut (ref null $type27)))))
  (type $call30 (func (param structref i64) (result i64)))
  (type $call25 (func (param (ref $type14) (ref null $type23) i64) (result i32)))
  (type $8 (func (param i32 i32 (ref null $type23) i64) (result i64)))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $call22 (func (param (ref $type23)) (result (ref $type14))))
  (type $call20 (func (param (ref $type14) i64 i64) (result (ref $type14))))
  (type $12 (func (param (ref $type14) i64 (ref $type14) i64 i64)))
  (type $type16 (array (mut (ref null $type15))))
  (type $14 (func (param i32) (result (ref $type14))))
  (type $type30 (struct (field (ref $call30)) (field structref)))
  (type $type29 (struct))
  (type $type28 (struct (field (mut (ref $type14)))))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment44))))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $26 (func (param i64) (result i64)))
 (type $27 (func (param i32) (result i64)))
 (type $28 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 49)
   (i32.const 50)
   (i32.const 51)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 52)
   (i32.const 53)
   (i32.const 54)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 55)
   (i32.const 56)
   (i32.const 57)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type15 6
   (i32.const 97)
   (i32.const 98)
   (i32.const 99)
   (i32.const 100)
   (i32.const 101)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $global88 (mut (ref null $type22)) (ref.null none))
 (global $global91 (mut (ref null $type24)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global96 (mut (ref null $type25)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $global106 (mut (ref null $type28)) (ref.null none))
 (global $global107 (mut (ref null $type29)) (ref.null none))
 (global $global123 (mut (ref null $type30)) (ref.null none))
 (global $global119 (mut (ref null $type30)) (ref.null none))
 (global $global108 (mut i64) (i64.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $global110 (mut i64) (i64.const 0))
 (global $global111 (mut (ref null $type30)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $14) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy (type $12) (param $0 (ref $type14)) (param $1 i64) (param $2 (ref $type14)) (param $3 i64) (param $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $4)
     (local.get $3)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.gt_u
     (local.get $1)
     (local.get $3)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (i64.sub
         (local.get $4)
         (local.get $3)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $8
     (i32.add
      (i32.wrap_i64
       (local.get $3)
      )
      (local.get $7)
     )
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type15 $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $5
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $8)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $5)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $8
           (i32.sub
            (local.get $8)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $8)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $7
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $5
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $8
     (i32.wrap_i64
      (i64.sub
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (loop $label1
     (if
      (local.get $8)
      (then
       (local.set $6
        (select
         (local.get $8)
         (local.tee $6
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $9
              (i32.and
               (local.get $7)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $11
            (i32.sub
             (i32.const 8192)
             (local.tee $10
              (i32.and
               (local.get $5)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.lt_u
            (local.get $6)
            (local.get $11)
           )
          )
         )
         (i32.gt_u
          (local.get $6)
          (local.get $8)
         )
        )
       )
       (array.copy $type15 $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.get $7)
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $7)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $9)
        (if (result (ref $type15))
         (i32.lt_u
          (local.get $5)
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $10)
        (local.get $6)
       )
       (local.set $7
        (i32.add
         (local.get $6)
         (local.get $7)
        )
       )
       (local.set $5
        (i32.add
         (local.get $5)
         (local.get $6)
        )
       )
       (local.set $8
        (i32.sub
         (local.get $8)
         (local.get $6)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function33 (type $call20) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i64)
  (local $4 (ref $type14))
  (if (result (ref $type14))
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i64.lt_s
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (local.get $2)
      )
      (i64.gt_s
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $2)
          (local.get $1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (call $string-copy
     (local.tee $4
      (call $string-new
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
     (i64.const 0)
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
    (local.get $4)
   )
  )
 )
 (func $function35 (type $call22) (param $0 (ref $type23)) (result (ref $type14))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref null $type23))
  (local $5 (ref null $type23))
  (local $6 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (local.set $4
   (struct.get $type23 1
    (local.get $0)
   )
  )
  (local.set $1
   (if (result i64)
    (i64.gt_u
     (local.tee $1
      (i64.extend_i32_u
       (struct.get $type14 1
        (struct.get $type23 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (local.get $1)
      )
      (else
       (local.set $5
        (struct.get $type23 1
         (local.get $4)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $2
          (i64.add
           (i64.extend_i32_u
            (struct.get $type14 1
             (struct.get $type23 0
              (local.get $4)
             )
            )
           )
           (local.get $1)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type23 1
             (local.get $5)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $2)
               (local.tee $1
                (i64.add
                 (local.tee $3
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (struct.get $type23 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
              (i64.xor
               (local.get $1)
               (local.get $3)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.get $1)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $5
                (struct.get $type23 1
                 (local.get $4)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.get $1)
                   (local.tee $2
                    (i64.add
                     (local.tee $3
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (struct.get $type23 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (i64.xor
                   (local.get $2)
                   (local.get $3)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.get $2)
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $4
                    (struct.get $type23 1
                     (local.get $5)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.get $2)
                       (local.tee $1
                        (i64.add
                         (local.tee $3
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (struct.get $type23 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.get $2)
                        )
                       )
                      )
                      (i64.xor
                       (local.get $1)
                       (local.get $3)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.get $1)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (local.set $5
                        (struct.get $type23 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.get $1)
                           (local.tee $2
                            (i64.add
                             (local.tee $3
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (struct.get $type23 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (i64.xor
                           (local.get $2)
                           (local.get $3)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.get $2)
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (local.set $4
                            (struct.get $type23 1
                             (local.get $5)
                            )
                           )
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.get $2)
                               (local.tee $1
                                (i64.add
                                 (local.tee $3
                                  (i64.extend_i32_u
                                   (struct.get $type14 1
                                    (struct.get $type23 0
                                     (local.get $5)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $2)
                                )
                               )
                              )
                              (i64.xor
                               (local.get $1)
                               (local.get $3)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.get $1)
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $1)
                              )
                              (else
                               (local.set $5
                                (struct.get $type23 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.get $1)
                                   (local.tee $2
                                    (i64.add
                                     (local.tee $3
                                      (i64.extend_i32_u
                                       (struct.get $type14 1
                                        (struct.get $type23 0
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (i64.xor
                                   (local.get $2)
                                   (local.get $3)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.get $2)
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $5)
                                  )
                                  (then
                                   (local.get $2)
                                  )
                                  (else
                                   (local.set $4
                                    (struct.get $type23 1
                                     (local.get $5)
                                    )
                                   )
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.get $2)
                                       (local.tee $1
                                        (i64.add
                                         (local.tee $3
                                          (i64.extend_i32_u
                                           (struct.get $type14 1
                                            (struct.get $type23 0
                                             (local.get $5)
                                            )
                                           )
                                          )
                                         )
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.xor
                                       (local.get $1)
                                       (local.get $3)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.get $1)
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $4)
                                      )
                                      (then
                                       (local.get $1)
                                      )
                                      (else
                                       (local.set $5
                                        (struct.get $type23 1
                                         (local.get $4)
                                        )
                                       )
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.get $1)
                                           (local.tee $2
                                            (i64.add
                                             (local.tee $3
                                              (i64.extend_i32_u
                                               (struct.get $type14 1
                                                (struct.get $type23 0
                                                 (local.get $4)
                                                )
                                               )
                                              )
                                             )
                                             (local.get $1)
                                            )
                                           )
                                          )
                                          (i64.xor
                                           (local.get $2)
                                           (local.get $3)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.get $2)
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $5)
                                          )
                                          (then
                                           (local.get $2)
                                          )
                                          (else
                                           (local.set $4
                                            (struct.get $type23 1
                                             (local.get $5)
                                            )
                                           )
                                           (if
                                            (i64.lt_s
                                             (i64.and
                                              (i64.xor
                                               (local.get $2)
                                               (local.tee $1
                                                (i64.add
                                                 (local.tee $3
                                                  (i64.extend_i32_u
                                                   (struct.get $type14 1
                                                    (struct.get $type23 0
                                                     (local.get $5)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (local.get $2)
                                                )
                                               )
                                              )
                                              (i64.xor
                                               (local.get $1)
                                               (local.get $3)
                                              )
                                             )
                                             (i64.const 0)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.get $1)
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $4)
                                              )
                                              (then
                                               (local.get $1)
                                              )
                                              (else
                                               (local.set $5
                                                (struct.get $type23 1
                                                 (local.get $4)
                                                )
                                               )
                                               (if
                                                (i64.lt_s
                                                 (i64.and
                                                  (i64.xor
                                                   (local.get $1)
                                                   (local.tee $2
                                                    (i64.add
                                                     (local.tee $3
                                                      (i64.extend_i32_u
                                                       (struct.get $type14 1
                                                        (struct.get $type23 0
                                                         (local.get $4)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                  (i64.xor
                                                   (local.get $2)
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (i64.const 0)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.get $2)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                  (then
                                                   (local.get $2)
                                                  )
                                                  (else
                                                   (local.set $4
                                                    (struct.get $type23 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                   (if
                                                    (i64.lt_s
                                                     (i64.and
                                                      (i64.xor
                                                       (local.get $2)
                                                       (local.tee $1
                                                        (i64.add
                                                         (local.tee $3
                                                          (i64.extend_i32_u
                                                           (struct.get $type14 1
                                                            (struct.get $type23 0
                                                             (local.get $5)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (local.get $2)
                                                        )
                                                       )
                                                      )
                                                      (i64.xor
                                                       (local.get $1)
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (i64.const 0)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.get $1)
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $4)
                                                      )
                                                      (then
                                                       (local.get $1)
                                                      )
                                                      (else
                                                       (local.set $5
                                                        (struct.get $type23 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (if
                                                        (i64.lt_s
                                                         (i64.and
                                                          (i64.xor
                                                           (local.get $1)
                                                           (local.tee $2
                                                            (i64.add
                                                             (local.tee $3
                                                              (i64.extend_i32_u
                                                               (struct.get $type14 1
                                                                (struct.get $type23 0
                                                                 (local.get $4)
                                                                )
                                                               )
                                                              )
                                                             )
                                                             (local.get $1)
                                                            )
                                                           )
                                                          )
                                                          (i64.xor
                                                           (local.get $2)
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (i64.const 0)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (call $function37
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (local.get $5)
                                                        (local.get $2)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (call $string-new
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (drop
   (call $function38
    (local.get $6)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $6)
 )
 (func $function37 (type $8) (param $0 i32) (param $1 i32) (param $2 (ref null $type23)) (param $3 i64) (result i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type23))
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $6
       (struct.get $type23 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.tee $5
             (i64.extend_i32_u
              (struct.get $type14 1
               (struct.get $type23 0
                (local.get $2)
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call25) (param $0 (ref $type14)) (param $1 (ref null $type23)) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type14))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $5
      (struct.get $type23 0
       (local.get $1)
      )
     )
     (i64.const 0)
     (local.tee $3
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $5)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type23 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $4
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (local.get $4)
    )
   )
  )
 )
 (func $function42 (type $call30) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type32))
  (local $3 (ref $type27))
  (struct.set $type32 1
   (local.tee $2
    (struct.new_default $type32)
   )
   (struct.new $type27
    (ref.func $function44)
    (struct.new $environment44
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type32 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type32 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type32 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $3)
   )
  )
 )
 (func $function44 (type $call27) (param $0 (ref null $environment44)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type34))
  (local $4 (ref $type30))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment44 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type27 1
      (global.get $global116)
     )
    )
    (drop
     (struct.get $environment44 0
      (local.get $0)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global108)
     )
    )
    (drop
     (struct.get $type30 1
      (global.get $global119)
     )
    )
    (struct.set $type34 1
     (local.tee $3
      (struct.new_default $type34)
     )
     (struct.new $type30
      (ref.func $function48)
      (struct.new $environment48
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (struct.set $type34 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call30
      (struct.get $type30 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type34 1
          (local.get $3)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type30 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type32 0
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type27 1
      (struct.get $type32 1
       (struct.get $environment44 1
        (local.get $0)
       )
      )
     )
     (local.get $2)
     (local.get $1)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (i64.eqz
        (local.get $1)
       )
       (then
        (i64.eqz
         (global.get $global109)
        )
       )
       (else
        (i32.and
         (i64.eq
          (global.get $global110)
          (local.get $2)
         )
         (i64.eq
          (global.get $global109)
          (i64.const 2)
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function45 (type $call27) (param $0 (ref null $environment44)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function46 (type $call30) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type34))
  (local $3 (ref $type30))
  (struct.set $type34 1
   (local.tee $2
    (struct.new_default $type34)
   )
   (struct.new $type30
    (ref.func $function48)
    (struct.new $environment48
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type34 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type34 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call30
   (struct.get $type30 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type34 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type30 0
    (local.get $3)
   )
  )
 )
 (func $function48 (type $call30) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type34))
  (local $3 (ref $type30))
  (local $4 i64)
  (if (result i64)
   (i64.ge_s
    (local.get $1)
    (i64.const 10)
   )
   (then
    (i64.extend_i32_u
     (struct.get $type14 1
      (struct.get $type28 0
       (global.get $global106)
      )
     )
    )
   )
   (else
    (struct.set $type28 0
     (global.get $global106)
     (global.get $string3)
    )
    (drop
     (struct.get $type30 1
      (global.get $global123)
     )
    )
    (struct.set $type34 1
     (local.tee $2
      (struct.new_default $type34)
     )
     (struct.new $type30
      (ref.func $function51)
      (struct.new $environment51
       (struct.get $environment48 0
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type34 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call30
      (struct.get $type30 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type34 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type30 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type30 1
      (struct.get $type34 1
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function49 (type $call30) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type34))
  (local $3 (ref $type30))
  (struct.set $type34 1
   (local.tee $2
    (struct.new_default $type34)
   )
   (struct.new $type30
    (ref.func $function51)
    (struct.new $environment51
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type34 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type34 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call30
   (struct.get $type30 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type34 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type30 0
    (local.get $3)
   )
  )
 )
 (func $function51 (type $call30) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 (ref $type28))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (if (result i64)
   (i64.gt_s
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type14 1
       (struct.get $type28 0
        (global.get $global106)
       )
      )
     )
    )
    (struct.get $environment51 0
     (ref.cast (ref $environment51)
      (local.get $0)
     )
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global107)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (struct.set $type28 0
     (local.tee $3
      (ref.as_non_null
       (global.get $global106)
      )
     )
     (call $function35
      (struct.new $type23
       (global.get $string0)
       (struct.new $type23
        (local.tee $4
         (struct.get $type28 0
          (local.get $3)
         )
        )
        (struct.new $type23
         (global.get $string1)
         (struct.new $type23
          (local.get $4)
          (struct.new $type23
           (global.get $string2)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (struct.set $type28 0
     (ref.as_non_null
      (global.get $global106)
     )
     (block (result (ref $type14))
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (call $function35
       (struct.new $type23
        (call $function33
         (local.tee $4
          (struct.get $type28 0
           (global.get $global106)
          )
         )
         (i64.shr_u
          (local.tee $2
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $4)
            )
           )
          )
          (i64.const 1)
         )
         (local.get $2)
        )
        (block (result (ref (exact $type23)))
         (drop
          (ref.as_non_null
           (global.get $global81)
          )
         )
         (struct.new $type23
          (call $function33
           (struct.get $type28 0
            (global.get $global106)
           )
           (i64.const 0)
           (i64.add
            (i64.shr_u
             (i64.extend_i32_u
              (struct.get $type14 1
               (struct.get $type28 0
                (global.get $global106)
               )
              )
             )
             (i64.const 1)
            )
            (i64.const 1)
           )
          )
          (block (result nullref)
           (drop
            (ref.as_non_null
             (global.get $global88)
            )
           )
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (drop
     (struct.get $type28 0
      (global.get $global106)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type34 0
       (struct.get $environment51 1
        (ref.cast (ref $environment51)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (struct.get $type30 1
      (struct.get $type34 1
       (struct.get $environment51 1
        (ref.cast (ref $environment51)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type32))
  (local $2 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type30 1
    (global.get $global111)
   )
  )
  (struct.set $type32 1
   (local.tee $1
    (struct.new_default $type32)
   )
   (struct.new $type27
    (ref.func $function44)
    (struct.new $environment44
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type32 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type32 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call27
   (struct.get $type27 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type32 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type27 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $global81
   (struct.new_default $type20)
  )
  (global.set $global88
   (struct.new_default $type22)
  )
  (global.set $global91
   (struct.new_default $type24)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type25)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global116
   (struct.new $type27
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $global106
   (struct.new $type28
    (global.get $string3)
   )
  )
  (global.set $global107
   (struct.new_default $type29)
  )
  (global.set $global123
   (struct.new $type30
    (ref.func $function49)
    (ref.null none)
   )
  )
  (global.set $global119
   (struct.new $type30
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $global108
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $global109
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $global110
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $global111
   (struct.new $type30
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

