(module
 (rec
  (type $type55 (sub (struct (field i32))))
  (type $environment159 (struct (field (ref $type12)) (field (ref $type12)) (field (ref $type103))))
  (type $type103 (struct (field (mut i32)) (field (mut (ref null $type46)))))
  (type $call53 (func (param (ref null $type42) (ref null $type42)) (result i32)))
  (type $4 (func (param (ref null $type20) i32 i32 i32 (ref null $type19) i64) (result (ref $type20))))
  (type $5 (func (param i32 i32 (ref null $type19) i64) (result i64)))
  (type $6 (func (param (ref null $type17) i32 i32 i32 (ref null $type16) i64) (result (ref $type17))))
  (type $type99 (struct (field (ref $environment142))))
  (type $type101 (struct (field (mut i32)) (field (mut (ref null $type99)))))
  (type $type85 (struct))
  (type $environment142 (struct (field i64) (field (ref $type101))))
  (type $type75 (struct))
  (type $type16 (struct (field f64) (field (ref null $type16))))
  (type $type19 (struct (field (ref $type17)) (field (ref null $type19))))
  (type $call99 (func (param (ref $environment142) i64 (ref $type55)) (result (ref $type55))))
  (type $type58 (sub $type55 (struct (field i32) (field (ref $type42)))))
  (type $type84 (struct (field (ref $environment137))))
  (type $type98 (struct (field (mut i32)) (field (mut (ref null $type84)))))
  (type $environment137 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type12)) (field (ref $type12)) (field (ref $type49)) (field (ref $type12)) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type80)) (field (ref $type98))))
  (type $call84 (func (param (ref $environment137)) (result (ref $type55))))
  (type $environment132 (struct (field (ref $type20)) (field i64) (field (ref $type49)) (field (ref $type90))))
  (type $environment130 (struct (field (ref $type12)) (field (ref $type49)) (field (ref $type90))))
  (type $environment124 (struct (field (ref $type20)) (field i64) (field (ref $type49)) (field (ref $type49)) (field i64) (field (ref $type90))))
  (type $environment126 (struct (field (ref $type20)) (field i64) (field (ref $type49)) (field (ref $type49)) (field f64) (field (ref $type90))))
  (type $environment122 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type49)) (field (ref $type49)) (field i32) (field f64) (field (ref $type90))))
  (type $25 (func (param (ref $environment120) f64)))
  (type $environment117 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type90))))
  (type $environment115 (struct (field (ref $type20)) (field i64) (field (ref $type14)) (field (ref $type90))))
  (type $type10 (struct (field (ref $environment111))))
  (type $type97 (struct (field (mut i32)) (field (mut (ref null $type10)))))
  (type $environment134 (struct (field (ref $type20)) (field i64) (field (ref $type49)) (field (ref $type90))))
  (type $environment128 (struct (field (ref $type20)) (field i64) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type90))))
  (type $environment120 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type49)) (field (ref $type49)) (field i32)))
  (type $environment113 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type12)) (field (ref $type14)) (field (ref $type49)) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type80)) (field (ref $type82)) (field (ref $type85)) (field (ref $type90))))
  (type $environment111 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type12)) (field (ref $type12)) (field (ref $type14)) (field (ref $type49)) (field (ref $type12)) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type80)) (field (ref $type82)) (field (ref $type82)) (field (ref $type85)) (field (ref $type97))))
  (type $call10 (func (param (ref $environment111)) (result i32)))
  (type $call94 (func (param (ref $environment108) i64 f64) (result i32)))
  (type $type94 (struct (field (ref $environment108))))
  (type $environment108 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type96))))
  (type $environment106 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type90))))
  (type $type96 (struct (field (mut i32)) (field (mut (ref null $type94)))))
  (type $environment104 (struct (field (ref $type14)) (field (ref $type90))))
  (type $environment101 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type12)) (field (ref $type12)) (field (ref $type90))))
  (type $environment99 (struct (field i64) (field (ref $type12)) (field (ref $type12)) (field (ref $type90))))
  (type $environment97 (struct (field (ref $type20)) (field i64) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field i64) (field (ref $type80)) (field (ref $type80)) (field (ref $type90))))
  (type $type82 (struct (field (mut i32))))
  (type $environment93 (struct (field (ref $type20)) (field i64) (field i64) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type80)) (field (ref $type82)) (field (ref $type90))))
  (type $call88 (func (param (ref struct) i64) (result i32)))
  (type $environment89 (struct (field (ref $type20)) (field (ref $type12)) (field (ref $type49)) (field (ref $type49)) (field (ref $type80)) (field i64) (field i32) (field (ref $type90))))
  (type $type80 (struct (field (mut f64))))
  (type $type17 (array (mut f64)))
  (type $type20 (array (mut (ref $type17))))
  (type $type88 (struct (field (ref $call88)) (field (ref struct))))
  (type $type90 (struct (field (mut i32)) (field (mut (ref null $type88)))))
  (type $54 (func (param (ref $type20) (ref $type12) (ref $type49) (ref $type49) (ref $type80) i64 i32) (result i32)))
  (type $type14 (array (mut i32)))
  (type $56 (func (param i64 (ref $type14) i32 i32 i32 i64) (result (ref $type14))))
  (type $57 (func (param i64 (ref $type12) i32 i32 i32 i64) (result (ref $type12))))
  (type $type71 (struct (field (ref $environment61))))
  (type $environment61 (struct (field (ref $type49)) (field (ref $type73))))
  (type $type73 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $call71 (func (param (ref $environment61) i64) (result (ref null $type42))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $type12 (array (mut i64)))
  (type $type49 (struct (field (mut i64))))
  (type $environment55 (struct (field (ref $type49)) (field i64) (field (ref $type12)) (field (ref $type69))))
  (type $call11 (func (param (ref null $environment55) i64) (result (ref $type12))))
  (type $call46 (func (param (ref null $environment159) i64) (result i32)))
  (type $type65 (struct))
  (type $type42 (struct (field (ref $type12)) (field (ref null $type42))))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type59 (struct))
  (type $type0 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct (field (ref $call46)) (field (ref null $environment159))))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type41 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type22 (struct))
  (type $type21 (struct))
  (type $type18 (struct))
  (type $type15 (struct))
  (type $type13 (struct))
  (type $type11 (struct (field (ref $call11)) (field (ref null $environment55))))
  (type $type8 (struct))
  (type $type5 (struct))
  (type $type57 (sub $type55 (struct (field i32))))
  (type $type56 (sub $type55 (struct (field i32))))
 )
 (type $101 (func (param i64) (result i64)))
 (type $102 (func (result i64)))
 (type $103 (func (param f64) (result f64)))
 (type $104 (func (param i32) (result f64)))
 (type $105 (func))
 (import "benchmark" "expected_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "expected_length" (func $foreign1 (result i64)))
 (import "benchmark" "hide_f64" (func $foreign2 (param f64) (result f64)))
 (import "benchmark" "input_f64" (func $foreign3 (param i32) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $empty56 (ref $type56) (struct.new $type56
  (i32.const 0)
 ))
 (global $empty57 (ref $type57) (struct.new $type57
  (i32.const 1)
 ))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $global154 (mut (ref null $type11)) (ref.null none))
 (global $global161 (mut (ref null $type13)) (ref.null none))
 (global $global256 (mut (ref null $type15)) (ref.null none))
 (global $global269 (mut (ref null $type18)) (ref.null none))
 (global $global258 (mut (ref null $type21)) (ref.null none))
 (global $ready258 (mut i32) (i32.const 0))
 (global $global271 (mut (ref null $type22)) (ref.null none))
 (global $ready271 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type25)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global274 (mut (ref null $type26)) (ref.null none))
 (global $ready274 (mut i32) (i32.const 0))
 (global $global241 (mut (ref null $type41)) (ref.null none))
 (global $global106 (mut (ref null $type43)) (ref.null none))
 (global $global108 (mut (ref null $type43)) (ref.null none))
 (global $global110 (mut (ref null $type44)) (ref.null none))
 (global $global114 (mut (ref null $type45)) (ref.null none))
 (global $global119 (mut (ref null $type46)) (ref.null none))
 (global $global121 (mut (ref null $type47)) (ref.null none))
 (global $global198 (mut (ref null $type47)) (ref.null none))
 (global $global219 (mut (ref null $type46)) (ref.null none))
 (global $global123 (mut (ref null $type43)) (ref.null none))
 (global $global125 (mut (ref null $type48)) (ref.null none))
 (global $global128 (mut (ref null $type50)) (ref.null none))
 (global $global134 (mut (ref null $type51)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global290 (mut (ref null $type52)) (ref.null none))
 (global $global287 (mut (ref null $type53)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global282 (mut (ref null $type54)) (ref.null none))
 (global $global251 (mut (ref null $type0)) (ref.null none))
 (global $global147 (mut (ref null $type59)) (ref.null none))
 (global $global151 (mut (ref null $type59)) (ref.null none))
 (global $global178 (mut (ref null $type60)) (ref.null none))
 (global $global207 (mut (ref null $type61)) (ref.null none))
 (global $global140 (mut (ref null $type62)) (ref.null none))
 (global $global141 (mut (ref null $type63)) (ref.null none))
 (global $global254 (mut (ref null $type64)) (ref.null none))
 (global $global244 (mut f64) (f64.const 0.0))
 (global $global245 (mut (ref null $type42)) (ref.null none))
 (global $global246 (mut (ref null $type65)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function45 (type $call46) (param $0 (ref null $environment159)) (param $1 i64) (result i32)
  (i64.gt_s
   (local.get $1)
   (i64.const 0)
  )
 )
 (func $function55 (type $call11) (param $0 (ref null $environment55)) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment55))
  (local $3 (ref $type49))
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment55 1
     (local.tee $2
      (ref.as_non_null
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $environment55 2
     (local.get $2)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (local.set $5
     (call $foreign0
      (struct.get $type49 0
       (local.tee $3
        (struct.get $environment55 0
         (local.get $2)
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.add
          (local.tee $6
           (struct.get $type49 0
            (local.get $3)
           )
          )
          (i64.const 1)
         )
        )
        (local.get $6)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type49 0
     (local.get $3)
     (local.get $4)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment55 2
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $4
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment55 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (struct.get $type11 1
      (struct.get $type69 1
       (struct.get $environment55 3
        (local.get $2)
       )
      )
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function61 (type $call71) (param $0 (ref $environment61)) (param $1 i64) (result (ref null $type42))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type69))
  (local $6 (ref $type49))
  (local $7 (ref $type11))
  (local $8 (ref $type12))
  (local $9 (ref $type73))
  (if (result (ref null $type42))
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result nullref)
     (i64.eq
      (struct.get $type49 0
       (struct.get $environment61 0
        (local.get $0)
       )
      )
      (call $foreign1)
     )
     (then
      (ref.null none)
     )
     (else
      (unreachable)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (local.set $2
     (call $foreign0
      (struct.get $type49 0
       (local.tee $6
        (struct.get $environment61 0
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.tee $4
           (struct.get $type49 0
            (local.get $6)
           )
          )
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type49 0
     (local.get $6)
     (local.get $3)
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type69 1
     (local.tee $5
      (struct.new_default $type69)
     )
     (struct.new $type11
      (ref.func $function55)
      (struct.new $environment55
       (local.get $6)
       (local.get $2)
       (array.new_default $type12
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (local.get $5)
      )
     )
    )
    (struct.set $type69 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type42
     (call_ref $call11
      (struct.get $type11 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type69 1
          (local.get $5)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type11 0
       (local.get $7)
      )
     )
     (block (result (ref null $type42))
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type73 0
         (local.tee $9
          (struct.get $environment61 1
           (local.get $0)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function61
       (struct.get $type71 0
        (struct.get $type73 1
         (local.get $9)
        )
       )
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function70 (type $call11) (param $0 (ref null $environment55)) (param $1 i64) (result (ref $type12))
  (if (result (ref $type12))
   (i32.or
    (i64.lt_s
     (local.get $1)
     (i64.const 0)
    )
    (i64.gt_s
     (local.get $1)
     (i64.const 4294967295)
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function71
       (local.get $1)
       (array.new_default $type12
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function71 (type $57) (param $0 i64) (param $1 (ref $type12)) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type12))
  (local $6 i64)
  (if (result (ref $type12))
   (i64.eq
    (local.get $0)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
     (i64.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function75 (type $56) (param $0 i64) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type14))
  (local $6 i64)
  (if (result (ref $type14))
   (i64.eq
    (local.get $0)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global58)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
     (i32.const 0)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function75
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function86 (type $54) (param $0 (ref $type20)) (param $1 (ref $type12)) (param $2 (ref $type49)) (param $3 (ref $type49)) (param $4 (ref $type80)) (param $5 i64) (param $6 i32) (result i32)
  (local $7 (ref $type90))
  (local $8 (ref $type88))
  (local $9 i64)
  (struct.set $type49 0
   (local.get $3)
   (array.get $type12
    (local.get $1)
    (i32.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $9
     (struct.get $type49 0
      (local.get $3)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type80 0
   (local.get $4)
   (array.get $type17
    (array.get $type20
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (i32.wrap_i64
     (local.get $9)
    )
   )
  )
  (struct.set $type90 1
   (local.tee $7
    (struct.new_default $type90)
   )
   (struct.new $type88
    (ref.func $function89)
    (struct.new $environment89
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
    )
   )
  )
  (struct.set $type90 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type90 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call88
   (struct.get $type88 1
    (local.tee $8
     (ref.as_non_null
      (struct.get $type90 1
       (local.get $7)
      )
     )
    )
   )
   (i64.const 1)
   (struct.get $type88 0
    (local.get $8)
   )
  )
 )
 (func $function89 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment89))
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 i64)
  (local $7 i64)
  (if (result i32)
   (i64.le_s
    (struct.get $type49 0
     (struct.get $environment89 2
      (ref.cast (ref $environment89)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $5
     (if (result f64)
      (struct.get $environment89 6
       (local.tee $2
        (ref.cast (ref $environment89)
         (local.get $0)
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global123)
        )
       )
       (local.set $6
        (array.get $type12
         (struct.get $environment89 1
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i64.gt_u
         (local.tee $7
          (struct.get $environment89 5
           (local.get $2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $6)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global123)
        )
       )
       (f64.sub
        (local.tee $4
         (if (result f64)
          (f64.eq
           (local.tee $3
            (array.get $type17
             (array.get $type20
              (struct.get $environment89 0
               (local.get $2)
              )
              (i32.wrap_i64
               (local.get $7)
              )
             )
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
           (f64.const 0.0)
          )
          (then
           (f64.const 0.0)
          )
          (else
           (if (result f64)
            (f64.lt
             (local.get $3)
             (f64.const 0.0)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global106)
              )
             )
             (if
              (i32.and
               (f64.eq
                (f64.abs
                 (local.tee $4
                  (f64.sub
                   (f64.const -0.0)
                   (local.get $3)
                  )
                 )
                )
                (f64.const inf)
               )
               (f64.lt
                (f64.abs
                 (local.get $3)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.get $4)
            )
            (else
             (local.get $3)
            )
           )
          )
         )
        )
        (local.tee $3
         (if (result f64)
          (f64.eq
           (local.tee $3
            (struct.get $type80 0
             (struct.get $environment89 4
              (local.get $2)
             )
            )
           )
           (f64.const 0.0)
          )
          (then
           (f64.const 0.0)
          )
          (else
           (if (result f64)
            (f64.lt
             (local.get $3)
             (f64.const 0.0)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global106)
              )
             )
             (if
              (i32.and
               (f64.eq
                (f64.abs
                 (local.tee $5
                  (f64.sub
                   (f64.const -0.0)
                   (local.get $3)
                  )
                 )
                )
                (f64.const inf)
               )
               (f64.lt
                (f64.abs
                 (local.get $3)
                )
                (f64.const inf)
               )
              )
              (then
               (unreachable)
              )
             )
             (local.get $5)
            )
            (else
             (local.get $3)
            )
           )
          )
         )
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $6
        (array.get $type12
         (struct.get $environment89 1
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (if
        (i64.gt_u
         (local.tee $7
          (struct.get $environment89 5
           (local.get $2)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $6)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (f64.sub
        (local.tee $4
         (array.get $type17
          (array.get $type20
           (struct.get $environment89 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
        (local.tee $3
         (struct.get $type80 0
          (struct.get $environment89 4
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $4)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $3)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $5)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global121)
     )
    )
    (if
     (f64.gt
      (local.get $5)
      (f64.const 0.0)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type49 0
       (struct.get $environment89 3
        (local.get $2)
       )
       (array.get $type12
        (struct.get $environment89 1
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (array.get $type12
        (struct.get $environment89 1
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $7
         (struct.get $environment89 5
          (local.get $2)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type80 0
       (struct.get $environment89 4
        (local.get $2)
       )
       (array.get $type17
        (array.get $type20
         (struct.get $environment89 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $7)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment89 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment89 7
        (local.get $2)
       )
      )
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function93 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment93))
  (local $3 (ref $type90))
  (local $4 (ref $type12))
  (local $5 (ref $type49))
  (local $6 (ref $type80))
  (local $7 (ref $type80))
  (local $8 (ref $type80))
  (local $9 (ref $type88))
  (local $10 i64)
  (local $11 i64)
  (local $12 f64)
  (local $13 f64)
  (local $14 f64)
  (if (result i32)
   (i64.eq
    (struct.get $environment93 1
     (ref.cast (ref $environment93)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (if (result i32)
      (struct.get $type82 0
       (struct.get $environment93 7
        (local.tee $2
         (ref.cast (ref $environment93)
          (local.get $0)
         )
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $10
          (array.get $type12
           (struct.get $environment93 3
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $11
          (struct.get $type49 0
           (struct.get $environment93 5
            (local.get $2)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global106)
        )
       )
       (if
        (f64.lt
         (array.get $type17
          (array.get $type20
           (struct.get $environment93 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $10)
           )
          )
          (i32.wrap_i64
           (local.get $11)
          )
         )
         (f64.const -1e-06)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global106)
          )
         )
         (if
          (i64.gt_u
           (local.tee $10
            (array.get $type12
             (struct.get $environment93 3
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (f64.eq
            (f64.abs
             (local.tee $13
              (f64.sub
               (f64.const -0.0)
               (local.tee $12
                (array.get $type17
                 (array.get $type20
                  (struct.get $environment93 0
                   (local.get $2)
                  )
                  (i32.wrap_i64
                   (local.get $10)
                  )
                 )
                 (i32.const 0)
                )
               )
              )
             )
            )
            (f64.const inf)
           )
           (f64.lt
            (f64.abs
             (local.get $12)
            )
            (f64.const inf)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $10
            (array.get $type12
             (struct.get $environment93 3
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $11
            (struct.get $type49 0
             (struct.get $environment93 5
              (local.get $2)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $12
          (f64.div
           (local.get $13)
           (local.tee $14
            (array.get $type17
             (array.get $type20
              (struct.get $environment93 0
               (local.get $2)
              )
              (i32.wrap_i64
               (local.get $10)
              )
             )
             (i32.wrap_i64
              (local.get $11)
             )
            )
           )
          )
         )
         (if
          (i32.and
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.get $13)
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $14)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.get $12)
             )
             (f64.const inf)
            )
           )
           (f64.ne
            (local.get $14)
            (f64.const 0.0)
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $environment93 3
           (local.get $2)
          )
         )
         (local.set $5
          (struct.get $environment93 4
           (local.get $2)
          )
         )
         (if
          (f64.gt
           (struct.get $type80 0
            (local.tee $6
             (struct.get $environment93 6
              (local.get $2)
             )
            )
           )
           (local.get $12)
          )
          (then
           (if
            (i64.gt_u
             (local.get $1)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (struct.set $type49 0
            (local.get $5)
            (array.get $type12
             (local.get $4)
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (struct.set $type80 0
            (local.get $6)
            (local.get $12)
           )
          )
          (else
           (if
            (f64.eq
             (struct.get $type80 0
              (local.get $6)
             )
             (local.get $12)
            )
            (then
             (struct.set $type90 1
              (local.tee $3
               (struct.new_default $type90)
              )
              (struct.new $type88
               (ref.func $function97)
               (struct.new $environment97
                (struct.get $environment93 0
                 (local.get $2)
                )
                (struct.get $environment93 2
                 (local.get $2)
                )
                (local.get $4)
                (local.get $5)
                (struct.get $environment93 5
                 (local.get $2)
                )
                (local.get $1)
                (local.tee $7
                 (struct.new_default $type80)
                )
                (local.tee $8
                 (struct.new_default $type80)
                )
                (local.get $3)
               )
              )
             )
             (struct.set $type90 0
              (local.get $3)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type90 0
                (local.get $3)
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (call_ref $call88
               (struct.get $type88 1
                (local.tee $9
                 (ref.as_non_null
                  (struct.get $type90 1
                   (local.get $3)
                  )
                 )
                )
               )
               (i64.const 1)
               (struct.get $type88 0
                (local.get $9)
               )
              )
             )
             (if
              (f64.lt
               (struct.get $type80 0
                (local.get $8)
               )
               (struct.get $type80 0
                (local.get $7)
               )
              )
              (then
               (if
                (i64.gt_u
                 (local.get $1)
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (struct.set $type49 0
                (local.get $5)
                (array.get $type12
                 (local.get $4)
                 (i32.wrap_i64
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $10
          (array.get $type12
           (struct.get $environment93 3
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $11
          (struct.get $type49 0
           (struct.get $environment93 5
            (local.get $2)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global106)
        )
       )
       (if
        (f64.lt
         (array.get $type17
          (array.get $type20
           (struct.get $environment93 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $10)
           )
          )
          (i32.wrap_i64
           (local.get $11)
          )
         )
         (f64.const -1e-06)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global106)
          )
         )
         (if
          (i64.gt_u
           (local.tee $10
            (array.get $type12
             (struct.get $environment93 3
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (f64.eq
            (f64.abs
             (local.tee $12
              (f64.sub
               (f64.const -0.0)
               (local.tee $13
                (array.get $type17
                 (array.get $type20
                  (struct.get $environment93 0
                   (local.get $2)
                  )
                  (i32.wrap_i64
                   (local.get $10)
                  )
                 )
                 (i32.const 0)
                )
               )
              )
             )
            )
            (f64.const inf)
           )
           (f64.lt
            (f64.abs
             (local.get $13)
            )
            (f64.const inf)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $10
            (array.get $type12
             (struct.get $environment93 3
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $11
            (struct.get $type49 0
             (struct.get $environment93 5
              (local.get $2)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $14
          (f64.div
           (local.get $12)
           (local.tee $13
            (array.get $type17
             (array.get $type20
              (struct.get $environment93 0
               (local.get $2)
              )
              (i32.wrap_i64
               (local.get $10)
              )
             )
             (i32.wrap_i64
              (local.get $11)
             )
            )
           )
          )
         )
         (if
          (i32.and
           (i32.and
            (i32.and
             (f64.lt
              (f64.abs
               (local.get $12)
              )
              (f64.const inf)
             )
             (f64.lt
              (f64.abs
               (local.get $13)
              )
              (f64.const inf)
             )
            )
            (f64.eq
             (f64.abs
              (local.get $14)
             )
             (f64.const inf)
            )
           )
           (f64.ne
            (local.get $13)
            (f64.const 0.0)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type80 0
          (struct.get $environment93 6
           (local.get $2)
          )
          (local.get $14)
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (struct.set $type49 0
          (struct.get $environment93 4
           (local.get $2)
          )
          (array.get $type12
           (struct.get $environment93 3
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (struct.set $type82 0
          (struct.get $environment93 7
           (local.get $2)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 0)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $10
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment93 8
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function93
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment93 8
        (local.get $2)
       )
      )
     )
     (local.get $10)
    )
   )
  )
 )
 (func $function97 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment97))
  (local $3 (ref $type20))
  (local $4 (ref $type80))
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (if (result i32)
   (i64.ge_s
    (struct.get $environment97 1
     (local.tee $2
      (ref.cast (ref $environment97)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type49 0
        (struct.get $environment97 3
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $8
         (f64.sub
          (f64.const -0.0)
          (local.tee $7
           (array.get $type17
            (array.get $type20
             (local.tee $3
              (struct.get $environment97 0
               (local.get $2)
              )
             )
             (i32.wrap_i64
              (local.get $5)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $7)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $type49 0
        (struct.get $environment97 3
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (struct.get $type49 0
        (struct.get $environment97 4
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (f64.div
      (local.get $8)
      (local.tee $7
       (array.get $type17
        (array.get $type20
         (local.get $3)
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (i32.and
        (f64.lt
         (f64.abs
          (local.get $8)
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $7)
         )
         (f64.const inf)
        )
       )
       (f64.eq
        (f64.abs
         (local.get $9)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $7)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type80 0
     (struct.get $environment97 6
      (local.get $2)
     )
     (local.get $9)
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $environment97 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (array.get $type12
        (struct.get $environment97 2
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $8
         (f64.sub
          (f64.const -0.0)
          (local.tee $7
           (array.get $type17
            (array.get $type20
             (struct.get $environment97 0
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $5)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $7)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (struct.get $environment97 5
        (local.get $2)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (array.get $type12
        (struct.get $environment97 2
         (local.get $2)
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (struct.get $type49 0
        (struct.get $environment97 4
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (f64.div
      (local.get $8)
      (local.tee $7
       (array.get $type17
        (array.get $type20
         (struct.get $environment97 0
          (local.get $2)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (i32.and
        (f64.lt
         (f64.abs
          (local.get $8)
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $7)
         )
         (f64.const inf)
        )
       )
       (f64.eq
        (f64.abs
         (local.get $9)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $7)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type80 0
     (local.tee $4
      (struct.get $environment97 7
       (local.get $2)
      )
     )
     (local.get $9)
    )
    (if (result i32)
     (f64.eq
      (struct.get $type80 0
       (local.get $4)
      )
      (struct.get $type80 0
       (struct.get $environment97 6
        (local.get $2)
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $5
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (struct.get $environment97 8
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function97
       (struct.get $type88 1
        (struct.get $type90 1
         (struct.get $environment97 8
          (local.get $2)
         )
        )
       )
       (local.get $5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function99 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $type12))
  (if (result i32)
   (i64.eq
    (struct.get $environment99 0
     (ref.cast (ref $environment99)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $environment99 1
      (ref.cast (ref $environment99)
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment99 2
      (ref.cast (ref $environment99)
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment99 3
        (ref.cast (ref $environment99)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment99 3
        (ref.cast (ref $environment99)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function101 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type12))
  (local $5 (ref $environment101))
  (local $6 (ref $type20))
  (if (result i32)
   (i64.eq
    (struct.get $environment101 1
     (ref.cast (ref $environment101)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (f64.lt
      (array.get $type17
       (array.get $type20
        (struct.get $environment101 0
         (ref.cast (ref $environment101)
          (local.get $0)
         )
        )
        (block (result i32)
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $2
              (i64.add
               (local.get $1)
               (i64.const 1)
              )
             )
             (local.get $1)
            )
            (i64.xor
             (local.get $2)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global198)
          )
         )
         (if
          (i64.gt_u
           (local.get $2)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (i32.const 0)
      )
      (f64.const 0.0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global140)
       )
      )
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment101 3
      (ref.cast (ref $environment101)
       (local.get $0)
      )
     )
     (block (result i32)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (array.set $type12
     (struct.get $environment101 4
      (local.tee $5
       (ref.cast (ref $environment101)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (local.set $2
       (i64.add
        (local.get $1)
        (local.tee $3
         (struct.get $environment101 2
          (local.get $5)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $2)
          (local.get $3)
         )
         (i64.xor
          (local.get $1)
          (local.get $2)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment101 5
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment101 5
        (local.get $5)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function104 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (drop
   (ref.cast (ref $environment104)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $environment104 0
      (ref.cast (ref $environment104)
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment104 1
        (ref.cast (ref $environment104)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function104
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment104 1
        (ref.cast (ref $environment104)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function106 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type96))
  (local $5 (ref $environment106))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment106 2
      (ref.cast (ref $environment106)
       (local.get $0)
      )
     )
    )
    (i64.const 1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (struct.set $type96 1
     (local.tee $4
      (struct.new_default $type96)
     )
     (struct.new $type94
      (struct.new $environment108
       (struct.get $environment106 0
        (local.tee $5
         (ref.cast (ref $environment106)
          (local.get $0)
         )
        )
       )
       (struct.get $environment106 1
        (local.get $5)
       )
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type96 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type96 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function108
      (struct.get $type94 0
       (struct.get $type96 1
        (local.get $4)
       )
      )
      (i64.const 3)
      (f64.const 0.0)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment106 3
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function106
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment106 3
        (local.get $5)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function108 (type $call94) (param $0 (ref $environment108)) (param $1 i64) (param $2 f64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 f64)
  (local $6 f64)
  (if (result i32)
   (i64.lt_s
    (local.tee $3
     (struct.get $environment108 1
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $5
         (f64.sub
          (f64.const -0.0)
          (local.get $2)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $2)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $environment108 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (array.get $type20
      (struct.get $environment108 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (local.get $5)
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (struct.get $environment108 2
        (local.get $0)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (f64.add
      (local.get $2)
      (local.tee $6
       (array.get $type17
        (array.get $type20
         (struct.get $environment108 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $2)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $6)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.get $5)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type96 0
       (struct.get $environment108 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function108
     (struct.get $type94 0
      (struct.get $type96 1
       (struct.get $environment108 3
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $5)
    )
   )
  )
 )
 (func $function111 (type $call10) (param $0 (ref $environment111)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $type90))
  (local $8 (ref $type49))
  (local $9 (ref $type49))
  (local $10 (ref $type88))
  (local $11 (ref $type20))
  (local $12 (ref $type80))
  (local $13 (ref $type82))
  (local $14 (ref $type12))
  (local.set $1
   (i64.add
    (local.tee $2
     (struct.get $environment111 1
      (local.get $0)
     )
    )
    (i64.const 1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
     (i64.xor
      (local.get $1)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function86
    (struct.get $environment111 0
     (local.get $0)
    )
    (struct.get $environment111 3
     (local.get $0)
    )
    (struct.get $environment111 6
     (local.get $0)
    )
    (struct.get $environment111 10
     (local.get $0)
    )
    (local.tee $12
     (struct.get $environment111 11
      (local.get $0)
     )
    )
    (local.get $1)
    (i32.const 0)
   )
  )
  (drop
   (if (result i32)
    (f64.le
     (struct.get $type80 0
      (local.get $12)
     )
     (f64.const 1e-06)
    )
    (then
     (local.set $1
      (i64.add
       (local.tee $2
        (struct.get $environment111 1
         (local.get $0)
        )
       )
       (i64.const 1)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $1)
         (local.get $2)
        )
        (i64.xor
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global178)
      )
     )
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global106)
      )
     )
     (if (result i32)
      (f64.lt
       (array.get $type17
        (array.get $type20
         (struct.get $environment111 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (f64.const -1e-06)
      )
      (then
       (struct.set $type82 0
        (struct.get $environment111 13
         (local.get $0)
        )
        (i32.const 0)
       )
       (i32.const 0)
      )
      (else
       (local.set $1
        (i64.add
         (local.tee $2
          (struct.get $environment111 1
           (local.get $0)
          )
         )
         (i64.const 1)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.get $2)
          )
          (i64.xor
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global178)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (f64.le
         (array.get $type17
          (array.get $type20
           (local.tee $11
            (struct.get $environment111 0
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 0)
         )
         (f64.const 1e-06)
        )
        (then
         (struct.set $type90 1
          (local.tee $7
           (struct.new_default $type90)
          )
          (struct.new $type88
           (ref.func $function113)
           (struct.new $environment113
            (local.get $11)
            (struct.get $environment111 1
             (local.get $0)
            )
            (struct.get $environment111 2
             (local.get $0)
            )
            (struct.get $environment111 3
             (local.get $0)
            )
            (struct.get $environment111 5
             (local.get $0)
            )
            (struct.get $environment111 6
             (local.get $0)
            )
            (struct.get $environment111 7
             (local.get $0)
            )
            (struct.get $environment111 9
             (local.get $0)
            )
            (struct.get $environment111 10
             (local.get $0)
            )
            (struct.get $environment111 11
             (local.get $0)
            )
            (struct.get $environment111 12
             (local.get $0)
            )
            (struct.get $environment111 14
             (local.get $0)
            )
            (local.get $7)
           )
          )
         )
         (struct.set $type90 0
          (local.get $7)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type90 0
            (local.get $7)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call88
          (struct.get $type88 1
           (local.tee $10
            (ref.as_non_null
             (struct.get $type90 1
              (local.get $7)
             )
            )
           )
          )
          (i64.const 4)
          (struct.get $type88 0
           (local.get $10)
          )
         )
        )
        (else
         (struct.set $type49 0
          (local.tee $8
           (struct.get $environment111 9
            (local.get $0)
           )
          )
          (i64.const 0)
         )
         (struct.set $type90 1
          (local.tee $7
           (struct.new_default $type90)
          )
          (struct.new $type88
           (ref.func $function93)
           (struct.new $environment93
            (struct.get $environment111 0
             (local.get $0)
            )
            (struct.get $environment111 1
             (local.get $0)
            )
            (struct.get $environment111 2
             (local.get $0)
            )
            (struct.get $environment111 4
             (local.get $0)
            )
            (local.get $8)
            (struct.get $environment111 10
             (local.get $0)
            )
            (struct.new_default $type80)
            (struct.new_default $type82)
            (local.get $7)
           )
          )
         )
         (struct.set $type90 0
          (local.get $7)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type90 0
            (local.get $7)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call_ref $call88
           (struct.get $type88 1
            (local.tee $10
             (ref.as_non_null
              (struct.get $type90 1
               (local.get $7)
              )
             )
            )
           )
           (i64.const 0)
           (struct.get $type88 0
            (local.get $10)
           )
          )
         )
         (drop
          (struct.get $type46 1
           (global.get $global219)
          )
         )
         (if
          (i64.eqz
           (struct.get $type49 0
            (local.get $8)
           )
          )
          (then
           (struct.set $type82 0
            (struct.get $environment111 13
             (local.get $0)
            )
            (i32.const 0)
           )
          )
          (else
           (struct.set $type82 0
            (struct.get $environment111 12
             (local.get $0)
            )
            (i32.const 1)
           )
          )
         )
         (i32.const 0)
        )
       )
      )
     )
    )
    (else
     (struct.set $type49 0
      (local.tee $8
       (struct.get $environment111 9
        (local.get $0)
       )
      )
      (i64.const 0)
     )
     (struct.set $type90 1
      (local.tee $7
       (struct.new_default $type90)
      )
      (struct.new $type88
       (ref.func $function93)
       (struct.new $environment93
        (struct.get $environment111 0
         (local.get $0)
        )
        (struct.get $environment111 1
         (local.get $0)
        )
        (struct.get $environment111 2
         (local.get $0)
        )
        (struct.get $environment111 4
         (local.get $0)
        )
        (local.get $8)
        (struct.get $environment111 10
         (local.get $0)
        )
        (struct.new_default $type80)
        (struct.new_default $type82)
        (local.get $7)
       )
      )
     )
     (struct.set $type90 0
      (local.get $7)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type90 0
        (local.get $7)
       )
      )
      (then
       (unreachable)
      )
     )
     (drop
      (call_ref $call88
       (struct.get $type88 1
        (local.tee $10
         (ref.as_non_null
          (struct.get $type90 1
           (local.get $7)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type88 0
        (local.get $10)
       )
      )
     )
     (drop
      (struct.get $type46 1
       (global.get $global219)
      )
     )
     (if
      (i64.eqz
       (struct.get $type49 0
        (local.get $8)
       )
      )
      (then
       (struct.set $type82 0
        (struct.get $environment111 13
         (local.get $0)
        )
        (i32.const 0)
       )
      )
      (else
       (struct.set $type82 0
        (struct.get $environment111 12
         (local.get $0)
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (if (result i32)
   (struct.get $type82 0
    (local.tee $13
     (struct.get $environment111 12
      (local.get $0)
     )
    )
   )
   (then
    (struct.set $type82 0
     (local.get $13)
     (i32.const 0)
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (local.set $1
     (struct.get $type49 0
      (local.tee $9
       (struct.get $environment111 10
        (local.get $0)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (struct.get $type49 0
        (local.tee $8
         (struct.get $environment111 9
          (local.get $0)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global108)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.eq
        (f64.abs
         (local.tee $6
          (f64.div
           (f64.const 1.0)
           (local.tee $5
            (array.get $type17
             (array.get $type20
              (local.tee $11
               (struct.get $environment111 0
                (local.get $0)
               )
              )
              (i32.wrap_i64
               (local.get $2)
              )
             )
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
      )
      (f64.ne
       (local.get $5)
       (f64.const 0.0)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $function120
     (struct.new $environment120
      (local.get $11)
      (struct.get $environment111 1
       (local.get $0)
      )
      (struct.get $environment111 2
       (local.get $0)
      )
      (local.get $8)
      (local.get $9)
      (i32.const 1)
     )
     (local.get $6)
    )
    (local.set $1
     (i64.sub
      (local.tee $2
       (struct.get $type49 0
        (local.get $8)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.add
          (local.tee $3
           (struct.get $environment111 2
            (local.get $0)
           )
          )
          (i64.const 4)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (i64.const 4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const -1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (if (result i32)
      (i64.ge_s
       (array.get $type12
        (struct.get $environment111 7
         (local.get $0)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (local.get $3)
      )
      (then
       (struct.set $type90 1
        (local.tee $7
         (struct.new_default $type90)
        )
        (struct.new $type88
         (ref.func $function128)
         (struct.new $environment128
          (struct.get $environment111 0
           (local.get $0)
          )
          (struct.get $environment111 1
           (local.get $0)
          )
          (struct.get $environment111 3
           (local.get $0)
          )
          (struct.get $environment111 6
           (local.get $0)
          )
          (struct.get $environment111 10
           (local.get $0)
          )
          (local.get $7)
         )
        )
       )
       (struct.set $type90 0
        (local.get $7)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type90 0
          (local.get $7)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call88
        (struct.get $type88 1
         (local.tee $10
          (ref.as_non_null
           (struct.get $type90 1
            (local.get $7)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type88 0
         (local.get $10)
        )
       )
      )
      (else
       (local.set $1
        (i64.sub
         (local.tee $2
          (struct.get $type49 0
           (struct.get $environment111 9
            (local.get $0)
           )
          )
         )
         (i64.const 1)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.get $2)
          )
          (i64.xor
           (local.get $2)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (array.get $type12
         (struct.get $environment111 7
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (local.set $1
        (i64.add
         (local.tee $3
          (struct.get $environment111 2
           (local.get $0)
          )
         )
         (i64.const 2)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $1)
           (local.get $3)
          )
          (i64.xor
           (local.get $1)
           (i64.const 2)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.le_s
          (local.get $1)
          (local.get $2)
         )
         (then
          (local.set $1
           (i64.sub
            (local.tee $2
             (struct.get $type49 0
              (struct.get $environment111 9
               (local.get $0)
              )
             )
            )
            (i64.const 1)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $1)
              (local.get $2)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $1)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (array.get $type12
            (struct.get $environment111 7
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.add
                (local.tee $3
                 (struct.get $environment111 2
                  (local.get $0)
                 )
                )
                (i64.const 2)
               )
              )
              (i64.const 2)
             )
             (i64.xor
              (local.get $2)
              (local.get $3)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $3
               (i64.sub
                (local.get $1)
                (local.get $2)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (local.get $2)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.get $type14
           (struct.get $environment111 5
            (local.get $0)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (local.set $1
          (i64.sub
           (local.tee $2
            (struct.get $type49 0
             (struct.get $environment111 9
              (local.get $0)
             )
            )
           )
           (i64.const 1)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.get $1)
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (array.get $type12
           (struct.get $environment111 7
            (local.get $0)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $2
              (i64.add
               (local.tee $3
                (struct.get $environment111 2
                 (local.get $0)
                )
               )
               (i64.const 2)
              )
             )
             (i64.const 2)
            )
            (i64.xor
             (local.get $2)
             (local.get $3)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $3
              (i64.sub
               (local.get $1)
               (local.get $2)
              )
             )
             (local.get $1)
            )
            (i64.xor
             (local.get $1)
             (local.get $2)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type14
          (struct.get $environment111 5
           (local.get $0)
          )
          (i32.wrap_i64
           (local.get $3)
          )
          (i32.const 0)
         )
         (local.set $1
          (i64.add
           (local.tee $2
            (struct.get $environment111 1
             (local.get $0)
            )
           )
           (i64.const 1)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.get $1)
             (local.get $2)
            )
            (i64.xor
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (i64.add
           (local.tee $3
            (struct.get $environment111 1
             (local.get $0)
            )
           )
           (i64.const 1)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.get $2)
             (local.get $3)
            )
            (i64.xor
             (local.get $2)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $2)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $3
            (struct.get $type49 0
             (struct.get $environment111 10
              (local.get $0)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (f64.eq
            (f64.abs
             (local.tee $6
              (f64.add
               (local.tee $5
                (array.get $type17
                 (array.get $type20
                  (struct.get $environment111 0
                   (local.get $0)
                  )
                  (i32.wrap_i64
                   (local.get $2)
                  )
                 )
                 (i32.wrap_i64
                  (local.get $3)
                 )
                )
               )
               (f64.const 1.0)
              )
             )
            )
            (f64.const inf)
           )
           (f64.lt
            (f64.abs
             (local.get $5)
            )
            (f64.const inf)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global207)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (struct.get $type49 0
             (struct.get $environment111 10
              (local.get $0)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.set $type17
          (array.get $type20
           (local.tee $11
            (struct.get $environment111 0
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.wrap_i64
           (local.get $2)
          )
          (local.get $6)
         )
         (struct.set $type90 1
          (local.tee $7
           (struct.new_default $type90)
          )
          (struct.new $type88
           (ref.func $function134)
           (struct.new $environment134
            (local.get $11)
            (struct.get $environment111 1
             (local.get $0)
            )
            (struct.get $environment111 10
             (local.get $0)
            )
            (local.get $7)
           )
          )
         )
         (struct.set $type90 0
          (local.get $7)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type90 0
            (local.get $7)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call88
          (struct.get $type88 1
           (local.tee $10
            (ref.as_non_null
             (struct.get $type90 1
              (local.get $7)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type88 0
           (local.get $10)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (local.set $1
     (i64.sub
      (local.tee $2
       (struct.get $type49 0
        (struct.get $environment111 10
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type12
      (struct.get $environment111 8
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $1
     (i64.sub
      (local.tee $2
       (struct.get $type49 0
        (struct.get $environment111 10
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.sub
      (local.tee $3
       (struct.get $type49 0
        (local.tee $8
         (struct.get $environment111 9
          (local.get $0)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (array.get $type12
      (local.tee $14
       (struct.get $environment111 7
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment111 8
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $2)
    )
    (local.set $1
     (i64.sub
      (local.tee $2
       (struct.get $type49 0
        (local.get $8)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $14)
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (struct.get $environment111 15
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (struct.get $type10 0
      (struct.get $type97 1
       (struct.get $environment111 15
        (local.get $0)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function113 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $environment113))
  (local $3 (ref $type90))
  (local $4 (ref $environment113))
  (local $5 (ref $type12))
  (local $6 (ref $type80))
  (local $7 (ref $type88))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (block $block
   (return
    (if (result i32)
     (i64.ge_s
      (struct.get $environment113 1
       (local.tee $2
        (ref.cast (ref $environment113)
         (local.get $0)
        )
       )
      )
      (local.get $1)
     )
     (then
      (br_if $block
       (i64.ne
        (array.get $type12
         (struct.get $environment113 6
          (local.get $2)
         )
         (block (result i32)
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $10
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $10)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global110)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $8
               (i64.add
                (local.tee $9
                 (struct.get $environment113 2
                  (local.get $2)
                 )
                )
                (local.tee $11
                 (struct.get $type49 0
                  (struct.get $environment113 7
                   (local.get $2)
                  )
                 )
                )
               )
              )
              (local.get $11)
             )
             (i64.xor
              (local.get $8)
              (local.get $9)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $8)
              (local.tee $9
               (i64.sub
                (local.get $8)
                (i64.const 1)
               )
              )
             )
             (i64.xor
              (local.get $9)
              (i64.const -1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $10)
          )
         )
        )
        (local.get $9)
       )
      )
      (drop
       (struct.get $environment113 11
        (local.get $2)
       )
      )
      (drop
       (call $function86
        (struct.get $environment113 0
         (local.get $2)
        )
        (struct.get $environment113 3
         (local.get $2)
        )
        (struct.get $environment113 5
         (local.get $2)
        )
        (struct.get $environment113 8
         (local.get $2)
        )
        (local.tee $6
         (struct.get $environment113 9
          (local.get $2)
         )
        )
        (local.get $1)
        (i32.const 1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (struct.get $type80 0
          (local.get $6)
         )
         (f64.const 0.0)
        )
       )
      )
      (struct.set $type49 0
       (struct.get $environment113 7
        (local.get $2)
       )
       (local.get $1)
      )
      (struct.set $type82 0
       (struct.get $environment113 10
        (local.get $2)
       )
       (i32.const 1)
      )
      (i32.const 0)
     )
     (else
      (struct.set $type90 1
       (local.tee $3
        (struct.new_default $type90)
       )
       (struct.new $type88
        (ref.func $function115)
        (struct.new $environment115
         (struct.get $environment113 0
          (local.tee $4
           (ref.as_non_null
            (local.get $2)
           )
          )
         )
         (struct.get $environment113 2
          (local.get $4)
         )
         (struct.get $environment113 4
          (local.get $4)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type90 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call88
       (struct.get $type88 1
        (local.tee $7
         (ref.as_non_null
          (struct.get $type90 1
           (local.get $3)
          )
         )
        )
       )
       (i64.const 3)
       (struct.get $type88 0
        (local.get $7)
       )
      )
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.tee $8
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $8)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type90 0
     (struct.get $environment113 12
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function113
   (struct.get $type88 1
    (struct.get $type90 1
     (struct.get $environment113 12
      (local.get $2)
     )
    )
   )
   (local.get $8)
  )
 )
 (func $function115 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $environment115))
  (local $4 (ref $type90))
  (local $5 (ref $type14))
  (local $6 (ref $type88))
  (drop
   (ref.cast (ref $environment115)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.ge_s
    (local.get $1)
    (i64.const 4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (array.get $type14
      (struct.get $environment115 2
       (local.tee $3
        (ref.cast (ref $environment115)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $2
            (i64.sub
             (local.get $1)
             (i64.const 3)
            )
           )
           (local.get $1)
          )
          (i64.xor
           (local.get $1)
           (i64.const 3)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
     (then
      (struct.set $type90 1
       (local.tee $4
        (struct.new_default $type90)
       )
       (struct.new $type88
        (ref.func $function117)
        (struct.new $environment117
         (struct.get $environment115 0
          (local.get $3)
         )
         (struct.get $environment115 1
          (local.get $3)
         )
         (local.get $1)
         (local.get $4)
        )
       )
      )
      (struct.set $type90 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call88
        (struct.get $type88 1
         (local.tee $6
          (ref.as_non_null
           (struct.get $type90 1
            (local.get $4)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type88 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment115 3
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function115
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment115 3
        (local.get $3)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function117 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $environment117))
  (local $7 (ref $type20))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment117 1
      (ref.cast (ref $environment117)
       (local.get $0)
      )
     )
    )
    (i64.const 1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (array.set $type17
     (array.get $type20
      (struct.get $environment117 0
       (local.tee $6
        (ref.cast (ref $environment117)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.tee $2
          (struct.get $environment117 2
           (local.get $6)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (f64.eq
          (f64.abs
           (local.tee $5
            (f64.sub
             (f64.const -0.0)
             (local.tee $4
              (array.get $type17
               (array.get $type20
                (struct.get $environment117 0
                 (local.get $6)
                )
                (i32.wrap_i64
                 (local.get $2)
                )
               )
               (i32.wrap_i64
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $2)
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment117 3
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function117
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment117 3
        (local.get $6)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function118 (type $call46) (param $0 (ref null $environment159)) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function120 (type $25) (param $0 (ref $environment120)) (param $1 f64)
  (local $2 (ref $type90))
  (local $3 (ref $type88))
  (local $4 (ref $type20))
  (local $5 (ref $type49))
  (local $6 (ref $type49))
  (local $7 i64)
  (local $8 i64)
  (struct.set $type90 1
   (local.tee $2
    (struct.new_default $type90)
   )
   (struct.new $type88
    (ref.func $function122)
    (struct.new $environment122
     (local.tee $4
      (struct.get $environment120 0
       (local.get $0)
      )
     )
     (struct.get $environment120 1
      (local.get $0)
     )
     (local.tee $7
      (struct.get $environment120 2
       (local.get $0)
      )
     )
     (local.tee $5
      (struct.get $environment120 3
       (local.get $0)
      )
     )
     (local.tee $6
      (struct.get $environment120 4
       (local.get $0)
      )
     )
     (struct.get $environment120 5
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type90 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type90 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call88
    (struct.get $type88 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type90 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type88 0
     (local.get $3)
    )
   )
  )
  (struct.set $type90 1
   (local.tee $2
    (struct.new_default $type90)
   )
   (struct.new $type88
    (ref.func $function126)
    (struct.new $environment126
     (local.get $4)
     (local.get $7)
     (local.get $5)
     (local.get $6)
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type90 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type90 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call88
    (struct.get $type88 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type90 1
        (local.get $2)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type88 0
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global207)
   )
  )
  (if
   (i64.gt_u
    (local.tee $7
     (struct.get $type49 0
      (local.get $5)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $8
     (struct.get $type49 0
      (local.get $6)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (array.get $type20
    (local.get $4)
    (i32.wrap_i64
     (local.get $7)
    )
   )
   (i32.wrap_i64
    (local.get $8)
   )
   (local.get $1)
  )
 )
 (func $function122 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment122))
  (local $3 (ref $type90))
  (local $4 (ref $type20))
  (local $5 (ref $type88))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $6
       (i64.add
        (local.tee $7
         (struct.get $environment122 1
          (local.tee $2
           (ref.cast (ref $environment122)
            (local.get $0)
           )
          )
         )
        )
        (local.tee $8
         (select
          (i64.const 2)
          (i64.const 1)
          (struct.get $environment122 5
           (local.get $2)
          )
         )
        )
       )
      )
      (local.get $7)
     )
     (i64.xor
      (local.get $6)
      (local.get $8)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type49 0
       (struct.get $environment122 3
        (local.get $2)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (struct.get $type49 0
          (struct.get $environment122 4
           (local.get $2)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $9
       (f64.mul
        (local.tee $10
         (struct.get $environment122 6
          (local.get $2)
         )
        )
        (local.tee $11
         (array.get $type17
          (array.get $type20
           (struct.get $environment122 0
            (local.get $2)
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $10)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $11)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $9)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global207)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (local.tee $4
         (struct.get $environment122 0
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (local.get $9)
      )
      (struct.set $type90 1
       (local.tee $3
        (struct.new_default $type90)
       )
       (struct.new $type88
        (ref.func $function124)
        (struct.new $environment124
         (local.get $4)
         (struct.get $environment122 2
          (local.get $2)
         )
         (struct.get $environment122 3
          (local.get $2)
         )
         (struct.get $environment122 4
          (local.get $2)
         )
         (local.get $1)
         (local.get $3)
        )
       )
      )
      (struct.set $type90 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type90 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call88
        (struct.get $type88 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type90 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type88 0
         (local.get $5)
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment122 7
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function122
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment122 7
        (local.get $2)
       )
      )
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function124 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 (ref $environment124))
  (local $9 (ref $type20))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment124 1
      (ref.cast (ref $environment124)
       (local.get $0)
      )
     )
    )
    (i64.const 1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type49 0
       (struct.get $environment124 3
        (local.tee $8
         (ref.cast (ref $environment124)
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (struct.get $environment124 4
          (local.get $8)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (array.get $type17
        (array.get $type20
         (local.tee $9
          (struct.get $environment124 0
           (local.get $8)
          )
         )
         (i32.wrap_i64
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type49 0
          (struct.get $environment124 2
           (local.get $8)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (f64.mul
        (local.tee $6
         (array.get $type17
          (array.get $type20
           (local.get $9)
           (i32.wrap_i64
            (local.get $3)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
        (block (result f64)
         (drop
          (ref.as_non_null
           (global.get $global178)
          )
         )
         (if
          (i64.gt_u
           (local.get $2)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.gt_u
           (local.tee $3
            (struct.get $type49 0
             (struct.get $environment124 3
              (local.get $8)
             )
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.tee $7
          (array.get $type17
           (array.get $type20
            (local.get $9)
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $6)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $7)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.tee $4
           (f64.sub
            (local.get $5)
            (local.get $4)
           )
          )
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global207)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (struct.get $environment124 0
         (local.get $8)
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment124 5
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function124
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment124 5
        (local.get $8)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function126 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $environment126))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment126 1
      (ref.cast (ref $environment126)
       (local.get $0)
      )
     )
    )
    (i64.const 1)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ne
      (local.get $1)
      (struct.get $type49 0
       (struct.get $environment126 3
        (local.tee $7
         (ref.cast (ref $environment126)
          (local.get $0)
         )
        )
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global106)
       )
      )
      (if
       (i32.and
        (f64.eq
         (f64.abs
          (local.tee $5
           (f64.sub
            (f64.const -0.0)
            (local.tee $4
             (struct.get $environment126 4
              (local.get $7)
             )
            )
           )
          )
         )
         (f64.const inf)
        )
        (f64.lt
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (struct.get $type49 0
          (struct.get $environment126 2
           (local.get $7)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (f64.mul
        (local.get $5)
        (local.tee $6
         (array.get $type17
          (array.get $type20
           (struct.get $environment126 0
            (local.get $7)
           )
           (i32.wrap_i64
            (local.get $2)
           )
          )
          (i32.wrap_i64
           (local.get $1)
          )
         )
        )
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.lt
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $6)
          )
          (f64.const inf)
         )
        )
        (f64.eq
         (f64.abs
          (local.get $4)
         )
         (f64.const inf)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global207)
       )
      )
      (if
       (i64.gt_u
        (local.tee $2
         (struct.get $type49 0
          (struct.get $environment126 2
           (local.get $7)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (array.get $type20
        (struct.get $environment126 0
         (local.get $7)
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment126 5
        (local.get $7)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function126
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment126 5
        (local.get $7)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function128 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment128))
  (local $3 (ref $type90))
  (local $4 (ref $type88))
  (local $5 (ref $type49))
  (local $6 (ref $type20))
  (local $7 i64)
  (local $8 i64)
  (local $9 f64)
  (local $10 f64)
  (if
   (if (result i32)
    (i64.gt_s
     (struct.get $type49 0
      (struct.get $environment128 3
       (local.tee $2
        (ref.cast (ref $environment128)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
    (then
     (if
      (i64.gt_u
       (local.get $1)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (struct.get $type49 0
       (struct.get $environment128 4
        (local.get $2)
       )
      )
      (array.get $type12
       (struct.get $environment128 2
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $7
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment128 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function128
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment128 5
        (local.get $2)
       )
      )
     )
     (local.get $7)
    )
   )
   (else
    (local.set $8
     (i64.sub
      (local.tee $7
       (struct.get $type49 0
        (struct.get $environment128 3
         (local.get $2)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type49 0
     (local.tee $5
      (struct.get $environment128 3
       (local.get $2)
      )
     )
     (local.get $8)
    )
    (struct.set $type90 1
     (local.tee $3
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function130)
      (struct.new $environment130
       (struct.get $environment128 2
        (local.get $2)
       )
       (local.get $5)
       (local.get $3)
      )
     )
    )
    (struct.set $type90 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type88 0
       (local.get $4)
      )
     )
    )
    (local.set $1
     (i64.add
      (local.tee $7
       (struct.get $environment128 1
        (local.get $2)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $7)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.add
      (local.tee $8
       (struct.get $environment128 1
        (local.get $2)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (struct.get $type49 0
        (struct.get $environment128 4
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (f64.eq
       (f64.abs
        (local.tee $10
         (f64.add
          (local.tee $9
           (array.get $type17
            (array.get $type20
             (struct.get $environment128 0
              (local.get $2)
             )
             (i32.wrap_i64
              (local.get $7)
             )
            )
            (i32.wrap_i64
             (local.get $8)
            )
           )
          )
          (f64.const 1.0)
         )
        )
       )
       (f64.const inf)
      )
      (f64.lt
       (f64.abs
        (local.get $9)
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (struct.get $type49 0
        (struct.get $environment128 4
         (local.get $2)
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (array.get $type20
      (local.tee $6
       (struct.get $environment128 0
        (local.get $2)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (i32.wrap_i64
      (local.get $7)
     )
     (local.get $10)
    )
    (struct.set $type90 1
     (local.tee $3
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function132)
      (struct.new $environment132
       (local.get $6)
       (struct.get $environment128 1
        (local.get $2)
       )
       (struct.get $environment128 4
        (local.get $2)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type90 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call88
     (struct.get $type88 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type90 1
         (local.get $3)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type88 0
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function130 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $environment130))
  (local $4 (ref $type12))
  (if (result i32)
   (i64.le_s
    (struct.get $type49 0
     (struct.get $environment130 1
      (ref.cast (ref $environment130)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (array.set $type12
     (struct.get $environment130 0
      (local.tee $3
       (ref.cast (ref $environment130)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type12
        (struct.get $environment130 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment130 2
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function130
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment130 2
        (local.get $3)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function132 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $environment132))
  (local $7 (ref $type20))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment132 1
      (ref.cast (ref $environment132)
       (local.get $0)
      )
     )
    )
    (i64.const 2)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (array.set $type17
     (array.get $type20
      (struct.get $environment132 0
       (local.tee $6
        (ref.cast (ref $environment132)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $2
          (struct.get $type49 0
           (struct.get $environment132 2
            (local.get $6)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (f64.eq
          (f64.abs
           (local.tee $5
            (f64.sub
             (f64.const -0.0)
             (local.tee $4
              (array.get $type17
               (array.get $type20
                (struct.get $environment132 0
                 (local.get $6)
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment132 3
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function132
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment132 3
        (local.get $6)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function134 (type $call88) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 f64)
  (local $6 (ref $environment134))
  (local $7 (ref $type20))
  (local.set $2
   (i64.add
    (local.tee $3
     (struct.get $environment134 1
      (ref.cast (ref $environment134)
       (local.get $0)
      )
     )
    )
    (i64.const 2)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.get $3)
     )
     (i64.xor
      (local.get $2)
      (i64.const 2)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (array.set $type17
     (array.get $type20
      (struct.get $environment134 0
       (local.tee $6
        (ref.cast (ref $environment134)
         (local.get $0)
        )
       )
      )
      (block (result i32)
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.tee $2
          (struct.get $type49 0
           (struct.get $environment134 2
            (local.get $6)
           )
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (f64.eq
          (f64.abs
           (local.tee $5
            (f64.sub
             (f64.const -0.0)
             (local.tee $4
              (array.get $type17
               (array.get $type20
                (struct.get $environment134 0
                 (local.get $6)
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $4)
          )
          (f64.const inf)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $1)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $5)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (struct.get $environment134 3
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function134
     (struct.get $type88 1
      (struct.get $type90 1
       (struct.get $environment134 3
        (local.get $6)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function137 (type $call84) (param $0 (ref $environment137)) (result (ref $type55))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $type49))
  (local $8 (ref $type49))
  (local $9 (ref $type90))
  (local $10 (ref $type20))
  (local $11 (ref $type80))
  (local $12 (ref $type88))
  (local $13 (ref $type12))
  (local $14 (ref $type12))
  (drop
   (call $function86
    (local.tee $10
     (struct.get $environment137 0
      (local.get $0)
     )
    )
    (struct.get $environment137 3
     (local.get $0)
    )
    (struct.get $environment137 5
     (local.get $0)
    )
    (local.tee $8
     (struct.get $environment137 9
      (local.get $0)
     )
    )
    (local.tee $11
     (struct.get $environment137 10
      (local.get $0)
     )
    )
    (i64.const 0)
    (i32.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if (result (ref $type55))
   (f64.gt
    (struct.get $type80 0
     (local.get $11)
    )
    (f64.const 0.0)
   )
   (then
    (struct.set $type49 0
     (local.tee $7
      (struct.get $environment137 8
       (local.get $0)
      )
     )
     (i64.const 0)
    )
    (struct.set $type90 1
     (local.tee $9
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function93)
      (struct.new $environment93
       (local.get $10)
       (struct.get $environment137 1
        (local.get $0)
       )
       (struct.get $environment137 2
        (local.get $0)
       )
       (struct.get $environment137 4
        (local.get $0)
       )
       (local.get $7)
       (local.get $8)
       (struct.new_default $type80)
       (struct.new_default $type82)
       (local.get $9)
      )
     )
    )
    (struct.set $type90 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $12
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $9)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type88 0
       (local.get $12)
      )
     )
    )
    (drop
     (struct.get $type46 1
      (global.get $global219)
     )
    )
    (if (result (ref $type57))
     (i64.eqz
      (struct.get $type49 0
       (local.get $7)
      )
     )
     (then
      (global.get $empty57)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global178)
       )
      )
      (local.set $2
       (struct.get $type49 0
        (local.tee $7
         (struct.get $environment137 9
          (local.get $0)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type49 0
          (local.tee $8
           (struct.get $environment137 8
            (local.get $0)
           )
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global108)
       )
      )
      (if
       (i32.and
        (i32.and
         (f64.eq
          (f64.abs
           (local.tee $6
            (f64.div
             (f64.const 1.0)
             (local.tee $5
              (array.get $type17
               (array.get $type20
                (local.tee $10
                 (struct.get $environment137 0
                  (local.get $0)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (f64.const inf)
         )
         (f64.lt
          (f64.abs
           (local.get $5)
          )
          (f64.const inf)
         )
        )
        (f64.ne
         (local.get $5)
         (f64.const 0.0)
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function120
       (struct.new $environment120
        (local.get $10)
        (struct.get $environment137 1
         (local.get $0)
        )
        (struct.get $environment137 2
         (local.get $0)
        )
        (local.get $8)
        (local.get $7)
        (i32.const 0)
       )
       (local.get $6)
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.tee $2
             (struct.get $type49 0
              (local.get $7)
             )
            )
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (array.get $type12
        (local.tee $13
         (struct.get $environment137 7
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (local.set $2
       (i64.sub
        (local.tee $1
         (struct.get $type49 0
          (struct.get $environment137 9
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (i64.sub
        (local.tee $3
         (struct.get $type49 0
          (local.tee $7
           (struct.get $environment137 8
            (local.get $0)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.get $3)
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (array.get $type12
        (local.tee $14
         (struct.get $environment137 6
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (local.get $13)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $1)
      )
      (local.set $2
       (i64.sub
        (local.tee $1
         (struct.get $type49 0
          (local.get $7)
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.get $2)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (local.get $14)
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $4)
      )
      (if
       (i32.eqz
        (struct.get $type98 0
         (struct.get $environment137 11
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function137
       (struct.get $type84 0
        (struct.get $type98 1
         (struct.get $environment137 11
          (local.get $0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global241)
     )
    )
    (struct.new $type58
     (i32.const 2)
     (struct.new $type42
      (struct.get $environment137 6
       (local.get $0)
      )
      (struct.new $type42
       (struct.get $environment137 7
        (local.get $0)
       )
       (ref.null none)
      )
     )
    )
   )
  )
 )
 (func $function142 (type $call99) (param $0 (ref $environment142)) (param $1 i64) (param $2 (ref $type55)) (result (ref $type55))
  (local $3 (ref null $type19))
  (local $4 (ref $type90))
  (local $5 (ref $type16))
  (local $6 (ref $type20))
  (local $7 (ref $type88))
  (local $8 (ref $type97))
  (local $9 (ref $type98))
  (local $10 (ref $type12))
  (local $11 (ref $type12))
  (local $12 (ref $type12))
  (local $13 (ref $type12))
  (local $14 (ref $type19))
  (local $15 (ref $type14))
  (local $16 (ref $type17))
  (local $17 (ref $type17))
  (local $18 (ref $type17))
  (local $19 (ref $type17))
  (local $20 (ref $type17))
  (local $21 (ref $type17))
  (local $22 (ref $type49))
  (local $23 (ref $type49))
  (local $24 (ref $type49))
  (local $25 (ref $type80))
  (local $26 (ref $type82))
  (local $27 i64)
  (local $28 i64)
  (if (result (ref $type55))
   (i64.gt_s
    (struct.get $environment142 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $28
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $28)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global251)
     )
    )
    (drop
     (call $foreign2
      (global.get $global244)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global254)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global256)
     )
    )
    (if
     (i32.eqz
      (global.get $ready258)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global258)
     )
    )
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global261)
     )
    )
    (drop
     (struct.get $type16 1
      (struct.get $type16 1
       (struct.get $type16 1
        (struct.get $type16 1
         (local.tee $5
          (struct.new $type16
           (f64.const 0.0)
           (struct.new $type16
            (f64.const 1.0)
            (struct.new $type16
             (f64.const 1.0)
             (struct.new $type16
              (f64.const 3.0)
              (struct.new $type16
               (f64.const -0.5)
               (ref.null none)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (if (result i64)
        (ref.is_null
         (local.tee $3
          (struct.get $type19 1
           (local.tee $14
            (struct.new $type19
             (call $function149
              (array.new_default $type17
               (i32.const 5)
              )
              (i32.const 1)
              (i32.const 0)
              (i32.const 1)
              (local.get $5)
              (i64.const 0)
             )
             (block (result (ref (exact $type19)))
              (drop
               (ref.as_non_null
                (global.get $global256)
               )
              )
              (if
               (i32.eqz
                (global.get $ready258)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global258)
               )
              )
              (if
               (i32.eqz
                (global.get $ready261)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global261)
               )
              )
              (drop
               (struct.get $type16 1
                (struct.get $type16 1
                 (struct.get $type16 1
                  (struct.get $type16 1
                   (local.tee $5
                    (struct.new $type16
                     (f64.const 740.0)
                     (struct.new $type16
                      (f64.const -1.0)
                      (struct.new $type16
                       (f64.const 0.0)
                       (struct.new $type16
                        (f64.const -2.0)
                        (struct.new_default $type16)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (struct.new $type19
               (call $function149
                (array.new $type17
                 (f64.const 740.0)
                 (i32.const 5)
                )
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (local.get $5)
                (i64.const 0)
               )
               (block (result (ref (exact $type19)))
                (drop
                 (ref.as_non_null
                  (global.get $global256)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready258)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global258)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready261)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global261)
                 )
                )
                (drop
                 (struct.get $type16 1
                  (struct.get $type16 1
                   (struct.get $type16 1
                    (struct.get $type16 1
                     (local.tee $5
                      (struct.new $type16
                       (f64.const 0.0)
                       (struct.new $type16
                        (f64.const 0.0)
                        (struct.new $type16
                         (f64.const -2.0)
                         (struct.new $type16
                          (f64.const 0.0)
                          (struct.new $type16
                           (f64.const 7.0)
                           (ref.null none)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (struct.new $type19
                 (call $function149
                  (array.new_default $type17
                   (i32.const 5)
                  )
                  (i32.const 1)
                  (i32.const 0)
                  (i32.const 1)
                  (local.get $5)
                  (i64.const 0)
                 )
                 (block (result (ref (exact $type19)))
                  (drop
                   (ref.as_non_null
                    (global.get $global256)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready258)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global258)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready261)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global261)
                   )
                  )
                  (drop
                   (struct.get $type16 1
                    (struct.get $type16 1
                     (struct.get $type16 1
                      (struct.get $type16 1
                       (local.tee $5
                        (struct.new $type16
                         (f64.const 0.5)
                         (struct.new $type16
                          (f64.const 0.0)
                          (struct.new $type16
                           (f64.const -1.0)
                           (struct.new $type16
                            (f64.const 1.0)
                            (struct.new $type16
                             (f64.const -2.0)
                             (ref.null none)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (struct.new $type19
                   (call $function149
                    (array.new $type17
                     (f64.const 0.5)
                     (i32.const 5)
                    )
                    (i32.const 1)
                    (i32.const 0)
                    (i32.const 1)
                    (local.get $5)
                    (i64.const 0)
                   )
                   (block (result (ref (exact $type19)))
                    (drop
                     (ref.as_non_null
                      (global.get $global256)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready258)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global258)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready261)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global261)
                     )
                    )
                    (drop
                     (struct.get $type16 1
                      (struct.get $type16 1
                       (struct.get $type16 1
                        (struct.get $type16 1
                         (local.tee $5
                          (struct.new $type16
                           (f64.const 9.0)
                           (struct.new $type16
                            (f64.const -1.0)
                            (struct.new $type16
                             (f64.const -1.0)
                             (struct.new $type16
                              (f64.const -1.0)
                              (struct.new $type16
                               (f64.const -1.0)
                               (ref.null none)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (struct.new $type19
                     (call $function149
                      (array.new $type17
                       (f64.const 9.0)
                       (i32.const 5)
                      )
                      (i32.const 1)
                      (i32.const 0)
                      (i32.const 1)
                      (local.get $5)
                      (i64.const 0)
                     )
                     (block (result (ref (exact $type19)))
                      (drop
                       (ref.as_non_null
                        (global.get $global256)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready258)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global258)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready261)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global261)
                       )
                      )
                      (drop
                       (struct.get $type16 1
                        (struct.get $type16 1
                         (struct.get $type16 1
                          (struct.get $type16 1
                           (local.tee $5
                            (struct.new $type16
                             (f64.const 0.0)
                             (struct.new $type16
                              (f64.const 0.0)
                              (struct.new $type16
                               (f64.const 0.0)
                               (struct.new $type16
                                (f64.const 0.0)
                                (struct.new_default $type16)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (struct.new $type19
                       (call $function149
                        (array.new_default $type17
                         (i32.const 5)
                        )
                        (i32.const 1)
                        (i32.const 0)
                        (i32.const 1)
                        (local.get $5)
                        (i64.const 0)
                       )
                       (block (result nullref)
                        (drop
                         (ref.as_non_null
                          (global.get $global269)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready271)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global271)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready274)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global274)
                         )
                        )
                        (ref.null none)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $3
            (struct.get $type19 1
             (local.get $3)
            )
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type19 1
               (local.get $3)
              )
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type19 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type19 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 5)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type19 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type19 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type19 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type19 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type19 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type19 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type19 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type19 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type19 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 14)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type19 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 15)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type19 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 16)
                                      )
                                      (else
                                       (if (result i64)
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type19 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const 17)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type19 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (i64.const 18)
                                          )
                                          (else
                                           (call $function153
                                            (i32.const 0)
                                            (i32.const 1)
                                            (struct.get $type19 1
                                             (local.get $3)
                                            )
                                            (i64.const 19)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $function154
      (array.new $type20
       (struct.get $type19 0
        (local.get $14)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (local.get $14)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global141)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global114)
     )
    )
    (if
     (i64.ne
      (i64.extend_i32_u
       (array.len
        (local.get $6)
       )
      )
      (i64.const 6)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global140)
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global147)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global151)
     )
    )
    (local.set $27
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $6)
       )
      )
      (i64.const 2)
     )
    )
    (drop
     (struct.get $type11 1
      (global.get $global154)
     )
    )
    (local.set $10
     (if (result (ref $type12))
      (i32.or
       (i64.lt_s
        (local.tee $1
         (i64.sub
          (i64.extend_i32_u
           (array.len
            (array.get $type20
             (local.get $6)
             (i32.const 0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (i64.gt_s
        (local.get $1)
        (i64.const 4294967295)
       )
      )
      (then
       (unreachable)
      )
      (else
       (if (result (ref $type12))
        (i64.eqz
         (local.get $1)
        )
        (then
         (array.new_fixed $type12 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call $function71
          (local.get $1)
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 1)
         )
        )
       )
      )
     )
    )
    (drop
     (struct.get $type11 1
      (global.get $global154)
     )
    )
    (local.set $11
     (if (result (ref $type12))
      (i32.or
       (i64.lt_s
        (local.get $27)
        (i64.const 0)
       )
       (i64.gt_s
        (local.get $27)
        (i64.const 4294967295)
       )
      )
      (then
       (unreachable)
      )
      (else
       (if (result (ref $type12))
        (i64.eqz
         (local.get $27)
        )
        (then
         (array.new_fixed $type12 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (if
          (i64.gt_u
           (local.get $27)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call $function71
          (local.get $27)
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $27)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 1)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global161)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global58)
     )
    )
    (local.set $15
     (call $function75
      (i64.const 1)
      (array.new_default $type14
       (i32.const 1)
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
     )
    )
    (drop
     (struct.get $type11 1
      (global.get $global154)
     )
    )
    (local.set $12
     (if (result (ref $type12))
      (i32.or
       (i64.lt_s
        (local.get $27)
        (i64.const 0)
       )
       (i64.gt_s
        (local.get $27)
        (i64.const 4294967295)
       )
      )
      (then
       (unreachable)
      )
      (else
       (if (result (ref $type12))
        (i64.eqz
         (local.get $27)
        )
        (then
         (array.new_fixed $type12 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global55)
          )
         )
         (if
          (i64.gt_u
           (local.get $27)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (call $function71
          (local.get $27)
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $27)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 1)
         )
        )
       )
      )
     )
    )
    (drop
     (struct.get $type11 1
      (global.get $global154)
     )
    )
    (struct.set $type90 1
     (local.tee $4
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function99)
      (struct.new $environment99
       (local.get $1)
       (local.get $10)
       (local.tee $13
        (if (result (ref $type12))
         (i32.or
          (i64.lt_s
           (local.get $1)
           (i64.const 0)
          )
          (i64.gt_s
           (local.get $1)
           (i64.const 4294967295)
          )
         )
         (then
          (unreachable)
         )
         (else
          (if (result (ref $type12))
           (i64.eqz
            (local.get $1)
           )
           (then
            (array.new_fixed $type12 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global55)
             )
            )
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (call $function71
             (local.get $1)
             (array.new_default $type12
              (i32.wrap_i64
               (local.get $1)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 1)
            )
           )
          )
         )
        )
       )
       (local.get $4)
      )
     )
    )
    (struct.set $type90 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type88 0
       (local.get $7)
      )
     )
    )
    (struct.set $type90 1
     (local.tee $4
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function101)
      (struct.new $environment101
       (local.get $6)
       (local.get $27)
       (local.get $1)
       (local.get $11)
       (local.get $12)
       (local.get $4)
      )
     )
    )
    (struct.set $type90 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type88 0
       (local.get $7)
      )
     )
    )
    (struct.set $type90 1
     (local.tee $4
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function104)
      (struct.new $environment104
       (local.get $15)
       (local.get $4)
      )
     )
    )
    (struct.set $type90 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type88 0
       (local.get $7)
      )
     )
    )
    (drop
     (struct.get $type46 1
      (global.get $global119)
     )
    )
    (struct.set $type90 1
     (local.tee $4
      (struct.new_default $type90)
     )
     (struct.new $type88
      (ref.func $function106)
      (struct.new $environment106
       (local.get $6)
       (local.get $27)
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (struct.set $type90 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type90 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call88
      (struct.get $type88 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type90 1
          (local.get $4)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type88 0
       (local.get $7)
      )
     )
    )
    (struct.set $type97 1
     (local.tee $8
      (struct.new_default $type97)
     )
     (struct.new $type10
      (struct.new $environment111
       (local.get $6)
       (local.get $27)
       (local.get $1)
       (local.get $10)
       (local.get $11)
       (local.get $15)
       (local.tee $22
        (struct.new $type49
         (local.get $1)
        )
       )
       (local.get $12)
       (local.get $13)
       (local.tee $23
        (struct.new_default $type49)
       )
       (local.tee $24
        (struct.new_default $type49)
       )
       (local.tee $25
        (struct.new_default $type80)
       )
       (struct.new_default $type82)
       (local.tee $26
        (struct.new $type82
         (i32.const 1)
        )
       )
       (struct.new_default $type85)
       (local.get $8)
      )
     )
    )
    (struct.set $type97 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function111
      (struct.get $type10 0
       (struct.get $type97 1
        (local.get $8)
       )
      )
     )
    )
    (local.set $2
     (if (result (ref $type55))
      (struct.get $type82 0
       (local.get $26)
      )
      (then
       (struct.set $type98 1
        (local.tee $9
         (struct.new_default $type98)
        )
        (struct.new $type84
         (struct.new $environment137
          (local.get $6)
          (local.get $27)
          (local.get $1)
          (local.get $10)
          (local.get $11)
          (local.get $22)
          (local.get $12)
          (local.get $13)
          (local.get $23)
          (local.get $24)
          (local.get $25)
          (local.get $9)
         )
        )
       )
       (struct.set $type98 0
        (local.get $9)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type98 0
          (local.get $9)
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function137
        (struct.get $type84 0
         (struct.get $type98 1
          (local.get $9)
         )
        )
       )
      )
      (else
       (global.get $empty56)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type101 0
       (struct.get $environment142 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function142
     (struct.get $type99 0
      (struct.get $type101 1
       (struct.get $environment142 1
        (local.get $0)
       )
      )
     )
     (local.get $28)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function149 (type $6) (param $0 (ref null $type17)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type16)) (param $5 i64) (result (ref $type17))
  (local $6 i64)
  (local $7 f64)
  (if (result (ref $type17))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type16 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type16 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function149
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function153 (type $5) (param $0 i32) (param $1 i32) (param $2 (ref null $type19)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type19 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function153
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function154 (type $4) (param $0 (ref null $type20)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type19)) (param $5 i64) (result (ref $type20))
  (local $6 i64)
  (local $7 (ref $type17))
  (if (result (ref $type20))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type19 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type19 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function154
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function156 (type $call53) (param $0 (ref null $type42)) (param $1 (ref null $type42)) (result i32)
  (local $2 (ref $type103))
  (local $3 (ref $type12))
  (local $4 (ref $type12))
  (local $5 (ref $type46))
  (local $scratch (ref null $type42))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global290)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.tee $3
            (struct.get $type42 0
             (local.get $0)
            )
           )
          )
         )
         (i64.extend_i32_u
          (array.len
           (local.tee $4
            (struct.get $type42 0
             (local.get $1)
            )
           )
          )
         )
        )
        (then
         (struct.set $type103 1
          (local.tee $2
           (struct.new_default $type103)
          )
          (struct.new $type46
           (ref.func $function159)
           (struct.new $environment159
            (local.get $3)
            (local.get $4)
            (local.get $2)
           )
          )
         )
         (struct.set $type103 0
          (local.get $2)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type103 0
            (local.get $2)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call46
          (struct.get $type46 1
           (local.tee $5
            (ref.as_non_null
             (struct.get $type103 1
              (local.get $2)
             )
            )
           )
          )
          (i64.const 0)
          (struct.get $type46 0
           (local.get $5)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function156
         (struct.get $type42 1
          (local.get $0)
         )
         (block (result (ref null $type42))
          (local.set $scratch
           (struct.get $type42 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready287)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global287)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function159 (type $call46) (param $0 (ref null $environment159)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 (ref $type103))
  (local $5 (ref $type12))
  (local $6 (ref $type12))
  (local.set $5
   (struct.get $environment159 1
    (local.get $0)
   )
  )
  (local.set $4
   (struct.get $environment159 2
    (local.get $0)
   )
  )
  (if (result i32)
   (local.tee $2
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (local.tee $6
        (struct.get $environment159 0
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (array.get $type12
       (local.get $5)
       (local.tee $2
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (array.get $type12
       (local.get $6)
       (local.get $2)
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $1)
          (local.tee $3
           (i64.add
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type103 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function159
       (struct.get $type46 1
        (struct.get $type103 1
         (local.get $4)
        )
       )
       (local.get $3)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type101))
  (local $2 (ref $type55))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (struct.set $type101 1
   (local.tee $1
    (struct.new_default $type101)
   )
   (struct.new $type99
    (struct.new $environment142
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type101 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type101 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function142
    (struct.get $type99 0
     (struct.get $type101 1
      (local.get $1)
     )
    )
    (i64.const 0)
    (global.get $empty56)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global282)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (local.tee $3
      (struct.get $type55 0
       (local.get $2)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $3)
        (i32.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global287)
         )
        )
        (call $function156
         (struct.get $type58 1
          (ref.cast (ref $type58)
           (local.get $2)
          )
         )
         (global.get $global245)
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (local $0 (ref $type73))
  (local $1 (ref $type49))
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $global58
   (struct.new_default $type8)
  )
  (global.set $global154
   (struct.new $type11
    (ref.func $function70)
    (ref.null none)
   )
  )
  (global.set $global161
   (struct.new_default $type13)
  )
  (global.set $global256
   (struct.new_default $type15)
  )
  (global.set $global269
   (struct.new_default $type18)
  )
  (global.set $global258
   (struct.new_default $type21)
  )
  (global.set $ready258
   (i32.const 1)
  )
  (global.set $global271
   (struct.new_default $type22)
  )
  (global.set $ready271
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type25)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global274
   (struct.new_default $type26)
  )
  (global.set $ready274
   (i32.const 1)
  )
  (global.set $global241
   (struct.new_default $type41)
  )
  (global.set $global106
   (struct.new_default $type43)
  )
  (global.set $global108
   (struct.new_default $type43)
  )
  (global.set $global110
   (struct.new_default $type44)
  )
  (global.set $global114
   (struct.new_default $type45)
  )
  (global.set $global119
   (struct.new $type46
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $global121
   (struct.new_default $type47)
  )
  (global.set $global198
   (struct.new_default $type47)
  )
  (global.set $global219
   (struct.new $type46
    (ref.func $function118)
    (ref.null none)
   )
  )
  (global.set $global123
   (struct.new_default $type43)
  )
  (global.set $global125
   (struct.new_default $type48)
  )
  (global.set $global128
   (struct.new_default $type50)
  )
  (global.set $global134
   (struct.new_default $type51)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global290
   (struct.new_default $type52)
  )
  (global.set $global287
   (struct.new_default $type53)
  )
  (global.set $ready287
   (i32.const 1)
  )
  (global.set $global282
   (struct.new_default $type54)
  )
  (global.set $global251
   (struct.new_default $type0)
  )
  (global.set $global147
   (struct.new_default $type59)
  )
  (global.set $global151
   (struct.new_default $type59)
  )
  (global.set $global178
   (struct.new_default $type60)
  )
  (global.set $global207
   (struct.new_default $type61)
  )
  (global.set $global140
   (struct.new_default $type62)
  )
  (global.set $global141
   (struct.new_default $type63)
  )
  (global.set $global254
   (struct.new_default $type64)
  )
  (global.set $global244
   (call $foreign3
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global125)
   )
  )
  (local.set $3
   (call $foreign0
    (struct.get $type49 0
     (local.tee $1
      (struct.new_default $type49)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $2
       (i64.add
        (local.tee $4
         (struct.get $type49 0
          (local.get $1)
         )
        )
        (i64.const 1)
       )
      )
      (local.get $4)
     )
     (i64.xor
      (local.get $2)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type49 0
   (local.get $1)
   (local.get $2)
  )
  (struct.set $type73 1
   (local.tee $0
    (struct.new_default $type73)
   )
   (struct.new $type71
    (struct.new $environment61
     (local.get $1)
     (local.get $0)
    )
   )
  )
  (struct.set $type73 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type73 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global245
   (call $function61
    (struct.get $type71 0
     (struct.get $type73 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
  )
  (global.set $global246
   (struct.new_default $type65)
  )
  (global.set $ready246
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

