(module
 (rec
  (type $call67 (func (param (ref $environment84) i64 (ref $type36)) (result (ref $type36))))
  (type $type35 (struct (field (ref $environment71))))
  (type $type37 (struct (field (ref $environment72))))
  (type $type67 (struct (field (ref $environment84))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type67)))))
  (type $environment84 (struct (field i64) (field (ref $type35)) (field (ref $type69))))
  (type $call44 (func (param i64) (result i64)))
  (type $call33 (func (param (ref null $type28) (ref null $type28)) (result i32)))
  (type $8 (func (param (ref $type53) i64) (result i64)))
  (type $environment72 (struct (field i64) (field i64) (field i64)))
  (type $call37 (func (param (ref $environment72) (ref $type36)) (result i32)))
  (type $environment71 (struct (field i64) (field i64) (field i64) (field (ref $type36)) (field (ref $type53)) (field (ref $type53))))
  (type $call35 (func (param (ref $environment71)) (result (ref $type36))))
  (type $13 (func (param (ref $type53) (ref null $type28) i64 (ref null $type28)) (result (ref null $type28))))
  (type $14 (func (param (ref $type53) (ref null $type28) i64) (result (ref null $type28))))
  (type $call58 (func (param (ref $environment58) i64 (ref $type28)) (result (ref null $type28))))
  (type $environment67 (struct (field (ref $type61)) (field (ref $type62)) (field (ref $type53)) (field i64) (field (ref $type56)) (field (ref $type53)) (field (ref $type53)) (field (ref $type53))))
  (type $environment64 (struct (field (ref $type50))))
  (type $type58 (struct (field (ref $environment58))))
  (type $type53 (struct (field i32)))
  (type $type61 (struct (field (mut (ref null $type28)))))
  (type $type62 (struct (field (mut (ref $type32)))))
  (type $type60 (struct (field (mut i32)) (field (mut (ref null $type58)))))
  (type $environment58 (struct (field (ref $type60))))
  (type $24 (func (param i64 (ref $type36) (ref $type53) i64 i64) (result i32)))
  (type $type54 (struct (field (ref $call54)) (field (ref struct))))
  (type $type56 (struct (field (mut i32)) (field (mut (ref null $type54)))))
  (type $type36 (array (mut (ref null $type32))))
  (type $environment53 (struct (field i64) (field i64) (field (ref $type36)) (field (ref $type56))))
  (type $call54 (func (param (ref struct) i64) (result i32)))
  (type $call49 (func (result (ref $type48))))
  (type $call45 (func (param (ref $environment43) (ref null $type32) i64) (result i64)))
  (type $call48 (func (param (ref struct) (ref null $type28) i64) (result i64)))
  (type $environment45 (struct (field (ref $type50))))
  (type $type45 (struct (field (ref $environment43))))
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type45)))))
  (type $type48 (struct (field (ref $call48)) (field (ref struct))))
  (type $type28 (struct (field i64) (field (ref null $type28))))
  (type $type32 (struct (field (ref null $type28)) (field (ref null $type32))))
  (type $environment43 (struct (field (ref $type47))))
  (type $type50 (struct (field (mut i32)) (field (mut (ref null $type48)))))
  (type $call40 (func (param (ref null $type32)) (result i64)))
  (type $type44 (struct))
  (type $type38 (struct (field (ref $type35)) (field (ref $type37))))
  (type $type43 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type27 (struct))
 )
 (type $54 (func (param i64) (result i64)))
 (type $55 (func (param i32) (result i64)))
 (type $56 (func (result i64)))
 (type $57 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (import "benchmark" "count" (func $foreign2 (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type27)) (ref.null none))
 (global $global137 (mut (ref null $type29)) (ref.null none))
 (global $global122 (mut (ref null $type29)) (ref.null none))
 (global $global164 (mut (ref null $type30)) (ref.null none))
 (global $global170 (mut (ref null $type31)) (ref.null none))
 (global $global172 (mut (ref null $type33)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type34)) (ref.null none))
 (global $global184 (mut (ref null $type30)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global139 (mut (ref null $type39)) (ref.null none))
 (global $global106 (mut (ref null $type40)) (ref.null none))
 (global $global132 (mut (ref null $type41)) (ref.null none))
 (global $global117 (mut (ref null $type43)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global182 (mut i64) (i64.const 0))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global183 (mut i64) (i64.const 0))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global187 (mut i64) (i64.const 0))
 (global $ready187 (mut i32) (i32.const 0))
 (global $global188 (mut i64) (i64.const 0))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global189 (mut i64) (i64.const 0))
 (global $ready189 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type38)) (ref.null none))
 (global $global191 (mut (ref null $type44)) (ref.null none))
 (global $ready191 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call40) (param $0 (ref null $type32)) (result i64)
  (local $1 (ref $type50))
  (local $2 (ref $environment43))
  (local $3 (ref null $type28))
  (local $4 (ref $type48))
  (local $5 (ref null $type32))
  (local $6 (ref null $type32))
  (local $7 (ref $type47))
  (local $8 i64)
  (struct.set $type47 1
   (local.tee $7
    (struct.new_default $type47)
   )
   (struct.new $type45
    (struct.new $environment43
     (local.get $7)
    )
   )
  )
  (struct.set $type47 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type47 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type45 0
    (struct.get $type47 1
     (local.get $7)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $5
     (struct.get $type32 1
      (local.get $0)
     )
    )
    (local.set $3
     (struct.get $type32 0
      (local.get $0)
     )
    )
    (struct.set $type50 1
     (local.tee $1
      (struct.new_default $type50)
     )
     (struct.new $type48
      (ref.func $function45)
      (struct.new $environment45
       (local.get $1)
      )
     )
    )
    (struct.set $type50 0
     (local.get $1)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (call_ref $call48
      (struct.get $type48 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type50 1
          (local.get $1)
         )
        )
       )
      )
      (local.get $3)
      (i64.const 0)
      (struct.get $type48 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment43 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type45 0
      (struct.get $type47 1
       (struct.get $environment43 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $5)
     )
     (then
      (local.get $8)
     )
     (else
      (local.set $0
       (struct.get $type32 1
        (local.get $5)
       )
      )
      (local.set $3
       (struct.get $type32 0
        (local.get $5)
       )
      )
      (struct.set $type50 1
       (local.tee $1
        (struct.new_default $type50)
       )
       (struct.new $type48
        (ref.func $function45)
        (struct.new $environment45
         (local.get $1)
        )
       )
      )
      (struct.set $type50 0
       (local.get $1)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type50 0
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (call_ref $call48
        (struct.get $type48 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type50 1
            (local.get $1)
           )
          )
         )
        )
        (local.get $3)
        (local.get $8)
        (struct.get $type48 0
         (local.get $4)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type47 0
         (struct.get $environment43 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type45 0
        (struct.get $type47 1
         (struct.get $environment43 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $0)
       )
       (then
        (local.get $8)
       )
       (else
        (local.set $5
         (struct.get $type32 1
          (local.get $0)
         )
        )
        (local.set $3
         (struct.get $type32 0
          (local.get $0)
         )
        )
        (struct.set $type50 1
         (local.tee $1
          (struct.new_default $type50)
         )
         (struct.new $type48
          (ref.func $function45)
          (struct.new $environment45
           (local.get $1)
          )
         )
        )
        (struct.set $type50 0
         (local.get $1)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type50 0
           (local.get $1)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (call_ref $call48
          (struct.get $type48 1
           (local.tee $4
            (ref.as_non_null
             (struct.get $type50 1
              (local.get $1)
             )
            )
           )
          )
          (local.get $3)
          (local.get $8)
          (struct.get $type48 0
           (local.get $4)
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type47 0
           (struct.get $environment43 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type45 0
          (struct.get $type47 1
           (struct.get $environment43 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $5)
         )
         (then
          (local.get $8)
         )
         (else
          (local.set $0
           (struct.get $type32 1
            (local.get $5)
           )
          )
          (local.set $3
           (struct.get $type32 0
            (local.get $5)
           )
          )
          (struct.set $type50 1
           (local.tee $1
            (struct.new_default $type50)
           )
           (struct.new $type48
            (ref.func $function45)
            (struct.new $environment45
             (local.get $1)
            )
           )
          )
          (struct.set $type50 0
           (local.get $1)
           (i32.const 1)
          )
          (if
           (i32.eqz
            (struct.get $type50 0
             (local.get $1)
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $8
           (call_ref $call48
            (struct.get $type48 1
             (local.tee $4
              (ref.as_non_null
               (struct.get $type50 1
                (local.get $1)
               )
              )
             )
            )
            (local.get $3)
            (local.get $8)
            (struct.get $type48 0
             (local.get $4)
            )
           )
          )
          (if
           (i32.eqz
            (struct.get $type47 0
             (struct.get $environment43 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type45 0
            (struct.get $type47 1
             (struct.get $environment43 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (local.get $8)
           )
           (else
            (local.set $5
             (struct.get $type32 1
              (local.get $0)
             )
            )
            (local.set $3
             (struct.get $type32 0
              (local.get $0)
             )
            )
            (struct.set $type50 1
             (local.tee $1
              (struct.new_default $type50)
             )
             (struct.new $type48
              (ref.func $function45)
              (struct.new $environment45
               (local.get $1)
              )
             )
            )
            (struct.set $type50 0
             (local.get $1)
             (i32.const 1)
            )
            (if
             (i32.eqz
              (struct.get $type50 0
               (local.get $1)
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $8
             (call_ref $call48
              (struct.get $type48 1
               (local.tee $4
                (ref.as_non_null
                 (struct.get $type50 1
                  (local.get $1)
                 )
                )
               )
              )
              (local.get $3)
              (local.get $8)
              (struct.get $type48 0
               (local.get $4)
              )
             )
            )
            (if
             (i32.eqz
              (struct.get $type47 0
               (struct.get $environment43 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type45 0
              (struct.get $type47 1
               (struct.get $environment43 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $5)
             )
             (then
              (local.get $8)
             )
             (else
              (local.set $0
               (struct.get $type32 1
                (local.get $5)
               )
              )
              (local.set $3
               (struct.get $type32 0
                (local.get $5)
               )
              )
              (struct.set $type50 1
               (local.tee $1
                (struct.new_default $type50)
               )
               (struct.new $type48
                (ref.func $function45)
                (struct.new $environment45
                 (local.get $1)
                )
               )
              )
              (struct.set $type50 0
               (local.get $1)
               (i32.const 1)
              )
              (if
               (i32.eqz
                (struct.get $type50 0
                 (local.get $1)
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $8
               (call_ref $call48
                (struct.get $type48 1
                 (local.tee $4
                  (ref.as_non_null
                   (struct.get $type50 1
                    (local.get $1)
                   )
                  )
                 )
                )
                (local.get $3)
                (local.get $8)
                (struct.get $type48 0
                 (local.get $4)
                )
               )
              )
              (if
               (i32.eqz
                (struct.get $type47 0
                 (struct.get $environment43 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type45 0
                (struct.get $type47 1
                 (struct.get $environment43 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (local.get $8)
               )
               (else
                (local.set $5
                 (struct.get $type32 1
                  (local.get $0)
                 )
                )
                (local.set $3
                 (struct.get $type32 0
                  (local.get $0)
                 )
                )
                (struct.set $type50 1
                 (local.tee $1
                  (struct.new_default $type50)
                 )
                 (struct.new $type48
                  (ref.func $function45)
                  (struct.new $environment45
                   (local.get $1)
                  )
                 )
                )
                (struct.set $type50 0
                 (local.get $1)
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (struct.get $type50 0
                   (local.get $1)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $8
                 (call_ref $call48
                  (struct.get $type48 1
                   (local.tee $4
                    (ref.as_non_null
                     (struct.get $type50 1
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (local.get $3)
                  (local.get $8)
                  (struct.get $type48 0
                   (local.get $4)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type47 0
                   (struct.get $environment43 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type45 0
                  (struct.get $type47 1
                   (struct.get $environment43 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $5)
                 )
                 (then
                  (local.get $8)
                 )
                 (else
                  (local.set $6
                   (struct.get $type32 1
                    (local.get $5)
                   )
                  )
                  (local.set $3
                   (struct.get $type32 0
                    (local.get $5)
                   )
                  )
                  (struct.set $type50 1
                   (local.tee $1
                    (struct.new_default $type50)
                   )
                   (struct.new $type48
                    (ref.func $function45)
                    (struct.new $environment45
                     (local.get $1)
                    )
                   )
                  )
                  (struct.set $type50 0
                   (local.get $1)
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (struct.get $type50 0
                     (local.get $1)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $8
                   (call_ref $call48
                    (struct.get $type48 1
                     (local.tee $4
                      (ref.as_non_null
                       (struct.get $type50 1
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (local.get $3)
                    (local.get $8)
                    (struct.get $type48 0
                     (local.get $4)
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type47 0
                     (struct.get $environment43 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type45 0
                    (struct.get $type47 1
                     (struct.get $environment43 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $6)
                   )
                   (then
                    (local.get $8)
                   )
                   (else
                    (local.set $0
                     (struct.get $type32 1
                      (local.get $6)
                     )
                    )
                    (local.set $3
                     (struct.get $type32 0
                      (local.get $6)
                     )
                    )
                    (struct.set $type50 1
                     (local.tee $1
                      (struct.new_default $type50)
                     )
                     (struct.new $type48
                      (ref.func $function45)
                      (struct.new $environment45
                       (local.get $1)
                      )
                     )
                    )
                    (struct.set $type50 0
                     (local.get $1)
                     (i32.const 1)
                    )
                    (if
                     (i32.eqz
                      (struct.get $type50 0
                       (local.get $1)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $8
                     (call_ref $call48
                      (struct.get $type48 1
                       (local.tee $4
                        (ref.as_non_null
                         (struct.get $type50 1
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (local.get $3)
                      (local.get $8)
                      (struct.get $type48 0
                       (local.get $4)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type47 0
                       (struct.get $environment43 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $2
                     (struct.get $type45 0
                      (struct.get $type47 1
                       (struct.get $environment43 0
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $0)
                     )
                     (then
                      (local.get $8)
                     )
                     (else
                      (local.set $5
                       (struct.get $type32 1
                        (local.get $0)
                       )
                      )
                      (local.set $3
                       (struct.get $type32 0
                        (local.get $0)
                       )
                      )
                      (local.set $8
                       (call_ref $call48
                        (struct.get $type48 1
                         (local.tee $4
                          (call $function44)
                         )
                        )
                        (local.get $3)
                        (local.get $8)
                        (struct.get $type48 0
                         (local.get $4)
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type47 0
                         (struct.get $environment43 0
                          (local.get $2)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function43
                       (struct.get $type45 0
                        (struct.get $type47 1
                         (struct.get $environment43 0
                          (local.get $2)
                         )
                        )
                       )
                       (local.get $5)
                       (local.get $8)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function43 (type $call45) (param $0 (ref $environment43)) (param $1 (ref null $type32)) (param $2 i64) (result i64)
  (local $3 (ref null $type32))
  (local $4 (ref null $type28))
  (local $5 (ref $type48))
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type32 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type32 0
      (local.get $1)
     )
    )
    (local.set $2
     (call_ref $call48
      (struct.get $type48 1
       (local.tee $5
        (call $function44)
       )
      )
      (local.get $4)
      (local.get $2)
      (struct.get $type48 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type45 0
      (struct.get $type47 1
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function44 (type $call49) (result (ref $type48))
  (local $0 (ref $type50))
  (struct.set $type50 1
   (local.tee $0
    (struct.new_default $type50)
   )
   (struct.new $type48
    (ref.func $function45)
    (struct.new $environment45
     (local.get $0)
    )
   )
  )
  (struct.set $type50 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type50 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (struct.get $type50 1
    (local.get $0)
   )
  )
 )
 (func $function45 (type $call48) (param $0 (ref struct)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref null $type28))
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $5
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.tee $4
           (struct.get $type28 0
            (local.get $1)
           )
          )
          (local.get $2)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment45 0
        (ref.cast (ref $environment45)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (struct.get $type48 1
      (struct.get $type50 1
       (struct.get $environment45 0
        (ref.cast (ref $environment45)
         (local.get $0)
        )
       )
      )
     )
     (local.get $5)
     (local.get $3)
    )
   )
  )
 )
 (func $function53 (type $call54) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $environment53))
  (local $5 (ref $type36))
  (local $6 (ref null $type32))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment53 0
     (local.tee $4
      (ref.cast (ref $environment53)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.add
          (local.tee $3
           (struct.get $environment53 1
            (local.get $4)
           )
          )
          (local.get $1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $environment53 2
      (local.get $4)
     )
    )
    (local.set $6
     (if (result (ref null $type32))
      (i64.gt_s
       (struct.get $environment53 0
        (local.get $4)
       )
       (local.get $2)
      )
      (then
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type36
        (local.get $5)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type36
     (struct.get $environment53 2
      (local.get $4)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $6)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $2
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment53 3
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function53
     (struct.get $type54 1
      (struct.get $type56 1
       (struct.get $environment53 3
        (local.get $4)
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function55 (type $24) (param $0 i64) (param $1 (ref $type36)) (param $2 (ref $type53)) (param $3 i64) (param $4 i64) (result i32)
  (local $5 i64)
  (local $6 i64)
  (local $7 (ref $environment58))
  (local $8 (ref $type28))
  (local $9 (ref $type60))
  (local $10 (ref $type50))
  (local $11 (ref $type56))
  (local $12 (ref null $type28))
  (local $13 (ref null $type28))
  (local $14 (ref $type62))
  (local $15 (ref $type61))
  (local $16 (ref $type53))
  (local $17 (ref $type48))
  (local $18 (ref $type54))
  (if (result i32)
   (i64.lt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (struct.set $type60 1
     (local.tee $9
      (struct.new_default $type60)
     )
     (struct.new $type58
      (struct.new $environment58
       (local.get $9)
      )
     )
    )
    (struct.set $type60 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type60 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type58 0
      (struct.get $type60 1
       (local.get $9)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (local.set $12
     (if (result (ref null $type28))
      (i64.eqz
       (local.get $0)
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $5
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
           (local.get $0)
          )
          (i64.xor
           (local.get $0)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (struct.get $type60 0
          (struct.get $environment58 0
           (local.get $7)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $7
        (struct.get $type58 0
         (struct.get $type60 1
          (struct.get $environment58 0
           (local.get $7)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (local.set $8
        (struct.new $type28
         (local.get $0)
         (ref.null none)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $5)
        )
        (then
         (local.get $8)
        )
        (else
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $6
              (i64.sub
               (local.get $5)
               (i64.const 1)
              )
             )
             (local.get $5)
            )
            (i64.xor
             (local.get $5)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.eqz
           (struct.get $type60 0
            (struct.get $environment58 0
             (local.get $7)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $7
          (struct.get $type58 0
           (struct.get $type60 1
            (struct.get $environment58 0
             (local.get $7)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (local.set $8
          (struct.new $type28
           (local.get $5)
           (local.get $8)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $6)
          )
          (then
           (local.get $8)
          )
          (else
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $5
                (i64.sub
                 (local.get $6)
                 (i64.const 1)
                )
               )
               (local.get $6)
              )
              (i64.xor
               (local.get $6)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.eqz
             (struct.get $type60 0
              (struct.get $environment58 0
               (local.get $7)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $7
            (struct.get $type58 0
             (struct.get $type60 1
              (struct.get $environment58 0
               (local.get $7)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (local.set $8
            (struct.new $type28
             (local.get $6)
             (local.get $8)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.get $5)
            )
            (then
             (local.get $8)
            )
            (else
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $6
                  (i64.sub
                   (local.get $5)
                   (i64.const 1)
                  )
                 )
                 (local.get $5)
                )
                (i64.xor
                 (local.get $5)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.eqz
               (struct.get $type60 0
                (struct.get $environment58 0
                 (local.get $7)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $7
              (struct.get $type58 0
               (struct.get $type60 1
                (struct.get $environment58 0
                 (local.get $7)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (local.set $8
              (struct.new $type28
               (local.get $5)
               (local.get $8)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.get $6)
              )
              (then
               (local.get $8)
              )
              (else
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $5
                    (i64.sub
                     (local.get $6)
                     (i64.const 1)
                    )
                   )
                   (local.get $6)
                  )
                  (i64.xor
                   (local.get $6)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type60 0
                  (struct.get $environment58 0
                   (local.get $7)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $7
                (struct.get $type58 0
                 (struct.get $type60 1
                  (struct.get $environment58 0
                   (local.get $7)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global137)
                )
               )
               (local.set $8
                (struct.new $type28
                 (local.get $6)
                 (local.get $8)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $5)
                )
                (then
                 (local.get $8)
                )
                (else
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $6
                      (i64.sub
                       (local.get $5)
                       (i64.const 1)
                      )
                     )
                     (local.get $5)
                    )
                    (i64.xor
                     (local.get $5)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type60 0
                    (struct.get $environment58 0
                     (local.get $7)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $7
                  (struct.get $type58 0
                   (struct.get $type60 1
                    (struct.get $environment58 0
                     (local.get $7)
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global137)
                  )
                 )
                 (local.set $8
                  (struct.new $type28
                   (local.get $5)
                   (local.get $8)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.get $6)
                  )
                  (then
                   (local.get $8)
                  )
                  (else
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $5
                        (i64.sub
                         (local.get $6)
                         (i64.const 1)
                        )
                       )
                       (local.get $6)
                      )
                      (i64.xor
                       (local.get $6)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type60 0
                      (struct.get $environment58 0
                       (local.get $7)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $7
                    (struct.get $type58 0
                     (struct.get $type60 1
                      (struct.get $environment58 0
                       (local.get $7)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (local.set $8
                    (struct.new $type28
                     (local.get $6)
                     (local.get $8)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.get $5)
                    )
                    (then
                     (local.get $8)
                    )
                    (else
                     (if
                      (i64.lt_s
                       (i64.and
                        (i64.xor
                         (local.tee $6
                          (i64.sub
                           (local.get $5)
                           (i64.const 1)
                          )
                         )
                         (local.get $5)
                        )
                        (i64.xor
                         (local.get $5)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type60 0
                        (struct.get $environment58 0
                         (local.get $7)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $7
                      (struct.get $type58 0
                       (struct.get $type60 1
                        (struct.get $environment58 0
                         (local.get $7)
                        )
                       )
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global137)
                      )
                     )
                     (local.set $8
                      (struct.new $type28
                       (local.get $5)
                       (local.get $8)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $6)
                      )
                      (then
                       (local.get $8)
                      )
                      (else
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $5
                            (i64.sub
                             (local.get $6)
                             (i64.const 1)
                            )
                           )
                           (local.get $6)
                          )
                          (i64.xor
                           (local.get $6)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type60 0
                          (struct.get $environment58 0
                           (local.get $7)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function58
                        (struct.get $type58 0
                         (struct.get $type60 1
                          (struct.get $environment58 0
                           (local.get $7)
                          )
                         )
                        )
                        (local.get $5)
                        (struct.new $type28
                         (local.get $6)
                         (local.get $8)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global143)
     )
    )
    (local.set $13
     (struct.get $type61 0
      (local.tee $15
       (struct.new $type61
        (local.get $12)
       )
      )
     )
    )
    (struct.set $type50 1
     (local.tee $10
      (struct.new_default $type50)
     )
     (struct.new $type48
      (ref.func $function64)
      (struct.new $environment64
       (local.get $10)
      )
     )
    )
    (struct.set $type50 0
     (local.get $10)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (local.get $10)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $16
     (struct.new $type53
      (i32.const 1)
     )
    )
    (local.set $14
     (struct.new $type62
      (struct.new $type32
       (local.get $12)
       (ref.null none)
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $5
        (call_ref $call48
         (struct.get $type48 1
          (local.tee $17
           (ref.as_non_null
            (struct.get $type50 1
             (local.get $10)
            )
           )
          )
         )
         (local.get $13)
         (i64.const 0)
         (struct.get $type48 0
          (local.get $17)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $6
            (i64.sub
             (local.get $5)
             (i64.const 1)
            )
           )
           (local.get $5)
          )
          (i64.xor
           (local.get $5)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type56 1
        (local.tee $11
         (struct.new_default $type56)
        )
        (struct.new $type54
         (ref.func $function67)
         (struct.new $environment67
          (local.get $15)
          (local.get $14)
          (local.get $16)
          (local.get $5)
          (local.get $11)
          (struct.new $type53
           (i32.const 1)
          )
          (struct.new $type53
           (i32.const 1)
          )
          (struct.new $type53
           (i32.const 1)
          )
         )
        )
       )
       (struct.set $type56 0
        (local.get $11)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type56 0
          (local.get $11)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call54
        (struct.get $type54 1
         (local.tee $18
          (ref.as_non_null
           (struct.get $type56 1
            (local.get $11)
           )
          )
         )
        )
        (local.get $6)
        (struct.get $type54 0
         (local.get $18)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type36
     (local.get $1)
     (i32.wrap_i64
      (local.get $3)
     )
     (struct.get $type62 0
      (local.get $14)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $6
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $6)
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function58 (type $call58) (param $0 (ref $environment58)) (param $1 i64) (param $2 (ref $type28)) (result (ref null $type28))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type60 0
       (struct.get $environment58 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function58
     (struct.get $type58 0
      (struct.get $type60 1
       (struct.get $environment58 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (struct.new $type28
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function64 (type $call48) (param $0 (ref struct)) (param $1 (ref null $type28)) (param $2 i64) (result i64)
  (local $3 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type50 0
       (struct.get $environment64 0
        (ref.cast (ref $environment64)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (struct.get $type48 1
      (struct.get $type50 1
       (struct.get $environment64 0
        (ref.cast (ref $environment64)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function67 (type $call54) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type28))
  (local $7 (ref null $type28))
  (local $8 (ref null $type28))
  (local $9 (ref $environment67))
  (local $10 (ref $type28))
  (local $11 (ref $type56))
  (local $12 (ref $type61))
  (local $13 (ref $type54))
  (local $14 (ref $type62))
  (local $15 (ref $type53))
  (local $16 (ref $type53))
  (local $17 (ref $type53))
  (local $18 (ref $type53))
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.set $1
     (i64.sub
      (local.tee $2
       (struct.get $environment67 3
        (ref.cast (ref $environment67)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (struct.get $environment67 0
      (local.tee $9
       (ref.cast (ref $environment67)
        (local.get $0)
       )
      )
     )
    )
    (if (result i32)
     (i64.gt_s
      (local.get $1)
      (i64.const 1)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $2
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $1)
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type56 1
       (local.tee $11
        (struct.new_default $type56)
       )
       (struct.new $type54
        (ref.func $function67)
        (struct.new $environment67
         (local.get $12)
         (struct.get $environment67 1
          (local.get $9)
         )
         (struct.get $environment67 2
          (local.get $9)
         )
         (local.get $1)
         (local.get $11)
         (struct.get $environment67 5
          (local.get $9)
         )
         (struct.get $environment67 6
          (local.get $9)
         )
         (struct.get $environment67 7
          (local.get $9)
         )
        )
       )
      )
      (struct.set $type56 0
       (local.get $11)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type56 0
         (local.get $11)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call54
       (struct.get $type54 1
        (local.tee $13
         (ref.as_non_null
          (struct.get $type56 1
           (local.get $11)
          )
         )
        )
       )
       (local.get $2)
       (struct.get $type54 0
        (local.get $13)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.tee $4
           (struct.get $environment67 3
            (ref.cast (ref $environment67)
             (local.get $0)
            )
           )
          )
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $12
     (struct.get $environment67 0
      (local.tee $9
       (ref.cast (ref $environment67)
        (local.get $0)
       )
      )
     )
    )
    (local.set $14
     (struct.get $environment67 1
      (local.get $9)
     )
    )
    (local.set $15
     (struct.get $environment67 2
      (local.get $9)
     )
    )
    (local.set $16
     (struct.get $environment67 5
      (local.get $9)
     )
    )
    (local.set $17
     (struct.get $environment67 6
      (local.get $9)
     )
    )
    (local.set $18
     (struct.get $environment67 7
      (local.get $9)
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 1)
      )
      (then
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $4
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $2)
          )
          (i64.xor
           (local.get $2)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type56 1
        (local.tee $11
         (struct.new_default $type56)
        )
        (struct.new $type54
         (ref.func $function67)
         (struct.new $environment67
          (local.get $12)
          (local.get $14)
          (local.get $15)
          (local.get $2)
          (local.get $11)
          (local.get $16)
          (local.get $17)
          (local.get $18)
         )
        )
       )
       (struct.set $type56 0
        (local.get $11)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type56 0
          (local.get $11)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call54
        (struct.get $type54 1
         (local.tee $13
          (ref.as_non_null
           (struct.get $type56 1
            (local.get $11)
           )
          )
         )
        )
        (local.get $4)
        (struct.get $type54 0
         (local.get $13)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $15
     (struct.get $environment67 6
      (local.get $9)
     )
    )
    (local.set $7
     (struct.get $type61 0
      (local.tee $12
       (struct.get $environment67 0
        (local.get $9)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (local.set $16
     (struct.get $environment67 7
      (local.get $9)
     )
    )
    (local.set $6
     (if (result (ref null $type28))
      (i64.eqz
       (local.tee $4
        (struct.get $environment67 3
         (local.get $9)
        )
       )
      )
      (then
       (local.get $7)
      )
      (else
       (local.set $6
        (struct.get $type28 1
         (local.get $7)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $2
            (i64.sub
             (local.get $4)
             (i64.const 1)
            )
           )
           (local.get $4)
          )
          (i64.xor
           (local.get $4)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $2)
        )
        (then
         (local.get $6)
        )
        (else
         (local.set $6
          (struct.get $type28 1
           (local.get $6)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $3
              (i64.sub
               (local.get $2)
               (i64.const 1)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $6
            (struct.get $type28 1
             (local.get $6)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $2
                (i64.sub
                 (local.get $3)
                 (i64.const 1)
                )
               )
               (local.get $3)
              )
              (i64.xor
               (local.get $3)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.get $2)
            )
            (then
             (local.get $6)
            )
            (else
             (local.set $6
              (struct.get $type28 1
               (local.get $6)
              )
             )
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $3
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (local.get $2)
                )
                (i64.xor
                 (local.get $2)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.get $3)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $6
                (struct.get $type28 1
                 (local.get $6)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $2
                    (i64.sub
                     (local.get $3)
                     (i64.const 1)
                    )
                   )
                   (local.get $3)
                  )
                  (i64.xor
                   (local.get $3)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global137)
                )
               )
               (if (result (ref null $type28))
                (i64.eqz
                 (local.get $2)
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $6
                  (struct.get $type28 1
                   (local.get $6)
                  )
                 )
                 (if
                  (i64.lt_s
                   (i64.and
                    (i64.xor
                     (local.tee $3
                      (i64.sub
                       (local.get $2)
                       (i64.const 1)
                      )
                     )
                     (local.get $2)
                    )
                    (i64.xor
                     (local.get $2)
                     (i64.const 1)
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global137)
                  )
                 )
                 (if (result (ref null $type28))
                  (i64.eqz
                   (local.get $3)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $6
                    (struct.get $type28 1
                     (local.get $6)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $5
                        (i64.sub
                         (local.get $3)
                         (i64.const 1)
                        )
                       )
                       (local.get $3)
                      )
                      (i64.xor
                       (local.get $3)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (if (result (ref null $type28))
                    (i64.eqz
                     (local.get $5)
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $6
                      (struct.get $type28 1
                       (local.get $6)
                      )
                     )
                     (if
                      (i64.lt_s
                       (i64.and
                        (i64.xor
                         (local.tee $2
                          (i64.sub
                           (local.get $5)
                           (i64.const 1)
                          )
                         )
                         (local.get $5)
                        )
                        (i64.xor
                         (local.get $5)
                         (i64.const 1)
                        )
                       )
                       (i64.const 0)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global137)
                      )
                     )
                     (if (result (ref null $type28))
                      (i64.eqz
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $6
                        (struct.get $type28 1
                         (local.get $6)
                        )
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.tee $3
                            (i64.sub
                             (local.get $2)
                             (i64.const 1)
                            )
                           )
                           (local.get $2)
                          )
                          (i64.xor
                           (local.get $2)
                           (i64.const 1)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function69
                        (local.get $15)
                        (local.get $6)
                        (local.get $3)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (struct.set $type61 0
     (local.get $12)
     (if (result (ref null $type28))
      (i64.eqz
       (local.get $4)
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $8
        (struct.get $type28 1
         (local.get $7)
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $2
            (i64.sub
             (local.get $4)
             (i64.const 1)
            )
           )
           (local.get $4)
          )
          (i64.xor
           (local.get $4)
           (i64.const 1)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (local.set $10
        (struct.new $type28
         (struct.get $type28 0
          (local.get $7)
         )
         (local.get $6)
        )
       )
       (if (result (ref null $type28))
        (i64.eqz
         (local.get $2)
        )
        (then
         (local.get $10)
        )
        (else
         (local.set $7
          (struct.get $type28 1
           (local.get $8)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $4
              (i64.sub
               (local.get $2)
               (i64.const 1)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (local.set $10
          (struct.new $type28
           (struct.get $type28 0
            (local.get $8)
           )
           (local.get $10)
          )
         )
         (if (result (ref null $type28))
          (i64.eqz
           (local.get $4)
          )
          (then
           (local.get $10)
          )
          (else
           (local.set $6
            (struct.get $type28 1
             (local.get $7)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $3
                (i64.sub
                 (local.get $4)
                 (i64.const 1)
                )
               )
               (local.get $4)
              )
              (i64.xor
               (local.get $4)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (local.set $10
            (struct.new $type28
             (struct.get $type28 0
              (local.get $7)
             )
             (local.get $10)
            )
           )
           (if (result (ref null $type28))
            (i64.eqz
             (local.get $3)
            )
            (then
             (local.get $10)
            )
            (else
             (local.set $7
              (struct.get $type28 1
               (local.get $6)
              )
             )
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $2
                  (i64.sub
                   (local.get $3)
                   (i64.const 1)
                  )
                 )
                 (local.get $3)
                )
                (i64.xor
                 (local.get $3)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (local.set $10
              (struct.new $type28
               (struct.get $type28 0
                (local.get $6)
               )
               (local.get $10)
              )
             )
             (if (result (ref null $type28))
              (i64.eqz
               (local.get $2)
              )
              (then
               (local.get $10)
              )
              (else
               (local.set $6
                (struct.get $type28 1
                 (local.get $7)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.tee $4
                    (i64.sub
                     (local.get $2)
                     (i64.const 1)
                    )
                   )
                   (local.get $2)
                  )
                  (i64.xor
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (call $function70
                (local.get $16)
                (local.get $6)
                (local.get $4)
                (struct.new $type28
                 (struct.get $type28 0
                  (local.get $7)
                 )
                 (local.get $10)
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (struct.set $type62 0
     (local.tee $14
      (struct.get $environment67 1
       (local.get $9)
      )
     )
     (struct.new $type32
      (struct.get $type61 0
       (local.get $12)
      )
      (struct.get $type62 0
       (local.get $14)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment67 4
        (local.get $9)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (struct.get $type54 1
      (struct.get $type56 1
       (struct.get $environment67 4
        (local.get $9)
       )
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function69 (type $14) (param $0 (ref $type53)) (param $1 (ref null $type28)) (param $2 i64) (result (ref null $type28))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $1
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $3)
    )
   )
  )
 )
 (func $function70 (type $13) (param $0 (ref $type53)) (param $1 (ref null $type28)) (param $2 i64) (param $3 (ref null $type28)) (result (ref null $type28))
  (local $4 (ref null $type28))
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (if (result (ref null $type28))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type28 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (local.get $0)
     (local.get $4)
     (local.get $5)
     (struct.new $type28
      (struct.get $type28 0
       (local.get $1)
      )
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function71 (type $call35) (param $0 (ref $environment71)) (result (ref $type36))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type56))
  (local $5 (ref $type36))
  (local $6 (ref $type54))
  (local.set $2
   (i64.sub
    (local.tee $1
     (struct.get $environment71 1
      (local.get $0)
     )
    )
    (local.tee $3
     (struct.get $environment71 2
      (local.get $0)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $1)
      (local.get $2)
     )
     (i64.xor
      (local.get $1)
      (local.get $3)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function55
    (struct.get $environment71 0
     (local.get $0)
    )
    (local.tee $5
     (struct.get $environment71 3
      (local.get $0)
     )
    )
    (struct.get $environment71 5
     (local.get $0)
    )
    (local.get $2)
    (local.tee $1
     (struct.get $environment71 1
      (local.get $0)
     )
    )
   )
  )
  (struct.set $type56 1
   (local.tee $4
    (struct.new_default $type56)
   )
   (struct.new $type54
    (ref.func $function53)
    (struct.new $environment53
     (local.get $1)
     (struct.get $environment71 2
      (local.get $0)
     )
     (local.get $5)
     (local.get $4)
    )
   )
  )
  (struct.set $type56 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type56 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call54
    (struct.get $type54 1
     (local.tee $6
      (ref.as_non_null
       (struct.get $type56 1
        (local.get $4)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type54 0
     (local.get $6)
    )
   )
  )
  (local.get $5)
 )
 (func $function72 (type $call37) (param $0 (ref $environment72)) (param $1 (ref $type36)) (result i32)
  (local $2 (ref null $type28))
  (local $3 (ref null $type28))
  (local $4 (ref null $type32))
  (local $5 (ref null $type32))
  (local $6 (ref $type53))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i32)
  (local $scratch (ref null $type28))
  (local.set $4
   (array.get $type36
    (local.get $1)
    (i32.const 0)
   )
  )
  (local.set $7
   (i64.sub
    (local.tee $8
     (struct.get $environment72 1
      (local.get $0)
     )
    )
    (local.tee $9
     (struct.get $environment72 2
      (local.get $0)
     )
    )
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $7)
      (local.get $8)
     )
     (i64.xor
      (local.get $8)
      (local.get $9)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.tee $8
       (i64.sub
        (local.get $7)
        (i64.const 1)
       )
      )
      (local.get $7)
     )
     (i64.xor
      (local.get $7)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (if
   (i64.gt_u
    (local.tee $7
     (select
      (local.get $8)
      (i64.const 0)
      (i64.ge_s
       (local.get $8)
       (i64.const 0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $16
     (i32.and
      (ref.is_null
       (local.tee $5
        (array.get $type36
         (local.get $1)
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
      )
      (ref.is_null
       (local.get $4)
      )
     )
    )
    (then
     (local.get $16)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global170)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (ref.is_null
         (local.get $5)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global172)
          )
         )
         (local.set $2
          (struct.get $type32 0
           (local.get $5)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.tee $3
            (struct.get $type32 0
             (local.get $4)
            )
           )
          )
          (then
           (ref.is_null
            (local.get $2)
           )
          )
          (else
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i64.eq
               (struct.get $type28 0
                (local.get $3)
               )
               (struct.get $type28 0
                (local.get $2)
               )
              )
              (then
               (local.set $3
                (struct.get $type28 1
                 (local.get $3)
                )
               )
               (local.set $2
                (struct.get $type28 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready172)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global172)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (ref.is_null
                  (local.get $2)
                 )
                )
                (else
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i64.eq
                     (struct.get $type28 0
                      (local.get $3)
                     )
                     (struct.get $type28 0
                      (local.get $2)
                     )
                    )
                    (then
                     (local.set $3
                      (struct.get $type28 1
                       (local.get $3)
                      )
                     )
                     (local.set $2
                      (struct.get $type28 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready172)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global172)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.is_null
                        (local.get $2)
                       )
                      )
                      (else
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i64.eq
                           (struct.get $type28 0
                            (local.get $3)
                           )
                           (struct.get $type28 0
                            (local.get $2)
                           )
                          )
                          (then
                           (local.set $3
                            (struct.get $type28 1
                             (local.get $3)
                            )
                           )
                           (local.set $2
                            (struct.get $type28 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready172)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global172)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (ref.is_null
                              (local.get $2)
                             )
                            )
                            (else
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if (result i32)
                                (i64.eq
                                 (struct.get $type28 0
                                  (local.get $3)
                                 )
                                 (struct.get $type28 0
                                  (local.get $2)
                                 )
                                )
                                (then
                                 (local.set $3
                                  (struct.get $type28 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type28 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready172)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global172)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                  )
                                  (else
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (i64.eq
                                       (struct.get $type28 0
                                        (local.get $3)
                                       )
                                       (struct.get $type28 0
                                        (local.get $2)
                                       )
                                      )
                                      (then
                                       (local.set $3
                                        (struct.get $type28 1
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $2
                                        (struct.get $type28 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready172)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global172)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $3)
                                        )
                                        (then
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                        )
                                        (else
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (if (result i32)
                                            (i64.eq
                                             (struct.get $type28 0
                                              (local.get $3)
                                             )
                                             (struct.get $type28 0
                                              (local.get $2)
                                             )
                                            )
                                            (then
                                             (local.set $3
                                              (struct.get $type28 1
                                               (local.get $3)
                                              )
                                             )
                                             (local.set $2
                                              (struct.get $type28 1
                                               (local.get $2)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready172)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global172)
                                              )
                                             )
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $3)
                                              )
                                              (then
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                              )
                                              (else
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (i32.const 0)
                                                )
                                                (else
                                                 (if (result i32)
                                                  (i64.eq
                                                   (struct.get $type28 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type28 0
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (then
                                                   (local.set $3
                                                    (struct.get $type28 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (local.set $2
                                                    (struct.get $type28 1
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready172)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global172)
                                                    )
                                                   )
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $3)
                                                    )
                                                    (then
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (i32.const 0)
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (i64.eq
                                                         (struct.get $type28 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type28 0
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (then
                                                         (local.set $3
                                                          (struct.get $type28 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.get $type28 1
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready172)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global172)
                                                          )
                                                         )
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $3)
                                                          )
                                                          (then
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                            (then
                                                             (i32.const 0)
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (i64.eq
                                                               (struct.get $type28 0
                                                                (local.get $3)
                                                               )
                                                               (struct.get $type28 0
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (then
                                                               (call $function78
                                                                (struct.get $type28 1
                                                                 (local.get $3)
                                                                )
                                                                (block (result (ref null $type28))
                                                                 (local.set $scratch
                                                                  (struct.get $type28 1
                                                                   (local.get $2)
                                                                  )
                                                                 )
                                                                 (if
                                                                  (i32.eqz
                                                                   (global.get $ready172)
                                                                  )
                                                                  (then
                                                                   (unreachable)
                                                                  )
                                                                 )
                                                                 (drop
                                                                  (ref.as_non_null
                                                                   (global.get $global172)
                                                                  )
                                                                 )
                                                                 (local.get $scratch)
                                                                )
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (else
                                             (i32.const 0)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (else
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (else
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (else
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (local.set $15
     (call $function41
      (local.get $4)
     )
    )
    (local.set $7
     (i64.add
      (local.tee $8
       (struct.get $environment72 0
        (local.get $0)
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $13
     (i64.mul
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $13)
         (local.get $7)
        )
        (local.get $8)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (local.set $6
     (struct.new $type53
      (i32.const 1)
     )
    )
    (local.set $8
     (i64.mul
      (local.tee $7
       (if (result i64)
        (i64.eqz
         (local.get $8)
        )
        (then
         (i64.const 1)
        )
        (else
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $9
              (i64.sub
               (local.get $8)
               (i64.const 1)
              )
             )
             (local.get $8)
            )
            (i64.xor
             (local.get $8)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.set $9
          (i64.mul
           (local.tee $7
            (if (result i64)
             (i64.eqz
              (local.get $9)
             )
             (then
              (i64.const 1)
             )
             (else
              (if
               (i64.lt_s
                (i64.and
                 (i64.xor
                  (local.tee $10
                   (i64.sub
                    (local.get $9)
                    (i64.const 1)
                   )
                  )
                  (local.get $9)
                 )
                 (i64.xor
                  (local.get $9)
                  (i64.const 1)
                 )
                )
                (i64.const 0)
               )
               (then
                (unreachable)
               )
              )
              (local.set $10
               (i64.mul
                (local.tee $7
                 (if (result i64)
                  (i64.eqz
                   (local.get $10)
                  )
                  (then
                   (i64.const 1)
                  )
                  (else
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.tee $11
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                       (local.get $10)
                      )
                      (i64.xor
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $11
                    (i64.mul
                     (local.tee $7
                      (if (result i64)
                       (i64.eqz
                        (local.get $11)
                       )
                       (then
                        (i64.const 1)
                       )
                       (else
                        (if
                         (i64.lt_s
                          (i64.and
                           (i64.xor
                            (local.tee $7
                             (i64.sub
                              (local.get $11)
                              (i64.const 1)
                             )
                            )
                            (local.get $11)
                           )
                           (i64.xor
                            (local.get $11)
                            (i64.const 1)
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $12
                         (i64.mul
                          (local.tee $7
                           (if (result i64)
                            (i64.eqz
                             (local.get $7)
                            )
                            (then
                             (i64.const 1)
                            )
                            (else
                             (if
                              (i64.lt_s
                               (i64.and
                                (i64.xor
                                 (local.tee $12
                                  (i64.sub
                                   (local.get $7)
                                   (i64.const 1)
                                  )
                                 )
                                 (local.get $7)
                                )
                                (i64.xor
                                 (local.get $7)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $14
                              (i64.mul
                               (local.tee $12
                                (call $function73
                                 (local.get $6)
                                 (local.get $12)
                                )
                               )
                               (local.get $7)
                              )
                             )
                             (if
                              (i64.ne
                               (local.get $12)
                               (i64.const 0)
                              )
                              (then
                               (if
                                (i64.ne
                                 (i64.div_s
                                  (local.get $14)
                                  (local.get $12)
                                 )
                                 (local.get $7)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                              )
                             )
                             (local.get $14)
                            )
                           )
                          )
                          (local.get $11)
                         )
                        )
                        (if
                         (i64.ne
                          (local.get $7)
                          (i64.const 0)
                         )
                         (then
                          (if
                           (i64.ne
                            (i64.div_s
                             (local.get $12)
                             (local.get $7)
                            )
                            (local.get $11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                         )
                        )
                        (local.get $12)
                       )
                      )
                     )
                     (local.get $10)
                    )
                   )
                   (if
                    (i64.ne
                     (local.get $7)
                     (i64.const 0)
                    )
                    (then
                     (if
                      (i64.ne
                       (i64.div_s
                        (local.get $11)
                        (local.get $7)
                       )
                       (local.get $10)
                      )
                      (then
                       (unreachable)
                      )
                     )
                    )
                   )
                   (local.get $11)
                  )
                 )
                )
                (local.get $9)
               )
              )
              (if
               (i64.ne
                (local.get $7)
                (i64.const 0)
               )
               (then
                (if
                 (i64.ne
                  (i64.div_s
                   (local.get $10)
                   (local.get $7)
                  )
                  (local.get $9)
                 )
                 (then
                  (unreachable)
                 )
                )
               )
              )
              (local.get $10)
             )
            )
           )
           (local.get $8)
          )
         )
         (if
          (i64.ne
           (local.get $7)
           (i64.const 0)
          )
          (then
           (if
            (i64.ne
             (i64.div_s
              (local.get $9)
              (local.get $7)
             )
             (local.get $8)
            )
            (then
             (unreachable)
            )
           )
          )
         )
         (local.get $9)
        )
       )
      )
      (local.get $13)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $8)
         (local.get $7)
        )
        (local.get $13)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (i64.eq
     (i64.div_s
      (local.get $8)
      (i64.const 2)
     )
     (local.get $15)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function73 (type $8) (param $0 (ref $type53)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $2
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
       (i64.xor
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.tee $2
       (call $function73
        (local.get $0)
        (local.get $2)
       )
      )
      (local.get $1)
     )
    )
    (if
     (i64.ne
      (local.get $2)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $2)
        )
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function78 (type $call33) (param $0 (ref null $type28)) (param $1 (ref null $type28)) (result i32)
  (local $scratch (ref null $type28))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type28 0
         (local.get $0)
        )
        (struct.get $type28 0
         (local.get $1)
        )
       )
       (then
        (return_call $function78
         (struct.get $type28 1
          (local.get $0)
         )
         (block (result (ref null $type28))
          (local.set $scratch
           (struct.get $type28 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready172)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global172)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $call44) (param $0 i64) (result i64)
  (local $1 (ref $environment84))
  (local $2 (ref $type36))
  (local $3 (ref $type69))
  (local $4 (ref $type38))
  (struct.set $type69 1
   (local.tee $3
    (struct.new_default $type69)
   )
   (struct.new $type67
    (struct.new $environment84
     (local.get $0)
     (struct.get $type38 0
      (local.tee $4
       (ref.as_non_null
        (global.get $global190)
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type69 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type69 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function72
     (struct.get $type37 0
      (struct.get $type38 1
       (local.get $4)
      )
     )
     (if (result (ref $type36))
      (i64.gt_s
       (struct.get $environment84 0
        (local.tee $1
         (struct.get $type67 0
          (struct.get $type69 1
           (local.get $3)
          )
         )
        )
       )
       (i64.const 0)
      )
      (then
       (local.set $2
        (call $function71
         (struct.get $type35 0
          (struct.get $environment84 1
           (local.get $1)
          )
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type69 0
          (struct.get $environment84 2
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if (result (ref $type36))
        (i64.gt_s
         (struct.get $environment84 0
          (local.tee $1
           (struct.get $type67 0
            (struct.get $type69 1
             (struct.get $environment84 2
              (local.get $1)
             )
            )
           )
          )
         )
         (i64.const 1)
        )
        (then
         (local.set $2
          (call $function71
           (struct.get $type35 0
            (struct.get $environment84 1
             (local.get $1)
            )
           )
          )
         )
         (if
          (i32.eqz
           (struct.get $type69 0
            (struct.get $environment84 2
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if (result (ref $type36))
          (i64.gt_s
           (struct.get $environment84 0
            (local.tee $1
             (struct.get $type67 0
              (struct.get $type69 1
               (struct.get $environment84 2
                (local.get $1)
               )
              )
             )
            )
           )
           (i64.const 2)
          )
          (then
           (local.set $2
            (call $function71
             (struct.get $type35 0
              (struct.get $environment84 1
               (local.get $1)
              )
             )
            )
           )
           (if
            (i32.eqz
             (struct.get $type69 0
              (struct.get $environment84 2
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (if (result (ref $type36))
            (i64.gt_s
             (struct.get $environment84 0
              (local.tee $1
               (struct.get $type67 0
                (struct.get $type69 1
                 (struct.get $environment84 2
                  (local.get $1)
                 )
                )
               )
              )
             )
             (i64.const 3)
            )
            (then
             (local.set $2
              (call $function71
               (struct.get $type35 0
                (struct.get $environment84 1
                 (local.get $1)
                )
               )
              )
             )
             (if
              (i32.eqz
               (struct.get $type69 0
                (struct.get $environment84 2
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (if (result (ref $type36))
              (i64.gt_s
               (struct.get $environment84 0
                (local.tee $1
                 (struct.get $type67 0
                  (struct.get $type69 1
                   (struct.get $environment84 2
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (i64.const 4)
              )
              (then
               (local.set $2
                (call $function71
                 (struct.get $type35 0
                  (struct.get $environment84 1
                   (local.get $1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (struct.get $type69 0
                  (struct.get $environment84 2
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (if (result (ref $type36))
                (i64.gt_s
                 (struct.get $environment84 0
                  (local.tee $1
                   (struct.get $type67 0
                    (struct.get $type69 1
                     (struct.get $environment84 2
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (i64.const 5)
                )
                (then
                 (local.set $2
                  (call $function71
                   (struct.get $type35 0
                    (struct.get $environment84 1
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type69 0
                    (struct.get $environment84 2
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if (result (ref $type36))
                  (i64.gt_s
                   (struct.get $environment84 0
                    (local.tee $1
                     (struct.get $type67 0
                      (struct.get $type69 1
                       (struct.get $environment84 2
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (i64.const 6)
                  )
                  (then
                   (local.set $2
                    (call $function71
                     (struct.get $type35 0
                      (struct.get $environment84 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type69 0
                      (struct.get $environment84 2
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result (ref $type36))
                    (i64.gt_s
                     (struct.get $environment84 0
                      (local.tee $1
                       (struct.get $type67 0
                        (struct.get $type69 1
                         (struct.get $environment84 2
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (i64.const 7)
                    )
                    (then
                     (local.set $2
                      (call $function71
                       (struct.get $type35 0
                        (struct.get $environment84 1
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type69 0
                        (struct.get $environment84 2
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if (result (ref $type36))
                      (i64.gt_s
                       (struct.get $environment84 0
                        (local.tee $1
                         (struct.get $type67 0
                          (struct.get $type69 1
                           (struct.get $environment84 2
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 8)
                      )
                      (then
                       (local.set $2
                        (call $function71
                         (struct.get $type35 0
                          (struct.get $environment84 1
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type69 0
                          (struct.get $environment84 2
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function84
                        (struct.get $type67 0
                         (struct.get $type69 1
                          (struct.get $environment84 2
                           (local.get $1)
                          )
                         )
                        )
                        (i64.const 9)
                        (local.get $2)
                       )
                      )
                      (else
                       (local.get $2)
                      )
                     )
                    )
                    (else
                     (local.get $2)
                    )
                   )
                  )
                  (else
                   (local.get $2)
                  )
                 )
                )
                (else
                 (local.get $2)
                )
               )
              )
              (else
               (local.get $2)
              )
             )
            )
            (else
             (local.get $2)
            )
           )
          )
          (else
           (local.get $2)
          )
         )
        )
        (else
         (local.get $2)
        )
       )
      )
      (else
       (array.new_fixed $type36 0)
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function84 (type $call67) (param $0 (ref $environment84)) (param $1 i64) (param $2 (ref $type36)) (result (ref $type36))
  (local $3 i64)
  (if (result (ref $type36))
   (i64.gt_s
    (struct.get $environment84 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $1)
        (local.tee $3
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function71
      (struct.get $type35 0
       (struct.get $environment84 1
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment84 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (struct.get $type67 0
      (struct.get $type69 1
       (struct.get $environment84 2
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready191)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global191)
   )
  )
  (return_call $function81
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type53))
  (local $5 (ref $type36))
  (local $scratch i64)
  (local $scratch_7 i64)
  (local $scratch_8 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global143
   (struct.new_default $type27)
  )
  (global.set $global137
   (struct.new_default $type29)
  )
  (global.set $global122
   (struct.new_default $type29)
  )
  (global.set $global164
   (struct.new_default $type30)
  )
  (global.set $global170
   (struct.new_default $type31)
  )
  (global.set $global172
   (struct.new_default $type33)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type34)
  )
  (global.set $global184
   (struct.new_default $type30)
  )
  (global.set $ready184
   (i32.const 1)
  )
  (global.set $global139
   (struct.new_default $type39)
  )
  (global.set $global106
   (struct.new_default $type40)
  )
  (global.set $global132
   (struct.new_default $type41)
  )
  (global.set $global117
   (struct.new_default $type43)
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global182
   (call $foreign2)
  )
  (global.set $ready182
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (global.set $global183
   (call $foreign0
    (global.get $global182)
   )
  )
  (global.set $ready183
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global187
   (call $foreign0
    (block (result i64)
     (local.set $scratch
      (call $foreign1
       (i32.const 0)
      )
     )
     (if
      (i32.eqz
       (global.get $ready184)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global184)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (global.set $ready187
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global188
   (call $foreign0
    (block (result i64)
     (local.set $scratch_7
      (call $foreign1
       (i32.const 1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready184)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global184)
      )
     )
     (local.get $scratch_7)
    )
   )
  )
  (global.set $ready188
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready182)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global189
   (call $foreign0
    (block (result i64)
     (local.set $scratch_8
      (call $foreign1
       (i32.const 2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready184)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global184)
      )
     )
     (local.get $scratch_8)
    )
   )
  )
  (global.set $ready189
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready187)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready188)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready189)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready117)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (local.set $2
   (global.get $global187)
  )
  (local.set $0
   (global.get $global188)
  )
  (local.set $1
   (global.get $global189)
  )
  (global.set $global190
   (if (result (ref $type38))
    (if (result i32)
     (i64.ge_s
      (global.get $global183)
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (if (result i32)
       (i64.gt_s
        (local.get $2)
        (i64.const 0)
       )
       (then
        (i32.and
         (i32.and
          (i64.ge_s
           (local.get $0)
           (local.get $1)
          )
          (i64.ge_s
           (local.get $1)
           (i64.const 0)
          )
         )
         (i64.gt_s
          (local.get $0)
          (i64.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (if
      (i64.gt_u
       (local.get $0)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $3
          (i64.sub
           (local.get $0)
           (local.get $1)
          )
         )
         (local.get $0)
        )
        (i64.xor
         (local.get $0)
         (local.get $1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $4
      (struct.new $type53
       (i32.const 1)
      )
     )
     (drop
      (call $function55
       (local.get $2)
       (local.tee $5
        (array.new_default $type36
         (i32.wrap_i64
          (local.get $0)
         )
        )
       )
       (local.get $4)
       (i64.const 0)
       (local.get $3)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global175)
      )
     )
     (struct.new $type38
      (struct.new $type35
       (struct.new $environment71
        (local.get $2)
        (local.get $0)
        (local.get $1)
        (local.get $5)
        (struct.new $type53
         (i32.const 1)
        )
        (local.get $4)
       )
      )
      (struct.new $type37
       (struct.new $environment72
        (local.get $2)
        (local.get $0)
        (local.get $1)
       )
      )
     )
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $global191
   (struct.new_default $type44)
  )
  (global.set $ready191
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

