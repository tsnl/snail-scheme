(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/sfir-mperm-timer-correction-20261015-v1/source/benchmarks/sfir/mperm/chez-original.scm" "/tmp/sfir-mperm-timer-correction-20261015-v1/validation/mperm/chez-original.so"))
