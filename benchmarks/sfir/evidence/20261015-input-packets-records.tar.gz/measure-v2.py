#!/usr/bin/env python3
"""Verify or execute the frozen Cat/WC input-buffer comparison, once."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent


# ---- Check identities before importing the frozen execution helpers ----

def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def checked_file(path, expected):
    path = Path(path)
    if not path.is_file() or digest(path) != expected:
        raise ValueError(f'frozen dependency changed: {path}')
    if not str(path).startswith('/nix/store/') and path.is_symlink():
        raise ValueError(f'frozen local dependency became a symlink: {path}')


def read_plan():
    checksum = (ROOT / 'measurement-plan-v2.sha256').read_text().split()[0]
    checked_file(ROOT / 'measurement-plan-v2.json', checksum)
    plan = load(ROOT / 'measurement-plan-v2.json')
    for name, expected in plan['bootstrap_files'].items():
        checked_file(ROOT / name, expected)
    if str(ROOT) != plan['directory'] or sys.path != plan['python_path']:
        raise ValueError('use the frozen directory and isolated Python interpreter')
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
        raise ValueError('invoke the frozen Python with -I -S -B')
    checked_file(sys.executable, plan['python_sha256'])
    return plan, checksum, load(ROOT / 'manifest.json')


def frozen_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def frozen_files(plan, manifest):
    files = dict(plan['extra_files'])
    files.update({str(ROOT / name): value for name, value in plan['bootstrap_files'].items()})
    for variant, data in manifest['variants'].items():
        files.update({str(ROOT / variant / name): value for name, value in data['files'].items()})
    reference = manifest['toolchain_reference']
    files.update({str(Path(reference['directory']) / name): value for name, value in reference['files'].items()})
    files.update({str(ROOT / name): value for name, value in manifest['artifacts'].items()})
    files.update({tool['path']: tool['sha256'] for tool in manifest['tools'].values()})
    return files


def verify_identities(plan, checksum, files):
    failures = []
    seal = hashlib.sha256(f'{checksum}  measurement-plan-v2.json\n'.encode()).hexdigest()
    checks = {str(ROOT / 'measurement-plan-v2.json'): checksum, str(ROOT / 'measurement-plan-v2.sha256'): seal, **files}
    for name, expected in checks.items():
        try:
            checked_file(name, expected)
        except (OSError, ValueError) as error:
            failures.append(str(error))
    for name in plan['absent_files']:
        if os.path.lexists(name):
            failures.append(f'frozen absent dependency appeared: {name}')
    return dict(status='passed' if not failures else 'failed', checked_files=len(checks),
                failures=failures, finished_unix_seconds=time.time())


# ---- Eight routes and 48 attempts are fixed before the first warmup ----

def expected_schedule():
    schedule = []
    pairs = [('cat', 'wasm'), ('cat', 'native'), ('wc', 'wasm'), ('wc', 'native')]
    for round_index in range(6):
        offset = round_index % len(pairs)
        for position, (case, target) in enumerate(pairs[offset:] + pairs[:offset]):
            variants = ['scalar', 'packet'] if position % 2 == 0 else ['packet', 'scalar']
            for variant in variants:
                schedule.append(dict(index=len(schedule), round=round_index,
                    phase='warmup' if round_index == 0 else 'sample', route=f'{variant}-{case}-{target}'))
    return schedule


def verify_contract(plan, manifest, timing):
    timing.protocol_configuration(plan['cpu'], plan['warmups'], plan['samples'])
    timing.require_clean_environment(manifest)
    if plan['cpu'] != 2 or plan['schedule'] != expected_schedule():
        raise ValueError('the CPU or predetermined schedule changed')
    routes = {(row['variant'], row['case'], row['target']) for row in plan['routes'].values()}
    if len(plan['routes']) != 8 or routes != {(v, c, t) for v in ('scalar', 'packet')
                                          for c in ('cat', 'wc') for t in ('wasm', 'native')}:
        raise ValueError('the plan must contain all eight routes')
    for row in plan['routes'].values():
        verify_route(row, manifest, frozen_files(plan, manifest))


def verify_route(row, manifest, files):
    spec = load(row['specification'])
    if spec['count'] != 50 or spec['expected'] != 1 or 'configured-count' not in spec['additional_exports']:
        raise ValueError('the original count and complete result predicate are required')
    if row['command'][:3] != [manifest['tools']['TASKSET']['path'], '-c', '2']:
        raise ValueError('each fresh process must be pinned to CPU 2')
    if digest(row['optimized_wasm']) != digest(row['native_optimized_wasm']):
        raise ValueError('native and Wasm must execute identical optimized guest bytes')
    if row['case'] == 'cat' and row['cat_output_sha256'] != manifest['input']['sha256']:
        raise ValueError('Cat must compare every output byte with the frozen input')
    for name in row['dependencies']:
        if name not in files:
            raise ValueError(f'route dependency has no frozen identity: {name}')


# ---- Every attempt owns new input copies, output files and a fresh process ----

def working_directory(trial, row, files):
    working = trial / 'workload'
    working.mkdir()
    for name, source in row['input_files'].items():
        destination = working / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        checked_file(destination, files[source])
    (working / 'outputs').mkdir()
    return working


def retained_output(working, row):
    if row['case'] != 'cat':
        return None
    path = working / 'outputs/cat.output'
    if not path.is_file() or path.is_symlink():
        return dict(status='missing', expected_sha256=row['cat_output_sha256'])
    checksum = digest(path)
    return dict(status='passed' if checksum == row['cat_output_sha256'] else 'failed',
                sha256=checksum, expected_sha256=row['cat_output_sha256'], bytes=path.stat().st_size)


def check_trial(trial, working, row, files, process, timing):
    result = dict(status='failed-process', cat_output=retained_output(working, row))
    for name, source in row['input_files'].items():
        checked_file(working / name, files[source])
    if not runner.succeeded(process):
        return result
    try:
        output = (trial / 'commands/execute/stdout.bin').read_bytes().decode('utf-8')
        json.loads(output)  # Cat and WC produce one complete timing record, with no other output.
        result['seconds'] = timing.elapsed_seconds('sfir-' + row['target'], output, load(row['specification']))
        if result['cat_output'] is not None and result['cat_output']['status'] != 'passed':
            raise ValueError('Cat output bytes differ from the complete frozen input')
        result['status'] = 'passed'
    except (OSError, UnicodeError, ValueError, TypeError, KeyError) as error:
        result.update(status='failed-result', reason=str(error))
    return result


def execute_trial(destination, item, row, plan, files, timing):
    trial = destination / 'trials' / f'{item["index"]:02d}-{item["phase"]}-{item["route"]}'
    trial.mkdir(parents=True)
    for path in row['dependencies']:
        checked_file(path, files[path])
    working = working_directory(trial, row, files)
    process = runner.record(trial, 'execute', row['command'], plan['environment'], working,
                            plan['timeout_seconds'], (working / 'input.txt').read_bytes())
    result = check_trial(trial, working, row, files, process, timing)
    result['command_record'] = str((trial / 'commands/execute/record.json').relative_to(destination))
    runner.save(trial / 'result.json', dict(item, **result))
    return result


# ---- Only routes with a passing warmup and all five samples earn a median ----

def route_statistics(name, attempts, verified_complete_schedule):
    selected = [item for item in attempts if item['route'] == name]
    complete = verified_complete_schedule and len(selected) == 6 and all(item['status'] == 'passed' for item in selected)
    samples = [item['seconds'] for item in selected if item['phase'] == 'sample' and item['status'] == 'passed']
    row = dict(route=name, complete=complete, samples=samples,
               attempts=[dict(index=item['index'], phase=item['phase'], status=item['status']) for item in selected])
    if complete:
        row['median_seconds'] = statistics.median(samples)
    return row


def comparisons(rows):
    result = []
    for case in ('cat', 'wc'):
        for target in ('wasm', 'native'):
            scalar, packet = (rows[f'{variant}-{case}-{target}'] for variant in ('scalar', 'packet'))
            row = dict(case=case, target=target, status='withheld')
            if scalar['complete'] and packet['complete']:
                row.update(status='passed', scalar_over_packet=scalar['median_seconds'] / packet['median_seconds'])
            else:
                row['reason'] = 'both routes require the complete frozen schedule, unchanged dependencies and six passing attempts'
            result.append(row)
    return result


def publish(destination, report, plan):
    complete = (report['status'] in ('complete', 'complete-with-failures')
                and report.get('verification_after', {}).get('status') == 'passed')
    report['rows'] = {name: route_statistics(name, report['attempts'], complete) for name in plan['routes']}
    report['comparisons'] = comparisons(report['rows'])
    runner.save(destination / 'measurement.json', report)


# Keep the campaign transition together: every interruption publishes its position,
# checks identities again, and leaves the one-shot destination in place.
def measure(plan, checksum, manifest, files, timing, attestation):
    destination = ROOT / 'measurement-v2'
    destination.mkdir()  # Existing evidence is never overwritten or resumed.
    report = dict(status='started', quiet_window_attestation=attestation, plan_sha256=checksum,
                  preparation_manifest_sha256=plan['bootstrap_files']['manifest.json'],
                  driver_sha256=plan['bootstrap_files']['measure-v2.py'], started_unix_seconds=time.time(),
                  environment=plan['environment'], attempts=[dict(item, status='not-attempted') for item in plan['schedule']])
    publish(destination, report, plan)
    try:
        report['verification_before'] = verify_identities(plan, checksum, files)
        if report['verification_before']['status'] != 'passed':
            raise ValueError('frozen dependencies failed preflight verification')
        verify_contract(plan, manifest, timing)
        report.update(status='running', machine_before=timing.machine_context(2))
        for item in report['attempts']:
            item['status'] = 'running'
            publish(destination, report, plan)
            item.update(execute_trial(destination, item, plan['routes'][item['route']], plan, files, timing))
            publish(destination, report, plan)
            print(f'{item["index"]:02d} {item["phase"]} {item["route"]}: {item["status"]}', flush=True)
        report['status'] = 'complete' if all(item['status'] == 'passed' for item in report['attempts']) else 'complete-with-failures'
    except BaseException as error:
        report.update(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'aborted', exception=repr(error))
        for item in report['attempts']:
            if item['status'] == 'running':
                item.update(status=report['status'], exception=repr(error))
    finally:
        report['verification_after'] = verify_identities(plan, checksum, files)
        report.update(machine_after=timing.machine_context(2), finished_unix_seconds=time.time())
        if report['verification_after']['status'] != 'passed':
            report['status'] = 'failed-integrity'
        publish(destination, report, plan)
    return report['status'] == 'complete'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['verify', 'measure'])
    parser.add_argument('--quiet-window', help='explicit attestation naming the approved quiet window; required for measure')
    options = parser.parse_args()
    if options.action == 'measure' and not (options.quiet_window or '').strip():
        parser.error('measure requires an explicit --quiet-window attestation; no workload was launched')
    plan, checksum, manifest = read_plan()
    global runner
    runner = frozen_module('runner', ROOT / 'packet/source/benchmarks/sfir/runner.py')
    timing = frozen_module('timing', ROOT / 'packet/source/benchmarks/sfir/timing.py')
    files = frozen_files(plan, manifest)
    if options.action == 'measure':
        passed = measure(plan, checksum, manifest, files, timing, options.quiet_window.strip())
    else:
        report = verify_identities(plan, checksum, files)
        if report['status'] == 'passed':
            verify_contract(plan, manifest, timing)
        print(json.dumps(dict(report, plan_sha256=checksum, routes=8, scheduled_attempts=48, workloads_executed=0), indent=2))
        passed = report['status'] == 'passed'
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda signum, frame: (_ for _ in ()).throw(KeyboardInterrupt(f'signal {signum}')))
    main()
