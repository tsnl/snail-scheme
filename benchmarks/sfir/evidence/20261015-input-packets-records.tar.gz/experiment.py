#!/usr/bin/env python3
"""Freeze and validate unchanged Cat/WC on scalar and packet input; never time."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import tarfile

sys.dont_write_bytecode = True
BASE = '6f32b9cf303569f2578f6c16b9394bba14b8c3cb'
CANDIDATE = 'c0b6f16299c5568e4f906f18af330df43aa7df25'
CASES = ('cat', 'wc')
VARIANTS = {'scalar': BASE, 'packet': CANDIDATE}
PIN = '85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1'


def driver(path):
    spec = importlib.util.spec_from_file_location('comparison_runner', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(runner, directory, label, command, manifest, cwd):
    result = runner.record(directory, label, command, runner.frozen_environment(manifest), cwd, 1800)
    if not runner.succeeded(result):
        raise RuntimeError(f'{label}: failed; see {directory / "commands" / label}')
    return result


# ---- Exact source revisions and a separate immutable input/tool manifest ----


def snapshot(runner, root, output, variant, revision, manifest):
    directory = output / variant
    directory.mkdir()
    archive = directory / 'source.tar'
    command = ['git', 'archive', '--format=tar', '--output', archive, revision,
               'src', 'lib', 'scripts', 'Cargo.toml', 'Cargo.lock', 'benchmarks/sfir']
    result = runner.record(output, variant + '-snapshot', command, os.environ, root, 300)
    if not runner.succeeded(result):
        raise RuntimeError('source snapshot failed')
    with tarfile.open(archive) as source:
        if any(not (member.isfile() or member.isdir()) for member in source.getmembers()):
            raise ValueError('source snapshot contains a nonordinary file')
        source.extractall(directory / 'source', filter='data')
    files = {str(path.relative_to(directory)): runner.digest(path)
             for path in sorted((directory / 'source').rglob('*')) if path.is_file()}
    files['source.tar'] = runner.digest(archive)
    manifest['variants'][variant] = dict(revision=revision, files=files)
    runner.save(output / 'manifest.json', manifest)


def tool_manifest(runner, reference, output):
    frozen = runner.load(reference / 'manifest.json')
    dependencies = {name: checksum for name, checksum in frozen['build_dependencies'].items()
                    if name.startswith(('toolchain/rust/bin/', 'toolchain/rust/lib/'))}
    runner.verify_files(reference, dependencies)
    environment = dict(frozen['execution_environment'])
    environment.update(CARGO_HOME=str(output / 'cargo-home'), CARGO_BUILD_JOBS='1', BINARYEN_CORES='1',
                       NODE_V8_COVERAGE=None, LD_PRELOAD=None, SNAIL_GC_STATS=None, SNAIL_NATIVE_GC_INTERVAL=None)
    (output / 'cargo-home').mkdir()
    return dict(kind='current-SFIR-input-packet-ablation-preparation', base=BASE, candidate=CANDIDATE,
                tools=frozen['tools'], execution_environment=environment,
                config=dict(compile_timeout=1800, run_timeout=1800), variants={}, artifacts={},
                toolchain_reference=dict(directory=str(reference), files=dependencies,
                    manifest_sha256=runner.digest(reference / 'manifest.json')),
                correctness=[], measurement='not-measured', performance_samples=False)


def canonical_input(runner, root, output, manifest):
    upstream = root / 'benchmarks/r7rs-benchmarks'
    for label, arguments in [('root', ['rev-parse', '--show-toplevel']), ('head', ['rev-parse', 'HEAD']),
                             ('status', ['status', '--porcelain'])]:
        result = runner.record(output, 'canonical-' + label, ['git', '-C', upstream, *arguments],
                               os.environ, root, 30)
        if not runner.succeeded(result):
            raise RuntimeError('cannot verify canonical clone')
        expected = str(upstream) if label == 'root' else PIN if label == 'head' else ''
        assert result['stdout'].strip() == expected, result
    target = output / 'bib'
    shutil.copy2(upstream / 'inputs/bib', target)
    manifest['input'] = dict(submodule=PIN, bytes=target.stat().st_size, sha256=runner.digest(target))
    for variant in VARIANTS:
        data = output / variant / 'data/inputs'
        data.mkdir(parents=True)
        shutil.copy2(target, data / 'bib')


def same_workloads(runner, output, manifest):
    identities = {}
    for case in CASES:
        left = output / 'scalar/source/benchmarks/sfir' / case
        right = output / 'packet/source/benchmarks/sfir' / case
        files = [path for path in sorted(left.rglob('*')) if path.is_file()]
        for path in files:
            relative = path.relative_to(left)
            assert path.read_bytes() == (right / relative).read_bytes(), (case, relative)
            identities[str(Path(case) / relative)] = runner.digest(path)
        assert runner.load(left / 'spec.json')['count'] == 50
    manifest['unchanged_workloads'] = identities


# ---- Correctness hosts retain the complete worker and I/O predicates ----


def prepare_case(runner, output, variant, case, manifest):
    directory = output / variant
    source = directory / 'source/benchmarks/sfir' / case
    target = directory / 'artifacts' / case
    target.mkdir(parents=True)
    for name in ('input.txt', 'spec.json'):
        shutil.copy2(source / name, target / name)
    corpus = runner.load(directory / 'source/benchmarks/sfir/corpus.json')
    selected, = [entry for entry in corpus['cases'] if entry['name'] == case]
    environment = runner.frozen_environment(manifest)
    built = runner.sfir_build(directory, selected, source, target, manifest, environment)
    if not runner.succeeded(built):
        raise RuntimeError(f'{variant} {case}: guest build failed')
    status = dict(raw_sha256=runner.digest(target / 'program.wasm.raw.wasm'),
                  optimized_sha256=runner.digest(target / 'program.wasm'))
    runner.save(target / 'status.json', status)
    assert runner.datum_validation(directory, target, manifest, environment) == 'passed'
    assert runner.output_files_match(source, target / 'runs/sfir-wasm', target, 'sfir-wasm')
    assert runner.native_validation(directory, source, target, manifest, environment) == 'passed'
    timing = build_timing(runner, directory, target, manifest)
    manifest['correctness'].append(dict(variant=variant, case=case, count=50, wasm='passed', native='passed',
        full_predicate=True, cat_output_bytes_checked=case == 'cat', timed=False,
        optimized_guest_sha256=status['optimized_sha256'], timing_executable=str(timing)))
    runner.save(output / 'manifest.json', manifest)
    print(f'Prepared {variant} {case}: full correctness and identical native guest; no timing', flush=True)


# ---- Build an uninstrumented native timing entry without executing it ----


def build_timing(runner, directory, target, manifest):
    timing = target / 'timing'
    timing.mkdir()
    support = directory / 'source/benchmarks/sfir/support'
    for name in ('scalar-provider.h', 'scalar-provider.c', 'scalar-timing-entry.c'):
        shutil.copy2(support / name, timing / name)
    configuration = '#define OBSERVE_BARRIERS 0\n' + runner.native_configuration(runner.load(target / 'spec.json'))
    (timing / 'case-config.h').write_text(configuration)
    run(runner, timing, 'native-build', [manifest['tools']['PYTHON']['path'], directory / 'source/scripts/build-native',
        '--wasm', '--entry-c', timing / 'scalar-timing-entry.c', '--c-provider', 'benchmark',
        timing / 'scalar-provider.h', timing / 'scalar-provider.c', target / 'program.wasm.raw.wasm',
        timing / 'program.native'], manifest, timing)
    native_guest, = timing.glob('program.native.native-*/optimized.wasm')
    assert (target / 'program.wasm').read_bytes() == native_guest.read_bytes()
    runner.save(timing / 'guest-identity.json', dict(sha256=runner.digest(native_guest),
        raw_input=str(target / 'program.wasm.raw.wasm'), optimized_guest=str(native_guest), executed=False))
    return timing / 'program.native'


def artifacts(runner, output):
    result = {}
    for variant in VARIANTS:
        for path in sorted((output / variant).rglob('*')):
            if not path.is_file() or 'source' in path.relative_to(output / variant).parts[:1]:
                continue
            if path.suffix in ('.wasm', '.wat', '.ll', '.o', '.a', '.c', '.h') or path.name in ('program.native', 'build.json', 'provider.json'):
                result[str(path.relative_to(output))] = runner.digest(path)
    return result


# ---- Verification is separate from any future clean measurement campaign ----


def verify(runner, output):
    manifest = runner.load(output / 'manifest.json')
    assert manifest['measurement'] == 'not-measured' and not manifest['performance_samples']
    assert runner.digest(output / 'experiment.py') == manifest['driver_sha256']
    reference = manifest['toolchain_reference']
    runner.verify_files(Path(reference['directory']), reference['files'])
    for tool in manifest['tools'].values():
        assert runner.digest(tool['path']) == tool['sha256'], tool
    for variant, data in manifest['variants'].items():
        runner.verify_files(output / variant, data['files'])
        assert runner.digest(output / variant / 'data/inputs/bib') == manifest['input']['sha256']
    runner.verify_files(output, manifest['artifacts'])
    assert runner.digest(output / 'bib') == manifest['input']['sha256']
    assert len(manifest['correctness']) == 4
    print('Verified frozen sources, tools, input, runtimes and artifacts; no timing samples', flush=True)


def prepare(runner, root, reference, output):
    output.mkdir(parents=True)
    shutil.copy2(Path(__file__), output / 'experiment.py')
    manifest = tool_manifest(runner, reference, output)
    manifest['driver_sha256'] = runner.digest(output / 'experiment.py')
    for variant, revision in VARIANTS.items():
        snapshot(runner, root, output, variant, revision, manifest)
    canonical_input(runner, root, output, manifest)
    same_workloads(runner, output, manifest)
    runner.save(output / 'manifest.json', manifest)
    for variant in VARIANTS:
        for case in CASES:
            prepare_case(runner, output, variant, case, manifest)
    manifest['artifacts'] = artifacts(runner, output)
    runner.save(output / 'manifest.json', manifest)
    verify(runner, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'verify'])
    parser.add_argument('--repo', type=Path, default=Path('/tmp/snail-sfir-input-buffer-migration-20261015'))
    parser.add_argument('--toolchain-reference', type=Path, default=Path('/tmp/sfir-checked-full57-20261015-v1'))
    parser.add_argument('--output', type=Path, required=True)
    options = parser.parse_args()
    output = options.output.resolve()
    path = (options.repo if options.action == 'prepare' else output / 'packet/source') / 'benchmarks/sfir/runner.py'
    runner = driver(path)
    if options.action == 'prepare':
        prepare(runner, options.repo.resolve(), options.toolchain_reference.resolve(), output)
    else:
        verify(runner, output)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda signum, frame: (_ for _ in ()).throw(KeyboardInterrupt(f'signal {signum}')))
    main()
