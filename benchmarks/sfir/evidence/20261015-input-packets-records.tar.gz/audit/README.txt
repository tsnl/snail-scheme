Completed paired Cat/WC measurement. Original relative paths retain exact bytes.
Only measurement-v2/measurement.json is the terminal measurement authority.
manifest.json, timing-routes.json, guest-identity.json and MEASUREMENT.md retain
preparation-time status words verbatim; they do not supersede terminal results.
The measured baseline/candidate are 6f32b9cf/c0b6f162. Rebase proof rebuilt f432b0a8;
the two recorded later path sets preserve that implementation through d153adf6.
No fresh d153 build, workload or measurement was executed for this report.
All 48 original trial process records/raw streams and result.json are retained.
Additional preparation/rebase/tool records contain no extra performance samples.
All 24 complete Cat output hashes and 96 input-copy hashes were rechecked.
Output trees, binaries, LLVM IR, sysroot and vendor copies are omitted; exact
existing artifact/dependency identities remain in manifest, plan and build JSON.
The original measurement records include incidental wall clocks; only the guest
seconds parsed from raw trial stdout supply the five measured samples per route.
Every member except index.json is indexed by exact byte length and SHA-256.
