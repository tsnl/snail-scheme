#!/usr/bin/env python3
"""Freeze the measurement plan using only file reads and shared-library inspection."""

import ast
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
PREPARATION_SHA256 = 'dc53cf4ff7eb1163653592cdf13e72b199078d39eed28b80e1b495e372542dbc'


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def inspect_driver(driver):
    ast.parse((ROOT / 'measure-v2.py').read_text())
    schedule = driver.expected_schedule()
    counts = Counter((item['route'], item['phase']) for item in schedule)
    assert len(schedule) == 48 and len(counts) == 16
    assert all(count == (1 if phase == 'warmup' else 5) for (_, phase), count in counts.items())
    for case in ('cat', 'wc'):
        for target in ('wasm', 'native'):
            first = [next(item['route'].split('-')[0] for item in schedule
                          if item['round'] == round_index and item['route'].endswith(f'-{case}-{target}'))
                     for round_index in range(6)]
            assert all(left != right for left, right in zip(first, first[1:]))
    attempts = [dict(item, status='passed', seconds=float(item['round'] + 1)) for item in schedule]
    route = schedule[0]['route']
    assert driver.route_statistics(route, attempts, True)['median_seconds'] == 4
    for phase in ('warmup', 'sample'):
        failed = [dict(item) for item in attempts]
        next(item for item in failed if item['route'] == route and item['phase'] == phase)['status'] = 'failed-process'
        assert 'median_seconds' not in driver.route_statistics(route, failed, True)
    assert 'median_seconds' not in driver.route_statistics(route, attempts, False)
    return dict(status='passed', checks=['syntax', '48 fixed attempts', 'one warmup and five samples per route',
                'each case/target pair alternates its first variant every round',
                'failed warmup withholds median', 'failed sample withholds median', 'incomplete campaign withholds median'],
                workloads_executed=0, timing_samples=0)


def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode
    assert digest(ROOT / 'manifest.json') == PREPARATION_SHA256
    assert not (ROOT / 'measurement-plan-v2.json').exists()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for name in ('runner.py', 'timing.py'):
        relative = 'source/benchmarks/sfir/' + name
        assert digest(ROOT / 'packet' / relative) == manifest['variants']['packet']['files'][relative]
    runner = module('runner', ROOT / 'packet/source/benchmarks/sfir/runner.py')
    timing = module('timing', ROOT / 'packet/source/benchmarks/sfir/timing.py')
    driver = module('comparison_measure', ROOT / 'measure-v2.py')
    driver.runner = runner
    checks = inspect_driver(driver)
    runner.save(ROOT / 'measurement-preparation-v2/static-checks.json', checks)

    environment = {name: value for name, value in manifest['execution_environment'].items() if value is not None}
    environment.update({name: tool['path'] for name, tool in manifest['tools'].items()})
    environment['PATH'] = os.pathsep.join(sorted({str(Path(tool['path']).parent) for tool in manifest['tools'].values()}))
    timing.protocol_configuration(2, 1, 5)
    timing.require_clean_environment(manifest)
    preparation = ROOT / 'measurement-preparation-v2'
    libraries = {}
    for name in ('NODE', 'TASKSET', 'PYTHON'):
        libraries[name] = timing.immutable_execution_dependencies(
            [manifest['tools'][name]['path']], preparation, name.lower(), manifest, environment)

    extra = {str(ROOT / 'bib'): manifest['input']['sha256']}
    routes = {}
    for row in runner.load(ROOT / 'timing-routes.json')['routes']:
        variant, case = row['variant'], row['case']
        target = ROOT / variant / 'artifacts' / case
        parity = runner.load(target / 'timing/guest-identity.json')
        native_libraries = timing.immutable_execution_dependencies(row['native_command'], preparation,
                            variant + '-' + case, manifest, environment)
        extra.update(native_libraries)
        for path in [ROOT / variant / 'data/inputs/bib', target / 'spec.json', target / 'input.txt',
                     target / 'status.json', target / 'native-parity.json', target / 'timing/guest-identity.json']:
            extra[str(path)] = digest(path)
        for execution_target in ('wasm', 'native'):
            command = row[execution_target + '_command']
            dependencies = {str(ROOT / name) for name in ('measure-v2.py', 'manifest.json', 'timing-routes.json',
                            'packet/source/benchmarks/sfir/runner.py', 'packet/source/benchmarks/sfir/timing.py')}
            dependencies.update(item for item in command if Path(item).is_absolute() and Path(item).is_file())
            dependencies.update(row['required_cwd_files'].values())
            dependencies.update(libraries['TASKSET'])
            dependencies.update(libraries['NODE'] if execution_target == 'wasm' else native_libraries)
            dependencies.add(str(target / 'spec.json'))
            name = f'{variant}-{case}-{execution_target}'
            routes[name] = dict(variant=variant, case=case, target=execution_target,
                command=[manifest['tools']['TASKSET']['path'], '-c', '2', *command],
                specification=str(target / 'spec.json'), input_files=row['required_cwd_files'],
                optimized_wasm=str(target / 'program.wasm'), native_optimized_wasm=parity['optimized_guest'],
                configured_count=50, expected_result=1, cat_output_sha256=row['cat_output_sha256'],
                dependencies=sorted(dependencies))

    for files in libraries.values():
        extra.update(files)
    # Freeze the isolated Python runtime, including its bytecode and extension modules.
    for path in sorted(Path(sys.prefix).rglob('*')):
        if path.is_file():
            extra[str(path)] = digest(path)
    for line in Path('/proc/self/maps').read_text().splitlines():
        path = line.split()[-1]
        if path.startswith('/nix/store/') and Path(path).is_file():
            extra[path] = digest(path)
    for path in sorted(preparation.rglob('*')):
        if path.is_file():
            extra[str(path)] = digest(path)
    bootstrap = ('manifest.json', 'experiment.py', 'timing-routes.json', 'measure-v2.py',
                 'packet/source/benchmarks/sfir/runner.py', 'packet/source/benchmarks/sfir/timing.py')
    plan = dict(kind='SFIR-owned-input-buffer-clean-comparison-v2', directory=str(ROOT),
        base=manifest['base'], candidate=manifest['candidate'], cpu=2, warmups=1, samples=5,
        timeout_seconds=manifest['config']['run_timeout'], fresh_process_per_attempt=True,
        fresh_working_directory_per_attempt=True, retries=0,
        quiet_window='measure requires an explicit --quiet-window attestation from the coordinating parent',
        timer='unchanged guest monotonic seconds around 50 original iterations and complete final predicate',
        outside_timer='process startup, input/setup, result formatting, final resource cleanup, Cat output byte hash',
        order='For each round rotate [(cat,wasm),(cat,native),(wc,wasm),(wc,native)] left by round mod 4; '
              'within each pair use scalar,packet when rotated position is even, otherwise packet,scalar. '
              'Each fixed case/target pair alternates its first variant every round. Round 0 is warmup; rounds 1 through 5 are samples. No adaptation.',
        failure_policy='Retain each attempt and raw process output; no retries. A failed warmup or sample withholds '
                       'its route median and comparisons. An interrupted or integrity-failed campaign withholds all comparisons.',
        environment=environment, python_path=sys.path, python_sha256=manifest['tools']['PYTHON']['sha256'],
        bootstrap_files={name: digest(ROOT / name) for name in bootstrap}, extra_files=dict(sorted(extra.items())),
        absent_files=[name for name in sys.path if not Path(name).exists()], routes=routes,
        schedule=driver.expected_schedule())
    assert digest(ROOT / 'manifest.json') == PREPARATION_SHA256
    runner.save(ROOT / 'measurement-plan-v2.json', plan)
    checksum = digest(ROOT / 'measurement-plan-v2.json')
    (ROOT / 'measurement-plan-v2.sha256').write_text(f'{checksum}  measurement-plan-v2.json\n')
    driver.verify_contract(plan, manifest, timing)
    verified = driver.verify_identities(plan, checksum, driver.frozen_files(plan, manifest))
    runner.save(preparation / 'initial-verification.json', verified)
    assert verified['status'] == 'passed', verified
    for name in ('measure-v2.py', 'measurement-plan-v2.json', 'measurement-plan-v2.sha256'):
        (ROOT / name).chmod(0o444)
    print(json.dumps(dict(plan_sha256=checksum, driver_sha256=digest(ROOT / 'measure-v2.py'),
                         preparation_manifest_sha256=PREPARATION_SHA256, routes=8, attempts=48,
                         checked_files=verified['checked_files'], workloads_executed=0), indent=2))


if __name__ == '__main__':
    main()
