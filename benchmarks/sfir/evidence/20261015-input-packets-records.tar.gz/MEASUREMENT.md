# Cat/WC input buffering measurement plan

The reviewed candidate is `c0b6f16299c5568e4f906f18af330df43aa7df25`; the exact
baseline is `6f32b9cf303569f2578f6c16b9394bba14b8c3cb`. Use **measure-v2.py** and
**measurement-plan-v2.json**. No workload or performance sample has been executed
by either measurement driver. The clean native timing executables remain unrun.

The preparation manifest remains unchanged, with SHA-256
`dc53cf4ff7eb1163653592cdf13e72b199078d39eed28b80e1b495e372542dbc`.
It describes preparation only; future measurement evidence belongs in the new
`measurement-v2/` directory.

## Frozen protocol

There are eight routes: scalar/packet × Cat/WC × linked Wasm/native. Every route
gets one fresh-process warmup followed by five fresh-process samples, each pinned
to CPU 2 with the frozen `taskset`. The original sources, 4,460,056-byte input,
count 50, complete result predicate, and mandatory Binaryen guest bytes are
unchanged. The native build consumes exactly the optimized guest bytes used by
Wasm within each variant/case pair.

Every attempt owns new copies of `input.txt` and `inputs/bib`, a new output
directory, a process record, and raw stdout/stderr files. The existing frozen
`runner.record` owns process groups, timeout cleanup, descendant checks and raw
captures. The existing frozen `timing.elapsed_seconds` validates the reported
result and positive finite workload duration. Both existing hosts check the
configured count and pass 50 to the worker. Cat's output SHA-256 must equal
`2994b446dfb07d7cf324fb6aa32d519b3f0bd53a582268714adf08df5f45b8d3` after every
warmup and sample, outside the workload clock. WC retains its complete
`(31102 851820 4460056)` datum predicate inside the worker.

The clock still encloses the original repeated workload and its complete final
predicate. Process startup, setup, result formatting, final resource cleanup,
and Cat's additional output hash stay outside that clock. Command wall times
are retained for diagnostics and are never used as performance samples.

The schedule is fixed in the plan. `S,P` means scalar then packet; `P,S` means
packet then scalar. Each case/target pair alternates its first variant every
round, while case/target positions rotate. No order adapts to results.

| Round | Phase | First pair | Second pair | Third pair | Fourth pair |
| --- | --- | --- | --- | --- | --- |
| 0 | Warmup | Cat Wasm S,P | Cat native P,S | WC Wasm S,P | WC native P,S |
| 1 | Sample 1 | Cat native S,P | WC Wasm P,S | WC native S,P | Cat Wasm P,S |
| 2 | Sample 2 | WC Wasm S,P | WC native P,S | Cat Wasm S,P | Cat native P,S |
| 3 | Sample 3 | WC native S,P | Cat Wasm P,S | Cat native S,P | WC Wasm P,S |
| 4 | Sample 4 | Cat Wasm S,P | Cat native P,S | WC Wasm S,P | WC native P,S |
| 5 | Sample 5 | Cat native S,P | WC Wasm P,S | WC native S,P | Cat Wasm P,S |

All frozen source, tools, Rust/runtime files, build artifacts, Python runtime,
shared libraries, inputs, execution helpers and driver identities are checked
before and after measurement; direct route dependencies are also checked before
each launch. The plan and driver are read-only and sealed by SHA-256. The child
environment is the exact map in the plan, without ambient variables. Machine
and CPU configuration are recorded before and after the campaign.

There are no retries or resumed runs. Existing `measurement-v2/` evidence makes
the command refuse to start again. An ordinary process or result failure remains
in the schedule, and subsequent predetermined attempts still run. A failed
warmup or sample withholds that route's median and every comparison using it.
Interruption, dependency failure or an incomplete campaign withholds all
comparisons. Every attempted or unattempted position remains visible in
`measurement-v2/measurement.json`; process records and output bytes remain under
its `trials/` directory. Ratios, when earned, are scalar median / packet median.

## Review and commands

SHA-256 identities:

- Plan: `7be6bf3b3b4217d20ebba617299d4b507c93193add8cecd87fa30e155030c9c6`
- Driver: `8209b62baa891b5cd4918e840cc64984e66877cc00229811370051c3de5ddb52`

Verification performs file and protocol checks and launches no workloads:

```sh
/nix/store/dlhnzkygd34z7mavq8c6pnag4kjafbjn-system-path/bin/python3 -I -S -B \
  /tmp/sfir-input-buffer-comparison-20261015-v1/measure-v2.py verify
```

Only after the coordinating parent grants a quiet window, replace the attestation
below with its actual approved window and execute once:

```sh
/nix/store/dlhnzkygd34z7mavq8c6pnag4kjafbjn-system-path/bin/python3 -I -S -B \
  /tmp/sfir-input-buffer-comparison-20261015-v1/measure-v2.py measure \
  --quiet-window 'ACTUAL PARENT-APPROVED QUIET WINDOW AND ATTESTATION'
```

The `measure` action refuses an absent or empty attestation. An attestation is an
explicit human statement, not an automated assertion that the machine is quiet.
The measurement branch has deliberately not been executed during preparation.

Syntax, schedule counts, per-pair variant alternation and pure failed-route
withholding checks passed. The read-only `verify` action passed for 7,577 frozen
files. Evidence is in `measurement-preparation-v2/static-checks.json`, its
`initial-verification.json`, and the retained shared-library inspection records.
The outer command records are at
`/tmp/snail-sfir-input-buffer-migration-20261015/build/input-buffer-work/commands/comparison-measurement-plan-v2/`
and `comparison-measurement-verify-v2/` beside it.

The first sealed draft (`measure.py`, `measurement-plan.json`, and
`measurement-preparation/`) is retained for audit and is superseded. Review found
that its rotation kept each case/target pair's first variant fixed. Version 2
corrects that order and adds an explicit alternation check. Neither draft has
executed any workload, and neither changes the preparation manifest.
