(module
 (rec
  (type $type13 (sub (struct (field i32))))
  (type $type289 (sub (struct)))
  (type $type295 (sub (struct (field i32))))
  (type $type277 (sub (struct (field i32))))
  (type $type226 (sub (struct (field i32))))
  (type $type219 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type32 (sub (struct (field i32))))
  (type $type88 (sub (struct)))
  (type $9 (func (param i64 i32 i32 i64) (result i64)))
  (type $type65 (struct (field (ref $type66))))
  (type $call315 (func (param (ref $type68) (ref $type65)) (result i32)))
  (type $type40 (sub $type13 (struct (field i32))))
  (type $call313 (func (param (ref null $type12) (ref $type41) i64) (result (ref $type226))))
  (type $14 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call309 (func (param (ref null $type12) (ref $type36)) (result (ref $type13))))
  (type $type41 (struct (field (ref $type42))))
  (type $type42 (array (mut i8)))
  (type $type38 (sub $type13 (struct (field i32))))
  (type $19 (func (param (ref $type68) i64 (ref null $type12)) (result (ref $type226))))
  (type $call304 (func (param (ref $type68) (ref $type277)) (result (ref $type226))))
  (type $21 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type295))))
  (type $22 (func (param (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $23 (func (param (ref $type68) (ref $type269) i32 i32 i32) (result (ref $type18))))
  (type $call267 (func (param i64) (result i32)))
  (type $call275 (func (param (ref $type68) i64) (result i32)))
  (type $26 (func (param (ref $type269) i32)))
  (type $call300 (func (param (ref $type68) i64) (result (ref $type295))))
  (type $call302 (func (param (ref $type68) i64 i64) (result (ref $type295))))
  (type $call292 (func (param (ref $type68) i32 (ref $type269)) (result (ref $type289))))
  (type $type291 (sub $type289 (struct (field (ref $type18)))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type290 (sub $type289 (struct (field (ref $type18)))))
  (type $call287 (func (param (ref $type68) i32 i32) (result (ref $type277))))
  (type $call77 (func (param (ref $type68)) (result i32)))
  (type $call265 (func (param i64 i32) (result i32)))
  (type $call264 (func (param (ref $type88)) (result i64)))
  (type $call84 (func (param (ref $type68)) (result i64)))
  (type $type21 (sub $type13 (struct (field i32))))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type15 (sub $type13 (struct (field i32))))
  (type $type298 (sub $type295 (struct (field i32) (field (ref $type18)))))
  (type $type296 (sub $type295 (struct (field i32) (field i32))))
  (type $type270 (struct (field (mut (ref $type18)))))
  (type $type278 (sub $type277 (struct (field i32) (field (ref $type13)))))
  (type $type16 (sub $type13 (struct (field i32))))
  (type $type229 (sub $type226 (struct (field i32) (field (ref $type18)))))
  (type $type228 (sub $type226 (struct (field i32) (field (ref $type13)))))
  (type $type284 (sub $type277 (struct (field i32) (field (ref $type18)))))
  (type $type283 (sub $type277 (struct (field i32) (field (ref $type18)))))
  (type $type282 (sub $type277 (struct (field i32) (field i64))))
  (type $type269 (struct (field (ref $type270)) (field (ref $type69))))
  (type $call276 (func (param (ref $type68)) (result (ref $type277))))
  (type $53 (func (param (ref null $type39) i32 i32 i32 (ref null $type12) i64) (result (ref $type39))))
  (type $54 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $type39 (array (mut (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $call46 (func (param (ref null $type12)) (result (ref $type39))))
  (type $type36 (sub $type13 (struct (field i32))))
  (type $59 (func (result (ref $type36))))
  (type $type221 (sub $type219 (struct (field i32) (field (ref $type24)))))
  (type $type31 (sub $type24 (struct (field i32))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $type30 (sub $type24 (struct (field i32))))
  (type $type26 (sub $type24 (struct (field i32))))
  (type $type222 (sub $type219 (struct (field i32) (field (ref $type18)))))
  (type $call218 (func (param i32 i32) (result (ref $type219))))
  (type $67 (func (param i32 i64 i32 (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $type35 (sub $type32 (struct (field i32) (field f64))))
  (type $type34 (sub $type32 (struct (field i32) (field (ref $type27)))))
  (type $type33 (sub $type32 (struct (field i32) (field i64))))
  (type $call215 (func (param i32 i32 i32) (result (ref $type32))))
  (type $72 (func (param i32 i32 i32 i64 i32 (ref $type18) i32 i32 i32 i64) (result (ref $type18))))
  (type $73 (func (param (ref $type18) i32 i32 i64 i32 i32 i32 i64) (result i32)))
  (type $type27 (struct (field (ref $type28)) (field (ref $type28))))
  (type $call174 (func (param (ref $type28) (ref $type28)) (result (ref $type27))))
  (type $76 (func (param i32 i32 (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $call172 (func (param (ref $type28) (ref $type28)) (result f64)))
  (type $78 (func (param f64 i32 i32 i32 i64 f64) (result f64)))
  (type $call137 (func (param (ref $type28)) (result i64)))
  (type $80 (func (param i32 i32 (ref $type28) (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $call158 (func (param (ref $type18) i64) (result (ref $type28))))
  (type $82 (func (param (ref $type18) i32 i64 i32 i32 i64 (ref $type28)) (result (ref $type28))))
  (type $83 (func (param (ref $type18) i32 i64 i32 i32 i32 i64 (ref $type28)) (result (ref $type28))))
  (type $84 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $85 (func (param (ref $type18) i64 i32 i32 i64 i64) (result i64)))
  (type $call143 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $type151 (struct (field (ref $type28)) (field (ref $type28))))
  (type $88 (func (param (ref $type28) (ref $type28)) (result (ref $type151))))
  (type $89 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i64) (result i32)))
  (type $90 (func (param (ref $type29) (ref $type29) i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $91 (func (param (ref $type29) (ref $type29) i64 i64 i32 i64 i32 i32 i32 i64 i64) (result i64)))
  (type $92 (func (param (ref $type29) (ref $type29) i64 i32 i32 i64 i64) (result i64)))
  (type $93 (func (param (ref $type29) i64 i64 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type29))))
  (type $94 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i32 i64) (result (ref $type29))))
  (type $95 (func (param (ref $type29) (ref $type29) i64 i64 i64 i32 i32 i32 i64 i64) (result i32)))
  (type $96 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $97 (func (param (ref $type29) (ref $type29) i64 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type29))))
  (type $call139 (func (param (ref $type28) (ref $type28)) (result i64)))
  (type $99 (func (param (ref $type29) (ref $type29) i32 i32 i64) (result i64)))
  (type $100 (func (param (ref $type29) i32 i32 i32 i64 i32 i32 i32 i64 i64) (result i64)))
  (type $101 (func (param i32 i32 (ref $type29) i32 i32 i32 i64 i64) (result (ref $type28))))
  (type $call136 (func (param i64) (result (ref $type28))))
  (type $103 (func (param i32 i32 i64 i64) (result i64)))
  (type $call115 (func (param i64) (result i64)))
  (type $call134 (func (param (ref $type28)) (result i32)))
  (type $call52 (func (param (ref $type29)) (result (ref $type29))))
  (type $type29 (array (mut i32)))
  (type $108 (func (param (ref $type29) i32 i32 i64) (result i64)))
  (type $type90 (sub $type88 (struct (field i32))))
  (type $call92 (func (param (ref $type68)) (result (ref $type88))))
  (type $type66 (struct (field (mut i32))))
  (type $type68 (struct (field (ref $type66)) (field (ref $type69))))
  (type $call86 (func (param (ref $type68)) (result i32)))
  (type $call85 (func (param i64) (result i32)))
  (type $115 (func (param (ref $type18) i64 i32 i32 i32 i64) (result i32)))
  (type $116 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call63 (func (param (ref $type18) (ref null $type61) i64) (result i32)))
  (type $118 (func (param i32 i32 (ref null $type61) i64) (result i64)))
  (type $type61 (struct (field (ref $type18)) (field (ref null $type61))))
  (type $call60 (func (param (ref $type61)) (result (ref $type18))))
  (type $121 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $type20 (array (mut (ref null $type19))))
  (type $123 (func (param i32) (result (ref $type18))))
  (type $type82 (struct))
  (type $type316 (struct))
  (type $type312 (struct))
  (type $type311 (struct))
  (type $type310 (struct))
  (type $type308 (struct))
  (type $type307 (struct))
  (type $type305 (struct))
  (type $type303 (struct))
  (type $type299 (struct))
  (type $type294 (struct))
  (type $type293 (struct))
  (type $type288 (struct))
  (type $type286 (struct))
  (type $type285 (struct))
  (type $type272 (struct))
  (type $type237 (struct))
  (type $type236 (struct))
  (type $type232 (struct))
  (type $type230 (struct))
  (type $type225 (struct))
  (type $type224 (struct))
  (type $type223 (struct))
  (type $type217 (struct))
  (type $type214 (struct))
  (type $type192 (struct))
  (type $type185 (struct))
  (type $type171 (struct))
  (type $type170 (struct))
  (type $type169 (struct))
  (type $type157 (struct))
  (type $type156 (struct))
  (type $type155 (struct))
  (type $type154 (struct))
  (type $type153 (struct))
  (type $type123 (struct))
  (type $type150 (struct))
  (type $type149 (struct))
  (type $type148 (struct))
  (type $type147 (struct))
  (type $type144 (struct))
  (type $type142 (struct))
  (type $type140 (struct))
  (type $type132 (struct))
  (type $type104 (struct))
  (type $type100 (struct))
  (type $type81 (struct))
  (type $type80 (struct))
  (type $type79 (struct))
  (type $type76 (struct))
  (type $type74 (struct))
  (type $type73 (struct))
  (type $type62 (struct))
  (type $type50 (struct))
  (type $type46 (struct))
  (type $type317 (struct))
  (type $type315 (struct))
  (type $type313 (struct))
  (type $type302 (struct))
  (type $type301 (struct))
  (type $type115 (struct))
  (type $type300 (struct))
  (type $type292 (struct))
  (type $type287 (struct))
  (type $type273 (struct))
  (type $type267 (struct))
  (type $type5 (struct))
  (type $type218 (struct))
  (type $type213 (struct))
  (type $type210 (struct))
  (type $type174 (struct))
  (type $type158 (struct))
  (type $type141 (struct))
  (type $type137 (struct))
  (type $type85 (struct))
  (type $type75 (struct))
  (type $type63 (struct))
  (type $type60 (struct))
  (type $type59 (struct))
  (type $type83 (struct (field i64) (field (ref $type18)) (field (ref $type18))))
  (type $type306 (struct))
  (type $type275 (struct))
  (type $type274 (struct))
  (type $type186 (struct))
  (type $type146 (struct))
  (type $type138 (struct))
  (type $type78 (struct))
  (type $type268 (struct))
  (type $type262 (struct))
  (type $type69 (struct (field (mut i64))))
  (type $type190 (struct))
  (type $type145 (struct))
  (type $type58 (struct))
  (type $type216 (struct))
  (type $type215 (struct))
  (type $type183 (struct))
  (type $type172 (struct))
  (type $type163 (struct))
  (type $type139 (struct))
  (type $type135 (struct))
  (type $type72 (struct))
  (type $type271 (struct))
  (type $type176 (struct))
  (type $type77 (struct))
  (type $type266 (struct))
  (type $type263 (struct))
  (type $type209 (struct))
  (type $type189 (struct))
  (type $type304 (struct))
  (type $type152 (struct))
  (type $type143 (struct))
  (type $type309 (struct))
  (type $type276 (struct))
  (type $type233 (struct))
  (type $type231 (struct))
  (type $type208 (struct))
  (type $type133 (struct))
  (type $type52 (struct))
  (type $type54 (struct))
  (type $type131 (struct))
  (type $type130 (struct))
  (type $type64 (struct))
  (type $type84 (struct))
  (type $type28 (struct (field i32) (field (ref $type29))))
  (type $type136 (struct))
  (type $type86 (struct))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type264 (struct))
  (type $type134 (struct))
  (type $type129 (struct))
  (type $type265 (struct))
  (type $type297 (sub $type295 (struct (field i32))))
  (type $type281 (sub $type277 (struct (field i32))))
  (type $type280 (sub $type277 (struct (field i32))))
  (type $type279 (sub $type277 (struct (field i32))))
  (type $type227 (sub $type226 (struct (field i32))))
  (type $type220 (sub $type219 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type89 (sub $type88 (struct)))
 )
 (type $266 (func (result i32)))
 (type $267 (func (param i32) (result i32)))
 (type $268 (func (param i32)))
 (type $269 (func (param i32 i32) (result i32)))
 (type $270 (func))
 (type $271 (func (param i32 i32)))
 (type $272 (func (param f64) (result f64)))
 (type $273 (func (param i32 i32) (result i64)))
 (type $274 (func (param i32) (result i64)))
 (type $275 (func (param i32 i32 i32) (result i32)))
 (type $276 (func (param i32 i32 i32 i32) (result i32)))
 (type $277 (func (param i32 i32) (result f64)))
 (type $278 (func (param i64) (result i64)))
 (type $279 (func (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-packet" (func $foreign7 (param i32) (result i64)))
 (import "snail.library" "snail:io/read-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign9 (param i32) (result i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign10 (param i32 i32)))
 (import "snail.library" "snail:math/cos" (func $foreign12 (param f64) (result f64)))
 (import "snail.library" "snail:math/sin" (func $foreign13 (param f64) (result f64)))
 (import "snail.library" "snail:datum/token-open" (func $foreign19 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign20 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign21 (param i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign22 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign24 (param i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-length" (func $foreign27 (param i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-character" (func $foreign28 (param i32 i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-scale" (func $foreign29 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-radix" (func $foreign30 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign31 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign32 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign33 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign34 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign35 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse-radix" (func $foreign36 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign37 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign38 (param i32) (result i32)))
 (import "benchmark" "barrier" (func $foreign39 (result i32)))
 (import "snail.library" "snail:io/standard-input" (func $foreign40 (result i32)))
 (import "snail.library" "snail:io/standard-output" (func $foreign41 (result i32)))
 (global $global1596 (mut (ref null $type265)) (ref.null none))
 (global $global336 (mut (ref null $type129)) (ref.null none))
 (global $global357 (mut (ref null $type134)) (ref.null none))
 (global $global1590 (mut (ref null $type264)) (ref.null none))
 (global $global150 (mut (ref null $type91)) (ref.null none))
 (global $global152 (mut (ref null $type92)) (ref.null none))
 (global $empty89 (ref $type89) (struct.new_default $type89))
 (global $global139 (mut (ref null $type86)) (ref.null none))
 (global $global368 (mut (ref null $type136)) (ref.null none))
 (global $global335 (mut (ref null $type28)) (ref.null none))
 (global $global1588 (mut (ref null $type84)) (ref.null none))
 (global $global101 (mut (ref null $type64)) (ref.null none))
 (global $global339 (mut (ref null $type130)) (ref.null none))
 (global $global343 (mut (ref null $type131)) (ref.null none))
 (global $global61 (mut (ref null $type54)) (ref.null none))
 (global $global349 (mut (ref null $type52)) (ref.null none))
 (global $global353 (mut (ref null $type133)) (ref.null none))
 (global $global1140 (mut (ref null $type208)) (ref.null none))
 (global $global1231 (mut (ref null $type231)) (ref.null none))
 (global $global1236 (mut (ref null $type233)) (ref.null none))
 (global $global1585 (mut (ref null $type276)) (ref.null none))
 (global $global1743 (mut (ref null $type309)) (ref.null none))
 (global $global154 (mut (ref null $type92)) (ref.null none))
 (global $global1608 (mut (ref null $type84)) (ref.null none))
 (global $ready1743 (mut i32) (i32.const 0))
 (global $global469 (mut (ref null $type143)) (ref.null none))
 (global $global551 (mut (ref null $type152)) (ref.null none))
 (global $ready1585 (mut i32) (i32.const 0))
 (global $global1727 (mut (ref null $type304)) (ref.null none))
 (global $global859 (mut (ref null $type189)) (ref.null none))
 (global $global1148 (mut (ref null $type209)) (ref.null none))
 (global $global1583 (mut (ref null $type263)) (ref.null none))
 (global $global1605 (mut (ref null $type266)) (ref.null none))
 (global $global1599 (mut (ref null $type77)) (ref.null none))
 (global $ready1727 (mut i32) (i32.const 0))
 (global $global560 (mut (ref null $type143)) (ref.null none))
 (global $global792 (mut (ref null $type176)) (ref.null none))
 (global $global1657 (mut (ref null $type271)) (ref.null none))
 (global $ready1599 (mut i32) (i32.const 0))
 (global $global113 (mut (ref null $type72)) (ref.null none))
 (global $global359 (mut (ref null $type135)) (ref.null none))
 (global $global361 (mut (ref null $type135)) (ref.null none))
 (global $global398 (mut (ref null $type139)) (ref.null none))
 (global $global656 (mut (ref null $type143)) (ref.null none))
 (global $global667 (mut (ref null $type163)) (ref.null none))
 (global $global746 (mut (ref null $type172)) (ref.null none))
 (global $global839 (mut (ref null $type183)) (ref.null none))
 (global $global865 (mut (ref null $type189)) (ref.null none))
 (global $global1183 (mut (ref null $type215)) (ref.null none))
 (global $global1189 (mut (ref null $type216)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type58)) (ref.null none))
 (global $global472 (mut (ref null $type145)) (ref.null none))
 (global $global714 (mut (ref null $type136)) (ref.null none))
 (global $global871 (mut (ref null $type190)) (ref.null none))
 (global $global1228 (mut (ref null $type69)) (ref.null none))
 (global $global1578 (mut (ref null $type262)) (ref.null none))
 (global $global1618 (mut (ref null $type268)) (ref.null none))
 (global $global128 (mut (ref null $type78)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global385 (mut (ref null $type138)) (ref.null none))
 (global $global417 (mut (ref null $type129)) (ref.null none))
 (global $global442 (mut (ref null $type143)) (ref.null none))
 (global $global481 (mut (ref null $type146)) (ref.null none))
 (global $global849 (mut (ref null $type186)) (ref.null none))
 (global $global1690 (mut (ref null $type274)) (ref.null none))
 (global $global1681 (mut (ref null $type275)) (ref.null none))
 (global $global1734 (mut (ref null $type306)) (ref.null none))
 (global $global1836 (mut (ref null $type83)) (ref.null none))
 (global $global86 (mut (ref null $type59)) (ref.null none))
 (global $global88 (mut (ref null $type60)) (ref.null none))
 (global $global96 (mut (ref null $type63)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type75)) (ref.null none))
 (global $global131 (mut (ref null $type77)) (ref.null none))
 (global $global133 (mut (ref null $type84)) (ref.null none))
 (global $global137 (mut (ref null $type85)) (ref.null none))
 (global $global376 (mut (ref null $type137)) (ref.null none))
 (global $global429 (mut (ref null $type141)) (ref.null none))
 (global $global557 (mut (ref null $type143)) (ref.null none))
 (global $global606 (mut (ref null $type158)) (ref.null none))
 (global $global710 (mut (ref null $type137)) (ref.null none))
 (global $global781 (mut (ref null $type174)) (ref.null none))
 (global $global1154 (mut (ref null $type210)) (ref.null none))
 (global $global1166 (mut (ref null $type213)) (ref.null none))
 (global $global1206 (mut (ref null $type218)) (ref.null none))
 (global $global1229 (mut (ref null $type5)) (ref.null none))
 (global $global1594 (mut (ref null $type267)) (ref.null none))
 (global $global1688 (mut (ref null $type267)) (ref.null none))
 (global $global1624 (mut (ref null $type273)) (ref.null none))
 (global $global1698 (mut (ref null $type59)) (ref.null none))
 (global $ready1681 (mut i32) (i32.const 0))
 (global $global1610 (mut (ref null $type287)) (ref.null none))
 (global $ready1610 (mut i32) (i32.const 0))
 (global $global1619 (mut (ref null $type292)) (ref.null none))
 (global $ready1619 (mut i32) (i32.const 0))
 (global $global1648 (mut (ref null $type77)) (ref.null none))
 (global $global1645 (mut (ref null $type300)) (ref.null none))
 (global $ready1645 (mut i32) (i32.const 0))
 (global $global1641 (mut (ref null $type115)) (ref.null none))
 (global $global1638 (mut (ref null $type267)) (ref.null none))
 (global $global1635 (mut (ref null $type301)) (ref.null none))
 (global $global1630 (mut (ref null $type302)) (ref.null none))
 (global $ready1630 (mut i32) (i32.const 0))
 (global $ready1734 (mut i32) (i32.const 0))
 (global $global1757 (mut (ref null $type313)) (ref.null none))
 (global $ready1757 (mut i32) (i32.const 0))
 (global $global1803 (mut (ref null $type315)) (ref.null none))
 (global $global1843 (mut (ref null $type317)) (ref.null none))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 58)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 117)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 32)
   (i32.const 118)
   (i32.const 105)
   (i32.const 101)
   (i32.const 119)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 104)
   (i32.const 97)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $global1430 (mut (ref null $type46)) (ref.null none))
 (global $global1433 (mut (ref null $type50)) (ref.null none))
 (global $ready1433 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type62)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type73)) (ref.null none))
 (global $global120 (mut (ref null $type72)) (ref.null none))
 (global $global122 (mut (ref null $type74)) (ref.null none))
 (global $global126 (mut (ref null $type76)) (ref.null none))
 (global $global1813 (mut (ref null $type79)) (ref.null none))
 (global $global1818 (mut (ref null $type80)) (ref.null none))
 (global $global1837 (mut (ref null $type81)) (ref.null none))
 (global $ready1837 (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type86)) (ref.null none))
 (global $global176 (mut (ref null $type100)) (ref.null none))
 (global $global199 (mut (ref null $type104)) (ref.null none))
 (global $global345 (mut (ref null $type132)) (ref.null none))
 (global $global363 (mut (ref null $type115)) (ref.null none))
 (global $global402 (mut (ref null $type140)) (ref.null none))
 (global $global405 (mut (ref null $type140)) (ref.null none))
 (global $global408 (mut (ref null $type140)) (ref.null none))
 (global $global414 (mut (ref null $type140)) (ref.null none))
 (global $global420 (mut (ref null $type141)) (ref.null none))
 (global $global438 (mut (ref null $type142)) (ref.null none))
 (global $global452 (mut (ref null $type144)) (ref.null none))
 (global $global463 (mut (ref null $type141)) (ref.null none))
 (global $global489 (mut (ref null $type146)) (ref.null none))
 (global $global501 (mut (ref null $type147)) (ref.null none))
 (global $global513 (mut (ref null $type148)) (ref.null none))
 (global $global522 (mut (ref null $type146)) (ref.null none))
 (global $global527 (mut (ref null $type149)) (ref.null none))
 (global $global533 (mut (ref null $type150)) (ref.null none))
 (global $global542 (mut (ref null $type152)) (ref.null none))
 (global $global563 (mut (ref null $type123)) (ref.null none))
 (global $global571 (mut (ref null $type153)) (ref.null none))
 (global $global577 (mut (ref null $type154)) (ref.null none))
 (global $global588 (mut (ref null $type155)) (ref.null none))
 (global $global593 (mut (ref null $type156)) (ref.null none))
 (global $global598 (mut (ref null $type157)) (ref.null none))
 (global $global652 (mut (ref null $type135)) (ref.null none))
 (global $global670 (mut (ref null $type115)) (ref.null none))
 (global $global716 (mut (ref null $type169)) (ref.null none))
 (global $global725 (mut (ref null $type170)) (ref.null none))
 (global $global729 (mut (ref null $type139)) (ref.null none))
 (global $global736 (mut (ref null $type171)) (ref.null none))
 (global $global741 (mut (ref null $type172)) (ref.null none))
 (global $global752 (mut (ref null $type134)) (ref.null none))
 (global $global754 (mut (ref null $type143)) (ref.null none))
 (global $global780 (mut (ref null $type28)) (ref.null none))
 (global $global790 (mut (ref null $type176)) (ref.null none))
 (global $global847 (mut (ref null $type185)) (ref.null none))
 (global $global883 (mut (ref null $type192)) (ref.null none))
 (global $global886 (mut (ref null $type192)) (ref.null none))
 (global $global1174 (mut (ref null $type214)) (ref.null none))
 (global $global1193 (mut (ref null $type217)) (ref.null none))
 (global $global1199 (mut (ref null $type218)) (ref.null none))
 (global $global1209 (mut (ref null $type223)) (ref.null none))
 (global $global1215 (mut (ref null $type224)) (ref.null none))
 (global $global1217 (mut (ref null $type225)) (ref.null none))
 (global $global1224 (mut (ref null $type230)) (ref.null none))
 (global $global1234 (mut (ref null $type232)) (ref.null none))
 (global $global1249 (mut (ref null $type236)) (ref.null none))
 (global $global1263 (mut (ref null $type237)) (ref.null none))
 (global $global1661 (mut (ref null $type272)) (ref.null none))
 (global $ready1661 (mut i32) (i32.const 0))
 (global $global1676 (mut (ref null $type276)) (ref.null none))
 (global $global1602 (mut (ref null $type285)) (ref.null none))
 (global $ready1602 (mut i32) (i32.const 0))
 (global $global1673 (mut (ref null $type276)) (ref.null none))
 (global $ready1673 (mut i32) (i32.const 0))
 (global $global1714 (mut (ref null $type276)) (ref.null none))
 (global $ready1714 (mut i32) (i32.const 0))
 (global $global1716 (mut (ref null $type286)) (ref.null none))
 (global $ready1716 (mut i32) (i32.const 0))
 (global $global1722 (mut (ref null $type286)) (ref.null none))
 (global $ready1722 (mut i32) (i32.const 0))
 (global $global1615 (mut (ref null $type288)) (ref.null none))
 (global $ready1615 (mut i32) (i32.const 0))
 (global $global1667 (mut (ref null $type293)) (ref.null none))
 (global $ready1667 (mut i32) (i32.const 0))
 (global $global1650 (mut (ref null $type294)) (ref.null none))
 (global $ready1650 (mut i32) (i32.const 0))
 (global $global1626 (mut (ref null $type299)) (ref.null none))
 (global $ready1626 (mut i32) (i32.const 0))
 (global $global1643 (mut (ref null $type267)) (ref.null none))
 (global $ready1643 (mut i32) (i32.const 0))
 (global $ready1648 (mut i32) (i32.const 0))
 (global $global1706 (mut (ref null $type303)) (ref.null none))
 (global $global1685 (mut (ref null $type276)) (ref.null none))
 (global $ready1685 (mut i32) (i32.const 0))
 (global $global1695 (mut (ref null $type286)) (ref.null none))
 (global $ready1695 (mut i32) (i32.const 0))
 (global $global1704 (mut (ref null $type303)) (ref.null none))
 (global $ready1704 (mut i32) (i32.const 0))
 (global $global1794 (mut (ref null $type305)) (ref.null none))
 (global $ready1794 (mut i32) (i32.const 0))
 (global $global1784 (mut (ref null $type307)) (ref.null none))
 (global $ready1784 (mut i32) (i32.const 0))
 (global $global1770 (mut (ref null $type308)) (ref.null none))
 (global $ready1770 (mut i32) (i32.const 0))
 (global $global1746 (mut (ref null $type310)) (ref.null none))
 (global $global1740 (mut (ref null $type311)) (ref.null none))
 (global $ready1740 (mut i32) (i32.const 0))
 (global $global1751 (mut (ref null $type312)) (ref.null none))
 (global $ready1751 (mut i32) (i32.const 0))
 (global $global1762 (mut (ref null $type236)) (ref.null none))
 (global $ready1803 (mut i32) (i32.const 0))
 (global $global1808 (mut (ref null $type316)) (ref.null none))
 (global $global1823 (mut (ref null $type236)) (ref.null none))
 (global $global1831 (mut (ref null $type82)) (ref.null none))
 (global $global1842 (mut (ref null $type5)) (ref.null none))
 (global $ready1842 (mut i32) (i32.const 0))
 (global $global1846 (mut (ref null $type115)) (ref.null none))
 (global $ready1846 (mut i32) (i32.const 0))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 43)
  (array.new_fixed $type19 43
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 120)
   (i32.const 105)
   (i32.const 115)
   (i32.const 32)
   (i32.const 112)
   (i32.const 111)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 115)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string52 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string55 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string56 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string57 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string58 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string59 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string60 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string61 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string62 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string63 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string64 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string65 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string66 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string67 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string68 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string69 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string70 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string71 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string72 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string73 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string74 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string75 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string76 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string77 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string78 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 18)
  (array.new_fixed $type19 18
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 116)
   (i32.const 32)
   (i32.const 73)
   (i32.const 54)
   (i32.const 52)
  )
  (ref.null none)
 ))
 (global $string79 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $empty220 (ref $type220) (struct.new $type220
  (i32.const 0)
 ))
 (global $empty227 (ref $type227) (struct.new $type227
  (i32.const 0)
 ))
 (global $empty279 (ref $type279) (struct.new $type279
  (i32.const 1)
 ))
 (global $empty280 (ref $type280) (struct.new $type280
  (i32.const 2)
 ))
 (global $empty281 (ref $type281) (struct.new $type281
  (i32.const 3)
 ))
 (global $empty297 (ref $type297) (struct.new $type297
  (i32.const 1)
 ))
 (export "bench" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $123) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-copy (type $121) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call60) (param $0 (ref $type61)) (result (ref $type18))
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref null $type61))
  (local $5 (ref null $type61))
  (local $6 (ref $type18))
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (local.set $4
   (struct.get $type61 1
    (local.get $0)
   )
  )
  (local.set $1
   (if (result i64)
    (i64.gt_u
     (local.tee $1
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type61 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (local.get $1)
      )
      (else
       (local.set $5
        (struct.get $type61 1
         (local.get $4)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $2
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type61 0
              (local.get $4)
             )
            )
           )
           (local.get $1)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $5)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type61 1
             (local.get $5)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $2)
               (local.tee $1
                (i64.add
                 (local.tee $3
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (struct.get $type61 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
              (i64.xor
               (local.get $1)
               (local.get $3)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.get $1)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $5
                (struct.get $type61 1
                 (local.get $4)
                )
               )
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.get $1)
                   (local.tee $2
                    (i64.add
                     (local.tee $3
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (struct.get $type61 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (i64.xor
                   (local.get $2)
                   (local.get $3)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.get $2)
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $5)
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $4
                    (struct.get $type61 1
                     (local.get $5)
                    )
                   )
                   (if
                    (i64.lt_s
                     (i64.and
                      (i64.xor
                       (local.get $2)
                       (local.tee $1
                        (i64.add
                         (local.tee $3
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (struct.get $type61 0
                             (local.get $5)
                            )
                           )
                          )
                         )
                         (local.get $2)
                        )
                       )
                      )
                      (i64.xor
                       (local.get $1)
                       (local.get $3)
                      )
                     )
                     (i64.const 0)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.get $1)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (local.set $5
                        (struct.get $type61 1
                         (local.get $4)
                        )
                       )
                       (if
                        (i64.lt_s
                         (i64.and
                          (i64.xor
                           (local.get $1)
                           (local.tee $2
                            (i64.add
                             (local.tee $3
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (struct.get $type61 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (i64.xor
                           (local.get $2)
                           (local.get $3)
                          )
                         )
                         (i64.const 0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.get $2)
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $5)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (local.set $4
                            (struct.get $type61 1
                             (local.get $5)
                            )
                           )
                           (if
                            (i64.lt_s
                             (i64.and
                              (i64.xor
                               (local.get $2)
                               (local.tee $1
                                (i64.add
                                 (local.tee $3
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (struct.get $type61 0
                                     (local.get $5)
                                    )
                                   )
                                  )
                                 )
                                 (local.get $2)
                                )
                               )
                              )
                              (i64.xor
                               (local.get $1)
                               (local.get $3)
                              )
                             )
                             (i64.const 0)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.get $1)
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $1)
                              )
                              (else
                               (local.set $5
                                (struct.get $type61 1
                                 (local.get $4)
                                )
                               )
                               (if
                                (i64.lt_s
                                 (i64.and
                                  (i64.xor
                                   (local.get $1)
                                   (local.tee $2
                                    (i64.add
                                     (local.tee $3
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (struct.get $type61 0
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (i64.xor
                                   (local.get $2)
                                   (local.get $3)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.get $2)
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $5)
                                  )
                                  (then
                                   (local.get $2)
                                  )
                                  (else
                                   (local.set $4
                                    (struct.get $type61 1
                                     (local.get $5)
                                    )
                                   )
                                   (if
                                    (i64.lt_s
                                     (i64.and
                                      (i64.xor
                                       (local.get $2)
                                       (local.tee $1
                                        (i64.add
                                         (local.tee $3
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (struct.get $type61 0
                                             (local.get $5)
                                            )
                                           )
                                          )
                                         )
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.xor
                                       (local.get $1)
                                       (local.get $3)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.get $1)
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $4)
                                      )
                                      (then
                                       (local.get $1)
                                      )
                                      (else
                                       (local.set $5
                                        (struct.get $type61 1
                                         (local.get $4)
                                        )
                                       )
                                       (if
                                        (i64.lt_s
                                         (i64.and
                                          (i64.xor
                                           (local.get $1)
                                           (local.tee $2
                                            (i64.add
                                             (local.tee $3
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (struct.get $type61 0
                                                 (local.get $4)
                                                )
                                               )
                                              )
                                             )
                                             (local.get $1)
                                            )
                                           )
                                          )
                                          (i64.xor
                                           (local.get $2)
                                           (local.get $3)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.get $2)
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $5)
                                          )
                                          (then
                                           (local.get $2)
                                          )
                                          (else
                                           (local.set $4
                                            (struct.get $type61 1
                                             (local.get $5)
                                            )
                                           )
                                           (if
                                            (i64.lt_s
                                             (i64.and
                                              (i64.xor
                                               (local.get $2)
                                               (local.tee $1
                                                (i64.add
                                                 (local.tee $3
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (struct.get $type61 0
                                                     (local.get $5)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (local.get $2)
                                                )
                                               )
                                              )
                                              (i64.xor
                                               (local.get $1)
                                               (local.get $3)
                                              )
                                             )
                                             (i64.const 0)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.get $1)
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $4)
                                              )
                                              (then
                                               (local.get $1)
                                              )
                                              (else
                                               (local.set $5
                                                (struct.get $type61 1
                                                 (local.get $4)
                                                )
                                               )
                                               (if
                                                (i64.lt_s
                                                 (i64.and
                                                  (i64.xor
                                                   (local.get $1)
                                                   (local.tee $2
                                                    (i64.add
                                                     (local.tee $3
                                                      (i64.extend_i32_u
                                                       (struct.get $type18 1
                                                        (struct.get $type61 0
                                                         (local.get $4)
                                                        )
                                                       )
                                                      )
                                                     )
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                  (i64.xor
                                                   (local.get $2)
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (i64.const 0)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.get $2)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $5)
                                                  )
                                                  (then
                                                   (local.get $2)
                                                  )
                                                  (else
                                                   (local.set $4
                                                    (struct.get $type61 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                   (if
                                                    (i64.lt_s
                                                     (i64.and
                                                      (i64.xor
                                                       (local.get $2)
                                                       (local.tee $1
                                                        (i64.add
                                                         (local.tee $3
                                                          (i64.extend_i32_u
                                                           (struct.get $type18 1
                                                            (struct.get $type61 0
                                                             (local.get $5)
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (local.get $2)
                                                        )
                                                       )
                                                      )
                                                      (i64.xor
                                                       (local.get $1)
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (i64.const 0)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.get $1)
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $4)
                                                      )
                                                      (then
                                                       (local.get $1)
                                                      )
                                                      (else
                                                       (local.set $5
                                                        (struct.get $type61 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (if
                                                        (i64.lt_s
                                                         (i64.and
                                                          (i64.xor
                                                           (local.get $1)
                                                           (local.tee $2
                                                            (i64.add
                                                             (local.tee $3
                                                              (i64.extend_i32_u
                                                               (struct.get $type18 1
                                                                (struct.get $type61 0
                                                                 (local.get $4)
                                                                )
                                                               )
                                                              )
                                                             )
                                                             (local.get $1)
                                                            )
                                                           )
                                                          )
                                                          (i64.xor
                                                           (local.get $2)
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (i64.const 0)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                       )
                                                       (call $function37
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (local.get $5)
                                                        (local.get $2)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (call $string-new
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (drop
   (call $function38
    (local.get $6)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $6)
 )
 (func $function37 (type $118) (param $0 i32) (param $1 i32) (param $2 (ref null $type61)) (param $3 i64) (result i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref null $type61))
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $6
       (struct.get $type61 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.tee $5
             (i64.extend_i32_u
              (struct.get $type18 1
               (struct.get $type61 0
                (local.get $2)
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call63) (param $0 (ref $type18)) (param $1 (ref null $type61)) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 (ref $type18))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $5
      (struct.get $type61 0
       (local.get $1)
      )
     )
     (local.tee $3
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $5)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type61 1
      (local.get $1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $4
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (local.get $4)
    )
   )
  )
 )
 (func $function40 (type $116) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function45 (type $115) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (local $7 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (if (result (ref $type19))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type18 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type20
          (struct.get $type18 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
    )
   )
  )
 )
 (func $function54 (type $call85) (param $0 i64) (result i32)
  (local $1 i64)
  (if (result i32)
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (if (result i32)
     (i64.eq
      (local.get $0)
      (i64.const -1)
     )
     (then
      (i32.const -1)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (i64.const -2)
            (local.get $0)
           )
          )
          (i64.const -2)
         )
         (i64.xor
          (local.get $0)
          (i64.const -2)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $1)
        (i64.extend32_s
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
   (else
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $0
        (i64.sub
         (i64.and
          (local.get $0)
          (i64.const 255)
         )
         (i64.const 1)
        )
       )
      )
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $0)
    )
   )
  )
 )
 (func $function55 (type $call86) (param $0 (ref $type68)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type69))
  (if (result i32)
   (i32.lt_s
    (local.tee $2
     (struct.get $type66 0
      (struct.get $type68 0
       (local.get $0)
      )
     )
    )
    (i32.const 0)
   )
   (then
    (call $foreign8
     (local.get $2)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (struct.set $type69 0
     (local.tee $3
      (struct.get $type68 1
       (local.get $0)
      )
     )
     (block (result i64)
      (if
       (i64.eqz
        (local.tee $1
         (struct.get $type69 0
          (local.get $3)
         )
        )
       )
       (then
        (struct.set $type69 0
         (local.get $3)
         (local.tee $1
          (call $foreign7
           (struct.get $type66 0
            (struct.get $type68 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (select
       (i64.shr_u
        (local.get $1)
        (i64.const 8)
       )
       (i64.const 0)
       (i64.gt_s
        (local.get $1)
        (i64.const 0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global137)
     )
    )
    (return_call $function54
     (local.get $1)
    )
   )
  )
 )
 (func $function59 (type $call92) (param $0 (ref $type68)) (result (ref $type88))
  (local $1 i64)
  (local $2 i32)
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $2
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if (result (ref $type88))
   (i32.eq
    (local.get $2)
    (i32.const -1)
   )
   (then
    (global.get $empty89)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $1
       (i64.extend_i32_s
        (local.get $2)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $1)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $1)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type90
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function60 (type $call92) (param $0 (ref $type68)) (result (ref $type88))
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type69))
  (drop
   (ref.as_non_null
    (global.get $global143)
   )
  )
  (local.set $2
   (if (result i32)
    (i32.lt_s
     (local.tee $2
      (struct.get $type66 0
       (struct.get $type68 0
        (local.get $0)
       )
      )
     )
     (i32.const 0)
    )
    (then
     (call $foreign9
      (local.get $2)
     )
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global133)
      )
     )
     (if
      (i64.eqz
       (local.tee $1
        (struct.get $type69 0
         (local.tee $3
          (struct.get $type68 1
           (local.get $0)
          )
         )
        )
       )
      )
      (then
       (struct.set $type69 0
        (local.get $3)
        (local.tee $1
         (call $foreign7
          (struct.get $type66 0
           (struct.get $type68 0
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (call $function54
      (local.get $1)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if (result (ref $type88))
   (i32.eq
    (local.get $2)
    (i32.const -1)
   )
   (then
    (global.get $empty89)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $1
       (i64.extend_i32_s
        (local.get $2)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $1)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $1)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type90
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function118 (type $108) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $4
          (i64.sub
           (local.get $3)
           (i64.const 1)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global336)
      )
     )
     (if
      (i64.gt_u
       (local.get $4)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $4
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function118
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function119 (type $call52) (param $0 (ref $type29)) (result (ref $type29))
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global345)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.tee $1
     (call $function118
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (local.tee $2
       (i64.extend_i32_u
        (array.len
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $2)
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type29 $type29
     (local.tee $4
      (array.new_default $type29
       (local.tee $3
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (i32.const 0)
     (local.get $0)
     (i32.const 0)
     (local.get $3)
    )
    (local.get $4)
   )
  )
 )
 (func $function121 (type $call134) (param $0 (ref $type28)) (result i32)
  (i64.eqz
   (i64.extend_i32_u
    (array.len
     (struct.get $type28 1
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function124 (type $call115) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function125
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function125 (type $103) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function125
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 1073741824)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function126 (type $call136) (param $0 i64) (result (ref $type28))
  (local $1 i64)
  (local $2 i32)
  (return_call $function127
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (block (result i32)
    (drop
     (ref.as_non_null
      (global.get $global363)
     )
    )
    (if
     (i64.gt_s
      (local.get $0)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $0)
         (local.tee $1
          (i64.sub
           (i64.const 0)
           (local.get $0)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $0
       (local.get $1)
      )
     )
    )
    (local.set $1
     (call $function124
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (i32.const 1)
   )
   (array.new_default $type29
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (i32.const 1)
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (i64.const 0)
  )
 )
 (func $function127 (type $101) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type28))
  (local $8 i64)
  (local $9 i64)
  (if (result (ref $type28))
   (i64.eqz
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global349)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function119
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global335)
      )
     )
     (else
      (struct.new $type28
       (local.get $0)
       (local.get $2)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (local.tee $8
        (i64.sub
         (i64.const 0)
         (local.tee $9
          (i64.rem_s
           (local.get $6)
           (i64.const 1073741824)
          )
         )
        )
       )
       (local.get $9)
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (local.get $8)
      (i64.extend32_s
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $2)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function127
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 1073741824)
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function129 (type $100) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i64)
  (local $10 i64)
  (local $11 i64)
  (if (result i64)
   (i64.eqz
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (local.get $2)
     (then
      (local.get $9)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (local.get $9)
         (local.tee $4
          (i64.sub
           (i64.const 0)
           (local.get $9)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $4)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.sub
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $10)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.extend_i32_s
      (array.get $type29
       (local.get $0)
       (i32.wrap_i64
        (local.get $10)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.add
          (local.get $4)
          (local.get $10)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (i64.div_s
       (local.get $11)
       (i64.const 1073741824)
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $11
           (i64.sub
            (local.get $8)
            (i64.const 1)
           )
          )
          (local.get $8)
         )
         (i64.xor
          (local.get $8)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (i64.div_s
         (local.tee $8
          (i64.shl
           (local.get $9)
           (i64.const 30)
          )
         )
         (i64.const 1073741824)
        )
        (local.get $9)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $9
           (i64.sub
            (local.get $8)
            (local.get $10)
           )
          )
          (local.get $8)
         )
         (i64.xor
          (local.get $8)
          (local.get $10)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $7)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function129
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (local.get $7)
       (local.get $11)
       (local.get $9)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function131 (type $99) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (if (result i64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.extend_i32_s
      (array.get $type29
       (local.get $0)
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (local.get $5)
     )
     (then
      (i64.const -1)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.get $5)
        (local.get $6)
       )
       (then
        (i64.const 1)
       )
       (else
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $4)
              (i64.const 1)
             )
            )
            (local.get $4)
           )
           (i64.xor
            (local.get $4)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function131
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (local.get $5)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function132 (type $call139) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (i32.ne
      (local.tee $4
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (struct.get $type28 0
       (local.get $1)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global385)
     )
    )
    (local.set $2
     (if (result i64)
      (i64.lt_s
       (local.tee $2
        (i64.extend_i32_u
         (array.len
          (local.tee $5
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
       )
       (local.tee $3
        (i64.extend_i32_u
         (array.len
          (local.tee $6
           (struct.get $type28 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (if (result i64)
        (i64.gt_s
         (local.get $2)
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (call $function131
          (local.get $5)
          (local.get $6)
          (i32.const 0)
          (i32.const 1)
          (local.get $2)
         )
        )
       )
      )
     )
    )
    (if (result i64)
     (local.get $4)
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $2)
         (local.tee $3
          (i64.sub
           (i64.const 0)
           (local.get $2)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $3)
     )
     (else
      (local.get $2)
     )
    )
   )
   (else
    (select
     (i64.const -1)
     (i64.const 1)
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function140 (type $97) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (if (result i64)
          (i64.gt_s
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (local.get $8)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global336)
            )
           )
           (if
            (i64.gt_u
             (local.get $8)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i64.extend_i32_s
            (array.get $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $8)
             )
            )
           )
          )
          (else
           (i64.const 0)
          )
         )
        )
        (local.tee $10
         (i64.add
          (local.tee $11
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global336)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type29
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $11)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function140
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $11)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function142 (type $97) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
        )
        (local.tee $11
         (i64.sub
          (local.get $10)
          (local.tee $12
           (if (result i64)
            (i64.gt_s
             (i64.extend_i32_u
              (array.len
               (local.get $1)
              )
             )
             (local.get $8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global336)
              )
             )
             (if
              (i64.gt_u
               (local.get $8)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.extend_i32_s
              (array.get $type29
               (local.get $1)
               (i32.wrap_i64
                (local.get $8)
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $10
         (i64.sub
          (local.get $11)
          (local.get $9)
         )
        )
        (local.get $11)
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (if (result i64)
         (i64.lt_s
          (local.get $10)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.get $10)
              (local.tee $9
               (i64.add
                (local.get $10)
                (i64.const 1073741824)
               )
              )
             )
             (i64.xor
              (local.get $9)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $9)
         )
         (else
          (local.get $10)
         )
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function142
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.extend_i32_u
      (i64.lt_s
       (local.get $10)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function144 (type $96) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $scratch (ref $type29))
  (local $scratch_8 (ref $type29))
  (local $scratch_9 (ref $type29))
  (local.set $2
   (struct.get $type28 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type28 1
    (local.get $1)
   )
  )
  (if (result (ref $type28))
   (select
    (local.tee $6
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (i32.eqz
     (local.get $6)
    )
    (local.tee $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global420)
     )
    )
    (local.set $4
     (i64.add
      (local.tee $5
       (select
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
        (i64.gt_s
         (local.get $4)
         (local.get $5)
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.get $5)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function119
          (block (result (ref $type29))
           (local.set $scratch
            (call $function140
             (local.get $2)
             (local.get $3)
             (local.get $5)
             (i32.const 1)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global353)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global349)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global335)
      )
     )
     (else
      (struct.new $type28
       (local.get $6)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global438)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global385)
     )
    )
    (if (result (ref $type28))
     (i64.lt_s
      (if (result i64)
       (i64.lt_s
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.get $4)
          (local.get $5)
         )
         (then
          (i64.const 1)
         )
         (else
          (call $function131
           (local.get $2)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (local.get $4)
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global429)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global343)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function119
            (block (result (ref $type29))
             (local.set $scratch_8
              (call $function142
               (local.get $3)
               (local.get $2)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global353)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global349)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global335)
        )
       )
       (else
        (struct.new $type28
         (i32.eqz
          (local.get $6)
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global429)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global343)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function119
            (block (result (ref $type29))
             (local.set $scratch_9
              (call $function142
               (local.get $2)
               (local.get $3)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i32.const 1)
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global353)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global349)
              )
             )
             (local.get $scratch_9)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global335)
        )
       )
       (else
        (struct.new $type28
         (local.get $6)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function147 (type $95) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $10)
          (local.tee $13
           (i64.extend_i32_s
            (array.get $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $12)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $11)
        (local.get $13)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function147
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function149 (type $94) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type29))
  (local $7 i64)
  (if (result (ref $type29))
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $6)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global452)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function147
      (local.get $2)
      (local.get $1)
      (local.get $6)
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $6)
        (local.tee $7
         (i64.add
          (local.get $6)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $7)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function149
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $7)
    )
   )
  )
 )
 (func $function150 (type $96) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i32)
  (local $5 i64)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 1
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global357)
      )
     )
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global335)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global463)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type28 1
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function119
          (block (result (ref $type29))
           (local.set $scratch
            (call $function149
             (local.get $2)
             (local.get $3)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $5)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global353)
            )
           )
           (local.set $4
            (select
             (i32.eqz
              (local.tee $4
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
             (local.get $4)
             (struct.get $type28 0
              (local.get $0)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global349)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global335)
      )
     )
     (else
      (struct.new $type28
       (local.get $4)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function152 (type $93) (param $0 (ref $type29)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 (ref $type29)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result (ref $type29))
  (local $10 i64)
  (local $11 i64)
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.mul
      (local.get $1)
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $11)
         (local.get $1)
        )
        (local.get $10)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $11)
        (local.tee $10
         (i64.add
          (local.get $9)
          (local.get $11)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $4)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $9
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function152
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $9)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function154 (type $92) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (local.get $6)
   )
   (else
    (if
     (i64.ne
      (i64.div_s
       (local.tee $7
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
       )
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $6
         (i64.add
          (local.get $7)
          (local.tee $8
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $8
        (i64.div_s
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (i64.rem_s
      (local.get $6)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function154
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $7)
     (local.get $5)
    )
   )
  )
 )
 (func $function156 (type $91) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i64) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i64) (param $10 i64) (result i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $10)
     (i64.const 1073741824)
    )
    (then
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.sub
           (local.get $3)
           (i64.const 2)
          )
         )
         (local.get $3)
        )
        (i64.xor
         (local.get $3)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global336)
      )
     )
     (if
      (i64.gt_u
       (local.get $11)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $13
      (i64.mul
       (local.tee $11
        (i64.extend_i32_s
         (array.get $type29
          (local.get $1)
          (i32.wrap_i64
           (local.get $11)
          )
         )
        )
       )
       (local.get $9)
      )
     )
     (if
      (i64.ne
       (local.get $11)
       (i64.const 0)
      )
      (then
       (if
        (i64.ne
         (i64.div_s
          (local.get $13)
          (local.get $11)
         )
         (local.get $9)
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (if
      (i64.ne
       (i64.div_s
        (local.tee $14
         (i64.shl
          (local.get $10)
          (i64.const 30)
         )
        )
        (i64.const 1073741824)
       )
       (local.get $10)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $11
          (i64.add
           (local.get $2)
           (local.get $3)
          )
         )
         (local.get $2)
        )
        (i64.xor
         (local.get $3)
         (local.get $11)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.tee $12
          (i64.sub
           (local.get $11)
           (i64.const 2)
          )
         )
         (local.get $11)
        )
        (i64.xor
         (local.get $11)
         (i64.const 2)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global336)
      )
     )
     (if
      (i64.gt_u
       (local.get $12)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.lt_s
       (i64.and
        (i64.xor
         (local.get $14)
         (local.tee $11
          (i64.add
           (local.get $14)
           (local.tee $12
            (i64.extend_i32_s
             (array.get $type29
              (local.get $0)
              (i32.wrap_i64
               (local.get $12)
              )
             )
            )
           )
          )
         )
        )
        (i64.xor
         (local.get $11)
         (local.get $12)
        )
       )
       (i64.const 0)
      )
      (then
       (unreachable)
      )
     )
     (i64.lt_s
      (local.get $11)
      (local.get $13)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $11
         (i64.sub
          (local.get $9)
          (i64.const 1)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $5)
          (local.get $10)
         )
        )
        (local.get $10)
       )
       (i64.xor
        (local.get $5)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function156
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $11)
     (local.get $9)
    )
   )
   (else
    (local.get $9)
   )
  )
 )
 (func $function158 (type $95) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i64) (param $9 i64) (result i32)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $5)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $8)
   )
   (then
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $3
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $4)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.sub
      (local.tee $8
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
      )
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.get $3)
       (i64.const -1)
      )
      (i64.gt_s
       (local.get $3)
       (i64.const 0)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $4)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (if (result i64)
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.add
                (local.get $3)
                (i64.const 1073741824)
               )
              )
              (local.get $3)
             )
             (i64.xor
              (local.get $2)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $2)
         )
         (else
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i64.lt_s
     (local.get $3)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.mul
      (local.tee $11
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $10)
         (local.get $11)
        )
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $10)
        (local.tee $11
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $11)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.sub
      (local.tee $10
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
      (local.tee $12
       (i64.and
        (local.get $11)
        (i64.const 1073741823)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
       (i64.xor
        (local.get $10)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $12
         (i64.add
          (local.get $2)
          (local.get $8)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $8)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $10
        (if (result i64)
         (i64.lt_s
          (local.get $9)
          (i64.const 0)
         )
         (then
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $10
               (i64.add
                (local.get $9)
                (i64.const 1073741824)
               )
              )
              (local.get $9)
             )
             (i64.xor
              (local.get $10)
              (i64.const 1073741824)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (local.get $10)
         )
         (else
          (local.get $9)
         )
        )
       )
      )
      (local.get $10)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (i32.wrap_i64
      (local.get $10)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $8)
        (local.tee $10
         (i64.add
          (local.get $8)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $7)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function158
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $10)
     (i64.add
      (i64.extend_i32_u
       (i64.lt_s
        (local.get $9)
        (i64.const 0)
       )
      )
      (i64.shr_u
       (local.get $11)
       (i64.const 30)
      )
     )
    )
   )
  )
 )
 (func $function160 (type $90) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $7
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $3)
        (local.get $7)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i64.xor
        (local.get $3)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (i64.add
      (local.get $8)
      (local.tee $3
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $2)
        (local.get $3)
       )
       (i64.xor
        (local.get $2)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $2
        (i64.rem_s
         (local.get $2)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $9)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
        )
        (local.tee $9
         (i64.add
          (local.get $9)
          (local.tee $10
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $7)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $9)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $10
         (i64.add
          (local.get $8)
          (local.get $9)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $2)
          (local.get $7)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $7)
        (local.get $8)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (i64.extend32_s
       (local.tee $9
        (i64.rem_s
         (local.get $10)
         (i64.const 1073741824)
        )
       )
      )
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $8
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function160
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $8)
     (i64.div_s
      (local.get $10)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function163 (type $89) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $13
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global522)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global489)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.tee $6
       (i64.sub
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (i64.extend_i32_s
      (array.get $type29
       (local.get $2)
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $6)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.shl
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
      )
      (i64.const 30)
     )
    )
    (if
     (i64.ne
      (i64.div_s
       (local.get $7)
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $8
         (i64.add
          (local.get $9)
          (local.get $10)
         )
        )
        (local.get $9)
       )
       (i64.xor
        (local.get $8)
        (local.get $10)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $8)
          (i64.const 1)
         )
        )
        (local.get $8)
       )
       (i64.xor
        (local.get $8)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $12
         (i64.add
          (local.get $7)
          (local.tee $6
           (i64.extend_i32_s
            (array.get $type29
             (local.get $1)
             (i32.wrap_i64
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $6)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_s
      (local.tee $8
       (i64.div_s
        (local.get $12)
        (local.get $11)
       )
      )
      (i64.const 1073741824)
     )
     (then
      (local.set $8
       (i64.const 1073741823)
      )
     )
    )
    (local.set $7
     (i64.mul
      (local.get $8)
      (local.get $11)
     )
    )
    (if
     (i64.ne
      (local.get $11)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $7)
         (local.get $11)
        )
        (local.get $8)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $12)
          (local.get $7)
         )
        )
        (local.get $12)
       )
       (i64.xor
        (local.get $7)
        (local.get $12)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function156
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $10)
      (i32.const 1)
      (local.get $11)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (local.get $8)
      (local.get $6)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global501)
     )
    )
    (if
     (call $function158
      (local.get $1)
      (local.get $2)
      (local.get $9)
      (local.get $7)
      (local.tee $6
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global513)
       )
      )
      (drop
       (call $function160
        (local.get $1)
        (local.get $2)
        (local.get $9)
        (local.get $6)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
        (i64.const 0)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.sub
            (local.get $7)
            (i64.const 1)
           )
          )
          (local.get $7)
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (local.get $6)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global339)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.extend32_s
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $13)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $13)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function163
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function166 (type $88) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type151))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type151))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i32)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result (ref $type151))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global542)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global385)
     )
    )
    (local.set $7
     (struct.get $type151 0
      (local.tee $9
       (if (result (ref $type151))
        (i64.lt_s
         (if (result i64)
          (i64.lt_s
           (local.tee $10
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (struct.get $type28 1
                (local.get $0)
               )
              )
             )
            )
           )
           (local.tee $11
            (i64.extend_i32_u
             (array.len
              (local.tee $3
               (struct.get $type28 1
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (if (result i64)
            (i64.gt_s
             (local.get $10)
             (local.get $11)
            )
            (then
             (i64.const 1)
            )
            (else
             (call $function131
              (local.get $2)
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $10)
             )
            )
           )
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global359)
          )
         )
         (struct.new $type151
          (ref.as_non_null
           (global.get $global335)
          )
          (if (result (ref $type28))
           (struct.get $type28 0
            (local.get $0)
           )
           (then
            (struct.new $type28
             (i32.const 0)
             (struct.get $type28 1
              (local.get $0)
             )
            )
           )
           (else
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type151))
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (i64.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global336)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global481)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (call $function154
             (local.tee $4
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
             (local.get $2)
             (i64.extend_i32_s
              (array.get $type29
               (local.get $3)
               (i32.const 0)
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global353)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global349)
            )
           )
           (struct.new $type151
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function119
                  (local.get $4)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global335)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global368)
              )
             )
             (call $function126
              (local.get $10)
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global533)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global336)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (i64.sub
               (local.tee $10
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $11
            (i64.add
             (local.tee $12
              (i64.extend_i32_s
               (array.get $type29
                (local.get $3)
                (i32.wrap_i64
                 (local.get $11)
                )
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.get $11)
               (local.get $12)
              )
              (i64.xor
               (local.get $11)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global472)
            )
           )
           (local.set $11
            (i64.div_s
             (i64.const 1073741824)
             (local.get $11)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (call $function152
             (local.get $2)
             (local.get $11)
             (local.get $12)
             (i32.const 1)
             (array.new_default $type29
              (i32.wrap_i64
               (local.get $13)
              )
             )
             (i32.const 1)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global472)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (if
            (i64.gt_u
             (local.tee $13
              (i64.add
               (local.tee $12
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (call $function119
             (block (result (ref $type29))
              (local.set $scratch
               (call $function152
                (local.get $3)
                (local.get $11)
                (local.get $12)
                (i32.const 1)
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $13)
                 )
                )
                (i32.const 1)
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global349)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (if
            (i64.lt_s
             (i64.and
              (i64.xor
               (local.tee $12
                (i64.add
                 (local.tee $13
                  (i64.sub
                   (i64.extend_i32_u
                    (array.len
                     (local.get $2)
                    )
                   )
                   (local.get $10)
                  )
                 )
                 (i64.const 1)
                )
               )
               (local.get $13)
              )
              (i64.xor
               (local.get $12)
               (i64.const 1)
              )
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (if
            (i64.gt_u
             (local.get $12)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global527)
            )
           )
           (drop
            (call $function163
             (local.tee $6
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $12)
               )
              )
             )
             (local.get $5)
             (local.get $3)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $6)
              )
             )
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.copy $type29 $type29
            (local.tee $4
             (array.new_default $type29
              (local.tee $14
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
            )
            (i32.const 0)
            (local.get $5)
            (i32.const 0)
            (local.get $14)
           )
           (drop
            (ref.as_non_null
             (global.get $global481)
            )
           )
           (if
            (i64.ne
             (call $function154
              (local.get $4)
              (local.get $4)
              (local.get $11)
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $4)
               )
              )
              (i64.const 0)
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global353)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global349)
            )
           )
           (struct.new $type151
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function119
                  (local.get $6)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global335)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global353)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global349)
              )
             )
             (if (result (ref $type28))
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.tee $2
                  (call $function119
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (then
               (ref.as_non_null
                (global.get $global335)
               )
              )
              (else
               (struct.new $type28
                (i32.const 0)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type151 1
      (local.get $9)
     )
    )
    (struct.new $type151
     (if (result (ref $type28))
      (select
       (i32.eqz
        (local.tee $14
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
       (local.get $14)
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global361)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global357)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $7)
           )
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $7)
           )
          )
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
       )
      )
      (else
       (local.get $7)
      )
     )
     (if (result (ref $type28))
      (struct.get $type28 0
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global361)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global357)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $8)
           )
          )
         )
        )
        (then
         (local.get $8)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $8)
           )
          )
          (struct.get $type28 1
           (local.get $8)
          )
         )
        )
       )
      )
      (else
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function168 (type $call143) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global551)
   )
  )
  (struct.get $type151 1
   (call $function166
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $function170 (type $85) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.or
      (i64.lt_s
       (local.tee $6
        (i64.sub
         (i64.extend_i32_u
          (array.get $type19
           (if (result (ref $type19))
            (i32.lt_u
             (local.tee $8
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type18 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type20
               (struct.get $type18 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $8)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $8)
            (i32.const 8191)
           )
          )
         )
         (i64.const 48)
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $6)
       (i64.const 9)
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $7
           (i64.add
            (local.get $4)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $7)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $5)
        (i64.div_s
         (local.tee $4
          (i64.mul
           (local.get $5)
           (i64.const 10)
          )
         )
         (i64.const 10)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $5
           (i64.add
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i64.xor
          (local.get $5)
          (local.get $6)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function170
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $7)
       (local.get $5)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function172 (type $84) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
    (if
     (i64.ne
      (local.get $0)
      (i64.const 0)
     )
     (then
      (if
       (i64.ne
        (i64.div_s
         (local.get $3)
         (local.get $0)
        )
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function172
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
     (local.get $3)
    )
   )
  )
 )
 (func $function174 (type $83) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 (ref $type28)) (result (ref $type28))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 (ref $type29))
  (local $13 (ref $type28))
  (local $scratch (ref $type29))
  (local $scratch_15 i64)
  (local $scratch_16 (ref $type28))
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global361)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global357)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
       )
       (then
        (local.get $7)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $7)
          )
         )
         (struct.get $type28 1
          (local.get $7)
         )
        )
       )
      )
     )
     (else
      (local.get $7)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.sub
          (local.get $2)
          (local.get $6)
         )
        )
        (local.get $2)
       )
       (i64.xor
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global571)
     )
    )
    (local.set $8
     (call $function172
      (i64.const 10)
      (i32.const 0)
      (i32.const 1)
      (local.tee $9
       (if (result i64)
        (i64.gt_s
         (local.get $9)
         (i64.const 9)
        )
        (then
         (i64.const 9)
        )
        (else
         (if
          (i32.eqz
           (local.get $3)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i64.lt_s
           (i64.and
            (i64.xor
             (local.tee $9
              (i64.sub
               (local.get $2)
               (local.get $6)
              )
             )
             (local.get $2)
            )
            (i64.xor
             (local.get $2)
             (local.get $6)
            )
           )
           (i64.const 0)
          )
          (then
           (unreachable)
          )
         )
         (local.get $9)
        )
       )
      )
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global472)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (i64.add
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.tee $12
            (struct.get $type28 1
             (local.get $7)
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call $function144
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $12
           (call $function119
            (block (result (ref $type29))
             (local.set $scratch
              (call $function152
               (local.get $12)
               (local.get $8)
               (local.get $10)
               (i32.const 1)
               (array.new_default $type29
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global353)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global349)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global335)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $12)
        )
       )
      )
      (block (result (ref $type28))
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
           (local.get $6)
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global563)
        )
       )
       (local.set $scratch_16
        (call $function126
         (block (result i64)
          (local.set $scratch_15
           (call $function170
            (local.get $0)
            (local.get $8)
            (i32.const 0)
            (i32.const 1)
            (local.get $6)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global368)
           )
          )
          (local.get $scratch_15)
         )
        )
       )
       (if
        (i64.lt_s
         (i64.and
          (i64.xor
           (local.get $6)
           (local.tee $8
            (i64.add
             (local.get $6)
             (local.get $9)
            )
           )
          )
          (i64.xor
           (local.get $8)
           (local.get $9)
          )
         )
         (i64.const 0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global442)
        )
       )
       (local.get $scratch_16)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function174
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $8)
     (local.get $7)
    )
   )
  )
 )
 (func $function178 (type $82) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type28)) (result (ref $type28))
  (local $7 (ref $type29))
  (local $8 (ref $type28))
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i32)
  (local $scratch (ref $type29))
  (local $scratch_14 (ref $type28))
  (if (result (ref $type28))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $5)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global361)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global357)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $6)
          )
         )
        )
       )
       (then
        (local.get $6)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $6)
          )
         )
         (struct.get $type28 1
          (local.get $6)
         )
        )
       )
      )
     )
     (else
      (local.get $6)
     )
    )
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $9
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
        (local.get $5)
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global472)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i64.gt_u
      (local.tee $11
       (i64.add
        (local.tee $10
         (i64.extend_i32_u
          (array.len
           (local.tee $7
            (struct.get $type28 1
             (local.get $6)
            )
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $function144
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $7
           (call $function119
            (block (result (ref $type29))
             (local.set $scratch
              (call $function152
               (local.get $7)
               (local.get $2)
               (local.get $10)
               (i32.const 1)
               (array.new_default $type29
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global353)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global349)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global335)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $7)
        )
       )
      )
      (block (result (ref $type28))
       (if
        (i64.ge_u
         (local.get $5)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global593)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global368)
        )
       )
       (local.set $scratch_14
        (call $function126
         (if (result i64)
          (if (result i32)
           (i64.lt_s
            (local.tee $5
             (if (result i64)
              (if (result i32)
               (i64.ge_u
                (local.tee $5
                 (i64.extend_i32_u
                  (array.get $type19
                   (if (result (ref $type19))
                    (i32.lt_u
                     (local.tee $12
                      (i32.wrap_i64
                       (local.get $5)
                      )
                     )
                     (i32.const 8192)
                    )
                    (then
                     (struct.get $type18 2
                      (local.get $0)
                     )
                    )
                    (else
                     (ref.as_non_null
                      (array.get $type20
                       (struct.get $type18 3
                        (local.get $0)
                       )
                       (i32.sub
                        (i32.shr_u
                         (local.get $12)
                         (i32.const 13)
                        )
                        (i32.const 1)
                       )
                      )
                     )
                    )
                   )
                   (i32.and
                    (local.get $12)
                    (i32.const 8191)
                   )
                  )
                 )
                )
                (i64.const 48)
               )
               (then
                (i64.le_u
                 (local.get $5)
                 (i64.const 57)
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (i64.sub
                (local.get $5)
                (i64.const 48)
               )
              )
              (else
               (if (result i64)
                (i32.and
                 (i64.le_u
                  (local.get $5)
                  (i64.const 90)
                 )
                 (i64.ge_u
                  (local.get $5)
                  (i64.const 65)
                 )
                )
                (then
                 (i64.sub
                  (local.get $5)
                  (i64.const 55)
                 )
                )
                (else
                 (select
                  (i64.sub
                   (local.get $5)
                   (i64.const 87)
                  )
                  (i64.const -1)
                  (i32.and
                   (i64.le_u
                    (local.get $5)
                    (i64.const 122)
                   )
                   (i64.ge_u
                    (local.get $5)
                    (i64.const 97)
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (i64.const 0)
           )
           (then
            (i32.const 1)
           )
           (else
            (i64.le_s
             (local.get $2)
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (local.get $5)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global442)
        )
       )
       (local.get $scratch_14)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function178
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $9)
     (local.get $6)
    )
   )
  )
 )
 (func $function179 (type $call158) (param $0 (ref $type18)) (param $1 i64) (result (ref $type28))
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (if
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (i64.const 2)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i64.eqz
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $0)
        )
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 36)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.eq
      (local.get $1)
      (i64.const 10)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global588)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global577)
         )
        )
        (if
         (i64.eq
          (local.tee $1
           (i64.extend_i32_u
            (i32.or
             (local.tee $3
              (i32.eq
               (local.tee $2
                (array.get $type19
                 (struct.get $type18 2
                  (local.get $0)
                 )
                 (i32.const 0)
                )
               )
               (i32.const 45)
              )
             )
             (i32.eq
              (local.get $2)
              (i32.const 43)
             )
            )
           )
          )
          (local.tee $4
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (unreachable)
         )
         (else
          (return_call $function174
           (local.get $0)
           (local.get $3)
           (local.get $4)
           (i32.const 1)
           (i32.const 0)
           (i32.const 1)
           (local.get $1)
           (ref.as_non_null
            (global.get $global335)
           )
          )
         )
        )
        (unreachable)
       )
      )
      (unreachable)
     )
     (else
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global598)
       )
      )
      (if
       (i64.eq
        (local.tee $4
         (i64.extend_i32_u
          (i32.or
           (local.tee $3
            (i32.eq
             (local.tee $2
              (array.get $type19
               (struct.get $type18 2
                (local.get $0)
               )
               (i32.const 0)
              )
             )
             (i32.const 45)
            )
           )
           (i32.eq
            (local.get $2)
            (i32.const 43)
           )
          )
         )
        )
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (return_call $function178
         (local.get $0)
         (local.get $3)
         (local.get $1)
         (i32.const 0)
         (i32.const 1)
         (local.get $4)
         (ref.as_non_null
          (global.get $global335)
         )
        )
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function193 (type $80) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (param $4 (ref $type28)) (result (ref $type28))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (i64.extend_i32_s
        (array.get $type29
         (struct.get $type28 1
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (i64.const 1)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global469)
       )
      )
      (local.set $4
       (call $function150
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global652)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global481)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (struct.get $type28 1
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function154
      (local.tee $6
       (array.new_default $type29
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $5)
      (i64.const 2)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $5)
       )
      )
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global349)
     )
    )
    (local.set $7
     (if (result (ref $type28))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (call $function119
           (local.get $6)
          )
         )
        )
       )
      )
      (then
       (ref.as_non_null
        (global.get $global335)
       )
      )
      (else
       (struct.new $type28
        (i32.const 0)
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global357)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $7)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global469)
       )
      )
      (local.set $8
       (call $function150
        (local.get $2)
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function193
       (local.get $0)
       (local.get $1)
       (local.get $8)
       (local.get $7)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function195 (type $call115) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 2)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 2)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 2)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 2)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 2)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 2)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 2)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 2)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 2)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 2)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 2)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 2)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 2)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (return_call $function196
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function196 (type $103) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function196
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 2)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function207 (type $call137) (param $0 (ref $type28)) (result i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type29))
  (if (result i64)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (array.len
       (local.tee $4
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i64.ne
      (i64.div_s
       (local.tee $3
        (i64.mul
         (local.tee $2
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 30)
        )
       )
       (i64.const 30)
      )
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global670)
     )
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $1
         (i64.add
          (local.get $3)
          (local.tee $2
           (call $function195
            (i64.extend_i32_s
             (array.get $type29
              (local.get $4)
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
       (i64.xor
        (local.get $1)
        (local.get $2)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function210 (type $78) (param $0 f64) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 f64) (result f64)
  (local $6 i64)
  (if (result f64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $6
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
        (local.get $4)
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i32.and
       (f64.lt
        (f64.abs
         (local.get $5)
        )
        (f64.const inf)
       )
       (f64.lt
        (f64.abs
         (local.get $0)
        )
        (f64.const inf)
       )
      )
      (f64.eq
       (f64.abs
        (local.tee $5
         (f64.mul
          (local.get $5)
          (local.get $0)
         )
        )
       )
       (f64.const inf)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function210
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $6)
     (local.get $5)
    )
   )
  )
 )
 (func $function215 (type $call172) (param $0 (ref $type28)) (param $1 (ref $type28)) (result f64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 f64)
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type28))
  (local $12 (ref $type28))
  (local $13 (ref $type28))
  (local $14 (ref $type151))
  (local $15 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result f64)
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global357)
     )
    )
    (if (result f64)
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (f64.const 0.0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global359)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global741)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global710)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (call $function207
            (local.tee $9
             (if (result (ref $type28))
              (struct.get $type28 0
               (local.get $0)
              )
              (then
               (struct.new $type28
                (i32.const 0)
                (struct.get $type28 1
                 (local.get $0)
                )
               )
              )
              (else
               (local.get $0)
              )
             )
            )
           )
          )
          (block (result i64)
           (drop
            (ref.as_non_null
             (global.get $global710)
            )
           )
           (local.tee $2
            (i64.sub
             (local.get $3)
             (local.tee $4
              (call $function207
               (local.tee $11
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $1)
                 )
                 (then
                  (struct.new $type28
                   (i32.const 0)
                   (struct.get $type28 1
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (i64.xor
          (local.get $3)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (if (result f64)
        (i64.gt_s
         (local.get $2)
         (i64.const 1024)
        )
        (then
         (f64.const inf)
        )
        (else
         (if (result f64)
          (i64.lt_s
           (local.get $2)
           (i64.const -1075)
          )
          (then
           (f64.const 0.0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global725)
            )
           )
           (local.set $7
            (local.get $9)
           )
           (local.set $10
            (local.get $11)
           )
           (if
            (i64.lt_s
             (local.get $2)
             (i64.const 0)
            )
            (then
             (if
              (i64.lt_s
               (i64.and
                (local.get $2)
                (local.tee $3
                 (i64.sub
                  (i64.const 0)
                  (local.get $2)
                 )
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global714)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global368)
              )
             )
             (local.set $12
              (call $function126
               (i64.const 2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global667)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global368)
              )
             )
             (local.set $8
              (call $function126
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global656)
              )
             )
             (local.set $8
              (if (result (ref $type28))
               (struct.get $type28 0
                (local.get $8)
               )
               (then
                (unreachable)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global368)
                 )
                )
                (call $function193
                 (i32.const 0)
                 (i32.const 1)
                 (local.get $12)
                 (local.get $8)
                 (call $function126
                  (i64.const 1)
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global469)
              )
             )
             (local.set $7
              (call $function150
               (local.get $7)
               (local.get $8)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global714)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global368)
              )
             )
             (local.set $12
              (call $function126
               (i64.const 2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global667)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global368)
              )
             )
             (local.set $8
              (call $function126
               (local.get $2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global656)
              )
             )
             (local.set $8
              (if (result (ref $type28))
               (struct.get $type28 0
                (local.get $8)
               )
               (then
                (unreachable)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global368)
                 )
                )
                (call $function193
                 (i32.const 0)
                 (i32.const 1)
                 (local.get $12)
                 (local.get $8)
                 (call $function126
                  (i64.const 1)
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global469)
              )
             )
             (local.set $10
              (call $function150
               (local.get $10)
               (local.get $8)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global405)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global398)
            )
           )
           (if
            (i64.lt_s
             (call $function132
              (local.get $7)
              (local.get $10)
             )
             (i64.const 0)
            )
            (then
             (if
              (i64.lt_s
               (i64.and
                (i64.xor
                 (local.tee $3
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (local.get $2)
                )
                (i64.xor
                 (local.get $2)
                 (i64.const 1)
                )
               )
               (i64.const 0)
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (local.get $3)
             )
            )
           )
           (if (result f64)
            (i64.gt_s
             (local.get $2)
             (i64.const 1023)
            )
            (then
             (f64.const inf)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global736)
              )
             )
             (if
              (i64.lt_s
               (local.tee $3
                (if (result i64)
                 (i64.lt_s
                  (local.get $2)
                  (i64.const -1022)
                 )
                 (then
                  (i64.const -1074)
                 )
                 (else
                  (if
                   (i64.lt_s
                    (i64.and
                     (i64.xor
                      (local.tee $3
                       (i64.sub
                        (local.get $2)
                        (i64.const 52)
                       )
                      )
                      (local.get $2)
                     )
                     (i64.xor
                      (local.get $2)
                      (i64.const 52)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.get $3)
                 )
                )
               )
               (i64.const 0)
              )
              (then
               (if
                (i64.lt_s
                 (i64.and
                  (local.get $3)
                  (local.tee $2
                   (i64.sub
                    (i64.const 0)
                    (local.get $3)
                   )
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global714)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global368)
                )
               )
               (local.set $10
                (call $function126
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global667)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global368)
                )
               )
               (local.set $7
                (call $function126
                 (local.get $2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global656)
                )
               )
               (local.set $7
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $7)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global368)
                   )
                  )
                  (call $function193
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $10)
                   (local.get $7)
                   (call $function126
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global469)
                )
               )
               (local.set $9
                (call $function150
                 (local.get $9)
                 (local.get $7)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global714)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global368)
                )
               )
               (local.set $10
                (call $function126
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global667)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global368)
                )
               )
               (local.set $7
                (call $function126
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global656)
                )
               )
               (local.set $7
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $7)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global368)
                   )
                  )
                  (call $function193
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $10)
                   (local.get $7)
                   (call $function126
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global469)
                )
               )
               (local.set $11
                (call $function150
                 (local.get $11)
                 (local.get $7)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global729)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global551)
              )
             )
             (local.set $14
              (call $function166
               (local.get $9)
               (local.get $11)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global376)
              )
             )
             (local.set $2
              (call $function129
               (local.tee $15
                (struct.get $type28 1
                 (local.tee $9
                  (struct.get $type151 0
                   (local.get $14)
                  )
                 )
                )
               )
               (i32.const 1)
               (local.tee $5
                (struct.get $type28 0
                 (local.get $9)
                )
               )
               (i32.const 1)
               (select
                (i64.const -9223372036854775808)
                (i64.const -9223372036854775807)
                (local.get $5)
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.extend_i32_u
                (array.len
                 (local.get $15)
                )
               )
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global442)
              )
             )
             (if
              (if (result i32)
               (i64.gt_s
                (local.tee $4
                 (call $function132
                  (call $function144
                   (local.tee $9
                    (struct.get $type151 1
                     (local.get $14)
                    )
                   )
                   (local.get $9)
                  )
                  (block (result (ref $type28))
                   (drop
                    (ref.as_non_null
                     (global.get $global398)
                    )
                   )
                   (local.get $11)
                  )
                 )
                )
                (i64.const 0)
               )
               (then
                (i32.const 1)
               )
               (else
                (if (result i32)
                 (i64.eqz
                  (local.get $4)
                 )
                 (then
                  (i64.eq
                   (i64.rem_s
                    (local.get $2)
                    (i64.const 2)
                   )
                   (i64.const 1)
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
              (then
               (if
                (i64.lt_s
                 (i64.and
                  (i64.xor
                   (local.get $2)
                   (local.tee $2
                    (i64.add
                     (local.get $2)
                     (i64.const 1)
                    )
                   )
                  )
                  (i64.xor
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (unreachable)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global716)
              )
             )
             (f64.mul
              (f64.convert_i64_s
               (local.get $2)
              )
              (call $function210
               (select
                (f64.const 0.5)
                (f64.const 2.0)
                (local.tee $5
                 (i64.lt_s
                  (local.get $3)
                  (i64.const 0)
                 )
                )
               )
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (if (result i64)
                (local.get $5)
                (then
                 (if
                  (i64.lt_s
                   (i64.and
                    (local.get $3)
                    (local.tee $2
                     (i64.sub
                      (i64.const 0)
                      (local.get $3)
                     )
                    )
                   )
                   (i64.const 0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.get $2)
                )
                (else
                 (local.get $3)
                )
               )
               (f64.const 1.0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (select
        (i32.eqz
         (local.tee $5
          (struct.get $type28 0
           (local.get $1)
          )
         )
        )
        (local.get $5)
        (struct.get $type28 0
         (local.get $0)
        )
       )
       (then
        (if
         (i32.and
          (f64.lt
           (f64.abs
            (local.get $6)
           )
           (f64.const inf)
          )
          (f64.eq
           (f64.abs
            (local.tee $6
             (f64.sub
              (f64.const -0.0)
              (local.get $6)
             )
            )
           )
           (f64.const inf)
          )
         )
         (then
          (unreachable)
         )
        )
       )
      )
      (local.get $6)
     )
    )
   )
  )
 )
 (func $function218 (type $call143) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global359)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $0)
   )
   (then
    (local.set $0
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global359)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global560)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global551)
     )
    )
    (local.set $0
     (struct.get $type151 1
      (call $function166
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global357)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global560)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global551)
       )
      )
      (local.set $1
       (struct.get $type151 1
        (call $function166
         (local.get $1)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global357)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global560)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global551)
         )
        )
        (local.set $0
         (struct.get $type151 1
          (call $function166
           (local.get $0)
           (local.get $1)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global357)
         )
        )
        (if (result (ref $type28))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type28 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global560)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global551)
           )
          )
          (local.set $1
           (struct.get $type151 1
            (call $function166
             (local.get $1)
             (local.get $0)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global357)
           )
          )
          (if (result (ref $type28))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type28 1
               (local.get $1)
              )
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global560)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global551)
             )
            )
            (local.set $0
             (struct.get $type151 1
              (call $function166
               (local.get $0)
               (local.get $1)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global357)
             )
            )
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type28 1
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global560)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global551)
               )
              )
              (local.set $1
               (struct.get $type151 1
                (call $function166
                 (local.get $1)
                 (local.get $0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global357)
               )
              )
              (if (result (ref $type28))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type28 1
                   (local.get $1)
                  )
                 )
                )
               )
               (then
                (local.get $0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global560)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global551)
                 )
                )
                (local.set $0
                 (struct.get $type151 1
                  (call $function166
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global357)
                 )
                )
                (if (result (ref $type28))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (struct.get $type28 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global560)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global551)
                   )
                  )
                  (local.set $1
                   (struct.get $type151 1
                    (call $function166
                     (local.get $1)
                     (local.get $0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global357)
                   )
                  )
                  (if (result (ref $type28))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type28 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global560)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global551)
                     )
                    )
                    (local.set $0
                     (struct.get $type151 1
                      (call $function166
                       (local.get $0)
                       (local.get $1)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global357)
                     )
                    )
                    (if (result (ref $type28))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global560)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global551)
                       )
                      )
                      (local.set $1
                       (struct.get $type151 1
                        (call $function166
                         (local.get $1)
                         (local.get $0)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global357)
                       )
                      )
                      (if (result (ref $type28))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type28 1
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global560)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global551)
                         )
                        )
                        (local.set $0
                         (struct.get $type151 1
                          (call $function166
                           (local.get $0)
                           (local.get $1)
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global357)
                         )
                        )
                        (if (result (ref $type28))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type28 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global560)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global551)
                           )
                          )
                          (local.set $1
                           (struct.get $type151 1
                            (call $function166
                             (local.get $1)
                             (local.get $0)
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global357)
                           )
                          )
                          (if (result (ref $type28))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type28 1
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global560)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global551)
                             )
                            )
                            (local.set $0
                             (struct.get $type151 1
                              (call $function166
                               (local.get $0)
                               (local.get $1)
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global357)
                             )
                            )
                            (if (result (ref $type28))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (struct.get $type28 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global560)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global551)
                               )
                              )
                              (local.set $1
                               (struct.get $type151 1
                                (call $function166
                                 (local.get $1)
                                 (local.get $0)
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global357)
                               )
                              )
                              (if (result (ref $type28))
                               (call $function121
                                (local.get $1)
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global560)
                                 )
                                )
                                (return_call $function219
                                 (i32.const 0)
                                 (i32.const 1)
                                 (local.get $1)
                                 (call $function168
                                  (local.get $0)
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function219 (type $76) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result (ref $type28))
   (call $function121
    (local.get $3)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global560)
     )
    )
    (local.set $2
     (call $function168
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function219
     (local.get $0)
     (local.get $1)
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function226 (type $call174) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type27))
  (local $2 (ref $type28))
  (local $3 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global357)
   )
  )
  (if (result (ref $type27))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global361)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global357)
       )
      )
      (if
       (i64.ne
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $0
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $0)
           )
          )
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global359)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global754)
     )
    )
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (local.set $1
       (struct.new $type28
        (i32.const 0)
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
    (local.set $2
     (call $function218
      (local.get $0)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global557)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global551)
     )
    )
    (struct.new $type27
     (struct.get $type151 0
      (call $function166
       (local.get $0)
       (local.get $2)
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global557)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global551)
       )
      )
      (struct.get $type151 0
       (call $function166
        (local.get $1)
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function314 (type $73) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result i32)
  (local $8 i32)
  (local $9 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign20
     (local.get $1)
     (array.get $type19
      (if (result (ref $type19))
       (i32.lt_u
        (local.tee $8
         (i32.wrap_i64
          (local.get $7)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type18 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type20
          (struct.get $type18 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $8)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $8)
       (i32.const 8191)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $9
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $9)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function314
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $9)
    )
   )
  )
 )
 (func $function322 (type $72) (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i32) (param $5 (ref $type18)) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i64) (result (ref $type18))
  (local $10 i32)
  (local $11 i32)
  (local $12 i64)
  (if
   (i32.eqz
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $3)
    (local.get $9)
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (local.get $5)
   )
   (else
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.get $9)
      (i64.extend32_s
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (call $foreign28
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.wrap_i64
       (local.get $9)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $5)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $9)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $10
        (i32.wrap_i64
         (local.get $9)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $5)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $5)
         )
         (i32.sub
          (i32.shr_u
           (local.get $10)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $10)
      (i32.const 8191)
     )
     (local.get $11)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $9)
        (local.tee $12
         (i64.add
          (local.get $9)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $12)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $8)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function322
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $12)
    )
   )
  )
 )
 (func $function324 (type $call215) (param $0 i32) (param $1 i32) (param $2 i32) (result (ref $type32))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type27))
  (local $12 (ref $type18))
  (local $13 (ref $type18))
  (local $14 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global1166)
   )
  )
  (local.set $12
   (call $function322
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (local.tee $3
     (i64.extend_i32_s
      (call $foreign27
       (local.get $0)
       (local.get $1)
       (i32.const 0)
      )
     )
    )
    (i32.const 1)
    (block (result (ref $type18))
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (if
      (i64.gt_u
       (local.get $3)
       (i64.const 4294967294)
      )
      (then
       (unreachable)
      )
     )
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1174)
   )
  )
  (local.set $4
   (i64.extend_i32_s
    (call $foreign30
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (local.set $3
   (call $foreign29
    (local.get $0)
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global606)
   )
  )
  (local.set $6
   (call $function179
    (local.get $12)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1166)
   )
  )
  (local.set $8
   (call $function179
    (call $function322
     (local.get $0)
     (local.get $1)
     (i32.const 1)
     (local.tee $5
      (i64.extend_i32_s
       (call $foreign27
        (local.get $0)
        (local.get $1)
        (i32.const 1)
       )
      )
     )
     (i32.const 1)
     (block (result (ref $type18))
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-new
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (i64.const 0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global606)
      )
     )
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global368)
   )
  )
  (local.set $10
   (call $function126
    (i64.const 10)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global667)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global368)
   )
  )
  (local.set $7
   (call $function126
    (if (result i64)
     (i64.lt_s
      (local.get $3)
      (i64.const 0)
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (local.get $3)
         (local.tee $4
          (i64.sub
           (i64.const 0)
           (local.get $3)
          )
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $4)
     )
     (else
      (local.get $3)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global656)
   )
  )
  (local.set $7
   (if (result (ref $type28))
    (struct.get $type28 0
     (local.get $7)
    )
    (then
     (unreachable)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global368)
      )
     )
     (call $function193
      (i32.const 0)
      (i32.const 1)
      (local.get $10)
      (local.get $7)
      (call $function126
       (i64.const 1)
      )
     )
    )
   )
  )
  (local.set $11
   (if (result (ref $type27))
    (i64.lt_s
     (local.get $3)
     (i64.const 0)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global469)
      )
     )
     (local.set $9
      (call $function150
       (local.get $8)
       (local.get $7)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global781)
      )
     )
     (call $function226
      (local.get $6)
      (local.get $9)
     )
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global469)
      )
     )
     (call $function226
      (call $function150
       (local.get $6)
       (local.get $7)
      )
      (block (result (ref $type28))
       (drop
        (ref.as_non_null
         (global.get $global781)
        )
       )
       (local.get $8)
      )
     )
    )
   )
  )
  (if (result (ref $type32))
   (i32.eq
    (local.get $2)
    (i32.const 5)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global847)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global790)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global402)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global398)
     )
    )
    (if (result (ref $type32))
     (if (result i32)
      (i64.eqz
       (call $function132
        (struct.get $type27 1
         (local.get $11)
        )
        (ref.as_non_null
         (global.get $global780)
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global752)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global368)
        )
       )
       (local.set $6
        (call $function126
         (i64.const -9223372036854775808)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global414)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global398)
        )
       )
       (if (result i32)
        (i64.ge_s
         (call $function132
          (local.tee $8
           (struct.get $type27 0
            (local.get $11)
           )
          )
          (local.get $6)
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global368)
          )
         )
         (local.set $6
          (call $function126
           (i64.const 9223372036854775807)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global408)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global398)
          )
         )
         (i64.le_s
          (call $function132
           (local.get $8)
           (local.get $6)
          )
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global376)
       )
      )
      (struct.new $type33
       (i32.const 0)
       (call $function129
        (local.tee $14
         (struct.get $type28 1
          (local.tee $6
           (struct.get $type27 0
            (local.get $11)
           )
          )
         )
        )
        (i32.const 1)
        (local.tee $0
         (struct.get $type28 0
          (local.get $6)
         )
        )
        (i32.const 1)
        (select
         (i64.const -9223372036854775808)
         (i64.const -9223372036854775807)
         (local.get $0)
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.extend_i32_u
         (array.len
          (local.get $14)
         )
        )
        (i64.const 0)
       )
      )
     )
     (else
      (struct.new $type34
       (i32.const 1)
       (local.get $11)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global792)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global357)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (if (result f64)
      (if (result i32)
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (struct.get $type27 0
            (local.get $11)
           )
          )
         )
        )
       )
       (then
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $12)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (array.get $type19
          (struct.get $type18 2
           (local.get $12)
          )
          (i32.const 0)
         )
         (i32.const 45)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (f64.const -0.0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global839)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global746)
        )
       )
       (call $function215
        (struct.get $type27 0
         (local.get $11)
        )
        (struct.get $type27 1
         (local.get $11)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function327 (type $67) (param $0 i32) (param $1 i64) (param $2 i32) (param $3 (ref $type18)) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result (ref $type18))
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (if
   (i32.eqz
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $7)
   )
   (then
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.get $7)
      (i64.extend32_s
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (call $foreign35
      (local.get $0)
      (i32.wrap_i64
       (local.get $7)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $3)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $3)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $3)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (local.get $9)
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $7)
        (local.tee $10
         (i64.add
          (local.get $7)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $10)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function327
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $10)
    )
   )
  )
 )
 (func $function329 (type $call218) (param $0 i32) (param $1 i32) (result (ref $type219))
  (local $2 (ref $type32))
  (local $3 (ref $type32))
  (local $4 (ref $type27))
  (local $5 i32)
  (local $6 i64)
  (local $7 f64)
  (if (result (ref $type219))
   (local.get $1)
   (then
    (if (result (ref $type219))
     (i32.eq
      (local.get $1)
      (i32.const 4)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1193)
       )
      )
      (struct.new $type222
       (i32.const 2)
       (call $function327
        (local.get $0)
        (local.tee $6
         (i64.extend_i32_s
          (call $foreign34
           (local.get $0)
          )
         )
        )
        (i32.const 1)
        (block (result (ref $type18))
         (drop
          (ref.as_non_null
           (global.get $global61)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967294)
          )
          (then
           (unreachable)
          )
         )
         (call $string-new
          (i32.wrap_i64
           (local.get $6)
          )
         )
        )
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
     )
     (else
      (if (result (ref $type219))
       (i32.eq
        (local.get $1)
        (i32.const 3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1189)
         )
        )
        (local.set $3
         (if (result (ref $type32))
          (i32.eq
           (local.tee $1
            (call $foreign33
             (local.get $0)
             (i32.const 0)
            )
           )
           (i32.const 1)
          )
          (then
           (struct.new $type33
            (i32.const 0)
            (call $foreign32
             (local.get $0)
             (i32.const 0)
            )
           )
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (local.get $1)
             (i32.const 2)
            )
            (then
             (struct.new $type35
              (i32.const 2)
              (call $foreign31
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1183)
              )
             )
             (call $function324
              (local.get $0)
              (i32.const 0)
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1189)
         )
        )
        (local.set $2
         (if (result (ref $type32))
          (i32.eq
           (local.tee $1
            (call $foreign33
             (local.get $0)
             (i32.const 1)
            )
           )
           (i32.const 1)
          )
          (then
           (struct.new $type33
            (i32.const 0)
            (call $foreign32
             (local.get $0)
             (i32.const 1)
            )
           )
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (local.get $1)
             (i32.const 2)
            )
            (then
             (struct.new $type35
              (i32.const 2)
              (call $foreign31
               (local.get $0)
               (i32.const 1)
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1183)
              )
             )
             (call $function324
              (local.get $0)
              (i32.const 1)
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global883)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global859)
         )
        )
        (struct.new $type221
         (i32.const 1)
         (if (result (ref $type24))
          (if (result i32)
           (if (result i32)
            (local.tee $0
             (struct.get $type32 0
              (local.get $2)
             )
            )
            (then
             (if (result i32)
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type34)
                 (local.get $2)
                )
               )
               (i32.const 1)
              )
              (else
               (drop
                (ref.cast (ref $type35)
                 (local.get $2)
                )
               )
               (i32.const 0)
              )
             )
            )
            (else
             (drop
              (ref.cast (ref $type33)
               (local.get $2)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global865)
             )
            )
            (if (result i32)
             (local.tee $0
              (struct.get $type32 0
               (local.get $2)
              )
             )
             (then
              (if (result i32)
               (i32.eq
                (local.get $0)
                (i32.const 1)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global792)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global357)
                 )
                )
                (i64.eqz
                 (i64.extend_i32_u
                  (array.len
                   (struct.get $type28 1
                    (struct.get $type27 0
                     (struct.get $type34 1
                      (ref.cast (ref $type34)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (f64.eq
                 (struct.get $type35 1
                  (ref.cast (ref $type35)
                   (local.get $2)
                  )
                 )
                 (f64.const 0.0)
                )
               )
              )
             )
             (else
              (i64.eqz
               (struct.get $type33 1
                (ref.cast (ref $type33)
                 (local.get $2)
                )
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global849)
            )
           )
           (if (result (ref $type24))
            (local.tee $0
             (struct.get $type32 0
              (local.get $3)
             )
            )
            (then
             (if (result (ref $type24))
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type34)
                 (local.get $3)
                )
               )
               (struct.new $type26
                (i32.const 1)
               )
              )
              (else
               (drop
                (ref.cast (ref $type35)
                 (local.get $3)
                )
               )
               (struct.new $type30
                (i32.const 2)
               )
              )
             )
            )
            (else
             (struct.new $type25
              (i32.const 0)
              (struct.get $type33 1
               (ref.cast (ref $type33)
                (local.get $3)
               )
              )
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global859)
            )
           )
           (if
            (i32.eqz
             (if (result i32)
              (if (result i32)
               (local.tee $0
                (struct.get $type32 0
                 (local.get $3)
                )
               )
               (then
                (if (result i32)
                 (i32.eq
                  (local.get $0)
                  (i32.const 1)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type34)
                    (local.get $3)
                   )
                  )
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.cast (ref $type35)
                    (local.get $3)
                   )
                  )
                  (i32.const 0)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type33)
                  (local.get $3)
                 )
                )
                (i32.const 1)
               )
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global859)
                )
               )
               (if (result i32)
                (local.tee $0
                 (struct.get $type32 0
                  (local.get $2)
                 )
                )
                (then
                 (if (result i32)
                  (i32.eq
                   (local.get $0)
                   (i32.const 1)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type34)
                     (local.get $2)
                    )
                   )
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type35)
                     (local.get $2)
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (drop
                  (ref.cast (ref $type33)
                   (local.get $2)
                  )
                 )
                 (i32.const 1)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global871)
              )
             )
             (drop
              (if (result f64)
               (local.tee $0
                (struct.get $type32 0
                 (local.get $3)
                )
               )
               (then
                (if (result f64)
                 (i32.eq
                  (local.get $0)
                  (i32.const 1)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global839)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global746)
                   )
                  )
                  (call $function215
                   (struct.get $type27 0
                    (local.tee $4
                     (struct.get $type34 1
                      (ref.cast (ref $type34)
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (struct.get $type27 1
                    (local.get $4)
                   )
                  )
                 )
                 (else
                  (struct.get $type35 1
                   (ref.cast (ref $type35)
                    (local.get $3)
                   )
                  )
                 )
                )
               )
               (else
                (f64.convert_i64_s
                 (struct.get $type33 1
                  (ref.cast (ref $type33)
                   (local.get $3)
                  )
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global871)
              )
             )
             (drop
              (if (result f64)
               (local.tee $0
                (struct.get $type32 0
                 (local.get $2)
                )
               )
               (then
                (if (result f64)
                 (i32.eq
                  (local.get $0)
                  (i32.const 1)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global839)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global746)
                   )
                  )
                  (call $function215
                   (struct.get $type27 0
                    (local.tee $4
                     (struct.get $type34 1
                      (ref.cast (ref $type34)
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (struct.get $type27 1
                    (local.get $4)
                   )
                  )
                 )
                 (else
                  (struct.get $type35 1
                   (ref.cast (ref $type35)
                    (local.get $2)
                   )
                  )
                 )
                )
               )
               (else
                (f64.convert_i64_s
                 (struct.get $type33 1
                  (ref.cast (ref $type33)
                   (local.get $2)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (struct.new $type31
            (i32.const 3)
           )
          )
         )
        )
       )
       (else
        (if (result (ref $type219))
         (i32.or
          (i32.eq
           (local.get $1)
           (i32.const 8)
          )
          (i32.eq
           (local.get $1)
           (i32.const 7)
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global1199)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1189)
           )
          )
          (local.set $2
           (if (result (ref $type32))
            (i32.eq
             (local.tee $5
              (call $foreign33
               (local.get $0)
               (i32.const 0)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign32
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $5)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign31
                 (local.get $0)
                 (i32.const 0)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1183)
                )
               )
               (call $function324
                (local.get $0)
                (i32.const 0)
                (local.get $5)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1189)
           )
          )
          (local.set $3
           (if (result (ref $type32))
            (i32.eq
             (local.tee $5
              (call $foreign33
               (local.get $0)
               (i32.const 1)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign32
               (local.get $0)
               (i32.const 1)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $5)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign31
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1183)
                )
               )
               (call $function324
                (local.get $0)
                (i32.const 1)
                (local.get $5)
               )
              )
             )
            )
           )
          )
          (if (result (ref $type219))
           (if (result i32)
            (i32.eq
             (local.get $1)
             (i32.const 8)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global859)
              )
             )
             (i32.eqz
              (if (result i32)
               (if (result i32)
                (if (result i32)
                 (local.tee $0
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result i32)
                   (i32.eq
                    (local.get $0)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.cast (ref $type34)
                      (local.get $2)
                     )
                    )
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.cast (ref $type35)
                      (local.get $2)
                     )
                    )
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type33)
                    (local.get $2)
                   )
                  )
                  (i32.const 1)
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global865)
                  )
                 )
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $2)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global792)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global357)
                      )
                     )
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type28 1
                         (struct.get $type27 0
                          (struct.get $type34 1
                           (ref.cast (ref $type34)
                            (local.get $2)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (f64.eq
                      (struct.get $type35 1
                       (ref.cast (ref $type35)
                        (local.get $2)
                       )
                      )
                      (f64.const 0.0)
                     )
                    )
                   )
                  )
                  (else
                   (i64.eqz
                    (struct.get $type33 1
                     (ref.cast (ref $type33)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global859)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $3)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type34)
                       (local.get $3)
                      )
                     )
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type35)
                       (local.get $3)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type33)
                     (local.get $3)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global865)
                   )
                  )
                  (if (result i32)
                   (local.tee $0
                    (struct.get $type32 0
                     (local.get $3)
                    )
                   )
                   (then
                    (if (result i32)
                     (i32.eq
                      (local.get $0)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global792)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global357)
                       )
                      )
                      (i64.eqz
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type28 1
                          (struct.get $type27 0
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $3)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (f64.eq
                       (struct.get $type35 1
                        (ref.cast (ref $type35)
                         (local.get $3)
                        )
                       )
                       (f64.const 0.0)
                      )
                     )
                    )
                   )
                   (else
                    (i64.eqz
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (struct.new $type222
             (i32.const 2)
             (global.get $string7)
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global886)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global859)
             )
            )
            (struct.new $type221
             (i32.const 1)
             (if (result (ref $type24))
              (if (result i32)
               (if (result i32)
                (local.tee $0
                 (struct.get $type32 0
                  (local.get $2)
                 )
                )
                (then
                 (if (result i32)
                  (i32.eq
                   (local.get $0)
                   (i32.const 1)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type34)
                     (local.get $2)
                    )
                   )
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.cast (ref $type35)
                     (local.get $2)
                    )
                   )
                   (i32.const 0)
                  )
                 )
                )
                (else
                 (drop
                  (ref.cast (ref $type33)
                   (local.get $2)
                  )
                 )
                 (i32.const 1)
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global865)
                 )
                )
                (if (result i32)
                 (local.tee $0
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result i32)
                   (i32.eq
                    (local.get $0)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global792)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global357)
                     )
                    )
                    (i64.eqz
                     (i64.extend_i32_u
                      (array.len
                       (struct.get $type28 1
                        (struct.get $type27 0
                         (struct.get $type34 1
                          (ref.cast (ref $type34)
                           (local.get $2)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (f64.eq
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $2)
                      )
                     )
                     (f64.const 0.0)
                    )
                   )
                  )
                 )
                 (else
                  (i64.eqz
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (struct.new_default $type25)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global859)
                )
               )
               (if (result (ref $type24))
                (if (result i32)
                 (if (result i32)
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $3)
                   )
                  )
                  (then
                   (if (result i32)
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type34)
                       (local.get $3)
                      )
                     )
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.cast (ref $type35)
                       (local.get $3)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.cast (ref $type33)
                     (local.get $3)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global865)
                   )
                  )
                  (if (result i32)
                   (local.tee $0
                    (struct.get $type32 0
                     (local.get $3)
                    )
                   )
                   (then
                    (if (result i32)
                     (i32.eq
                      (local.get $0)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global792)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global357)
                       )
                      )
                      (i64.eqz
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type28 1
                          (struct.get $type27 0
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $3)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (f64.eq
                       (struct.get $type35 1
                        (ref.cast (ref $type35)
                         (local.get $3)
                        )
                       )
                       (f64.const 0.0)
                      )
                     )
                    )
                   )
                   (else
                    (i64.eqz
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global849)
                  )
                 )
                 (if (result (ref $type24))
                  (local.tee $0
                   (struct.get $type32 0
                    (local.get $2)
                   )
                  )
                  (then
                   (if (result (ref $type24))
                    (i32.eq
                     (local.get $0)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type34)
                       (local.get $2)
                      )
                     )
                     (struct.new $type26
                      (i32.const 1)
                     )
                    )
                    (else
                     (drop
                      (ref.cast (ref $type35)
                       (local.get $2)
                      )
                     )
                     (struct.new $type30
                      (i32.const 2)
                     )
                    )
                   )
                  )
                  (else
                   (struct.new $type25
                    (i32.const 0)
                    (struct.get $type33 1
                     (ref.cast (ref $type33)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global871)
                  )
                 )
                 (drop
                  (if (result f64)
                   (local.tee $0
                    (struct.get $type32 0
                     (local.get $2)
                    )
                   )
                   (then
                    (if (result f64)
                     (i32.eq
                      (local.get $0)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global839)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global746)
                       )
                      )
                      (call $function215
                       (struct.get $type27 0
                        (local.tee $4
                         (struct.get $type34 1
                          (ref.cast (ref $type34)
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (struct.get $type27 1
                        (local.get $4)
                       )
                      )
                     )
                     (else
                      (struct.get $type35 1
                       (ref.cast (ref $type35)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                   (else
                    (f64.convert_i64_s
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global871)
                  )
                 )
                 (drop
                  (call $foreign12
                   (local.tee $7
                    (if (result f64)
                     (local.tee $0
                      (struct.get $type32 0
                       (local.get $3)
                      )
                     )
                     (then
                      (if (result f64)
                       (i32.eq
                        (local.get $0)
                        (i32.const 1)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global839)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global746)
                         )
                        )
                        (call $function215
                         (struct.get $type27 0
                          (local.tee $4
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (struct.get $type27 1
                          (local.get $4)
                         )
                        )
                       )
                       (else
                        (struct.get $type35 1
                         (ref.cast (ref $type35)
                          (local.get $3)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (f64.convert_i64_s
                       (struct.get $type33 1
                        (ref.cast (ref $type33)
                         (local.get $3)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (call $foreign13
                   (local.get $7)
                  )
                 )
                 (struct.new $type31
                  (i32.const 3)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global1189)
           )
          )
          (local.set $2
           (if (result (ref $type32))
            (i32.eq
             (local.tee $1
              (call $foreign33
               (local.get $0)
               (i32.const 0)
              )
             )
             (i32.const 1)
            )
            (then
             (struct.new $type33
              (i32.const 0)
              (call $foreign32
               (local.get $0)
               (i32.const 0)
              )
             )
            )
            (else
             (if (result (ref $type32))
              (i32.eq
               (local.get $1)
               (i32.const 2)
              )
              (then
               (struct.new $type35
                (i32.const 2)
                (call $foreign31
                 (local.get $0)
                 (i32.const 0)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1183)
                )
               )
               (call $function324
                (local.get $0)
                (i32.const 0)
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global849)
           )
          )
          (struct.new $type221
           (i32.const 1)
           (if (result (ref $type24))
            (local.tee $0
             (struct.get $type32 0
              (local.get $2)
             )
            )
            (then
             (if (result (ref $type24))
              (i32.eq
               (local.get $0)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type34)
                 (local.get $2)
                )
               )
               (struct.new $type26
                (i32.const 1)
               )
              )
              (else
               (drop
                (ref.cast (ref $type35)
                 (local.get $2)
                )
               )
               (struct.new $type30
                (i32.const 2)
               )
              )
             )
            )
            (else
             (struct.new $type25
              (i32.const 0)
              (struct.get $type33 1
               (ref.cast (ref $type33)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty220)
   )
  )
 )
 (func $function335 (type $59) (result (ref $type36))
  (local $0 i64)
  (local $1 i64)
  (local $2 (ref $type69))
  (drop
   (ref.as_non_null
    (global.get $global1229)
   )
  )
  (if
   (i64.eq
    (local.tee $0
     (struct.get $type69 0
      (global.get $global1228)
     )
    )
    (i64.const 9223372036854775807)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1148)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1140)
     )
    )
    (call $foreign21
     (call $function314
      (global.get $string10)
      (call $foreign19)
      (i32.const 1)
      (i64.const 40)
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (unreachable)
   )
   (else
    (struct.set $type69 0
     (ref.as_non_null
      (global.get $global1228)
     )
     (block (result i64)
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $0)
          (local.tee $1
           (i64.add
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $1)
     )
    )
   )
  )
  (struct.new $type36
   (i32.const 6)
  )
 )
 (func $function379 (type $call46) (param $0 (ref null $type12)) (result (ref $type39))
  (local $1 (ref null $type12))
  (local $2 i64)
  (if (result (ref $type39))
   (ref.is_null
    (local.get $0)
   )
   (then
    (array.new_fixed $type39 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1433)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1433)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (if (result i64)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type12 1
             (local.get $0)
            )
           )
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type12 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 2)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type12 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 3)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type12 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 4)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type12 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $1
                      (struct.get $type12 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $1
                        (struct.get $type12 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $1
                          (struct.get $type12 1
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $1
                            (struct.get $type12 1
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (i64.const 9)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $1
                              (struct.get $type12 1
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (i64.const 10)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $1
                                (struct.get $type12 1
                                 (local.get $1)
                                )
                               )
                              )
                              (then
                               (i64.const 11)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $1
                                  (struct.get $type12 1
                                   (local.get $1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 12)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $1
                                    (struct.get $type12 1
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 13)
                                  )
                                  (else
                                   (call $function381
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type12 1
                                     (local.get $1)
                                    )
                                    (i64.const 14)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function382
     (array.new $type39
      (struct.get $type12 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 1)
     (i32.const 0)
     (i32.const 1)
     (local.get $0)
     (i64.const 0)
    )
   )
  )
 )
 (func $function381 (type $54) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function381
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function382 (type $53) (param $0 (ref null $type39)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 (ref null $type12)) (param $5 i64) (result (ref $type39))
  (local $6 i64)
  (local $7 (ref $type13))
  (if (result (ref $type39))
   (ref.is_null
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $0)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.get $type12 0
      (local.get $4)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type39
     (local.get $0)
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $7)
    )
    (local.set $4
     (struct.get $type12 1
      (local.get $4)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $5)
        (local.tee $6
         (i64.add
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $6)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function382
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $6)
    )
   )
  )
 )
 (func $function418 (type $call276) (param $0 (ref $type68)) (result (ref $type277))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type88))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type18))
  (local $8 (ref $type219))
  (local $9 (ref $type269))
  (local $10 (ref $type226))
  (local $11 (ref $type295))
  (local $12 (ref $type277))
  (local $scratch (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global1588)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $2
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (block $block
   (return
    (if (result (ref $type279))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type89)
         (local.tee $4
          (if (result (ref $type88))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty89)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type90
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type90 0
           (ref.cast (ref $type90)
            (local.get $4)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty279)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1594)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign38
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1596)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1599)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1588)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global152)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global139)
         )
        )
        (local.set $2
         (call $function55
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global150)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1590)
         )
        )
        (drop
         (if (result i32)
          (if (result i32)
           (i64.lt_s
            (local.tee $1
             (if (result i64)
              (ref.test (ref $type89)
               (local.tee $4
                (if (result (ref $type88))
                 (i32.eq
                  (local.get $2)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty89)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $1
                     (i64.extend_i32_s
                      (local.get $2)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $1)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $1)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type90
                   (i32.wrap_i64
                    (local.get $1)
                   )
                  )
                 )
                )
               )
              )
              (then
               (i64.const -1)
              )
              (else
               (i64.extend_i32_u
                (struct.get $type90 0
                 (ref.cast (ref $type90)
                  (local.get $4)
                 )
                )
               )
              )
             )
            )
            (i64.const 0)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1596)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 10)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1596)
               )
              )
              (i64.eq
               (local.get $1)
               (i64.const 13)
              )
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready1599)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1599)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1588)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global152)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global139)
            )
           )
           (local.set $2
            (call $function55
             (local.get $0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global150)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1590)
            )
           )
           (if (result i32)
            (if (result i32)
             (i64.lt_s
              (local.tee $1
               (if (result i64)
                (ref.test (ref $type89)
                 (local.tee $4
                  (if (result (ref $type88))
                   (i32.eq
                    (local.get $2)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty89)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (i64.extend_i32_s
                        (local.get $2)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $1)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $1)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type90
                     (i32.wrap_i64
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type90 0
                   (ref.cast (ref $type90)
                    (local.get $4)
                   )
                  )
                 )
                )
               )
              )
              (i64.const 0)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1596)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 10)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1596)
                 )
                )
                (i64.eq
                 (local.get $1)
                 (i64.const 13)
                )
               )
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (if
              (i32.eqz
               (global.get $ready1599)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1599)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1588)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global152)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global139)
              )
             )
             (local.set $2
              (call $function55
               (local.get $0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global150)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1590)
              )
             )
             (if (result i32)
              (if (result i32)
               (i64.lt_s
                (local.tee $1
                 (if (result i64)
                  (ref.test (ref $type89)
                   (local.tee $4
                    (if (result (ref $type88))
                     (i32.eq
                      (local.get $2)
                      (i32.const -1)
                     )
                     (then
                      (global.get $empty89)
                     )
                     (else
                      (if
                       (i64.gt_u
                        (local.tee $1
                         (i64.extend_i32_s
                          (local.get $2)
                         )
                        )
                        (i64.const 1114111)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i32.and
                        (i64.le_u
                         (local.get $1)
                         (i64.const 57343)
                        )
                        (i64.ge_u
                         (local.get $1)
                         (i64.const 55296)
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (struct.new $type90
                       (i32.wrap_i64
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i64.const -1)
                  )
                  (else
                   (i64.extend_i32_u
                    (struct.get $type90 0
                     (ref.cast (ref $type90)
                      (local.get $4)
                     )
                    )
                   )
                  )
                 )
                )
                (i64.const 0)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1596)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 10)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1596)
                   )
                  )
                  (i64.eq
                   (local.get $1)
                   (i64.const 13)
                  )
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (if
                (i32.eqz
                 (global.get $ready1599)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1599)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1588)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global152)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global139)
                )
               )
               (local.set $2
                (call $function55
                 (local.get $0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global150)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1590)
                )
               )
               (if (result i32)
                (if (result i32)
                 (i64.lt_s
                  (local.tee $1
                   (if (result i64)
                    (ref.test (ref $type89)
                     (local.tee $4
                      (if (result (ref $type88))
                       (i32.eq
                        (local.get $2)
                        (i32.const -1)
                       )
                       (then
                        (global.get $empty89)
                       )
                       (else
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (i64.extend_i32_s
                            (local.get $2)
                           )
                          )
                          (i64.const 1114111)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (if
                         (i32.and
                          (i64.le_u
                           (local.get $1)
                           (i64.const 57343)
                          )
                          (i64.ge_u
                           (local.get $1)
                           (i64.const 55296)
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (struct.new $type90
                         (i32.wrap_i64
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i64.const -1)
                    )
                    (else
                     (i64.extend_i32_u
                      (struct.get $type90 0
                       (ref.cast (ref $type90)
                        (local.get $4)
                       )
                      )
                     )
                    )
                   )
                  )
                  (i64.const 0)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1596)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 10)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1596)
                     )
                    )
                    (i64.eq
                     (local.get $1)
                     (i64.const 13)
                    )
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready1599)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1599)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1588)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global152)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global139)
                  )
                 )
                 (local.set $2
                  (call $function55
                   (local.get $0)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global150)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1590)
                  )
                 )
                 (if (result i32)
                  (if (result i32)
                   (i64.lt_s
                    (local.tee $1
                     (if (result i64)
                      (ref.test (ref $type89)
                       (local.tee $4
                        (if (result (ref $type88))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty89)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type90
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                      )
                      (then
                       (i64.const -1)
                      )
                      (else
                       (i64.extend_i32_u
                        (struct.get $type90 0
                         (ref.cast (ref $type90)
                          (local.get $4)
                         )
                        )
                       )
                      )
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1596)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 10)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1596)
                       )
                      )
                      (i64.eq
                       (local.get $1)
                       (i64.const 13)
                      )
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if
                    (i32.eqz
                     (global.get $ready1599)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1599)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1588)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global152)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global139)
                    )
                   )
                   (local.set $2
                    (call $function55
                     (local.get $0)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global150)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1590)
                    )
                   )
                   (if (result i32)
                    (if (result i32)
                     (i64.lt_s
                      (local.tee $1
                       (if (result i64)
                        (ref.test (ref $type89)
                         (local.tee $4
                          (if (result (ref $type88))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty89)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type90
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type90 0
                           (ref.cast (ref $type90)
                            (local.get $4)
                           )
                          )
                         )
                        )
                       )
                      )
                      (i64.const 0)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1596)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1596)
                         )
                        )
                        (i64.eq
                         (local.get $1)
                         (i64.const 13)
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if
                      (i32.eqz
                       (global.get $ready1599)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1599)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1588)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global152)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global139)
                      )
                     )
                     (local.set $2
                      (call $function55
                       (local.get $0)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global150)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1590)
                      )
                     )
                     (if (result i32)
                      (if (result i32)
                       (i64.lt_s
                        (local.tee $1
                         (if (result i64)
                          (ref.test (ref $type89)
                           (local.tee $4
                            (if (result (ref $type88))
                             (i32.eq
                              (local.get $2)
                              (i32.const -1)
                             )
                             (then
                              (global.get $empty89)
                             )
                             (else
                              (if
                               (i64.gt_u
                                (local.tee $1
                                 (i64.extend_i32_s
                                  (local.get $2)
                                 )
                                )
                                (i64.const 1114111)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (if
                               (i32.and
                                (i64.le_u
                                 (local.get $1)
                                 (i64.const 57343)
                                )
                                (i64.ge_u
                                 (local.get $1)
                                 (i64.const 55296)
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (struct.new $type90
                               (i32.wrap_i64
                                (local.get $1)
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i64.const -1)
                          )
                          (else
                           (i64.extend_i32_u
                            (struct.get $type90 0
                             (ref.cast (ref $type90)
                              (local.get $4)
                             )
                            )
                           )
                          )
                         )
                        )
                        (i64.const 0)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1596)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 10)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1596)
                           )
                          )
                          (i64.eq
                           (local.get $1)
                           (i64.const 13)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready1599)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1599)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1588)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global152)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global139)
                        )
                       )
                       (local.set $2
                        (call $function55
                         (local.get $0)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global150)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1590)
                        )
                       )
                       (if (result i32)
                        (if (result i32)
                         (i64.lt_s
                          (local.tee $1
                           (if (result i64)
                            (ref.test (ref $type89)
                             (local.tee $4
                              (if (result (ref $type88))
                               (i32.eq
                                (local.get $2)
                                (i32.const -1)
                               )
                               (then
                                (global.get $empty89)
                               )
                               (else
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (i64.extend_i32_s
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 1114111)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (if
                                 (i32.and
                                  (i64.le_u
                                   (local.get $1)
                                   (i64.const 57343)
                                  )
                                  (i64.ge_u
                                   (local.get $1)
                                   (i64.const 55296)
                                  )
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (struct.new $type90
                                 (i32.wrap_i64
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (then
                             (i64.const -1)
                            )
                            (else
                             (i64.extend_i32_u
                              (struct.get $type90 0
                               (ref.cast (ref $type90)
                                (local.get $4)
                               )
                              )
                             )
                            )
                           )
                          )
                          (i64.const 0)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1596)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 10)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (i64.eq
                             (local.get $1)
                             (i64.const 13)
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if
                          (i32.eqz
                           (global.get $ready1599)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1599)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1588)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global152)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global139)
                          )
                         )
                         (local.set $2
                          (call $function55
                           (local.get $0)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global150)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1590)
                          )
                         )
                         (if (result i32)
                          (if (result i32)
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type89)
                               (local.tee $4
                                (if (result (ref $type88))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty89)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type90
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type90 0
                                 (ref.cast (ref $type90)
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 10)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1596)
                               )
                              )
                              (i64.eq
                               (local.get $1)
                               (i64.const 13)
                              )
                             )
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if
                            (i32.eqz
                             (global.get $ready1599)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1599)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1588)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global152)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global139)
                            )
                           )
                           (local.set $2
                            (call $function55
                             (local.get $0)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global150)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1590)
                            )
                           )
                           (if (result i32)
                            (if (result i32)
                             (i64.lt_s
                              (local.tee $1
                               (if (result i64)
                                (ref.test (ref $type89)
                                 (local.tee $4
                                  (if (result (ref $type88))
                                   (i32.eq
                                    (local.get $2)
                                    (i32.const -1)
                                   )
                                   (then
                                    (global.get $empty89)
                                   )
                                   (else
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (i64.extend_i32_s
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 1114111)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (if
                                     (i32.and
                                      (i64.le_u
                                       (local.get $1)
                                       (i64.const 57343)
                                      )
                                      (i64.ge_u
                                       (local.get $1)
                                       (i64.const 55296)
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (struct.new $type90
                                     (i32.wrap_i64
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i64.const -1)
                                )
                                (else
                                 (i64.extend_i32_u
                                  (struct.get $type90 0
                                   (ref.cast (ref $type90)
                                    (local.get $4)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (i64.const 0)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1596)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 10)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1596)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 13)
                                )
                               )
                              )
                             )
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if
                              (i32.eqz
                               (global.get $ready1599)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1599)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1588)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global152)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global139)
                              )
                             )
                             (local.set $2
                              (call $function55
                               (local.get $0)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global150)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1590)
                              )
                             )
                             (if (result i32)
                              (if (result i32)
                               (i64.lt_s
                                (local.tee $1
                                 (if (result i64)
                                  (ref.test (ref $type89)
                                   (local.tee $4
                                    (if (result (ref $type88))
                                     (i32.eq
                                      (local.get $2)
                                      (i32.const -1)
                                     )
                                     (then
                                      (global.get $empty89)
                                     )
                                     (else
                                      (if
                                       (i64.gt_u
                                        (local.tee $1
                                         (i64.extend_i32_s
                                          (local.get $2)
                                         )
                                        )
                                        (i64.const 1114111)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (if
                                       (i32.and
                                        (i64.le_u
                                         (local.get $1)
                                         (i64.const 57343)
                                        )
                                        (i64.ge_u
                                         (local.get $1)
                                         (i64.const 55296)
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (struct.new $type90
                                       (i32.wrap_i64
                                        (local.get $1)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const -1)
                                  )
                                  (else
                                   (i64.extend_i32_u
                                    (struct.get $type90 0
                                     (ref.cast (ref $type90)
                                      (local.get $4)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i64.const 0)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1596)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 10)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1596)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $1)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if
                                (i32.eqz
                                 (global.get $ready1599)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1599)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1588)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global152)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global139)
                                )
                               )
                               (local.set $2
                                (call $function55
                                 (local.get $0)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global150)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1590)
                                )
                               )
                               (if (result i32)
                                (if (result i32)
                                 (i64.lt_s
                                  (local.tee $1
                                   (if (result i64)
                                    (ref.test (ref $type89)
                                     (local.tee $4
                                      (if (result (ref $type88))
                                       (i32.eq
                                        (local.get $2)
                                        (i32.const -1)
                                       )
                                       (then
                                        (global.get $empty89)
                                       )
                                       (else
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (i64.extend_i32_s
                                            (local.get $2)
                                           )
                                          )
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type90
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const -1)
                                    )
                                    (else
                                     (i64.extend_i32_u
                                      (struct.get $type90 0
                                       (ref.cast (ref $type90)
                                        (local.get $4)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1596)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 10)
                                   )
                                   (then
                                    (i32.const 1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1596)
                                     )
                                    )
                                    (i64.eq
                                     (local.get $1)
                                     (i64.const 13)
                                    )
                                   )
                                  )
                                 )
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (if
                                  (i32.eqz
                                   (global.get $ready1599)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1599)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1588)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global152)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global139)
                                  )
                                 )
                                 (local.set $2
                                  (call $function55
                                   (local.get $0)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global150)
                                  )
                                 )
                                 (local.set $4
                                  (if (result (ref $type88))
                                   (i32.eq
                                    (local.get $2)
                                    (i32.const -1)
                                   )
                                   (then
                                    (global.get $empty89)
                                   )
                                   (else
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (i64.extend_i32_s
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 1114111)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (if
                                     (i32.and
                                      (i64.le_u
                                       (local.get $1)
                                       (i64.const 57343)
                                      )
                                      (i64.ge_u
                                       (local.get $1)
                                       (i64.const 55296)
                                      )
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (struct.new $type90
                                     (i32.wrap_i64
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1590)
                                  )
                                 )
                                 (if (result i32)
                                  (if (result i32)
                                   (i64.lt_s
                                    (local.tee $1
                                     (if (result i64)
                                      (ref.test (ref $type89)
                                       (local.get $4)
                                      )
                                      (then
                                       (i64.const -1)
                                      )
                                      (else
                                       (i64.extend_i32_u
                                        (struct.get $type90 0
                                         (ref.cast (ref $type90)
                                          (local.get $4)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                   (then
                                    (i32.const 1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1596)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 10)
                                     )
                                     (then
                                      (i32.const 1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1596)
                                       )
                                      )
                                      (i64.eq
                                       (local.get $1)
                                       (i64.const 13)
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (if
                                    (i32.eqz
                                     (global.get $ready1599)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1599)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1588)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global152)
                                    )
                                   )
                                   (if (result i32)
                                    (if (result i32)
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function420
                                        (block (result (ref $type88))
                                         (local.set $scratch
                                          (call $function59
                                           (local.get $0)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1590)
                                          )
                                         )
                                         (local.get $scratch)
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (i32.const 1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1596)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 10)
                                       )
                                       (then
                                        (i32.const 1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1596)
                                         )
                                        )
                                        (i64.eq
                                         (local.get $1)
                                         (i64.const 13)
                                        )
                                       )
                                      )
                                     )
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if
                                      (i32.eqz
                                       (global.get $ready1599)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1599)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1588)
                                      )
                                     )
                                     (if (result i32)
                                      (if (result i32)
                                       (i64.lt_s
                                        (local.tee $1
                                         (call $function419
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                       (then
                                        (i32.const 1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1596)
                                         )
                                        )
                                        (if (result i32)
                                         (call $function422
                                          (local.get $1)
                                          (i32.const 10)
                                         )
                                         (then
                                          (i32.const 1)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1596)
                                           )
                                          )
                                          (call $function422
                                           (local.get $1)
                                           (i32.const 13)
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (if
                                        (i32.eqz
                                         (global.get $ready1599)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1599)
                                        )
                                       )
                                       (call $function423
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready1602)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1602)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (return
         (if (result (ref $type277))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type282
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global1596)
            )
           )
           (if (result (ref $type277))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty280)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1596)
              )
             )
             (if (result (ref $type277))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type283
                (i32.const 5)
                (global.get $string33)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1596)
                )
               )
               (if (result (ref $type277))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type283
                  (i32.const 5)
                  (global.get $string32)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global1596)
                  )
                 )
                 (if (result (ref $type277))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global1605)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1608)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global154)
                    )
                   )
                   (local.set $4
                    (call $function60
                     (local.get $0)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1590)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1596)
                    )
                   )
                   (struct.new $type283
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string31)
                     (global.get $string30)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type89)
                         (local.get $4)
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type90 0
                           (ref.cast (ref $type90)
                            (local.get $4)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global152)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global139)
                        )
                       )
                       (local.set $2
                        (call $function55
                         (local.get $0)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global150)
                        )
                       )
                       (drop
                        (if (result (ref $type88))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty89)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type90
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global1596)
                    )
                   )
                   (if (result (ref $type284))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready1610)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1610)
                      )
                     )
                     (return_call $function427
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global1596)
                      )
                     )
                     (if (result (ref $type284))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready1610)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1610)
                        )
                       )
                       (return_call $function427
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global1596)
                        )
                       )
                       (if (result (ref $type284))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready1673)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1673)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1588)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global152)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global139)
                          )
                         )
                         (local.set $2
                          (call $function55
                           (local.get $0)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global150)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1590)
                          )
                         )
                         (return
                          (if (result (ref $type277))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type89)
                               (local.tee $4
                                (if (result (ref $type88))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty89)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type90
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type90 0
                                 (ref.cast (ref $type90)
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type284
                             (i32.const 6)
                             (global.get $string44)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (if (result (ref $type277))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type282
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1596)
                               )
                              )
                              (if (result (ref $type277))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1676)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1583)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready1585)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1585)
                                 )
                                )
                                (local.set $12
                                 (call $function418
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready1727)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1727)
                                 )
                                )
                                (if (result (ref $type284))
                                 (i32.eq
                                  (struct.get $type226 0
                                   (local.tee $10
                                    (call $function460
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type228)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type284))
                                   (struct.get $type226 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type284
                                     (i32.const 6)
                                     (struct.get $type229 1
                                      (ref.cast (ref $type229)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type284
                                     (i32.const 6)
                                     (global.get $string45)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1596)
                                 )
                                )
                                (if (result (ref $type277))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1681)
                                   )
                                  )
                                  (if (result (ref $type284))
                                   (call $function446
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1585)
                                     )
                                    )
                                    (return_call $function418
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type284
                                     (i32.const 6)
                                     (global.get $string43)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1596)
                                   )
                                  )
                                  (if (result (ref $type277))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready1685)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1685)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1588)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global152)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global139)
                                     )
                                    )
                                    (local.set $2
                                     (call $function55
                                      (local.get $0)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global150)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1590)
                                     )
                                    )
                                    (if (result (ref $type277))
                                     (i64.lt_s
                                      (local.tee $1
                                       (if (result i64)
                                        (ref.test (ref $type89)
                                         (local.tee $4
                                          (if (result (ref $type88))
                                           (i32.eq
                                            (local.get $2)
                                            (i32.const -1)
                                           )
                                           (then
                                            (global.get $empty89)
                                           )
                                           (else
                                            (if
                                             (i64.gt_u
                                              (local.tee $1
                                               (i64.extend_i32_s
                                                (local.get $2)
                                               )
                                              )
                                              (i64.const 1114111)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (if
                                             (i32.and
                                              (i64.le_u
                                               (local.get $1)
                                               (i64.const 57343)
                                              )
                                              (i64.ge_u
                                               (local.get $1)
                                               (i64.const 55296)
                                              )
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (struct.new $type90
                                             (i32.wrap_i64
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const -1)
                                        )
                                        (else
                                         (i64.extend_i32_u
                                          (struct.get $type90 0
                                           (ref.cast (ref $type90)
                                            (local.get $4)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type284
                                       (i32.const 6)
                                       (global.get $string46)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1688)
                                       )
                                      )
                                      (if (result (ref $type278))
                                       (call $function448
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type278
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1690)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1618)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type269
                                          (struct.new $type270
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type69)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1657)
                                         )
                                        )
                                        (call $function441
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $5
                                         (call $function450
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 1)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready1695)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global1695)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type277))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $5)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (array.get $type19
                                             (struct.get $type18 2
                                              (local.get $5)
                                             )
                                             (i32.const 0)
                                            )
                                           )
                                           (struct.new $type278
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global1698)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global86)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global61)
                                            )
                                           )
                                           (if
                                            (i64.gt_u
                                             (local.tee $1
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $5)
                                               )
                                              )
                                             )
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (call $string-copy
                                            (local.tee $6
                                             (call $string-new
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                            (i64.const 0)
                                            (local.get $5)
                                            (local.get $1)
                                           )
                                           (local.set $5
                                            (call $function453
                                             (local.get $6)
                                             (i32.const 1)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready1704)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global1704)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global101)
                                            )
                                           )
                                           (if (result (ref $type277))
                                            (struct.get $type295 0
                                             (local.tee $11
                                              (if (result (ref $type295))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $5)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $5)
                                                  (global.get $string56)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type296
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global101)
                                                 )
                                                )
                                                (if (result (ref $type295))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $5)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $5)
                                                    (global.get $string55)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type296
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global101)
                                                   )
                                                  )
                                                  (if (result (ref $type295))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $5)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $5)
                                                      (global.get $string54)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type296
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global101)
                                                     )
                                                    )
                                                    (if (result (ref $type295))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $5)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $5)
                                                        (global.get $string53)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type296
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global101)
                                                       )
                                                      )
                                                      (if (result (ref $type295))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $5)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $5)
                                                          (global.get $string52)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type296
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global101)
                                                         )
                                                        )
                                                        (if (result (ref $type295))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $5)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $5)
                                                            (global.get $string51)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type296)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global101)
                                                           )
                                                          )
                                                          (if (result (ref $type295))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $5)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $5)
                                                              (global.get $string50)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type296
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global101)
                                                             )
                                                            )
                                                            (if (result (ref $type295))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $5)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $5)
                                                                (global.get $string49)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type296
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global101)
                                                               )
                                                              )
                                                              (if (result (ref $type295))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $5)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $5)
                                                                  (global.get $string48)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type296
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $5)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type295))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $5)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global1706)
                                                                   )
                                                                  )
                                                                  (call $function456
                                                                   (local.get $5)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type298
                                                                   (i32.const 2)
                                                                   (global.get $string47)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type284))
                                              (i32.eq
                                               (struct.get $type295 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type284
                                                (i32.const 6)
                                                (struct.get $type298 1
                                                 (ref.cast (ref $type298)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (drop
                                              (ref.cast (ref $type296)
                                               (local.get $11)
                                              )
                                             )
                                             (struct.new $type278
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1596)
                                     )
                                    )
                                    (if (result (ref $type277))
                                     (if (result i32)
                                      (i64.eq
                                       (local.get $1)
                                       (i64.const 117)
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1596)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready1714)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1714)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1605)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1608)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global154)
                                       )
                                      )
                                      (local.set $4
                                       (call $function60
                                        (local.get $0)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1590)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1596)
                                       )
                                      )
                                      (if (result (ref $type277))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type89)
                                            (local.get $4)
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type90 0
                                              (ref.cast (ref $type90)
                                               (local.get $4)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global152)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global139)
                                           )
                                          )
                                          (local.set $2
                                           (call $function55
                                            (local.get $0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global150)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type88))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty89)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type90
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1605)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1608)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global154)
                                          )
                                         )
                                         (local.set $4
                                          (call $function60
                                           (local.get $0)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1590)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1596)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type89)
                                             (local.get $4)
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type90 0
                                               (ref.cast (ref $type90)
                                                (local.get $4)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global152)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global139)
                                            )
                                           )
                                           (local.set $2
                                            (call $function55
                                             (local.get $0)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global150)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type88))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty89)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type90
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type282
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type284
                                         (i32.const 6)
                                         (global.get $string58)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global1596)
                                       )
                                      )
                                      (if (result (ref $type277))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type284
                                         (i32.const 6)
                                         (global.get $string42)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type277))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type284
                                           (i32.const 6)
                                           (global.get $string41)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1690)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1618)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type269
                                            (struct.new $type270
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type69)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1657)
                                           )
                                          )
                                          (call $function441
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $5
                                           (call $function450
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 1)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (local.set $6
                                           (call $function35
                                            (struct.new $type61
                                             (global.get $string40)
                                             (struct.new $type61
                                              (local.get $5)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready1716)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1716)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global1698)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global86)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.tee $1
                                             (i64.extend_i32_u
                                              (struct.get $type18 1
                                               (local.get $6)
                                              )
                                             )
                                            )
                                            (i64.const 4294967294)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $string-copy
                                           (local.tee $7
                                            (call $string-new
                                             (i32.wrap_i64
                                              (local.get $1)
                                             )
                                            )
                                           )
                                           (i64.const 0)
                                           (local.get $6)
                                           (local.get $1)
                                          )
                                          (local.set $5
                                           (call $function453
                                            (local.get $7)
                                            (i32.const 1)
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global101)
                                           )
                                          )
                                          (if (result (ref $type277))
                                           (if (result i32)
                                            (if (result i32)
                                             (i64.eq
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $5)
                                               )
                                              )
                                              (i64.const 2)
                                             )
                                             (then
                                              (call $function40
                                               (local.get $5)
                                               (global.get $string63)
                                               (i32.const 0)
                                               (i32.const 1)
                                               (i64.const 0)
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                            (then
                                             (i32.const 1)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global101)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $5)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $5)
                                                (global.get $string62)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type278
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global101)
                                             )
                                            )
                                            (if (result (ref $type277))
                                             (if (result i32)
                                              (if (result i32)
                                               (i64.eq
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $5)
                                                 )
                                                )
                                                (i64.const 2)
                                               )
                                               (then
                                                (call $function40
                                                 (local.get $5)
                                                 (global.get $string61)
                                                 (i32.const 0)
                                                 (i32.const 1)
                                                 (i64.const 0)
                                                )
                                               )
                                               (else
                                                (i32.const 0)
                                               )
                                              )
                                              (then
                                               (i32.const 1)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global101)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $5)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $5)
                                                  (global.get $string60)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type278
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1215)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1209)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1140)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign36
                                                (local.tee $2
                                                 (call $function314
                                                  (local.get $6)
                                                  (call $foreign19)
                                                  (i32.const 1)
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (local.get $6)
                                                   )
                                                  )
                                                  (i32.const 1)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (i32.const 10)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global1206)
                                               )
                                              )
                                              (local.set $8
                                               (call $function329
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign22
                                               (local.get $2)
                                              )
                                              (if (result (ref $type277))
                                               (i32.eq
                                                (struct.get $type219 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type278
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type221 1
                                                   (ref.cast (ref $type221)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type284))
                                                 (i32.eq
                                                  (struct.get $type219 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type284
                                                   (i32.const 6)
                                                   (struct.get $type222 1
                                                    (ref.cast (ref $type222)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type284
                                                   (i32.const 6)
                                                   (global.get $string59)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global1596)
                          )
                         )
                         (if (result (ref $type284))
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 91)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 93)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1596)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 123)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1596)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type284
                            (i32.const 6)
                            (global.get $string29)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global1690)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1618)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type269
                             (struct.new $type270
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type69)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1657)
                            )
                           )
                           (call $function441
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $5
                            (call $function450
                             (local.get $0)
                             (local.get $9)
                             (i32.const 1)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1722)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1722)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global101)
                            )
                           )
                           (return
                            (if (result (ref $type277))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $5)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $5)
                                (global.get $string64)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty281)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1224)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global1140)
                               )
                              )
                              (if (result (ref $type277))
                               (i32.eq
                                (struct.get $type226 0
                                 (local.tee $10
                                  (if (result (ref $type226))
                                   (local.tee $3
                                    (call $foreign37
                                     (local.tee $2
                                      (call $function314
                                       (local.get $5)
                                       (call $foreign19)
                                       (i32.const 1)
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (local.get $5)
                                        )
                                       )
                                       (i32.const 1)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.const 0)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1217)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global1206)
                                     )
                                    )
                                    (local.set $8
                                     (call $function329
                                      (local.get $2)
                                      (local.get $3)
                                     )
                                    )
                                    (call $foreign22
                                     (local.get $2)
                                    )
                                    (if (result (ref $type226))
                                     (i32.eq
                                      (struct.get $type219 0
                                       (local.get $8)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type228
                                       (i32.const 1)
                                       (struct.new $type23
                                        (i32.const 5)
                                        (struct.get $type221 1
                                         (ref.cast (ref $type221)
                                          (local.get $8)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (if (result (ref $type229))
                                       (i32.eq
                                        (struct.get $type219 0
                                         (local.get $8)
                                        )
                                        (i32.const 2)
                                       )
                                       (then
                                        (struct.new $type229
                                         (i32.const 2)
                                         (struct.get $type222 1
                                          (ref.cast (ref $type222)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (if (result (ref $type226))
                                     (i32.eq
                                      (call $foreign23
                                       (local.get $2)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (drop
                                       (call $foreign24
                                        (local.get $2)
                                       )
                                      )
                                      (struct.new $type228
                                       (i32.const 1)
                                       (struct.new $type21
                                        (i32.const 4)
                                       )
                                      )
                                     )
                                     (else
                                      (call $foreign22
                                       (local.get $2)
                                      )
                                      (struct.new $type229
                                       (i32.const 2)
                                       (global.get $string9)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type278
                                 (i32.const 0)
                                 (struct.get $type228 1
                                  (ref.cast (ref $type228)
                                   (local.get $10)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type284))
                                 (i32.eq
                                  (struct.get $type226 0
                                   (local.get $10)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type284
                                   (i32.const 6)
                                   (struct.get $type229 1
                                    (ref.cast (ref $type229)
                                     (local.get $10)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (unreachable)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready1585)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1585)
   )
  )
  (return_call $function418
   (local.get $0)
  )
 )
 (func $function419 (type $call84) (param $0 (ref $type68)) (result i64)
  (local $1 (ref $type88))
  (local $scratch (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (return_call $function420
   (block (result (ref $type88))
    (local.set $scratch
     (call $function59
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1590)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function420 (type $call264) (param $0 (ref $type88)) (result i64)
  (if (result i64)
   (ref.test (ref $type89)
    (local.get $0)
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type90 0
      (ref.cast (ref $type90)
       (local.get $0)
      )
     )
    )
   )
  )
 )
 (func $function422 (type $call265) (param $0 i64) (param $1 i32) (result i32)
  (i64.eq
   (i64.extend_i32_u
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $function423 (type $call77) (param $0 (ref $type68)) (result i32)
  (local $1 i64)
  (drop
   (ref.as_non_null
    (global.get $global1588)
   )
  )
  (if (result i32)
   (if (result i32)
    (i64.lt_s
     (local.tee $1
      (call $function419
       (local.get $0)
      )
     )
     (i64.const 0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1596)
      )
     )
     (if (result i32)
      (call $function422
       (local.get $1)
       (i32.const 10)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1596)
        )
       )
       (call $function422
        (local.get $1)
        (i32.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready1599)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1599)
     )
    )
    (return_call $function423
     (local.get $0)
    )
   )
  )
 )
 (func $function427 (type $call287) (param $0 (ref $type68)) (param $1 i32) (param $2 i32) (result (ref $type277))
  (local $3 (ref $type18))
  (local $4 (ref $type289))
  (local $5 (ref $type269))
  (if
   (i32.eqz
    (global.get $ready1615)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1615)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1618)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $5
   (struct.new $type269
    (struct.new $type270
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type69)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1619)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1619)
   )
  )
  (if (result (ref $type277))
   (ref.test (ref $type290)
    (local.tee $4
     (call $function430
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type290 0
      (ref.cast (ref $type290)
       (local.get $4)
      )
     )
    )
    (struct.new $type278
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global1154)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1140)
        )
       )
       (drop
        (call $foreign24
         (call $function314
          (local.get $3)
          (call $foreign19)
          (i32.const 1)
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $3)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
       )
       (struct.new $type21
        (i32.const 4)
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
        (local.get $3)
       )
      )
     )
    )
   )
   (else
    (struct.new $type284
     (i32.const 6)
     (struct.get $type291 0
      (ref.cast (ref $type291)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function430 (type $call292) (param $0 (ref $type68)) (param $1 i32) (param $2 (ref $type269)) (result (ref $type289))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type88))
  (local $6 (ref $type295))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global1588)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $4
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (block $block
   (return
    (if (result (ref $type289))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type89)
         (local.tee $5
          (if (result (ref $type88))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty89)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type90
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type90 0
           (ref.cast (ref $type90)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type291
       (global.get $string34)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1596)
       )
      )
      (if (result (ref $type289))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1624)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (struct.new $type290
         (if (result (ref $type18))
          (i32.or
           (i64.lt_s
            (local.tee $3
             (struct.get $type69 0
              (struct.get $type269 1
               (local.get $2)
              )
             )
            )
            (i64.const 0)
           )
           (i64.lt_s
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.tee $7
               (struct.get $type270 0
                (struct.get $type269 0
                 (local.get $2)
                )
               )
              )
             )
            )
            (local.get $3)
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (if (result (ref $type291))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready1626)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1626)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1588)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global152)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.set $4
           (call $function55
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global150)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1590)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1596)
           )
          )
          (local.set $6
           (if (result (ref $type295))
            (i64.eq
             (local.tee $3
              (if (result i64)
               (ref.test (ref $type89)
                (local.tee $5
                 (if (result (ref $type88))
                  (i32.eq
                   (local.get $4)
                   (i32.const -1)
                  )
                  (then
                   (global.get $empty89)
                  )
                  (else
                   (if
                    (i64.gt_u
                     (local.tee $3
                      (i64.extend_i32_s
                       (local.get $4)
                      )
                     )
                     (i64.const 1114111)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if
                    (i32.and
                     (i64.le_u
                      (local.get $3)
                      (i64.const 57343)
                     )
                     (i64.ge_u
                      (local.get $3)
                      (i64.const 55296)
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (struct.new $type90
                    (i32.wrap_i64
                     (local.get $3)
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const -1)
               )
               (else
                (i64.extend_i32_u
                 (struct.get $type90 0
                  (ref.cast (ref $type90)
                   (local.get $5)
                  )
                 )
                )
               )
              )
             )
             (i64.const 97)
            )
            (then
             (struct.new $type296
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1596)
              )
             )
             (if (result (ref $type295))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type296
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global1596)
                )
               )
               (if (result (ref $type295))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type296
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global1596)
                  )
                 )
                 (if (result (ref $type295))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type296
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global1596)
                    )
                   )
                   (if (result (ref $type295))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type296
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global1596)
                      )
                     )
                     (if (result (ref $type295))
                      (if (result i32)
                       (i64.eq
                        (local.get $3)
                        (i64.const 34)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1596)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $3)
                          (i64.const 124)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1596)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type296
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global1596)
                        )
                       )
                       (if (result (ref $type295))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready1630)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1630)
                          )
                         )
                         (call $function433
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type295))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready1643)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global1643)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $3)
                              (i64.const 32)
                             )
                             (then
                              (i32.const 1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global1596)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $3)
                                (i64.const 9)
                               )
                               (then
                                (i32.const 1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global1596)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $3)
                                  (i64.const 10)
                                 )
                                 (then
                                  (i32.const 1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global1596)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready1645)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1645)
                            )
                           )
                           (call $function438
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type298
                            (i32.const 2)
                            (global.get $string35)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1650)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1650)
           )
          )
          (if (result (ref $type291))
           (local.tee $4
            (struct.get $type295 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type291))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type291
               (struct.get $type298 1
                (ref.cast (ref $type298)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1657)
             )
            )
            (call $function441
             (local.get $2)
             (struct.get $type296 1
              (ref.cast (ref $type296)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready1667)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1667)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global1596)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global1605)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1608)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global154)
              )
             )
             (local.set $5
              (call $function60
               (local.get $0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1590)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1596)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type89)
                 (local.get $5)
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type90 0
                   (ref.cast (ref $type90)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global152)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global139)
                )
               )
               (local.set $4
                (call $function55
                 (local.get $0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global150)
                )
               )
               (drop
                (if (result (ref $type88))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty89)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type90
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1657)
           )
          )
          (call $function441
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready1619)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1619)
   )
  )
  (return_call $function430
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function433 (type $call302) (param $0 (ref $type68)) (param $1 i64) (param $2 i64) (result (ref $type295))
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global1588)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $5
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1596)
   )
  )
  (if (result (ref $type295))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type89)
       (local.tee $6
        (if (result (ref $type88))
         (i32.eq
          (local.get $5)
          (i32.const -1)
         )
         (then
          (global.get $empty89)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $5)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type90
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type90 0
         (ref.cast (ref $type90)
          (local.get $6)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1635)
     )
    )
    (if (result (ref $type295))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1638)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (i32.or
            (i64.lt_s
             (local.get $1)
             (i64.const 55296)
            )
            (i64.gt_s
             (local.get $1)
             (i64.const 57343)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type296
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type298
       (i32.const 2)
       (global.get $string37)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1641)
     )
    )
    (if (result (ref $type298))
     (i32.or
      (i64.lt_s
       (local.tee $3
        (call $function436
         (local.get $3)
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 69631)
      )
     )
     (then
      (struct.new $type298
       (i32.const 2)
       (global.get $string36)
      )
     )
     (else
      (if
       (i64.ne
        (local.get $1)
        (i64.div_s
         (local.tee $4
          (i64.shl
           (local.get $1)
           (i64.const 4)
          )
         )
         (i64.const 16)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.tee $1
           (i64.add
            (local.get $3)
            (local.get $4)
           )
          )
         )
         (i64.xor
          (local.get $1)
          (local.get $3)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $2)
          (local.tee $3
           (i64.add
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $3)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready1630)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1630)
       )
      )
      (return_call $function433
       (local.get $0)
       (local.get $1)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function436 (type $call115) (param $0 i64) (result i64)
  (local $1 i64)
  (if (result i64)
   (i32.and
    (i64.le_s
     (local.get $0)
     (i64.const 57)
    )
    (i64.ge_s
     (local.get $0)
     (i64.const 48)
    )
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $1
         (i64.sub
          (local.get $0)
          (i64.const 48)
         )
        )
        (local.get $0)
       )
       (i64.xor
        (local.get $0)
        (i64.const 48)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $1)
   )
   (else
    (if (result i64)
     (i32.and
      (i64.le_s
       (local.get $0)
       (i64.const 70)
      )
      (i64.ge_s
       (local.get $0)
       (i64.const 65)
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $1
           (i64.sub
            (local.get $0)
            (i64.const 55)
           )
          )
          (local.get $0)
         )
         (i64.xor
          (local.get $0)
          (i64.const 55)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (local.get $1)
     )
     (else
      (if (result i64)
       (i32.and
        (i64.le_s
         (local.get $0)
         (i64.const 102)
        )
        (i64.ge_s
         (local.get $0)
         (i64.const 97)
        )
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $1
             (i64.sub
              (local.get $0)
              (i64.const 87)
             )
            )
            (local.get $0)
           )
           (i64.xor
            (local.get $0)
            (i64.const 87)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (local.get $1)
       )
       (else
        (i64.const -1)
       )
      )
     )
    )
   )
  )
 )
 (func $function438 (type $call300) (param $0 (ref $type68)) (param $1 i64) (result (ref $type295))
  (local $2 i32)
  (local $3 (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global1596)
   )
  )
  (if (result (ref $type295))
   (if (result i32)
    (i64.eq
     (local.get $1)
     (i64.const 32)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1596)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1588)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $2
     (call $function55
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1590)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type89)
       (local.tee $3
        (if (result (ref $type88))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty89)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type90
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type90 0
         (ref.cast (ref $type90)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1645)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1645)
     )
    )
    (return_call $function438
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1596)
     )
    )
    (if (result (ref $type295))
     (if (result i32)
      (i64.eq
       (local.get $1)
       (i64.const 10)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1596)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1596)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1605)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1608)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global154)
         )
        )
        (local.set $3
         (call $function60
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1590)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type89)
            (local.get $3)
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type90 0
              (ref.cast (ref $type90)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global152)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global139)
           )
          )
          (local.set $2
           (call $function55
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global150)
           )
          )
          (drop
           (if (result (ref $type88))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty89)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type90
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1648)
       )
      )
      (drop
       (call $function439
        (local.get $0)
       )
      )
      (global.get $empty297)
     )
     (else
      (struct.new $type298
       (i32.const 2)
       (global.get $string38)
      )
     )
    )
   )
  )
 )
 (func $function439 (type $call77) (param $0 (ref $type68)) (result i32)
  (local $1 (ref $type88))
  (local $2 i64)
  (local $3 i32)
  (drop
   (ref.as_non_null
    (global.get $global1608)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (local.set $1
   (call $function60
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1596)
   )
  )
  (if (result i32)
   (if (result i32)
    (i64.eq
     (if (result i64)
      (ref.test (ref $type89)
       (local.get $1)
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type90 0
         (ref.cast (ref $type90)
          (local.get $1)
         )
        )
       )
      )
     )
     (i64.const 32)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global1608)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global154)
      )
     )
     (local.set $1
      (call $function60
       (local.get $0)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1590)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global1596)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type89)
        (local.get $1)
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type90 0
          (ref.cast (ref $type90)
           (local.get $1)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $3
     (call $function55
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (drop
     (if (result (ref $type88))
      (i32.eq
       (local.get $3)
       (i32.const -1)
      )
      (then
       (global.get $empty89)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $2
          (i64.extend_i32_s
           (local.get $3)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $2)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $2)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type90
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1648)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1648)
     )
    )
    (return_call $function439
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function441 (type $26) (param $0 (ref $type269)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type270))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type69 0
      (struct.get $type269 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type270 0
       (struct.get $type269 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready1661)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1661)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1148)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1140)
       )
      )
      (call $foreign21
       (call $function314
        (global.get $string39)
        (call $foreign19)
        (i32.const 1)
        (i64.const 35)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (if (result i64)
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
          (then
           (i64.const 4294967294)
          )
          (else
           (if
            (i64.ne
             (i64.div_s
              (local.tee $3
               (i64.shl
                (local.get $2)
                (i64.const 1)
               )
              )
              (i64.const 2)
             )
             (local.get $2)
            )
            (then
             (unreachable)
            )
           )
           (local.get $3)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type270 0
        (local.tee $7
         (struct.get $type269 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type270 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type270 0
       (struct.get $type269 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (if
   (i64.lt_s
    (i64.and
     (i64.xor
      (local.get $2)
      (local.tee $3
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
     (i64.xor
      (local.get $3)
      (i64.const 1)
     )
    )
    (i64.const 0)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type69 0
   (struct.get $type269 1
    (local.get $0)
   )
   (local.get $3)
  )
 )
 (func $function446 (type $call275) (param $0 (ref $type68)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global1588)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $4
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (block $block
   (return
    (if (result i32)
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type89)
         (local.tee $5
          (if (result (ref $type88))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty89)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type90
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type90 0
           (ref.cast (ref $type90)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1596)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 35)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1605)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1608)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global154)
          )
         )
         (local.set $5
          (call $function60
           (local.get $0)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1590)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1596)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type89)
             (local.get $5)
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type90 0
               (ref.cast (ref $type90)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 124)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global152)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global139)
            )
           )
           (local.set $4
            (call $function55
             (local.get $0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global150)
            )
           )
           (drop
            (if (result (ref $type88))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty89)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type90
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.get $1)
            (local.tee $1
             (i64.add
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (i64.xor
            (local.get $1)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (br $block)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (br_if $block
         (i32.eqz
          (if (result i32)
           (i64.eq
            (local.get $3)
            (i64.const 124)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global1605)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1608)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global154)
             )
            )
            (local.set $5
             (call $function60
              (local.get $0)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1590)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1596)
             )
            )
            (if (result i32)
             (i64.eq
              (if (result i64)
               (ref.test (ref $type89)
                (local.get $5)
               )
               (then
                (i64.const -1)
               )
               (else
                (i64.extend_i32_u
                 (struct.get $type90 0
                  (ref.cast (ref $type90)
                   (local.get $5)
                  )
                 )
                )
               )
              )
              (i64.const 35)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global152)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global139)
               )
              )
              (local.set $4
               (call $function55
                (local.get $0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global150)
               )
              )
              (drop
               (if (result (ref $type88))
                (i32.eq
                 (local.get $4)
                 (i32.const -1)
                )
                (then
                 (global.get $empty89)
                )
                (else
                 (if
                  (i64.gt_u
                   (local.tee $2
                    (i64.extend_i32_s
                     (local.get $4)
                    )
                   )
                   (i64.const 1114111)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.and
                   (i64.le_u
                    (local.get $2)
                    (i64.const 57343)
                   )
                   (i64.ge_u
                    (local.get $2)
                    (i64.const 55296)
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (struct.new $type90
                  (i32.wrap_i64
                   (local.get $2)
                  )
                 )
                )
               )
              )
              (i32.const 1)
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 1)
         )
         (then
          (i32.const 1)
         )
         (else
          (if
           (i64.lt_s
            (i64.and
             (i64.xor
              (local.tee $2
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
              (local.get $1)
             )
             (i64.xor
              (local.get $1)
              (i64.const 1)
             )
            )
            (i64.const 0)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1681)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1681)
           )
          )
          (return_call $function446
           (local.get $0)
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready1681)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1681)
   )
  )
  (return_call $function446
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function448 (type $call267) (param $0 i64) (result i32)
  (if (result i32)
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1594)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.ge_s
       (local.get $0)
       (i64.const 0)
      )
      (then
       (if
        (i64.gt_u
         (local.get $0)
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $0)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $0)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (i32.eq
        (call $foreign38
         (i32.wrap_i64
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global1596)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $0)
        (i64.const 40)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1596)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $0)
          (i64.const 41)
         )
         (then
          (i32.const 1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global1596)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $0)
            (i64.const 34)
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1596)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $0)
              (i64.const 59)
             )
             (then
              (i32.const 1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global1596)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $0)
                (i64.const 124)
               )
               (then
                (i32.const 1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1596)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $0)
                  (i64.const 39)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1596)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $0)
                    (i64.const 96)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global1596)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $0)
                      (i64.const 44)
                     )
                     (then
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global1596)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $0)
                        (i64.const 91)
                       )
                       (then
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global1596)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $0)
                          (i64.const 93)
                         )
                         (then
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global1596)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $0)
                            (i64.const 123)
                           )
                           (then
                            (i32.const 1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global1596)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function450 (type $23) (param $0 (ref $type68)) (param $1 (ref $type269)) (param $2 i32) (param $3 i32) (param $4 i32) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $type88))
  (local $8 (ref $type18))
  (local $9 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global1608)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global154)
   )
  )
  (local.set $7
   (call $function60
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1590)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1688)
   )
  )
  (if (result (ref $type18))
   (call $function448
    (if (result i64)
     (ref.test (ref $type89)
      (local.get $7)
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type90 0
        (ref.cast (ref $type90)
         (local.get $7)
        )
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1624)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (if (result (ref $type18))
     (i32.or
      (i64.lt_s
       (local.tee $5
        (struct.get $type69 0
         (struct.get $type269 1
          (local.get $1)
         )
        )
       )
       (i64.const 0)
      )
      (i64.lt_s
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.tee $8
          (struct.get $type270 0
           (struct.get $type269 0
            (local.get $1)
           )
          )
         )
        )
       )
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $9
        (call $string-new
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
       (i64.const 0)
       (local.get $8)
       (local.get $5)
      )
      (local.get $9)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1588)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global139)
     )
    )
    (local.set $6
     (call $function55
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1590)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (if (result i64)
        (ref.test (ref $type89)
         (local.tee $7
          (if (result (ref $type88))
           (i32.eq
            (local.get $6)
            (i32.const -1)
           )
           (then
            (global.get $empty89)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $5
               (i64.extend_i32_s
                (local.get $6)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $5)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $5)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type90
             (i32.wrap_i64
              (local.get $5)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type90 0
           (ref.cast (ref $type90)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $5)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $5)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1657)
     )
    )
    (call $function441
     (local.get $1)
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function450
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function453 (type $22) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (if
   (i32.eqz
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $5
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $6
             (i32.wrap_i64
              (local.get $4)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $6)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $6)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $5)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $5
         (i64.add
          (local.get $5)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $5)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $5)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $6
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $6)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $6)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $4)
        (local.tee $5
         (i64.add
          (local.get $4)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function453
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $5)
    )
   )
  )
 )
 (func $function456 (type $21) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type295))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result (ref $type295))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.tee $5
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
        (local.get $3)
       )
       (i64.xor
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1635)
     )
    )
    (if (result (ref $type295))
     (if (result i32)
      (i64.gt_s
       (local.get $5)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1638)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (i32.or
            (i64.lt_s
             (local.get $4)
             (i64.const 55296)
            )
            (i64.gt_s
             (local.get $4)
             (i64.const 57343)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type296
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type298
       (i32.const 2)
       (global.get $string37)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1641)
     )
    )
    (if (result (ref $type298))
     (i32.or
      (i64.lt_s
       (local.tee $5
        (call $function436
         (i64.extend_i32_u
          (array.get $type19
           (if (result (ref $type19))
            (i32.lt_u
             (local.tee $7
              (i32.wrap_i64
               (local.get $3)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type18 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type20
               (struct.get $type18 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $7)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $7)
            (i32.const 8191)
           )
          )
         )
        )
       )
       (i64.const 0)
      )
      (i64.gt_s
       (local.get $4)
       (i64.const 69631)
      )
     )
     (then
      (struct.new $type298
       (i32.const 2)
       (global.get $string57)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $6
           (i64.add
            (local.get $3)
            (i64.const 1)
           )
          )
         )
         (i64.xor
          (local.get $6)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ne
        (local.get $4)
        (i64.div_s
         (local.tee $3
          (i64.shl
           (local.get $4)
           (i64.const 4)
          )
         )
         (i64.const 16)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $3)
          (local.tee $4
           (i64.add
            (local.get $3)
            (local.get $5)
           )
          )
         )
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function456
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $6)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function460 (type $call304) (param $0 (ref $type68)) (param $1 (ref $type277)) (result (ref $type226))
  (local $2 (ref $type226))
  (local $3 (ref $type18))
  (local $4 i32)
  (local $5 i64)
  (if (result (ref $type226))
   (local.tee $4
    (struct.get $type277 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type226))
     (i32.eq
      (local.get $4)
      (i32.const 1)
     )
     (then
      (global.get $empty227)
     )
     (else
      (if (result (ref $type226))
       (i32.eq
        (struct.get $type277 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (struct.new $type229
         (i32.const 2)
         (struct.get $type284 1
          (ref.cast (ref $type284)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type226))
         (i32.eq
          (struct.get $type277 0
           (local.get $1)
          )
          (i32.const 4)
         )
         (then
          (local.set $5
           (struct.get $type282 1
            (ref.cast (ref $type282)
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1734)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1734)
           )
          )
          (return_call $function461
           (local.get $0)
           (local.get $5)
           (ref.null none)
          )
         )
         (else
          (if (result (ref $type226))
           (i32.eq
            (struct.get $type277 0
             (local.get $1)
            )
            (i32.const 5)
           )
           (then
            (local.set $3
             (struct.get $type283 1
              (ref.cast (ref $type283)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready1794)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1794)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1583)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1585)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1585)
             )
            )
            (local.set $1
             (call $function418
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1727)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1727)
             )
            )
            (if (result (ref $type226))
             (i32.eq
              (struct.get $type226 0
               (local.tee $2
                (call $function460
                 (local.get $0)
                 (local.get $1)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type228)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1154)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1140)
               )
              )
              (drop
               (call $foreign24
                (call $function314
                 (local.get $3)
                 (call $foreign19)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $3)
                  )
                 )
                 (i32.const 1)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1236)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1231)
               )
              )
              (drop
               (call $function335)
              )
              (drop
               (ref.as_non_null
                (global.get $global1236)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1231)
               )
              )
              (struct.new $type228
               (i32.const 1)
               (call $function335)
              )
             )
             (else
              (if (result (ref $type229))
               (struct.get $type226 0
                (local.get $2)
               )
               (then
                (struct.new $type229
                 (i32.const 2)
                 (struct.get $type229 1
                  (ref.cast (ref $type229)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (struct.new $type229
                 (i32.const 2)
                 (global.get $string76)
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type229))
             (i32.eq
              (struct.get $type277 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type229
               (i32.const 2)
               (global.get $string66)
              )
             )
             (else
              (struct.new $type229
               (i32.const 2)
               (global.get $string65)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type228
     (i32.const 1)
     (struct.get $type278 1
      (ref.cast (ref $type278)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function461 (type $19) (param $0 (ref $type68)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type226))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type36))
  (local $6 (ref $type12))
  (local $7 (ref $type277))
  (local $8 (ref $type226))
  (local $9 (ref $type69))
  (local $10 (ref $type13))
  (local $11 i32)
  (local $12 i64)
  (local $scratch (ref $type36))
  (local $scratch_14 (ref null $type12))
  (local $scratch_15 (ref $type36))
  (drop
   (ref.as_non_null
    (global.get $global1585)
   )
  )
  (if (result (ref $type226))
   (i32.eq
    (struct.get $type277 0
     (local.tee $7
      (call $function418
       (local.get $0)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready1740)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1740)
     )
    )
    (if (result (ref $type228))
     (i64.eqz
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global1743)
       )
      )
      (struct.new $type228
       (i32.const 1)
       (if (result (ref $type13))
        (ref.is_null
         (local.get $2)
        )
        (then
         (global.get $empty14)
        )
        (else
         (local.set $3
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1236)
          )
         )
         (drop
          (struct.get $type12 0
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1231)
          )
         )
         (local.set $5
          (call $function335)
         )
         (if
          (i32.eqz
           (global.get $ready1743)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global1743)
          )
         )
         (if (result (ref $type13))
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $4
            (struct.get $type12 1
             (local.get $3)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1236)
            )
           )
           (drop
            (struct.get $type12 0
             (local.get $3)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1231)
            )
           )
           (local.set $5
            (call $function335)
           )
           (if
            (i32.eqz
             (global.get $ready1743)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1743)
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $4)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $3
              (struct.get $type12 1
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1236)
              )
             )
             (drop
              (struct.get $type12 0
               (local.get $4)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1231)
              )
             )
             (local.set $5
              (call $function335)
             )
             (if
              (i32.eqz
               (global.get $ready1743)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1743)
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $4
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1236)
                )
               )
               (drop
                (struct.get $type12 0
                 (local.get $3)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1231)
                )
               )
               (local.set $5
                (call $function335)
               )
               (if
                (i32.eqz
                 (global.get $ready1743)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global1743)
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $3
                  (struct.get $type12 1
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1236)
                  )
                 )
                 (drop
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1231)
                  )
                 )
                 (local.set $5
                  (call $function335)
                 )
                 (if
                  (i32.eqz
                   (global.get $ready1743)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1743)
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1236)
                    )
                   )
                   (drop
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1231)
                    )
                   )
                   (local.set $5
                    (call $function335)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready1743)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1743)
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1236)
                      )
                     )
                     (drop
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1231)
                      )
                     )
                     (local.set $5
                      (call $function335)
                     )
                     (if
                      (i32.eqz
                       (global.get $ready1743)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1743)
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1236)
                        )
                       )
                       (drop
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1231)
                        )
                       )
                       (local.set $5
                        (call $function335)
                       )
                       (if
                        (i32.eqz
                         (global.get $ready1743)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1743)
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1236)
                          )
                         )
                         (drop
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1231)
                          )
                         )
                         (local.set $5
                          (call $function335)
                         )
                         (if
                          (i32.eqz
                           (global.get $ready1743)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1743)
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $4
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1236)
                            )
                           )
                           (drop
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1231)
                            )
                           )
                           (local.set $5
                            (call $function335)
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1743)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1743)
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $3
                              (struct.get $type12 1
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1236)
                              )
                             )
                             (drop
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1231)
                              )
                             )
                             (local.set $5
                              (call $function335)
                             )
                             (if
                              (i32.eqz
                               (global.get $ready1743)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1743)
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $4
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1236)
                                )
                               )
                               (drop
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1231)
                                )
                               )
                               (local.set $5
                                (call $function335)
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready1743)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1743)
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1236)
                                  )
                                 )
                                 (drop
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1231)
                                  )
                                 )
                                 (local.set $5
                                  (call $function335)
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready1743)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1743)
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (call $function463
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                    (block (result (ref $type36))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1236)
                                      )
                                     )
                                     (drop
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1231)
                                      )
                                     )
                                     (local.set $scratch
                                      (call $function335)
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready1743)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1743)
                                      )
                                     )
                                     (local.get $scratch)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type228))
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global1746)
         )
        )
        (drop
         (call $function379
          (block (result (ref null $type12))
           (local.set $scratch_14
            (if (result (ref null $type12))
             (ref.is_null
              (local.get $2)
             )
             (then
              (ref.null none)
             )
             (else
              (local.set $6
               (struct.new $type12
                (struct.get $type12 0
                 (local.get $2)
                )
                (ref.null none)
               )
              )
              (if (result (ref null $type12))
               (ref.is_null
                (local.tee $3
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
               )
               (then
                (local.get $6)
               )
               (else
                (local.set $6
                 (struct.new $type12
                  (struct.get $type12 0
                   (local.get $3)
                  )
                  (local.get $6)
                 )
                )
                (if (result (ref null $type12))
                 (ref.is_null
                  (local.tee $3
                   (struct.get $type12 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (local.set $6
                   (struct.new $type12
                    (struct.get $type12 0
                     (local.get $3)
                    )
                    (local.get $6)
                   )
                  )
                  (if (result (ref null $type12))
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type12 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (local.get $6)
                   )
                   (else
                    (local.set $6
                     (struct.new $type12
                      (struct.get $type12 0
                       (local.get $3)
                      )
                      (local.get $6)
                     )
                    )
                    (if (result (ref null $type12))
                     (ref.is_null
                      (local.tee $3
                       (struct.get $type12 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (local.set $6
                       (struct.new $type12
                        (struct.get $type12 0
                         (local.get $3)
                        )
                        (local.get $6)
                       )
                      )
                      (if (result (ref null $type12))
                       (ref.is_null
                        (local.tee $3
                         (struct.get $type12 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (local.get $6)
                       )
                       (else
                        (local.set $6
                         (struct.new $type12
                          (struct.get $type12 0
                           (local.get $3)
                          )
                          (local.get $6)
                         )
                        )
                        (if (result (ref null $type12))
                         (ref.is_null
                          (local.tee $3
                           (struct.get $type12 1
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (local.set $6
                           (struct.new $type12
                            (struct.get $type12 0
                             (local.get $3)
                            )
                            (local.get $6)
                           )
                          )
                          (if (result (ref null $type12))
                           (ref.is_null
                            (local.tee $3
                             (struct.get $type12 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (local.get $6)
                           )
                           (else
                            (local.set $6
                             (struct.new $type12
                              (struct.get $type12 0
                               (local.get $3)
                              )
                              (local.get $6)
                             )
                            )
                            (if (result (ref null $type12))
                             (ref.is_null
                              (local.tee $3
                               (struct.get $type12 1
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.get $6)
                             )
                             (else
                              (local.set $6
                               (struct.new $type12
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                                (local.get $6)
                               )
                              )
                              (if (result (ref null $type12))
                               (ref.is_null
                                (local.tee $3
                                 (struct.get $type12 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (local.get $6)
                               )
                               (else
                                (local.set $6
                                 (struct.new $type12
                                  (struct.get $type12 0
                                   (local.get $3)
                                  )
                                  (local.get $6)
                                 )
                                )
                                (if (result (ref null $type12))
                                 (ref.is_null
                                  (local.tee $3
                                   (struct.get $type12 1
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $6)
                                 )
                                 (else
                                  (local.set $6
                                   (struct.new $type12
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                    (local.get $6)
                                   )
                                  )
                                  (if (result (ref null $type12))
                                   (ref.is_null
                                    (local.tee $3
                                     (struct.get $type12 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $6)
                                   )
                                   (else
                                    (local.set $6
                                     (struct.new $type12
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                      (local.get $6)
                                     )
                                    )
                                    (if (result (ref null $type12))
                                     (ref.is_null
                                      (local.tee $3
                                       (struct.get $type12 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $6)
                                     )
                                     (else
                                      (local.set $6
                                       (struct.new $type12
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                        (local.get $6)
                                       )
                                      )
                                      (if (result (ref null $type12))
                                       (ref.is_null
                                        (local.tee $3
                                         (struct.get $type12 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $6)
                                       )
                                       (else
                                        (call $function465
                                         (i32.const 0)
                                         (i32.const 1)
                                         (struct.get $type12 1
                                          (local.get $3)
                                         )
                                         (struct.new $type12
                                          (struct.get $type12 0
                                           (local.get $3)
                                          )
                                          (local.get $6)
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1430)
            )
           )
           (local.get $scratch_14)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1234)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1229)
         )
        )
        (if
         (i64.eq
          (local.tee $1
           (struct.get $type69 0
            (global.get $global1228)
           )
          )
          (i64.const 9223372036854775807)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global1148)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1140)
           )
          )
          (call $foreign21
           (call $function314
            (global.get $string10)
            (call $foreign19)
            (i32.const 1)
            (i64.const 40)
            (i32.const 1)
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
          (unreachable)
         )
         (else
          (struct.set $type69 0
           (ref.as_non_null
            (global.get $global1228)
           )
           (block (result i64)
            (if
             (i64.lt_s
              (i64.and
               (i64.xor
                (local.get $1)
                (local.tee $12
                 (i64.add
                  (local.get $1)
                  (i64.const 1)
                 )
                )
               )
               (i64.xor
                (local.get $12)
                (i64.const 1)
               )
              )
              (i64.const 0)
             )
             (then
              (unreachable)
             )
            )
            (local.get $12)
           )
          )
         )
        )
        (struct.new $type228
         (i32.const 1)
         (struct.new $type38
          (i32.const 7)
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready1751)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1751)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 9)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 10)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 11)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 12)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 13)
                                    )
                                    (else
                                     (call $function467
                                      (i32.const 0)
                                      (i32.const 1)
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                      (i64.const 14)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global199)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready1757)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1757)
         )
        )
        (return_call $function468
         (local.get $2)
         (struct.new $type41
          (array.new_default $type42
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type226))
     (i32.eq
      (struct.get $type277 0
       (local.get $7)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type229
       (i32.const 2)
       (global.get $string68)
      )
     )
     (else
      (if (result (ref $type226))
       (i32.eq
        (struct.get $type277 0
         (local.get $7)
        )
        (i32.const 3)
       )
       (then
        (if (result (ref $type226))
         (i32.and
          (i32.eqz
           (ref.is_null
            (local.get $2)
           )
          )
          (i64.eqz
           (local.get $1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready1770)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1770)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1583)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1585)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1585)
           )
          )
          (local.set $7
           (call $function418
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1727)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1727)
           )
          )
          (if (result (ref $type226))
           (i32.eq
            (struct.get $type226 0
             (local.tee $8
              (call $function460
               (local.get $0)
               (local.get $7)
              )
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $10
             (struct.get $type228 1
              (ref.cast (ref $type228)
               (local.get $8)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1585)
             )
            )
            (if (result (ref $type226))
             (i32.eq
              (struct.get $type277 0
               (local.tee $7
                (call $function418
                 (local.get $0)
                )
               )
              )
              (i32.const 2)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready1743)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global1743)
               )
              )
              (struct.new $type228
               (i32.const 1)
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $10)
                )
                (else
                 (local.set $3
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1236)
                  )
                 )
                 (drop
                  (struct.get $type12 0
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1231)
                  )
                 )
                 (local.set $5
                  (call $function335)
                 )
                 (if
                  (i32.eqz
                   (global.get $ready1743)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1743)
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $4
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1236)
                    )
                   )
                   (drop
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1231)
                    )
                   )
                   (local.set $5
                    (call $function335)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready1743)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global1743)
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1236)
                      )
                     )
                     (drop
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1231)
                      )
                     )
                     (local.set $5
                      (call $function335)
                     )
                     (if
                      (i32.eqz
                       (global.get $ready1743)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global1743)
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $4
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1236)
                        )
                       )
                       (drop
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1231)
                        )
                       )
                       (local.set $5
                        (call $function335)
                       )
                       (if
                        (i32.eqz
                         (global.get $ready1743)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global1743)
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $3
                          (struct.get $type12 1
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1236)
                          )
                         )
                         (drop
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1231)
                          )
                         )
                         (local.set $5
                          (call $function335)
                         )
                         (if
                          (i32.eqz
                           (global.get $ready1743)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global1743)
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $4
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1236)
                            )
                           )
                           (drop
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1231)
                            )
                           )
                           (local.set $5
                            (call $function335)
                           )
                           (if
                            (i32.eqz
                             (global.get $ready1743)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global1743)
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $3
                              (struct.get $type12 1
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1236)
                              )
                             )
                             (drop
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1231)
                              )
                             )
                             (local.set $5
                              (call $function335)
                             )
                             (if
                              (i32.eqz
                               (global.get $ready1743)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global1743)
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $4
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1236)
                                )
                               )
                               (drop
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1231)
                                )
                               )
                               (local.set $5
                                (call $function335)
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready1743)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global1743)
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1236)
                                  )
                                 )
                                 (drop
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1231)
                                  )
                                 )
                                 (local.set $5
                                  (call $function335)
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready1743)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global1743)
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (local.set $4
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1236)
                                    )
                                   )
                                   (drop
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1231)
                                    )
                                   )
                                   (local.set $5
                                    (call $function335)
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready1743)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global1743)
                                    )
                                   )
                                   (if (result (ref $type13))
                                    (ref.is_null
                                     (local.get $4)
                                    )
                                    (then
                                     (local.get $5)
                                    )
                                    (else
                                     (local.set $3
                                      (struct.get $type12 1
                                       (local.get $4)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1236)
                                      )
                                     )
                                     (drop
                                      (struct.get $type12 0
                                       (local.get $4)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1231)
                                      )
                                     )
                                     (local.set $5
                                      (call $function335)
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready1743)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global1743)
                                      )
                                     )
                                     (if (result (ref $type13))
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (local.get $5)
                                      )
                                      (else
                                       (local.set $4
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1236)
                                        )
                                       )
                                       (drop
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1231)
                                        )
                                       )
                                       (local.set $5
                                        (call $function335)
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready1743)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global1743)
                                        )
                                       )
                                       (if (result (ref $type13))
                                        (ref.is_null
                                         (local.get $4)
                                        )
                                        (then
                                         (local.get $5)
                                        )
                                        (else
                                         (local.set $3
                                          (struct.get $type12 1
                                           (local.get $4)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1236)
                                          )
                                         )
                                         (drop
                                          (struct.get $type12 0
                                           (local.get $4)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1231)
                                          )
                                         )
                                         (local.set $5
                                          (call $function335)
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready1743)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global1743)
                                          )
                                         )
                                         (if (result (ref $type13))
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (local.get $5)
                                          )
                                          (else
                                           (call $function463
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                            (block (result (ref $type36))
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1236)
                                              )
                                             )
                                             (drop
                                              (struct.get $type12 0
                                               (local.get $3)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1231)
                                              )
                                             )
                                             (local.set $scratch_15
                                              (call $function335)
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready1743)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global1743)
                                              )
                                             )
                                             (local.get $scratch_15)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type229))
               (i32.eq
                (struct.get $type277 0
                 (local.get $7)
                )
                (i32.const 6)
               )
               (then
                (struct.new $type229
                 (i32.const 2)
                 (struct.get $type284 1
                  (ref.cast (ref $type284)
                   (local.get $7)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type229))
                 (local.tee $11
                  (struct.get $type277 0
                   (local.get $7)
                  )
                 )
                 (then
                  (if (result (ref $type229))
                   (i32.eq
                    (local.get $11)
                    (i32.const 1)
                   )
                   (then
                    (struct.new $type229
                     (i32.const 2)
                     (global.get $string74)
                    )
                   )
                   (else
                    (if (result (ref $type229))
                     (i32.eq
                      (struct.get $type277 0
                       (local.get $7)
                      )
                      (i32.const 3)
                     )
                     (then
                      (struct.new $type229
                       (i32.const 2)
                       (global.get $string73)
                      )
                     )
                     (else
                      (if (result (ref $type229))
                       (i32.eq
                        (struct.get $type277 0
                         (local.get $7)
                        )
                        (i32.const 4)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type282)
                          (local.get $7)
                         )
                        )
                        (struct.new $type229
                         (i32.const 2)
                         (global.get $string72)
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type283)
                          (local.get $7)
                         )
                        )
                        (struct.new $type229
                         (i32.const 2)
                         (global.get $string71)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type278)
                    (local.get $7)
                   )
                  )
                  (struct.new $type229
                   (i32.const 2)
                   (global.get $string75)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type229))
             (struct.get $type226 0
              (local.get $8)
             )
             (then
              (struct.new $type229
               (i32.const 2)
               (struct.get $type229 1
                (ref.cast (ref $type229)
                 (local.get $8)
                )
               )
              )
             )
             (else
              (struct.new $type229
               (i32.const 2)
               (global.get $string70)
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type229
           (i32.const 2)
           (global.get $string67)
          )
         )
        )
       )
       (else
        (if (result (ref $type229))
         (i32.eq
          (struct.get $type277 0
           (local.get $7)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type229
           (i32.const 2)
           (struct.get $type284 1
            (ref.cast (ref $type284)
             (local.get $7)
            )
           )
          )
         )
         (else
          (if (result (ref $type229))
           (local.tee $11
            (struct.get $type277 0
             (local.get $7)
            )
           )
           (then
            (if
             (i32.eq
              (local.get $11)
              (i32.const 4)
             )
             (then
              (drop
               (ref.cast (ref $type282)
                (local.get $7)
               )
              )
             )
             (else
              (drop
               (ref.cast (ref $type283)
                (local.get $7)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1727)
             )
            )
            (local.set $8
             (call $function460
              (local.get $0)
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1784)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1784)
             )
            )
            (if (result (ref $type229))
             (i32.eq
              (struct.get $type226 0
               (local.get $8)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global1734)
               )
              )
              (return_call $function461
               (local.get $0)
               (local.get $1)
               (struct.new $type12
                (struct.get $type228 1
                 (ref.cast (ref $type228)
                  (local.get $8)
                 )
                )
                (local.get $2)
               )
              )
             )
             (else
              (if (result (ref $type229))
               (i32.eq
                (struct.get $type226 0
                 (local.get $8)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type229
                 (i32.const 2)
                 (struct.get $type229 1
                  (ref.cast (ref $type229)
                   (local.get $8)
                  )
                 )
                )
               )
               (else
                (unreachable)
               )
              )
             )
            )
           )
           (else
            (local.set $6
             (struct.new $type12
              (struct.get $type278 1
               (ref.cast (ref $type278)
                (local.get $7)
               )
              )
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready1734)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1734)
             )
            )
            (return_call $function461
             (local.get $0)
             (local.get $1)
             (local.get $6)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function463 (type $call309) (param $0 (ref null $type12)) (param $1 (ref $type36)) (result (ref $type13))
  (local $2 (ref null $type12))
  (local $scratch (ref $type36))
  (if (result (ref $type36))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function463
     (struct.get $type12 1
      (local.get $0)
     )
     (block (result (ref $type36))
      (drop
       (ref.as_non_null
        (global.get $global1236)
       )
      )
      (drop
       (struct.get $type12 0
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1231)
       )
      )
      (local.set $scratch
       (call $function335)
      )
      (if
       (i32.eqz
        (global.get $ready1743)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1743)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function465 (type $14) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function465
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function467 (type $54) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $4
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function467
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $4)
    )
   )
  )
 )
 (func $function468 (type $call313) (param $0 (ref null $type12)) (param $1 (ref $type41)) (param $2 i64) (result (ref $type226))
  (local $3 (ref $type13))
  (local $4 (ref $type24))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result (ref $type226))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type228
     (i32.const 1)
     (struct.new $type40
      (i32.const 8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global1762)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1263)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1249)
     )
    )
    (if (result (ref $type229))
     (if (result i32)
      (i64.lt_s
       (local.tee $5
        (if (result i64)
         (i64.eq
          (if (result i64)
           (local.tee $7
            (struct.get $type13 0
             (local.tee $3
              (struct.get $type12 0
               (local.get $0)
              )
             )
            )
           )
           (then
            (if (result i64)
             (i32.eq
              (local.get $7)
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type15)
                (local.get $3)
               )
              )
              (i64.const 1)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type13 0
                 (local.get $3)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type16)
                  (local.get $3)
                 )
                )
                (i64.const 2)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $3)
                  )
                  (i32.const 3)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type17)
                    (local.get $3)
                   )
                  )
                  (i64.const 3)
                 )
                 (else
                  (if (result i64)
                   (i32.eq
                    (struct.get $type13 0
                     (local.get $3)
                    )
                    (i32.const 4)
                   )
                   (then
                    (drop
                     (ref.cast (ref $type21)
                      (local.get $3)
                     )
                    )
                    (i64.const 4)
                   )
                   (else
                    (if (result i64)
                     (i32.eq
                      (struct.get $type13 0
                       (local.get $3)
                      )
                      (i32.const 5)
                     )
                     (then
                      (drop
                       (ref.cast (ref $type23)
                        (local.get $3)
                       )
                      )
                      (i64.const 5)
                     )
                     (else
                      (if (result i64)
                       (i32.eq
                        (struct.get $type13 0
                         (local.get $3)
                        )
                        (i32.const 6)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type36)
                          (local.get $3)
                         )
                        )
                        (i64.const 6)
                       )
                       (else
                        (if (result i64)
                         (i32.eq
                          (struct.get $type13 0
                           (local.get $3)
                          )
                          (i32.const 7)
                         )
                         (then
                          (drop
                           (ref.cast (ref $type38)
                            (local.get $3)
                           )
                          )
                          (i64.const 7)
                         )
                         (else
                          (drop
                           (ref.cast (ref $type40)
                            (local.get $3)
                           )
                          )
                          (i64.const 8)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (i64.const 0)
           )
          )
          (i64.const 5)
         )
         (then
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $3)
            )
            (i32.const 5)
           )
           (then
            (unreachable)
           )
          )
          (if (result i64)
           (struct.get $type24 0
            (local.tee $4
             (struct.get $type23 1
              (ref.cast (ref $type23)
               (local.get $3)
              )
             )
            )
           )
           (then
            (if
             (i32.eq
              (struct.get $type24 0
               (local.get $4)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type26)
                (local.get $4)
               )
              )
             )
             (else
              (if
               (i32.eq
                (struct.get $type24 0
                 (local.get $4)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type30)
                  (local.get $4)
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type31)
                  (local.get $4)
                 )
                )
               )
              )
             )
            )
            (i64.const -1)
           )
           (else
            (struct.get $type25 1
             (ref.cast (ref $type25)
              (local.get $4)
             )
            )
           )
          )
         )
         (else
          (i64.const -1)
         )
        )
       )
       (i64.const 0)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $5)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type229
       (i32.const 2)
       (global.get $string69)
      )
     )
     (else
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $6
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
          (local.get $2)
         )
         (i64.xor
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 0)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type42
       (struct.get $type41 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (return_call $function468
       (struct.get $type12 1
        (local.get $0)
       )
       (block (result (ref $type41))
        (if
         (i64.lt_s
          (i64.and
           (i64.xor
            (local.tee $5
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
            (local.get $2)
           )
           (i64.xor
            (local.get $2)
            (i64.const 1)
           )
          )
          (i64.const 0)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready1757)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1757)
         )
        )
        (local.get $1)
       )
       (local.get $5)
      )
     )
    )
   )
  )
 )
 (func $function475 (type $call315) (param $0 (ref $type68)) (param $1 (ref $type65)) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global152)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global139)
   )
  )
  (local.set $3
   (call $function55
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if (result i32)
   (ref.test (ref $type89)
    (local.tee $4
     (if (result (ref $type88))
      (i32.eq
       (local.get $3)
       (i32.const -1)
      )
      (then
       (global.get $empty89)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $2
          (i64.extend_i32_s
           (local.get $3)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $2)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $2)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type90
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (call $foreign10
     (struct.get $type66 0
      (struct.get $type65 0
       (local.get $1)
      )
     )
     (struct.get $type90 0
      (ref.cast (ref $type90)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready1803)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1803)
     )
    )
    (return_call $function475
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function487 (type $9) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 i32)
  (local $5 i64)
  (local $6 (ref $type18))
  (local $7 (ref $type18))
  (local $8 (ref $type68))
  (local $9 (ref $type66))
  (local $10 (ref $type65))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1843)
     )
    )
    (local.set $7
     (struct.get $type83 1
      (global.get $global1836)
     )
    )
    (if
     (i32.eqz
      (call $foreign39)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1843)
     )
    )
    (local.set $6
     (struct.get $type83 2
      (global.get $global1836)
     )
    )
    (if
     (i32.eqz
      (call $foreign39)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1808)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $6)
      (local.tee $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $6)
        )
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eq
      (call $foreign2)
      (i32.const 1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global120)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global113)
       )
      )
      (call $foreign0)
      (drop
       (call $function45
        (local.get $6)
        (local.get $5)
        (i32.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (call $foreign3)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1818)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $7)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $8
     (struct.new $type68
      (struct.new $type66
       (call $foreign5)
      )
      (struct.new_default $type69)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1813)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global113)
     )
    )
    (call $foreign0)
    (drop
     (call $function45
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $6)
       )
      )
      (i32.const 1)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (local.set $10
     (struct.new $type65
      (struct.new $type66
       (call $foreign4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1803)
     )
    )
    (drop
     (call $function475
      (local.get $8)
      (local.get $10)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $4
         (struct.get $type66 0
          (local.tee $9
           (struct.get $type65 0
            (local.get $10)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $4)
          (i32.const -3)
         )
         (i32.eq
          (local.get $4)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type66 0
       (local.get $9)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (struct.set $type69 0
     (struct.get $type68 1
      (local.get $8)
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $4
         (struct.get $type66 0
          (local.tee $9
           (struct.get $type68 0
            (local.get $8)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $4)
          (i32.const -3)
         )
         (i32.eq
          (local.get $4)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type66 0
       (local.get $9)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $4)
      )
     )
    )
    (if
     (i64.lt_s
      (i64.and
       (i64.xor
        (local.get $3)
        (local.tee $5
         (i64.add
          (local.get $3)
          (i64.const 1)
         )
        )
       )
       (i64.xor
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function487
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $5)
    )
   )
   (else
    (i64.const 1)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1846)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1846)
   )
  )
  (return_call $function487
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1842)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1842)
   )
  )
  (struct.get $type83 0
   (global.get $global1836)
  )
 )
 (func $main
  (local $0 (ref $type226))
  (local $1 (ref null $type68))
  (local $2 (ref $type277))
  (local $3 (ref $type24))
  (local $4 (ref $type13))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type18))
  (local $8 (ref $type83))
  (local $9 (ref $type66))
  (local $10 i32)
  (local $11 i64)
  (local $scratch (ref $type18))
  (local $scratch_13 (ref $type83))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global1430
   (struct.new_default $type46)
  )
  (global.set $global1433
   (struct.new_default $type50)
  )
  (global.set $ready1433
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type54)
  )
  (global.set $global81
   (struct.new_default $type58)
  )
  (global.set $global86
   (struct.new_default $type59)
  )
  (global.set $global88
   (struct.new_default $type60)
  )
  (global.set $global91
   (struct.new_default $type62)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type63)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type64)
  )
  (drop
   (call $foreign41)
  )
  (drop
   (call $foreign40)
  )
  (global.set $global113
   (struct.new_default $type72)
  )
  (global.set $global118
   (struct.new_default $type73)
  )
  (global.set $global120
   (struct.new_default $type72)
  )
  (global.set $global122
   (struct.new_default $type74)
  )
  (global.set $global124
   (struct.new_default $type75)
  )
  (global.set $global126
   (struct.new_default $type76)
  )
  (global.set $global131
   (struct.new_default $type77)
  )
  (global.set $global128
   (struct.new_default $type78)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global1813
   (struct.new_default $type79)
  )
  (global.set $global1818
   (struct.new_default $type80)
  )
  (global.set $global1837
   (struct.new_default $type81)
  )
  (global.set $ready1837
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type84)
  )
  (global.set $global137
   (struct.new_default $type85)
  )
  (global.set $global139
   (struct.new_default $type86)
  )
  (global.set $global143
   (struct.new_default $type86)
  )
  (global.set $global150
   (struct.new_default $type91)
  )
  (global.set $global152
   (struct.new_default $type92)
  )
  (global.set $global154
   (struct.new_default $type92)
  )
  (global.set $global176
   (struct.new_default $type100)
  )
  (global.set $global199
   (struct.new_default $type104)
  )
  (global.set $global335
   (struct.new $type28
    (i32.const 0)
    (array.new_fixed $type29 0)
   )
  )
  (global.set $global336
   (struct.new_default $type129)
  )
  (global.set $global339
   (struct.new_default $type130)
  )
  (global.set $global343
   (struct.new_default $type131)
  )
  (global.set $global345
   (struct.new_default $type132)
  )
  (global.set $global349
   (struct.new_default $type52)
  )
  (global.set $global353
   (struct.new_default $type133)
  )
  (global.set $global357
   (struct.new_default $type134)
  )
  (global.set $global359
   (struct.new_default $type135)
  )
  (global.set $global361
   (struct.new_default $type135)
  )
  (global.set $global363
   (struct.new_default $type115)
  )
  (global.set $global368
   (struct.new_default $type136)
  )
  (global.set $global376
   (struct.new_default $type137)
  )
  (global.set $global385
   (struct.new_default $type138)
  )
  (global.set $global398
   (struct.new_default $type139)
  )
  (global.set $global402
   (struct.new_default $type140)
  )
  (global.set $global405
   (struct.new_default $type140)
  )
  (global.set $global408
   (struct.new_default $type140)
  )
  (global.set $global414
   (struct.new_default $type140)
  )
  (global.set $global417
   (struct.new_default $type129)
  )
  (global.set $global420
   (struct.new_default $type141)
  )
  (global.set $global429
   (struct.new_default $type141)
  )
  (global.set $global438
   (struct.new_default $type142)
  )
  (global.set $global442
   (struct.new_default $type143)
  )
  (global.set $global452
   (struct.new_default $type144)
  )
  (global.set $global463
   (struct.new_default $type141)
  )
  (global.set $global469
   (struct.new_default $type143)
  )
  (global.set $global472
   (struct.new_default $type145)
  )
  (global.set $global481
   (struct.new_default $type146)
  )
  (global.set $global489
   (struct.new_default $type146)
  )
  (global.set $global501
   (struct.new_default $type147)
  )
  (global.set $global513
   (struct.new_default $type148)
  )
  (global.set $global522
   (struct.new_default $type146)
  )
  (global.set $global527
   (struct.new_default $type149)
  )
  (global.set $global533
   (struct.new_default $type150)
  )
  (global.set $global542
   (struct.new_default $type152)
  )
  (global.set $global551
   (struct.new_default $type152)
  )
  (global.set $global557
   (struct.new_default $type143)
  )
  (global.set $global560
   (struct.new_default $type143)
  )
  (global.set $global563
   (struct.new_default $type123)
  )
  (global.set $global571
   (struct.new_default $type153)
  )
  (global.set $global577
   (struct.new_default $type154)
  )
  (global.set $global588
   (struct.new_default $type155)
  )
  (global.set $global593
   (struct.new_default $type156)
  )
  (global.set $global598
   (struct.new_default $type157)
  )
  (global.set $global606
   (struct.new_default $type158)
  )
  (global.set $global652
   (struct.new_default $type135)
  )
  (global.set $global656
   (struct.new_default $type143)
  )
  (global.set $global667
   (struct.new_default $type163)
  )
  (global.set $global670
   (struct.new_default $type115)
  )
  (global.set $global710
   (struct.new_default $type137)
  )
  (global.set $global714
   (struct.new_default $type136)
  )
  (global.set $global716
   (struct.new_default $type169)
  )
  (global.set $global725
   (struct.new_default $type170)
  )
  (global.set $global729
   (struct.new_default $type139)
  )
  (global.set $global736
   (struct.new_default $type171)
  )
  (global.set $global741
   (struct.new_default $type172)
  )
  (global.set $global746
   (struct.new_default $type172)
  )
  (global.set $global752
   (struct.new_default $type134)
  )
  (global.set $global754
   (struct.new_default $type143)
  )
  (drop
   (ref.as_non_null
    (global.get $global368)
   )
  )
  (global.set $global780
   (call $function126
    (i64.const 1)
   )
  )
  (global.set $global781
   (struct.new_default $type174)
  )
  (global.set $global790
   (struct.new_default $type176)
  )
  (global.set $global792
   (struct.new_default $type176)
  )
  (global.set $global839
   (struct.new_default $type183)
  )
  (global.set $global847
   (struct.new_default $type185)
  )
  (global.set $global849
   (struct.new_default $type186)
  )
  (global.set $global859
   (struct.new_default $type189)
  )
  (global.set $global865
   (struct.new_default $type189)
  )
  (global.set $global871
   (struct.new_default $type190)
  )
  (global.set $global883
   (struct.new_default $type192)
  )
  (global.set $global886
   (struct.new_default $type192)
  )
  (global.set $global1140
   (struct.new_default $type208)
  )
  (global.set $global1148
   (struct.new_default $type209)
  )
  (global.set $global1154
   (struct.new_default $type210)
  )
  (global.set $global1166
   (struct.new_default $type213)
  )
  (global.set $global1174
   (struct.new_default $type214)
  )
  (global.set $global1183
   (struct.new_default $type215)
  )
  (global.set $global1189
   (struct.new_default $type216)
  )
  (global.set $global1193
   (struct.new_default $type217)
  )
  (global.set $global1199
   (struct.new_default $type218)
  )
  (global.set $global1206
   (struct.new_default $type218)
  )
  (global.set $global1209
   (struct.new_default $type223)
  )
  (global.set $global1215
   (struct.new_default $type224)
  )
  (global.set $global1217
   (struct.new_default $type225)
  )
  (global.set $global1224
   (struct.new_default $type230)
  )
  (global.set $global1228
   (struct.new $type69
    (i64.const 1)
   )
  )
  (global.set $global1229
   (struct.new_default $type5)
  )
  (global.set $global1231
   (struct.new_default $type231)
  )
  (global.set $global1234
   (struct.new_default $type232)
  )
  (global.set $global1236
   (struct.new_default $type233)
  )
  (global.set $global1249
   (struct.new_default $type236)
  )
  (global.set $global1263
   (struct.new_default $type237)
  )
  (global.set $global1578
   (struct.new_default $type262)
  )
  (global.set $global1583
   (struct.new_default $type263)
  )
  (global.set $global1590
   (struct.new_default $type264)
  )
  (global.set $global1608
   (struct.new_default $type84)
  )
  (global.set $global1588
   (struct.new_default $type84)
  )
  (global.set $global1596
   (struct.new_default $type265)
  )
  (global.set $global1605
   (struct.new_default $type266)
  )
  (global.set $global1594
   (struct.new_default $type267)
  )
  (global.set $global1688
   (struct.new_default $type267)
  )
  (global.set $global1618
   (struct.new_default $type268)
  )
  (global.set $global1657
   (struct.new_default $type271)
  )
  (global.set $global1661
   (struct.new_default $type272)
  )
  (global.set $ready1661
   (i32.const 1)
  )
  (global.set $global1624
   (struct.new_default $type273)
  )
  (global.set $global1690
   (struct.new_default $type274)
  )
  (global.set $global1698
   (struct.new_default $type59)
  )
  (global.set $global1599
   (struct.new_default $type77)
  )
  (global.set $ready1599
   (i32.const 1)
  )
  (global.set $global1681
   (struct.new_default $type275)
  )
  (global.set $ready1681
   (i32.const 1)
  )
  (global.set $global1676
   (struct.new_default $type276)
  )
  (global.set $global1585
   (struct.new_default $type276)
  )
  (global.set $ready1585
   (i32.const 1)
  )
  (global.set $global1602
   (struct.new_default $type285)
  )
  (global.set $ready1602
   (i32.const 1)
  )
  (global.set $global1673
   (struct.new_default $type276)
  )
  (global.set $ready1673
   (i32.const 1)
  )
  (global.set $global1714
   (struct.new_default $type276)
  )
  (global.set $ready1714
   (i32.const 1)
  )
  (global.set $global1716
   (struct.new_default $type286)
  )
  (global.set $ready1716
   (i32.const 1)
  )
  (global.set $global1722
   (struct.new_default $type286)
  )
  (global.set $ready1722
   (i32.const 1)
  )
  (global.set $global1610
   (struct.new_default $type287)
  )
  (global.set $ready1610
   (i32.const 1)
  )
  (global.set $global1615
   (struct.new_default $type288)
  )
  (global.set $ready1615
   (i32.const 1)
  )
  (global.set $global1619
   (struct.new_default $type292)
  )
  (global.set $ready1619
   (i32.const 1)
  )
  (global.set $global1667
   (struct.new_default $type293)
  )
  (global.set $ready1667
   (i32.const 1)
  )
  (global.set $global1650
   (struct.new_default $type294)
  )
  (global.set $ready1650
   (i32.const 1)
  )
  (global.set $global1626
   (struct.new_default $type299)
  )
  (global.set $ready1626
   (i32.const 1)
  )
  (global.set $global1643
   (struct.new_default $type267)
  )
  (global.set $ready1643
   (i32.const 1)
  )
  (global.set $global1648
   (struct.new_default $type77)
  )
  (global.set $ready1648
   (i32.const 1)
  )
  (global.set $global1645
   (struct.new_default $type300)
  )
  (global.set $ready1645
   (i32.const 1)
  )
  (global.set $global1641
   (struct.new_default $type115)
  )
  (global.set $global1638
   (struct.new_default $type267)
  )
  (global.set $global1635
   (struct.new_default $type301)
  )
  (global.set $global1630
   (struct.new_default $type302)
  )
  (global.set $ready1630
   (i32.const 1)
  )
  (global.set $global1706
   (struct.new_default $type303)
  )
  (global.set $global1685
   (struct.new_default $type276)
  )
  (global.set $ready1685
   (i32.const 1)
  )
  (global.set $global1695
   (struct.new_default $type286)
  )
  (global.set $ready1695
   (i32.const 1)
  )
  (global.set $global1704
   (struct.new_default $type303)
  )
  (global.set $ready1704
   (i32.const 1)
  )
  (global.set $global1727
   (struct.new_default $type304)
  )
  (global.set $ready1727
   (i32.const 1)
  )
  (global.set $global1794
   (struct.new_default $type305)
  )
  (global.set $ready1794
   (i32.const 1)
  )
  (global.set $global1734
   (struct.new_default $type306)
  )
  (global.set $ready1734
   (i32.const 1)
  )
  (global.set $global1784
   (struct.new_default $type307)
  )
  (global.set $ready1784
   (i32.const 1)
  )
  (global.set $global1770
   (struct.new_default $type308)
  )
  (global.set $ready1770
   (i32.const 1)
  )
  (global.set $global1743
   (struct.new_default $type309)
  )
  (global.set $ready1743
   (i32.const 1)
  )
  (global.set $global1746
   (struct.new_default $type310)
  )
  (global.set $global1740
   (struct.new_default $type311)
  )
  (global.set $ready1740
   (i32.const 1)
  )
  (global.set $global1751
   (struct.new_default $type312)
  )
  (global.set $ready1751
   (i32.const 1)
  )
  (global.set $global1762
   (struct.new_default $type236)
  )
  (global.set $global1757
   (struct.new_default $type313)
  )
  (global.set $ready1757
   (i32.const 1)
  )
  (global.set $global1803
   (struct.new_default $type315)
  )
  (global.set $ready1803
   (i32.const 1)
  )
  (global.set $global1808
   (struct.new_default $type316)
  )
  (global.set $global1823
   (struct.new_default $type236)
  )
  (global.set $global1831
   (struct.new_default $type82)
  )
  (drop
   (ref.as_non_null
    (global.get $global1831)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1837)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1837)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global113)
   )
  )
  (call $foreign0)
  (drop
   (call $function45
    (global.get $string79)
    (i64.const 9)
    (i32.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (global.set $global1836
   (block (result (ref $type83))
    (local.set $scratch_13
     (block $block1 (result (ref $type83))
      (local.set $1
       (struct.new $type68
        (struct.new $type66
         (call $foreign5)
        )
        (struct.new_default $type69)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1583)
       )
      )
      (if
       (i32.eqz
        (global.get $ready1585)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1585)
       )
      )
      (local.set $2
       (call $function418
        (ref.as_non_null
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready1727)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1727)
       )
      )
      (local.set $0
       (call $function460
        (ref.as_non_null
         (local.get $1)
        )
        (local.get $2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global1578)
       )
      )
      (block $block
       (br_if $block
        (i32.ne
         (struct.get $type226 0
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1823)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.tee $4
           (struct.get $type228 1
            (ref.cast (ref $type228)
             (local.get $0)
            )
           )
          )
         )
         (i32.const 5)
        )
        (then
         (unreachable)
        )
       )
       (br $block1
        (struct.new $type83
         (if (result i64)
          (struct.get $type24 0
           (local.tee $3
            (struct.get $type23 1
             (ref.cast (ref $type23)
              (local.get $4)
             )
            )
           )
          )
          (then
           (if
            (i32.eq
             (struct.get $type24 0
              (local.get $3)
             )
             (i32.const 1)
            )
            (then
             (drop
              (ref.cast (ref $type26)
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1148)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1140)
              )
             )
             (call $foreign21
              (call $function314
               (global.get $string78)
               (call $foreign19)
               (i32.const 1)
               (i64.const 18)
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (unreachable)
            )
            (else
             (if
              (i32.eq
               (struct.get $type24 0
                (local.get $3)
               )
               (i32.const 2)
              )
              (then
               (drop
                (ref.cast (ref $type30)
                 (local.get $3)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type31)
                 (local.get $3)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1148)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1140)
              )
             )
             (call $foreign21
              (call $function314
               (global.get $string77)
               (call $foreign19)
               (i32.const 1)
               (i64.const 19)
               (i32.const 1)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (unreachable)
            )
           )
           (unreachable)
          )
          (else
           (struct.get $type25 1
            (ref.cast (ref $type25)
             (local.get $3)
            )
           )
          )
         )
         (block (result (ref $type18))
          (drop
           (ref.as_non_null
            (global.get $global1583)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1585)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1585)
           )
          )
          (local.set $2
           (call $function418
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1727)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1727)
           )
          )
          (local.set $0
           (call $function460
            (ref.as_non_null
             (local.get $1)
            )
            (local.get $2)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1578)
           )
          )
          (br_if $block
           (i32.ne
            (struct.get $type226 0
             (local.get $0)
            )
            (i32.const 1)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.tee $4
              (struct.get $type228 1
               (ref.cast (ref $type228)
                (local.get $0)
               )
              )
             )
            )
            (i32.const 3)
           )
           (then
            (unreachable)
           )
          )
          (struct.get $type17 1
           (ref.cast (ref $type17)
            (local.get $4)
           )
          )
         )
         (block (result (ref $type18))
          (drop
           (ref.as_non_null
            (global.get $global1583)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1585)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1585)
           )
          )
          (local.set $2
           (call $function418
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1727)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1727)
           )
          )
          (local.set $0
           (call $function460
            (ref.as_non_null
             (local.get $1)
            )
            (local.get $2)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1578)
           )
          )
          (br_if $block
           (i32.ne
            (struct.get $type226 0
             (local.get $0)
            )
            (i32.const 1)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.tee $4
              (struct.get $type228 1
               (ref.cast (ref $type228)
                (local.get $0)
               )
              )
             )
            )
            (i32.const 3)
           )
           (then
            (unreachable)
           )
          )
          (local.set $scratch
           (struct.get $type17 1
            (ref.cast (ref $type17)
             (local.get $4)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1583)
           )
          )
          (if
           (i32.eqz
            (global.get $ready1585)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1585)
           )
          )
          (local.set $2
           (call $function418
            (ref.as_non_null
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready1727)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1727)
           )
          )
          (local.set $0
           (call $function460
            (ref.as_non_null
             (local.get $1)
            )
            (local.get $2)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global1578)
           )
          )
          (br_if $block
           (i32.ne
            (struct.get $type226 0
             (local.get $0)
            )
            (i32.const 1)
           )
          )
          (drop
           (ref.cast (ref $type228)
            (local.get $0)
           )
          )
          (local.get $scratch)
         )
        )
       )
      )
      (if
       (struct.get $type226 0
        (local.get $0)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global88)
         )
        )
        (local.set $5
         (call $function35
          (struct.new $type61
           (global.get $string27)
           (struct.new $type61
            (struct.get $type229 1
             (ref.cast (ref $type229)
              (local.get $0)
             )
            )
            (ref.null none)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1148)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1140)
         )
        )
        (call $foreign21
         (call $function314
          (local.get $5)
          (call $foreign19)
          (i32.const 1)
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $5)
           )
          )
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global1148)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global1140)
         )
        )
        (call $foreign21
         (call $function314
          (global.get $string28)
          (call $foreign19)
          (i32.const 1)
          (i64.const 44)
          (i32.const 1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
       )
      )
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global131)
     )
    )
    (struct.set $type69 0
     (struct.get $type68 1
      (local.get $1)
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (if
     (i32.eqz
      (if (result i32)
       (i32.eq
        (local.tee $10
         (struct.get $type66 0
          (local.tee $9
           (struct.get $type68 0
            (local.get $1)
           )
          )
         )
        )
        (i32.const -1)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.or
         (i32.eq
          (local.get $10)
          (i32.const -3)
         )
         (i32.eq
          (local.get $10)
          (i32.const -2)
         )
        )
       )
      )
     )
     (then
      (struct.set $type66 0
       (local.get $9)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $10)
      )
     )
    )
    (local.get $scratch_13)
   )
  )
  (global.set $global1842
   (struct.new_default $type5)
  )
  (global.set $ready1842
   (i32.const 1)
  )
  (global.set $global1843
   (struct.new_default $type317)
  )
  (global.set $global1846
   (struct.new_default $type115)
  )
  (global.set $ready1846
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

