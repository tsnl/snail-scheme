(import (scheme base) (scheme cxr) (scheme read) (scheme write) (scheme file)
        (scheme process-context) (snail-scheme wasm-optimize)
        (snail-scheme chromium-trace))

;; Diagnostic only. Keep Ack's complete checked body and closure ABI, but give
;; its recursive worker a private direct signature without an environment.
;; Reading each original environment still precedes its original arguments.
(define calls 0)
(define (rewrite-calls node)
  (cond
    ((and (pair? node) (memq (car node) '(call return_call))
          (eq? (cadr node) '$function45))
     (set! calls (+ calls 1))
     `(block (result i64) (drop ,(rewrite-calls (caddr node)))
             (,(car node) $ack-worker ,@(map rewrite-calls (cdddr node)))))
    ((pair? node) (map rewrite-calls node))
    (else node)))
(define (local-read-count node)
  (cond ((equal? node '(local.get $environment)) 1)
        ((pair? node) (apply + (map local-read-count node)))
        (else 0)))
(define arguments (cdr (command-line)))
(define module (call-with-input-file (car arguments) read))
(define original
  (let find ((nodes (cdr module)))
    (cond ((null? nodes) (error "missing Ack function"))
          ((and (pair? (car nodes)) (eq? (caar nodes) 'func)
                (eq? (cadar nodes) '$function45)) (car nodes))
          (else (find (cdr nodes))))))
(unless (= (local-read-count original) 0)
  (error "Ack unexpectedly reads its environment parameter"))
(define worker
  `(func $ack-worker
         ,@(map rewrite-calls
                (let remove-abi ((nodes (cddr original)))
                  (cond ((null? nodes) '())
                        ((or (equal? (car nodes) '(type $call27))
                             (equal? (car nodes) '(param $environment eqref)))
                         (remove-abi (cdr nodes)))
                        (else (cons (car nodes) (remove-abi (cdr nodes)))))))))
(unless (= calls 3) (error "unexpected recursive Ack call count" calls))
(define wrapper
  '(func $function45 (type $call27) (param $environment eqref)
         (param $argument117 i64) (param $argument118 i64) (result i64)
         (return_call $ack-worker (local.get $argument117) (local.get $argument118))))
(define changed
  (cons (car module)
        (append (map (lambda (node) (if (eq? node original) wrapper node)) (cdr module))
                (list worker))))
(call-with-output-file (cadr arguments) (lambda (port) (write changed port)))
(with-chromium-trace-to
 (string-append (cadddr arguments) ".trace.json")
 (lambda ()
   (assemble-wasm (cadr arguments) (caddr arguments))
   (optimize-scheme-wasm (caddr arguments) (cadddr arguments))))
(display "checked-worker-with-3-environment-reads-preserved\n")
