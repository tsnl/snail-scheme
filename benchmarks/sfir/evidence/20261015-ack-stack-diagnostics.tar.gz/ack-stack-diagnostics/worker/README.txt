Diagnostic checkpoint, 15 October 2026

This folder contains targeted compiler and V8 diagnostics, not clean timing
samples. No compiler, benchmark, campaign file, canonical input, repeat count,
algorithm or predicate was changed. The isolated worktree is
/tmp/snail-sfir-ack-stack-audit-20261015 at origin/main befc4628. Its Git status
remained clean. No broad suite was launched.

Finding

The current Wasm representation couples Ack's otherwise unused environment
parameter to the benchmark loop's necessary environment. The historical
unoptimized module represents that local loop as a direct function with scalar
captures. The current unoptimized module instead creates a closure factory and
a recursive loop closure. The loop and Ack both use $call27; the optimized
current module must keep that type's environment parameter because the loop
uses it. The historical optimized Ack has only two I64 parameters.

The source change explaining this structural difference is 0df80903 (#234):
strict-infer's infer-application/infer-direct-let path was removed and every
application now uses infer-call. That deliberately enforces ordinary rank-one
lambda parameter typing. Restoring inference-time generalization would violate
the new contract. This analysis does not propose doing so. Current locations:
src/snail-scheme/strict-infer.sld:816;
src/snail-scheme/strict-specialize.sld:308-327;
src/snail-scheme/strict-wasm.sld:805-816.

The canonical recurrence still contains an ordinary call for the nested Ack
and return_call for its tail positions. This is finite-stack pressure from
non-tail recursion, not evidence that proper tail calls were lost.

Checked worker experiment

ack-worker.scm transforms only the current generated raw Wasm. It keeps the
original closure entry as a wrapper and moves its complete checked body into
a private two-I64 worker. Each of the three original recursive environment
reads remains an evaluated drop before the original call arguments. Every
arithmetic operation, all four signed-I64 overflow checks, global readiness
checks, recursive call and result computation remain. Ordinary calls remain
ordinary, tail calls remain tail calls. The wrapper ignores the original
environment only after the audit proves Ack never reads that parameter.

audit.scm reverses just this ABI rewrite and checks structural equality with
the original checked Ack. It separately checks equality of every other module
item. Both assertions passed; the retained audit command records the result.
The standard mandatory Binaryen pipeline, including -O3 --closed-world,
--always-inline-max-function-size=40 and --converge, then produced the module.

The canonical current scalar host and unchanged spec run with count 2, inputs
3 and 12, expected result 32765 and four total workload barriers. The worker
passed default V8: result 32765, barriers 4, setup_barriers 0. Its stdout includes
the harness clock, but this instrumented experiment supplies NO timing sample.

Original historical Wasm SHA256:
25da1d3dcafe2ae60c2a1b97343a328a82bcbe9d46f2e5df799a0b4172e15694
Original current checked Wasm SHA256:
2c149fbe600f1f4ad502981d01be55d02fb8eebd0371299f4c14cc5e7d07b7e8
Checked private worker Wasm SHA256:
4a43a8d8eebbb7daa2a09152daaf890b0768c96719813a147604e2b08cf6a082

Tiering limits

Artifact                    Default V8       --liftoff-only    --no-liftoff
Historical original         pass (parent)    stack overflow    stack overflow
Current checked             fail (parent)    stack overflow    fail (parent)
Current checked + worker    pass             stack overflow    stack overflow

The parent's separate removal of only Ack's four overflow checks still fails
default V8. Removing overflow guards alone is therefore insufficient; keeping
them with a private recursive worker is sufficient for this default-V8 probe.

Cold disassemblies have these explicit rsp reservations in Ack (bytes):
Artifact                    Liftoff          TurboFan
Historical original         32               32
Current checked             80               32
Current checked + worker    48               32

These numbers are instructions' explicit reservations, not complete activation
sizes. Liftoff safepoint metadata reports 11, 18 and 13 stack slots respectively;
cold TurboFan reports 8 for each. Static frame size alone does not explain why
adaptive default execution passes while either forced tier fails. Further hot
compilation/inlining investigation is unresolved. The evidence does establish
that closure/calling representation changes the default-route result with all
required arithmetic checks intact.

Possible general follow-up, not an implementation or a landing

1. Lower immediate lambda applications after typing to activation-local bindings
   while preserving their already established monotypes, evaluation order,
   initialization events, effects and traps. This could expose nonescaping local
   functions without restoring the old inference/generalization behavior.
2. Give known functions private direct workers and retain their closure ABI in
   wrappers. Direct recursive workers need not inherit unrelated closures'
   environment requirements. Preserve operator/readiness evaluation and live
   reference roots across collecting calls. The experiment validates only this
   concrete Ack transformation, not a compiler-wide implementation proof.
3. Inspect V8 hot tiering/inlining and live values across non-tail calls before
   selecting a future optimization or promising a stack-depth improvement.

All commands, errors and binary stdout/stderr are under commands/. The manifest
records immutable inputs, generated artifacts, scripts and their SHA256 values.
Original full57 validation failures remain untouched and must remain failed
routes; this experiment supplies no replacement correctness/performance result.
