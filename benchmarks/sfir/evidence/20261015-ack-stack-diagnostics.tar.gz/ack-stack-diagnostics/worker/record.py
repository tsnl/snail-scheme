#!/usr/bin/env python3
"""Record diagnostic commands; these runs are never campaign timing samples."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    label, cwd, *command = sys.argv[1:]
    directory = ROOT / "commands" / label
    directory.mkdir(parents=True, exist_ok=False)
    selected = json.loads((ROOT / "environment.json").read_text())
    environment = os.environ.copy()
    for key, value in selected.items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    record = {"kind": "diagnostic-only", "command": command, "cwd": cwd,
              "environment": selected, "timeout_seconds": 120}
    started = time.monotonic()
    try:
        result = subprocess.run(command, cwd=cwd, env=environment,
                                capture_output=True, timeout=120, check=False)
        stdout, stderr = result.stdout, result.stderr
        record.update(status="finished", returncode=result.returncode)
    except subprocess.TimeoutExpired as failure:
        stdout, stderr = failure.stdout or b"", failure.stderr or b""
        record.update(status="timeout", returncode=None)
    record["diagnostic_wall_seconds"] = time.monotonic() - started
    for name, data in [("stdout", stdout), ("stderr", stderr)]:
        (directory / (name + ".bin")).write_bytes(data)
        record[name + "_sha256"] = hashlib.sha256(data).hexdigest()
    (directory / "record.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"label": label, "status": record["status"],
                      "returncode": record["returncode"],
                      "stdout": stdout.decode(errors="replace")[:350],
                      "stderr": stderr.decode(errors="replace")[:550]}))


if __name__ == "__main__":
    main()
