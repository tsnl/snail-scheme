Diagnostic only. Same canonical Ack artifacts and inputs from full57 v1. Default failures retained. These altered V8 settings are not performance samples or replacement correctness routes.
The first two Rust diagnostic commands omitted stdin and are harness mistakes; retain their failures and use distinct corrected labels below.
