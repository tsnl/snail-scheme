#!/bin/sh
# Local test budget: one process tree, including compilers and tool subprocesses.
# The shared slice remains bounded if this launcher is interrupted or detached.
set -eu
if [ "$#" -eq 0 ]; then
  printf '%s\n' 'usage: test-bounded COMMAND [ARGUMENT ...]' >&2
  exit 2
fi
exec 9>"${XDG_RUNTIME_DIR:?a user systemd session is required}/snail-tests.lock"
flock -n 9 || { printf '%s\n' 'another bounded test is running' >&2; exit 1; }
task_active=$(systemctl --user list-units --no-legend --plain --type=service --state=active,activating 'snail-test-*')
if [ -n "$task_active" ]; then
  printf '%s\n' 'a previous bounded test still has an active service' >&2
  exit 1
fi
systemctl --user set-property --runtime snail-tests.slice \
  MemoryMax=4G MemorySwapMax=0 CPUQuota=200% TasksMax=128
# These are task/tool settings, rather than the caller's full environment.
for task_env_name in PATH CHIBI SNAIL_NATIVE_LIBC SNAIL_NATIVE_GCC RUSTC_WRAPPER \
  CARGO_TARGET_DIR LOFI_NATIVE_PROFILE LOFI_TEST_CARGO SNAIL_LOG; do
  task_env_value=$(printenv "$task_env_name" || true)
  if [ -n "$task_env_value" ]; then
    set -- "--setenv=$task_env_name=$task_env_value" "$@"
  fi
done
exec systemd-run --user --wait --pipe --collect --same-dir \
  --unit="snail-test-$$" --slice=snail-tests.slice \
  --property=MemoryMax=4G --property=MemorySwapMax=0 \
  --property=CPUQuota=200% --property=TasksMax=128 \
  --property=RuntimeMaxSec=600 --property=TimeoutStopSec=5 \
  --property=KillMode=control-group --property=OOMPolicy=kill \
  --setenv=BINARYEN_CORES=2 --setenv=CARGO_BUILD_JOBS=2 --setenv=RAYON_NUM_THREADS=2 \
  "$@"
