Fixed-probe retained-object diagnostic, 18 October 2026

Before: repository revision 812ffaad2907413a52305f184617577d32e44ab9.
After: compiler source hashes and all resource settings are recorded in the
adjacent compiler-memory-fragments-2026-10-18.json document.

Run from the corresponding repository checkout:
  chibi-scheme -h16M/1G -I bootstrap PROBE.scm . benchmarks/lofi/sboyer/main.sld
Use before-probe.scm or after-probe.scm. Bound the whole process group externally
to 4 GiB, zero swap, two CPUs, 128 tasks and 600 seconds. The output paths are fixed in
the probe; run sequentially. The only probe change is opening the final WAT as
binary output for the new serializer API. Both WAT outputs have the recorded
byte length and SHA256; the archive omits the 3.14 MB duplicate WAT files.

The public JSON diagnostic has a different observer structure. Its separately
recorded result includes additional <state>, <context> and <program> objects at
emission that the matched probe does not retain. Saved snapshots contain only
phase/timing/resident-page values and object type/count records; its observer
functions do not capture compiler inputs. Host temporary-root liveness may be
instrumentation-sensitive; the precise retention mechanism is not established.
Do not compare absolute object counts across the two probes. Instrumentation
must be held fixed for a before/after comparison.
